<?php

/**
 * @file
 * Hooks provided by the LocalGov Publications module.
 */

/**
 * @addtogroup hooks
 * @{
 */

/**
 * Alter the menu tree of a publication.
 *
 * Modules may implement this hook to alter the menu tree of a publication,
 * when it's used to build the navigation in the publication_navigation block.
 *
 * See \Drupal\localgov_publications\Plugin\Block\PublicationNavigationBlock::build()
 * for where this is called.
 *
 * @param array $tree
 *   The menu tree, as returned by
 *   \Drupal\book\BookManagerInterfacebookManager::bookTreeAllData()
 */
function hook_localgov_publications_menu_tree_alter(&$tree) {

  // This example replaces the title shown in the navigation with a shorter
  // title provided by a custom field (lbhf_teaser_title).
  foreach ($tree as $item) {
    if (!empty($item['below'])) {
      hook_localgov_publications_menu_tree_alter($item['below']);
    }

    if (!isset($item['link']['nid'])) {
      continue;
    }

    $node = Node::load($item['link']['nid']);

    if (!$node instanceof NodeInterface) {
      continue;
    }

    if (!$node->hasField('lbhf_teaser_title')) {
      continue;
    }

    $teaserTitle = $node->get('lbhf_teaser_title')->value;
    if ($teaserTitle) {
      $item['link']['title'] = $teaserTitle;
    }
  }
}

/**
 * Alter the table of contents for a publication page.
 *
 * Modules may implement this hook to alter the links shown in the table of
 * contents block. This block scans the current node's content for headings to
 * display, but may pick up headings that are unwanted if they've been inserted
 * into the node by other code in a site.
 *
 * See \Drupal\localgov_publications\Plugin\Block\TocBlock::build() for where
 * this is called.
 *
 * @param \Drupal\Core\Link[] $links
 *   The existing table of contents. An array of Link objects.
 * @param \Drupal\node\NodeInterface $node
 *   The node the links were found in.
 */
function hook_localgov_publications_toc_alter(&$links, $node) {

  // For example, if the breadcrumb trail is rendered in the node template, and
  // we wish to remove it from the table of contents:
  foreach ($links as $i => $link) {
    $options = $link->getUrl()->getOptions();
    if (isset($options['fragment']) && $options['fragment'] === 'system-breadcrumbs') {
      unset($links[$i]);
    }
  }
}

/**
 * @} End of "addtogroup hooks".
 */
