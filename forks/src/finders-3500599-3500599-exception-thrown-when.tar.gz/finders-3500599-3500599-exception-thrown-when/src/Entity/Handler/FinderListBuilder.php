<?php

namespace Drupal\finders\Entity\Handler;

use Drupal\Core\Entity\EntityInterface;
use Drupal\Core\Entity\EntityListBuilder;

/**
 * Provides the list builder handler for the Finder entity.
 */
class FinderListBuilder extends EntityListBuilder {

  /**
   * {@inheritdoc}
   */
  public function buildHeader() {
    $header = [];

    $header['name'] = $this->t('Name');
    $header['type'] = $this->t('Type');

    return $header + parent::buildHeader();
  }

  /**
   * {@inheritdoc}
   */
  public function buildRow(EntityInterface $entity) {
    $row = [];

    /** @var \Drupal\finders\Entity\FinderInterface $entity */
    $row['name'] = $entity->label();
    $row['type'] = $entity->getFinderTypePlugin()->getPluginDefinition()['label'];

    return $row + parent::buildRow($entity);
  }

}
