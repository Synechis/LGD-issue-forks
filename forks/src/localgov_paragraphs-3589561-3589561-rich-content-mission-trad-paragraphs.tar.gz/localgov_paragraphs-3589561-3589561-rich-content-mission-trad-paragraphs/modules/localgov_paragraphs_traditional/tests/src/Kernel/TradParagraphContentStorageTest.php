<?php

namespace Drupal\Tests\localgov_paragraphs_traditional\Kernel;

use Drupal\Core\Config\FileStorage;
use Drupal\Core\Field\FieldStorageDefinitionInterface;
use Drupal\KernelTests\KernelTestBase;
use Drupal\field\Entity\FieldStorageConfig;
use PHPUnit\Framework\Attributes\Group;
use PHPUnit\Framework\Attributes\RunTestsInSeparateProcesses;

/**
 * Tests the storage for localgov_trad_paragraph_content.
 *
 * @group localgov_paragraphs
 */
#[Group('localgov_paragraphs')]
#[RunTestsInSeparateProcesses]
class TradParagraphContentStorageTest extends KernelTestBase {

  /**
   * The storage's configuration name.
   */
  const CONFIG = 'field.storage.node.localgov_trad_paragraph_content';

  /**
   * {@inheritdoc}
   */
  protected static $modules = [
    'system',
    'user',
    'field',
    'text',
    'filter',
    'node',
    'file',
    'entity_reference_revisions',
    'paragraphs',
    'localgov_paragraphs_traditional',
  ];

  /**
   * {@inheritdoc}
   */
  protected function setUp(): void {
    parent::setUp();
    $this->installEntitySchema('user');
    $this->installEntitySchema('node');
    $this->installEntitySchema('paragraph');
    $this->installConfig(['system', 'field', 'text', 'filter', 'node']);
  }

  /**
   * The storage comes from config/install
   */
  public function testShippedWithTheModule(): void {
    $this->assertNull(FieldStorageConfig::loadByName('node', 'localgov_trad_paragraph_content'));

    $this->installConfig(['localgov_paragraphs_traditional']);

    $storage = FieldStorageConfig::loadByName('node', 'localgov_trad_paragraph_content');
    $this->assertNotNull($storage);
    $this->assertSame('entity_reference_revisions', $storage->getType());
    $this->assertSame('paragraph', $storage->getSetting('target_type'));
    $this->assertSame(FieldStorageDefinitionInterface::CARDINALITY_UNLIMITED, $storage->getCardinality());
    $this->assertTrue($storage->isTranslatable());
    $this->assertTrue((bool) $storage->get('persist_with_no_fields'), 'Removing the last field that uses the storage does not delete it: other content types may take it up later.');
    $this->assertSame(['localgov_paragraphs_traditional'], $storage->get('dependencies')['enforced']['module']);
    $this->assertSame([], $storage->getBundles());

    $path = $this->container->get('extension.list.module')->getPath('localgov_paragraphs_traditional') . '/config/install/';
    $shipped = (new FileStorage($path))->read(static::CONFIG);
    $active = $this->config(static::CONFIG)->get();
    unset($active['uuid'], $active['_core']);
    $this->assertSame($this->sortKeys($shipped), $this->sortKeys($active));
  }

  /**
   * Sorts an array by key, recursively.
   */
  protected function sortKeys(array $data): array {
    foreach ($data as &$value) {
      if (is_array($value)) {
        $value = $this->sortKeys($value);
      }
    }
    ksort($data);
    return $data;
  }

}
