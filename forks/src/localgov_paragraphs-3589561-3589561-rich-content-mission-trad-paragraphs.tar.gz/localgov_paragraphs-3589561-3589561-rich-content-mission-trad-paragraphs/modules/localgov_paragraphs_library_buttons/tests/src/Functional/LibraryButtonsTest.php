<?php

namespace Drupal\Tests\localgov_paragraphs_library_buttons\Functional;

use Drupal\Core\Field\FieldStorageDefinitionInterface;
use Drupal\field\Entity\FieldConfig;
use Drupal\field\Entity\FieldStorageConfig;
use Drupal\node\Entity\NodeType;
use Drupal\paragraphs\Entity\Paragraph;
use Drupal\paragraphs\Entity\ParagraphsType;
use Drupal\paragraphs_library\Entity\LibraryItem;
use Drupal\Tests\BrowserTestBase;
use PHPUnit\Framework\Attributes\Group;
use PHPUnit\Framework\Attributes\RunTestsInSeparateProcesses;

/**
 * Tests that the library buttons sit in the paragraph header, not a dropdown.
 *
 * @group localgov_paragraphs
 */
#[Group('localgov_paragraphs')]
#[RunTestsInSeparateProcesses]
class LibraryButtonsTest extends BrowserTestBase {

  /**
   * {@inheritdoc}
   */
  protected $defaultTheme = 'stark';

  /**
   * {@inheritdoc}
   */
  protected static $modules = [
    'node',
    'paragraphs',
    'paragraphs_library',
    'localgov_paragraphs_library_buttons',
  ];

  /**
   * A node with one promotable paragraph.
   *
   * @var \Drupal\node\NodeInterface
   */
  protected $node;

  /**
   * A node with one paragraph taken from the library.
   *
   * @var \Drupal\node\NodeInterface
   */
  protected $libraryNode;

  /**
   * {@inheritdoc}
   */
  protected function setUp(): void {
    parent::setUp();

    NodeType::create(['type' => 'page', 'name' => 'Page'])->save();
    $type = ParagraphsType::create(['id' => 'text', 'label' => 'Text']);
    $type->setThirdPartySetting('paragraphs_library', 'allow_library_conversion', TRUE);
    $type->save();
    FieldStorageConfig::create([
      'field_name' => 'field_text',
      'entity_type' => 'paragraph',
      'type' => 'string',
    ])->save();
    FieldConfig::create([
      'field_name' => 'field_text',
      'entity_type' => 'paragraph',
      'bundle' => 'text',
      'label' => 'Text',
    ])->save();
    $this->container->get('entity_display.repository')
      ->getFormDisplay('paragraph', 'text')
      ->setComponent('field_text', ['type' => 'string_textfield'])
      ->save();

    FieldStorageConfig::create([
      'field_name' => 'field_paragraphs',
      'entity_type' => 'node',
      'type' => 'entity_reference_revisions',
      'cardinality' => FieldStorageDefinitionInterface::CARDINALITY_UNLIMITED,
      'settings' => ['target_type' => 'paragraph'],
    ])->save();
    FieldConfig::create([
      'field_name' => 'field_paragraphs',
      'entity_type' => 'node',
      'bundle' => 'page',
      'label' => 'Paragraphs',
      'settings' => [
        'handler' => 'default:paragraph',
        'handler_settings' => ['target_bundles' => ['text' => 'text', 'from_library' => 'from_library']],
      ],
    ])->save();
    $this->container->get('entity_display.repository')
      ->getFormDisplay('node', 'page')
      ->setComponent('field_paragraphs', ['type' => 'paragraphs'])
      ->save();

    $paragraph = Paragraph::create(['type' => 'text', 'field_text' => 'Opening hours']);
    $paragraph->save();
    $this->node = $this->drupalCreateNode([
      'type' => 'page',
      'field_paragraphs' => [$paragraph],
    ]);

    $item = LibraryItem::create([
      'label' => 'Opening hours',
      'paragraphs' => Paragraph::create(['type' => 'text', 'field_text' => 'Opening hours']),
    ]);
    $item->save();
    $from_library = Paragraph::create(['type' => 'from_library', 'field_reusable_paragraph' => $item]);
    $from_library->save();
    $this->libraryNode = $this->drupalCreateNode([
      'type' => 'page',
      'field_paragraphs' => [$from_library],
    ]);

    $this->drupalLogin($this->drupalCreateUser([
      'edit any page content',
      'create paragraph library item',
      'edit paragraph library item',
      'administer paragraphs library',
    ]));
  }

  /**
   * Promote and Unlink are visible header buttons on a content form.
   */
  public function testButtonsAreInTheHeader(): void {
    $this->drupalGet($this->node->toUrl('edit-form'));
    $this->assertButtonInHeader('field_paragraphs_0_promote_to_library', 'Promote to library');

    $this->drupalGet($this->libraryNode->toUrl('edit-form'));
    $this->assertButtonInHeader('field_paragraphs_0_unlink_from_library', 'Unlink from library');

    $this->assertSession()->elementExists('css', '.paragraphs-dropdown-actions input[value="Duplicate"]');
  }

  /**
   * Without the module the same buttons sit inside the dropdown.
   */
  public function testButtonsAreInTheDropdownWithoutTheModule(): void {
    $this->container->get('module_installer')->uninstall(['localgov_paragraphs_library_buttons']);

    $this->drupalGet($this->node->toUrl('edit-form'));
    $button = $this->assertSession()->elementExists('css', 'input[name="field_paragraphs_0_promote_to_library"]');
    $this->assertTrue($button->hasClass('paragraphs-dropdown-action'));
    $this->assertSession()->elementExists('css', '.paragraphs-dropdown-actions input[name="field_paragraphs_0_promote_to_library"]');
  }

  /**
   * The library item's own form is left alone.
   *
   * Paragraphs Library offers Promote there too; it stays in the dropdown.
   */
  public function testLibraryItemFormIsUntouched(): void {
    $this->drupalGet('admin/content/paragraphs/1/edit');
    $this->assertSession()->statusCodeEquals(200);
    $button = $this->assertSession()->elementExists('css', 'input[name="paragraphs_0_promote_to_library"]');
    $this->assertTrue($button->hasClass('paragraphs-dropdown-action'));
  }

  /**
   * Asserts a widget button renders in the header, outside the dropdown.
   */
  protected function assertButtonInHeader(string $name, string $label): void {
    $button = $this->assertSession()->elementExists('css', 'input[name="' . $name . '"]');
    $this->assertSame($label, $button->getAttribute('value'));
    $this->assertFalse($button->hasClass('paragraphs-dropdown-action'), $label . ' is not a dropdown action.');
    $this->assertSession()->elementNotExists('css', '.paragraphs-dropdown-actions input[name="' . $name . '"]');
    $this->assertSession()->elementExists('css', '.paragraphs-actions input[name="' . $name . '"]');
  }

}
