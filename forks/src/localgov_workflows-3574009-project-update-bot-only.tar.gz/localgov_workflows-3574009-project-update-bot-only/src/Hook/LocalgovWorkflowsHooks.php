<?php

namespace Drupal\localgov_workflows\Hook;

use Drupal\localgov_workflows\RequireLogMessage;
use Drupal\Core\Form\FormStateInterface;
use Drupal\Core\Access\AccessResult;
use Drupal\Core\Cache\RefinableCacheableDependencyInterface;
use Drupal\workflows\Entity\Workflow;
use Drupal\node\NodeTypeInterface;
use Drupal\localgov_roles\RolesHelper;
use Drupal\Core\Hook\Attribute\Hook;
use Drupal\Core\StringTranslation\StringTranslationTrait;

/**
 * Hook implementations for localgov_workflows.
 */
class LocalgovWorkflowsHooks {
  use StringTranslationTrait;

  /**
   * Implements hook_modules_installed().
   */
  #[Hook('modules_installed')]
  public function modulesInstalled($modules, $is_syncing) {
    // Fix the core moderated content view.
    if (in_array('localgov_workflows', $modules, TRUE) && !$is_syncing) {
      // Don't change things if the core editorial workflow is enabled.
      if (!is_null(\Drupal::entityTypeManager()->getStorage('workflow')->load('editorial'))) {
        return;
      }
      $moderated_content_view = \Drupal::entityTypeManager()->getStorage('view')->load('moderated_content');
      if ($moderated_content_view) {
        // Fix filters to match editorial workflow.
        $display = $moderated_content_view->get('display');
        $filters = $display['default']['display_options']['filters'];
        $filters['moderation_state']['value'] = [
          'localgov_editorial-draft' => 'localgov_editorial-draft',
          'localgov_editorial-review' => 'localgov_editorial-review',
          'localgov_editorial-archived' => 'localgov_editorial-archived',
        ];
        $filters['moderation_state_1']['value'] = [
          'localgov_editorial-published' => 'localgov_editorial-published',
        ];
        $display['default']['display_options']['filters'] = $filters;
        // Update no results text.
        $display['default']['display_options']['empty']['area_text_custom']['content'] = 'No unpublished content available. Pages in Draft, Review and Archived states appear here.';
        $moderated_content_view->set('display', $display);
        $moderated_content_view->save();
      }
    }
  }

  /**
   * Implements hook_localgov_roles_default().
   */
  #[Hook('localgov_roles_default')]
  public function localgovRolesDefault(): array {
    return [
      RolesHelper::EDITOR_ROLE => [
        'use localgov_editorial transition approve',
        'use localgov_editorial transition archive',
        'use localgov_editorial transition archived_draft',
        'use localgov_editorial transition archived_published',
        'use localgov_editorial transition create_new_draft',
        'use localgov_editorial transition publish',
        'use localgov_editorial transition reject',
        'use localgov_editorial transition submit_for_review',
        'view all scheduled transitions',
        'view any unpublished content',
        'view latest version',
      ],
      RolesHelper::AUTHOR_ROLE => [
        'use localgov_editorial transition archive',
        'use localgov_editorial transition create_new_draft',
        'use localgov_editorial transition reject',
        'use localgov_editorial transition submit_for_review',
        'use localgov_editorial transition publish',
        'view all scheduled transitions',
        'view any unpublished content',
        'view latest version',
      ],
      RolesHelper::CONTRIBUTOR_ROLE => [
        'use localgov_editorial transition create_new_draft',
        'use localgov_editorial transition reject',
        'use localgov_editorial transition submit_for_review',
        'view all scheduled transitions',
        'view any unpublished content',
        'view latest version',
        'use localgov_editorial transition create_new_draft',
        'use localgov_editorial transition reject',
        'use localgov_editorial transition submit_for_review',
        'view any unpublished content',
        'view latest version',
      ],
    ];
  }

  /**
   * Implements hook_ENTITY_TYPE_insert().
   */
  #[Hook('node_type_insert')]
  public function nodeTypeInsert(NodeTypeInterface $node_type) {
    // Add workflow to new localgov_ node bundle with no other workflow.
    if (strpos($node_type->id(), 'localgov_') === 0) {
      $types = \Drupal::service('entity_type.bundle.info')->getBundleInfo('node');
      if (empty($types['node']['workflow'])) {
        // The localgov_editorial workflow may not exist during site install.
        if ($editorial = Workflow::load('localgov_editorial')) {
          $type = $editorial->getTypePlugin();
          $type->addEntityTypeAndBundle('node', $node_type->id());
          $editorial->save();
        }
      }
    }
  }

  /**
   * Implements hook_menu_local_tasks_alter().
   */
  #[Hook('menu_local_tasks_alter')]
  public function menuLocalTasksAlter(&$data, $route_name, RefinableCacheableDependencyInterface &$cacheability) {
    // Disabled the default 'content moderation` tab on admin content pages as
    // this expects the default 'editorial' workflow is enabled and doesn't work
    // with other workflows without altering the content moderation view.
    $admin_content_routes = [
      'system.admin_content',
      'view.localgov_approvals_dashboard.approvals_dashboard',
    ];
    if (in_array($route_name, $admin_content_routes, TRUE)) {
      // Check if there are more workflows enabled than localgov_editorial.
      $workflows = \Drupal::entityQuery('workflow')->accessCheck(TRUE)->execute();
      if (in_array('localgov_editorial', $workflows, TRUE) && count($workflows) == 1) {
        // Hide the moderated content tab.
        for ($i = 0; $i < count($data['tabs']); $i++) {
          foreach ($data['tabs'][$i] as $key => $tab) {
            if ($key == 'content_moderation.moderated_content') {
              $data['tabs'][$i][$key]['#access'] = AccessResult::neutral();
            }
          }
        }
      }
    }
    // Rename 'Scheduled transitions' tab to 'Scheduling' and increase its weight.
    if (isset($data['tabs'][0]['entity.scheduled_transition.collection'])) {
      $data['tabs'][0]['entity.scheduled_transition.collection']['#link']['title'] = $this->t('Scheduling');
      $data['tabs'][0]['entity.scheduled_transition.collection']['#weight'] = 70;
    }
    if (isset($data['tabs'][0]['scheduled_transitions.tasks:node.scheduled_transitions']['#link']['title'])) {
      $title = $data['tabs'][0]['scheduled_transitions.tasks:node.scheduled_transitions']['#link']['title'];
      $arguments = $title->getArguments();
      $arguments['@title'] = 'Scheduling';
      $data['tabs'][0]['scheduled_transitions.tasks:node.scheduled_transitions']['#link']['title'] = $this->t($title->getUntranslatedString(), $arguments);
            // phpcs:ignore.
        }
    // Rename 'Moderated content' tab to 'Unpublished'.
    if (isset($data['tabs'][1]['content_moderation.workflows:content_moderation.moderated_content'])) {
      $data['tabs'][1]['content_moderation.workflows:content_moderation.moderated_content']['#link']['title'] = $this->t('Unpublished');
      $data['tabs'][1]['content_moderation.workflows:content_moderation.moderated_content']['#weight'] = 10;
    }
    // Add cache dependency on workflow.
    $cacheability->addCacheTags([
      'config:workflow_list',
    ]);
  }

  /**
   * Implements hook_menu_local_actions_alter().
   */
  #[Hook('menu_local_actions_alter')]
  public function menuLocalActionsAlter(&$local_actions) {
    // Rename 'Add scheduled transitions' action to 'Add schedule'.
    foreach ($local_actions as $key => $action) {
      if (preg_match('/^scheduled_transitions\.actions:.*\.add_scheduled_transition$/', $key)) {
        $local_actions[$key]['title'] = $this->t('Add schedule');
      }
    }
  }

  /**
   * Implements hook_preprocess_html().
   */
  #[Hook('preprocess_html')]
  public function preprocessHtml(&$variables) {
    $route_name = \Drupal::routeMatch()->getRouteName();
    if ($route_name === 'entity.scheduled_transition.collection') {
      $variables['head_title']['title'] = $this->t('Scheduling');
    }
    elseif ($route_name === 'entity.scheduled_transition.reschedule_form') {
      $variables['head_title']['title'] = $this->t('Reschedule');
    }
    elseif ($route_name === 'content_moderation.admin_moderated_content') {
      $variables['head_title']['title'] = $this->t('Unpublished');
    }
  }

  /**
   * Implements hook_preprocess_page_title().
   */
  #[Hook('preprocess_page_title')]
  public function preprocessPageTitle(&$variables) {
    $route_name = \Drupal::routeMatch()->getRouteName();
    if ($route_name === 'entity.scheduled_transition.collection') {
      $variables['title'] = $this->t('Scheduling');
    }
    elseif ($route_name === 'content_moderation.admin_moderated_content') {
      $variables['title'] = $this->t('Unpublished');
    }
  }

  /**
   * Implements hook_form_alter().
   */
  #[Hook('form_alter')]
  public function formAlter(&$form, FormStateInterface $form_state, string $form_id) {
    // Rename 'Scheduled transition' form items to 'Schedule'.
    if (str_ends_with($form_id, 'scheduled_transitions_add_form_form')) {
      $form['actions']['submit']['#value'] = $this->t('Schedule');
    }
    // Rename 'Reschedule transition' form items to 'Reschedule'.
    if ($form_id == 'scheduled_transition_reschedule_form') {
      $form['actions']['submit']['#value'] = $this->t('Reschedule');
    }
  }

  /**
   * Implements hook_form_BASE_FORM_ID_alter().
   */
  #[Hook('form_node_type_form_alter')]
  public function formNodeTypeFormAlter(&$form, FormStateInterface $form_state) {
    return \Drupal::classResolver(RequireLogMessage::class)->alterNodeTypeForm($form, $form_state);
  }

}
