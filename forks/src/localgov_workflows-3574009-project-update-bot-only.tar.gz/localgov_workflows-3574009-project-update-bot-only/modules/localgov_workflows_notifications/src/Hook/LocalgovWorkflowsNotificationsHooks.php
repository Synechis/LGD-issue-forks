<?php

namespace Drupal\localgov_workflows_notifications\Hook;

use Drupal\Core\Url;
use Drupal\views\ViewExecutable;
use Drupal\views\Views;
use Drupal\Core\Entity\EntityInterface;
use Drupal\localgov_roles\RolesHelper;
use Drupal\Core\Form\FormStateInterface;
use Drupal\Core\Field\FieldStorageDefinitionInterface;
use Drupal\Core\Field\BaseFieldDefinition;
use Drupal\Core\Entity\EntityTypeInterface;
use Drupal\Core\Hook\Attribute\Hook;
use Drupal\Core\StringTranslation\StringTranslationTrait;

/**
 * Hook implementations for localgov_workflows_notifications.
 */
class LocalgovWorkflowsNotificationsHooks {
  use StringTranslationTrait;

  /**
   * Implements hook_entity_base_field_info().
   */
  #[Hook('entity_base_field_info')]
  public function entityBaseFieldInfo(EntityTypeInterface $entity_type) {
    $fields = [];
    // Add service contacts field to nodes.
    if ($entity_type->id() === 'node') {
      $fields['localgov_service_contacts'] = BaseFieldDefinition::create('entity_reference')->setLabel('Service contacts')->setSetting('target_type', 'localgov_service_contact')->setSetting('handler', 'service_contact_reference')->setCardinality(FieldStorageDefinitionInterface::CARDINALITY_UNLIMITED)->setDisplayOptions('form', [
        'type' => 'entity_reference_autocomplete',
        'settings' => [
          'match_operator' => 'CONTAINS',
          'size' => 60,
          'autocomplete_type' => 'tags',
          'placeholder' => '',
        ],
      ])->setDisplayConfigurable('form', TRUE);
    }
    return $fields;
  }

  /**
   * Implements hook_form_alter().
   */
  #[Hook('form_alter')]
  public function formAlter(&$form, FormStateInterface $form_state, $form_id) {
    if (!isset($form['localgov_service_contacts'])) {
      return;
    }
    // Hide service contacts widget if user doesn't have permission.
    if (!\Drupal::currentUser()->hasPermission('view localgov_service_contact')) {
      $form['localgov_service_contacts']['#access'] = FALSE;
      return;
    }
    // Add service contacts field advanced group on node edit forms.
    if (isset($form['advanced'])) {
      $form['service_contacts'] = [
        '#type' => 'details',
        '#title' => $this->t('Service contacts'),
        '#description' => $this->t('Associate service contacts with this content by searching by name or email.'),
        '#group' => 'advanced',
        '#open' => TRUE,
        '#weight' => -4,
      ];
      $form['localgov_service_contacts']['#group'] = 'service_contacts';
      // Remove field weight.
      foreach ($form['localgov_service_contacts']['widget'] as $i => $item) {
        if (is_array($item) && isset($item['_weight'])) {
          unset($form['localgov_service_contacts']['widget'][$i]['_weight']);
        }
      }
    }
    // Add our custom validation handler.
    $form['#validate'][] = 'localgov_workflows_notifications_node_form_validate';
  }

  /**
   * Implements hook_preprocess_HOOK() for field_multiple_value_form.
   */
  #[Hook('preprocess_field_multiple_value_form')]
  public function preprocessFieldMultipleValueForm(&$variables) {
    // Remove title and ordering from service contacts field.
    if ($variables['element']['#field_name'] === 'localgov_service_contacts') {
      if (isset($variables['table']['#header'])) {
        $variables['table']['#header'] = [];
      }
      if (isset($variables['table']['#tabledrag'])) {
        unset($variables['table']['#tabledrag']);
      }
    }
  }

  /**
   * Implements hook_cron().
   */
  #[Hook('cron')]
  public function cron(): void {
    // Don't proceed if email notifications are disabled.
    $settings = \Drupal::config('localgov_workflows_notifications.settings');
    if (!$settings->get('email_enabled')) {
      return;
    }
    // Don't proceed if localgov_review_date module is not enabled.
    if (!\Drupal::moduleHandler()->moduleExists('localgov_review_date')) {
      return;
    }
    // Enqueue email notification for content past its needs review date.
    $notification_timer = \Drupal::service('localgov_workflows_notifications.notification_timer');
    if ($notification_timer->trigger()) {
      // Get review date IDs that need have passed their review date.
      $request_time = \Drupal::time()->getRequestTime();
      $last_run = $notification_timer->getLastRun();
      $storage = \Drupal::entityTypeManager()->getStorage('review_date');
      $review_date_ids = $storage->getQuery()->condition('active', 1)->condition('review', $last_run, '>')->condition('review', $request_time, '<=')->accessCheck(FALSE)->execute();
      if (!empty($review_date_ids)) {
        // Create email notifications.
        $notifier = \Drupal::service('localgov_workflows_notifications.notifier');
        foreach ($review_date_ids as $id) {
          $review_date = $storage->load($id);
          if ($entity = $review_date->getEntity()) {
            $notifier->enqueue($entity, 'needs_review');
          }
        }
      }
      $notification_timer->update();
    }
  }

  /**
   * Implements hook_localgov_roles_default().
   */
  #[Hook('localgov_roles_default')]
  public function localgovRolesDefault(): array {
    // Service contact permissions.
    return [
      RolesHelper::EDITOR_ROLE => [
        'administer localgov_service_contact',
        'create localgov_service_contact',
        'delete localgov_service_contact',
        'edit localgov_service_contact',
        'view localgov_service_contact',
      ],
      RolesHelper::AUTHOR_ROLE => [
        'view localgov_service_contact',
      ],
      RolesHelper::CONTRIBUTOR_ROLE => [
        'view localgov_service_contact',
      ],
    ];
  }

  /**
   * Implements hook_entity_operation_alter().
   */
  #[Hook('entity_operation_alter')]
  public function entityOperationAlter(array &$operations, EntityInterface $entity) {
    // Add "View content" operation link for every service contact listed.
    // First make sure that the "Content by owner" View is enabled.
    $view = Views::getView('localgov_content_by_owner');
    if ($view instanceof ViewExecutable) {
      // Only add the operation link to the Service contact entity collection.
      if ($entity->bundle() === 'localgov_service_contact') {
        $operations['service_contact_view_content'] = [
          'title' => $this->t('View content'),
              // Point to a filtered version of the "Content by owner" View,
              // using the View's contextual filter.
          'url' => Url::fromRoute('view.localgov_content_by_owner.page_1', [
                  [
                    'service-contact-id' => $entity->id(),
                  ],
          ]),
          'weight' => 150,
        ];
      }
    }
  }

}
