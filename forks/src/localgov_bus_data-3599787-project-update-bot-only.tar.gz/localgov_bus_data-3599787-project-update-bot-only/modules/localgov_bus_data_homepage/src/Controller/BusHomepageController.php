<?php

declare(strict_types=1);

namespace Drupal\localgov_bus_data_homepage\Controller;

use Drupal\Core\Controller\ControllerBase;
use Drupal\Core\Database\Connection;
use Drupal\Core\StringTranslation\TranslatableMarkup;
use Drupal\Core\Url;
use Symfony\Component\DependencyInjection\ContainerInterface;

/**
 * Public landing page for the bus timetables section (/buses).
 *
 * All content — intro text, interchange links, and area browse groups — is
 * driven by localgov_bus_data_homepage.settings config, making the submodule
 * reusable across different councils without code changes.
 */
final class BusHomepageController extends ControllerBase {

  public function __construct(
    private readonly Connection $database,
  ) {}

  /**
   * {@inheritdoc}
   */
  public static function create(ContainerInterface $container): static {
    return new self(
      $container->get('database'),
    );
  }

  /**
   * Returns the page title from config.
   */
  public function title(): string|TranslatableMarkup {
    return $this->config('localgov_bus_data_homepage.settings')->get('page_title')
      ?: $this->t('Bus Timetables');
  }

  /**
   * Renders the /buses landing page.
   */
  public function page(): array {
    $config = $this->config('localgov_bus_data_homepage.settings');

    $interchange_items = [];
    foreach ($config->get('interchanges') ?? [] as $entry) {
      $query = ['bustimes_locality' => $entry['bustimes_locality']];
      if (!empty($entry['bustimes_stop_name'])) {
        $query['bustimes_stop_name'] = $entry['bustimes_stop_name'];
      }
      $interchange_items[] = [
        '#type'  => 'link',
        '#title' => $entry['label'],
        '#url'   => Url::fromRoute(
          'view.localgov_bus_stop_search.page_bus_stops',
          [],
          ['query' => $query],
        ),
      ];
    }

    $area_groups = [];
    $seen_slugs = [];
    foreach ($config->get('areas') ?? [] as $area) {
      $localities = $this->loadLocalitiesForPrefix($area['atco_prefix']);
      if (empty($localities)) {
        continue;
      }
      $items = [];
      foreach ($localities as $place) {
        $items[] = [
          '#type'  => 'link',
          '#title' => $place,
          '#url'   => Url::fromRoute(
            'view.localgov_bus_stop_search.page_bus_stops',
            [],
            ['query' => ['bustimes_locality' => $place]],
          ),
        ];
      }
      $base_slug = $this->areaSlug($area['label']);
      $slug = $base_slug;
      $n = 1;
      while (isset($seen_slugs[$slug])) {
        $slug = $base_slug . '-' . ++$n;
      }
      $seen_slugs[$slug] = TRUE;

      $area_groups[] = [
        'label'    => $area['label'],
        'panel_id' => 'bus-area-panel--' . $slug,
        'tab_id'   => 'bus-area-tab--' . $slug,
        'places'   => $items,
      ];
    }

    $use_lgd_header = (bool) ($config->get('use_lgd_page_header') ?? FALSE);
    $area_browse_dropdown = (bool) ($config->get('area_browse_dropdown') ?? FALSE);

    return [
      '#theme'                     => 'localgov_bus_homepage',
      '#intro_text'                => $use_lgd_header ? '' : ($config->get('intro_text') ?? ''),
      '#route_search_title'        => $config->get('route_search_title') ?: (string) $this->t('Search by route number'),
      '#route_search_description'  => $config->get('route_search_description') ?? '',
      '#stop_search_title'         => $config->get('stop_search_title') ?: (string) $this->t('Find a bus stop'),
      '#stop_search_description'   => $config->get('stop_search_description') ?? '',
      '#interchanges_title'        => $config->get('interchanges_title') ?: (string) $this->t('Bus interchanges and stations'),
      '#interchanges_description'  => $config->get('interchanges_description') ?? '',
      '#area_browse_title'         => $config->get('area_browse_title') ?: (string) $this->t('Search by area'),
      '#area_browse_description'   => $config->get('area_browse_description') ?? '',
      '#interchange_items'         => $interchange_items,
      '#area_groups'               => $area_groups,
      '#area_browse_dropdown'      => $area_browse_dropdown,
      '#cache'             => [
        'tags'     => ['localgov_bus_stop_list', 'config:localgov_bus_data_homepage.settings'],
        'contexts' => ['languages:language_interface'],
        'max-age'  => 3600,
      ],
      '#attached' => ['library' => ['localgov_bus_data_homepage/area-browse']],
    ];
  }

  /**
   * Generates a safe HTML id from an area label with a given prefix.
   */
  private function areaSlug(string $label): string {
    $slug = strtr(strtolower($label), [' ' => '-', '&' => 'and']);
    return preg_replace('/[^a-z0-9\-]/', '', $slug);
  }

  /**
   * Returns sorted distinct locality names for stops with the given prefix.
   *
   * Uses a direct DB query rather than EntityQuery because EntityQuery does not
   * support DISTINCT on a single column without loading every entity. Locality
   * strings are not sensitive; bypassing entity access is intentional and safe.
   *
   * @param string $prefix
   *   ATCO code prefix (first 6 characters) identifying a geographic area.
   *
   * @return string[]
   *   Sorted locality name strings.
   */
  private function loadLocalitiesForPrefix(string $prefix): array {
    $table = $this->entityTypeManager()
      ->getDefinition('localgov_bus_stop')
      ->getBaseTable();
    return $this->database->query(
      "SELECT DISTINCT bustimes_locality FROM {$table}
       WHERE bustimes_stop_id LIKE :p
         AND bustimes_locality IS NOT NULL
         AND bustimes_locality <> ''
       ORDER BY bustimes_locality",
      [':p' => $prefix . '%'],
    )->fetchCol();
  }

}
