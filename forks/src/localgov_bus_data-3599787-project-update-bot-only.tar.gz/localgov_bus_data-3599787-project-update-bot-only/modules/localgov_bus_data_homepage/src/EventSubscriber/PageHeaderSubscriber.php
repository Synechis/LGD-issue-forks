<?php

declare(strict_types=1);

namespace Drupal\localgov_bus_data_homepage\EventSubscriber;

use Drupal\Core\Config\ConfigFactoryInterface;
use Drupal\Core\Routing\RouteMatchInterface;
use Drupal\localgov_core\Event\PageHeaderDisplayEvent;
use Symfony\Component\EventDispatcher\EventSubscriberInterface;

/**
 * Sets the LGD page header title and lede for the bus timetables homepage.
 */
final class PageHeaderSubscriber implements EventSubscriberInterface {

  public function __construct(
    private readonly ConfigFactoryInterface $configFactory,
    private readonly RouteMatchInterface $routeMatch,
  ) {}

  /**
   * {@inheritdoc}
   */
  public static function getSubscribedEvents(): array {
    if (!class_exists(PageHeaderDisplayEvent::class)) {
      return [];
    }
    return [
      PageHeaderDisplayEvent::EVENT_NAME => ['setPageHeader', 0],
    ];
  }

  /**
   * Sets page header title and lede from settings when on the bus homepage.
   */
  public function setPageHeader(PageHeaderDisplayEvent $event): void {
    if ($this->routeMatch->getRouteName() !== 'localgov_bus_data_homepage.buses_home') {
      return;
    }

    $event->setCacheTags(['config:localgov_bus_data_homepage.settings']);

    $config = $this->configFactory->get('localgov_bus_data_homepage.settings');

    if (!$config->get('use_lgd_page_header')) {
      return;
    }

    $title = $config->get('page_title');
    $lede  = $config->get('intro_text');

    if ($title !== NULL && $title !== '') {
      $event->setTitle($title);
    }

    if ($lede !== NULL && $lede !== '') {
      $event->setLede([
        '#type' => 'html_tag',
        '#tag' => 'p',
        '#value' => $lede,
      ]);
    }
  }

}
