<?php

declare(strict_types=1);

namespace Drupal\localgov_bus_data_homepage\EventSubscriber;

use Drupal\Core\Config\ConfigFactoryInterface;
use Drupal\Core\Routing\RouteSubscriberBase;
use Symfony\Component\Routing\RouteCollection;

/**
 * Overrides the bus homepage route path from config.
 *
 * The localgov_bus_data_homepage.buses_home route is declared with a static
 * path in routing.yml. This subscriber replaces it with whatever the admin
 * has saved in page_path so it stays in sync with the View paths.
 */
final class BusHomepageRouteSubscriber extends RouteSubscriberBase {

  public function __construct(
    private readonly ConfigFactoryInterface $configFactory,
  ) {}

  /**
   * {@inheritdoc}
   */
  protected function alterRoutes(RouteCollection $collection): void {
    $route = $collection->get('localgov_bus_data_homepage.buses_home');
    if (!$route) {
      return;
    }

    $path = $this->configFactory
      ->get('localgov_bus_data_homepage.settings')
      ->get('page_path') ?? 'buses';

    $route->setPath('/' . ltrim($path, '/'));
  }

}
