<?php

namespace Drupal\localgov_bus_data_homepage\Hook;

use Drupal\Core\Hook\Attribute\Hook;
/**
 * Hook implementations for localgov_bus_data_homepage.
 */
class LocalgovBusDataHomepageHooks
{
    /**
     * Implements hook_theme().
     */
    #[Hook('theme')]
    public static function theme(): array
    {
        return [
            'localgov_bus_homepage' => [
                'variables' => [
                    'intro_text' => '',
                    'route_search_title' => '',
                    'route_search_description' => '',
                    'stop_search_title' => '',
                    'stop_search_description' => '',
                    'interchanges_title' => '',
                    'interchanges_description' => '',
                    'area_browse_title' => '',
                    'area_browse_description' => '',
                    'interchange_items' => [
                    ],
                    'area_groups' => [
                    ],
                    'area_browse_dropdown' => FALSE,
                ],
            ],
        ];
    }
}
