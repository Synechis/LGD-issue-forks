<?php

declare(strict_types=1);

namespace Drupal\localgov_bus_data_homepage\Service;

use Drupal\Core\Entity\EntityTypeManagerInterface;
use Drupal\Core\Routing\RouteBuilderInterface;

/**
 * Updates View display paths and field link paths when the bus base path changes.
 *
 * Iterates every display in each bus View and rewrites any path that starts
 * with the old base segment — both the display page path and field alter paths
 * (the link token paths used in field formatters).
 */
final class BusPathUpdater {

  /**
   * View IDs managed by the localgov_bus_data module.
   */
  private const VIEW_IDS = [
    'localgov_bus_routes',
    'localgov_bus_stop_search',
    'localgov_bus_stop_detail',
    'localgov_bus_timetable',
  ];

  public function __construct(
    private readonly EntityTypeManagerInterface $entityTypeManager,
    private readonly RouteBuilderInterface $routeBuilder,
  ) {}

  /**
   * Rewrites all bus View paths from $oldBase to $newBase and flags a route rebuild.
   *
   * @param string $oldBase
   *   Current base path segment, e.g. 'buses'.
   * @param string $newBase
   *   New base path or prefix, e.g. 'transport/buses'.
   */
  public function update(string $oldBase, string $newBase): void {
    foreach (self::VIEW_IDS as $viewId) {
      $view = $this->entityTypeManager->getStorage('view')->load($viewId);
      if (!$view) {
        continue;
      }

      foreach (array_keys($view->get('display')) as $displayId) {
        $display = &$view->getDisplay($displayId);

        // Update the display page path (e.g. buses/routes → transport/buses/routes).
        if (!empty($display['display_options']['path'])) {
          $display['display_options']['path'] = $this->replacePath(
            $display['display_options']['path'],
            $oldBase,
            $newBase,
          );
        }

        // Update field alter link paths (e.g. /buses/stops/{{ bustimes_stop_id }}).
        if (!empty($display['display_options']['fields'])) {
          foreach ($display['display_options']['fields'] as &$field) {
            if (!empty($field['alter']['path'])) {
              $field['alter']['path'] = $this->replacePath(
                $field['alter']['path'],
                $oldBase,
                $newBase,
              );
            }
          }
        }
      }

      $view->save();
    }

    $this->routeBuilder->rebuild();
  }

  /**
   * Replaces the leading base segment in a path string.
   *
   * Handles both slash-prefixed link paths (/buses/stops/...) and bare display
   * paths (buses/routes) without risk of double-substitution.
   *
   * @param string $path
   *   The path string to rewrite.
   * @param string $oldBase
   *   The current base segment (e.g. 'buses').
   * @param string $newBase
   *   The replacement base or prefix (e.g. 'transport/buses').
   *
   * @return string
   *   The rewritten path, or the original if the base was not found at the start.
   */
  private function replacePath(string $path, string $oldBase, string $newBase): string {
    // Link token paths start with /buses/.
    if (str_starts_with($path, '/' . $oldBase . '/')) {
      return '/' . $newBase . substr($path, strlen($oldBase) + 1);
    }
    // Display paths start with buses/ (no leading slash).
    if (str_starts_with($path, $oldBase . '/')) {
      return $newBase . substr($path, strlen($oldBase));
    }
    return $path;
  }

}
