<?php

declare(strict_types=1);

namespace Drupal\Tests\localgov_bus_data\Unit\Service;

use Drupal\localgov_bus_data\Service\GtfsDownloader;
use Drupal\Core\Config\ConfigFactoryInterface;
use Drupal\Core\Config\ImmutableConfig;
use Drupal\Tests\UnitTestCase;
use GuzzleHttp\ClientInterface;
use GuzzleHttp\Exception\TransferException;
use GuzzleHttp\Psr7\Response;
use Psr\Log\LoggerInterface;

/**
 * Unit tests for GtfsDownloader.
 *
 * All HTTP, config, and logger dependencies are mocked so that no real
 * network calls or Drupal container are needed.
 *
 * @coversDefaultClass \Drupal\localgov_bus_data\Service\GtfsDownloader
 * @group localgov_bus_data
 */
final class GtfsDownloaderTest extends UnitTestCase {

  private const BULK_GTFS_URL = 'https://test.example.com/gtfs/';

  /**
   * Builds a config factory stub returning the given bulk GTFS URL.
   */
  private function makeConfigFactory(string $bulkGtfsUrl = self::BULK_GTFS_URL): ConfigFactoryInterface {
    $settings = $this->createMock(ImmutableConfig::class);
    $settings->method('get')->willReturnMap([
      ['source.bulk_gtfs_url', $bulkGtfsUrl],
    ]);

    $configFactory = $this->createMock(ConfigFactoryInterface::class);
    $configFactory->method('get')
      ->with('localgov_bus_data.settings')
      ->willReturn($settings);

    return $configFactory;
  }

  /**
   * DownloadBulkGtfs sends GET to the configured URL with a sink option.
   *
   * @covers ::downloadBulkGtfs
   */
  public function testDownloadBulkGtfsUsesConfiguredUrlAndSink(): void {
    $capturedArgs = [];

    $httpClient = $this->createMock(ClientInterface::class);
    $httpClient->method('request')
      ->willReturnCallback(
        static function (string $method, string $url, array $options) use (&$capturedArgs): Response {
          $capturedArgs = [$method, $url, $options];
          return new Response(200, [], '');
        },
      );

    (new GtfsDownloader(
      $httpClient,
      $this->makeConfigFactory(),
      $this->createMock(LoggerInterface::class),
    ))->downloadBulkGtfs('/tmp/test.zip');

    $this->assertSame('GET', $capturedArgs[0]);
    $this->assertSame(self::BULK_GTFS_URL, $capturedArgs[1]);
    $this->assertArrayHasKey('sink', $capturedArgs[2]);
    $this->assertSame('/tmp/test.zip', $capturedArgs[2]['sink']);
    $this->assertSame(600, $capturedArgs[2]['timeout']);
    $this->assertArrayNotHasKey('query', $capturedArgs[2]);
  }

  /**
   * A Guzzle exception from downloadBulkGtfs is converted to RuntimeException.
   *
   * @covers ::downloadBulkGtfs
   */
  public function testDownloadBulkGtfsGuzzleExceptionThrowsRuntimeException(): void {
    $httpClient = $this->createMock(ClientInterface::class);
    $httpClient->method('request')
      ->willThrowException(new TransferException('Network error'));

    $logger = $this->createMock(LoggerInterface::class);
    $logger->expects($this->once())->method('error');

    $this->expectException(\RuntimeException::class);
    $this->expectExceptionMessage('Bulk GTFS download failed.');

    (new GtfsDownloader(
      $httpClient,
      $this->makeConfigFactory(),
      $logger,
    ))->downloadBulkGtfs('/tmp/test.zip');
  }

  /**
   * DownloadBulkGtfs falls back to the hardcoded URL when config returns null.
   *
   * @covers ::downloadBulkGtfs
   */
  public function testDownloadBulkGtfsFallsBackToDefaultUrl(): void {
    $capturedUrl = '';

    $httpClient = $this->createMock(ClientInterface::class);
    $httpClient->method('request')
      ->willReturnCallback(
        static function (string $method, string $url, array $options) use (&$capturedUrl): Response {
          $capturedUrl = $url;
          return new Response(200, [], '');
        },
      );

    // Config returns null for bulk_gtfs_url.
    $settings = $this->createMock(ImmutableConfig::class);
    $settings->method('get')->willReturn(NULL);
    $configFactory = $this->createMock(ConfigFactoryInterface::class);
    $configFactory->method('get')->willReturn($settings);

    (new GtfsDownloader(
      $httpClient,
      $configFactory,
      $this->createMock(LoggerInterface::class),
    ))->downloadBulkGtfs('/tmp/fallback.zip');

    $this->assertSame(
      'https://data.bus-data.dft.gov.uk/timetable/download/gtfs-file/all/',
      $capturedUrl,
    );
  }

}
