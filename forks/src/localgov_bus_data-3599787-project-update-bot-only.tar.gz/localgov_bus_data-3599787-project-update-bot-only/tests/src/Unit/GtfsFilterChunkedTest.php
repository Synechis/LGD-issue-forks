<?php

declare(strict_types=1);

namespace Drupal\Tests\localgov_bus_data\Unit\Service;

use Drupal\Core\Config\ConfigFactoryInterface;
use Drupal\Core\Config\ImmutableConfig;
use Drupal\localgov_bus_data\Service\GtfsFilter;
use Drupal\Tests\UnitTestCase;
use Psr\Log\LoggerInterface;

/**
 * Unit tests for the chunked batch methods on GtfsFilter.
 *
 * Core invariant under test: running the chunked collect and rewrite pipeline
 * with any chunk size N ≥ 1 must produce the same final output as calling
 * filterByGeography() in a single pass.
 *
 * Uses real temporary CSV files so that fseek(), fgetcsv(), fputcsv(), and
 * rename() are exercised without mocking.
 *
 * @coversDefaultClass \Drupal\localgov_bus_data\Service\GtfsFilter
 * @group localgov_bus_data
 */
final class GtfsFilterChunkedTest extends UnitTestCase {

  /**
   * Temporary directory for GTFS CSV fixtures.
   *
   * @var string
   */
  private string $tmpDir;

  /**
   * Bounding box roughly covering Cumberland (used across multiple tests).
   *
   * @var array{north: float, south: float, east: float, west: float}
   */
  private array $bbox = [
    'north' => 55.1,
    'south' => 54.3,
    'east'  => -2.0,
    'west'  => -3.75,
  ];

  /**
   * {@inheritdoc}
   */
  protected function setUp(): void {
    parent::setUp();
    $this->tmpDir = sys_get_temp_dir() . '/gtfs_chunked_test_' . uniqid('', TRUE);
    mkdir($this->tmpDir, 0750, TRUE);
  }

  /**
   * {@inheritdoc}
   */
  protected function tearDown(): void {
    foreach (glob($this->tmpDir . '/*') ?: [] as $file) {
      if (is_file($file)) {
        unlink($file);
      }
    }
    rmdir($this->tmpDir);
    parent::tearDown();
  }

  // ---------------------------------------------------------------------------
  // Helpers
  // ---------------------------------------------------------------------------

  /**
   * Creates a GtfsFilter instance with an optional bounding box or GeoJSON.
   *
   * @param array{north: float, south: float, east: float, west: float}|null $bbox
   *   Bounding box config or NULL.
   * @param string|null $geojson
   *   GeoJSON string or NULL.
   *
   * @return \Drupal\localgov_bus_data\Service\GtfsFilter
   */
  private function makeFilter(?array $bbox, ?string $geojson = NULL): GtfsFilter {
    $config = $this->createMock(ImmutableConfig::class);
    $config->method('get')->willReturnMap([
      ['source.boundary_geojson', $geojson],
      ['source.bounding_box', $bbox],
    ]);
    $configFactory = $this->createMock(ConfigFactoryInterface::class);
    $configFactory->method('get')->willReturn($config);
    return new GtfsFilter($configFactory, $this->createMock(LoggerInterface::class));
  }

  /**
   * Writes rows to a CSV file in the test temp directory.
   *
   * @param string $filename
   *   Filename relative to the temp directory.
   * @param array<int, list<string>> $rows
   *   Rows including the header.
   */
  private function writeCsv(string $filename, array $rows): void {
    $fh = fopen($this->tmpDir . '/' . $filename, 'w');
    assert($fh !== FALSE);
    foreach ($rows as $row) {
      fputcsv($fh, $row, escape: '');
    }
    fclose($fh);
  }

  /**
   * Reads all rows (including header) from a CSV file in the temp directory.
   *
   * @param string $filename
   *   Filename relative to the temp directory.
   *
   * @return list<list<string>>
   */
  private function readCsv(string $filename): array {
    $rows = [];
    $fh = fopen($this->tmpDir . '/' . $filename, 'r');
    assert($fh !== FALSE);
    while (($row = fgetcsv($fh, escape: '')) !== FALSE) {
      $rows[] = $row;
    }
    fclose($fh);
    return $rows;
  }

  /**
   * Writes a standard four-file GTFS fixture.
   *
   * T1 serves S1 (in-box) — valid.
   * T2 serves S3 (out-of-box) — filtered out.
   * T3 serves S1 and S4 (cross-boundary) — valid, S4 retained despite being
   *   out of box.
   */
  private function writeStandardFixture(): void {
    $this->writeCsv('stops.txt', [
      ['stop_id', 'stop_lat', 'stop_lon'],
      ['S1', '54.900', '-3.500'],   // in-box
      ['S2', '54.800', '-3.200'],   // in-box
      ['S3', '56.000', '-1.500'],   // out-of-box
      ['S4', '56.500', '-2.000'],   // out-of-box (cross-boundary)
    ]);
    $this->writeCsv('stop_times.txt', [
      ['trip_id', 'stop_id', 'stop_sequence'],
      ['T1', 'S1', '1'],
      ['T1', 'S2', '2'],
      ['T2', 'S3', '1'],
      ['T3', 'S1', '1'],
      ['T3', 'S4', '2'],
    ]);
    $this->writeCsv('trips.txt', [
      ['trip_id', 'route_id'],
      ['T1', 'R1'],
      ['T2', 'R2'],
      ['T3', 'R1'],
    ]);
    $this->writeCsv('routes.txt', [
      ['route_id', 'route_short_name'],
      ['R1', '60'],
      ['R2', '685'],
    ]);
  }

  /**
   * Runs the full chunked collect pipeline (init → N chunks → finalize).
   *
   * @param \Drupal\localgov_bus_data\Service\GtfsFilter $filter
   *   The filter instance.
   * @param int $chunkRows
   *   Rows per chunk pass.
   *
   * @return array<string, true>
   *   Trip IDs decoded from valid_trip_ids.json, keyed for O(1) lookup.
   */
  private function runChunkedCollect(GtfsFilter $filter, int $chunkRows): array {
    $totalBytes = $filter->collectValidTripsInit($this->tmpDir);

    $byteOffset = 0;
    $passes = 0;

    do {
      $result = $filter->collectValidTripsChunk($this->tmpDir, $byteOffset, $chunkRows);
      $byteOffset = $result['offset'];
      $passes++;
      // Guard against infinite loops in tests.
      $this->assertLessThan(10000, $passes, 'Chunked collect took more than 10 000 passes — likely infinite loop.');
    } while (!$result['done']);

    $filter->collectValidTripsFinalize($this->tmpDir);

    $json = file_get_contents($this->tmpDir . '/valid_trip_ids.json');
    $this->assertIsString($json);

    if ($json === 'null') {
      return [];
    }

    $ids = json_decode($json, TRUE);
    $this->assertIsArray($ids);
    return array_fill_keys($ids, TRUE);
  }

  /**
   * Runs the full chunked rewrite pipeline (init → N chunks → finalize).
   *
   * Assumes valid_trip_ids.json already exists in the temp directory.
   *
   * @param \Drupal\localgov_bus_data\Service\GtfsFilter $filter
   *   The filter instance.
   * @param int $chunkRows
   *   Rows per chunk pass.
   */
  private function runChunkedRewrite(GtfsFilter $filter, int $chunkRows): void {
    $init = $filter->rewriteStopTimesInit($this->tmpDir);

    if ($init['skip']) {
      return;
    }

    $byteOffset = $init['header_offset'] ?? 0;
    $tmpFile    = $init['tmp_file'];
    $passes     = 0;

    do {
      $result = $filter->rewriteStopTimesChunk(
        $this->tmpDir,
        $tmpFile,
        $byteOffset,
        $chunkRows,
      );
      $byteOffset = $result['offset'];
      $passes++;
      $this->assertLessThan(10000, $passes, 'Chunked rewrite took more than 10 000 passes — likely infinite loop.');
    } while (!$result['done']);

    $filter->rewriteStopTimesFinalize($this->tmpDir);
  }

  // ---------------------------------------------------------------------------
  // Collect: no-filter path
  // ---------------------------------------------------------------------------

  /**
   * When no filter is configured, init returns 0 and the first chunk is done.
   *
   * @covers ::collectValidTripsInit
   * @covers ::collectValidTripsChunk
   * @covers ::collectValidTripsFinalize
   */
  public function testCollectNoFilterSkipsImmediately(): void {
    $this->writeStandardFixture();
    $filter = $this->makeFilter(NULL);

    $totalBytes = $filter->collectValidTripsInit($this->tmpDir);
    $this->assertSame(0, $totalBytes);

    $result = $filter->collectValidTripsChunk($this->tmpDir, 0, 1000);
    $this->assertTrue($result['done']);
    $this->assertSame(0, $result['offset']);

    $filter->collectValidTripsFinalize($this->tmpDir);

    $json = file_get_contents($this->tmpDir . '/valid_trip_ids.json');
    $this->assertSame('null', $json);
  }

  // ---------------------------------------------------------------------------
  // Collect: single-pass equivalence
  // ---------------------------------------------------------------------------

  /**
   * A single oversized chunk produces the same trip IDs as filterByGeography().
   *
   * @covers ::collectValidTripsInit
   * @covers ::collectValidTripsChunk
   * @covers ::collectValidTripsFinalize
   */
  public function testCollectSingleChunkMatchesSinglePass(): void {
    $this->writeStandardFixture();

    $tripIds = $this->runChunkedCollect($this->makeFilter($this->bbox), 10000);

    $this->assertArrayHasKey('T1', $tripIds);
    $this->assertArrayHasKey('T3', $tripIds);
    $this->assertArrayNotHasKey('T2', $tripIds);
  }

  // ---------------------------------------------------------------------------
  // Collect: multi-pass equivalence
  // ---------------------------------------------------------------------------

  /**
   * One row per chunk produces the same trip IDs as a single pass.
   *
   * This is the most demanding case: every row triggers a new chunk call,
   * ensuring byte-offset resumption is correct at every boundary.
   *
   * @covers ::collectValidTripsChunk
   */
  public function testCollectOneRowPerChunkMatchesSinglePass(): void {
    $this->writeStandardFixture();

    $tripIds = $this->runChunkedCollect($this->makeFilter($this->bbox), 1);

    $this->assertArrayHasKey('T1', $tripIds);
    $this->assertArrayHasKey('T3', $tripIds);
    $this->assertArrayNotHasKey('T2', $tripIds);
  }

  /**
   * Two rows per chunk produces the same trip IDs as a single pass.
   *
   * @covers ::collectValidTripsChunk
   */
  public function testCollectTwoRowsPerChunkMatchesSinglePass(): void {
    $this->writeStandardFixture();

    $tripIds = $this->runChunkedCollect($this->makeFilter($this->bbox), 2);

    $this->assertArrayHasKey('T1', $tripIds);
    $this->assertArrayHasKey('T3', $tripIds);
    $this->assertArrayNotHasKey('T2', $tripIds);
  }

  // ---------------------------------------------------------------------------
  // Collect: deduplication across chunks
  // ---------------------------------------------------------------------------

  /**
   * A trip ID found in multiple chunks appears exactly once in the final JSON.
   *
   * T1 appears in rows 1 and 2 (both stops S1, S2 are in-box). With chunk
   * size 1 it is found twice across two passes and must be deduplicated.
   *
   * @covers ::collectValidTripsFinalize
   */
  public function testCollectDeduplicatesTripIdsAcrossChunks(): void {
    $this->writeStandardFixture();

    $this->runChunkedCollect($this->makeFilter($this->bbox), 1);

    $json = file_get_contents($this->tmpDir . '/valid_trip_ids.json');
    $ids  = json_decode($json, TRUE);
    $this->assertIsArray($ids);

    // T1 must appear exactly once despite being found in two chunk passes.
    $this->assertSame(count($ids), count(array_unique($ids)));
    $this->assertContains('T1', $ids);
  }

  // ---------------------------------------------------------------------------
  // Collect: temp file cleanup
  // ---------------------------------------------------------------------------

  /**
   * Finalize removes in_area_stop_ids.json and partial_trip_ids.json.
   *
   * @covers ::collectValidTripsFinalize
   */
  public function testCollectFinalizeCleansUpTempFiles(): void {
    $this->writeStandardFixture();

    $this->runChunkedCollect($this->makeFilter($this->bbox), 1000);

    $this->assertFileDoesNotExist($this->tmpDir . '/in_area_stop_ids.json');
    $this->assertFileDoesNotExist($this->tmpDir . '/partial_trip_ids.json');
    $this->assertFileExists($this->tmpDir . '/valid_trip_ids.json');
  }

  // ---------------------------------------------------------------------------
  // Collect: byte-offset progress
  // ---------------------------------------------------------------------------

  /**
   * The byte offset advances monotonically and reaches the file size.
   *
   * @covers ::collectValidTripsChunk
   */
  public function testCollectByteOffsetAdvancesMonotonically(): void {
    $this->writeStandardFixture();
    $filter = $this->makeFilter($this->bbox);

    $filter->collectValidTripsInit($this->tmpDir);

    $stopTimesSize = filesize($this->tmpDir . '/stop_times.txt');
    $prevOffset    = 0;
    $passes        = 0;

    do {
      $result = $filter->collectValidTripsChunk($this->tmpDir, $prevOffset, 1);
      $this->assertGreaterThanOrEqual($prevOffset, $result['offset'],
        'Byte offset must never decrease.');
      $prevOffset = $result['offset'];
      $passes++;
    } while (!$result['done']);

    $this->assertSame((int) $stopTimesSize, $prevOffset,
      'Final offset must equal the file size.');
  }

  // ---------------------------------------------------------------------------
  // Rewrite: no-filter path
  // ---------------------------------------------------------------------------

  /**
   * When valid_trip_ids.json contains the null sentinel, init returns skip=TRUE.
   *
   * @covers ::rewriteStopTimesInit
   */
  public function testRewriteNoFilterSkipsImmediately(): void {
    $this->writeStandardFixture();
    $filter = $this->makeFilter(NULL);

    // Simulate the collect phase having written the null sentinel.
    file_put_contents($this->tmpDir . '/valid_trip_ids.json', 'null');

    $init = $filter->rewriteStopTimesInit($this->tmpDir);
    $this->assertTrue($init['skip']);
  }

  // ---------------------------------------------------------------------------
  // Rewrite: single-pass equivalence
  // ---------------------------------------------------------------------------

  /**
   * A single oversized chunk produces the same filtered files as filterByGeography().
   *
   * @covers ::rewriteStopTimesInit
   * @covers ::rewriteStopTimesChunk
   * @covers ::rewriteStopTimesFinalize
   */
  public function testRewriteSingleChunkMatchesSinglePass(): void {
    $this->writeStandardFixture();
    $filter = $this->makeFilter($this->bbox);

    $this->runChunkedCollect($filter, 10000);
    $this->runChunkedRewrite($filter, 10000);

    $this->assertRewriteResultMatchesExpectation();
  }

  // ---------------------------------------------------------------------------
  // Rewrite: multi-pass equivalence
  // ---------------------------------------------------------------------------

  /**
   * One row per chunk produces the same filtered files as a single pass.
   *
   * @covers ::rewriteStopTimesChunk
   */
  public function testRewriteOneRowPerChunkMatchesSinglePass(): void {
    $this->writeStandardFixture();
    $filter = $this->makeFilter($this->bbox);

    $this->runChunkedCollect($filter, 10000);
    $this->runChunkedRewrite($filter, 1);

    $this->assertRewriteResultMatchesExpectation();
  }

  /**
   * Two rows per chunk produces the same filtered files as a single pass.
   *
   * @covers ::rewriteStopTimesChunk
   */
  public function testRewriteTwoRowsPerChunkMatchesSinglePass(): void {
    $this->writeStandardFixture();
    $filter = $this->makeFilter($this->bbox);

    $this->runChunkedCollect($filter, 10000);
    $this->runChunkedRewrite($filter, 2);

    $this->assertRewriteResultMatchesExpectation();
  }

  // ---------------------------------------------------------------------------
  // Rewrite: stop ID accumulation across chunks
  // ---------------------------------------------------------------------------

  /**
   * Cross-boundary stops referenced in different chunks are all retained.
   *
   * T3 calls S1 (row 4) and S4 (row 5 — out of box). With chunk size 1,
   * S4's row is processed in a different pass than S1's. Both must appear in
   * the rewritten stops.txt.
   *
   * @covers ::rewriteStopTimesChunk
   * @covers ::rewriteStopTimesFinalize
   */
  public function testRewriteRetainsCrossBoundaryStopsAcrossChunks(): void {
    $this->writeStandardFixture();
    $filter = $this->makeFilter($this->bbox);

    $this->runChunkedCollect($filter, 10000);
    $this->runChunkedRewrite($filter, 1);

    $stopIds = array_column(array_slice($this->readCsv('stops.txt'), 1), 0);
    // S4 is out-of-box but referenced by T3 (which is valid) — must be kept.
    $this->assertContains('S4', $stopIds);
    // S3 is not referenced by any valid trip — must be removed.
    $this->assertNotContains('S3', $stopIds);
  }

  // ---------------------------------------------------------------------------
  // Rewrite: temp file cleanup
  // ---------------------------------------------------------------------------

  /**
   * Finalize removes the stop_times rewrite temp file and partial_stop_ids.json.
   *
   * @covers ::rewriteStopTimesFinalize
   */
  public function testRewriteFinalizeCleansUpTempFiles(): void {
    $this->writeStandardFixture();
    $filter = $this->makeFilter($this->bbox);

    $this->runChunkedCollect($filter, 10000);
    $this->runChunkedRewrite($filter, 10000);

    $this->assertFileDoesNotExist($this->tmpDir . '/stop_times.txt.rewrite_tmp');
    $this->assertFileDoesNotExist($this->tmpDir . '/partial_stop_ids.json');
  }

  // ---------------------------------------------------------------------------
  // Full pipeline: collect + rewrite equivalence
  // ---------------------------------------------------------------------------

  /**
   * Full chunked pipeline with tiny chunk size matches full single-pass result.
   *
   * Runs collect and rewrite both at chunk size 1, then verifies every output
   * file matches the expected single-pass result.
   *
   * @covers ::collectValidTripsInit
   * @covers ::collectValidTripsChunk
   * @covers ::collectValidTripsFinalize
   * @covers ::rewriteStopTimesInit
   * @covers ::rewriteStopTimesChunk
   * @covers ::rewriteStopTimesFinalize
   */
  public function testFullChunkedPipelineAtChunkSizeOneMatchesSinglePass(): void {
    $this->writeStandardFixture();
    $filter = $this->makeFilter($this->bbox);

    $this->runChunkedCollect($filter, 1);
    $this->runChunkedRewrite($filter, 1);

    $this->assertRewriteResultMatchesExpectation();
  }

  // ---------------------------------------------------------------------------
  // Assertion helper
  // ---------------------------------------------------------------------------

  /**
   * Asserts that the rewritten GTFS files match expected output for the fixture.
   *
   * Expected result (bbox N55.1/S54.3/E-2.0/W-3.75):
   * - T1 and T3 retained (both serve in-box stops); T2 removed.
   * - stops: S1, S2, S4 retained (S3 removed — no valid trip references it).
   * - routes: R1 retained; R2 removed.
   */
  private function assertRewriteResultMatchesExpectation(): void {
    // stop_times.txt: header + 3 rows (T1×S1, T1×S2, T3×S1, T3×S4 = 4 rows).
    $stopTimes = $this->readCsv('stop_times.txt');
    $retainedTripIds = array_column(array_slice($stopTimes, 1), 0);
    $this->assertNotContains('T2', $retainedTripIds, 'T2 rows must be removed from stop_times.');
    $this->assertContains('T1', $retainedTripIds, 'T1 rows must be retained in stop_times.');
    $this->assertContains('T3', $retainedTripIds, 'T3 rows must be retained in stop_times.');

    // stops.txt: S3 removed; S1, S2, S4 retained.
    $stopIds = array_column(array_slice($this->readCsv('stops.txt'), 1), 0);
    $this->assertContains('S1', $stopIds);
    $this->assertContains('S2', $stopIds);
    $this->assertContains('S4', $stopIds);
    $this->assertNotContains('S3', $stopIds);

    // trips.txt: T2 removed.
    $tripIds = array_column(array_slice($this->readCsv('trips.txt'), 1), 0);
    $this->assertContains('T1', $tripIds);
    $this->assertContains('T3', $tripIds);
    $this->assertNotContains('T2', $tripIds);

    // routes.txt: R2 removed (only referenced by T2).
    $routeIds = array_column(array_slice($this->readCsv('routes.txt'), 1), 0);
    $this->assertContains('R1', $routeIds);
    $this->assertNotContains('R2', $routeIds);
  }

}
