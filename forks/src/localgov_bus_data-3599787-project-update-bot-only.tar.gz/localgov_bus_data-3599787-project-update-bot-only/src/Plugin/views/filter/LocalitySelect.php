<?php

declare(strict_types=1);

namespace Drupal\localgov_bus_data\Plugin\views\filter;

use Drupal\Core\Database\Connection;
use Drupal\Core\Form\FormStateInterface;
use Drupal\views\Attribute\ViewsFilter;
use Drupal\views\Plugin\views\filter\FilterPluginBase;
use Symfony\Component\DependencyInjection\ContainerInterface;

/**
 * Filter bus stops by locality (NaPTAN area name) via a select list.
 *
 * Options are built from distinct non-null bustimes_locality values in the
 * bus stop table. When NaPTAN enrichment is disabled (all locality values are
 * NULL) the select renders with only the "All areas" placeholder and the
 * filter is a no-op — all stops remain visible.
 *
 * @ingroup views_filter_handlers
 */
#[ViewsFilter('localgov_bus_data_locality_autocomplete')]
final class LocalitySelect extends FilterPluginBase {

  /**
   * Cached locality options keyed by locality name.
   *
   * NULL until first populated; empty array when no locality data exists.
   *
   * @var array<string, string>|null
   */
  protected ?array $localityOptions = NULL;

  /**
   * {@inheritdoc}
   *
   * $database is protected (not readonly) so DependencySerializationTrait
   * can re-inject it via __wakeup() after the plugin is deserialised.
   */
  public function __construct(
    array $configuration,
    $plugin_id,
    $plugin_definition,
    // Not readonly: DependencySerializationTrait::__wakeup() must be able
    // to reassign this property after deserialisation.
    protected Connection $database,
  ) {
    parent::__construct($configuration, $plugin_id, $plugin_definition);
  }

  /**
   * {@inheritdoc}
   */
  public static function create(
    ContainerInterface $container,
    array $configuration,
    $plugin_id,
    $plugin_definition,
  ): static {
    return new static(
      $configuration,
      $plugin_id,
      $plugin_definition,
      $container->get('database'),
    );
  }

  /**
   * {@inheritdoc}
   */
  public function adminLabel($short = FALSE): string {
    return (string) $this->t('Locality (area select)');
  }

  /**
   * {@inheritdoc}
   */
  protected function valueForm(&$form, FormStateInterface $form_state): void {
    $options = $this->getLocalityOptions();

    $form['value'] = [
      '#type'          => 'select',
      '#title'         => $this->t('Area'),
      '#options'       => ['' => $this->t('- All areas -')] + $options,
      '#default_value' => is_string($this->value) ? $this->value : '',
    ];

    if ($form_state->get('exposed')) {
      $identifier = $this->options['expose']['identifier'];
      $user_input = $form_state->getUserInput();
      if (!isset($user_input[$identifier])) {
        $user_input[$identifier] = is_string($this->value) ? $this->value : '';
        $form_state->setUserInput($user_input);
      }
    }
  }

  /**
   * {@inheritdoc}
   *
   * Skips the filter when the submitted value is empty (the "All areas"
   * placeholder), ensuring all stops remain visible when NaPTAN is disabled.
   *
   * The operator is fixed to '=' in the View config and this plugin always
   * uses exact-match, so operator input is intentionally not re-read here.
   */
  public function acceptExposedInput($input): bool {
    if (empty($this->options['exposed'])) {
      return TRUE;
    }

    $identifier  = $this->options['expose']['identifier'];
    $value       = $input[$identifier] ?? '';
    $this->value = (string) $value;

    return $this->value !== '';
  }

  /**
   * {@inheritdoc}
   */
  public function query(): void {
    if ($this->value === '' || $this->value === NULL) {
      return;
    }

    $this->ensureMyTable();
    $this->query->addWhere(
      $this->options['group'],
      "$this->tableAlias.$this->realField",
      $this->value,
      '=',
    );
  }

  /**
   * Returns distinct locality names for the select options.
   *
   * The result is cached on this instance for the lifetime of the request.
   *
   * The table name is intentionally hardcoded: this query populates filter
   * option values independently of the View's join context, and
   * localgov_bus_stop is always the correct source for locality values.
   *
   * Returns an empty array when no locality data exists (NaPTAN disabled),
   * which leaves the filter inactive.
   *
   * @return array<string, string>
   *   Associative array of locality name to locality name, sorted
   *   alphabetically.
   */
  protected function getLocalityOptions(): array {
    if ($this->localityOptions !== NULL) {
      return $this->localityOptions;
    }

    $rows = $this->database
      ->select('localgov_bus_stop', 's')
      ->fields('s', ['bustimes_locality'])
      ->isNotNull('bustimes_locality')
      ->condition('bustimes_locality', '', '<>')
      ->distinct()
      ->orderBy('bustimes_locality')
      ->execute()
      ->fetchCol();

    $this->localityOptions = [];
    foreach ($rows as $locality) {
      $this->localityOptions[(string) $locality] = (string) $locality;
    }

    return $this->localityOptions;
  }

}
