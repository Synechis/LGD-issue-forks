<?php

declare(strict_types=1);

namespace Drupal\localgov_bus_data\Controller;

use Drupal\Core\Controller\ControllerBase;
use Drupal\Core\Database\Connection;
use Drupal\Core\StringTranslation\TranslatableMarkup;
use Symfony\Component\DependencyInjection\ContainerInterface;

/**
 * Renders the import log admin page.
 *
 * Displays recent GTFS import runs as a plain render-array table.
 * No Views dependency — the table is intentionally lightweight.
 */
final class ImportLogController extends ControllerBase {

  public function __construct(
    private readonly Connection $database,
  ) {}

  /**
   * {@inheritdoc}
   */
  public static function create(ContainerInterface $container): static {
    return new static(
      $container->get('database'),
    );
  }

  /**
   * Renders the import log table.
   *
   * @return array<string, mixed>
   *   Render array.
   */
  public function page(): array {
    $retention = (int) ($this->config('localgov_bus_data.settings')->get('import.log_retention') ?? 30);
    $cutoff    = time() - ($retention * 86400);

    $rows = $this->database->select('localgov_bus_data_import_log', 'l')
      ->fields('l')
      ->condition('timestamp', $cutoff, '>=')
      ->orderBy('timestamp', 'DESC')
      ->range(0, 100)
      ->execute()
      ?->fetchAll(\PDO::FETCH_ASSOC) ?? [];

    $tableRows = [];
    foreach ($rows as $row) {
      $counts = json_decode((string) ($row['rows_imported'] ?? '{}'), TRUE);
      $countSummary = '';
      if (is_array($counts)) {
        $parts = [];
        foreach ($counts as $migration => $count) {
          // Strip migration group prefix for readability.
          $label = str_replace('localgov_bus_data_', '', $migration);
          $parts[] = "{$label}: {$count}";
        }
        $countSummary = implode(', ', $parts);
      }

      $tableRows[] = [
        ['data' => ['#plain_text' => date('Y-m-d H:i:s', (int) $row['timestamp'])]],
        $row['status'] === 'success'
          ? new TranslatableMarkup('Success')
          : new TranslatableMarkup('Error'),
        ['data' => ['#plain_text' => $countSummary]],
        ['data' => ['#plain_text' => number_format((int) ($row['duration_ms'] ?? 0)) . ' ms']],
        ['data' => ['#plain_text' => $row['message'] ?? '']],
      ];
    }

    $build['table'] = [
      '#type'   => 'table',
      '#header' => [
        $this->t('Timestamp'),
        $this->t('Status'),
        $this->t('Rows imported'),
        $this->t('Duration'),
        $this->t('Message'),
      ],
      '#rows'  => $tableRows,
      '#empty' => $this->t('No import runs recorded in the last @days days.', ['@days' => $retention]),
      '#cache' => [
        'max-age' => 0,
      ],
    ];

    return $build;
  }

}
