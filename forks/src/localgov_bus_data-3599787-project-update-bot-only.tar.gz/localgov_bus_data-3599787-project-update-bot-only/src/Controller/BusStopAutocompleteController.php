<?php

declare(strict_types=1);

namespace Drupal\localgov_bus_data\Controller;

use Drupal\Core\Controller\ControllerBase;
use Drupal\Core\Entity\EntityTypeManagerInterface;
use Symfony\Component\DependencyInjection\ContainerInterface;
use Symfony\Component\HttpFoundation\JsonResponse;
use Symfony\Component\HttpFoundation\Request;

/**
 * Returns autocomplete suggestions for bus stop names.
 */
final class BusStopAutocompleteController extends ControllerBase {

  public function __construct(
    EntityTypeManagerInterface $entityTypeManager,
  ) {
    $this->entityTypeManager = $entityTypeManager;
  }

  /**
   * {@inheritdoc}
   */
  public static function create(ContainerInterface $container): static {
    return new static(
      $container->get('entity_type.manager'),
    );
  }

  /**
   * Returns JSON autocomplete matches for the given stop name prefix.
   */
  public function autocomplete(Request $request): JsonResponse {
    $query = mb_substr((string) $request->query->get('q', ''), 0, 128);
    $results = [];

    if (mb_strlen($query) >= 2) {
      $storage = $this->entityTypeManager->getStorage('localgov_bus_stop');
      $ids = $storage->getQuery()
        ->condition('bustimes_stop_name', $query, 'CONTAINS')
        ->sort('bustimes_stop_name', 'ASC')
        ->range(0, 10)
        ->accessCheck(TRUE)
        ->execute();

      $stops = $storage->loadMultiple($ids);

      foreach ($stops as $stop) {
        $name = $stop->bustimes_stop_name->getString();
        $results[] = [
          'value' => $name,
          'label' => $name,
        ];
      }
    }

    $response = new JsonResponse($results);
    $response->setMaxAge(60);
    $response->setPublic();
    return $response;
  }

}
