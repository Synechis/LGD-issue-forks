<?php

declare(strict_types=1);

namespace Drupal\localgov_bus_data\Controller;

use Drupal\Core\Controller\ControllerBase;
use Drupal\Core\Url;
use Symfony\Component\HttpFoundation\RedirectResponse;
use Symfony\Component\HttpKernel\Exception\NotFoundHttpException;

/**
 * Controllers for bus data admin pages.
 *
 * Two responsibilities:
 *
 * - landing() serves /admin/content/bus-data, the anchor for the "Bus Data"
 *   primary tab on /admin/content. It redirects to the Bus Stops collection so
 *   the first sub-tab is active by default, matching the Media tab pattern.
 *
 * - overview() serves /admin/structure/bus-data/*, the field_ui_base_route
 *   for each entity type so Field UI tabs (Manage fields, Manage form display,
 *   Manage display) appear under Structure.
 */
final class BusDataStructureController extends ControllerBase {

  /**
   * Redirects /admin/content/bus-data to the Bus Stops collection.
   *
   * This route is the anchor for the "Bus Data" primary tab on /admin/content
   * and the base_route for the five collection sub-tabs.
   */
  public function landing(): RedirectResponse {
    return $this->redirect('entity.localgov_bus_stop.collection');
  }

  /**
   * Renders the structure overview page for a bus data entity type.
   *
   * @param string $entity_type_id
   *   The entity type ID passed as a route default.
   *
   * @return array
   *   A render array.
   *
   * @throws \Symfony\Component\HttpKernel\Exception\NotFoundHttpException
   *   When the entity type ID does not exist.
   */
  public function overview(string $entity_type_id): array {
    // Pass FALSE so getDefinition() returns NULL instead of throwing on an
    // unknown ID, allowing a clean 404 rather than a 500.
    $entity_type = $this->entityTypeManager()->getDefinition($entity_type_id, FALSE);
    if ($entity_type === NULL) {
      throw new NotFoundHttpException();
    }

    return [
      '#type' => 'container',
      // Entity type plugin definitions are static until a cache rebuild;
      // no cache tags needed. Use 'route' context so each entity type's
      // page is cached as a distinct variant.
      '#cache' => [
        'contexts' => ['route'],
      ],
      'description' => [
        '#type' => 'html_tag',
        '#tag' => 'p',
        '#value' => $this->t(
          'Use the tabs above to manage fields and display modes for %label entities.',
          ['%label' => $entity_type->getLabel()],
        ),
      ],
      'collection_link' => [
        '#type' => 'link',
        '#title' => $this->t('View %label records', ['%label' => $entity_type->getLabel()]),
        '#url' => Url::fromRoute('entity.' . $entity_type_id . '.collection'),
        '#attributes' => ['class' => ['button']],
      ],
    ];
  }

}
