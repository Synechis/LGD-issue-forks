<?php

declare(strict_types=1);

namespace Drupal\localgov_bus_data\Service;

use Drupal\Core\Config\ConfigFactoryInterface;
use GuzzleHttp\ClientInterface;
use GuzzleHttp\Exception\GuzzleException;
use Psr\Log\LoggerInterface;

/**
 * Downloads the national bulk GTFS timetable ZIP.
 *
 * The bulk file contains all published UK bus timetable data in GTFS format.
 * It is typically 700 MB–1 GB and is regenerated nightly. Use
 * GtfsFilter::filterByGeography() after extraction to reduce it to the
 * local area before running migrations.
 *
 * @see https://data.bus-data.dft.gov.uk/guidance/
 */
final class GtfsDownloader {

  public function __construct(
    private readonly ClientInterface $httpClient,
    private readonly ConfigFactoryInterface $configFactory,
    private readonly LoggerInterface $logger,
  ) {}

  /**
   * Downloads the bulk GTFS timetable ZIP to a local file.
   *
   * @param string $destination
   *   Absolute local filesystem path where the file should be saved.
   *
   * @throws \RuntimeException
   */
  public function downloadBulkGtfs(string $destination): void {
    $url = (string) ($this->configFactory
      ->get('localgov_bus_data.settings')
      ->get('source.bulk_gtfs_url')
      ?? 'https://data.bus-data.dft.gov.uk/timetable/download/gtfs-file/all/');

    try {
      // 600 s is intentional: the bulk GTFS file is ~700 MB and takes several
      // minutes on a slow connection.
      $this->httpClient->request('GET', $url, [
        'sink'    => $destination,
        'timeout' => 600,
      ]);
    }
    catch (GuzzleException $e) {
      $this->logger->error('Bulk GTFS download failed: @message (@type).', [
        '@message' => $e->getMessage(),
        '@type'    => get_class($e),
      ]);
      throw new \RuntimeException('Bulk GTFS download failed.', 0, $e);
    }
  }

  /**
   * Sends a HEAD request to retrieve the remote file size.
   *
   * @param string $url
   *   Remote URL.
   *
   * @return int|null
   *   Content-Length in bytes, or NULL if unavailable.
   */
  public function getRemoteFileSize(string $url): ?int {
    try {
      $response = $this->httpClient->request('HEAD', $url, [
        'timeout'      => 30,
        'http_errors'  => FALSE,
      ]);
      $lengths = $response->getHeader('Content-Length');
      if (!empty($lengths)) {
        return (int) $lengths[0];
      }
    }
    catch (\Exception $e) {
      $this->logger->warning('Could not determine remote file size: @msg', [
        '@msg' => $e->getMessage(),
      ]);
    }
    return NULL;
  }

  /**
   * Downloads a byte-range chunk of a remote file and appends it locally.
   *
   * If the server returns HTTP 206 Partial Content the download used Range
   * requests and can be resumed. HTTP 200 means the server delivered the full
   * file; the caller should treat the download as complete.
   *
   * @param string $url
   *   Remote URL (must already include any required query parameters).
   * @param string $destination
   *   Absolute local path to write/append to.
   * @param int $offset
   *   Byte offset to start the Range request from.
   * @param int $chunkSize
   *   Number of bytes to request.
   *
   * @return array{bytes: int, is_range: bool}
   *   bytes  — actual bytes written to disk.
   *   is_range — TRUE when the server honoured the Range header (206).
   *
   * @throws \RuntimeException
   */
  public function downloadChunk(string $url, string $destination, int $offset, int $chunkSize): array {
    $endByte = $offset + $chunkSize - 1;

    try {
      $response = $this->httpClient->request('GET', $url, [
        'headers'     => ['Range' => "bytes={$offset}-{$endByte}"],
        'timeout'     => 120,
        'stream'      => TRUE,
        'http_errors' => FALSE,
      ]);
    }
    catch (GuzzleException $e) {
      throw new \RuntimeException('GTFS chunk download failed: ' . $e->getMessage(), 0, $e);
    }

    $status  = $response->getStatusCode();
    $isRange = ($status === 206);

    if ($status !== 200 && $status !== 206) {
      throw new \RuntimeException(
        sprintf('GTFS download returned unexpected HTTP %d from %s.', $status, $url)
      );
    }

    // First chunk (offset 0) writes a new file; subsequent chunks append.
    $mode   = ($offset === 0) ? 'wb' : 'ab';
    $handle = @fopen($destination, $mode);
    if ($handle === FALSE) {
      throw new \RuntimeException("Cannot open {$destination} for writing.");
    }

    $bytesWritten = 0;
    try {
      $body = $response->getBody();
      while (!$body->eof()) {
        $data          = $body->read(65536);
        $bytesWritten += strlen($data);
        fwrite($handle, $data);
      }
    }
    finally {
      fclose($handle);
    }

    return ['bytes' => $bytesWritten, 'is_range' => $isRange];
  }

}
