<?php

declare(strict_types=1);

namespace Drupal\localgov_bus_data\Service;

use Drupal\Core\Config\ConfigFactoryInterface;
use Drupal\Core\Database\Connection;
use GuzzleHttp\ClientInterface;
use Psr\Log\LoggerInterface;

/**
 * Downloads and applies NaPTAN stop data to enrich bus stop entities.
 *
 * NaPTAN (National Public Transport Access Nodes) provides authoritative
 * UK stop metadata including the stop indicator (e.g. "opp", "adj"), street
 * name, and locality. These are matched to existing bus stop entities via the
 * ATCO code (bustimes_stop_id) and stored in three denormalised columns.
 */
final class NaptanImportService {

  public function __construct(
    private readonly ConfigFactoryInterface $configFactory,
    private readonly ClientInterface $httpClient,
    private readonly Connection $database,
    private readonly LoggerInterface $logger,
  ) {}

  /**
   * Returns TRUE if NaPTAN enrichment is enabled in settings.
   */
  public function isEnabled(): bool {
    return (bool) $this->configFactory
      ->get('localgov_bus_data.settings')
      ->get('naptan.enabled');
  }

  /**
   * Returns the configured NaPTAN API URL.
   */
  public function getUrl(): string {
    return (string) ($this->configFactory
      ->get('localgov_bus_data.settings')
      ->get('naptan.url')
      ?? '');
  }

  /**
   * Downloads the NaPTAN CSV to a temp file using Guzzle sink.
   *
   * Writing directly to a file avoids loading the full response body into
   * PHP memory. The caller is responsible for deleting the temp file.
   *
   * @return string
   *   Absolute path to the downloaded temp file.
   *
   * @throws \RuntimeException
   *   If the URL is not configured or the download fails.
   */
  public function downloadToTempFile(): string {
    $url = $this->getUrl();
    if ($url === '') {
      throw new \RuntimeException('NaPTAN URL is not configured.');
    }

    $tmpFile = sys_get_temp_dir() . '/naptan_' . uniqid('', TRUE) . '.csv';

    $this->logger->notice('NaPTAN enrichment: downloading from @url.', ['@url' => $url]);

    try {
      $this->httpClient->request('GET', $url, [
        'timeout' => 120,
        'sink'    => $tmpFile,
      ]);
    }
    catch (\Exception $e) {
      @unlink($tmpFile);
      throw new \RuntimeException('NaPTAN download failed: ' . $e->getMessage(), 0, $e);
    }

    if (!file_exists($tmpFile) || filesize($tmpFile) === 0) {
      @unlink($tmpFile);
      throw new \RuntimeException('NaPTAN download returned an empty file.');
    }

    return $tmpFile;
  }

  /**
   * Downloads the NaPTAN CSV and updates stop enrichment fields.
   *
   * Matches rows on ATCOCode → bustimes_stop_id and writes bustimes_indicator,
   * bustimes_street, bustimes_locality for each matched stop.
   *
   * @return int
   *   Number of stop rows updated.
   *
   * @throws \RuntimeException
   *   If the URL is not configured or the download fails.
   */
  public function enrich(): int {
    $tmpFile = $this->downloadToTempFile();

    try {
      $handle = fopen($tmpFile, 'r');
      if ($handle === FALSE) {
        throw new \RuntimeException('Cannot open downloaded NaPTAN CSV file.');
      }

      // Skip header row.
      fgetcsv($handle, escape: '');
      $byteOffset = (int) ftell($handle);
      fclose($handle);

      $updated = 0;
      do {
        $result     = $this->processChunk($tmpFile, $byteOffset, 5000);
        $prevOffset = $byteOffset;
        $byteOffset = $result['offset'];
        $updated   += $result['updated'];
      } while ($byteOffset !== $prevOffset);

      $this->logger->notice('NaPTAN enrichment: @count stops updated.', ['@count' => $updated]);
      return $updated;
    }
    finally {
      @unlink($tmpFile);
    }
  }

  /**
   * Loads a map of ATCO code to entity ID for all stops in the database.
    *
    * Kept as a public helper for compatibility; large datasets should prefer
    * processChunk(), which resolves only the ATCO codes in each chunk.
   *
   * @return array<string, int>
   *   Array keyed by bustimes_stop_id (ATCO code) with entity ID values.
   */
  public function loadStopMap(): array {
    $result = $this->database
      ->select('localgov_bus_stop', 's')
      ->fields('s', ['id', 'bustimes_stop_id'])
      ->execute();

    $map = [];
    while ($row = $result->fetchAssoc()) {
      $map[(string) ($row['bustimes_stop_id'] ?? '')] = (int) ($row['id'] ?? 0);
    }

    return $map;
  }

  /**
   * Processes a chunk of NaPTAN CSV rows and updates stop enrichment fields.
   *
    * Reads up to $limit rows from the CSV starting at $byteOffset and resolves
    * only the ATCO codes found in that chunk to stop entity IDs.
   *
   * @param string $csvFile
   *   Absolute path to the downloaded NaPTAN CSV temp file.
   * @param int $byteOffset
   *   Byte position to seek to before reading (skip header on first call).
   * @param int $limit
   *   Maximum rows to process per call.
   *
   * @return array{updated: int, offset: int}
   *   updated — number of stop rows updated in this call.
   *   offset  — byte position after the last row read.
   *
   * @throws \RuntimeException
   */
  public function processChunk(
    string $csvFile,
    int $byteOffset,
    int $limit,
  ): array {
    $handle = fopen($csvFile, 'r');
    if ($handle === FALSE) {
      throw new \RuntimeException("Cannot open NaPTAN CSV file: {$csvFile}");
    }

    // Re-read the header to resolve column indices on every chunk call.
    // The header byte offset is passed in $byteOffset so we seek past it.
    // But we need the column names — seek to start, read header, seek back.
    rewind($handle);
    $header = fgetcsv($handle, escape: '');
    if (!is_array($header)) {
      fclose($handle);
      throw new \RuntimeException('NaPTAN CSV header row could not be read.');
    }

    $cols = array_flip($header);
    $required = ['ATCOCode', 'Indicator', 'Street', 'LocalityName'];
    $missing = array_diff($required, array_keys($cols));
    if (!empty($missing)) {
      fclose($handle);
      throw new \RuntimeException(
        'NaPTAN CSV is missing required columns: ' . implode(', ', $missing) . '.'
      );
    }

    $atcoCol      = $cols['ATCOCode'];
    $indicatorCol = $cols['Indicator'];
    $streetCol    = $cols['Street'];
    $localityCol  = $cols['LocalityName'];

    fseek($handle, $byteOffset);

    $rawRows = [];
    $atcoCodes = [];

    for ($i = 0; $i < $limit; $i++) {
      $row = fgetcsv($handle, escape: '');
      if ($row === FALSE) {
        break;
      }
      if (!isset($row[$atcoCol])) {
        continue;
      }
      $atco = trim((string) $row[$atcoCol]);
      if ($atco === '') {
        continue;
      }

      $atcoCodes[$atco] = TRUE;

      $indicator = isset($row[$indicatorCol]) ? trim((string) $row[$indicatorCol]) : '';
      $street    = isset($row[$streetCol]) ? trim((string) $row[$streetCol]) : '';
      $locality  = isset($row[$localityCol]) ? trim((string) $row[$localityCol]) : '';

      $rawRows[] = [
        'atco'      => $atco,
        'indicator' => $indicator !== '' ? $indicator : NULL,
        'street'    => $street !== '' ? $street : NULL,
        'locality'  => $locality !== '' ? $locality : NULL,
      ];
    }

    $newOffset = (int) ftell($handle);
    fclose($handle);

    $stopMap = $this->loadStopMapForAtcoCodes(array_keys($atcoCodes));

    $pending = [];
    foreach ($rawRows as $row) {
      $entityId = $stopMap[$row['atco']] ?? NULL;
      if ($entityId === NULL) {
        continue;
      }
      $pending[$entityId] = [
        'id'        => $entityId,
        'indicator' => $row['indicator'],
        'street'    => $row['street'],
        'locality'  => $row['locality'],
      ];
    }

    $updated = 0;

    foreach (array_chunk(array_values($pending), 500) as $chunk) {
      $args           = [];
      $indCases       = [];
      $strCases       = [];
      $locCases       = [];
      $idPlaceholders = [];

      foreach ($chunk as $i => $r) {
        $idKey  = ':id_' . $i;
        $indKey = ':ind_' . $i;
        $strKey = ':str_' . $i;
        $locKey = ':loc_' . $i;

        $indCases[]       = "WHEN {$idKey} THEN {$indKey}";
        $strCases[]       = "WHEN {$idKey} THEN {$strKey}";
        $locCases[]       = "WHEN {$idKey} THEN {$locKey}";
        $idPlaceholders[] = $idKey;

        $args[$idKey]  = $r['id'];
        $args[$indKey] = $r['indicator'];
        $args[$strKey] = $r['street'];
        $args[$locKey] = $r['locality'];
      }

      $indExpr = 'CASE id ' . implode(' ', $indCases) . ' ELSE bustimes_indicator END';
      $strExpr = 'CASE id ' . implode(' ', $strCases) . ' ELSE bustimes_street END';
      $locExpr = 'CASE id ' . implode(' ', $locCases) . ' ELSE bustimes_locality END';
      $inList  = implode(', ', $idPlaceholders);

      $stmt = $this->database->prepareStatement(
        "UPDATE {localgov_bus_stop}
         SET bustimes_indicator = {$indExpr},
             bustimes_street    = {$strExpr},
             bustimes_locality  = {$locExpr}
         WHERE id IN ({$inList})",
        [],
        TRUE,
      );
      $stmt->execute($args);
      $updated += $stmt->rowCount();
    }

    return ['updated' => $updated, 'offset' => $newOffset];
  }

  /**
   * Loads a stop map for a bounded set of ATCO codes.
   *
   * @param array<int, string> $atcoCodes
   *   ATCO codes to resolve.
   *
   * @return array<string, int>
   *   Map of ATCO code to stop entity ID.
   */
  private function loadStopMapForAtcoCodes(array $atcoCodes): array {
    if ($atcoCodes === []) {
      return [];
    }

    $map = [];

    foreach (array_chunk($atcoCodes, 1000) as $chunk) {
      $result = $this->database
        ->select('localgov_bus_stop', 's')
        ->fields('s', ['id', 'bustimes_stop_id'])
        ->condition('bustimes_stop_id', $chunk, 'IN')
        ->execute();

      while ($row = $result->fetchAssoc()) {
        $map[(string) ($row['bustimes_stop_id'] ?? '')] = (int) ($row['id'] ?? 0);
      }
    }

    return $map;
  }

}
