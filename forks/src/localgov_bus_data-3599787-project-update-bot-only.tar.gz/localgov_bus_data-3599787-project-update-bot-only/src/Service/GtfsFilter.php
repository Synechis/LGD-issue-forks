<?php

declare(strict_types=1);

namespace Drupal\localgov_bus_data\Service;

use Drupal\Core\Config\ConfigFactoryInterface;
use Psr\Log\LoggerInterface;

/**
 * Filters a downloaded GTFS directory to a configured geographic area.
 *
 * Operator datasets from BODS often cover multiple council areas. This service
 * trims the GTFS files to only trips that serve at least one stop inside the
 * configured area — but retains the FULL stop sequence for those trips,
 * including any stops outside the area (e.g. cross-boundary routes).
 *
 * This preserves complete route data for services like Carlisle → Gretna:
 * the Carlisle stop triggers inclusion, but Gretna is kept so the timetable
 * shows the correct terminal and stop sequence.
 *
 * Geographic filter priority:
 *   1. GeoJSON polygon (source.boundary_geojson config) — most accurate.
 *   2. Bounding box (source.bounding_box config) — fallback if no GeoJSON.
 *   3. No filter — if neither is configured, all data is kept.
 *
 * Processing order:
 *   1. Scan stops.txt       → collect in-area stop IDs (read-only)
 *   2. Scan stop_times.txt  → collect trip IDs with ≥1 in-area stop (read-only)
 *   3. Rewrite stop_times.txt keeping valid trips; collect all stop IDs used
 *   4. Rewrite stops.txt    keeping all stops referenced by valid trips
 *   5. Rewrite trips.txt    keeping valid trips
 *   6. Scan trips.txt       → collect route IDs; rewrite routes.txt
 *
 * All files are processed line-by-line; peak memory is proportional to the
 * number of unique trip/stop IDs, not the file size.
 */
final class GtfsFilter {

  public function __construct(
    private readonly ConfigFactoryInterface $configFactory,
    private readonly LoggerInterface $logger,
  ) {}

  /**
   * Filters GTFS files to trips that serve the configured geographic area.
   *
   * Checks for a GeoJSON polygon boundary first; falls back to the bounding
   * box if no GeoJSON is configured. If neither is configured, the directory
   * is left untouched.
   *
   * @param string $gtfsDir
   *   Absolute path to the extracted GTFS directory.
   *
   * @return array{stops: int, stop_times: int, trips: int, routes: int}
   *   Row counts remaining after filtering (zeroes if no filter configured).
   */
  public function filterByGeography(string $gtfsDir): array {
    $this->collectValidTrips($gtfsDir);
    return $this->rewriteByValidTrips($gtfsDir);
  }

  /**
   * Phase 1: Scans stops and stop_times to identify trips that serve the area.
   *
   * Writes the result to valid_trip_ids.json in $gtfsDir for consumption by
   * rewriteByValidTrips(). When no filter is configured, writes a null
   * sentinel so rewriteByValidTrips() knows to skip all rewrites.
   *
   * Splitting the filter into two phases allows each to run as a separate
   * batch operation, keeping every HTTP request within server timeout limits.
   *
   * @param string $gtfsDir
   *   Absolute path to the extracted GTFS directory.
   *
   * @throws \RuntimeException
   *   If valid_trip_ids.json cannot be written.
   */
  public function collectValidTrips(string $gtfsDir): void {
    $rings = $this->getPolygonRings();
    if ($rings !== NULL) {
      $preBbox = $this->computeRingsBbox($rings);
      $this->logger->info('GtfsFilter: filtering to GeoJSON polygon (bbox N:@n S:@s E:@e W:@w).', [
        '@n' => $preBbox['north'],
        '@s' => $preBbox['south'],
        '@e' => $preBbox['east'],
        '@w' => $preBbox['west'],
      ]);
      $inAreaStopIds = $this->collectInPolygonStopIds($gtfsDir . '/stops.txt', $rings, $preBbox);
    }
    else {
      $bbox = $this->getBoundingBox();
      if ($bbox === NULL) {
        $this->logger->info('GtfsFilter: no geographic filter configured, skipping.');
        if (file_put_contents($gtfsDir . '/valid_trip_ids.json', 'null') === FALSE) {
          throw new \RuntimeException('Could not write valid_trip_ids.json to GTFS temp directory.');
        }
        return;
      }
      $this->logger->info('GtfsFilter: filtering to bbox N:@n S:@s E:@e W:@w', [
        '@n' => $bbox['north'],
        '@s' => $bbox['south'],
        '@e' => $bbox['east'],
        '@w' => $bbox['west'],
      ]);
      $inAreaStopIds = $this->collectInBoxStopIds($gtfsDir . '/stops.txt', $bbox);
    }

    $this->logger->info('GtfsFilter: @count stops found within configured area.', [
      '@count' => count($inAreaStopIds),
    ]);

    $validTripIds = $this->collectValidTripIds($gtfsDir . '/stop_times.txt', $inAreaStopIds);
    $this->logger->info('GtfsFilter: @count trips serve at least one in-area stop.', [
      '@count' => count($validTripIds),
    ]);

    if (file_put_contents($gtfsDir . '/valid_trip_ids.json', json_encode(array_keys($validTripIds))) === FALSE) {
      throw new \RuntimeException('Could not write valid_trip_ids.json to GTFS temp directory.');
    }
  }

  /**
   * Phase 1 of chunked collect: scans stops.txt and writes in_area_stop_ids.json.
   *
   * Called once on the first batch pass. Writes in_area_stop_ids.json to $gtfsDir
   * so subsequent chunk passes can read it without carrying the stop ID set in
   * $context['sandbox']. When no geographic filter is configured, writes a null
   * sentinel so collectValidTripsFinalize() knows to write the same sentinel to
   * valid_trip_ids.json.
   *
   * @param string $gtfsDir
   *   Absolute path to the extracted GTFS directory.
   *
   * @return int
   *   Total byte size of stop_times.txt for progress reporting. Zero when no
   *   filter is configured (the chunk phase will be skipped).
   *
   * @throws \RuntimeException
   */
  public function collectValidTripsInit(string $gtfsDir): int {
    $rings = $this->getPolygonRings();
    if ($rings !== NULL) {
      $preBbox = $this->computeRingsBbox($rings);
      $this->logger->info('GtfsFilter: filtering to GeoJSON polygon (bbox N:@n S:@s E:@e W:@w).', [
        '@n' => $preBbox['north'],
        '@s' => $preBbox['south'],
        '@e' => $preBbox['east'],
        '@w' => $preBbox['west'],
      ]);
      $inAreaStopIds = $this->collectInPolygonStopIds($gtfsDir . '/stops.txt', $rings, $preBbox);
    }
    else {
      $bbox = $this->getBoundingBox();
      if ($bbox === NULL) {
        $this->logger->info('GtfsFilter: no geographic filter configured, skipping.');
        if (file_put_contents($gtfsDir . '/in_area_stop_ids.json', 'null') === FALSE) {
          throw new \RuntimeException('Could not write in_area_stop_ids.json.');
        }
        return 0;
      }
      $this->logger->info('GtfsFilter: filtering to bbox N:@n S:@s E:@e W:@w', [
        '@n' => $bbox['north'],
        '@s' => $bbox['south'],
        '@e' => $bbox['east'],
        '@w' => $bbox['west'],
      ]);
      $inAreaStopIds = $this->collectInBoxStopIds($gtfsDir . '/stops.txt', $bbox);
    }

    $this->logger->info('GtfsFilter: @count stops found within configured area.', [
      '@count' => count($inAreaStopIds),
    ]);

    if (file_put_contents($gtfsDir . '/in_area_stop_ids.json', json_encode(array_keys($inAreaStopIds))) === FALSE) {
      throw new \RuntimeException('Could not write in_area_stop_ids.json.');
    }

    // Initialise empty partial trip IDs file.
    if (file_put_contents($gtfsDir . '/partial_trip_ids.json', '') === FALSE) {
      throw new \RuntimeException('Could not initialise partial_trip_ids.json.');
    }

    $stopTimesFile = $gtfsDir . '/stop_times.txt';
    clearstatcache(TRUE, $stopTimesFile);
    return file_exists($stopTimesFile) ? (int) filesize($stopTimesFile) : 0;
  }

  /**
   * Phase 2 of chunked collect: scans a chunk of stop_times.txt.
   *
   * Reads up to $chunkRows rows starting at $byteOffset. Appends any trip IDs
   * that serve an in-area stop to partial_trip_ids.json (one ID per line).
   * The in-area stop ID set is read from in_area_stop_ids.json on every call so
   * it does not need to be carried in $context['sandbox'].
   *
   * @param string $gtfsDir
   *   Absolute path to the extracted GTFS directory.
   * @param int $byteOffset
   *   Byte position to seek to before reading.
   * @param int $chunkRows
   *   Maximum number of CSV rows to read per call.
   *
   * @return array{offset: int, done: bool}
   *   offset — byte position after the last row read.
   *   done   — TRUE when the file is exhausted.
   *
   * @throws \RuntimeException
   */
  public function collectValidTripsChunk(string $gtfsDir, int $byteOffset, int $chunkRows): array {
    $stopIdsJson = $gtfsDir . '/in_area_stop_ids.json';
    if (!file_exists($stopIdsJson)) {
      throw new \RuntimeException('in_area_stop_ids.json not found; call collectValidTripsInit() first.');
    }

    $json = file_get_contents($stopIdsJson);
    if ($json === FALSE) {
      throw new \RuntimeException('Could not read in_area_stop_ids.json.');
    }

    // Null sentinel means no filter — nothing to collect.
    if ($json === 'null') {
      return ['offset' => $byteOffset, 'done' => TRUE];
    }

    $stopIdList = json_decode($json, TRUE);
    if (!is_array($stopIdList)) {
      throw new \RuntimeException('in_area_stop_ids.json contains unexpected data.');
    }

    /** @var array<string, true> $inAreaStopIds */
    $inAreaStopIds = array_fill_keys($stopIdList, TRUE);

    $stopTimesFile = $gtfsDir . '/stop_times.txt';
    $cols = $this->resolveColumns($stopTimesFile, ['stop_id', 'trip_id']);
    if ($cols === FALSE) {
      return ['offset' => $byteOffset, 'done' => TRUE];
    }

    $fh = fopen($stopTimesFile, 'r');
    if ($fh === FALSE) {
      throw new \RuntimeException('Cannot open stop_times.txt for chunked scan.');
    }

    fseek($fh, $byteOffset);

    $foundTripIds = [];
    $read = 0;

    for ($i = 0; $i < $chunkRows; $i++) {
      $row = fgetcsv($fh, escape: '');
      if ($row === FALSE) {
        break;
      }
      $read++;
      $stopId = (string) ($row[$cols['stop_id']] ?? '');
      if (isset($inAreaStopIds[$stopId])) {
        $tripId = (string) ($row[$cols['trip_id']] ?? '');
        if ($tripId !== '') {
          $foundTripIds[$tripId] = TRUE;
        }
      }
    }

    $newOffset = (int) ftell($fh);
    fclose($fh);

    $done = $read < $chunkRows;

    // Append found trip IDs to partial file (one per line).
    if (!empty($foundTripIds)) {
      $lines = implode("\n", array_keys($foundTripIds)) . "\n";
      if (file_put_contents($gtfsDir . '/partial_trip_ids.json', $lines, FILE_APPEND | LOCK_EX) === FALSE) {
        throw new \RuntimeException('Could not append to partial_trip_ids.json.');
      }
    }

    return ['offset' => $newOffset, 'done' => $done];
  }

  /**
   * Phase 3 of chunked collect: writes valid_trip_ids.json from partial results.
   *
   * Reads the accumulated trip IDs from partial_trip_ids.json (written by
   * collectValidTripsChunk()), deduplicates them, and writes the final
   * valid_trip_ids.json consumed by rewriteByValidTrips() / rewriteStopTimesInit().
   * Cleans up the temporary in_area_stop_ids.json and partial_trip_ids.json files.
   *
   * @param string $gtfsDir
   *   Absolute path to the extracted GTFS directory.
   *
   * @throws \RuntimeException
   */
  public function collectValidTripsFinalize(string $gtfsDir): void {
    $stopIdsJson = $gtfsDir . '/in_area_stop_ids.json';

    // If no filter was configured (null sentinel), write the same to valid_trip_ids.json.
    if (file_exists($stopIdsJson)) {
      $sentinel = file_get_contents($stopIdsJson);
      if ($sentinel === 'null') {
        if (file_put_contents($gtfsDir . '/valid_trip_ids.json', 'null') === FALSE) {
          throw new \RuntimeException('Could not write valid_trip_ids.json.');
        }
        @unlink($stopIdsJson);
        @unlink($gtfsDir . '/partial_trip_ids.json');
        return;
      }
    }

    $partialFile = $gtfsDir . '/partial_trip_ids.json';
    $raw = file_exists($partialFile) ? file_get_contents($partialFile) : '';
    if ($raw === FALSE) {
      throw new \RuntimeException('Could not read partial_trip_ids.json.');
    }

    // Deduplicate trip IDs accumulated across all chunk passes.
    $lines = array_filter(array_map('trim', explode("\n", $raw)));
    $uniqueTripIds = array_keys(array_flip($lines));

    $this->logger->info('GtfsFilter: @count trips serve at least one in-area stop.', [
      '@count' => count($uniqueTripIds),
    ]);

    if (file_put_contents($gtfsDir . '/valid_trip_ids.json', json_encode($uniqueTripIds)) === FALSE) {
      throw new \RuntimeException('Could not write valid_trip_ids.json.');
    }

    @unlink($stopIdsJson);
    @unlink($partialFile);
  }

  /**
   * Phase 1 of chunked rewrite: initialises the stop_times.txt rewrite pass.
   *
   * Reads valid_trip_ids.json (written by collectValidTripsFinalize()) and
   * opens a temp output file for writing filtered rows into. When the null
   * sentinel is present (no filter configured) the rewrite is a no-op.
   *
   * @param string $gtfsDir
   *   Absolute path to the extracted GTFS directory.
   *
   * @return array{total_bytes: int, tmp_file: string, skip: bool}
   *   total_bytes — size of stop_times.txt for progress reporting.
   *   tmp_file    — path to the temp output file (empty string when skip=TRUE).
   *   skip        — TRUE when no filter is configured; caller skips chunk phase.
   *
   * @throws \RuntimeException
   */
  public function rewriteStopTimesInit(string $gtfsDir): array {
    $jsonFile = $gtfsDir . '/valid_trip_ids.json';
    if (!file_exists($jsonFile)) {
      throw new \RuntimeException('valid_trip_ids.json not found; collectValidTripsFinalize() must run first.');
    }

    $json = file_get_contents($jsonFile);
    if ($json === FALSE) {
      throw new \RuntimeException('Could not read valid_trip_ids.json.');
    }

    if ($json === 'null') {
      return ['total_bytes' => 0, 'tmp_file' => '', 'skip' => TRUE];
    }

    $stopTimesFile = $gtfsDir . '/stop_times.txt';
    $cols = $this->resolveColumns($stopTimesFile, ['trip_id']);
    if ($cols === FALSE) {
      throw new \RuntimeException('stop_times.txt missing required column "trip_id".');
    }

    // Write header row to temp output file.
    $tmpFile = $stopTimesFile . '.rewrite_tmp';
    $in = fopen($stopTimesFile, 'r');
    if ($in === FALSE) {
      throw new \RuntimeException('Cannot open stop_times.txt for rewrite.');
    }
    $header = fgetcsv($in, escape: '');
    $headerOffset = (int) ftell($in);
    fclose($in);

    if (!is_array($header)) {
      throw new \RuntimeException('stop_times.txt header row could not be read.');
    }

    $out = fopen($tmpFile, 'w');
    if ($out === FALSE) {
      throw new \RuntimeException('Cannot create stop_times.txt rewrite temp file.');
    }
    fputcsv($out, $header, escape: '');
    fclose($out);

    clearstatcache(TRUE, $stopTimesFile);

    return [
      'total_bytes' => (int) filesize($stopTimesFile),
      'tmp_file'    => $tmpFile,
      'skip'        => FALSE,
      'header_offset' => $headerOffset,
    ];
  }

  /**
   * Phase 2 of chunked rewrite: rewrites a chunk of stop_times.txt.
   *
   * Reads up to $chunkRows rows from stop_times.txt starting at $byteOffset,
   * appending rows for valid trips to the temp output file. The valid trip ID
   * set is read from valid_trip_ids.json on every call to avoid carrying a
   * large array through $context['sandbox'].
   *
   * Also accumulates the stop IDs referenced by retained rows so that the
   * finalise step can rewrite stops.txt correctly.
   *
   * @param string $gtfsDir
   *   Absolute path to the extracted GTFS directory.
   * @param string $tmpFile
   *   Absolute path to the temp output file opened by rewriteStopTimesInit().
   * @param int $byteOffset
   *   Byte position in stop_times.txt to start reading from.
   * @param int $chunkRows
   *   Maximum number of rows to process per call.
   *
   * @return array{offset: int, done: bool, kept: int}
   *   offset — byte position after the last row read.
   *   done   — TRUE when the file is exhausted.
   *   kept   — number of rows written to the temp file in this call.
   *
   * @throws \RuntimeException
   */
  public function rewriteStopTimesChunk(
    string $gtfsDir,
    string $tmpFile,
    int $byteOffset,
    int $chunkRows,
  ): array {
    $jsonFile = $gtfsDir . '/valid_trip_ids.json';
    $json = file_get_contents($jsonFile);
    if ($json === FALSE || $json === 'null') {
      return ['offset' => $byteOffset, 'done' => TRUE, 'kept' => 0];
    }

    $tripIdList = json_decode($json, TRUE);
    if (!is_array($tripIdList)) {
      throw new \RuntimeException('valid_trip_ids.json contains unexpected data.');
    }

    /** @var array<string, true> $validTripIds */
    $validTripIds = array_fill_keys($tripIdList, TRUE);

    $stopTimesFile = $gtfsDir . '/stop_times.txt';
    $cols = $this->resolveColumns($stopTimesFile, ['trip_id', 'stop_id']);
    if ($cols === FALSE) {
      return ['offset' => $byteOffset, 'done' => TRUE, 'kept' => 0];
    }

    $in = fopen($stopTimesFile, 'r');
    if ($in === FALSE) {
      throw new \RuntimeException('Cannot open stop_times.txt for chunk rewrite.');
    }

    $out = fopen($tmpFile, 'a');
    if ($out === FALSE) {
      fclose($in);
      throw new \RuntimeException('Cannot open rewrite temp file for appending.');
    }

    fseek($in, $byteOffset);

    $kept = 0;
    $read = 0;
    $neededStopIds = [];

    for ($i = 0; $i < $chunkRows; $i++) {
      $row = fgetcsv($in, escape: '');
      if ($row === FALSE) {
        break;
      }
      $read++;
      $tripId = (string) ($row[$cols['trip_id']] ?? '');
      if (isset($validTripIds[$tripId])) {
        fputcsv($out, $row, escape: '');
        $stopId = (string) ($row[$cols['stop_id']] ?? '');
        if ($stopId !== '') {
          $neededStopIds[$stopId] = TRUE;
        }
        $kept++;
      }
    }

    $newOffset = (int) ftell($in);
    fclose($in);
    fclose($out);

    $done = $read < $chunkRows;

    // Accumulate needed stop IDs to disk for use by rewriteStopTimesFinalize().
    if (!empty($neededStopIds)) {
      $partial = $gtfsDir . '/partial_stop_ids.json';
      $lines = implode("\n", array_keys($neededStopIds)) . "\n";
      if (file_put_contents($partial, $lines, FILE_APPEND | LOCK_EX) === FALSE) {
        throw new \RuntimeException('Could not append to partial_stop_ids.json.');
      }
    }

    return ['offset' => $newOffset, 'done' => $done, 'kept' => $kept];
  }

  /**
   * Phase 3 of chunked rewrite: finalises stop_times and rewrites remaining files.
   *
   * Renames the temp output file to stop_times.txt, reads the accumulated
   * needed stop IDs from partial_stop_ids.json, then rewrites stops.txt,
   * trips.txt, and routes.txt. These three files are small (already filtered)
   * and complete in a single pass.
   *
   * @param string $gtfsDir
   *   Absolute path to the extracted GTFS directory.
   *
   * @return array{stops: int, stop_times: int, trips: int, routes: int}
   *   Row counts remaining after filtering.
   *
   * @throws \RuntimeException
   */
  public function rewriteStopTimesFinalize(string $gtfsDir): array {
    $stopTimesFile = $gtfsDir . '/stop_times.txt';
    $tmpFile       = $stopTimesFile . '.rewrite_tmp';

    if (!file_exists($tmpFile)) {
      throw new \RuntimeException('Rewrite temp file not found; rewriteStopTimesInit() must run first.');
    }

    if (!rename($tmpFile, $stopTimesFile)) {
      throw new \RuntimeException('Could not rename stop_times rewrite temp file.');
    }

    // Count kept rows (subtract 1 for header).
    $stopTimesKept = max(0, $this->countCsvRows($stopTimesFile) - 1);

    // Read accumulated needed stop IDs.
    $partialStops = $gtfsDir . '/partial_stop_ids.json';
    $raw = file_exists($partialStops) ? file_get_contents($partialStops) : '';
    $lines = array_filter(array_map('trim', explode("\n", (string) $raw)));
    /** @var array<string, true> $allNeededStopIds */
    $allNeededStopIds = array_fill_keys($lines, TRUE);
    @unlink($partialStops);

    $this->logger->info('GtfsFilter: @count stop_times retained.', ['@count' => $stopTimesKept]);

    // Rewrite stops, trips, routes (small files — single pass each).
    $stopsKept = $this->rewriteByStopId($gtfsDir . '/stops.txt', $allNeededStopIds);
    $this->logger->info('GtfsFilter: @count stops retained.', ['@count' => $stopsKept]);

    $jsonFile = $gtfsDir . '/valid_trip_ids.json';
    $json = file_get_contents($jsonFile);
    $tripIdList = is_string($json) ? json_decode($json, TRUE) : [];
    /** @var array<string, true> $validTripIds */
    $validTripIds = is_array($tripIdList) ? array_fill_keys($tripIdList, TRUE) : [];

    $tripsKept = $this->rewriteByTripId($gtfsDir . '/trips.txt', $validTripIds);
    $this->logger->info('GtfsFilter: @count trips retained.', ['@count' => $tripsKept]);

    $validRouteIds = $validTripIds !== [] ? $this->collectRouteIdsFromTrips($gtfsDir . '/trips.txt') : [];
    $routesKept = $this->rewriteByRouteId($gtfsDir . '/routes.txt', $validRouteIds);
    $this->logger->info('GtfsFilter: @count routes retained.', ['@count' => $routesKept]);

    return [
      'stops'      => $stopsKept,
      'stop_times' => $stopTimesKept,
      'trips'      => $tripsKept,
      'routes'     => $routesKept,
    ];
  }

  /**
   * Phase 2: Rewrites GTFS files to retain only valid trips and their stops.
   *
   * Reads the trip-ID list written by collectValidTrips() and rewrites
   * stop_times.txt, stops.txt, trips.txt, and routes.txt. If the JSON file
   * contains the null sentinel (no filter configured), all rewrites are
   * skipped and zero counts are returned.
   *
   * @param string $gtfsDir
   *   Absolute path to the extracted GTFS directory.
   *
   * @return array{stops: int, stop_times: int, trips: int, routes: int}
   *   Row counts remaining after filtering.
   *
   * @throws \RuntimeException
   *   If valid_trip_ids.json is missing or cannot be decoded.
   */
  public function rewriteByValidTrips(string $gtfsDir): array {
    $jsonFile = $gtfsDir . '/valid_trip_ids.json';
    if (!file_exists($jsonFile)) {
      throw new \RuntimeException('valid_trip_ids.json not found; collectValidTrips() must run first.');
    }

    $json = file_get_contents($jsonFile);
    if ($json === FALSE) {
      throw new \RuntimeException('Could not read valid_trip_ids.json.');
    }

    if ($json === 'null') {
      return ['stops' => 0, 'stop_times' => 0, 'trips' => 0, 'routes' => 0];
    }

    $tripIdList = json_decode($json, TRUE);
    if (!is_array($tripIdList)) {
      throw new \RuntimeException('valid_trip_ids.json contains unexpected data.');
    }

    /** @var array<string, true> $validTripIds */
    $validTripIds = array_fill_keys($tripIdList, TRUE);

    [
      'count'    => $stopTimesKept,
      'stop_ids' => $allNeededStopIds,
    ] = $this->rewriteStopTimesAndCollectStops(
      $gtfsDir . '/stop_times.txt',
      $validTripIds,
    );

    $stopsKept = $this->rewriteByStopId($gtfsDir . '/stops.txt', $allNeededStopIds);
    $this->logger->info('GtfsFilter: @count stops retained (includes cross-boundary stops).', [
      '@count' => $stopsKept,
    ]);

    $tripsKept = $this->rewriteByTripId($gtfsDir . '/trips.txt', $validTripIds);
    $this->logger->info('GtfsFilter: @count trips retained.', ['@count' => $tripsKept]);

    // rewriteByTripId() skips the file when $validTripIds is empty, so reading
    // it back would yield unfiltered data. Skip the route scan in that case.
    $validRouteIds = $validTripIds !== [] ? $this->collectRouteIdsFromTrips($gtfsDir . '/trips.txt') : [];
    $routesKept = $this->rewriteByRouteId($gtfsDir . '/routes.txt', $validRouteIds);
    $this->logger->info('GtfsFilter: @count routes retained.', ['@count' => $routesKept]);

    return [
      'stops'      => $stopsKept,
      'stop_times' => $stopTimesKept,
      'trips'      => $tripsKept,
      'routes'     => $routesKept,
    ];
  }

  /**
   * Scans stops.txt and returns IDs of stops inside the bounding box.
   *
   * Read-only; does not modify the file.
   *
   * @param string $file
   *   Absolute path to stops.txt.
   * @param array{north: float, south: float, east: float, west: float} $bbox
   *   Bounding box coordinates.
   *
   * @return array<string, true>
   *   Stop IDs inside the box, keyed for O(1) lookup.
   */
  private function collectInBoxStopIds(string $file, array $bbox): array {
    $inBox = [];
    $cols = $this->resolveColumns($file, ['stop_lat', 'stop_lon', 'stop_id']);
    if ($cols === FALSE) {
      return $inBox;
    }
    $this->scanCsv($file, function (array $header, array $row) use ($bbox, $cols, &$inBox): void {
      $lat = (float) ($row[$cols['stop_lat']] ?? 0);
      $lon = (float) ($row[$cols['stop_lon']] ?? 0);
      if ($lat >= $bbox['south'] && $lat <= $bbox['north']
        && $lon >= $bbox['west'] && $lon <= $bbox['east']) {
        $stopId = (string) ($row[$cols['stop_id']] ?? '');
        if ($stopId !== '') {
          $inBox[$stopId] = TRUE;
        }
      }
    });
    return $inBox;
  }

  /**
   * Scans stops.txt and returns IDs of stops inside the GeoJSON polygon.
   *
   * Uses a bounding-box pre-filter to avoid the more expensive ray-cast for
   * stops that are clearly outside the polygon's extent. Read-only.
   *
   * @param string $file
   *   Absolute path to stops.txt.
   * @param list<list<array{0: float, 1: float}>> $rings
   *   Polygon rings — each ring is a list of [lon, lat] pairs (GeoJSON order).
   *   A stop is considered inside the area if it falls within any ring.
   * @param array{north: float, south: float, east: float, west: float} $preBbox
   *   Bounding box of the polygon rings, used as a fast pre-filter.
   *
   * @return array<string, true>
   *   Stop IDs inside the polygon, keyed for O(1) lookup.
   */
  private function collectInPolygonStopIds(string $file, array $rings, array $preBbox): array {
    $inArea = [];
    $cols = $this->resolveColumns($file, ['stop_lat', 'stop_lon', 'stop_id']);
    if ($cols === FALSE) {
      return $inArea;
    }
    $this->scanCsv($file, function (array $header, array $row) use ($rings, $preBbox, $cols, &$inArea): void {
      $lat = (float) ($row[$cols['stop_lat']] ?? 0);
      $lon = (float) ($row[$cols['stop_lon']] ?? 0);
      // Quick bbox pre-filter — avoids the ray-cast for most stops.
      if ($lat < $preBbox['south'] || $lat > $preBbox['north']
        || $lon < $preBbox['west'] || $lon > $preBbox['east']) {
        return;
      }
      foreach ($rings as $ring) {
        if ($this->pointInPolygon($lat, $lon, $ring)) {
          $stopId = (string) ($row[$cols['stop_id']] ?? '');
          if ($stopId !== '') {
            $inArea[$stopId] = TRUE;
          }
          return;
        }
      }
    });
    return $inArea;
  }

  /**
   * Tests whether a point is inside a GeoJSON polygon ring (ray casting).
   *
   * Uses the ray casting (even-odd rule) algorithm. Points exactly on the
   * boundary may return either TRUE or FALSE; this is acceptable for the
   * geographic filtering use-case.
   *
   * @param float $lat
   *   Point latitude (WGS84).
   * @param float $lon
   *   Point longitude (WGS84).
   * @param list<array{0: float, 1: float}> $ring
   *   Ring vertices as [lon, lat] pairs (GeoJSON order: x = lon, y = lat).
   *
   * @return bool
   *   TRUE if the point is inside the ring.
   */
  private function pointInPolygon(float $lat, float $lon, array $ring): bool {
    $n = count($ring);
    $inside = FALSE;
    // In the ray casting algorithm lon is the horizontal axis (x) and lat is
    // the vertical axis (y). GeoJSON ring entries are [lon, lat].
    for ($i = 0, $j = $n - 1; $i < $n; $j = $i++) {
      // Lon of vertex i.
      $xi = $ring[$i][0];
      // Lat of vertex i.
      $yi = $ring[$i][1];
      // Lon of vertex j.
      $xj = $ring[$j][0];
      // Lat of vertex j.
      $yj = $ring[$j][1];
      // The outer condition guarantees $yi and $yj straddle $lat, so
      // ($yj - $yi) cannot be zero and there is no division-by-zero risk.
      if ((($yi > $lat) !== ($yj > $lat))
        && ($lon < ($xj - $xi) * ($lat - $yi) / ($yj - $yi) + $xi)) {
        $inside = !$inside;
      }
    }
    return $inside;
  }

  /**
   * Computes a bounding box that encloses all polygon rings.
   *
   * @param list<list<array{0: float, 1: float}>> $rings
   *   Polygon rings as [lon, lat] pairs.
   *
   * @return array{north: float, south: float, east: float, west: float}
   *   Bounding box of the rings.
   */
  private function computeRingsBbox(array $rings): array {
    $north = -90.0;
    $south = 90.0;
    $east = -180.0;
    $west = 180.0;
    foreach ($rings as $ring) {
      foreach ($ring as [$lon, $lat]) {
        if ($lat > $north) {
          $north = $lat;
        }
        if ($lat < $south) {
          $south = $lat;
        }
        if ($lon > $east) {
          $east = $lon;
        }
        if ($lon < $west) {
          $west = $lon;
        }
      }
    }
    return ['north' => $north, 'south' => $south, 'east' => $east, 'west' => $west];
  }

  /**
   * Reads the GeoJSON boundary from config and returns polygon rings.
   *
   * Supports Polygon and MultiPolygon geometry types, and unwraps Feature
   * or FeatureCollection wrappers. Only outer rings are used; inner rings
   * (holes) are ignored.
   *
   * @return list<list<array{0: float, 1: float}>>|null
   *   Array of rings — each ring is a list of [lon, lat] float pairs — or
   *   NULL if no valid GeoJSON is configured.
   */
  private function getPolygonRings(): ?array {
    $json = $this->configFactory->get('localgov_bus_data.settings')->get('source.boundary_geojson');
    if (empty($json) || !is_string($json)) {
      return NULL;
    }
    $data = json_decode($json, TRUE);
    if (!is_array($data)) {
      $this->logger->error('GtfsFilter: source.boundary_geojson is not valid JSON.');
      return NULL;
    }
    return $this->extractRings($data);
  }

  /**
   * Recursively extracts polygon rings from a GeoJSON structure.
   *
   * @param array<mixed> $data
   *   Decoded GeoJSON (Feature, FeatureCollection, Polygon, or MultiPolygon).
   *
   * @return list<list<array{0: float, 1: float}>>|null
   *   Rings or NULL on unsupported geometry type.
   */
  private function extractRings(array $data): ?array {
    $type = (string) ($data['type'] ?? '');

    if ($type === 'Feature') {
      $geometry = $data['geometry'] ?? NULL;
      if (!is_array($geometry)) {
        return NULL;
      }
      return $this->extractRings($geometry);
    }

    if ($type === 'GeometryCollection') {
      $geometries = $data['geometries'] ?? [];
      if (empty($geometries)) {
        return NULL;
      }
      $allRings = [];
      foreach ($geometries as $geometry) {
        if (!is_array($geometry)) {
          continue;
        }
        $rings = $this->extractRings($geometry);
        if ($rings !== NULL) {
          array_push($allRings, ...$rings);
        }
      }
      return empty($allRings) ? NULL : $allRings;
    }

    if ($type === 'FeatureCollection') {
      $features = $data['features'] ?? [];
      if (empty($features)) {
        return NULL;
      }
      $allRings = [];
      foreach ($features as $feature) {
        if (!is_array($feature)) {
          continue;
        }
        $rings = $this->extractRings($feature);
        if ($rings !== NULL) {
          array_push($allRings, ...$rings);
        }
      }
      return empty($allRings) ? NULL : $allRings;
    }

    $coords = $data['coordinates'] ?? NULL;
    if (!is_array($coords)) {
      return NULL;
    }

    if ($type === 'Polygon') {
      // $coords[0] is the outer ring; $coords[1..n] are optional holes.
      if (empty($coords[0])) {
        return NULL;
      }
      return [array_map(fn($p) => [(float) $p[0], (float) $p[1]], $coords[0])];
    }

    if ($type === 'MultiPolygon') {
      $rings = [];
      foreach ($coords as $polygon) {
        if (!empty($polygon[0])) {
          $rings[] = array_map(fn($p) => [(float) $p[0], (float) $p[1]], $polygon[0]);
        }
      }
      return empty($rings) ? NULL : $rings;
    }

    $this->logger->error(
      'GtfsFilter: unsupported GeoJSON type "@type". Expected Polygon or MultiPolygon.',
      ['@type' => $type],
    );
    return NULL;
  }

  /**
   * Scans stop_times.txt and returns IDs of trips with ≥1 in-area stop.
   *
   * Read-only; does not modify the file.
   *
   * @param string $file
   *   Absolute path to stop_times.txt.
   * @param array<string, true> $inAreaStopIds
   *   Stop IDs inside the configured area.
   *
   * @return array<string, true>
   *   Trip IDs that call at least one in-area stop, keyed for O(1) lookup.
   */
  private function collectValidTripIds(string $file, array $inAreaStopIds): array {
    $validTrips = [];
    $cols = $this->resolveColumns($file, ['stop_id', 'trip_id']);
    if ($cols === FALSE) {
      return $validTrips;
    }
    $this->scanCsv($file, function (array $header, array $row) use ($inAreaStopIds, $cols, &$validTrips): void {
      $stopId = (string) ($row[$cols['stop_id']] ?? '');
      if (isset($inAreaStopIds[$stopId])) {
        $tripId = (string) ($row[$cols['trip_id']] ?? '');
        if ($tripId !== '') {
          $validTrips[$tripId] = TRUE;
        }
      }
    });
    return $validTrips;
  }

  /**
   * Rewrites stop_times.txt keeping all rows for valid trips.
   *
   * Also collects every stop_id referenced by those trips so that
   * cross-boundary stops can be retained in stops.txt.
   *
   * @param string $file
   *   Absolute path to stop_times.txt.
   * @param array<string, true> $validTripIds
   *   Trip IDs to keep (from collectValidTripIds).
   *
   * @return array{count: int, stop_ids: array<string, true>}
   *   Array with 'count' (int rows kept) and 'stop_ids' (unique stop IDs map).
   */
  private function rewriteStopTimesAndCollectStops(string $file, array $validTripIds): array {
    $neededStopIds = [];
    $rowCount = 0;
    $cols = $this->resolveColumns($file, ['trip_id', 'stop_id']);
    if ($cols === FALSE) {
      return ['count' => 0, 'stop_ids' => []];
    }
    $this->rewriteCsv(
      $file,
      function (array $header, array $row) use ($validTripIds, $cols, &$neededStopIds, &$rowCount): bool {
        $tripId = (string) ($row[$cols['trip_id']] ?? '');
        if (isset($validTripIds[$tripId])) {
          $stopId = (string) ($row[$cols['stop_id']] ?? '');
          if ($stopId !== '') {
            $neededStopIds[$stopId] = TRUE;
          }
          $rowCount++;
          return TRUE;
        }
        return FALSE;
      },
    );
    return ['count' => $rowCount, 'stop_ids' => $neededStopIds];
  }

  /**
   * Rewrites stops.txt keeping all stops used by valid trips.
   *
   * @param string $file
   *   Absolute path to stops.txt.
   * @param array<string, true> $neededStopIds
   *   Stop IDs to keep (from rewriteStopTimesAndCollectStops).
   *
   * @return int
   *   Number of stop rows retained.
   */
  private function rewriteByStopId(string $file, array $neededStopIds): int {
    $count = 0;
    $cols = $this->resolveColumns($file, ['stop_id']);
    if ($cols === FALSE) {
      return $count;
    }
    $this->rewriteCsv(
      $file,
      function (array $header, array $row) use ($neededStopIds, $cols, &$count): bool {
        $stopId = (string) ($row[$cols['stop_id']] ?? '');
        if (isset($neededStopIds[$stopId])) {
          $count++;
          return TRUE;
        }
        return FALSE;
      },
    );
    return $count;
  }

  /**
   * Rewrites trips.txt keeping only valid trips.
   *
   * @param string $file
   *   Absolute path to trips.txt.
   * @param array<string, true> $validTripIds
   *   Trip IDs to keep.
   *
   * @return int
   *   Number of trip rows retained.
   */
  private function rewriteByTripId(string $file, array $validTripIds): int {
    if (!file_exists($file) || $validTripIds === []) {
      return 0;
    }
    $count = 0;
    $cols = $this->resolveColumns($file, ['trip_id']);
    if ($cols === FALSE) {
      return $count;
    }
    $this->rewriteCsv(
      $file,
      function (array $header, array $row) use ($validTripIds, $cols, &$count): bool {
        $tripId = (string) ($row[$cols['trip_id']] ?? '');
        if (isset($validTripIds[$tripId])) {
          $count++;
          return TRUE;
        }
        return FALSE;
      },
    );
    return $count;
  }

  /**
   * Scans a (already-filtered) trips.txt and collects every route_id present.
   *
   * Called after rewriteByTripId() so the file already contains only retained
   * trips; every route_id found is therefore referenced by at least one trip
   * that serves the configured area.
   *
   * @param string $file
   *   Absolute path to the (filtered) trips.txt.
   *
   * @return array<string, true>
   *   Route IDs keyed for O(1) lookup.
   */
  private function collectRouteIdsFromTrips(string $file): array {
    $routeIds = [];
    $cols = $this->resolveColumns($file, ['route_id']);
    if ($cols === FALSE) {
      return $routeIds;
    }
    $this->scanCsv($file, function (array $header, array $row) use ($cols, &$routeIds): void {
      $routeId = (string) ($row[$cols['route_id']] ?? '');
      if ($routeId !== '') {
        $routeIds[$routeId] = TRUE;
      }
    });
    return $routeIds;
  }

  /**
   * Rewrites routes.txt keeping only routes referenced by retained trips.
   *
   * @param string $file
   *   Absolute path to routes.txt.
   * @param array<string, true> $validRouteIds
   *   Route IDs to keep (from collectRouteIdsFromTrips).
   *
   * @return int
   *   Number of route rows retained.
   */
  private function rewriteByRouteId(string $file, array $validRouteIds): int {
    if (!file_exists($file) || $validRouteIds === []) {
      return 0;
    }
    $count = 0;
    $cols = $this->resolveColumns($file, ['route_id']);
    if ($cols === FALSE) {
      return $count;
    }
    $this->rewriteCsv(
      $file,
      function (array $header, array $row) use ($validRouteIds, $cols, &$count): bool {
        $routeId = (string) ($row[$cols['route_id']] ?? '');
        if (isset($validRouteIds[$routeId])) {
          $count++;
          return TRUE;
        }
        return FALSE;
      },
    );
    return $count;
  }

  /**
   * Opens a CSV file, reads the header row, and resolves column indices.
   *
   * The file is opened only to read the header; data rows are processed
   * separately by scanCsv() or rewriteCsv(). The small overhead of a second
   * fopen() is negligible compared to iterating hundreds of thousands of rows.
   *
   * @param string $file
   *   Absolute path to the CSV file.
   * @param string[] $columns
   *   Required column names to resolve.
   *
   * @return array<string, int>|false
   *   Map of column name to 0-based integer index, or FALSE if the file
   *   cannot be read or any required column is absent from the header.
   */
  private function resolveColumns(string $file, array $columns): array|false {
    if (!file_exists($file)) {
      return FALSE;
    }
    $fh = fopen($file, 'r');
    if ($fh === FALSE) {
      return FALSE;
    }
    $header = fgetcsv($fh, escape: '');
    fclose($fh);
    if (!is_array($header)) {
      return FALSE;
    }
    $indices = [];
    foreach ($columns as $col) {
      $idx = array_search($col, $header, TRUE);
      if ($idx === FALSE) {
        $this->logger->error(
          'GtfsFilter: @file is missing required column "@col".',
          ['@file' => basename($file), '@col' => $col],
        );
        return FALSE;
      }
      $indices[$col] = $idx;
    }
    return $indices;
  }

  /**
   * Scans a CSV file line-by-line without modifying it.
   *
   * @param string $file
   *   Absolute path to the CSV file.
   * @param callable $cb
   *   Callback invoked for every data row with (array $header, array $row).
   */
  private function scanCsv(string $file, callable $cb): void {
    if (!file_exists($file)) {
      return;
    }
    $fh = fopen($file, 'r');
    if ($fh === FALSE) {
      $this->logger->error('GtfsFilter: could not open @file for reading.', ['@file' => $file]);
      return;
    }
    $header = fgetcsv($fh, escape: '');
    if (!is_array($header)) {
      fclose($fh);
      return;
    }
    while (($row = fgetcsv($fh, escape: '')) !== FALSE) {
      $cb($header, $row);
    }
    fclose($fh);
  }

  /**
   * Rewrites a CSV file in-place, keeping only rows accepted by $keep.
   *
   * The header row is always preserved. Rows are processed line-by-line so
   * peak memory is proportional to a single row, not the whole file.
   *
   * @param string $file
   *   Absolute path to the CSV file.
   * @param callable $keep
   *   Callback with (array $header, array $row): bool. Return TRUE to keep.
   */
  private function rewriteCsv(string $file, callable $keep): void {
    if (!file_exists($file)) {
      return;
    }
    $tmpFile = $file . '.tmp';
    $in = fopen($file, 'r');
    $out = fopen($tmpFile, 'w');

    if ($in === FALSE || $out === FALSE) {
      if ($in !== FALSE) {
        fclose($in);
      }
      if ($out !== FALSE) {
        fclose($out);
      }
      $this->logger->error('GtfsFilter: could not open @file for rewriting.', ['@file' => $file]);
      return;
    }

    $header = fgetcsv($in, escape: '');
    if (!is_array($header)) {
      fclose($in);
      fclose($out);
      unlink($tmpFile);
      return;
    }
    fputcsv($out, $header, escape: '');

    while (($row = fgetcsv($in, escape: '')) !== FALSE) {
      if ($keep($header, $row)) {
        fputcsv($out, $row, escape: '');
      }
    }

    fclose($in);
    fclose($out);
    if (!rename($tmpFile, $file)) {
      $this->logger->error('GtfsFilter: could not rename temp file to @file.', ['@file' => $file]);
      if (!unlink($tmpFile)) {
        $this->logger->warning('GtfsFilter: could not remove temp file @file.', ['@file' => $tmpFile]);
      }
    }
  }

  /**
   * Reads the bounding box from config.
   *
   * @return array{north: float, south: float, east: float, west: float}|null
   *   NULL if no valid bounding box is configured.
   */
  private function getBoundingBox(): ?array {
    $bbox = $this->configFactory->get('localgov_bus_data.settings')->get('source.bounding_box');

    if (!is_array($bbox)
      || !isset($bbox['north'], $bbox['south'], $bbox['east'], $bbox['west'])
      ) {
      return NULL;
    }

    return [
      'north' => (float) $bbox['north'],
      'south' => (float) $bbox['south'],
      'east'  => (float) $bbox['east'],
      'west'  => (float) $bbox['west'],
    ];
  }

  /**
   * Counts the number of rows in a CSV file (including the header).
   *
   * @param string $file
   *   Absolute path to the CSV file.
   *
   * @return int
   *   Total row count including the header row.
   */
  private function countCsvRows(string $file): int {
    if (!file_exists($file)) {
      return 0;
    }
    $fh = fopen($file, 'r');
    if ($fh === FALSE) {
      return 0;
    }
    $count = 0;
    while (fgetcsv($fh, escape: '') !== FALSE) {
      $count++;
    }
    fclose($fh);
    return $count;
  }

}
