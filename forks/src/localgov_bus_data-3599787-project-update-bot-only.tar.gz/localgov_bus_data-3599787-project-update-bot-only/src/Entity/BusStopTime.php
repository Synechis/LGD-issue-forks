<?php

declare(strict_types=1);

namespace Drupal\localgov_bus_data\Entity;

use Drupal\Core\Entity\ContentEntityBase;
use Drupal\Core\Entity\EntityTypeInterface;
use Drupal\Core\Field\BaseFieldDefinition;
use Drupal\Core\StringTranslation\TranslatableMarkup;

/**
 * Defines the Bus Stop Time entity type.
 *
 * No add/edit form handlers — stop times are import-only (500k+ rows).
 *
 * @ContentEntityType(
 *   id = "localgov_bus_stop_time",
 *   label = @Translation("Bus Stop Time"),
 *   label_collection = @Translation("Bus Stop Times"),
 *   base_table = "localgov_bus_stop_time",
 *   field_ui_base_route = "localgov_bus_data.structure.bus_stop_time",
 *   admin_permission = "administer localgov bus data",
 *   handlers = {
 *     "access" = "Drupal\localgov_bus_data\Entity\BusDataEntityAccessControlHandler",
 *     "views_data" = "Drupal\views\EntityViewsData",
 *     "list_builder" = "Drupal\localgov_bus_data\Entity\BusStopTimeListBuilder",
 *     "form" = {
 *       "delete" = "Drupal\Core\Entity\ContentEntityDeleteForm",
 *     },
 *     "route_provider" = {
 *       "html" = "Drupal\Core\Entity\Routing\AdminHtmlRouteProvider",
 *     },
 *   },
 *   entity_keys = {
 *     "id" = "id",
 *     "uuid" = "uuid",
 *     "label" = "bustimes_departure_time",
 *   },
 *   links = {
 *     "collection" = "/admin/content/bus-data/stop-times",
 *     "canonical" = "/admin/content/bus-data/stop-time/{localgov_bus_stop_time}",
 *     "delete-form" = "/admin/content/bus-data/stop-time/{localgov_bus_stop_time}/delete",
 *   },
 * )
 */
final class BusStopTime extends ContentEntityBase {

  /**
   * {@inheritdoc}
   */
  public static function baseFieldDefinitions(
    EntityTypeInterface $entity_type,
  ): array {
    $fields = parent::baseFieldDefinitions($entity_type);

    $fields['bustimes_trip_id'] = BaseFieldDefinition::create('entity_reference')
      ->setLabel(new TranslatableMarkup('Trip'))
      ->setDescription(new TranslatableMarkup('The trip this stop time belongs to.'))
      ->setSetting('target_type', 'localgov_bus_trip')
      ->setDisplayConfigurable('form', TRUE)
      ->setDisplayConfigurable('view', TRUE);

    $fields['bustimes_stop_id'] = BaseFieldDefinition::create('entity_reference')
      ->setLabel(new TranslatableMarkup('Stop'))
      ->setDescription(new TranslatableMarkup('The stop being called at.'))
      ->setSetting('target_type', 'localgov_bus_stop')
      ->setDisplayConfigurable('form', TRUE)
      ->setDisplayConfigurable('view', TRUE);

    $fields['bustimes_arrival_time'] = BaseFieldDefinition::create('string')
      ->setLabel(new TranslatableMarkup('Arrival Time'))
      ->setDescription(
        new TranslatableMarkup('Scheduled arrival time (HH:MM:SS).')
      )
      ->setSetting('max_length', 8)
      ->setDisplayConfigurable('form', TRUE)
      ->setDisplayConfigurable('view', TRUE);

    $fields['bustimes_departure_time'] = BaseFieldDefinition::create('string')
      ->setLabel(new TranslatableMarkup('Departure Time'))
      ->setDescription(
        new TranslatableMarkup('Scheduled departure time (HH:MM:SS).')
      )
      ->setSetting('max_length', 8)
      ->setDisplayConfigurable('form', TRUE)
      ->setDisplayConfigurable('view', TRUE);

    $fields['bustimes_stop_sequence'] = BaseFieldDefinition::create('integer')
      ->setLabel(new TranslatableMarkup('Stop Sequence'))
      ->setDescription(
        new TranslatableMarkup('Order of this stop within the trip.')
      )
      ->setDisplayConfigurable('form', TRUE)
      ->setDisplayConfigurable('view', TRUE);

    return $fields;
  }

}
