<?php

declare(strict_types=1);

namespace Drupal\localgov_bus_data\Entity;

use Drupal\Core\Entity\EntityInterface;

/**
 * List builder for bus stops.
 */
final class BusStopListBuilder extends BusDataEntityListBuilder {

  /**
   * {@inheritdoc}
   */
  public function buildHeader(): array {
    $header['atco_code'] = $this->t('ATCO code');
    $header['stop_name'] = $this->t('Stop name');
    $header['lat'] = $this->t('Lat');
    $header['lon'] = $this->t('Lon');
    $header['wheelchair'] = $this->t('Wheelchair');

    return $header + parent::buildHeader();
  }

  /**
   * {@inheritdoc}
   */
  public function buildRow(EntityInterface $entity): array {
    assert($entity instanceof BusStop);

    $row['atco_code'] = ['data' => ['#plain_text' => $entity->get('bustimes_stop_id')->value]];
    $row['stop_name'] = ['data' => ['#plain_text' => $entity->get('bustimes_stop_name')->value]];
    $row['lat'] = ['data' => ['#plain_text' => $entity->get('bustimes_stop_lat')->value]];
    $row['lon'] = ['data' => ['#plain_text' => $entity->get('bustimes_stop_lon')->value]];
    $row['wheelchair'] = ['data' => ['#plain_text' => $entity->get('bustimes_wheelchair_boarding')->value]];

    return $row + parent::buildRow($entity);
  }

}
