<?php

declare(strict_types=1);

namespace Drupal\localgov_bus_data\Entity;

use Drupal\Core\Entity\EntityInterface;

/**
 * List builder for bus trips.
 */
final class BusTripListBuilder extends BusDataEntityListBuilder {

  /**
   * {@inheritdoc}
   */
  public function buildHeader(): array {
    $header['trip_id'] = $this->t('Trip ID');
    $header['route'] = $this->t('Route');
    $header['headsign'] = $this->t('Headsign');
    $header['direction'] = $this->t('Direction');

    return $header + parent::buildHeader();
  }

  /**
   * {@inheritdoc}
   */
  public function buildRow(EntityInterface $entity): array {
    assert($entity instanceof BusTrip);

    $row['trip_id'] = ['data' => ['#plain_text' => $entity->get('bustimes_trip_id')->value]];

    $route = $entity->get('bustimes_route_id')->entity;
    $row['route'] = ['data' => ['#plain_text' => $route ? $route->label() : '']];

    $row['headsign'] = ['data' => ['#plain_text' => $entity->get('bustimes_trip_headsign')->value]];

    $direction_value = (int) $entity->get('bustimes_direction_id')->value;
    $row['direction'] = [
      'data' => [
        '#plain_text' => match ($direction_value) {
          0 => $this->t('Outbound'),
          1 => $this->t('Inbound'),
          default => (string) $direction_value,
        },
      ],
    ];

    return $row + parent::buildRow($entity);
  }

}
