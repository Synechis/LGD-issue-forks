<?php

declare(strict_types=1);

namespace Drupal\localgov_bus_data\Entity;

use Drupal\Core\Entity\EntityInterface;

/**
 * List builder for bus calendars.
 */
final class BusCalendarListBuilder extends BusDataEntityListBuilder {

  /**
   * {@inheritdoc}
   */
  public function buildHeader(): array {
    $header['service_id'] = $this->t('Service ID');
    $header['days'] = $this->t('Days');
    $header['start'] = $this->t('Start');
    $header['end'] = $this->t('End');

    return $header + parent::buildHeader();
  }

  /**
   * {@inheritdoc}
   */
  public function buildRow(EntityInterface $entity): array {
    assert($entity instanceof BusCalendar);

    $row['service_id'] = ['data' => ['#plain_text' => $entity->get('bustimes_service_id')->value]];

    $day_letters = [
      'M' => 'bustimes_monday',
      'Tu' => 'bustimes_tuesday',
      'W' => 'bustimes_wednesday',
      'Th' => 'bustimes_thursday',
      'F' => 'bustimes_friday',
      'Sa' => 'bustimes_saturday',
      'Su' => 'bustimes_sunday',
    ];

    $days = [];
    foreach ($day_letters as $label => $field_name) {
      $days[] = $entity->get($field_name)->value ? $label : '–';
    }
    $row['days'] = ['data' => ['#plain_text' => implode(' ', $days)]];

    $row['start'] = ['data' => ['#plain_text' => $entity->get('bustimes_start_date')->value]];
    $row['end'] = ['data' => ['#plain_text' => $entity->get('bustimes_end_date')->value]];

    return $row + parent::buildRow($entity);
  }

}
