<?php

declare(strict_types=1);

namespace Drupal\localgov_bus_data\Entity;

use Drupal\Core\Entity\ContentEntityBase;
use Drupal\Core\Entity\EntityTypeInterface;
use Drupal\Core\Field\BaseFieldDefinition;
use Drupal\Core\StringTranslation\TranslatableMarkup;

/**
 * Defines the Bus Calendar entity type.
 *
 * @ContentEntityType(
 *   id = "localgov_bus_calendar",
 *   label = @Translation("Bus Calendar"),
 *   label_collection = @Translation("Bus Calendars"),
 *   base_table = "localgov_bus_calendar",
 *   field_ui_base_route = "localgov_bus_data.structure.bus_calendar",
 *   admin_permission = "administer localgov bus data",
 *   handlers = {
 *     "access" = "Drupal\localgov_bus_data\Entity\BusDataEntityAccessControlHandler",
 *     "views_data" = "Drupal\views\EntityViewsData",
 *     "list_builder" = "Drupal\localgov_bus_data\Entity\BusCalendarListBuilder",
 *     "form" = {
 *       "add" = "Drupal\Core\Entity\ContentEntityForm",
 *       "edit" = "Drupal\Core\Entity\ContentEntityForm",
 *       "delete" = "Drupal\Core\Entity\ContentEntityDeleteForm",
 *     },
 *     "route_provider" = {
 *       "html" = "Drupal\Core\Entity\Routing\AdminHtmlRouteProvider",
 *     },
 *   },
 *   entity_keys = {
 *     "id" = "id",
 *     "uuid" = "uuid",
 *     "label" = "bustimes_service_id",
 *   },
 *   links = {
 *     "collection" = "/admin/content/bus-data/calendars",
 *     "canonical" = "/admin/content/bus-data/calendar/{localgov_bus_calendar}",
 *     "add-form" = "/admin/content/bus-data/calendar/add",
 *     "edit-form" = "/admin/content/bus-data/calendar/{localgov_bus_calendar}/edit",
 *     "delete-form" = "/admin/content/bus-data/calendar/{localgov_bus_calendar}/delete",
 *   },
 * )
 */
final class BusCalendar extends ContentEntityBase {

  /**
   * {@inheritdoc}
   */
  public static function baseFieldDefinitions(
    EntityTypeInterface $entity_type,
  ): array {
    $fields = parent::baseFieldDefinitions($entity_type);

    $fields['bustimes_service_id'] = BaseFieldDefinition::create('string')
      ->setLabel(new TranslatableMarkup('Service ID'))
      ->setDescription(new TranslatableMarkup('GTFS service identifier.'))
      ->setRequired(TRUE)
      ->setSetting('max_length', 255)
      ->setDisplayConfigurable('form', TRUE)
      ->setDisplayConfigurable('view', TRUE);

    foreach ([
      'monday' => new TranslatableMarkup('Monday'),
      'tuesday' => new TranslatableMarkup('Tuesday'),
      'wednesday' => new TranslatableMarkup('Wednesday'),
      'thursday' => new TranslatableMarkup('Thursday'),
      'friday' => new TranslatableMarkup('Friday'),
      'saturday' => new TranslatableMarkup('Saturday'),
      'sunday' => new TranslatableMarkup('Sunday'),
    ] as $day => $label) {
      $fields["bustimes_{$day}"] = BaseFieldDefinition::create('boolean')
        ->setLabel($label)
        ->setDefaultValue(FALSE)
        ->setDisplayConfigurable('form', TRUE)
        ->setDisplayConfigurable('view', TRUE);
    }

    $fields['bustimes_weekday'] = BaseFieldDefinition::create('boolean')
      ->setLabel(new TranslatableMarkup('Runs on a Weekday'))
      ->setDescription(
        new TranslatableMarkup('TRUE if the service runs on any weekday (Mon–Fri). Populated post-import.')
      )
      ->setRequired(FALSE)
      ->setDefaultValue(FALSE)
      ->setDisplayConfigurable('form', TRUE)
      ->setDisplayConfigurable('view', TRUE);

    $fields['bustimes_start_date'] = BaseFieldDefinition::create('datetime')
      ->setLabel(new TranslatableMarkup('Start Date'))
      ->setDescription(new TranslatableMarkup('Service validity start date.'))
      ->setSetting('datetime_type', 'date')
      ->setDisplayConfigurable('form', TRUE)
      ->setDisplayConfigurable('view', TRUE);

    $fields['bustimes_end_date'] = BaseFieldDefinition::create('datetime')
      ->setLabel(new TranslatableMarkup('End Date'))
      ->setDescription(new TranslatableMarkup('Service validity end date.'))
      ->setSetting('datetime_type', 'date')
      ->setDisplayConfigurable('form', TRUE)
      ->setDisplayConfigurable('view', TRUE);

    return $fields;
  }

}
