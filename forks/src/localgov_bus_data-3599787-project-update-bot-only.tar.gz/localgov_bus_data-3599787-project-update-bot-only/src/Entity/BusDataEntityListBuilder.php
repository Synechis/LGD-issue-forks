<?php

declare(strict_types=1);

namespace Drupal\localgov_bus_data\Entity;

use Drupal\Core\Entity\EntityListBuilder;

/**
 * Base list builder for bus data entities.
 */
abstract class BusDataEntityListBuilder extends EntityListBuilder {

  /**
   * {@inheritdoc}
   *
   * Default pager limit for bus data admin lists.
   */
  protected $limit = 50;

}
