<?php

declare(strict_types=1);

namespace Drupal\localgov_bus_data\Entity;

use Drupal\Core\Entity\ContentEntityBase;
use Drupal\Core\Entity\EntityTypeInterface;
use Drupal\Core\Field\BaseFieldDefinition;
use Drupal\Core\StringTranslation\TranslatableMarkup;

/**
 * Defines the Bus Route entity type.
 *
 * @ContentEntityType(
 *   id = "localgov_bus_route",
 *   label = @Translation("Bus Route"),
 *   label_collection = @Translation("Bus Routes"),
 *   base_table = "localgov_bus_route",
 *   field_ui_base_route = "localgov_bus_data.structure.bus_route",
 *   admin_permission = "administer localgov bus data",
 *   handlers = {
 *     "access" = "Drupal\localgov_bus_data\Entity\BusDataEntityAccessControlHandler",
 *     "views_data" = "Drupal\views\EntityViewsData",
 *     "list_builder" = "Drupal\localgov_bus_data\Entity\BusRouteListBuilder",
 *     "form" = {
 *       "add" = "Drupal\Core\Entity\ContentEntityForm",
 *       "edit" = "Drupal\Core\Entity\ContentEntityForm",
 *       "delete" = "Drupal\Core\Entity\ContentEntityDeleteForm",
 *     },
 *     "route_provider" = {
 *       "html" = "Drupal\Core\Entity\Routing\AdminHtmlRouteProvider",
 *     },
 *   },
 *   entity_keys = {
 *     "id" = "id",
 *     "uuid" = "uuid",
 *     "label" = "bustimes_route_short_name",
 *   },
 *   links = {
 *     "collection" = "/admin/content/bus-data/routes",
 *     "canonical" = "/admin/content/bus-data/route/{localgov_bus_route}",
 *     "add-form" = "/admin/content/bus-data/route/add",
 *     "edit-form" = "/admin/content/bus-data/route/{localgov_bus_route}/edit",
 *     "delete-form" = "/admin/content/bus-data/route/{localgov_bus_route}/delete",
 *   },
 * )
 */
final class BusRoute extends ContentEntityBase {

  /**
   * {@inheritdoc}
   */
  public static function baseFieldDefinitions(
    EntityTypeInterface $entity_type,
  ): array {
    $fields = parent::baseFieldDefinitions($entity_type);

    $fields['bustimes_route_id'] = BaseFieldDefinition::create('string')
      ->setLabel(new TranslatableMarkup('Route ID'))
      ->setDescription(new TranslatableMarkup('GTFS route identifier.'))
      ->setRequired(TRUE)
      ->setSetting('max_length', 255)
      ->setDisplayConfigurable('form', TRUE)
      ->setDisplayConfigurable('view', TRUE);

    $fields['bustimes_route_short_name'] = BaseFieldDefinition::create('string')
      ->setLabel(new TranslatableMarkup('Short Name'))
      ->setDescription(
        new TranslatableMarkup('Short route name, e.g. "685".')
      )
      ->setSetting('max_length', 100)
      ->setDisplayConfigurable('form', TRUE)
      ->setDisplayConfigurable('view', TRUE);

    $fields['bustimes_route_long_name'] = BaseFieldDefinition::create('string')
      ->setLabel(new TranslatableMarkup('Long Name'))
      ->setDescription(
        new TranslatableMarkup('Full route name, e.g. "Carlisle \u2013 Newcastle".')
      )
      ->setSetting('max_length', 255)
      ->setDisplayConfigurable('form', TRUE)
      ->setDisplayConfigurable('view', TRUE);

    $fields['bustimes_agency_id'] = BaseFieldDefinition::create('string')
      ->setLabel(new TranslatableMarkup('Agency ID'))
      ->setDescription(new TranslatableMarkup('Operator code, e.g. "ARBA".'))
      ->setSetting('max_length', 100)
      ->setDisplayConfigurable('form', TRUE)
      ->setDisplayConfigurable('view', TRUE);

    $fields['bustimes_route_type'] = BaseFieldDefinition::create('integer')
      ->setLabel(new TranslatableMarkup('Route Type'))
      ->setDescription(new TranslatableMarkup('GTFS route type; 3 = bus.'))
      ->setDisplayConfigurable('form', TRUE)
      ->setDisplayConfigurable('view', TRUE);

    $fields['bustimes_headsign'] = BaseFieldDefinition::create('string')
      ->setLabel(new TranslatableMarkup('Headsign'))
      ->setDescription(
        new TranslatableMarkup('Representative outbound destination, e.g. "Newcastle".')
      )
      ->setSetting('max_length', 255)
      ->setDisplayConfigurable('form', TRUE)
      ->setDisplayConfigurable('view', TRUE);

    $fields['bustimes_headsign_inbound'] = BaseFieldDefinition::create('string')
      ->setLabel(new TranslatableMarkup('Headsign (Inbound)'))
      ->setDescription(
        new TranslatableMarkup('Representative inbound destination, e.g. "Carlisle".')
      )
      ->setSetting('max_length', 255)
      ->setDisplayConfigurable('form', TRUE)
      ->setDisplayConfigurable('view', TRUE);

    return $fields;
  }

}
