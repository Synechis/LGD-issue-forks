<?php

declare(strict_types=1);

namespace Drupal\localgov_bus_data\Entity;

use Drupal\Core\Entity\ContentEntityBase;
use Drupal\Core\Entity\EntityTypeInterface;
use Drupal\Core\Field\BaseFieldDefinition;
use Drupal\Core\StringTranslation\TranslatableMarkup;

/**
 * Defines the Bus Trip entity type.
 *
 * @ContentEntityType(
 *   id = "localgov_bus_trip",
 *   label = @Translation("Bus Trip"),
 *   label_collection = @Translation("Bus Trips"),
 *   base_table = "localgov_bus_trip",
 *   field_ui_base_route = "localgov_bus_data.structure.bus_trip",
 *   admin_permission = "administer localgov bus data",
 *   handlers = {
 *     "access" = "Drupal\localgov_bus_data\Entity\BusDataEntityAccessControlHandler",
 *     "views_data" = "Drupal\views\EntityViewsData",
 *     "list_builder" = "Drupal\localgov_bus_data\Entity\BusTripListBuilder",
 *     "form" = {
 *       "add" = "Drupal\Core\Entity\ContentEntityForm",
 *       "edit" = "Drupal\Core\Entity\ContentEntityForm",
 *       "delete" = "Drupal\Core\Entity\ContentEntityDeleteForm",
 *     },
 *     "route_provider" = {
 *       "html" = "Drupal\Core\Entity\Routing\AdminHtmlRouteProvider",
 *     },
 *   },
 *   entity_keys = {
 *     "id" = "id",
 *     "uuid" = "uuid",
 *     "label" = "bustimes_trip_headsign",
 *   },
 *   links = {
 *     "collection" = "/admin/content/bus-data/trips",
 *     "canonical" = "/admin/content/bus-data/trip/{localgov_bus_trip}",
 *     "add-form" = "/admin/content/bus-data/trip/add",
 *     "edit-form" = "/admin/content/bus-data/trip/{localgov_bus_trip}/edit",
 *     "delete-form" = "/admin/content/bus-data/trip/{localgov_bus_trip}/delete",
 *   },
 * )
 */
final class BusTrip extends ContentEntityBase {

  /**
   * {@inheritdoc}
   */
  public static function baseFieldDefinitions(
    EntityTypeInterface $entity_type,
  ): array {
    $fields = parent::baseFieldDefinitions($entity_type);

    $fields['bustimes_trip_id'] = BaseFieldDefinition::create('string')
      ->setLabel(new TranslatableMarkup('Trip ID'))
      ->setDescription(new TranslatableMarkup('GTFS trip identifier.'))
      ->setRequired(TRUE)
      ->setSetting('max_length', 255)
      ->setDisplayConfigurable('form', TRUE)
      ->setDisplayConfigurable('view', TRUE);

    $fields['bustimes_route_id'] = BaseFieldDefinition::create('entity_reference')
      ->setLabel(new TranslatableMarkup('Route'))
      ->setDescription(new TranslatableMarkup('The bus route this trip belongs to.'))
      ->setSetting('target_type', 'localgov_bus_route')
      ->setDisplayConfigurable('form', TRUE)
      ->setDisplayConfigurable('view', TRUE);

    $fields['bustimes_service_id'] = BaseFieldDefinition::create('entity_reference')
      ->setLabel(new TranslatableMarkup('Calendar'))
      ->setDescription(
        new TranslatableMarkup('The service calendar defining operating days.')
      )
      ->setSetting('target_type', 'localgov_bus_calendar')
      ->setDisplayConfigurable('form', TRUE)
      ->setDisplayConfigurable('view', TRUE);

    $fields['bustimes_direction_id'] = BaseFieldDefinition::create('integer')
      ->setLabel(new TranslatableMarkup('Direction'))
      ->setDescription(
        new TranslatableMarkup('0 = outbound, 1 = inbound.')
      )
      ->setDisplayConfigurable('form', TRUE)
      ->setDisplayConfigurable('view', TRUE);

    $fields['bustimes_trip_headsign'] = BaseFieldDefinition::create('string')
      ->setLabel(new TranslatableMarkup('Headsign'))
      ->setDescription(
        new TranslatableMarkup('Destination display text, e.g. "Newcastle".')
      )
      ->setSetting('max_length', 255)
      ->setDisplayConfigurable('form', TRUE)
      ->setDisplayConfigurable('view', TRUE);

    return $fields;
  }

}
