<?php

declare(strict_types=1);

namespace Drupal\localgov_bus_data\Entity;

use Drupal\Core\Entity\EntityInterface;

/**
 * List builder for bus stop times.
 */
final class BusStopTimeListBuilder extends BusDataEntityListBuilder {

  /**
   * {@inheritdoc}
   *
   * Stop times lists are shorter for usability.
   */
  protected $limit = 25;

  /**
   * {@inheritdoc}
   */
  public function buildHeader(): array {
    $header['trip'] = $this->t('Trip');
    $header['stop'] = $this->t('Stop');
    $header['departure'] = $this->t('Departure');
    $header['sequence'] = $this->t('Sequence');

    return $header + parent::buildHeader();
  }

  /**
   * {@inheritdoc}
   */
  public function buildRow(EntityInterface $entity): array {
    assert($entity instanceof BusStopTime);

    $trip = $entity->get('bustimes_trip_id')->entity;
    $row['trip'] = ['data' => ['#plain_text' => $trip ? $trip->label() : '']];

    $stop = $entity->get('bustimes_stop_id')->entity;
    $row['stop'] = ['data' => ['#plain_text' => $stop ? $stop->label() : '']];

    $row['departure'] = ['data' => ['#plain_text' => $entity->get('bustimes_departure_time')->value]];
    $row['sequence'] = ['data' => ['#plain_text' => $entity->get('bustimes_stop_sequence')->value]];

    return $row + parent::buildRow($entity);
  }

}
