<?php

declare(strict_types=1);

namespace Drupal\localgov_bus_data\Entity;

use Drupal\Core\Entity\EntityInterface;

/**
 * List builder for bus routes.
 */
final class BusRouteListBuilder extends BusDataEntityListBuilder {

  /**
   * {@inheritdoc}
   */
  public function buildHeader(): array {
    $header['route'] = $this->t('Route');
    $header['long_name'] = $this->t('Long name');
    $header['operator'] = $this->t('Operator');
    $header['type'] = $this->t('Type');

    return $header + parent::buildHeader();
  }

  /**
   * {@inheritdoc}
   */
  public function buildRow(EntityInterface $entity): array {
    assert($entity instanceof BusRoute);

    $row['route'] = ['data' => ['#plain_text' => $entity->get('bustimes_route_short_name')->value]];
    $row['long_name'] = ['data' => ['#plain_text' => $entity->get('bustimes_route_long_name')->value]];
    $row['operator'] = ['data' => ['#plain_text' => $entity->get('bustimes_agency_id')->value]];
    $row['type'] = ['data' => ['#plain_text' => $entity->get('bustimes_route_type')->value]];

    return $row + parent::buildRow($entity);
  }

}
