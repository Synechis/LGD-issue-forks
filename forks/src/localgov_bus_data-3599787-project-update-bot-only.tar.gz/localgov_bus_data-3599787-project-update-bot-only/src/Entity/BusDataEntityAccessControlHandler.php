<?php

declare(strict_types=1);

namespace Drupal\localgov_bus_data\Entity;

use Drupal\Core\Access\AccessResult;
use Drupal\Core\Access\AccessResultInterface;
use Drupal\Core\Entity\EntityAccessControlHandler;
use Drupal\Core\Entity\EntityInterface;
use Drupal\Core\Session\AccountInterface;

/**
 * Access control handler shared by all localgov_bus_data entity types.
 *
 * Grants access based on per-entity-type CRUD permissions, with
 * "administer localgov bus data" as a bypass-all fallback.
 */
final class BusDataEntityAccessControlHandler extends EntityAccessControlHandler {

  /**
   * {@inheritdoc}
   */
  protected function checkAccess(EntityInterface $entity, $operation, AccountInterface $account): AccessResultInterface {
    if ($operation === 'delete' && $entity->isNew()) {
      return AccessResult::forbidden()->addCacheableDependency($entity);
    }

    if ($account->hasPermission('administer localgov bus data')) {
      return AccessResult::allowed()->cachePerPermissions();
    }

    $entity_type_id = $entity->getEntityTypeId();
    $permission = match ($operation) {
      'view', 'view label' => "view {$entity_type_id} entities",
      'update' => "edit {$entity_type_id} entities",
      'delete' => "delete {$entity_type_id} entities",
      default => NULL,
    };

    if ($permission === NULL) {
      return AccessResult::neutral()->cachePerPermissions();
    }

    return AccessResult::allowedIfHasPermission($account, $permission);
  }

  /**
   * {@inheritdoc}
   */
  protected function checkCreateAccess(AccountInterface $account, array $context, $entity_bundle = NULL): AccessResultInterface {
    if ($account->hasPermission('administer localgov bus data')) {
      return AccessResult::allowed()->cachePerPermissions();
    }

    $entity_type_id = $this->entityTypeId;

    return AccessResult::allowedIfHasPermission($account, "create {$entity_type_id} entities");
  }

}
