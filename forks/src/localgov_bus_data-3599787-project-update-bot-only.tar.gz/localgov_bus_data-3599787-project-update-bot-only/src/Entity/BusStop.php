<?php

declare(strict_types=1);

namespace Drupal\localgov_bus_data\Entity;

use Drupal\Core\Entity\ContentEntityBase;
use Drupal\Core\Entity\EntityTypeInterface;
use Drupal\Core\Field\BaseFieldDefinition;
use Drupal\Core\StringTranslation\TranslatableMarkup;

/**
 * Defines the Bus Stop entity type.
 *
 * @ContentEntityType(
 *   id = "localgov_bus_stop",
 *   label = @Translation("Bus Stop"),
 *   label_collection = @Translation("Bus Stops"),
 *   base_table = "localgov_bus_stop",
 *   field_ui_base_route = "localgov_bus_data.structure.bus_stop",
 *   admin_permission = "administer localgov bus data",
 *   handlers = {
 *     "access" = "Drupal\localgov_bus_data\Entity\BusDataEntityAccessControlHandler",
 *     "views_data" = "Drupal\views\EntityViewsData",
 *     "list_builder" = "Drupal\localgov_bus_data\Entity\BusStopListBuilder",
 *     "form" = {
 *       "add" = "Drupal\Core\Entity\ContentEntityForm",
 *       "edit" = "Drupal\Core\Entity\ContentEntityForm",
 *       "delete" = "Drupal\Core\Entity\ContentEntityDeleteForm",
 *     },
 *     "route_provider" = {
 *       "html" = "Drupal\Core\Entity\Routing\AdminHtmlRouteProvider",
 *     },
 *   },
 *   entity_keys = {
 *     "id" = "id",
 *     "uuid" = "uuid",
 *     "label" = "bustimes_stop_name",
 *   },
 *   links = {
 *     "collection" = "/admin/content/bus-data/stops",
 *     "canonical" = "/admin/content/bus-data/stop/{localgov_bus_stop}",
 *     "add-form" = "/admin/content/bus-data/stop/add",
 *     "edit-form" = "/admin/content/bus-data/stop/{localgov_bus_stop}/edit",
 *     "delete-form" = "/admin/content/bus-data/stop/{localgov_bus_stop}/delete",
 *   },
 * )
 */
final class BusStop extends ContentEntityBase {

  /**
   * {@inheritdoc}
   */
  public static function baseFieldDefinitions(
    EntityTypeInterface $entity_type,
  ): array {
    $fields = parent::baseFieldDefinitions($entity_type);

    $fields['bustimes_stop_id'] = BaseFieldDefinition::create('string')
      ->setLabel(new TranslatableMarkup('Stop ID'))
      ->setDescription(new TranslatableMarkup('ATCO stop code.'))
      ->setRequired(TRUE)
      ->setSetting('max_length', 255)
      ->setDisplayConfigurable('form', TRUE)
      ->setDisplayConfigurable('view', TRUE);

    $fields['bustimes_stop_name'] = BaseFieldDefinition::create('string')
      ->setLabel(new TranslatableMarkup('Stop Name'))
      ->setDescription(
        new TranslatableMarkup('Stop name, e.g. "Carlisle Bus Station".')
      )
      ->setRequired(TRUE)
      ->setSetting('max_length', 255)
      ->setDisplayConfigurable('form', TRUE)
      ->setDisplayConfigurable('view', TRUE);

    $fields['bustimes_stop_lat'] = BaseFieldDefinition::create('decimal')
      ->setLabel(new TranslatableMarkup('Latitude'))
      ->setDescription(new TranslatableMarkup('WGS84 latitude.'))
      ->setSetting('precision', 10)
      ->setSetting('scale', 7)
      ->setDisplayConfigurable('form', TRUE)
      ->setDisplayConfigurable('view', TRUE);

    $fields['bustimes_stop_lon'] = BaseFieldDefinition::create('decimal')
      ->setLabel(new TranslatableMarkup('Longitude'))
      ->setDescription(new TranslatableMarkup('WGS84 longitude.'))
      ->setSetting('precision', 10)
      ->setSetting('scale', 7)
      ->setDisplayConfigurable('form', TRUE)
      ->setDisplayConfigurable('view', TRUE);

    $fields['bustimes_location'] = BaseFieldDefinition::create('geofield')
      ->setLabel(new TranslatableMarkup('Location'))
      ->setDescription(
        new TranslatableMarkup('Stop location as WKT POINT geometry, derived from lat/lon during import.')
      )
      ->setRequired(FALSE)
      ->setDisplayConfigurable('form', TRUE)
      ->setDisplayConfigurable('view', TRUE);

    $fields['bustimes_wheelchair_boarding'] = BaseFieldDefinition::create('integer')
      ->setLabel(new TranslatableMarkup('Wheelchair Boarding'))
      ->setDescription(
        new TranslatableMarkup('0 = no info, 1 = accessible, 2 = not accessible.')
      )
      ->setDisplayConfigurable('form', TRUE)
      ->setDisplayConfigurable('view', TRUE);

    $fields['bustimes_services'] = BaseFieldDefinition::create('string_long')
      ->setLabel(new TranslatableMarkup('Services'))
      ->setDescription(
        new TranslatableMarkup('Comma-separated list of route short names serving this stop, e.g. "63, 63A, X60". Populated post-import.')
      )
      ->setRequired(FALSE)
      ->setDisplayConfigurable('form', TRUE)
      ->setDisplayConfigurable('view', TRUE);

    $fields['bustimes_indicator'] = BaseFieldDefinition::create('string')
      ->setLabel(new TranslatableMarkup('Indicator'))
      ->setDescription(
        new TranslatableMarkup('Stop position relative to road, e.g. "opp" (opposite), "adj" (adjacent), "nr" (near). From NaPTAN.')
      )
      ->setRequired(FALSE)
      ->setSetting('max_length', 64)
      ->setDisplayConfigurable('form', TRUE)
      ->setDisplayConfigurable('view', TRUE);

    $fields['bustimes_street'] = BaseFieldDefinition::create('string')
      ->setLabel(new TranslatableMarkup('Street'))
      ->setDescription(new TranslatableMarkup('Street name for the stop. From NaPTAN.'))
      ->setRequired(FALSE)
      ->setSetting('max_length', 255)
      ->setDisplayConfigurable('form', TRUE)
      ->setDisplayConfigurable('view', TRUE);

    $fields['bustimes_locality'] = BaseFieldDefinition::create('string')
      ->setLabel(new TranslatableMarkup('Locality'))
      ->setDescription(new TranslatableMarkup('Locality or town name for the stop. From NaPTAN.'))
      ->setRequired(FALSE)
      ->setSetting('max_length', 255)
      ->setDisplayConfigurable('form', TRUE)
      ->setDisplayConfigurable('view', TRUE);

    return $fields;
  }

}
