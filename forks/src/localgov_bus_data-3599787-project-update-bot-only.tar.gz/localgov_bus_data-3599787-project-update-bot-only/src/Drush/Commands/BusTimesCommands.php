<?php

declare(strict_types=1);

namespace Drupal\localgov_bus_data\Drush\Commands;

use Drupal\Core\Entity\EntityTypeManagerInterface;
use Drupal\localgov_bus_data\Service\GtfsImportService;
use Drush\Attributes as CLI;
use Drush\Commands\DrushCommands;

/**
 * Drush commands for LocalGov Bus Data.
 */
final class BusTimesCommands extends DrushCommands {

  public function __construct(
    private readonly GtfsImportService $importService,
    private readonly EntityTypeManagerInterface $entityTypeManager,
  ) {
    parent::__construct();
  }

  /**
   * Imports bus timetable data into Drupal entities via Migrate.
   */
  #[CLI\Command(name: 'bus-times:import', aliases: ['bti'])]
  #[CLI\Option(name: 'dry-run', description: 'Show what would be imported without downloading or writing.')]
  #[CLI\Option(name: 'full', description: 'Force a full truncate-and-reimport, ignoring incremental state.')]
  #[CLI\Usage(name: 'drush bus-times:import', description: 'Run an incremental GTFS timetable import (add/update/delete).')]
  #[CLI\Usage(name: 'drush bus-times:import --full', description: 'Force full truncate-and-reimport, discarding change-detection state.')]
  #[CLI\Usage(name: 'drush bus-times:import --dry-run', description: 'Dry-run only; no writes.')]
  public function import(array $options = ['dry-run' => FALSE, 'full' => FALSE]): void {
    $this->importService->run(
      (bool) ($options['dry-run'] ?? FALSE),
      !(bool) ($options['full'] ?? FALSE),
    );
  }

  /**
   * Seeds minimal test data for local development.
   *
   * Inserts 5 routes, ~26 stops, 3 calendars, ~40 trips, and ~200 stop times.
   * All inserts are idempotent — existing records are skipped so the
   * command is safe to re-run.
   */
  #[CLI\Command(name: 'bus-times:seed', aliases: ['bts'])]
  #[CLI\Help(description: 'Insert minimal test fixture data into bus entity tables.')]
  public function seed(): void {
    $storage = fn(string $type) => $this->entityTypeManager->getStorage($type);

    $seedStartDate = date('Y') . '-01-01';
    $seedEndDate   = date('Y') . '-12-31';

    $stopDefs = [
      ['0820AYC10039', 'Carlisle Bus Station', 54.8946000, -2.9374000, 1],
      ['0820AYE10212', 'Carlisle, Lowther Street', 54.8942000, -2.9290000, 1],
      ['0820AYE10108', 'Carlisle, Court Square', 54.8937000, -2.9334000, 0],
      ['0820AYE10050', 'Carlisle, Botchergate', 54.8898000, -2.9310000, 1],
      ['0820ACF10081', 'Gilsland, The Howard Arms', 54.9857000, -2.5778000, 0],
      ['0810GHT20001', 'Penrith, Middlegate', 54.6640000, -2.7553000, 1],
      ['0901001', 'Carlisle, Carlisle Station', 54.8954000, -2.9405000, 2],
      ['0901002', 'Carlisle, Kingstown Road', 54.8825000, -2.9499000, 0],
      ['0901003', 'Carlisle, Warwick Road', 54.8966000, -2.9326000, 1],
      ['0901004', 'Carlisle, Botcherby Drive', 54.9052000, -2.9098000, 1],
      ['0902001', 'Workington, Market Street', 54.6423000, -3.5478000, 1],
      ['0902002', 'Workington, Rail Station', 54.6437000, -3.5446000, 2],
      ['0902003', 'Workington, Lowca Road', 54.6535000, -3.5289000, 0],
      ['0902004', 'Workington, Princess Street', 54.6349000, -3.5864000, 1],
      ['0903001', 'Whitehaven, Market Place', 54.5306000, -3.5643000, 0],
      ['0903002', 'Whitehaven, Station Road', 54.5349000, -3.5632000, 2],
      ['0903003', 'Whitehaven, Spencer Street', 54.5284000, -3.5809000, 1],
      ['0903004', 'Whitehaven, Harbour View', 54.5367000, -3.5961000, 0],
      ['0904001', 'Penrith, King Street', 54.6668000, -2.7509000, 1],
      ['0904002', 'Penrith, Rail Station', 54.6629000, -2.7437000, 2],
      ['0904003', 'Penrith, High Street', 54.6644000, -2.7544000, 0],
      ['0904004', 'Penrith, Lowther Street', 54.6656000, -2.7601000, 1],
      ['0905001', 'Keswick, Station Lane', 54.6044000, -3.1201000, 1],
      ['0905002', 'Keswick, Main Street', 54.6082000, -3.1078000, 2],
      ['0905003', 'Keswick, Derwent Hotel', 54.6089000, -3.1089000, 0],
      ['0905004', 'Keswick, Theatre by the Lake', 54.6026000, -3.1138000, 1],
    ];

    $stops = [];
    foreach ($stopDefs as [$stopId, $name, $lat, $lon, $wheelchair]) {
      $existing = $storage('localgov_bus_stop')->loadByProperties(['bustimes_stop_id' => $stopId]);
      if ($existing) {
        $stop = reset($existing);
        $this->logger()->notice("Stop already exists: {$stopId} — skipping.");
      }
      else {
        $stop = $storage('localgov_bus_stop')->create([
          'bustimes_stop_id'             => $stopId,
          'bustimes_stop_name'           => $name,
          'bustimes_stop_lat'            => (string) $lat,
          'bustimes_stop_lon'            => (string) $lon,
          'bustimes_wheelchair_boarding' => $wheelchair,
        ]);
        $stop->save();
      }
      $stops[$stopId] = $stop;
    }
    $this->logger()->success(dt('Stops: @count ready.', ['@count' => count($stops)]));

    $routeDefs = [
      ['685', '685', 'Carlisle – Newcastle', 'ARBA', 3],
      ['X4', 'X4', 'Carlisle – Penrith', 'CBLE', 3],
      ['60', '60', 'Carlisle – Workington', 'STAG', 3],
      ['555', '555', 'Keswick – Penrith – Lancaster', 'CBLE', 3],
      ['X5', 'X5', 'Workington – Whitehaven', 'STAG', 3],
    ];

    $routes = [];
    foreach ($routeDefs as [$routeId, $short, $long, $agency, $type]) {
      $existing = $storage('localgov_bus_route')->loadByProperties(['bustimes_route_id' => $routeId]);
      if ($existing) {
        $route = reset($existing);
        $this->logger()->notice("Route already exists: {$routeId} — skipping.");
      }
      else {
        $route = $storage('localgov_bus_route')->create([
          'bustimes_route_id'         => $routeId,
          'bustimes_route_short_name' => $short,
          'bustimes_route_long_name'  => $long,
          'bustimes_agency_id'        => $agency,
          'bustimes_route_type'       => $type,
        ]);
        $route->save();
      }
      $routes[$routeId] = $route;
    }
    $this->logger()->success(dt('Routes: @count ready.', ['@count' => count($routes)]));

    $calId = 'MON_FRI';
    $existing = $storage('localgov_bus_calendar')->loadByProperties(['bustimes_service_id' => $calId]);
    if ($existing) {
      $calendar = reset($existing);
      $this->logger()->notice("Calendar already exists: {$calId} — checking date range.");

      $needsSave = FALSE;
      $startVal = $calendar->get('bustimes_start_date')->value;
      $endVal = $calendar->get('bustimes_end_date')->value;

      if ($startVal !== $seedStartDate) {
        $calendar->set('bustimes_start_date', ['value' => $seedStartDate]);
        $needsSave = TRUE;
      }
      if ($endVal !== $seedEndDate) {
        $calendar->set('bustimes_end_date', ['value' => $seedEndDate]);
        $needsSave = TRUE;
      }
      if ($needsSave) {
        $calendar->save();
      }
    }
    else {
      $calendar = $storage('localgov_bus_calendar')->create([
        'bustimes_service_id' => $calId,
        'bustimes_monday'     => TRUE,
        'bustimes_tuesday'    => TRUE,
        'bustimes_wednesday'  => TRUE,
        'bustimes_thursday'   => TRUE,
        'bustimes_friday'     => TRUE,
        'bustimes_saturday'   => FALSE,
        'bustimes_sunday'     => FALSE,
        'bustimes_start_date' => ['value' => $seedStartDate],
        'bustimes_end_date'   => ['value' => $seedEndDate],
      ]);
      $calendar->save();
    }
    $this->logger()->success('Calendar: MON_FRI ready.');

    $calIdSat = 'SAT';
    $existing = $storage('localgov_bus_calendar')->loadByProperties(['bustimes_service_id' => $calIdSat]);
    if ($existing) {
      $calendarSat = reset($existing);

      $needsSave = FALSE;
      $startVal = $calendarSat->get('bustimes_start_date')->value;
      $endVal = $calendarSat->get('bustimes_end_date')->value;

      if ($startVal !== $seedStartDate) {
        $calendarSat->set('bustimes_start_date', ['value' => $seedStartDate]);
        $needsSave = TRUE;
      }
      if ($endVal !== $seedEndDate) {
        $calendarSat->set('bustimes_end_date', ['value' => $seedEndDate]);
        $needsSave = TRUE;
      }

      if (!$calendarSat->get('bustimes_saturday')->value) {
        $calendarSat->set('bustimes_saturday', TRUE);
        $needsSave = TRUE;
      }
      if ($calendarSat->get('bustimes_monday')->value) {
        $calendarSat->set('bustimes_monday', FALSE);
        $needsSave = TRUE;
      }
      if ($calendarSat->get('bustimes_tuesday')->value) {
        $calendarSat->set('bustimes_tuesday', FALSE);
        $needsSave = TRUE;
      }
      if ($calendarSat->get('bustimes_wednesday')->value) {
        $calendarSat->set('bustimes_wednesday', FALSE);
        $needsSave = TRUE;
      }
      if ($calendarSat->get('bustimes_thursday')->value) {
        $calendarSat->set('bustimes_thursday', FALSE);
        $needsSave = TRUE;
      }
      if ($calendarSat->get('bustimes_friday')->value) {
        $calendarSat->set('bustimes_friday', FALSE);
        $needsSave = TRUE;
      }
      if ($calendarSat->get('bustimes_sunday')->value) {
        $calendarSat->set('bustimes_sunday', FALSE);
        $needsSave = TRUE;
      }

      if ($needsSave) {
        $calendarSat->save();
      }
    }
    else {
      $calendarSat = $storage('localgov_bus_calendar')->create([
        'bustimes_service_id' => $calIdSat,
        'bustimes_monday'     => FALSE,
        'bustimes_tuesday'    => FALSE,
        'bustimes_wednesday'  => FALSE,
        'bustimes_thursday'   => FALSE,
        'bustimes_friday'     => FALSE,
        'bustimes_saturday'   => TRUE,
        'bustimes_sunday'     => FALSE,
        'bustimes_start_date' => ['value' => $seedStartDate],
        'bustimes_end_date'   => ['value' => $seedEndDate],
      ]);
      $calendarSat->save();
    }

    $calIdSun = 'SUN';
    $existing = $storage('localgov_bus_calendar')->loadByProperties(['bustimes_service_id' => $calIdSun]);
    if ($existing) {
      $calendarSun = reset($existing);

      $needsSave = FALSE;
      $startVal = $calendarSun->get('bustimes_start_date')->value;
      $endVal = $calendarSun->get('bustimes_end_date')->value;

      if ($startVal !== $seedStartDate) {
        $calendarSun->set('bustimes_start_date', ['value' => $seedStartDate]);
        $needsSave = TRUE;
      }
      if ($endVal !== $seedEndDate) {
        $calendarSun->set('bustimes_end_date', ['value' => $seedEndDate]);
        $needsSave = TRUE;
      }

      if (!$calendarSun->get('bustimes_sunday')->value) {
        $calendarSun->set('bustimes_sunday', TRUE);
        $needsSave = TRUE;
      }
      if ($calendarSun->get('bustimes_monday')->value) {
        $calendarSun->set('bustimes_monday', FALSE);
        $needsSave = TRUE;
      }
      if ($calendarSun->get('bustimes_tuesday')->value) {
        $calendarSun->set('bustimes_tuesday', FALSE);
        $needsSave = TRUE;
      }
      if ($calendarSun->get('bustimes_wednesday')->value) {
        $calendarSun->set('bustimes_wednesday', FALSE);
        $needsSave = TRUE;
      }
      if ($calendarSun->get('bustimes_thursday')->value) {
        $calendarSun->set('bustimes_thursday', FALSE);
        $needsSave = TRUE;
      }
      if ($calendarSun->get('bustimes_friday')->value) {
        $calendarSun->set('bustimes_friday', FALSE);
        $needsSave = TRUE;
      }
      if ($calendarSun->get('bustimes_saturday')->value) {
        $calendarSun->set('bustimes_saturday', FALSE);
        $needsSave = TRUE;
      }

      if ($needsSave) {
        $calendarSun->save();
      }
    }
    else {
      $calendarSun = $storage('localgov_bus_calendar')->create([
        'bustimes_service_id' => $calIdSun,
        'bustimes_monday'     => FALSE,
        'bustimes_tuesday'    => FALSE,
        'bustimes_wednesday'  => FALSE,
        'bustimes_thursday'   => FALSE,
        'bustimes_friday'     => FALSE,
        'bustimes_saturday'   => FALSE,
        'bustimes_sunday'     => TRUE,
        'bustimes_start_date' => ['value' => $seedStartDate],
        'bustimes_end_date'   => ['value' => $seedEndDate],
      ]);
      $calendarSun->save();
    }

    $calByServiceId = [
      'MON_FRI' => $calendar,
      'SAT'     => $calendarSat,
      'SUN'     => $calendarSun,
    ];

    $tripDefs = [
      ['685_OUT_MONFRI_1', '685', 0, 'Newcastle', 'MON_FRI'],
      ['685_OUT_MONFRI_2', '685', 0, 'Newcastle', 'MON_FRI'],
      ['X4_OUT_MONFRI_2', 'X4', 0, 'Penrith', 'MON_FRI'],
      ['685_OUT_SAT_1', '685', 0, 'Newcastle', 'SAT'],
      ['685_OUT_SAT_2', '685', 0, 'Newcastle', 'SAT'],
      ['685_IN_MONFRI_1', '685', 1, 'Carlisle', 'MON_FRI'],
      ['685_IN_MONFRI_2', '685', 1, 'Carlisle', 'MON_FRI'],
      ['685_IN_SAT_1', '685', 1, 'Carlisle', 'SAT'],
      ['685_IN_SAT_2', '685', 1, 'Carlisle', 'SAT'],
      ['X4_OUT_MONFRI_1', 'X4', 0, 'Penrith', 'MON_FRI'],
      ['X4_OUT_SUN_1', 'X4', 0, 'Penrith', 'SUN'],
      ['X4_OUT_SUN_2', 'X4', 0, 'Penrith', 'SUN'],
      ['X4_IN_MONFRI_1', 'X4', 1, 'Carlisle', 'MON_FRI'],
      ['X4_IN_MONFRI_2', 'X4', 1, 'Carlisle', 'MON_FRI'],
      ['X4_IN_SUN_1', 'X4', 1, 'Carlisle', 'SUN'],
      ['X4_IN_SUN_2', 'X4', 1, 'Carlisle', 'SUN'],
      ['60_OUT_MONFRI_1', '60', 0, 'to Workington', 'MON_FRI'],
      ['60_OUT_MONFRI_2', '60', 0, 'to Workington', 'MON_FRI'],
      ['60_OUT_SAT_1', '60', 0, 'to Workington', 'SAT'],
      ['60_OUT_SAT_2', '60', 0, 'to Workington', 'SAT'],
      ['60_IN_MONFRI_1', '60', 1, 'to Carlisle', 'MON_FRI'],
      ['60_IN_MONFRI_2', '60', 1, 'to Carlisle', 'MON_FRI'],
      ['60_IN_SAT_1', '60', 1, 'to Carlisle', 'SAT'],
      ['60_IN_SAT_2', '60', 1, 'to Carlisle', 'SAT'],
      ['555_OUT_MONFRI_1', '555', 0, 'Lancaster', 'MON_FRI'],
      ['555_OUT_MONFRI_2', '555', 0, 'Lancaster', 'MON_FRI'],
      ['555_OUT_SUN_1', '555', 0, 'Lancaster', 'SUN'],
      ['555_OUT_SUN_2', '555', 0, 'Lancaster', 'SUN'],
      ['555_IN_MONFRI_1', '555', 1, 'Keswick', 'MON_FRI'],
      ['555_IN_MONFRI_2', '555', 1, 'Keswick', 'MON_FRI'],
      ['555_IN_SUN_1', '555', 1, 'Keswick', 'SUN'],
      ['555_IN_SUN_2', '555', 1, 'Keswick', 'SUN'],
      ['X5_OUT_MONFRI_1', 'X5', 0, 'Whitehaven', 'MON_FRI'],
      ['X5_OUT_MONFRI_2', 'X5', 0, 'Whitehaven', 'MON_FRI'],
      ['X5_OUT_SAT_1', 'X5', 0, 'Whitehaven', 'SAT'],
      ['X5_OUT_SAT_2', 'X5', 0, 'Whitehaven', 'SAT'],
      ['X5_IN_MONFRI_1', 'X5', 1, 'Workington', 'MON_FRI'],
      ['X5_IN_MONFRI_2', 'X5', 1, 'Workington', 'MON_FRI'],
      ['X5_IN_SAT_1', 'X5', 1, 'Workington', 'SAT'],
      ['X5_IN_SAT_2', 'X5', 1, 'Workington', 'SAT'],
    ];

    $trips = [];
    foreach ($tripDefs as [$tripId, $routeKey, $dir, $headsign, $serviceKey]) {
      $existing = $storage('localgov_bus_trip')->loadByProperties(['bustimes_trip_id' => $tripId]);
      if ($existing) {
        $trip = reset($existing);
        $this->logger()->notice("Trip already exists: {$tripId} — skipping.");
      }
      else {
        $trip = $storage('localgov_bus_trip')->create([
          'bustimes_trip_id'       => $tripId,
          'bustimes_route_id'      => ['target_id' => $routes[$routeKey]->id()],
          'bustimes_service_id'    => ['target_id' => $calByServiceId[$serviceKey]->id()],
          'bustimes_direction_id'  => $dir,
          'bustimes_trip_headsign' => $headsign,
        ]);
        $trip->save();
      }
      $trips[$tripId] = $trip;
    }
    $this->logger()->success(dt('Trips: @count ready.', ['@count' => count($trips)]));

    $stopTimeDefs = [
      ['685_OUT_MONFRI_1', '0820AYC10039', '09:00:00', '09:00:00', 1],
      ['685_OUT_MONFRI_1', '0820AYE10212', '09:06:00', '09:06:00', 2],
      ['685_OUT_MONFRI_1', '0820AYE10108', '09:09:00', '09:09:00', 3],
      ['685_OUT_MONFRI_1', '0820AYE10050', '09:13:00', '09:14:00', 4],
      ['685_OUT_MONFRI_1', '0820ACF10081', '09:50:00', '09:51:00', 5],
      ['685_OUT_MONFRI_2', '0820AYC10039', '14:00:00', '14:00:00', 1],
      ['685_OUT_MONFRI_2', '0820AYE10212', '14:06:00', '14:06:00', 2],
      ['685_OUT_MONFRI_2', '0820AYE10108', '14:09:00', '14:09:00', 3],
      ['685_OUT_MONFRI_2', '0820AYE10050', '14:13:00', '14:14:00', 4],
      ['685_OUT_MONFRI_2', '0820ACF10081', '14:50:00', '14:51:00', 5],
      ['X4_OUT_MONFRI_2', '0820AYC10039', '14:00:00', '14:00:00', 1],
      ['X4_OUT_MONFRI_2', '0820AYE10212', '14:06:00', '14:06:00', 2],
      ['X4_OUT_MONFRI_2', '0820AYE10108', '14:09:00', '14:09:00', 3],
      ['X4_OUT_MONFRI_2', '0820AYE10050', '14:13:00', '14:14:00', 4],
      ['X4_OUT_MONFRI_2', '0810GHT20001', '15:05:00', '15:06:00', 5],
    ];
    $routeStopTemplates = [
      '685' => [
        0 => ['0820AYC10039', '0820AYE10212', '0901003', '0820AYE10050', '0820ACF10081'],
        1 => ['0820ACF10081', '0820AYE10050', '0820AYE10108', '0820AYE10212', '0820AYC10039'],
      ],
      'X4' => [
        0 => ['0820AYC10039', '0820AYE10108', '0901002', '0810GHT20001', '0904002'],
        1 => ['0904002', '0810GHT20001', '0820AYE10108', '0820AYE10212', '0820AYC10039'],
      ],
      '60' => [
        0 => ['0820AYC10039', '0820AYE10212', '0901001', '0902002', '0902001'],
        1 => ['0902001', '0902002', '0820AYE10050', '0820AYE10108', '0820AYC10039'],
      ],
      '555' => [
        0 => ['0905002', '0905003', '0904003', '0810GHT20001', '0904002'],
        1 => ['0904002', '0810GHT20001', '0904003', '0905003', '0905002'],
      ],
      'X5' => [
        0 => ['0902002', '0902001', '0902004', '0903001', '0903002'],
        1 => ['0903002', '0903001', '0902004', '0902001', '0902002'],
      ],
    ];

    $addMinutes = static function (string $time, int $minutes): string {
      $dt = new \DateTimeImmutable('1970-01-01 ' . $time);
      return $dt->modify('+' . $minutes . ' minutes')->format('H:i:s');
    };

    $offsetsMinutes = [0, 6, 9, 13, 50];

    foreach (array_keys($trips) as $tripKey) {
      if (!preg_match('/^(.+?)_(OUT|IN)_(MONFRI|SAT|SUN)_(\d+)$/', $tripKey, $m)) {
        continue;
      }

      $routeKey = $m[1];
      $dirPart = $m[2];
      $calPart = $m[3];
      $n = (int) $m[4];

      $dir = $dirPart === 'OUT' ? 0 : 1;
      $baseTime = '08:15:00';

      if ($dirPart === 'OUT') {
        if ($calPart === 'MONFRI') {
          $baseTime = $n === 1 ? '08:15:00' : '15:20:00';
        }
        elseif ($calPart === 'SAT') {
          $baseTime = $n === 1 ? '07:55:00' : '16:05:00';
        }
        elseif ($calPart === 'SUN') {
          $baseTime = $n === 1 ? '08:05:00' : '14:55:00';
        }
      }
      else {
        if ($calPart === 'MONFRI') {
          $baseTime = $n === 1 ? '07:40:00' : '14:25:00';
        }
        elseif ($calPart === 'SAT') {
          $baseTime = $n === 1 ? '07:55:00' : '16:05:00';
        }
        elseif ($calPart === 'SUN') {
          $baseTime = $n === 1 ? '08:10:00' : '13:55:00';
        }
      }

      if (!isset($routeStopTemplates[$routeKey][$dir])) {
        continue;
      }

      $stopsForTrip = $routeStopTemplates[$routeKey][$dir];
      for ($i = 0; $i < 5; $i++) {
        $seq = $i + 1;
        $stopKey = $stopsForTrip[$i];
        $time = $addMinutes($baseTime, $offsetsMinutes[$i] ?? 0);
        $stopTimeDefs[] = [$tripKey, $stopKey, $time, $time, $seq];
      }
    }

    $stCount = 0;
    foreach ($stopTimeDefs as [$tripKey, $stopKey, $arr, $dep, $seq]) {
      $trip = $trips[$tripKey];
      $stop = $stops[$stopKey];

      $existing = $storage('localgov_bus_stop_time')->loadByProperties([
        'bustimes_trip_id'       => $trip->id(),
        'bustimes_stop_sequence' => $seq,
      ]);
      if ($existing) {
        continue;
      }

      $st = $storage('localgov_bus_stop_time')->create([
        'bustimes_trip_id'        => ['target_id' => $trip->id()],
        'bustimes_stop_id'        => ['target_id' => $stop->id()],
        'bustimes_arrival_time'   => $arr,
        'bustimes_departure_time' => $dep,
        'bustimes_stop_sequence'  => $seq,
      ]);
      $st->save();
      $stCount++;
    }
    $this->logger()->success(dt('Stop times: @count inserted.', ['@count' => $stCount]));

    $this->importService->populateCalendarWeekdays();
    $this->importService->populateRouteHeadsigns();
    $this->importService->populateStopServices();

    $this->output()->writeln('');
    $this->output()->writeln('Verify with:');
    $this->output()->writeln('  ddev drush sql:query "SELECT COUNT(*) FROM localgov_bus_stop_time;"');
  }

}
