<?php

declare(strict_types=1);

namespace Drupal\localgov_bus_data\Form;

use Drupal\Core\Config\ConfigFactoryInterface;
use Drupal\Core\Config\TypedConfigManagerInterface;
use Drupal\Core\Form\ConfigFormBase;
use Drupal\Core\Form\FormStateInterface;
use Drupal\Core\Url;
use Drupal\localgov_bus_data\Service\GtfsImportService;
use Drupal\localgov_bus_data\Service\NaptanImportService;
use Symfony\Component\DependencyInjection\ContainerInterface;

/**
 * LocalGov Bus Data admin settings form.
 *
 * Provides GTFS import configuration and an "Import now" trigger.
 */
final class SettingsForm extends ConfigFormBase {

  /**
   * Protected so DependencySerializationTrait can detect injected services.
   *
   * Must not be private or readonly: get_object_vars() requires at least
   * protected visibility to detect properties when serialising AJAX form state.
   */
  public function __construct(
    ConfigFactoryInterface $configFactory,
    TypedConfigManagerInterface $typedConfigManager,
    protected GtfsImportService $importService,
    protected NaptanImportService $naptanImportService,
  ) {
    parent::__construct($configFactory, $typedConfigManager);
  }

  /**
   * {@inheritdoc}
   */
  public static function create(ContainerInterface $container): static {
    return new static(
      $container->get('config.factory'),
      $container->get('config.typed'),
      $container->get('localgov_bus_data.gtfs_import'),
      $container->get('localgov_bus_data.naptan_import'),
    );
  }

  /**
   * {@inheritdoc}
   */
  public function getFormId(): string {
    return 'localgov_bus_data_settings';
  }

  /**
   * {@inheritdoc}
   */
  protected function getEditableConfigNames(): array {
    return ['localgov_bus_data.settings'];
  }

  /**
   * {@inheritdoc}
   */
  public function buildForm(array $form, FormStateInterface $form_state): array {
    $config = $this->config('localgov_bus_data.settings');

    $savedUrl = (string) ($config->get('source.bulk_gtfs_url') ?? '');

    if (!$form_state->isSubmitted()) {
      // Initial page load: enable the button only when the module has been
      // previously configured and saved — returning users shouldn't have to
      // save again before running an import.
      $buttonDisabled = ($savedUrl === '');
    }
    else {
      // Form has been submitted (e.g. via an action button such as "Import
      // now"). Compare each submitted value against the saved config to detect
      // unsaved changes. The config is loaded fresh from storage so it always
      // reflects what was actually persisted.
      $savedBbox = $config->get('source.bounding_box');
      $savedBbox = is_array($savedBbox) ? $savedBbox : [];
      // Compare a single numeric bounding-box field: handles blank↔float and
      // float precision differences by casting non-blank values to float.
      $compareBboxField = function (mixed $formVal, mixed $savedVal): bool {
        $formBlank  = $this->isBlankScalar($formVal);
        $savedBlank = ($savedVal === NULL || $savedVal === '');
        if ($formBlank !== $savedBlank) {
          return TRUE;
        }
        return !$formBlank && ((float) $formVal !== (float) $savedVal);
      };
      $hasUnsavedChanges =
        trim((string) $form_state->getValue(['source', 'bulk_gtfs_url'])) !== $savedUrl
        || trim((string) $form_state->getValue(['source', 'boundary_geojson'])) !== (string) ($config->get('source.boundary_geojson') ?? '')
        || (bool) $form_state->getValue(['source', 'enabled']) !== (bool) $config->get('source.enabled')
        || $compareBboxField($form_state->getValue(['source', 'bounding_box', 'bbox_north']), $savedBbox['north'] ?? NULL)
        || $compareBboxField($form_state->getValue(['source', 'bounding_box', 'bbox_south']), $savedBbox['south'] ?? NULL)
        || $compareBboxField($form_state->getValue(['source', 'bounding_box', 'bbox_east']),  $savedBbox['east'] ?? NULL)
        || $compareBboxField($form_state->getValue(['source', 'bounding_box', 'bbox_west']),  $savedBbox['west'] ?? NULL)
        || trim((string) $form_state->getValue(['import', 'schedule'])) !== (string) ($config->get('import.schedule') ?? '')
        || (string) $form_state->getValue(['import', 'log_retention']) !== (string) ($config->get('import.log_retention') ?? '')
        || (bool) $form_state->getValue(['naptan', 'naptan_enabled']) !== (bool) $config->get('naptan.enabled')
        || trim((string) $form_state->getValue(['naptan', 'naptan_url'])) !== (string) ($config->get('naptan.url') ?? '');
      $buttonDisabled = $hasUnsavedChanges;
    }

    $form['source'] = [
      '#type'  => 'details',
      '#title' => $this->t('Data Source'),
      '#open'  => TRUE,
      '#tree'  => TRUE,
    ];

    $form['source']['bulk_gtfs_url'] = [
      '#type' => 'url',
      '#title' => $this->t('Bulk GTFS download URL'),
      '#description' => $this->t(
        '<p><strong>Regional GTFS download page.</strong> <a href="https://data.bus-data.dft.gov.uk/timetable/download/">https://data.bus-data.dft.gov.uk/timetable/download/</a></p>For example, use the North West region for Cumberland: <a href="https://data.bus-data.dft.gov.uk/timetable/download/gtfs-file/north_west/">https://data.bus-data.dft.gov.uk/timetable/download/gtfs-file/north_west/</a>.</p>
        <details>
        <summary>All regions:</summary>
          <table>
            <thead>
              <tr><th>Region</th><th>URL</th></tr>
            </thead>
            <tbody>
              <tr><td>North East</td><td><a href="https://data.bus-data.dft.gov.uk/timetable/download/gtfs-file/north_east/">https://data.bus-data.dft.gov.uk/timetable/download/gtfs-file/north_east/</a></td></tr>
              <tr><td>North West</td><td><a href="https://data.bus-data.dft.gov.uk/timetable/download/gtfs-file/north_west/">https://data.bus-data.dft.gov.uk/timetable/download/gtfs-file/north_west/</a></td></tr>
              <tr><td>East Midlands</td><td><a href="https://data.bus-data.dft.gov.uk/timetable/download/gtfs-file/east_midlands/">https://data.bus-data.dft.gov.uk/timetable/download/gtfs-file/east_midlands/</a></td></tr>
              <tr><td>East Anglia</td><td><a href="https://data.bus-data.dft.gov.uk/timetable/download/gtfs-file/east_anglia/">https://data.bus-data.dft.gov.uk/timetable/download/gtfs-file/east_anglia/</a></td></tr>
              <tr><td>London</td><td><a href="https://data.bus-data.dft.gov.uk/timetable/download/gtfs-file/london/">https://data.bus-data.dft.gov.uk/timetable/download/gtfs-file/london/</a></td></tr>
              <tr><td>South East</td><td><a href="https://data.bus-data.dft.gov.uk/timetable/download/gtfs-file/south_east/">https://data.bus-data.dft.gov.uk/timetable/download/gtfs-file/south_east/</a></td></tr>
              <tr><td>South West</td><td><a href="https://data.bus-data.dft.gov.uk/timetable/download/gtfs-file/south_west/">https://data.bus-data.dft.gov.uk/timetable/download/gtfs-file/south_west/</a></td></tr>
              <tr><td>West Midlands</td><td><a href="https://data.bus-data.dft.gov.uk/timetable/download/gtfs-file/west_midlands/">https://data.bus-data.dft.gov.uk/timetable/download/gtfs-file/west_midlands/</a></td></tr>
              <tr><td>Wales</td><td><a href="https://data.bus-data.dft.gov.uk/timetable/download/gtfs-file/wales/">https://data.bus-data.dft.gov.uk/timetable/download/gtfs-file/wales/</a></td></tr>
              <tr><td>Scotland</td><td><a href="https://data.bus-data.dft.gov.uk/timetable/download/gtfs-file/scotland/">https://data.bus-data.dft.gov.uk/timetable/download/gtfs-file/scotland/</a></td></tr>
              <tr><td>England</td><td><a href="https://data.bus-data.dft.gov.uk/timetable/download/gtfs-file/england/">https://data.bus-data.dft.gov.uk/timetable/download/gtfs-file/england/</a></td></tr>
              <tr><td>All</td><td><a href="https://data.bus-data.dft.gov.uk/timetable/download/gtfs-file/all/">https://data.bus-data.dft.gov.uk/timetable/download/gtfs-file/all/</a></td></tr>
            </tbody>
          </table>
        </details>'
      ),
      '#default_value' => $config->get('source.bulk_gtfs_url') ?? '',
      '#required' => TRUE,
      '#maxlength' => 255,
    ];

    $form['source']['boundary_geojson'] = [
      '#type'          => 'textarea',
      '#title'         => $this->t('Boundary GeoJSON'),
      '#description'   => $this->t(
        '<p>Paste a GeoJSON <code>Polygon</code> or <code>MultiPolygon</code> geometry here to filter imported stops to a precise boundary. <code>Feature</code> and <code>FeatureCollection</code> wrappers are also accepted.</p><p><strong>Coordinates must be in WGS84 (decimal degrees).</strong> A good source for UK council boundaries is <a href="https://mapit.mysociety.org/" target="_blank">MapIt by mySociety</a> — use the <code>.geojson</code> endpoint for your area.</p><p>When a GeoJSON boundary is provided it takes precedence over the bounding box below.</p>'
      ),
      '#default_value' => $config->get('source.boundary_geojson') ?? '',
      '#rows'          => 6,
      '#resizable'     => FALSE,
      '#attributes'    => [
        'style'          => 'font-family: monospace; font-size: 0.85em;',
        'spellcheck'     => 'false',
        'autocomplete'   => 'off',
        'autocorrect'    => 'off',
        'autocapitalize' => 'off',
      ],
    ];

    $bbox = $config->get('source.bounding_box');
    $bbox = is_array($bbox) ? $bbox : [];
    $form['source']['bounding_box'] = [
      '#type'        => 'details',
      '#title'       => $this->t('Geographic bounding box'),
      '#description' => $this->t('<p>Stops outside this box are discarded after download. Trips and stop times that no longer serve any in-box stop are also removed.</p><p>For example, if the bounding box is set to the North West region for Cumberland, stops outside the North West region will be discarded.</p><p>Example bounding box for Cumberland: North latitude: 55.10, South latitude: 54.15, East longitude: -2.45, West longitude: -3.75.</p>'),
      '#open'        => TRUE,
      '#tree'        => TRUE,
    ];
    $form['source']['bounding_box']['bbox_north'] = [
      '#type' => 'number',
      '#title' => $this->t('North latitude'),
      '#default_value' => array_key_exists('north', $bbox) ? $bbox['north'] : '',
      '#step' => 0.01,
      '#min' => -90,
      '#max' => 90,
    ];
    $form['source']['bounding_box']['bbox_south'] = [
      '#type' => 'number',
      '#title' => $this->t('South latitude'),
      '#default_value' => array_key_exists('south', $bbox) ? $bbox['south'] : '',
      '#step' => 0.01,
      '#min' => -90,
      '#max' => 90,
    ];
    $form['source']['bounding_box']['bbox_east'] = [
      '#type' => 'number',
      '#title' => $this->t('East longitude'),
      '#default_value' => array_key_exists('east', $bbox) ? $bbox['east'] : '',
      '#step' => 0.01,
      '#min' => -180,
      '#max' => 180,
    ];
    $form['source']['bounding_box']['bbox_west'] = [
      '#type' => 'number',
      '#title' => $this->t('West longitude'),
      '#default_value' => array_key_exists('west', $bbox) ? $bbox['west'] : '',
      '#step' => 0.01,
      '#min' => -180,
      '#max' => 180,
    ];

    $form['source']['enabled'] = [
      '#type' => 'checkbox',
      '#title' => $this->t('Enable this source'),
      '#default_value' => (bool) $config->get('source.enabled'),
    ];

    $logUrl = Url::fromRoute('localgov_bus_data.import_log')->toString();
    $form['source']['import_now'] = [
      '#type' => 'container',
      '#attributes' => ['id' => 'bus-times-import-now'],
    ];
    $form['source']['import_now']['trigger_button'] = [
      '#type'                    => 'submit',
      '#value'                   => $this->t('Import now'),
      '#submit'                  => ['::submitImportNow'],
      '#limit_validation_errors' => [],
      '#disabled'                => $buttonDisabled,
    ];
    $form['source']['import_now']['trigger_description'] = [
      '#type'   => 'item',
      '#markup' => $buttonDisabled
        ? $this->t(
            'Save your configuration before running an import. Results appear in the <a href=":url">import log</a>.',
            [':url' => $logUrl]
          )
        : $this->t(
            'Downloads fresh GTFS data and re-imports all bus entities. Results appear in the <a href=":url">import log</a>.',
            [':url' => $logUrl]
          ),
    ];

    $form['import'] = [
      '#type'  => 'details',
      '#title' => $this->t('Import settings'),
      '#open'  => FALSE,
      '#tree'  => TRUE,
    ];

    $form['import']['schedule'] = [
      '#type' => 'textfield',
      '#title' => $this->t('Import schedule (cron expression)'),
      '#description' => $this->t('5-field cron expression. Supports <code>*</code> (any) and exact integers only — not ranges or steps. Default <code>0 3 * * *</code> runs daily at 03:00.'),
      '#default_value' => $config->get('import.schedule') ?? '',
      '#maxlength' => 30,
    ];

    $form['import']['log_retention'] = [
      '#type' => 'number',
      '#title' => $this->t('Import log retention (days)'),
      '#default_value' => $config->get('import.log_retention') ?? '',
      '#min' => 1,
      '#max' => 365,
    ];

    $form['naptan'] = [
      '#type'  => 'details',
      '#title' => $this->t('NaPTAN stop enrichment'),
      '#open'  => FALSE,
      '#tree'  => TRUE,
    ];

    $form['naptan']['naptan_enabled'] = [
      '#type'          => 'checkbox',
      '#title'         => $this->t('Enable NaPTAN enrichment'),
      '#description'   => $this->t('When enabled, each GTFS import will download NaPTAN data and update stop indicator, street, and locality fields.'),
      '#default_value' => (bool) $config->get('naptan.enabled'),
    ];

    $form['naptan']['naptan_url'] = [
      '#type'          => 'url',
      '#title'         => $this->t('NaPTAN API URL'),
      '#description'   => $this->t(
        '<p>NaPTAN CSV endpoint. The default downloads all GB stops; only stops already in the database are updated. You can optionally filter by area code, e.g. append <code>&amp;atcoAreaCodes=082</code> for Cumbria — check the <a href="https://naptan.api.dft.gov.uk/" target="_blank">NaPTAN API</a> for valid codes.</p><p>For a full download of all stops, use the <a href="https://naptan.api.dft.gov.uk/v1/access-nodes?dataFormat=csv" target="_blank">https://naptan.api.dft.gov.uk/v1/access-nodes?dataFormat=csv</a>.</p>'
      ),
      '#default_value' => $config->get('naptan.url') ?? '',
      '#maxlength'     => 512,
      '#states'        => [
        'visible' => [':input[name="naptan[naptan_enabled]"]' => ['checked' => TRUE]],
      ],
    ];

    $form['naptan']['naptan_update'] = [
      '#type'                    => 'submit',
      '#value'                   => $this->t('Update stop details now'),
      '#submit'                  => ['::submitNaptanUpdate'],
      '#limit_validation_errors' => [],
      '#states'                  => [
        'visible' => [':input[name="naptan[naptan_enabled]"]' => ['checked' => TRUE]],
      ],
    ];

    return parent::buildForm($form, $form_state);
  }

  /**
   * {@inheritdoc}
   */
  public function validateForm(array &$form, FormStateInterface $form_state): void {
    parent::validateForm($form, $form_state);

    // Action-only buttons (Import now, Update stop details now) carry
    // #limit_validation_errors => [] but validateForm() still runs. Skip
    // field-level validation for those triggers — they have no config to save.
    $trigger_submit = $form_state->getTriggeringElement()['#submit'] ?? [];
    if (in_array('::submitImportNow', $trigger_submit, TRUE)
      || in_array('::submitNaptanUpdate', $trigger_submit, TRUE)) {
      return;
    }

    $geojson = trim((string) $form_state->getValue(['source', 'boundary_geojson']));
    if ($geojson !== '') {
      // Warn (but do not block) for very large polygons stored in config.
      if (strlen($geojson) > 512000) {
        $this->messenger()->addWarning($this->t(
          'The boundary GeoJSON is very large (@kb KB). Consider simplifying the polygon to reduce config size.',
          ['@kb' => round(strlen($geojson) / 1024)],
        ));
      }
      $decoded = json_decode($geojson, TRUE);
      if (!is_array($decoded)) {
        $form_state->setErrorByName('source][boundary_geojson', $this->t(
          'Boundary GeoJSON is not valid JSON.',
        ));
      }
      else {
        $type = (string) ($decoded['type'] ?? '');
        if ($type === 'Feature') {
          $gtype = (string) ($decoded['geometry']['type'] ?? '');
          if (!in_array($gtype, ['Polygon', 'MultiPolygon'], TRUE)) {
            $form_state->setErrorByName('source][boundary_geojson', $this->t(
              'Boundary GeoJSON Feature must contain a Polygon or MultiPolygon geometry (found: @type).',
              ['@type' => $gtype ?: 'unknown'],
            ));
          }
        }
        elseif ($type === 'GeometryCollection') {
          $geometries = $decoded['geometries'] ?? [];
          if (empty($geometries)) {
            $form_state->setErrorByName('source][boundary_geojson', $this->t(
              'Boundary GeoJSON GeometryCollection contains no geometries.',
            ));
          }
          else {
            $hasValidGeometry = FALSE;
            foreach ($geometries as $geometry) {
              $gtype = (string) ($geometry['type'] ?? '');
              if (in_array($gtype, ['Polygon', 'MultiPolygon'], TRUE)) {
                $hasValidGeometry = TRUE;
                break;
              }
            }
            if (!$hasValidGeometry) {
              $form_state->setErrorByName('source][boundary_geojson', $this->t(
                'Boundary GeoJSON GeometryCollection contains no Polygon or MultiPolygon geometry.',
              ));
            }
          }
        }
        elseif ($type === 'FeatureCollection') {
          $features = $decoded['features'] ?? [];
          if (empty($features)) {
            $form_state->setErrorByName('source][boundary_geojson', $this->t(
              'Boundary GeoJSON FeatureCollection contains no features.',
            ));
          }
          else {
            $hasValidGeometry = FALSE;
            foreach ($features as $feature) {
              $gtype = (string) (($feature['geometry']['type'] ?? $feature['type'] ?? ''));
              if (in_array($gtype, ['Polygon', 'MultiPolygon'], TRUE)) {
                $hasValidGeometry = TRUE;
                break;
              }
            }
            if (!$hasValidGeometry) {
              $form_state->setErrorByName('source][boundary_geojson', $this->t(
                'Boundary GeoJSON FeatureCollection contains no Polygon or MultiPolygon geometry.',
              ));
            }
          }
        }
        elseif (!in_array($type, ['Polygon', 'MultiPolygon'], TRUE)) {
          $form_state->setErrorByName('source][boundary_geojson', $this->t(
            'Boundary GeoJSON must be a Polygon, MultiPolygon, Feature, FeatureCollection, or GeometryCollection (found: @type).',
            ['@type' => $type ?: 'unknown'],
          ));
        }
      }
    }

    $schedule = trim((string) $form_state->getValue(['import', 'schedule']));
    if ($schedule !== '' && !preg_match('/^(\S+\s+){4}\S+$/', $schedule)) {
      $form_state->setErrorByName('import][schedule', $this->t(
        'The import schedule must be a valid 5-field cron expression (e.g. <code>0 3 * * *</code>).',
      ));
    }

    if ($this->isBlankScalar($form_state->getValue(['import', 'log_retention']))) {
      $form_state->setErrorByName('import][log_retention', $this->t('Import log retention is required.'));
    }
    $northRaw = $form_state->getValue(['source', 'bounding_box', 'bbox_north']);
    $southRaw = $form_state->getValue(['source', 'bounding_box', 'bbox_south']);
    $eastRaw = $form_state->getValue(['source', 'bounding_box', 'bbox_east']);
    $westRaw = $form_state->getValue(['source', 'bounding_box', 'bbox_west']);
    $nEmpty = $this->isBlankScalar($northRaw);
    $sEmpty = $this->isBlankScalar($southRaw);
    $eEmpty = $this->isBlankScalar($eastRaw);
    $wEmpty = $this->isBlankScalar($westRaw);
    $allEmpty  = $nEmpty && $sEmpty && $eEmpty && $wEmpty;
    $allFilled = !$nEmpty && !$sEmpty && !$eEmpty && !$wEmpty;

    if (!$allEmpty && !$allFilled) {
      $form_state->setErrorByName('source][bounding_box', $this->t(
        'Provide all four bounding box coordinates, or leave all four empty to skip geographic filtering.',
      ));
    }
    elseif ($allFilled) {
      $north = (float) $northRaw;
      $south = (float) $southRaw;
      $east  = (float) $eastRaw;
      $west  = (float) $westRaw;
      if ($north <= $south) {
        $form_state->setErrorByName('source][bounding_box][bbox_north', $this->t(
          'North latitude (@n°) must be greater than South latitude (@s°).',
          ['@n' => $north, '@s' => $south],
        ));
      }
      if ($east <= $west) {
        $form_state->setErrorByName('source][bounding_box][bbox_east', $this->t(
          'East longitude (@e°) must be greater than West longitude (@w°).',
          ['@e' => $east, '@w' => $west],
        ));
      }
    }
  }

  /**
   * Whether a form value is empty (null, '', or whitespace-only string).
   */
  private function isBlankScalar(mixed $value): bool {
    if ($value === NULL || $value === '') {
      return TRUE;
    }
    return is_string($value) && trim($value) === '';
  }

  /**
   * {@inheritdoc}
   */
  public function submitForm(array &$form, FormStateInterface $form_state): void {
    $northRaw = $form_state->getValue(['source', 'bounding_box', 'bbox_north']);
    $southRaw = $form_state->getValue(['source', 'bounding_box', 'bbox_south']);
    $eastRaw = $form_state->getValue(['source', 'bounding_box', 'bbox_east']);
    $westRaw = $form_state->getValue(['source', 'bounding_box', 'bbox_west']);
    $bboxEmpty = $this->isBlankScalar($northRaw)
      && $this->isBlankScalar($southRaw)
      && $this->isBlankScalar($eastRaw)
      && $this->isBlankScalar($westRaw);
    $boundingBox = $bboxEmpty ? [] : [
      'north' => (float) $northRaw,
      'south' => (float) $southRaw,
      'east'  => (float) $eastRaw,
      'west'  => (float) $westRaw,
    ];

    $this->config('localgov_bus_data.settings')
      ->set('source.bulk_gtfs_url', trim((string) $form_state->getValue(['source', 'bulk_gtfs_url'])))
      ->set('source.boundary_geojson', trim((string) $form_state->getValue(['source', 'boundary_geojson'])))
      ->set('source.bounding_box', $boundingBox)
      ->set('source.enabled', (bool) $form_state->getValue(['source', 'enabled']))
      ->set('import.schedule', trim((string) $form_state->getValue(['import', 'schedule'])))
      ->set('import.log_retention', (int) $form_state->getValue(['import', 'log_retention']))
      ->set('naptan.enabled', (bool) $form_state->getValue(['naptan', 'naptan_enabled']))
      ->set('naptan.url', trim((string) $form_state->getValue(['naptan', 'naptan_url'])))
      ->save();

    parent::submitForm($form, $form_state);
  }

  /**
   * Submit handler for the "Import now" button.
   *
   * Delegates to GtfsImportService::buildBatchDefinition() which returns the
   * multi-step batch definition. Each step runs within the nginx request
   * timeout instead of in a single long-running PHP process.
   */
  public function submitImportNow(array &$form, FormStateInterface $form_state): void {
    batch_set($this->importService->buildBatchDefinition());
  }

  /**
   * Submit handler for the "Update stop details now" button.
   *
   * Runs NaPTAN enrichment immediately without a full GTFS re-import.
   */
  public function submitNaptanUpdate(array &$form, FormStateInterface $form_state): void {
    try {
      $count = $this->naptanImportService->enrich();
      $this->messenger()->addStatus($this->t(
        'NaPTAN enrichment complete: @count stops updated.',
        ['@count' => $count],
      ));
    }
    catch (\RuntimeException $e) {
      $this->messenger()->addError($this->t(
        'NaPTAN enrichment failed: @msg',
        ['@msg' => $e->getMessage()],
      ));
    }
  }

}
