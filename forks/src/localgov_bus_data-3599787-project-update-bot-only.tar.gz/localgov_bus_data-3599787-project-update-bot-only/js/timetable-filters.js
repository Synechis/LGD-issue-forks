/**
 * @file
 * Timetable filter behaviour for the LocalGov Bus timetable page.
 *
 * Watches the Schedule select (Monday to Friday / Saturday / Sunday) and
 * keeps the three hidden boolean filter inputs in sync so that only one day
 * type is active at a time when the form is submitted.
 */

(function (Drupal, once) {
  'use strict';

  Drupal.behaviors.localgovBusDataTimetableFilters = {
    attach(context) {
      const days = ['weekdays', 'saturday', 'sunday'];

      /**
       * Sets the hidden boolean inputs so only the selected day is true.
       *
       * @param {string} selected - One of 'weekdays', 'saturday', 'sunday'.
       * @param {ParentNode} formRoot - Element to query for hidden inputs.
       */
      function syncDayInputs(selected, formRoot) {
        days.forEach((day) => {
          const input = formRoot.querySelector(
            'input[name="bustimes_' + day + '"]'
          );
          if (input) {
            // Non-selected days use '' (empty = Views "Any"), not '0'.
            // '0' would filter for calendar.field = false, which is wrong.
            input.value = day === selected ? '1' : '';
          }
        });
      }

      once(
        'localgov-bus-data-timetable-schedule',
        '[data-bus-timetable-schedule]',
        context
      ).forEach((schedule) => {
        const formRoot = schedule.closest('form') || context;
        // Sync on attach so hidden fields match the select (e.g. bfcache).
        syncDayInputs(schedule.value, formRoot);
        schedule.addEventListener('change', () => {
          syncDayInputs(schedule.value, formRoot);
        });
      });
    },
  };

}(Drupal, once));
