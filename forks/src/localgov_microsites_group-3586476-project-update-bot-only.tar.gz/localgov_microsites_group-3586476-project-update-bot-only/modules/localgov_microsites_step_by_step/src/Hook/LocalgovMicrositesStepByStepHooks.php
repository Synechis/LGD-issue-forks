<?php

namespace Drupal\localgov_microsites_step_by_step\Hook;

use Drupal\localgov_microsites_group\RolesHelper;
use Drupal\Core\Hook\Attribute\Hook;

/**
 * Hook implementations for localgov_microsites_step_by_step.
 */
class LocalgovMicrositesStepByStepHooks {

  /**
   * Implements hook_localgov_microsites_roles_default().
   */
  #[Hook('localgov_microsites_roles_default')]
  public function localgovMicrositesRolesDefault() {
    return [
      'group' => [
        RolesHelper::GROUP_ADMIN_ROLE => [
          'access group_term overview',
          'create group_node:localgov_step_by_step_page entity',
          'create group_node:localgov_step_by_step_overview entity',
          'create group_term:localgov_topic entity',
          'delete any group_node:localgov_step_by_step_page relationship',
          'delete any group_node:localgov_step_by_step_page entity',
          'delete any group_node:localgov_step_by_step_overview relationship',
          'delete any group_node:localgov_step_by_step_overview entity',
          'delete any group_term:localgov_topic relationship',
          'delete any group_term:localgov_topic entity',
          'delete own group_node:localgov_step_by_step_page relationship',
          'delete own group_node:localgov_step_by_step_page entity',
          'delete own group_node:localgov_step_by_step_overview relationship',
          'delete own group_node:localgov_step_by_step_overview entity',
          'delete own group_term:localgov_topic relationship',
          'update any group_node:localgov_step_by_step_page relationship',
          'update any group_node:localgov_step_by_step_page entity',
          'update any group_node:localgov_step_by_step_overview relationship',
          'update any group_node:localgov_step_by_step_overview entity',
          'update any group_term:localgov_topic relationship',
          'update any group_term:localgov_topic entity',
          'update own group_node:localgov_step_by_step_page relationship',
          'update own group_node:localgov_step_by_step_page entity',
          'update own group_node:localgov_step_by_step_overview relationship',
          'update own group_node:localgov_step_by_step_overview entity',
          'update own group_term:localgov_topic relationship',
          'view any unpublished group_term:localgov_topic entity',
          'view group_node:localgov_step_by_step_page relationship',
          'view group_node:localgov_step_by_step_page entity',
          'view group_node:localgov_step_by_step_overview relationship',
          'view group_node:localgov_step_by_step_overview entity',
          'view group_term:localgov_topic relationship',
          'view group_term:localgov_topic entity',
          'view unpublished group_node:localgov_step_by_step_page entity',
          'view unpublished group_node:localgov_step_by_step_overview entity',
        ],
        RolesHelper::GROUP_ANONYMOUS_ROLE => [
          'view group_node:localgov_step_by_step_page entity',
          'view group_node:localgov_step_by_step_overview entity',
          'view group_term:localgov_topic entity',
        ],
        RolesHelper::GROUP_MEMBER_ROLE => [
          'access group_term overview',
          'create group_node:localgov_step_by_step_page entity',
          'create group_node:localgov_step_by_step_overview entity',
          'create group_term:localgov_topic entity',
          'delete any group_term:localgov_topic entity',
          'update any group_node:localgov_step_by_step_page relationship',
          'update any group_node:localgov_step_by_step_page entity',
          'update any group_node:localgov_step_by_step_overview relationship',
          'update any group_node:localgov_step_by_step_overview entity',
          'update any group_term:localgov_topic entity',
          'update own group_node:localgov_step_by_step_page relationship',
          'update own group_node:localgov_step_by_step_page entity',
          'update own group_node:localgov_step_by_step_overview relationship',
          'update own group_node:localgov_step_by_step_overview entity',
          'view any unpublished group_term:localgov_topic entity',
          'view group_node:localgov_step_by_step_page entity',
          'view group_node:localgov_step_by_step_overview entity',
          'view group_term:localgov_topic entity',
          'view unpublished group_node:localgov_step_by_step_page entity',
          'view unpublished group_node:localgov_step_by_step_overview entity',
          'delete any group_node:localgov_step_by_step_page relationship',
          'delete any group_node:localgov_step_by_step_page entity',
          'delete any group_node:localgov_step_by_step_overview relationship',
          'delete any group_node:localgov_step_by_step_overview entity',
          'delete own group_node:localgov_step_by_step_page relationship',
          'delete own group_node:localgov_step_by_step_page entity',
          'delete own group_node:localgov_step_by_step_overview relationship',
          'delete own group_node:localgov_step_by_step_overview entity',
        ],
        RolesHelper::GROUP_OUTSIDER_ROLE => [
          'view group_node:localgov_step_by_step_page entity',
          'view group_node:localgov_step_by_step_overview entity',
          'view group_term:localgov_topic entity',
        ],
      ],
    ];
  }

}
