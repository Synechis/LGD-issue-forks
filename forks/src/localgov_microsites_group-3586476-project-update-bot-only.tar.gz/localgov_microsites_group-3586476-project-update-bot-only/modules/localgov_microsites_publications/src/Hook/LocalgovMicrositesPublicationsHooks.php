<?php

namespace Drupal\localgov_microsites_publications\Hook;

use Drupal\localgov_microsites_group\RolesHelper;
use Drupal\Core\Hook\Attribute\Hook;

/**
 * Hook implementations for localgov_microsites_publications.
 */
class LocalgovMicrositesPublicationsHooks {

  /**
   * Implements hook_localgov_microsites_roles_default().
   */
  #[Hook('localgov_microsites_roles_default')]
  public function localgovMicrositesRolesDefault() {
    return [
      'global' => [
        RolesHelper::MICROSITES_CONTROLLER_ROLE => [
          'administer book outlines',
          'create new books',
          'add content to books',
        ],
        RolesHelper::MICROSITES_EDITOR_ROLE => [
          'administer book outlines',
          'create new books',
          'add content to books',
        ],
      ],
      'group' => [
        RolesHelper::GROUP_ADMIN_ROLE => [
          'access group_term overview',
          'create group_node:localgov_publication_page entity',
          'create group_node:localgov_publication_cover_page entity',
          'delete any group_node:localgov_publication_page relationship',
          'delete any group_node:localgov_publication_page entity',
          'delete any group_node:localgov_publication_cover_page relationship',
          'delete any group_node:localgov_publication_cover_page entity',
          'delete own group_node:localgov_publication_page relationship',
          'delete own group_node:localgov_publication_page entity',
          'delete own group_node:localgov_publication_cover_page relationship',
          'delete own group_node:localgov_publication_cover_page entity',
          'update any group_node:localgov_publication_page relationship',
          'update any group_node:localgov_publication_page entity',
          'update any group_node:localgov_publication_cover_page relationship',
          'update any group_node:localgov_publication_cover_page entity',
          'update own group_node:localgov_publication_page relationship',
          'update own group_node:localgov_publication_page entity',
          'update own group_node:localgov_publication_cover_page relationship',
          'update own group_node:localgov_publication_cover_page entity',
          'view group_node:localgov_publication_page relationship',
          'view group_node:localgov_publication_page entity',
          'view group_node:localgov_publication_cover_page relationship',
          'view group_node:localgov_publication_cover_page entity',
          'view unpublished group_node:localgov_publication_page entity',
          'view unpublished group_node:localgov_publication_cover_page entity',
        ],
        RolesHelper::GROUP_ANONYMOUS_ROLE => [
          'view group_node:localgov_publication_page entity',
          'view group_node:localgov_publication_cover_page entity',
        ],
        RolesHelper::GROUP_MEMBER_ROLE => [
          'access group_term overview',
          'create group_node:localgov_publication_page entity',
          'create group_node:localgov_publication_cover_page entity',
          'update any group_node:localgov_publication_page relationship',
          'update any group_node:localgov_publication_page entity',
          'update any group_node:localgov_publication_cover_page relationship',
          'update any group_node:localgov_publication_cover_page entity',
          'update own group_node:localgov_publication_page relationship',
          'update own group_node:localgov_publication_page entity',
          'update own group_node:localgov_publication_cover_page relationship',
          'update own group_node:localgov_publication_cover_page entity',
          'view group_node:localgov_publication_page entity',
          'view group_node:localgov_publication_cover_page entity',
          'view unpublished group_node:localgov_publication_page entity',
          'view unpublished group_node:localgov_publication_cover_page entity',
          'delete any group_node:localgov_publication_page relationship',
          'delete any group_node:localgov_publication_page entity',
          'delete any group_node:localgov_publication_cover_page relationship',
          'delete any group_node:localgov_publication_cover_page entity',
          'delete own group_node:localgov_publication_page relationship',
          'delete own group_node:localgov_publication_page entity',
          'delete own group_node:localgov_publication_cover_page relationship',
          'delete own group_node:localgov_publication_cover_page entity',
        ],
        RolesHelper::GROUP_OUTSIDER_ROLE => [
          'view group_node:localgov_publication_page entity',
          'view group_node:localgov_publication_cover_page entity',
        ],
      ],
    ];
  }

}
