<?php

namespace Drupal\localgov_microsites_news\Hook;

use Drupal\localgov_microsites_group\RolesHelper;
use Drupal\Core\Hook\Attribute\Hook;

/**
 * Hook implementations for localgov_microsites_news.
 */
class LocalgovMicrositesNewsHooks {

  /**
   * Implements hook_localgov_microsites_roles_default().
   */
  #[Hook('localgov_microsites_roles_default')]
  public function localgovMicrositesRolesDefault() {
    return [
      'group' => [
        RolesHelper::GROUP_ADMIN_ROLE => [
          'access group_term overview',
          'create group_node:localgov_news_article entity',
          'create group_node:localgov_newsroom entity',
          'create group_term:localgov_topic entity',
          'delete any group_node:localgov_news_article relationship',
          'delete any group_node:localgov_news_article entity',
          'delete any group_node:localgov_newsroom relationship',
          'delete any group_node:localgov_newsroom entity',
          'delete any group_term:localgov_topic relationship',
          'delete any group_term:localgov_topic entity',
          'delete own group_node:localgov_news_article relationship',
          'delete own group_node:localgov_news_article entity',
          'delete own group_node:localgov_newsroom relationship',
          'delete own group_node:localgov_newsroom entity',
          'delete own group_term:localgov_topic relationship',
          'update any group_node:localgov_news_article relationship',
          'update any group_node:localgov_news_article entity',
          'update any group_node:localgov_newsroom relationship',
          'update any group_node:localgov_newsroom entity',
          'update any group_term:localgov_topic relationship',
          'update any group_term:localgov_topic entity',
          'update own group_node:localgov_news_article relationship',
          'update own group_node:localgov_news_article entity',
          'update own group_node:localgov_newsroom relationship',
          'update own group_node:localgov_newsroom entity',
          'update own group_term:localgov_topic relationship',
          'view any unpublished group_term:localgov_topic entity',
          'view group_node:localgov_news_article relationship',
          'view group_node:localgov_news_article entity',
          'view group_node:localgov_newsroom relationship',
          'view group_node:localgov_newsroom entity',
          'view group_term:localgov_topic relationship',
          'view group_term:localgov_topic entity',
          'view unpublished group_node:localgov_news_article entity',
          'view unpublished group_node:localgov_newsroom entity',
        ],
        RolesHelper::GROUP_ANONYMOUS_ROLE => [
          'view group_node:localgov_news_article entity',
          'view group_node:localgov_newsroom entity',
          'view group_term:localgov_topic entity',
        ],
        RolesHelper::GROUP_MEMBER_ROLE => [
          'access group_term overview',
          'create group_node:localgov_news_article entity',
          'create group_node:localgov_newsroom entity',
          'create group_term:localgov_topic entity',
          'delete any group_term:localgov_topic entity',
          'update any group_node:localgov_news_article relationship',
          'update any group_node:localgov_news_article entity',
          'update any group_node:localgov_newsroom relationship',
          'update any group_node:localgov_newsroom entity',
          'update any group_term:localgov_topic entity',
          'update own group_node:localgov_news_article relationship',
          'update own group_node:localgov_news_article entity',
          'update own group_node:localgov_newsroom relationship',
          'update own group_node:localgov_newsroom entity',
          'view any unpublished group_term:localgov_topic entity',
          'view group_node:localgov_news_article entity',
          'view group_node:localgov_newsroom entity',
          'view group_term:localgov_topic entity',
          'view unpublished group_node:localgov_news_article entity',
          'view unpublished group_node:localgov_newsroom entity',
          'delete any group_node:localgov_news_article relationship',
          'delete any group_node:localgov_news_article entity',
          'delete any group_node:localgov_newsroom relationship',
          'delete any group_node:localgov_newsroom entity',
          'delete own group_node:localgov_news_article relationship',
          'delete own group_node:localgov_news_article entity',
          'delete own group_node:localgov_newsroom relationship',
          'delete own group_node:localgov_newsroom entity',
        ],
        RolesHelper::GROUP_OUTSIDER_ROLE => [
          'view group_node:localgov_news_article entity',
          'view group_node:localgov_newsroom entity',
          'view group_term:localgov_topic entity',
        ],
      ],
    ];
  }

}
