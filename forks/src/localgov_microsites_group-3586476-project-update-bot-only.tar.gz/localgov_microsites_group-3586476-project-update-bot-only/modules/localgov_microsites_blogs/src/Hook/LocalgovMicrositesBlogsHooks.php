<?php

namespace Drupal\localgov_microsites_blogs\Hook;

use Drupal\localgov_microsites_group\RolesHelper;
use Drupal\Core\Hook\Attribute\Hook;

/**
 * Hook implementations for localgov_microsites_blogs.
 */
class LocalgovMicrositesBlogsHooks {

  /**
   * Implements hook_modules_installed().
   */
  #[Hook('modules_installed')]
  public function modulesInstalled($modules) {
    // Don't use global site pathauto settings.
    //
    // There doesn't seem to be a way to alter configuration when being installed,
    // when it's being saved it's hard to tell where it came from (sync, create,
    // or import). So just removing it after installation.
    $config_factory = \Drupal::configFactory();
    if (in_array('localgov_blogs', $modules) || in_array('localgov_microsites_blogs', $modules)) {
      foreach ([
        'pathauto.pattern.localgov_blog_channel',
        'pathauto.pattern.localgov_blog_post',
      ] as $config_name) {
        if ($config = $config_factory->getEditable($config_name)) {
          $config->delete();
        }
      }
    }
  }

  /**
   * Implements hook_localgov_microsites_roles_default().
   */
  #[Hook('localgov_microsites_roles_default')]
  public function localgovMicrositesRolesDefault() {
    return [
      'group' => [
        RolesHelper::GROUP_ADMIN_ROLE => [
          'access group_term overview',
          'create group_node:localgov_blog_post entity',
          'create group_node:localgov_blog_channel entity',
          'create group_term:localgov_topic entity',
          'create group_term:localgov_blog_author entity',
          'delete any group_node:localgov_blog_post relationship',
          'delete any group_node:localgov_blog_post entity',
          'delete any group_node:localgov_blog_channel relationship',
          'delete any group_node:localgov_blog_channel entity',
          'delete any group_term:localgov_topic relationship',
          'delete any group_term:localgov_topic entity',
          'delete any group_term:localgov_blog_author relationship',
          'delete any group_term:localgov_blog_author entity',
          'delete own group_node:localgov_blog_post relationship',
          'delete own group_node:localgov_blog_post entity',
          'delete own group_node:localgov_blog_channel relationship',
          'delete own group_node:localgov_blog_channel entity',
          'delete own group_term:localgov_topic relationship',
          'update any group_node:localgov_blog_post relationship',
          'update any group_node:localgov_blog_post entity',
          'update any group_node:localgov_blog_channel relationship',
          'update any group_node:localgov_blog_channel entity',
          'update any group_term:localgov_topic relationship',
          'update any group_term:localgov_topic entity',
          'update own group_node:localgov_blog_post relationship',
          'update own group_node:localgov_blog_post entity',
          'update own group_node:localgov_blog_channel relationship',
          'update own group_node:localgov_blog_channel entity',
          'update own group_term:localgov_topic relationship',
          'view any unpublished group_term:localgov_topic entity',
          'view group_node:localgov_blog_post relationship',
          'view group_node:localgov_blog_post entity',
          'view group_node:localgov_blog_channel relationship',
          'view group_node:localgov_blog_channel entity',
          'view group_term:localgov_topic relationship',
          'view group_term:localgov_topic entity',
          'view unpublished group_node:localgov_blog_post entity',
          'view unpublished group_node:localgov_blog_channel entity',
        ],
        RolesHelper::GROUP_ANONYMOUS_ROLE => [
          'view group_node:localgov_blog_post entity',
          'view group_node:localgov_blog_channel entity',
          'view group_term:localgov_blog_author entity',
          'view group_term:localgov_topic entity',
        ],
        RolesHelper::GROUP_MEMBER_ROLE => [
          'access group_term overview',
          'create group_node:localgov_blog_post entity',
          'create group_node:localgov_blog_channel entity',
          'create group_term:localgov_topic entity',
          'create group_term:localgov_blog_author entity',
          'delete any group_term:localgov_topic entity',
          'delete any group_term:localgov_blog_author entity',
          'update any group_node:localgov_blog_post relationship',
          'update any group_node:localgov_blog_post entity',
          'update any group_node:localgov_blog_channel relationship',
          'update any group_node:localgov_blog_channel entity',
          'update any group_term:localgov_topic entity',
          'update any group_term:localgov_blog_author entity',
          'update own group_node:localgov_blog_post relationship',
          'update own group_node:localgov_blog_post entity',
          'update own group_node:localgov_blog_channel relationship',
          'update own group_node:localgov_blog_channel entity',
          'view any unpublished group_term:localgov_topic entity',
          'view any unpublished group_term:localgov_blog_author entity',
          'view group_node:localgov_blog_post entity',
          'view group_node:localgov_blog_channel entity',
          'view group_term:localgov_topic entity',
          'view group_term:localgov_blog_author entity',
          'view unpublished group_node:localgov_blog_post entity',
          'view unpublished group_node:localgov_blog_channel entity',
          'delete any group_node:localgov_blog_post relationship',
          'delete any group_node:localgov_blog_post entity',
          'delete any group_node:localgov_blog_channel relationship',
          'delete any group_node:localgov_blog_channel entity',
          'delete own group_node:localgov_blog_post relationship',
          'delete own group_node:localgov_blog_post entity',
          'delete own group_node:localgov_blog_channel relationship',
          'delete own group_node:localgov_blog_channel entity',
        ],
        RolesHelper::GROUP_OUTSIDER_ROLE => [
          'view group_node:localgov_blog_post entity',
          'view group_node:localgov_blog_channel entity',
          'view group_term:localgov_blog_author entity',
          'view group_term:localgov_topic entity',
        ],
      ],
    ];
  }

}
