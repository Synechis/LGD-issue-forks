<?php

namespace Drupal\localgov_microsites_group_term_ui\Hook;

use Drupal\taxonomy\Entity\Term;
use Drupal\Core\Entity\EntityFormInterface;
use Drupal\Core\Form\FormStateInterface;
use Drupal\group\Entity\GroupType;
use Drupal\Core\Entity\EntityInterface;
use Drupal\views\Entity\View;
use Drupal\Component\Serialization\Yaml;
use Drupal\Core\Hook\Attribute\Hook;

/**
 * Hook implementations for localgov_microsites_group_term_ui.
 */
class LocalgovMicrositesGroupTermUiHooks {

  /**
   * Implements hook_modules_installed().
   */
  #[Hook('modules_installed')]
  public function modulesInstalled($modules, $is_syncing) {
    // Disable the Term view that comes with the group_term module.
    if (in_array('localgov_microsites_group_term_ui', $modules) && !$is_syncing) {
      $view = \Drupal::entityTypeManager()->getStorage('view')->load('group_terms');
      if (is_null($view)) {
        $module_path = \Drupal::service('extension.list.module')->getPath('localgov_microsites_group_term_ui');
        $view_config = Yaml::decode(file_get_contents($module_path . '/config/extra/views.view.group_terms.yml'));
        $view = View::create($view_config);
        $view->save();
      }
      $view->setStatus(FALSE)->save();
    }
  }

  /**
   * Implements hook_entity_insert().
   */
  #[Hook('entity_insert')]
  public function entityInsert(EntityInterface $entity) {
    if ($entity->getEntityTypeId() != 'taxonomy_term') {
      return;
    }
    /** @var \Drupal\group\Entity\Group $group */
    $group = \Drupal::routeMatch()->getParameter('group');
    if (empty($group)) {
      return;
    }
    // Add term as group content.
    $group_type = GroupType::load($group->bundle());
    $plugin_id = 'group_term:' . $entity->bundle();
    if ($group_type->hasPlugin($plugin_id)) {
      $group->addRelationship($entity, $plugin_id);
    }
  }

  /**
   * Implements hook_form_alter().
   */
  #[Hook('form_alter')]
  public function formAlter(&$form, FormStateInterface $form_state, $form_id) {
    // Only alter LocalGov taxonomy forms.
    if (!in_array($form_id, [
      'taxonomy_term_localgov_event_category_form',
      'taxonomy_term_localgov_event_locality_form',
      'taxonomy_term_localgov_event_price_form',
      'taxonomy_term_localgov_topic_form',
    ])) {
      return;
    }
    // Filter parent terms so that only group terms are shown.
    if (isset($form['relations']['parent']['#options'])) {
      // Find group.
      $group = localgov_microsites_group_get_by_context();
      if (is_null($group)) {
        /** @var \Drupal\group\Entity\Group $group */
        $group = \Drupal::routeMatch()->getParameter('group');
      }
      // Find vocabulary.
      $vid = \Drupal::routeMatch()->getParameter('vid');
      if (is_null($vid) && $form_state->getFormObject() instanceof EntityFormInterface) {
        $vid = $form_state->getFormObject()->getEntity()->bundle();
      }
      // Remove terms that are not part of the groups content.
      if (!is_null($group) && !is_null($vid)) {
        foreach ($form['relations']['parent']['#options'] as $tid => $name) {
          $terms = $tid ? $group->getRelationshipsByEntity(Term::load($tid)) : [];
          if ($name != '<root>' && empty($terms)) {
            unset($form['relations']['parent']['#options'][$tid]);
          }
        }
      }
    }
    // Add our submit handler.
    $form['actions']['overview']['#access'] = TRUE;
    $form['actions']['overview']['#submit'][] = 'localgov_microsites_group_term_ui_submit_taxonomy_term_localgov_topic_form';
  }

}
