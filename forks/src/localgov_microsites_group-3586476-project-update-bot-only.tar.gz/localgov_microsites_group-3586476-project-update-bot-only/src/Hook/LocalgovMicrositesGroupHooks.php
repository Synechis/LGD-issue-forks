<?php

namespace Drupal\localgov_microsites_group\Hook;

use Drupal\Core\Entity\EntityInterface;
use Drupal\user\Entity\User;
use Drupal\views\ViewExecutable;
use Drupal\Core\StringTranslation\TranslatableMarkup;
use Drupal\Core\Entity\EntityFormInterface;
use Drupal\Core\Render\Element;
use Drupal\Core\Form\FormStateInterface;
use Drupal\group\Entity\GroupMembership;
use Drupal\group\Entity\GroupRelationshipInterface;
use Drupal\localgov_microsites_group\DomainSettingsHelper;
use Drupal\Core\Entity\Display\EntityViewDisplayInterface;
use Drupal\group\Entity\GroupInterface;
use Drupal\Core\Cache\Cache;
use Drupal\menu_link_content\MenuLinkContentInterface;
use Drupal\localgov_microsites_group\GroupExtraFieldDisplay;
use Drupal\localgov_microsites_group\Form\MicrositeDomainAdd;
use Drupal\localgov_microsites_group\Form\DomainGroupContentAdd;
use Drupal\localgov_microsites_group\Form\DomainGroupAdd;
use Drupal\localgov_microsites_group\Entity\MicrositeGroup;
use Drupal\localgov_microsites_group\RolesHelper;
use Drupal\Core\Hook\Attribute\Hook;
use Drupal\Core\StringTranslation\StringTranslationTrait;

/**
 * Hook implementations for localgov_microsites_group.
 */
class LocalgovMicrositesGroupHooks {
  use StringTranslationTrait;

  /**
   * Implements hook_modules_installed().
   */
  #[Hook('modules_installed')]
  public function modulesInstalled($modules, $is_syncing) {
    // Assume configuration is correct if the site is being config sync'd.
    if ($is_syncing) {
      return;
    }
    foreach ($modules as $module) {
      RolesHelper::assignModuleRoles($module);
    }
  }

  /**
   * Implements hook_entity_bundle_info_alter().
   */
  #[Hook('entity_bundle_info_alter')]
  public function entityBundleInfoAlter(array &$bundles): void {
    if (isset($bundles['group'])) {
      // @todo loop over and check if is a domain group.
      $bundles['group']['microsite']['class'] = MicrositeGroup::class;
      $bundles['group']['microsite']['label'] = 'Microsite';
    }
  }

  /**
   * Implements hook_theme().
   */
  #[Hook('theme')]
  public function theme($existing, $type, $theme, $path) {
    return [
      'microsites_task_block' => [
        'variables' => [
          'links' => NULL,
        ],
      ],
    ];
  }

  /**
   * Implements hook_entity_type_build().
   */
  #[Hook('entity_type_build')]
  public function entityTypeBuild(array &$entity_types) {
    /** @var \Drupal\Core\Entity\EntityTypeInterface[] $entity_types */
    $entity_types['group']->setFormClass('new_domain', DomainGroupAdd::class);
    $entity_types['group_relationship']->setFormClass('new_domain', DomainGroupContentAdd::class);
    $entity_types['domain']->setFormClass('new_microsite', MicrositeDomainAdd::class);
  }

  /**
   * Implements hook_menu_local_actions_alter().
   */
  #[Hook('menu_local_actions_alter')]
  public function menuLocalActionsAlter(array &$local_actions) {
    if (!empty($local_actions['group_relationship.group_node_create_page']) && !in_array('view.group_nodes.microsite_page', $local_actions['group_relationship.group_node_create_page']['appears_on'])) {
      $local_actions['group_relationship.group_node_create_page']['appears_on'][] = 'view.group_nodes.microsite_page';
    }
    if (!empty($local_actions['group_relationship.group_node_add_page']) && !in_array('view.group_nodes.microsite_page', $local_actions['group_relationship.group_node_add_page']['appears_on'])) {
      $local_actions['group_relationship.group_node_add_page']['appears_on'][] = 'view.group_nodes.microsite_page';
    }
  }

  /**
   * Implements hook_entity_extra_field_info().
   */
  #[Hook('entity_extra_field_info')]
  public function entityExtraFieldInfo() {
    return \Drupal::service('class_resolver')->getInstanceFromDefinition(GroupExtraFieldDisplay::class)->entityExtraFieldInfo();
  }

  /**
   * Implements hook_ENTITY_TYPE_presave() for menu_link_content entities.
   */
  #[Hook('menu_link_content_presave')]
  public function menuLinkContentPresave(MenuLinkContentInterface $entity) {
    // Find active group.
    $group = localgov_microsites_group_get_by_context();
    if (is_null($group)) {
      $group = \Drupal::request()->attributes->get('group');
    }
    // Clear group cache so menu links are visible.
    if ($group) {
      Cache::invalidateTags([
        'group:' . $group->id(),
      ]);
    }
  }

  /**
   * Implements hook_ENTITY_TYPE_view().
   */
  #[Hook('group_view')]
  public function groupView(array &$build, GroupInterface $group, EntityViewDisplayInterface $display, $view_mode) {
    return \Drupal::service('class_resolver')->getInstanceFromDefinition(GroupExtraFieldDisplay::class)->groupView($build, $group, $display, $view_mode);
  }

  /**
   * Implements hook_ENTITY_TYPE_insert() for group entities.
   */
  #[Hook('group_insert')]
  public function groupInsert(GroupInterface $group) {
    if ($group->hasField('lgms_favicon')) {
      \Drupal::classResolver(DomainSettingsHelper::class)->faviconField($group, $group->lgms_favicon);
    }
  }

  /**
   * Implements hook_ENTITY_TYPE_update() for group entities.
   */
  #[Hook('group_update')]
  public function groupUpdate(GroupInterface $group) {
    if ($group->hasField('lgms_favicon')) {
      \Drupal::classResolver(DomainSettingsHelper::class)->faviconField($group, $group->lgms_favicon);
    }
  }

  /**
   * Implements hook_ENTITY_TYPE_insert() for group_relationship entities.
   */
  #[Hook('group_relationship_insert')]
  public function groupRelationshipInsert(GroupRelationshipInterface $entity) {
    // Add the Trusted Editor Role to group members.
    $type = $entity->get('type')->getValue();
    if (isset($type[0]['target_id']) && $type[0]['target_id'] == 'microsite-group_membership') {
      /** @var \Drupal\user\Entity\User $member */
      $member = $entity->getEntity();
      $member->addRole('microsites_trusted_editor');
      $member->save();
    }
  }

  /**
   * Implements hook_ENTITY_TYPE_delete() for group_relationship entities.
   */
  #[Hook('group_relationship_delete')]
  public function groupRelationshipDelete(GroupRelationshipInterface $entity) {
    // Remove the Trusted Editor Role when a user is no longer a member of groups.
    $type = $entity->get('type')->getValue();
    if (isset($type[0]['target_id']) && $type[0]['target_id'] == 'microsite-group_membership') {
      /** @var \Drupal\user\Entity\User $member */
      $member = $entity->getEntity();
      $groups = GroupMembership::loadByUser($member);
      if (empty($groups)) {
        $member->removeRole('microsites_trusted_editor');
        $member->save();
      }
    }
  }

  /**
   * Implements hook_form_FORM_ID_alter().
   */
  #[Hook('form_user_login_form_alter')]
  public function formUserLoginFormAlter(&$form, FormStateInterface $form_state, $form_id) {
    $form['#submit'][] = 'localgov_microsites_group_user_login_form_submit';
  }

  /**
   * Implements hook_form_alter().
   */
  #[Hook('form_alter')]
  public function formAlter(&$form, FormStateInterface $form_state, $form_id) {
    if (isset($form['domain_path'])) {
      $domain_ids = Element::children($form['domain_path']);
      $active_domain = \Drupal::service('domain.negotiator')->getActiveDomain();
      $domain_access = [];
      foreach ($domain_ids as $id) {
        // Hide path auto settings for all but the active domain.
        if ($id !== $active_domain->id()) {
          $form['domain_path'][$id]['#access'] = FALSE;
        }
        else {
          $domain_access[] = [
            'target_id' => $id,
          ];
        }
        // Set domain path pathauto as on by default for new nodes.
        if ($form_state->getFormObject() instanceof EntityFormInterface && $form_state->getFormObject()->getEntity()->isNew()) {
          $form['domain_path'][$id]['pathauto']['#default_value'] = TRUE;
        }
      }
      // The Domain Path module does a lot of checks for domain access
      // configuration, but we use the Group module for access checks. Adding the
      // domain access field to the form ensures the Domain Path checks pass, but
      // is a bit of a hack as it would be better to fix whatever is going wrong
      // in the Domain Path module.
      if (!isset($form['field_domain_access'])) {
        $form['field_domain_access'] = [
          '#type' => 'value',
          '#value' => $domain_access,
        ];
      }
    }
  }

  /**
   * Implements hook_form_FORM_ID_alter().
   */
  #[Hook('form_media_library_add_form_upload_alter')]
  public function formMediaLibraryAddFormUploadAlter(&$form, FormStateInterface $form_state) {
    $form['#submit'][] = 'localgov_microsites_group_media_library_add_form_submit';
  }

  /**
   * Implements hook_form_FORM_ID_alter().
   */
  #[Hook('form_media_library_add_form_oembed_alter')]
  public function formMediaLibraryAddFormOembedAlter(&$form, FormStateInterface $form_state) {
    $form['#submit'][] = 'localgov_microsites_group_media_library_add_form_submit';
  }

  /**
   * Implements hook_form_FORM_ID_alter() for group-microsite-edit-form form.
   */
  #[Hook('form_group_microsite_edit_form_alter')]
  public function formGroupMicrositeEditFormAlter(&$form, FormStateInterface $form_state) {
    $form['actions']['submit']['#submit'][] = 'localgov_microsites_group_form_group_microsite_edit_form_submit';
  }

  /**
   * Implements hook_preprocess_page_title().
   */
  #[Hook('preprocess_page_title')]
  public function preprocessPageTitle(&$variables) {
    // Change page title.
    if ($variables['title'] instanceof TranslatableMarkup && $variables['title']->__toString() == 'Group content menus') {
      $variables['title'] = $this->t('Menus');
    }
  }

  /**
   * Implements hook_preprocess_menu().
   */
  #[Hook('preprocess_menu')]
  public function preprocessMenu(&$variables) {
    // Hide Microsite administration link if Drupal user 1.
    if (\Drupal::currentUser()->id() == 1 && isset($variables['menu_name']) && $variables['menu_name'] == 'admin' && isset($variables['items']['localgov_microsites_group.microsite_admin'])) {
      unset($variables['items']['localgov_microsites_group.microsite_admin']);
    }
  }

  /**
   * Implements hook_views_query_substitutions().
   */
  #[Hook('views_query_substitutions')]
  public function viewsQuerySubstitutions(ViewExecutable $view) {
    if ($view->id() == 'my_invitations') {
      return [
        '***GINVITE_USER_EMAIL***' => User::load($view->argument['entity_id']->getValue())->getEmail(),
      ];
    }
  }

  /**
   * Implements hook_entity_insert().
   */
  #[Hook('entity_insert')]
  public function entityInsert(EntityInterface $entity) {
    // We can safely skip any route that is creating a group_relationship.
    $route = \Drupal::routeMatch();
    if (strpos($route->getRouteName(), 'entity.group_relationship') !== FALSE) {
      return;
    }
    if (in_array($route->getRouteName(), [
      'localgov_microsites_group_term_ui.taxononmy.add',
    ])) {
      return;
    }
    // Working on one plugin per content type. If there is more than one
    // exceptions will have to be added.
    $plugin_id = '';
    if ($group = localgov_microsites_group_get_by_context()) {
      foreach ($group->getGroupType()->getInstalledPlugins() as $plugin) {
        if ($plugin->getRelationType()->getEntityTypeId() == $entity->getEntityTypeId() && $plugin->getRelationType()->getEntityBundle() == $entity->bundle()) {
          $plugin_id = $plugin->getRelationTypeId();
          break;
        }
      }
    }
    // If it's in on a domain in a group, and not on a group_relationship path
    // add it to the group.
    if ($plugin_id !== '') {
      $group->addRelationship($entity, $plugin_id);
    }
  }

  /**
   * Implements hook_toolbar().
   *
   * - Adds a Control site indicator to the toolbar.
   */
  #[Hook('toolbar')]
  public function toolbar() {
    if (!\Drupal::hasService('domain.negotiator')) {
      return;
    }
    $active_domain = \Drupal::service('domain.negotiator')->getActiveDomain();
    if (empty($active_domain) || !$active_domain->get('is_default')) {
      return;
    }
    return [
      'localgov-microsites-group-toolbar-override' => [
        '#attached' => [
          'library' => 'localgov_microsites_group/control_site_toolbar_override',
        ],
      ],
      'localgov-microsites-group-control-site-indicator' => [
        '#type' => 'toolbar_item',
        '#weight' => 101,
        'tab' => [
          '#type' => 'html_tag',
          '#tag' => 'div',
          '#value' => $this->t("Control site: Don't edit content"),
          '#attributes' => [
            'class' => [
              'toolbar-icon',
              'toolbar-icon-warning',
            ],
          ],
          '#attached' => [
            'library' => 'localgov_microsites_group/toolbar_icons',
          ],
        ],
      ],
    ];
  }

  /**
   * Implements hook_toolbar_alter().
   */
  #[Hook('toolbar_alter')]
  public function toolbarAlter(&$items) {
    // The control site access provider gives admin mode there.
    // Decide to also hide from microsites, so the control site is the admin site
    // with our custom permissions.
    unset($items['group_sites']);
  }

  /**
   * Implements hook_localgov_microsites_roles_default().
   */
  #[Hook('localgov_microsites_roles_default')]
  public function localgovMicrositesRolesDefault() {
    return [
      'global' => [
        RolesHelper::MICROSITES_CONTROLLER_ROLE => [
          'assign microsites_controller role',
          'assign microsites_trusted_editor role',
        ],
      ],
    ];
  }

}
