<?php

namespace Drupal\localgov_blogs\Hook;

use Drupal\localgov_roles\RolesHelper;
use Drupal\Core\Form\FormStateInterface;
use Drupal\views\Views;
use Drupal\Core\Entity\Display\EntityViewDisplayInterface;
use Drupal\node\NodeInterface;
use Drupal\Core\Hook\Attribute\Hook;
use Drupal\Core\StringTranslation\StringTranslationTrait;

/**
 * Hook implementations for localgov_blogs.
 */
class LocalgovBlogsHooks {
  use StringTranslationTrait;

  /**
   * Implements hook_theme().
   */
  #[Hook('theme')]
  public function theme($existing, $type, $theme, $path): array {
    return [
      'localgov_blogs_prev_next_block' => [
        'variables' => [
          'previous_url' => NULL,
          'previous_title' => NULL,
          'next_url' => NULL,
          'next_title' => NULL,
          'show_title' => NULL,
        ],
      ],
    ];
  }

  /**
   * Implements hook_modules_installed().
   */
  #[Hook('modules_installed')]
  public function modulesInstalled($modules, $is_syncing): void {
    // Configure scheduled transitions if it's being installed.
    if (in_array('scheduled_transitions', $modules, TRUE)) {
      localgov_blogs_configure_scheduled_transitions();
    }
  }

  /**
   * Implements hook_entity_extra_field_info().
   */
  #[Hook('entity_extra_field_info')]
  public function entityExtraFieldInfo(): array {
    $fields = [];
    // Add a blog listing field to blog channels.
    $fields['node']['localgov_blog_channel']['display']['localgov_blog_listing'] = [
      'label' => $this->t('Blog post listing'),
      'description' => $this->t('View of blog posts without the the featured posts.'),
      'weight' => -20,
      'visible' => TRUE,
    ];
    // Add promote to blog channel field to posts.
    $fields['node']['localgov_blog_post']['form']['localgov_blog_channel_promote'] = [
      'label' => $this->t('Promote on blog channel'),
      'description' => $this->t("Add to promoted blog posts for selected channel."),
      'weight' => 1,
      'visible' => TRUE,
    ];
    return $fields;
  }

  /**
   * Implements hook_ENTITY_TYPE_view() for node entities.
   */
  #[Hook('node_view')]
  public function nodeView(array &$build, NodeInterface $node, EntityViewDisplayInterface $display, $view_mode): void {
    // Add the blog listing view to blog channels.
    if ($display->getComponent('localgov_blog_listing')) {
      $view_id = 'localgov_blog_list';
      $display_id = 'blog_listing';
      $view = Views::getView($view_id);
      if ($view && $view->access($display_id)) {
        $build['localgov_blog_listing'] = [
          '#type' => 'view',
          '#name' => $view_id,
          '#display_id' => $display_id,
          '#arguments' => [
            $node->id(),
          ],
        ];
      }
    }
  }

  /**
   * Implements hook_form_alter().
   */
  #[Hook('form_alter')]
  public function formAlter(&$form, FormStateInterface $form_state, $form_id): void {
    // Add promote to channel field to blog posts.
    if (($form_id == 'node_localgov_blog_post_form' || $form_id == 'node_localgov_blog_post_edit_form') && ($form_display = $form_state->get('form_display')) && $form_display->getComponent('localgov_blog_channel_promote')) {
      // Check if the current post is promoted on channel.
      $post = $form_state->getFormObject()->getEntity();
      $channel = $post->get('localgov_blog_channel')->entity;
      if (!is_null($channel)) {
        $featured_posts = $channel->get('localgov_blog_channel_featured')->getValue();
        $promoted = in_array($post->id(), array_column($featured_posts, 'target_id'), TRUE);
      }
      else {
        $promoted = FALSE;
      }
      $form['localgov_blog_channel_promote'] = [
        '#title' => $this->t('Promote on channel'),
        '#type' => 'checkbox',
        '#description' => $this->t("Include in promoted posts on the channel."),
        '#default_value' => $promoted,
        '#weight' => 3,
      ];
      if (isset($form['#fieldgroups'])) {
        $form['#fieldgroups']['group_about']->children[] = 'localgov_blog_channel_promote';
      }
      $form['actions']['submit']['#submit'][] = 'localgov_blogs_blog_channel_promote_submit';
    }
  }

  /**
   * Implements hook_field_widget_complete_form_alter().
   */
  #[Hook('field_widget_complete_form_alter')]
  public function fieldWidgetCompleteFormAlter(&$field_widget_complete_form, FormStateInterface $form_state, $context): void {
    // Check the blog channel select options.
    $field_definition = $context['items']->getFieldDefinition();
    if ($field_definition->getName() == 'localgov_blog_channel' && isset($field_widget_complete_form['widget']['#options'])) {
      $options = $field_widget_complete_form['widget']['#options'];
      // If there are no blog channels display a warning.
      if (count($options) == 1 && isset($options['_none'])) {
        $create_channel_path = 'localgov_blog_channel';
        if (\Drupal::moduleHandler()->moduleExists('localgov_microsites_group')) {
          // @phpstan-ignore-next-line Ignore the next line as this is only present on microsites.
          $group = localgov_microsites_group_get_by_context();
          // @phpstan-ignore-next-line Ignore the next line as this is only present on microsites.
          if ($group instanceof \GroupInterface) {
            $create_channel_path = 'group_node:' . $create_channel_path;
          }
        }
        \Drupal::messenger()->addWarning($this->t('There are no blogs channels. Please <a href="./@link">create a blog channel</a> to add this post to.', [
          '@link' => $create_channel_path,
        ]));
      }
      // If there's only one blog channel just use that.
      unset($options['_none']);
      if (count($options) == 1) {
        $field_widget_complete_form['widget']['#value'] = key($options);
        $field_widget_complete_form['widget']['#type'] = 'value';
      }
    }
  }

  /**
   * Implements hook_localgov_roles_default().
   */
  #[Hook('localgov_roles_default')]
  public function localgovRolesDefault(): array {
    // Content editing permissions.
    $perms = [
      RolesHelper::EDITOR_ROLE => [
        'create localgov_blog_post content',
        'delete any localgov_blog_post content',
        'delete localgov_blog_post revisions',
        'delete own localgov_blog_post content',
        'edit any localgov_blog_post content',
        'edit own localgov_blog_post content',
        'revert localgov_blog_post revisions',
        'view localgov_blog_post revisions',
        'create localgov_blog_channel content',
        'delete any localgov_blog_channel content',
        'delete localgov_blog_channel revisions',
        'delete own localgov_blog_channel content',
        'edit any localgov_blog_channel content',
        'edit own localgov_blog_channel content',
        'revert localgov_blog_channel revisions',
        'view localgov_blog_channel revisions',
        'create terms in localgov_blog_author',
        'delete terms in localgov_blog_author',
        'edit terms in localgov_blog_author',
      ],
      RolesHelper::AUTHOR_ROLE => [
        'create localgov_blog_post content',
        'delete own localgov_blog_post content',
        'edit own localgov_blog_post content',
        'revert localgov_blog_post revisions',
        'view localgov_blog_post revisions',
        'create localgov_blog_channel content',
        'delete own localgov_blog_channel content',
        'edit own localgov_blog_channel content',
        'revert localgov_blog_channel revisions',
        'view localgov_blog_channel revisions',
      ],
      RolesHelper::CONTRIBUTOR_ROLE => [
        'create localgov_blog_post content',
        'delete own localgov_blog_post content',
        'edit own localgov_blog_post content',
        'view localgov_blog_post revisions',
        'create localgov_blog_channel content',
        'delete own localgov_blog_channel content',
        'edit own localgov_blog_channel content',
        'view localgov_blog_channel revisions',
      ],
    ];
    // Content scheduling permissions required by localgov_workflows.
    if (\Drupal::moduleHandler()->moduleExists('localgov_workflows')) {
      $perms[RolesHelper::EDITOR_ROLE] = array_merge($perms[RolesHelper::EDITOR_ROLE], [
        'add scheduled transitions node localgov_blog_post',
        'reschedule scheduled transitions node localgov_blog_post',
        'view scheduled transitions node localgov_blog_post',
        'add scheduled transitions node localgov_blog_channel',
        'reschedule scheduled transitions node localgov_blog_channel',
        'view scheduled transitions node localgov_blog_channel',
      ]);
      $perms[RolesHelper::AUTHOR_ROLE] = array_merge($perms[RolesHelper::AUTHOR_ROLE], [
        'add scheduled transitions node localgov_blog_post',
        'reschedule scheduled transitions node localgov_blog_post',
        'view scheduled transitions node localgov_blog_post',
        'add scheduled transitions node localgov_blog_channel',
        'reschedule scheduled transitions node localgov_blog_channel',
        'view scheduled transitions node localgov_blog_channel',
      ]);
      $perms[RolesHelper::CONTRIBUTOR_ROLE] = array_merge($perms[RolesHelper::CONTRIBUTOR_ROLE], [
        'add scheduled transitions node localgov_blog_post',
        'reschedule scheduled transitions node localgov_blog_post',
        'view scheduled transitions node localgov_blog_post',
        'add scheduled transitions node localgov_blog_channel',
        'reschedule scheduled transitions node localgov_blog_channel',
        'view scheduled transitions node localgov_blog_channel',
      ]);
    }
    return $perms;
  }

}
