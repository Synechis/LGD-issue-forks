/**
 * @file
 * Defines JavaScript behaviors for the review date widget.
 */
(function localgovReviewDateScript(Drupal, once) {
  /**
   * Build summary text for the review date details element.
   *
   * @param {HTMLElement} form
   *   The review date form wrapper.
   *
   * @return {string}
   *   The summary text.
   */
  function getSummaryText(form) {
    const lastReview =
      form.querySelector('.review-date-last-review')?.value || '';
    const nextReview =
      form.querySelector('.review-date-next-review')?.value || '';

    if (lastReview && nextReview) {
      return Drupal.t('Last reviewed on @last<br>Next review on @next', {
        '@last': lastReview,
        '@next': nextReview,
      });
    }

    return Drupal.t('Not reviewed yet');
  }

  /**
   * Render the summary text in the details summary wrapper.
   *
   * @param {HTMLElement} form
   *   The review date form wrapper.
   */
  function renderSummary(form) {
    const summaryElement =
      form.querySelector(':scope > summary') || form.querySelector('summary');
    if (!summaryElement) {
      return;
    }

    let summaryWrapper = summaryElement.querySelector('.summary');
    if (!summaryWrapper) {
      summaryWrapper = document.createElement('span');
      summaryWrapper.className = 'summary';
      summaryElement.appendChild(summaryWrapper);
    }

    summaryWrapper.innerHTML = ` (${getSummaryText(form)})`;
  }

  /**
   * Show review date summary on node edit form.
   */
  Drupal.behaviors.ReviewDateSummary = {
    attach: function attach(context) {
      const forms = once(
        'allReviewDateSummaryForms',
        '.review-date-form',
        context,
      );

      forms.forEach((form) => {
        renderSummary(form);

        const summaryInputs = form.querySelectorAll(
          '.review-date-last-review, .review-date-next-review',
        );
        summaryInputs.forEach((input) => {
          input.addEventListener('change', () => {
            renderSummary(form);
          });
          input.addEventListener('input', () => {
            renderSummary(form);
          });
        });
      });
    },
  };

  /**
   * Update review date when next review date select changes.
   */
  Drupal.behaviors.ReviewDateNextReviewSelect = {
    attach: function attach(context) {
      const reviewInSelects = once(
        'allReviewDateNextReviewSelects',
        '.review-date-review-in',
        context,
      );

      reviewInSelects.forEach((reviewInSelect) => {
        reviewInSelect.addEventListener('change', (event) => {
          const reviewIn = parseInt(event.target.value, 10);
          if (Number.isNaN(reviewIn)) {
            return;
          }

          const today = new Date();
          const reviewDate = new Date(
            today.setMonth(today.getMonth() + reviewIn),
          );
          const form = reviewInSelect.closest('.review-date-form') || context;
          const reviewDateInput = form.querySelector(
            '.review-date-review-date',
          );

          if (reviewDateInput) {
            reviewDateInput.value = reviewDate.toISOString().slice(0, 10);
            reviewDateInput.dispatchEvent(
              new Event('change', { bubbles: true }),
            );
          }
        });
      });
    },
  };

  /**
   * Set content reviewed if content moderation state set to published.
   */
  Drupal.behaviors.ReviewDateSetReviewed = {
    attach: function attach(context) {
      const moderationStateInputs = once(
        'allReviewDateSetReviewedInputs',
        '#edit-moderation-state-0-state',
        context,
      );

      moderationStateInputs.forEach((moderationStateInput) => {
        moderationStateInput.addEventListener('change', (event) => {
          const moderationState = event.target.value;
          if (moderationState === 'published') {
            const form =
              moderationStateInput.closest('.review-date-form') || context;
            const reviewed = form.querySelector('.review-date-reviewed');
            if (!reviewed) {
              return;
            }

            reviewed.checked = true;
            reviewed.dispatchEvent(new Event('change', { bubbles: true }));
          }
        });
      });
    },
  };
})(Drupal, once);
