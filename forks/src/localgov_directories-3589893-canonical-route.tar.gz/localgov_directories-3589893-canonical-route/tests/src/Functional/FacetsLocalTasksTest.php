<?php

namespace Drupal\Tests\localgov_directories\Functional;

use Drupal\Tests\BrowserTestBase;
use Drupal\language\Entity\ConfigurableLanguage;
use Drupal\localgov_directories\Entity\LocalgovDirectoriesFacets;
use Drupal\localgov_directories\Entity\LocalgovDirectoriesFacetsType;

/**
 * Tests the local tasks (tabs) on directory facet admin pages.
 *
 * @group localgov_directories
 */
class FacetsLocalTasksTest extends BrowserTestBase {

  /**
   * {@inheritdoc}
   */
  protected $defaultTheme = 'stark';

  /**
   * Modules to enable.
   *
   * @var array
   */
  protected static $modules = [
    'block',
    'media',
    'path',
    'views',
    'language',
    'content_translation',
    // LocalGov Media can stay here, its optional config will get
    // installed as the configuration entities are needed.
    'localgov_media',
  ];

  /**
   * Facet used in the tests.
   *
   * @var \Drupal\localgov_directories\Entity\LocalgovDirectoriesFacets
   */
  protected $facet;

  /**
   * {@inheritdoc}
   */
  protected function setUp(): void {
    parent::setUp();
    $this->container->get('module_installer')->install(['localgov_core']);
    $this->container->get('module_installer')->install([
      'localgov_directories',
    ], TRUE);
    $this->rebuildContainer();

    $this->drupalPlaceBlock('local_tasks_block');

    ConfigurableLanguage::createFromLangcode('cy')->save();

    $type = LocalgovDirectoriesFacetsType::create([
      'id' => 'facet_type',
      'label' => 'Facet type',
    ]);
    $type->save();
    $this->container->get('content_translation.manager')
      ->setEnabled('localgov_directories_facets', 'facet_type', TRUE);

    $this->facet = LocalgovDirectoriesFacets::create([
      'bundle' => 'facet_type',
      'title' => 'Facet ' . $this->randomMachineName(8),
    ]);
    $this->facet->save();

    // Translation routes and tabs depend on the bundle being translatable.
    $this->rebuildAll();

    $this->drupalLogin($this->drupalCreateUser([
      'access directory facets overview',
      'edit directory facets',
      'delete directory facets',
      'translate any entity',
      'create content translations',
    ]));
  }

  /**
   * Test the facet canonical URL and the tabs on edit and translate pages.
   */
  public function testFacetLocalTasks(): void {
    $assert_session = $this->assertSession();

    // Confirm that the canonical link is the edit form.
    $this->assertSame(
      $this->facet->toUrl('edit-form')->toString(),
      $this->facet->toUrl()->toString()
    );

    // Confirm that the Edit page shows Edit, Delete and Translate tabs.
    $this->drupalGet($this->facet->toUrl('edit-form'));
    $assert_session->statusCodeEquals(200);
    $this->assertFacetTabs();

    // Translations overview shows the same tabs.
    $this->drupalGet($this->facet->toUrl('drupal:content-translation-overview'));
    $assert_session->statusCodeEquals(200);
    $this->assertFacetTabs();
  }

  /**
   * Check that the Edit, Delete and Translate facet tabs are present.
   */
  protected function assertFacetTabs(): void {
    $assert_session = $this->assertSession();
    $tabs = [
      'Edit' => $this->facet->toUrl('edit-form')->toString(),
      'Delete' => $this->facet->toUrl('delete-form')->toString(),
      'Translate' => $this->facet->toUrl('drupal:content-translation-overview')->toString(),
    ];
    foreach ($tabs as $title => $href) {
      $assert_session->elementExists('xpath', '//h2[text()="Primary tabs"]/following-sibling::ul/li/a[normalize-space()="' . $title . '" and @href="' . $href . '"]');
    }
  }

}
