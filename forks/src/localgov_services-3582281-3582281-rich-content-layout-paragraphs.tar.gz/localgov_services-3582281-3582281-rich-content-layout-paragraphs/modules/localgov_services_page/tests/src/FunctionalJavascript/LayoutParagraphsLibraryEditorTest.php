<?php

namespace Drupal\Tests\localgov_services_page\FunctionalJavascript;

use Drupal\FunctionalJavascriptTests\WebDriverTestBase;
use Drupal\node\NodeInterface;
use Drupal\paragraphs_library\Entity\LibraryItem;
use Drupal\Tests\node\Traits\NodeCreationTrait;
use PHPUnit\Framework\Attributes\Group;
use PHPUnit\Framework\Attributes\RunTestsInSeparateProcesses;

/**
 * Tests reusing a paragraph across service pages with Layout Paragraphs.
 *
 * @group localgov_services
 */
#[Group('localgov_services')]
#[RunTestsInSeparateProcesses]
class LayoutParagraphsLibraryEditorTest extends WebDriverTestBase {

  use NodeCreationTrait;

  /**
   * The field.
   */
  const FIELD = 'localgov_paragraph_content';

  /**
   * The initial content snippet.
   */
  const FIRST = 'Recycling centres close at 4pm on Sundays.';

  /**
   * The snippet for changing in the library.
   */
  const SECOND = 'Recycling centres close at 5pm on Sundays from October.';

  /**
   * {@inheritdoc}
   */
  protected $defaultTheme = 'claro';

  /**
   * {@inheritdoc}
   */
  protected static $modules = [
    'localgov_media',
  ];

  /**
   * The first service page.
   *
   * @var \Drupal\node\NodeInterface
   */
  protected $pageA;

  /**
   * The second service page.
   *
   * @var \Drupal\node\NodeInterface
   */
  protected $pageB;

  /**
   * {@inheritdoc}
   */
  protected function setUp(): void {
    parent::setUp();
    // Install dependencies here to include optional configuration in D11.
    // Note: localgov_core installed separately to install body field storage.
    $installer = $this->container->get('module_installer');
    $installer->install(['localgov_core']);
    $installer->install(['localgov_services_page']);
    $this->rebuildContainer();

    foreach (['A', 'B'] as $letter) {
      $this->{'page' . $letter} = $this->createNode([
        'type' => 'localgov_services_page',
        'title' => 'Recycling page ' . $letter,
        'body' => ['value' => 'Where to take it.', 'summary' => 'Recycling.', 'format' => 'wysiwyg'],
        'status' => NodeInterface::PUBLISHED,
      ]);
    }

    $this->drupalLogin($this->drupalCreateUser([
      'access content',
      'edit any localgov_services_page content',
      'create paragraph library item',
      'edit paragraph library item',
      'administer paragraphs library',
      'access paragraphs_library_items entity browser pages',
      'use text format wysiwyg',
    ]));
  }

  /**
   * Promote from the component form, reuse on a second page, edit once.
   */
  public function testPromoteReuseAndEdit(): void {
    $assert = $this->assertSession();
    $page = $this->getSession()->getPage();

    $this->drupalGet($this->pageA->toUrl('edit-form'));
    $this->openComponentDialog();
    $this->chooseComponentType('Text');
    $assert->waitForText('Create Text');

    $assert->elementExists('css', '.ui-dialog-buttonpane .lpb-btn--promote-to-library');
    $this->setEditorData('textarea[name="localgov_text[0][value]"]', self::FIRST);
    $this->clickDialogButton('.lpb-btn--promote-to-library');
    $assert->assertWaitOnAjaxRequest();

    $items = LibraryItem::loadMultiple();
    $this->assertCount(1, $items, 'One reusable paragraph now exists in the library.');
    $item = reset($items);
    $this->assertStringContainsString(self::FIRST, $item->get('paragraphs')->entity->get('localgov_text')->value);

    $this->saveNode();
    $assert->pageTextContains(self::FIRST);
    $this->assertSame(self::FIELD, $this->fieldShowing(self::FIRST), 'The text renders from the Rich content field.');

    $this->drupalGet($this->pageB->toUrl('edit-form'));
    $this->openComponentDialog();
    $this->chooseComponentType('From reusable paragraph library');
    $assert->waitForText('Create From reusable paragraph library');
    $this->chooseLibraryItem($item);
    $this->clickDialogButton('.lpb-btn--save');
    $assert->assertWaitOnAjaxRequest();
    $assert->waitForText($item->label());

    $this->saveNode();
    $assert->pageTextContains(self::FIRST);

    $this->drupalGet($item->toUrl('edit-form'));
    $this->setEditorData('textarea[name="paragraphs[0][subform][localgov_text][0][value]"]', self::SECOND);
    $page->pressButton('Save');

    foreach ([$this->pageA, $this->pageB] as $node) {
      $stored = $this->container->get('entity_type.manager')->getStorage('node')
        ->load($node->id())->get(self::FIELD);
      $this->assertCount(1, $stored, $node->label() . ' holds one component.');
      $paragraph = $stored[0]->entity;
      $this->assertSame('from_library', $paragraph->bundle());
      $this->assertSame($item->id(), $paragraph->get('field_reusable_paragraph')->target_id,
        $node->label() . ' points at the library item, not a copy.');
      $this->assertPageShows($node, self::SECOND);
    }
  }

  /**
   * Asserts the page shows the text, reloading it up to three times.
   *
   * After a library item is edited, the next load of a page that uses it can
   * still show the old text from cache.
   */
  protected function assertPageShows($node, string $text): void {
    for ($attempt = 0; $attempt < 3; $attempt++) {
      $this->drupalGet($node->toUrl());
      if (str_contains($this->getSession()->getPage()->getText(), $text)) {
        break;
      }
      $this->getSession()->wait(2000);
    }
    $this->assertSession()->pageTextContains($text);
  }

  /**
   * Opens layout builder's "Choose a component" dialog.
   *
   * Add is only visible on hover, so the click is dispatched on
   * the element.
   */
  protected function openComponentDialog(): void {
    $this->assertSession()->waitForElement('css', '.lpb-btn--add');
    $this->getSession()->executeScript("document.querySelector('.lpb-btn--add').click();");
    $this->assertSession()->waitForText('Choose a component');
  }

  /**
   * Saves the node form, once the component dialog is dismissed.
   *
   * Until the dialog closes, its button pane sits over the Save button.
   */
  protected function saveNode(): void {
    $session = $this->getSession();
    $this->assertTrue(
      $session->wait(20000, "!document.querySelector('.ui-dialog:not([style*=\"display: none\"])')"),
      'The component dialog closed.');
    // The builder re-renders the form, so Save is resolved at click time.
    $clicked = $session->evaluateScript(
      "(() => { const s = [...document.querySelectorAll('#edit-submit, input[type=submit], button')]"
      . ".filter(e => (e.value || e.textContent || '').trim().startsWith('Save'))"
      . ".filter(e => !e.className.includes('lpb-btn'))"
      . ".filter(e => e.offsetParent !== null);"
      . " if (!s.length) { return false; } s[0].click(); return true; })()");
    $this->assertTrue($clicked, 'Pressed Save on the node form.');
    $this->assertTrue(
      $session->wait(30000, "!document.querySelector('#edit-submit')"),
      'The node form was submitted.');
  }

  /**
   * Picks a paragraph type in the "Choose a component" dialog.
   */
  protected function chooseComponentType(string $label): void {
    $this->assertSession()->waitForText($label);
    $clicked = $this->getSession()->evaluateScript(
      "(() => { const a = [...document.querySelectorAll('.ui-dialog a, .ui-dialog button')]"
      . ".find(e => e.textContent.trim() === " . json_encode($label) . ");"
      . " if (!a) { return false; } a.click(); return true; })()");
    $this->assertTrue($clicked, 'Chose ' . $label . ' in the component dialog.');
  }

  /**
   * Clicks a button in the component dialog's button pane.
   *
   * The dialog is rebuilt by AJAX, so the element is looked up at click
   * time.
   */
  protected function clickDialogButton(string $selector): void {
    $this->assertSession()->waitForElementVisible('css', '.ui-dialog-buttonpane ' . $selector);
    $clicked = $this->getSession()->evaluateScript(
      "(() => { const b = document.querySelector('.ui-dialog-buttonpane $selector');"
      . " if (!b) { return false; } b.click(); return true; })()");
    $this->assertTrue($clicked, 'Clicked ' . $selector . ' in the component dialog.');
  }

  /**
   * Picks a library item on the From library component form.
   *
   * Paragraphs Library uses an entity browser where entity_browser is
   * installed and an autocomplete where it is not.
   */
  protected function chooseLibraryItem(LibraryItem $item): void {
    $assert = $this->assertSession();
    $page = $this->getSession()->getPage();
    $opener = $page->find('css', 'input[value="Select reusable paragraph"]');
    if (!$opener) {
      $page->fillField('field_reusable_paragraph[0][target_id]', $item->label() . ' (' . $item->id() . ')');
      return;
    }
    $opener->click();
    $assert->waitForElementVisible('css', 'iframe[name^="entity_browser_iframe"]');
    $frame = $page->find('css', 'iframe[name^="entity_browser_iframe"]')->getAttribute('name');
    $this->getSession()->switchToIFrame($frame);
    $assert->waitForElementVisible('css', 'input[name^="entity_browser_select"]')->click();
    $page->pressButton('Select reusable paragraph');
    $this->getSession()->switchToIFrame();
    $assert->assertWaitOnAjaxRequest();
    $assert->waitForElementRemoved('css', 'iframe[name^="entity_browser_iframe"]');

    // Saving before the form rebuilds submits it without the reference.
    $held = $this->getSession()->wait(20000,
      "(() => { const f = document.querySelector('[name=\"field_reusable_paragraph[target_id]\"]');"
      . " return !!f && f.value !== '' && !document.querySelector('.ajax-progress'); })()");
    $this->assertTrue($held, 'The component form holds the chosen reusable paragraph.');
    $assert->waitForText($item->label());
  }

  /**
   * Sets a CKEditor 5 instance's content through its API.
   */
  protected function setEditorData(string $textarea_selector, string $text): void {
    $textarea = $this->assertSession()->waitForElement('css', $textarea_selector);
    $this->assertNotNull($textarea, 'The text field is on the form.');
    $this->assertSession()->waitForElementVisible('css', '.ck-editor__editable');
    $this->getSession()->wait(10000, "document.querySelector('$textarea_selector').dataset.ckeditor5Id !== undefined && Drupal.CKEditor5Instances.get(document.querySelector('$textarea_selector').dataset.ckeditor5Id) !== undefined");
    $this->getSession()->executeScript("Drupal.CKEditor5Instances.get(document.querySelector('$textarea_selector').dataset.ckeditor5Id).setData('<p>$text</p>');");
  }

  /**
   * Gets the node field whose rendered output has the text snippet.
   */
  protected function fieldShowing(string $text): ?string {
    foreach ($this->getSession()->getPage()->findAll('css', '.node [class*="field--name-"]') as $element) {
      if (str_contains($element->getText(), $text)) {
        preg_match('/field--name-([a-z0-9-]+)/', $element->getAttribute('class'), $matches);
        return str_replace('-', '_', $matches[1]);
      }
    }
    return NULL;
  }

}
