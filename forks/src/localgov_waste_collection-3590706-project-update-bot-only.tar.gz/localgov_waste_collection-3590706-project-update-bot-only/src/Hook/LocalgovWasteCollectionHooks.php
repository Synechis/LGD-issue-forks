<?php

namespace Drupal\localgov_waste_collection\Hook;

use Drupal\Core\Hook\Attribute\Hook;

/**
 * Hook implementations for localgov_waste_collection.
 */
class LocalgovWasteCollectionHooks {
  /**
   * @file
   * LocalGov Waste Collection module file.
   */

  /**
   * Implements hook_theme().
   */
  #[Hook('theme')]
  public function theme($existing, $type, $theme, $path): array {
    return [
      'localgov_waste_collection_form' => [
        'template' => 'localgov-waste-collection-form',
        'variables' => [
          'form' => NULL,
          'noresults' => NULL,
        ],
      ],
      'localgov_waste_collection_property_list' => [
        'template' => 'localgov-waste-collection-property-list',
        'variables' => [
          'form' => NULL,
          'postcode' => NULL,
          'properties' => NULL,
        ],
      ],
      'localgov_waste_collection_view_schedule' => [
        'template' => 'localgov-waste-collection-view-schedule',
        'variables' => [
          'address' => NULL,
          'uprn' => NULL,
          'service_updates_path' => NULL,
          'collection_time' => NULL,
          'pdf' => NULL,
          'next_collection_date' => NULL,
          'next_collection_labels' => [],
          'calendar_range_label' => '',
          'collections' => [],
          'dates' => [],
          'show_ics_download' => FALSE,
          'show_webcal_subscribe' => TRUE,
          'webcal_url' => NULL,
        ],
      ],
      'localgov_waste_collection_collection_item' => [
        'template' => 'localgov-waste-collection-collection-item',
        'variables' => [
          'date' => NULL,
          'label' => '',
          'colour' => '',
          'colour_name' => '',
          'holiday' => FALSE,
          'service_updates_path' => NULL,
        ],
      ],
    ];
  }

}
