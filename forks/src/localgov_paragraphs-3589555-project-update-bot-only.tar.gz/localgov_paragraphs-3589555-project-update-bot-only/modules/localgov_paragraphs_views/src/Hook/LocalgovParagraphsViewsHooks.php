<?php

namespace Drupal\localgov_paragraphs_views\Hook;

use Drupal\Core\Hook\Attribute\Hook;

/**
 * Hook implementations for localgov_paragraphs_views.
 */
class LocalgovParagraphsViewsHooks {
  /**
   * @file
   * LocalGovDrupal Paragraphs Views module file.
   */

  /**
   * Implements hook_preprocess_HOOK().
   */
  #[Hook('preprocess_paragraph')]
  public function preprocessParagraph(&$variables) {
    /** @var \Drupal\paragraphs\Entity\Paragraph $paragraph */
    $paragraph = $variables['paragraph'];
    // Create heading element for paragraphs with a heading level field and
    // non-empty title field.
    if ($paragraph->hasField('localgov_heading_level') && $paragraph->hasField('localgov_title') && !$paragraph->get('localgov_title')->isEmpty()) {
      $heading_text = $paragraph->get('localgov_title')->value;
      $heading_level = $paragraph->get('localgov_heading_level')->value;
      if (is_string($heading_level)) {
        $variables['heading'] = _localgov_paragraphs_views_create_heading($heading_text, $heading_level);
      }
    }
  }

}
