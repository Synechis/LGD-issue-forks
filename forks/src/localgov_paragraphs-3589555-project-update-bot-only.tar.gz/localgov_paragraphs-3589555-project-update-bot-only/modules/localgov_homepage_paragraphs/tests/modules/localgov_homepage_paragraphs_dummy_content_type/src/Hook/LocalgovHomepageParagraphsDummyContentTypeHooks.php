<?php

namespace Drupal\localgov_homepage_paragraphs_dummy_content_type\Hook;

use Drupal\Core\Hook\Attribute\Hook;

/**
 * Hook implementations for localgov_homepage_paragraphs_dummy_content_type.
 */
class LocalgovHomepageParagraphsDummyContentTypeHooks {

  /**
   * Implements hook_theme().
   *
   * - Overrides paragraph template for Newsroom teaser, Homepage icons, and
   *   Homepage IA blocks.
   * - Overrides field template for field_newsroom, field_homepage_icons, and
   *   field_ia_blocks.
   */
  #[Hook('theme')]
  public function theme($existing, $type, $theme, $path) {
    return [
      'field__localgov_homepage_newsroom' => [
        'base hook' => 'field',
      ],
      'field__localgov_homepage_labelled_icons' => [
        'base hook' => 'field',
      ],
      'field__localgov_homepage_ia_blocks' => [
        'base hook' => 'field',
      ],
    ];
  }

}
