<?php

namespace Drupal\localgov_paragraphs_layout\Hook;

use Drupal\Core\Form\FormStateInterface;
use Drupal\Core\Hook\Attribute\Hook;

/**
 * Hook implementations for localgov_paragraphs_layout.
 */
class LocalgovParagraphsLayoutHooks {

  /**
   * Implements hook_form_alter().
   */
  #[Hook('form_alter')]
  public function formAlter(&$form, FormStateInterface $form_state, $form_id) {
    // Hide useless admin options when adding new section using Layout Paragraphs.
    if (isset($form['localgov_paragraph_content']['widget']['entity_form']['layout_plugin_form'])) {
      $form['localgov_paragraph_content']['widget']['entity_form']['layout_plugin_form']['#access'] = FALSE;
    }
  }

}
