<?php

declare(strict_types=1);

namespace Drupal\localgov\Form;

use Drupal\Core\Extension\ModuleExtensionList;
use Drupal\Core\Form\FormBase;
use Drupal\Core\Form\FormStateInterface;
use Drupal\Core\State\StateInterface;
use Symfony\Component\DependencyInjection\ContainerInterface;

/**
 * Form for selecting the crop tool, shown during installation.
 *
 * Runs before any module is installed; localgov_install() then installs the
 * selected tool, and no other. See localgov_install_tasks_alter().
 */
class CropToolForm extends FormBase {

  /**
   * The state key the chosen tool is stored under.
   */
  const STATE_KEY = 'localgov_media.crop_tool';

  /**
   * The module each tool needs in the codebase, keyed by tool.
   */
  const MODULES = [
    'manual_crop' => 'image_widget_crop',
    'focal_point' => 'focal_point',
  ];

  /**
   * Constructs the form.
   *
   * @param \Drupal\Core\State\StateInterface $state
   *   The state service.
   * @param \Drupal\Core\Extension\ModuleExtensionList $moduleList
   *   The module extension list.
   */
  public function __construct(
    protected StateInterface $state,
    protected ModuleExtensionList $moduleList,
  ) {}

  /**
   * {@inheritdoc}
   */
  public static function create(ContainerInterface $container) {
    return new static(
      $container->get('state'),
      $container->get('extension.list.module'),
    );
  }

  /**
   * {@inheritdoc}
   */
  public function getFormId(): string {
    return 'localgov_crop_tool';
  }

  /**
   * {@inheritdoc}
   */
  public function buildForm(array $form, FormStateInterface $form_state): array {
    $form['#title'] = $this->t('Choose crop tool');
    $form['tool'] = [
      '#type' => 'radios',
      '#title' => $this->t('Crop tool'),
      '#description' => $this->t('How editors set the framing of an image. The site keeps the tool it is built with: moving to the other one afterwards is a migration, not a setting.'),
      '#options' => $this->options(),
      '#default_value' => 'manual_crop',
    ];
    $form['actions'] = ['#type' => 'actions'];
    $form['actions']['submit'] = [
      '#type' => 'submit',
      '#value' => $this->t('Save and continue'),
      '#button_type' => 'primary',
    ];
    return $form;
  }

  /**
   * Returns the tools whose widget module is in this codebase.
   *
   * drupal/focal_point is a suggestion of localgov_core, not a requirement.
   *
   * @return array
   *   Labels keyed by tool.
   */
  protected function options(): array {
    $options = [
      'manual_crop' => $this->t('Manual crop (recommended): a crop per shape, per image'),
      'focal_point' => $this->t('Focal point: one point per image, every shape cropped around it. Freestyle images are not cropped at all.'),
    ];
    foreach (self::MODULES as $tool => $module) {
      if (!$this->moduleList->exists($module)) {
        unset($options[$tool]);
      }
    }
    return $options;
  }

  /**
   * {@inheritdoc}
   */
  public function submitForm(array &$form, FormStateInterface $form_state): void {
    $this->state->set(self::STATE_KEY, $form_state->getValue('tool'));
  }

}
