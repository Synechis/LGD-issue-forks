<?php

declare(strict_types=1);

namespace Drupal\Tests\localgov\Functional;

use Drupal\localgov_media\CropTools;
use Drupal\localgov_media\Hook\MediaHooks;
use Drupal\Tests\BrowserTestBase;
use PHPUnit\Framework\Attributes\Group;
use PHPUnit\Framework\Attributes\RunTestsInSeparateProcesses;

/**
 * Tests installing the profile with the crop tool form left at its default.
 *
 * The default is manual_crop. For focal_point, see
 * CropToolFocalPointInstallTest.
 *
 * @group localgov
 */
#[Group('localgov')]
#[RunTestsInSeparateProcesses]
class MediaInstallTest extends BrowserTestBase {

  /**
   * {@inheritdoc}
   */
  protected $profile = 'localgov';

  /**
   * {@inheritdoc}
   */
  protected $defaultTheme = 'stark';

  /**
   * Tests the installed modules, image styles, crop types and image widget.
   */
  public function testManualCropIsTheDefault(): void {
    $modules = \Drupal::moduleHandler();
    $installed = [
      'localgov_media',
      'localgov_media_document',
      'localgov_media_image',
      'localgov_media_image_manual_crop',
      'localgov_media_video',
      'localgov_media_wysiwyg',
      'image_widget_crop',
    ];
    foreach ($installed as $module) {
      $this->assertTrue($modules->moduleExists($module), "$module is installed by the profile");
    }
    $this->assertFalse($modules->moduleExists('localgov_media_legacy'), 'A new site has nothing to keep from before 3.4');
    $this->assertFalse($modules->moduleExists('localgov_media_microsites'), 'LocalGov shapes, not Microsites ones');
    $this->assertFalse($modules->moduleExists('localgov_media_image_focal_point'));
    $this->assertFalse($modules->moduleExists('focal_point'));
    $this->assertNull(\Drupal::state()->get('localgov_media.crop_tool'), 'The state key is deleted once the tool is installed');

    $etm = \Drupal::entityTypeManager();
    $styles = array_keys($etm->getStorage('image_style')->loadMultiple());
    $this->assertCount(51, preg_grep('/^localgov_(\d+_\d+|freestyle)_\d+$/', $styles), 'Nine widths for three shapes, twelve for the two wide ones, no crop tool in the name');
    $this->assertCount(17, $etm->getStorage('responsive_image_style')->loadMultiple());
    $this->assertSame(['16_9', '1_1', '21_9', '4_3', 'freestyle'], array_keys($etm->getStorage('crop_type')->loadMultiple()));

    $teaser = $etm->getStorage('entity_view_display')->load('media.image.localgov_teaser')->getComponent('field_media_image');
    $this->assertSame('localgov_16_9_384', $teaser['settings']['image_style'], 'LocalGov teasers are 16:9');
    $default = $etm->getStorage('entity_view_display')->load('media.image.default');
    $this->assertNotNull($default, 'The default image display exists');
    $this->assertSame('localgov_16_9_large', $default->getComponent('field_media_image')['settings']['responsive_image_style']);
    $this->assertSame('image_widget_crop', $etm->getStorage('entity_form_display')->load('media.image.default')->getComponent('field_media_image')['type']);

    $this->drupalLogin($this->createUser(['create media', 'create image media', 'access content']));
    $this->drupalGet('media/add/image');
    $this->assertSession()->statusCodeEquals(200);
  }

  /**
   * Tests that focal point cannot be installed on the site afterwards.
   */
  public function testTheOtherToolIsRefusedAfterwards(): void {
    $rule = \Drupal::service(CropTools::class);
    $this->assertSame('manual_crop', $rule->applied());
    $refusal = (string) $rule->refusal(['localgov_media_image_focal_point']);
    $this->assertStringContainsString('One crop tool per site', $refusal);
    $this->assertStringContainsString('migration, not a module install', $refusal);
    $this->assertSame([], \Drupal::service(MediaHooks::class)->runtimeRequirements(), 'The status report is clean');
  }

}
