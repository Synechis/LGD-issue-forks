<?php

declare(strict_types=1);

namespace Drupal\Tests\localgov\Functional;

use Drupal\image\Entity\ImageStyle;
use Drupal\localgov_media\CropTools;
use Drupal\Tests\BrowserTestBase;
use PHPUnit\Framework\Attributes\Group;
use PHPUnit\Framework\Attributes\RunTestsInSeparateProcesses;

/**
 * Tests installing the profile with the crop tool form set to focal_point.
 *
 * installParameters() sets that form value the way drush site:install does:
 *
 *   drush si localgov localgov_crop_tool.tool=focal_point -y
 *
 * Skips where drupal/focal_point is absent; localgov.info.yml declares it
 * under test_dependencies for CI.
 *
 * @group localgov
 */
#[Group('localgov')]
#[RunTestsInSeparateProcesses]
class CropToolFocalPointInstallTest extends BrowserTestBase {

  /**
   * {@inheritdoc}
   */
  protected $profile = 'localgov';

  /**
   * {@inheritdoc}
   */
  protected $defaultTheme = 'stark';

  /**
   * {@inheritdoc}
   */
  protected function setUp(): void {
    // A file scan rather than ExtensionDiscovery: nothing is bootstrapped yet.
    $found = FALSE;
    foreach (['modules', 'profiles'] as $dir) {
      $found = $found || (bool) glob(DRUPAL_ROOT . "/$dir/*/focal_point/focal_point.info.yml")
        || (bool) glob(DRUPAL_ROOT . "/$dir/focal_point/focal_point.info.yml");
    }
    if (!$found) {
      $this->markTestSkipped('drupal/focal_point is not present in this build.');
    }
    parent::setUp();
  }

  /**
   * {@inheritdoc}
   */
  protected function installParameters() {
    $parameters = parent::installParameters();
    $parameters['forms']['localgov_crop_tool']['tool'] = 'focal_point';
    return $parameters;
  }

  /**
   * Tests the installed modules, image styles, crop types and image widget.
   */
  public function testFocalPoint(): void {
    $modules = \Drupal::moduleHandler();
    $this->assertTrue($modules->moduleExists('localgov_media_image'));
    $this->assertTrue($modules->moduleExists('localgov_media_image_focal_point'));
    $this->assertTrue($modules->moduleExists('focal_point'));
    $this->assertFalse($modules->moduleExists('localgov_media_image_manual_crop'));
    $this->assertFalse($modules->moduleExists('image_widget_crop'), 'The crop widget module is never installed');
    $this->assertNull(\Drupal::state()->get('localgov_media.crop_tool'), 'The state key is deleted once the tool is installed');

    $etm = \Drupal::entityTypeManager();
    $styles = array_keys($etm->getStorage('image_style')->loadMultiple());
    $localgov = preg_grep('/^localgov_(\d+_\d+|freestyle)_\d+$/', $styles);
    $this->assertCount(51, $localgov, 'The same ids as a manual crop site');
    $this->assertCount(0, preg_grep('/_(focal_point|manual_crop)$/', $styles), 'No crop tool in any name');
    $this->assertSame(['focal_point'], array_keys($etm->getStorage('crop_type')->loadMultiple()), 'No manual crop types were created on the way');

    $effects = array_column(array_values(ImageStyle::load('localgov_16_9_1152')->get('effects')), 'id');
    $this->assertSame('focal_point_scale_and_crop', $effects[0]);
    $this->assertNotContains('crop_crop', $effects);
    $this->assertSame(
      ['image_scale', 'image_convert'],
      array_column(array_values(ImageStyle::load('localgov_freestyle_1152')->get('effects')), 'id'),
      'Freestyle has no focal point equivalent: it scales'
    );

    $this->assertCount(17, $etm->getStorage('responsive_image_style')->loadMultiple(), 'From the layer, not the crop tool');
    $teaser = $etm->getStorage('entity_view_display')->load('media.image.localgov_teaser')->getComponent('field_media_image');
    $this->assertSame('localgov_16_9_384', $teaser['settings']['image_style']);
    $default = $etm->getStorage('entity_view_display')->load('media.image.default');
    $this->assertSame('localgov_16_9_large', $default->getComponent('field_media_image')['settings']['responsive_image_style']);
    $this->assertSame('image_focal_point', $etm->getStorage('entity_form_display')->load('media.image.default')->getComponent('field_media_image')['type']);

    $rule = \Drupal::service(CropTools::class);
    $this->assertSame('focal_point', $rule->applied());
    $this->assertStringContainsString('migration, not a module install', (string) $rule->refusal(['image_widget_crop']));

    $this->drupalLogin($this->createUser(['create media', 'create image media', 'access content']));
    $this->drupalGet('media/add/image');
    $this->assertSession()->statusCodeEquals(200);
  }

}
