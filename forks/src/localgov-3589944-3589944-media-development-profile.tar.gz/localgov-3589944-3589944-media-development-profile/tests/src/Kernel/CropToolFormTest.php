<?php

declare(strict_types=1);

namespace Drupal\Tests\localgov\Kernel;

use Drupal\Core\Form\FormState;
use Drupal\KernelTests\KernelTestBase;
use Drupal\localgov\Form\CropToolForm;
use PHPUnit\Framework\Attributes\Group;
use PHPUnit\Framework\Attributes\RunTestsInSeparateProcesses;

/**
 * Tests the crop tool selection form.
 *
 * @group localgov
 */
#[Group('localgov')]
#[RunTestsInSeparateProcesses]
class CropToolFormTest extends KernelTestBase {

  /**
   * {@inheritdoc}
   */
  protected static $modules = ['system', 'user'];

  /**
   * {@inheritdoc}
   */
  protected function setUp(): void {
    parent::setUp();
    $path = $this->container->get('extension.list.profile')->getPath('localgov');
    $this->container->get('class_loader')->addPsr4('Drupal\\localgov\\', DRUPAL_ROOT . '/' . $path . '/src');
  }

  /**
   * Tests the options offered and the default.
   *
   * Focal point is offered only where drupal/focal_point is in the codebase.
   */
  public function testChoices(): void {
    $form = $this->container->get('form_builder')->getForm(CropToolForm::class);
    $expected = ['manual_crop'];
    if ($this->container->get('extension.list.module')->exists('focal_point')) {
      $expected[] = 'focal_point';
    }
    $this->assertSame($expected, array_keys($form['tool']['#options']));
    $this->assertSame('manual_crop', $form['tool']['#default_value'], 'Manual crop is the recommended default');
    $this->assertEmpty($form['tool']['#required'], 'The radios are not marked required; there is always a default');
    $this->assertStringContainsString('moving to the other one afterwards is a migration', (string) $form['tool']['#description']);
  }

  /**
   * Tests that a valid selection is stored and an invalid one refused.
   */
  public function testChoiceIsStored(): void {
    $form_state = (new FormState())->setValues(['tool' => 'focal_point']);
    $this->container->get('form_builder')->submitForm(CropToolForm::class, $form_state);
    $this->assertSame([], $form_state->getErrors());
    $this->assertSame('focal_point', $this->container->get('state')->get(CropToolForm::STATE_KEY));

    $form_state = (new FormState())->setValues(['tool' => 'something_else']);
    $this->container->get('form_builder')->submitForm(CropToolForm::class, $form_state);
    $this->assertNotEmpty($form_state->getErrors(), 'A tool that is not offered is refused');
    $this->assertSame('focal_point', $this->container->get('state')->get(CropToolForm::STATE_KEY), 'And the stored choice is untouched');
  }

}
