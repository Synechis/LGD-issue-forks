<?php

namespace Drupal\localgov_alert_banner_collapsible\Event;

use Drupal\Component\EventDispatcher\Event;
use Drupal\Component\Render\MarkupInterface;

/**
 * Event that is fired when generating an alert banner summary.
 */
class AlertBannerCollapsibleGenerateSummaryEvent extends Event {

  const EVENT_NAME = 'localgov_alert_banner_collapsible.generate_summary';

  /**
   * Summary.
   *
   * @var \Drupal\Component\Render\MarkupInterface|array|string|null
   */
  private $summary = NULL;

  /**
   * Construct and new AlertBannerCollapsibleGenerateSummaryEvent.
   *
   * @param array $alertBanners
   *   Array of alert banner entities.
   * @param array $alertBannerTitles
   *   Array of alert banner titles.
   * @param int $maxBeforeSummary
   *   Number of alerts to show before the summary (from block config)
   */
  public function __construct(
    private readonly array $alertBanners,
    private readonly array $alertBannerTitles,
    private readonly int $maxBeforeSummary,
  ) {}

  /**
   * Get alert banner entities.
   *
   * @return array
   *   Array of alert banner entities.
   */
  public function getAlertBanners():array {
    return $this->alertBanners;
  }

  /**
   * Get alert banner titles.
   *
   * @return array
   *   Array of alert banner titles.
   */
  public function getAlertBannerTitles():array {
    return $this->alertBannerTitles;
  }

  /**
   * Get number of alert banners.
   *
   * @return int
   *   Int of number of alert banners.
   */
  public function numberOfAlertBanners():int {
    return count($this->alertBanners);
  }

  /**
   * Get max number of alert banners before summary.
   *
   * This is user configurable on the block.
   *
   * @return int
   *   Number of alert banners to show before the show more.
   */
  public function getMaxBeforeSummary():int {
    return $this->maxBeforeSummary;
  }

  /**
   * Get the set summary.
   *
   * @return \Drupal\Component\Render\MarkupInterface|array|string|null
   *   The set summary, recommended to be MarkupInterface, could also be a
   *   render array or a string.
   *   If set to NULL, the default summary will be used.
   */
  public function getSummary():MarkupInterface|array|string|null {
    return $this->summary;
  }

  /**
   * Set the summary for the collapsible alert banner.
   *
   * @param \Drupal\Component\Render\MarkupInterface|array|string $summary
   *   Used to set the summary. Recommended to be MarkupInterface
   *   (eg. use $this->t) for translated strings.
   *   Could also be a render array or a string.
   */
  public function setSummary(MarkupInterface|array|string $summary):void {
    $this->summary = $summary;
  }

}
