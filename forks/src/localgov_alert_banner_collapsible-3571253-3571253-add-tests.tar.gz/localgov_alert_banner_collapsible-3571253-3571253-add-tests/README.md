# LocalGov Drupal Alert banner collapsible

Adds a new collapsiple alert banner block so that alert banners can be collapsed and expanded instead of hidden, so it's possible to get them back again.

## Cavets

This is an experimental module.
Alert banners where the field 'remove_hide_link' is set will be displayed in a persistent alerts section above the collapsible block.
This currently won't set the hide-alert-banner-token cookie, and has no means of determining if a user has already seen an alert banner.

## Dependencies

- [Localgov alert banner](https://github.com/localgovdrupal/localgov_alert_banner)

## Changing the alert banner summary

Implement an event subscriber for the following event: 
\Drupal\localgov_alert_banner_collapsible\Event\AlertBannerCollapsibleGenerateSummaryEvent::EVENT_NAME
and set `$event->summary($summary)` with either a MarkupInterface or render array.

### Example

```
<?php

declare(strict_types=1);

namespace Drupal\my_module\EventSubscriber;

use Drupal\Core\StringTranslation\StringTranslationTrait;
use Drupal\localgov_alert_banner_collapsible\Event\AlertBannerCollapsibleGenerateSummaryEvent;
use Symfony\Component\EventDispatcher\EventSubscriberInterface;

/**
 * Set the summary of the collapisble alert banner.
 */
final class LocalgovAlertBannerSummary implements EventSubscriberInterface {

  use StringTranslationTrait;

  public function generateSummary(AlertBannerCollapsibleGenerateSummaryEvent $event) {

    $max_before_summary = $event->getMaxBeforeSummary();
    $num_banners = $event->getNumberOfAlertBanners();
    $banner_titles = $event->getAlertBannerTitles();
    if ($num_banners === 1) {
      $summary = $this->t('1 alert: @single_alert_banner_title', [
        '@single_alert_banner_title' => reset($banner_titles),
      ]);
    }
    elseif ($num_banners === 2 && $max_before_summary >= 2) {
      $summary = $this->t('@number_of_alert_banners alerts: @first_alert_banner_title and @second_alert_banner_title', [
        '@number_of_alert_banners' => $num_banners,
        '@first_alert_banner_title' => reset($banner_titles),
        '@second_alert_banner_title' => end($banner_titles),
      ]);
    }
    elseif ($num_banners <= $max_before_summary) {
      $summary = $this->t('@number_of_alert_banners alerts: @multiple_alert_banner_titles and @last_alert_banner_title', [
        '@number_of_alert_banners' => $num_banners,
        '@multiple_alert_banner_titles' => implode(', ', $banner_titles),
        '@last_alert_banner_title' => end($banner_titles),
      ]);
    }
    else {
      $summary = t('@number_of_alert_banners alerts: @multiple_alert_banner_titles and @number_of_additional_alert_banners more', [
        '@number_of_alert_banners' => $num_banners,
        '@multiple_alert_banner_titles' => implode(', ', array_slice($banner_titles, 0, $max_before_summary)),
        '@number_of_additional_alert_banners' => count(array_slice($banner_titles, $max_before_summary)),
      ]);
    }

    $event->setSummary($summary);
  }

  /**
   * {@inheritdoc}
   */
  public static function getSubscribedEvents(): array {
    return [
      AlertBannerCollapsibleGenerateSummaryEvent::EVENT_NAME => ['generateSummary'],
    ];
  }

}
```

## Maintainers

 Current maintainers: 

  - AndyB https://github.com/andybroomfield
