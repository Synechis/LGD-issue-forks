<?php

declare(strict_types=1);

namespace Drupal\Tests\localgov_alert_banner_collapsible\FunctionalJavascript;

use Drupal\FunctionalJavascriptTests\WebDriverTestBase;
use Drupal\localgov_alert_banner\Entity\AlertBannerEntity;

/**
 * Tests collapsible alert banner functionality.
 *
 * @group localgov_alert_banner_collapsible
 */
final class CollapsibleBannerTest extends WebDriverTestBase {

  /**
   * {@inheritdoc}
   */
  protected $defaultTheme = 'stark';

  /**
   * {@inheritdoc}
   */
  protected static $modules = [
    'block',
    'path',
    'options',
    'node',
    'workflows',
    'content_moderation',
    'condition_field',
    'localgov_alert_banner',
    'localgov_alert_banner_collapsible',
  ];

  /**
   * The block instance.
   *
   * @var \Drupal\block\Entity\Block
   */
  protected $block;

  /**
   * {@inheritdoc}
   */
  protected function setUp(): void {
    parent::setUp();

    // Create and place the collapsible alert banner block.
    $admin_user = $this->drupalCreateUser(['administer blocks']);
    $this->drupalLogin($admin_user);
    $this->block = $this->drupalPlaceBlock('localgov_alert_banner_collapsible', [
      'region' => 'content',
      'id' => 'alert_banner_collapsible',
    ]);
  }

  /**
   * Tests that collapsible banner displays correctly.
   */
  public function testCollapsibleBannerDisplays(): void {
    // Create an alert banner.
    $banner = AlertBannerEntity::create([
      'type' => 'localgov_alert_banner',
      'title' => 'Test Alert Banner',
      'short_description' => 'This is a test alert',
      'link' => [
        'uri' => 'https://example.com',
        'title' => 'More info',
      ],
      'moderation_state' => 'published',
      'visibility' => [],
    ]);
    $banner->save();

    // Visit the front page.
    $this->drupalGet('<front>');

    // Assert the collapsible pane is present.
    $this->assertSession()->elementExists('css', '.localgov-alert-banner-collapsible-pane');

    // Assert the control button is present.
    $this->assertSession()->elementExists('css', '.js-alert-banner-pane-button');

    // Assert the summary is displayed.
    $this->assertSession()->pageTextContains('1 alert: Test Alert Banner');

    // Assert the alert banner content is in the collapsible section.
    $this->assertSession()->elementExists('css', '.js-alert-banner-pane-content');
  }

  /**
   * Tests that the collapsible banner can change state.
   */
  public function testCollapsibleBannerChangesState(): void {
    // Create an alert banner.
    $banner = AlertBannerEntity::create([
      'type' => 'localgov_alert_banner',
      'title' => 'Test Alert Banner',
      'short_description' => 'This is a test alert',
      'moderation_state' => 'published',
      'visibility' => [],
    ]);
    $banner->save();

    // Visit the front page.
    $this->drupalGet('<front>');

    // Get the button and content elements.
    $button = $this->assertSession()->elementExists('css', '.js-alert-banner-pane-button');
    $content = $this->assertSession()->elementExists('css', '.js-alert-banner-pane-content');

    // By default (state 0), content should be hidden.
    $this->assertTrue($content->hasClass('hidden'), 'Content should be hidden by default');
    $this->assertEquals('false', $button->getAttribute('aria-expanded'), 'Button aria-expanded should be false');
    $this->assertEquals('Show alert banners', $button->getText(), 'Button should show "Show alert banners" text');

    // Click the button to expand.
    $button->click();
    $this->assertSession()->waitForElementRemoved('css', '.js-alert-banner-pane-content.hidden');

    // Assert content is visible.
    $this->assertFalse($content->hasClass('hidden'), 'Content should be visible after clicking');
    $this->assertEquals('true', $button->getAttribute('aria-expanded'), 'Button aria-expanded should be true');
    $this->assertEquals('Hide alert banners', $button->getText(), 'Button should show "Hide alert banners" text');

    // Click again to collapse.
    $button->click();
    $this->assertSession()->waitForElement('css', '.js-alert-banner-pane-content.hidden');

    // Assert content is hidden again.
    $this->assertTrue($content->hasClass('hidden'), 'Content should be hidden after clicking again');
    $this->assertEquals('false', $button->getAttribute('aria-expanded'), 'Button aria-expanded should be false');
    $this->assertEquals('Show alert banners', $button->getText(), 'Button should show "Show alert banners" text');
  }

  /**
   * Tests that the banner state is remembered between page loads.
   */
  public function testStatePersistsBetweenPageLoads(): void {
    // Create an alert banner.
    $banner = AlertBannerEntity::create([
      'type' => 'localgov_alert_banner',
      'title' => 'Test Alert Banner',
      'short_description' => 'This is a test alert',
      'moderation_state' => 'published',
      'visibility' => [],
    ]);
    $banner->save();

    // Visit the front page.
    $this->drupalGet('<front>');

    // Get the button and expand the banner.
    $button = $this->assertSession()->elementExists('css', '.js-alert-banner-pane-button');
    $button->click();
    $this->assertSession()->waitForElementRemoved('css', '.js-alert-banner-pane-content.hidden');

    // Verify it's expanded.
    $content = $this->assertSession()->elementExists('css', '.js-alert-banner-pane-content');
    $this->assertFalse($content->hasClass('hidden'), 'Content should be visible');

    // Reload the page.
    $this->drupalGet('<front>');

    // Assert the banner is still expanded.
    $content = $this->assertSession()->elementExists('css', '.js-alert-banner-pane-content');
    $button = $this->assertSession()->elementExists('css', '.js-alert-banner-pane-button');
    $this->assertFalse($content->hasClass('hidden'), 'Content should still be visible after page reload');
    $this->assertEquals('true', $button->getAttribute('aria-expanded'), 'Button aria-expanded should be true');
    $this->assertEquals('Hide alert banners', $button->getText(), 'Button should show "Hide alert banners" text');

    // Collapse it.
    $button->click();
    $this->assertSession()->waitForElement('css', '.js-alert-banner-pane-content.hidden');

    // Reload again.
    $this->drupalGet('<front>');

    // Assert it's still collapsed.
    $content = $this->assertSession()->elementExists('css', '.js-alert-banner-pane-content');
    $button = $this->assertSession()->elementExists('css', '.js-alert-banner-pane-button');
    $this->assertTrue($content->hasClass('hidden'), 'Content should be hidden after page reload');
    $this->assertEquals('false', $button->getAttribute('aria-expanded'), 'Button aria-expanded should be false');
  }

  /**
   * Tests that persistent banners show above the collapsible section.
   */
  public function testPersistentBannersShowAboveCollapsible(): void {
    // Create a regular banner.
    $regular_banner = AlertBannerEntity::create([
      'type' => 'localgov_alert_banner',
      'title' => 'Regular Alert Banner',
      'short_description' => 'This is a regular alert',
      'remove_hide_link' => 0,
      'moderation_state' => 'published',
      'visibility' => [],
    ]);
    $regular_banner->save();

    // Create a persistent banner (with remove_hide_link = TRUE).
    $persistent_banner = AlertBannerEntity::create([
      'type' => 'localgov_alert_banner',
      'title' => 'Persistent Alert Banner',
      'short_description' => 'This is a persistent alert',
      'remove_hide_link' => 1,
      'moderation_state' => 'published',
      'visibility' => [],
    ]);
    $persistent_banner->save();

    // Visit the front page.
    $this->drupalGet('<front>');

    // Assert the persistent banner section exists.
    $persistent_section = $this->assertSession()->elementExists('css', '.localgov-alert-banner-peristant-banners');

    // Assert the collapsible section exists.
    $collapsible_section = $this->assertSession()->elementExists('css', '.localgov-alert-banner-collapsible-pane');

    // Expand the collapsible section to make content visible.
    $button = $this->assertSession()->elementExists('css', '.js-alert-banner-pane-button');
    $button->click();
    $this->assertSession()->waitForElementRemoved('css', '.js-alert-banner-pane-content.hidden');

    // Assert the persistent section comes before the collapsible section.
    $persistent_html = $persistent_section->getOuterHtml();
    $collapsible_html = $collapsible_section->getOuterHtml();
    $page_html = $this->getSession()->getPage()->getHtml();
    $persistent_pos = strpos($page_html, $persistent_html);
    $collapsible_pos = strpos($page_html, $collapsible_html);
    $this->assertLessThan($collapsible_pos, $persistent_pos, 'Persistent banners should appear before collapsible section');

    // Assert persistent banner title is in the persistent section.
    $this->assertSession()->pageTextContains('Persistent Alert Banner');
    $this->assertSession()->elementTextContains('css', '.localgov-alert-banner-peristant-banners', 'Persistent Alert Banner');

    // Assert regular banner is NOT in the persistent section
    // (should be in collapsible).
    $persistent_text = $persistent_section->getText();
    $this->assertStringNotContainsString('Regular Alert Banner', $persistent_text, 'Regular banner should not be in persistent section');

    // Assert regular banner is in the collapsible section.
    $this->assertSession()->pageTextContains('Regular Alert Banner');
    $collapsible_content = $this->assertSession()->elementExists('css', '.js-alert-banner-pane-content');
    $this->assertSession()->elementTextContains('css', '.js-alert-banner-pane-content', 'Regular Alert Banner');

    // Assert the summary only counts the regular banner,
    // not the persistent one.
    $this->assertSession()->pageTextContains('1 alert: Regular Alert Banner');
  }

  /**
   * Tests banner summary with a single alert.
   */
  public function testBannerSummaryWithSingleAlert(): void {
    // Create a single banner.
    $banner = AlertBannerEntity::create([
      'type' => 'localgov_alert_banner',
      'title' => 'Single Alert',
      'short_description' => 'Test',
      'moderation_state' => 'published',
      'visibility' => [],
    ]);
    $banner->save();

    $this->drupalGet('<front>');

    // Assert the summary for a single alert.
    $this->assertSession()->pageTextContains('1 alert: Single Alert');
  }

  /**
   * Tests banner summary with multiple alerts under the threshold.
   */
  public function testBannerSummaryWithMultipleAlertsUnderThreshold(): void {
    // Create 3 banners (default threshold is 3).
    for ($i = 1; $i <= 3; $i++) {
      $banner = AlertBannerEntity::create([
        'type' => 'localgov_alert_banner',
        'title' => "Alert Banner $i",
        'short_description' => "Test $i",
        'moderation_state' => 'published',
        'visibility' => [],
      ]);
      $banner->save();
    }

    $this->drupalGet('<front>');

    // Assert the summary shows all titles.
    $this->assertSession()->pageTextContains('3 alerts: Alert Banner 1; Alert Banner 2; Alert Banner 3');
  }

  /**
   * Tests banner summary with alerts exceeding the threshold.
   */
  public function testBannerSummaryExceedingThreshold(): void {
    // Create 5 banners (default threshold is 3).
    for ($i = 1; $i <= 5; $i++) {
      $banner = AlertBannerEntity::create([
        'type' => 'localgov_alert_banner',
        'title' => "Alert Banner $i",
        'short_description' => "Test $i",
        'moderation_state' => 'published',
        'visibility' => [],
      ]);
      $banner->save();
    }

    $this->drupalGet('<front>');

    // Assert the summary shows first 3 titles and "and 2 more".
    $this->assertSession()->pageTextContains('5 alerts: Alert Banner 1; Alert Banner 2; Alert Banner 3; and 2 more');
  }

  /**
   * Tests banner summary with custom threshold setting.
   */
  public function testBannerSummaryWithCustomThreshold(): void {
    // Update block configuration to set threshold to 2.
    $this->block->getPlugin()->setConfigurationValue('max_titles_before_summary', 2);
    $this->block->save();

    // Create 4 banners.
    for ($i = 1; $i <= 4; $i++) {
      $banner = AlertBannerEntity::create([
        'type' => 'localgov_alert_banner',
        'title' => "Alert Banner $i",
        'short_description' => "Test $i",
        'moderation_state' => 'published',
        'visibility' => [],
      ]);
      $banner->save();
    }

    $this->drupalGet('<front>');

    // Assert the summary shows first 2 titles and "and 2 more".
    $this->assertSession()->pageTextContains('4 alerts: Alert Banner 1; Alert Banner 2; and 2 more');
  }

  /**
   * Tests that block doesn't display when there are no alert banners.
   */
  public function testBlockDoesNotDisplayWithNoAlerts(): void {
    // Visit the front page without creating any banners.
    $this->drupalGet('<front>');

    // Assert the collapsible pane is NOT present.
    $this->assertSession()->elementNotExists('css', '.localgov-alert-banner-collapsible-pane');
  }

  /**
   * Tests default open state configuration.
   */
  public function testDefaultOpenState(): void {
    // Update block configuration to default to open (state 1).
    $this->block->getPlugin()->setConfigurationValue('default_state', '1');
    $this->block->save();

    // Create an alert banner.
    $banner = AlertBannerEntity::create([
      'type' => 'localgov_alert_banner',
      'title' => 'Test Alert Banner',
      'short_description' => 'This is a test alert',
      'moderation_state' => 'published',
      'visibility' => [],
    ]);
    $banner->save();

    // Clear localStorage to ensure default state is used.
    $this->getSession()->executeScript("window.localStorage.removeItem('localgovAlertBannerCollapsibleState');");

    // Visit the front page.
    $this->drupalGet('<front>');

    // Get the button and content elements.
    $button = $this->assertSession()->elementExists('css', '.js-alert-banner-pane-button');
    $content = $this->assertSession()->elementExists('css', '.js-alert-banner-pane-content');

    // Content should be visible by default (not hidden).
    $this->assertFalse($content->hasClass('hidden'), 'Content should be visible by default when state is set to open');
    $this->assertEquals('true', $button->getAttribute('aria-expanded'), 'Button aria-expanded should be true');
    $this->assertEquals('Hide alert banners', $button->getText(), 'Button should show "Hide alert banners" text');
  }

  /**
   * Tests custom open and closed labels.
   */
  public function testCustomLabels(): void {
    // Update block configuration with custom labels.
    $this->block->getPlugin()->setConfigurationValue('open_label', 'Custom Hide Text');
    $this->block->getPlugin()->setConfigurationValue('closed_label', 'Custom Show Text');
    $this->block->getPlugin()->setConfigurationValue('default_state', '0');
    $this->block->save();

    // Create an alert banner.
    $banner = AlertBannerEntity::create([
      'type' => 'localgov_alert_banner',
      'title' => 'Test Alert Banner',
      'short_description' => 'This is a test alert',
      'moderation_state' => 'published',
      'visibility' => [],
    ]);
    $banner->save();

    // Visit the front page.
    $this->drupalGet('<front>');

    // Get the button.
    $button = $this->assertSession()->elementExists('css', '.js-alert-banner-pane-button');

    // Should show custom closed label initially.
    $this->assertEquals('Custom Show Text', $button->getText(), 'Button should show custom closed label');

    // Click to expand.
    $button->click();
    $this->assertSession()->waitForElementRemoved('css', '.js-alert-banner-pane-content.hidden');

    // Should show custom open label.
    $this->assertEquals('Custom Hide Text', $button->getText(), 'Button should show custom open label');
  }

  /**
   * Tests that hide buttons are removed from collapsible alert banners.
   */
  public function testHideButtonsRemovedFromCollapsibleBanners(): void {
    // Create a regular banner (without remove_hide_link).
    $banner = AlertBannerEntity::create([
      'type' => 'localgov_alert_banner',
      'title' => 'Test Alert Banner',
      'short_description' => 'This is a test alert',
      'remove_hide_link' => 0,
      'moderation_state' => 'published',
      'visibility' => [],
    ]);
    $banner->save();

    // Visit the front page.
    $this->drupalGet('<front>');

    // Expand the collapsible section to see the banner.
    $button = $this->assertSession()->elementExists('css', '.js-alert-banner-pane-button');
    $button->click();
    $this->assertSession()->waitForElementRemoved('css', '.js-alert-banner-pane-content.hidden');

    // Assert that close buttons within the collapsible
    // content have been removed.
    $close_buttons = $this->getSession()->getPage()->findAll('css', '.js-alert-banner-pane-content .js-localgov-alert-banner__close');
    $this->assertCount(0, $close_buttons, 'Hide buttons should be removed from collapsible alert banners');
  }

}
