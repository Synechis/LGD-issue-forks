<?php

namespace Drupal\group_alert_banner\Hook;

use Drupal\localgov_alert_banner\Entity\AlertBannerEntityTypeInterface;
use Drupal\Core\Hook\Attribute\Hook;

/**
 * Hook implementations for group_alert_banner.
 */
class GroupAlertBannerHooks {

  /**
   * Implements hook_ENTITY_TYPE_insert().
   *
   * This is necessary during configuration imports.  This makes the plugin
   * definitions from this module immediately available to other config files.
   */
  #[Hook('localgov_alert_banner_type_insert')]
  public function localgovAlertBannerTypeInsert(AlertBannerEntityTypeInterface $banner_type) {
    \Drupal::service('group_relation_type.manager')->clearCachedDefinitions();
  }

  /**
   * Implements hook_localgov_microsites_roles_default().
   *
   * Defines default site-wide and group-specific Alert banner permissions.
   *
   * @see Drupal\localgov_microsites_group\RolesHelper::getModuleRoles()
   */
  #[Hook('localgov_microsites_roles_default')]
  public function localgovMicrositesRolesDefault() {
    $alert_banner_related_role_permissions = [
          // phpcs:disable Drupal.Classes.FullyQualifiedNamespace
      'global' => [
              // @phpstan-ignore-next-line
        \Drupal\localgov_microsites_group\RolesHelper::MICROSITES_CONTROLLER_ROLE => [
          'access localgov alert banner listing page',
          'use localgov_alert_banners transition create_new_draft',
          'use localgov_alert_banners transition publish',
          'use localgov_alert_banners transition unpublish',
          'view all localgov alert banner entities',
          'view all localgov alert banner entity pages',
        ],
              // @phpstan-ignore-next-line
        \Drupal\localgov_microsites_group\RolesHelper::MICROSITES_EDITOR_ROLE => [
          'access localgov alert banner listing page',
          'use localgov_alert_banners transition create_new_draft',
          'use localgov_alert_banners transition publish',
          'use localgov_alert_banners transition unpublish',
          'view all localgov alert banner entities',
          'view all localgov alert banner entity pages',
        ],
      ],
      'group' => [
              // @phpstan-ignore-next-line
        \Drupal\localgov_microsites_group\RolesHelper::GROUP_ADMIN_ROLE => [
          'access localgov_alert_banner overview',
          'create group_localgov_alert_banner:localgov_alert_banner entity',
          'create group_localgov_alert_banner:localgov_alert_banner relationship',
          'delete any group_localgov_alert_banner:localgov_alert_banner entity',
          'delete own group_localgov_alert_banner:localgov_alert_banner entity',
          'delete any group_localgov_alert_banner:localgov_alert_banner relationship',
          'delete own group_localgov_alert_banner:localgov_alert_banner relationship',
          'update any group_localgov_alert_banner:localgov_alert_banner entity',
          'update own group_localgov_alert_banner:localgov_alert_banner entity',
          'update any group_localgov_alert_banner:localgov_alert_banner relationship',
          'update own group_localgov_alert_banner:localgov_alert_banner relationship',
          'view group_localgov_alert_banner:localgov_alert_banner entity',
          'view group_localgov_alert_banner:localgov_alert_banner relationship',
          'view any unpublished group_localgov_alert_banner:localgov_alert_banner entity',
        ],
              // @phpstan-ignore-next-line
        \Drupal\localgov_microsites_group\RolesHelper::GROUP_MEMBER_ROLE => [
          'access localgov_alert_banner overview',
          'view group_localgov_alert_banner:localgov_alert_banner entity',
        ],
              // @phpstan-ignore-next-line
        \Drupal\localgov_microsites_group\RolesHelper::GROUP_OUTSIDER_ROLE => [
          'view group_localgov_alert_banner:localgov_alert_banner entity',
        ],
              // @phpstan-ignore-next-line
        \Drupal\localgov_microsites_group\RolesHelper::GROUP_ANONYMOUS_ROLE => [
          'view group_localgov_alert_banner:localgov_alert_banner entity',
        ],
      ],
    ];
    return $alert_banner_related_role_permissions;
  }

  /**
   * Implements hook_query_TAG_alter().
   *
   * On group pages, only list group banners belonging to the current group OR
   * site-wide banners.
   */
  #[Hook('query_entity_query_alter')]
  public function queryEntityQueryAlter(\Drupal\Core\Database\Query\AlterableInterface $query) {
    if (!$query instanceof \Drupal\Core\Database\Query\SelectInterface) {
      return;
    }
    $entity_type_id = $query->getMetaData('entity_type');
    if ($entity_type_id !== 'localgov_alert_banner' || !$query->hasTag($entity_type_id . '_access')) {
      return;
    }
    $group = \Drupal::service('group.group_route_context')->getGroupFromRoute();
    $gid = empty($group) ? -1 : $group->id();
    if (empty($group) && \Drupal::getContainer()->has('domain_group_resolver')) {
      $gid_from_domain = \Drupal::service('domain_group_resolver')->getActiveDomainGroupId();
      $gid = $gid_from_domain ?? $gid;
    }
    // The 'gcfd' table alias is set in
    // Drupal\group\QueryAccess\EntityQueryAlter::doAlter() for the
    // group_relationship_field_data table.
    $table_aliases = $query->getTables();
    if (array_key_exists('gcfd', $table_aliases)) {
      $query->where('(gcfd.entity_id IS NOT NULL AND gcfd.gid = :gid) OR gcfd.entity_id IS NULL', [
        ':gid' => $gid,
      ]);
    }
  }

  /**
   * Implements hook_block_build_alter().
   *
   * Alterations:
   * - Adds the "route.group" context to alert blocks.  This lets us list
   *   different alert banners in different groups.
   */
  #[Hook('block_build_alter')]
  public function blockBuildAlter(array &$build, \Drupal\Core\Block\BlockPluginInterface $block_plugin) {
    $block_type = $block_plugin->getBaseId();
    if ($block_type === 'localgov_alert_banner_block') {
      $build['#cache']['contexts'][] = 'route.group';
    }
  }

  /**
   * Implements hook_form_BASE_FORM_ID_alter() for hook_form_localgov_alert_banner_form_alter().
   *
   * Appends a custom form submit handler for the group banner add form.
   */
  #[Hook('form_localgov_alert_banner_form_alter')]
  public function formLocalgovAlertBannerFormAlter(&$form, \Drupal\Core\Form\FormStateInterface $form_state, $form_id) {
    $is_banner_add_form = strpos($form_id, '_add_form', -9);
    $is_group_context = \Drupal::service('group.group_route_context')->getGroupFromRoute();
    if ($is_banner_add_form && $is_group_context) {
      $form['actions']['submit']['#submit'][] = 'group_alert_banner_restore_publish_page_redirect';
    }
  }

}
