<?php

namespace Drupal\localgov_alert_banner_full_page\Hook;

use Drupal\Core\Hook\Attribute\Hook;

/**
 * Hook implementations for localgov_alert_banner_full_page.
 */
class LocalgovAlertBannerFullPageHooks {

  /**
   * Implements hook_theme().
   */
  #[Hook('theme')]
  public function theme(): array {
    $theme = [];
    $theme['localgov_alert_banner__localgov_full_page'] = [
      'base hook' => 'localgov_alert_banner',
    ];
    return $theme;
  }

}
