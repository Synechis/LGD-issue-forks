<?php

namespace Drupal\localgov_alert_banner\Hook;

use Drupal\Core\Routing\RouteMatchInterface;
use Drupal\Core\Hook\Attribute\Hook;
use Drupal\Core\StringTranslation\StringTranslationTrait;

/**
 * Hook implementations for localgov_alert_banner.
 */
class LocalgovAlertBannerHooks {
  use StringTranslationTrait;

  /**
   * Implements hook_help().
   */
  #[Hook('help')]
  public function help($route_name, RouteMatchInterface $route_match): string|\Stringable|array|null {
    switch ($route_name) {
      // Main module help for the localgov_alert_banner module.
      case 'help.page.localgov_alert_banner':
        $output = '';
        $output .= '<h3>' . $this->t('About') . '</h3>';
        $output .= '<p>' . $this->t('Alert Banner Support module') . '</p>';
        return $output;

      default:
        return NULL;
    }
  }

  /**
   * Implements hook_theme().
   */
  #[Hook('theme')]
  public function theme(): array {
    $theme = [];
    $theme['localgov_alert_banner'] = [
      'render element' => 'elements',
      'file' => 'localgov_alert_banner.page.inc',
      'template' => 'localgov-alert-banner',
    ];
    $theme['localgov_alert_banner_content_add_list'] = [
      'render element' => 'content',
      'variables' => [
        'content' => NULL,
      ],
      'file' => 'localgov_alert_banner.page.inc',
    ];
    return $theme;
  }

  /**
   * Implements hook_theme_suggestions_HOOK().
   */
  #[Hook('theme_suggestions_localgov_alert_banner')]
  public function themeSuggestionsLocalgovAlertBanner(array $variables): array {
    $suggestions = [];
    $entity = $variables['elements']['#localgov_alert_banner'];
    $sanitized_view_mode = strtr($variables['elements']['#view_mode'], '.', '_');
    $suggestions[] = 'localgov_alert_banner__' . $sanitized_view_mode;
    $suggestions[] = 'localgov_alert_banner__' . $entity->bundle();
    $suggestions[] = 'localgov_alert_banner__' . $entity->bundle() . '__' . $sanitized_view_mode;
    $suggestions[] = 'localgov_alert_banner__' . $entity->id();
    $suggestions[] = 'localgov_alert_banner__' . $entity->id() . '__' . $sanitized_view_mode;
    return $suggestions;
  }

  /**
   * Implements hook_modules_installed().
   */
  #[Hook('modules_installed')]
  public function modulesInstalled($modules, $is_syncing): void {
    // Configure scheduled transitions if it's being installed.
    if (in_array('scheduled_transitions', $modules, TRUE)) {
      localgov_alert_banner_configure_scheduled_transitions();
    }
  }

  /**
   * Implements hook_preprocess_field().
   */
  #[Hook('preprocess_field')]
  public function preprocessField(&$variables): void {
    if ($variables['element']['#field_name'] == 'link' && $variables['element']['#bundle'] == 'localgov_alert_banner') {
      foreach ($variables['element']['#items'] as $item) {
        if (empty($item->getValue()['title'])) {
          $default_text = $this->t('More information');
          $variables['items'][0]['content']['#title'] = $default_text;
        }
      }
    }
  }

  /**
   * Implements hook_gin_content_form_routes().
   */
  #[Hook('gin_content_form_routes')]
  public function ginContentFormRoutes(): array {
    return [
          // Alert banner add form.
      'entity.localgov_alert_banner.add_form',
          // Alert banner add form edit form.
      'entity.localgov_alert_banner.edit_form',
    ];
  }

}
