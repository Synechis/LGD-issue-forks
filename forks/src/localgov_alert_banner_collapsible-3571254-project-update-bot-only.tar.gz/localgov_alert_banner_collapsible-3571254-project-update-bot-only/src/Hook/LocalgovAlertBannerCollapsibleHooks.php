<?php

namespace Drupal\localgov_alert_banner_collapsible\Hook;

use Drupal\Core\Hook\Attribute\Hook;

/**
 * Hook implementations for localgov_alert_banner_collapsible.
 */
class LocalgovAlertBannerCollapsibleHooks {
  /**
   * @file
   * Primary module hooks for Localgov alert banner collapsible module.
   */

  /**
   * Implements hook_theme().
   */
  #[Hook('theme')]
  public function theme(): array {
    return [
      'localgov_alert_banner_collapsible' => [
        'variables' => [
          'control' => NULL,
          'alert_banners' => NULL,
          'persistent_alert_banners' => NULL,
          'html_id' => NULL,
          'count' => NULL,
          'summary' => NULL,
          'closed_label' => NULL,
          'open_label' => NULL,
          'published_alert_banners' => NULL,
          'alert_banner_titles' => NULL,
          'default_state' => NULL,
        ],
      ],
    ];
  }

}
