<?php

namespace Drupal\localgov_microsites_sitemap\Hook;

use Drupal\localgov_microsites_sitemap\MicrositeSitemapManager;
use Drupal\Core\Entity\EntityInterface;
use Drupal\Core\Hook\Attribute\Hook;
use Drupal\group\Entity\GroupInterface;

/**
 * Hook implementations for microsite sitemap lifecycle management.
 */
final class GroupSitemapHooks {

  /**
   * GroupSitemapHooks constructor.
   *
   * @param \Drupal\localgov_microsites_sitemap\MicrositeSitemapManager $manager
   *   The Microsite Sitemap Manager service.
   */
  public function __construct(
    protected MicrositeSitemapManager $manager,
  ) {}

  /**
   * Creates sitemap variants when a new microsite group is saved.
   *
   * @phpstan-ignore-next-line
   */
  #[Hook('entity_insert')]
  public function entityInsert(EntityInterface $entity): void {
    if ($entity instanceof GroupInterface && $entity->bundle() === 'microsite') {
      $this->manager->createForGroup($entity);
    }
  }

  /**
   * Removes sitemap variants when a microsite group is deleted.
   *
   * @phpstan-ignore-next-line
   */
  #[Hook('entity_delete')]
  public function entityDelete(EntityInterface $entity): void {
    if ($entity instanceof GroupInterface && $entity->bundle() === 'microsite') {
      $this->manager->deleteForGroup($entity);
    }
  }

}
