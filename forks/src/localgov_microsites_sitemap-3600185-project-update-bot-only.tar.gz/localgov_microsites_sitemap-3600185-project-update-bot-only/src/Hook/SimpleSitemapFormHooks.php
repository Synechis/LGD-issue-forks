<?php

namespace Drupal\localgov_microsites_sitemap\Hook;

use Drupal\localgov_microsites_sitemap\MicrositeSitemapManager;
use Drupal\Core\Entity\EntityTypeManagerInterface;
use Drupal\Core\Form\FormStateInterface;
use Drupal\Core\Hook\Attribute\Hook;
use Drupal\Core\StringTranslation\StringTranslationTrait;
use Drupal\simple_sitemap\Entity\SimpleSitemapInterface;
use Drupal\simple_sitemap\Form\SimpleSitemapEntityForm;

/**
 * Form alter hooks for the simple_sitemap variant edit/add forms.
 *
 * Adds a microsite group selector field to sitemap variants whose type is
 * localgov_microsites_sitemap_hreflang or localgov_microsites_sitemap_index.
 * The selected group ID is stored as a third party setting and read
 * by the custom URL generator plugins to scope content to that microsite.
 */
final class SimpleSitemapFormHooks {

  use StringTranslationTrait;

  /**
   * SimpleSitemapFormHooks constructor.
   *
   * @param \Drupal\Core\Entity\EntityTypeManagerInterface $entityTypeManager
   *   The entity type manager service.
   */
  public function __construct(
    protected EntityTypeManagerInterface $entityTypeManager,
  ) {}

  /**
   * Adds the microsite group field to the sitemap variant edit form.
   *
   * @phpstan-ignore-next-line
   */
  #[Hook('form_simple_sitemap_edit_form_alter')]
  public function editFormAlter(array &$form, FormStateInterface $form_state): void {
    $this->addGroupField($form, $form_state);
  }

  /**
   * Adds the microsite group field to the sitemap variant add form.
   *
   * @phpstan-ignore-next-line
   */
  #[Hook('form_simple_sitemap_add_form_alter')]
  public function addFormAlter(array &$form, FormStateInterface $form_state): void {
    $this->addGroupField($form, $form_state);
  }

  /**
   * Injects the microsite group selector and entity builder into the form.
   *
   * @param array $form
   *   The form definition.
   * @param \Drupal\Core\Form\FormStateInterface $form_state
   *   The form state.
   */
  protected function addGroupField(array &$form, FormStateInterface $form_state): void {
    $form_object = $form_state->getFormObject();

    if (!$form_object instanceof SimpleSitemapEntityForm) {
      return;
    }

    $sitemap = $form_object->getEntity();

    if (!$sitemap instanceof SimpleSitemapInterface) {
      return;
    }

    $type_id = $sitemap->get('type');
    if (!in_array($type_id, [
      MicrositeSitemapManager::SITEMAP_TYPE_HREFLANG,
      MicrositeSitemapManager::SITEMAP_TYPE_INDEX,
    ], TRUE)) {
      return;
    }

    $groups = $this->entityTypeManager->getStorage('group')
      ->loadByProperties(['type' => 'microsite']);

    $options = ['' => $this->t('- None -')];
    foreach ($groups as $group) {
      $options[$group->id()] = $group->label();
    }

    $current = $sitemap->getThirdPartySetting(
      MicrositeSitemapManager::MODULE_NAME,
      MicrositeSitemapManager::THIRD_PARTY_SETTING_GROUP_ID_KEY
    );

    $form[MicrositeSitemapManager::THIRD_PARTY_SETTING_GROUP_ID_KEY] = [
      '#type' => 'select',
      '#title' => $this->t('Microsite group'),
      '#description' => $this->t('Scope this sitemap to a specific microsite. The URL generator will only include content belonging to the selected group.'),
      '#options' => $options,
      '#default_value' => $current ?? '',
      '#weight' => 10,
    ];

    $form['#entity_builders'][] = [$this, 'entityBuilder'];
  }

  /**
   * Saves the selected group ID as a third party setting.
   *
   * @param string $entity_type
   *   The entity type.
   * @param \Drupal\simple_sitemap\Entity\SimpleSitemapInterface $entity
   *   The entity.
   * @param array $form
   *   The form array.
   * @param \Drupal\Core\Form\FormStateInterface $form_state
   *   The form state.
   */
  public function entityBuilder(string $entity_type, SimpleSitemapInterface $entity, array &$form, FormStateInterface $form_state): void {
    $group_id = (int) $form_state->getValue(MicrositeSitemapManager::THIRD_PARTY_SETTING_GROUP_ID_KEY);

    if ($group_id > 0) {
      $entity->setThirdPartySetting(MicrositeSitemapManager::MODULE_NAME, MicrositeSitemapManager::THIRD_PARTY_SETTING_GROUP_ID_KEY, $group_id);
    }
    else {
      $entity->unsetThirdPartySetting(MicrositeSitemapManager::MODULE_NAME, MicrositeSitemapManager::THIRD_PARTY_SETTING_GROUP_ID_KEY);
    }
  }

}
