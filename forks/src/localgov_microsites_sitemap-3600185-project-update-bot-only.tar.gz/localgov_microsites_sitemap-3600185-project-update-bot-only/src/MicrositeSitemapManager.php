<?php

namespace Drupal\localgov_microsites_sitemap;

use Drupal\Core\Config\ConfigFactoryInterface;
use Drupal\Core\Entity\EntityTypeManagerInterface;
use Drupal\group\Entity\GroupInterface;
use Drupal\group\Plugin\Group\Relation\GroupRelationTypeManagerInterface;
use Drupal\localgov_microsites_group\ContentTypeHelper;
use Drupal\simple_sitemap\Entity\SimpleSitemapInterface;

/**
 * Manages simple_sitemap variants for microsite groups.
 *
 * The group ID is stored on each variant as a third party setting so that
 * the custom URL generator plugins can filter content by group, and so that
 * the value is visible and editable in the simple_sitemap admin UI.
 */
class MicrositeSitemapManager {

  const MODULE_NAME = 'localgov_microsites_sitemap';
  const THIRD_PARTY_SETTING_GROUP_ID_KEY = 'localgov_microsites_group_id';
  const SITEMAP_TYPE_HREFLANG = 'localgov_microsites_sitemap_hreflang';
  const SITEMAP_TYPE_INDEX = 'localgov_microsites_sitemap_index';
  const SITEMAP_ID_HREFLANG_PREFIX = 'lgd_ms_';
  const SITEMAP_ID_INDEX_PREFIX = 'lgd_ms_index_';

  /**
   * MicrositeSitemapManager constructor.
   *
   * @param \Drupal\Core\Entity\EntityTypeManagerInterface $entityTypeManager
   *   The entity type manager service.
   * @param \Drupal\Core\Config\ConfigFactoryInterface $configFactory
   *   The config factory service.
   * @param \Drupal\localgov_microsites_group\ContentTypeHelper $contentTypeHelper
   *   The microsites content type helper service.
   * @param \Drupal\group\Plugin\Group\Relation\GroupRelationTypeManagerInterface $relationTypeManager
   *   The group relation type plugin manager.
   */
  public function __construct(
    protected EntityTypeManagerInterface $entityTypeManager,
    protected ConfigFactoryInterface $configFactory,
    protected ContentTypeHelper $contentTypeHelper,
    protected GroupRelationTypeManagerInterface $relationTypeManager,
  ) {}

  /**
   * Returns the hreflang sitemap variant ID for a group.
   *
   * @param \Drupal\group\Entity\GroupInterface $group
   *   The group entity.
   *
   * @return string
   *   The name of the sitemap id based on the group ID.
   */
  public function getHreflangSitemapId(GroupInterface $group): string {
    return self::SITEMAP_ID_HREFLANG_PREFIX . $group->id();
  }

  /**
   * Returns the index sitemap variant ID for a group.
   *
   * @param \Drupal\group\Entity\GroupInterface $group
   *   The group entity.
   *
   * @return string
   *   The name of the sitemap id based on the group ID.
   */
  public function getIndexSitemapId(GroupInterface $group): string {
    return self::SITEMAP_ID_INDEX_PREFIX . $group->id();
  }

  /**
   * Creates both sitemap variants for the given microsite group.
   *
   * @param \Drupal\group\Entity\GroupInterface $group
   *   The group entity.
   */
  public function createForGroup(GroupInterface $group): void {
    $this->createHreflangVariant($group);
    $this->createIndexVariant($group);
  }

  /**
   * Loads every sitemap variant scoped to the given microsite group.
   *
   * @param \Drupal\group\Entity\GroupInterface $group
   *   The group entity.
   *
   * @return \Drupal\simple_sitemap\Entity\SimpleSitemapInterface[]
   *   The sitemap variants belonging to the group, keyed by sitemap ID.
   */
  public function loadForGroup(GroupInterface $group): array {
    $key = 'third_party_settings.' . self::MODULE_NAME . '.' . self::THIRD_PARTY_SETTING_GROUP_ID_KEY;

    return $this->entityTypeManager->getStorage('simple_sitemap')
      ->loadByProperties([$key => (int) $group->id()]);
  }

  /**
   * Delete every sitemap variant for the given microsite group.
   *
   * @param \Drupal\group\Entity\GroupInterface $group
   *   The group entity.
   */
  public function deleteForGroup(GroupInterface $group): void {
    foreach ($this->loadForGroup($group) as $sitemap_id => $sitemap) {
      // The bundle settings are keyed by sitemap ID and are not config
      // dependencies of the variant, so they have to go separately.
      $this->deleteBundleSettings($sitemap_id);
      $sitemap->delete();
    }
  }

  /**
   * Creates sitemap variants for all existing microsite groups.
   *
   * Called on module install to initialise pre-existing microsites.
   */
  public function initializeAllMicrosites(): void {
    $groups = $this->entityTypeManager->getStorage('group')
      ->loadByProperties(['type' => 'microsite']);

    foreach ($groups as $group) {
      $this->createForGroup($group);
    }
  }

  /**
   * Removes all microsite sitemap variants.
   *
   * Called on module uninstall.
   */
  public function removeAllMicrositeSitemaps(): void {
    $groups = $this->entityTypeManager->getStorage('group')
      ->loadByProperties(['type' => 'microsite']);

    foreach ($groups as $group) {
      $this->deleteForGroup($group);
    }
  }

  /**
   * Creates the hreflang sitemap variant and copies bundle settings.
   *
   * @param \Drupal\group\Entity\GroupInterface $group
   *   The group entity.
   */
  protected function createHreflangVariant(GroupInterface $group): void {
    // Generate the base sitemap id using the group ID and a fixed prefix.
    $base_sitemap_id = $this->getHreflangSitemapId($group);
    $sitemap_id = $this->getAvailableSitemapId($base_sitemap_id);
    $storage = $this->entityTypeManager->getStorage('simple_sitemap');

    $sitemap = $storage->create([
      'id' => $sitemap_id,
      'label' => (string) $group->label() . ' Sitemap',
      'type' => self::SITEMAP_TYPE_HREFLANG,
      'status' => TRUE,
    ]);
    if ($sitemap instanceof SimpleSitemapInterface) {
      $sitemap->setThirdPartySetting(self::MODULE_NAME, self::THIRD_PARTY_SETTING_GROUP_ID_KEY, (int) $group->id());
      $sitemap->save();

      $this->setBundleSettings($group, $sitemap_id);
    }
  }

  /**
   * Creates the index sitemap variant for the microsite.
   *
   * @param \Drupal\group\Entity\GroupInterface $group
   *   The group entity.
   */
  protected function createIndexVariant(GroupInterface $group): void {
    // Generate the base sitemap id using the group ID and a fixed prefix.
    $base_sitemap_id = $this->getIndexSitemapId($group);
    $sitemap_id = $this->getAvailableSitemapId($base_sitemap_id);
    $storage = $this->entityTypeManager->getStorage('simple_sitemap');

    $sitemap = $storage->create([
      'id' => $sitemap_id,
      'label' => (string) $group->label() . ' Sitemap Index',
      'type' => self::SITEMAP_TYPE_INDEX,
      'status' => TRUE,
    ]);

    if ($sitemap instanceof SimpleSitemapInterface) {
      $sitemap->setThirdPartySetting(self::MODULE_NAME, self::THIRD_PARTY_SETTING_GROUP_ID_KEY, (int) $group->id());
      $sitemap->save();
    }
  }

  /**
   * Given a base sitemap ID, return the first available ID.
   *
   * @param string $base_sitemap_id
   *   The base sitemap ID.
   *
   * @return string
   *   The available ID.
   */
  private function getAvailableSitemapId(string $base_sitemap_id): string {
    $storage = $this->entityTypeManager->getStorage('simple_sitemap');
    $sitemap_id = $base_sitemap_id;
    $counter = 1;

    // Look for a sitemap with the defined ID until finding one ID avaliable.
    // Due to the specificity of the id generated, it is a really edge case
    // That the ID is already taken, but it is worth checking.
    while ($storage->load($sitemap_id)) {
      // The ID is already taken, add a suffix and retry.
      $sitemap_id = $base_sitemap_id . '_' . $counter;
    }
    return $sitemap_id;
  }

  /**
   * Enables indexing of every content type available to the microsite.
   *
   * The content types are those whose group relation plugins are installed on
   * the group type, minus those belonging to modules the microsite has turned
   * off via Microsite -> Site settings -> Content types.
   * Everything else about each bundle
   * (priority, changefreq, images) is inherited from the default sitemap.
   *
   * @param \Drupal\group\Entity\GroupInterface $group
   *   The group entity.
   * @param string $target_id
   *   The target sitemap variant id.
   */
  protected function setBundleSettings(GroupInterface $group, string $target_id): void {
    foreach ($this->contentTypeHelper->enabledContentTypes($group) as $plugin_id) {
      $relation_type = $this->relationTypeManager->getDefinition($plugin_id, FALSE);
      if ($relation_type === NULL) {
        continue;
      }

      $entity_type_id = $relation_type->getEntityTypeId();
      $bundle = $relation_type->getEntityBundle();

      // Relations that are not bundle specific (group_membership, for example)
      // do not describe a content type we can index.
      if (!$bundle) {
        continue;
      }

      // Without a canonical route there is no URL to put in the sitemap.
      $entity_type = $this->entityTypeManager->getDefinition($entity_type_id, FALSE);
      if ($entity_type === NULL || !$entity_type->hasLinkTemplate('canonical')) {
        continue;
      }

      $suffix = $entity_type_id . '.' . $bundle;
      $defaults = $this->configFactory->get('simple_sitemap.bundle_settings.default.' . $suffix);

      $this->configFactory->getEditable('simple_sitemap.bundle_settings.' . $target_id . '.' . $suffix)
        ->setData([
          'index' => TRUE,
          'priority' => $defaults->get('priority') ?? 0.5,
          'changefreq' => $defaults->get('changefreq') ?? '',
          'include_images' => $defaults->get('include_images') ?? FALSE,
        ])
        ->save();
    }
  }

  /**
   * Deletes all bundle settings configs for a sitemap variant.
   *
   * @param string $sitemap_id
   *   The sitemap variant id.
   */
  protected function deleteBundleSettings(string $sitemap_id): void {
    $prefix = 'simple_sitemap.bundle_settings.' . $sitemap_id . '.';
    foreach ($this->configFactory->listAll($prefix) as $config_name) {
      $this->configFactory->getEditable($config_name)->delete();
    }
  }

}
