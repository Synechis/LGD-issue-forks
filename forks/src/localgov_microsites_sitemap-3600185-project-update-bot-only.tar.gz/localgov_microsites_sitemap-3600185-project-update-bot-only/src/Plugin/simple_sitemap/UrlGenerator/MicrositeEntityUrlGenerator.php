<?php

namespace Drupal\localgov_microsites_sitemap\Plugin\simple_sitemap\UrlGenerator;

use Drupal\localgov_microsites_sitemap\MicrositeSitemapManager;
use Drupal\Core\Cache\MemoryCache\MemoryCacheInterface;
use Drupal\Core\Config\ConfigFactoryInterface;
use Drupal\Core\Database\Connection;
use Drupal\Core\Entity\ContentEntityInterface;
use Drupal\Core\Entity\EntityPublishedInterface;
use Drupal\Core\Entity\EntityTypeManagerInterface;
use Drupal\Core\Extension\ModuleHandlerInterface;
use Drupal\Core\Language\LanguageInterface;
use Drupal\Core\Language\LanguageManagerInterface;
use Drupal\Core\Url;
use Drupal\domain\DomainInterface;
use Drupal\domain_path\DomainPathInterface;
use Drupal\localgov_microsites_group\DomainFromGroupTrait;
use Drupal\simple_sitemap\Entity\EntityHelper;
use Drupal\simple_sitemap\Logger;
use Drupal\simple_sitemap\Manager\EntityManager;
use Drupal\simple_sitemap\Plugin\simple_sitemap\SimpleSitemapPluginBase;
use Drupal\simple_sitemap\Plugin\simple_sitemap\UrlGenerator\EntityUrlGenerator;
use Drupal\simple_sitemap\Plugin\simple_sitemap\UrlGenerator\UrlGeneratorManager;
use Drupal\simple_sitemap\Settings;
use Symfony\Component\DependencyInjection\ContainerInterface;

/**
 * Entity Url Generator for entity belonging to a microsite group.
 *
 * @UrlGenerator(
 *   id = "localgov_microsites_sitemap_entity",
 *   label = @Translation("LocalGov Microsite entity URL generator"),
 *   description = @Translation("Generates URLs for entities belonging to a microsite group."),
 * )
 */
final class MicrositeEntityUrlGenerator extends EntityUrlGenerator {

  use DomainFromGroupTrait;

  /**
   * Cached microsite base URL for the current sitemap variant.
   *
   * NULL = not yet resolved; empty string = no domain found for this group.
   */
  protected ?string $micrositeBaseUrl = NULL;

  /**
   * Cached microsite domain entity for the current sitemap variant.
   */
  protected ?DomainInterface $micrositeDomain = NULL;

  /**
   * Cached page paths (front, 403, 404) for the microsite domain.
   *
   * Keys: 'front', '403', '404'. Values are internal paths or NULL.
   * NULL = not yet resolved.
   */
  protected ?array $micrositePagePaths = NULL;

  /**
   * EntityUrlGenerator constructor.
   *
   * @param array $configuration
   *   A configuration array containing information about the plugin instance.
   * @param string $plugin_id
   *   The plugin_id for the plugin instance.
   * @param mixed $plugin_definition
   *   The plugin implementation definition.
   * @param \Drupal\simple_sitemap\Logger $logger
   *   Simple XML Sitemap logger.
   * @param \Drupal\simple_sitemap\Settings $settings
   *   The simple_sitemap.settings service.
   * @param \Drupal\Core\Language\LanguageManagerInterface $language_manager
   *   The language manager.
   * @param \Drupal\Core\Entity\EntityTypeManagerInterface $entity_type_manager
   *   The entity type manager.
   * @param \Drupal\simple_sitemap\Entity\EntityHelper $entity_helper
   *   Helper class for working with entities.
   * @param \Drupal\simple_sitemap\Manager\EntityManager $entities_manager
   *   The simple_sitemap.entity_manager service.
   * @param \Drupal\simple_sitemap\Plugin\simple_sitemap\UrlGenerator\UrlGeneratorManager $url_generator_manager
   *   The UrlGenerator plugins manager.
   * @param \Drupal\Core\Cache\MemoryCache\MemoryCacheInterface $memory_cache
   *   The memory cache.
   * @param \Drupal\Core\Database\Connection $database
   *   The database connection.
   * @param \Drupal\Core\Config\ConfigFactoryInterface $configFactory
   *   The config factory service.
   * @param \Drupal\Core\Extension\ModuleHandlerInterface|null $module_handler
   *   The module handler service.
   */
  public function __construct(
    array $configuration,
    $plugin_id,
    $plugin_definition,
    Logger $logger,
    Settings $settings,
    LanguageManagerInterface $language_manager,
    EntityTypeManagerInterface $entity_type_manager,
    EntityHelper $entity_helper,
    EntityManager $entities_manager,
    UrlGeneratorManager $url_generator_manager,
    MemoryCacheInterface $memory_cache,
    protected Connection $database,
    protected ConfigFactoryInterface $configFactory,
    ?ModuleHandlerInterface $module_handler = NULL,
  ) {
    parent::__construct(
      $configuration,
      $plugin_id,
      $plugin_definition,
      $logger,
      $settings,
      $language_manager,
      $entity_type_manager,
      $entity_helper,
      $entities_manager,
      $url_generator_manager,
      $memory_cache,
      $module_handler
    );
  }

  /**
   * {@inheritdoc}
   */
  public static function create(
    ContainerInterface $container,
    array $configuration,
    $plugin_id,
    $plugin_definition,
  ): SimpleSitemapPluginBase {
    return new static(
      $configuration,
      $plugin_id,
      $plugin_definition,
      $container->get('simple_sitemap.logger'),
      $container->get('simple_sitemap.settings'),
      $container->get('language_manager'),
      $container->get('entity_type.manager'),
      $container->get('simple_sitemap.entity_helper'),
      $container->get('simple_sitemap.entity_manager'),
      $container->get('plugin.manager.simple_sitemap.url_generator'),
      $container->get('entity.memory_cache'),
      $container->get('database'),
      $container->get('config.factory'),
      $container->get('module_handler'),
    );
  }

  /**
   * {@inheritdoc}
   */
  public function getDataSets(): array {
    $group_id = $this->sitemap->getThirdPartySetting(
      MicrositeSitemapManager::MODULE_NAME,
      MicrositeSitemapManager::THIRD_PARTY_SETTING_GROUP_ID_KEY
    );

    if (!$group_id) {
      return parent::getDataSets();
    }

    $cache = [];
    $result = [];

    foreach (parent::getDataSets() as $batch) {
      $entity_type = $batch['entity_type'];

      if (!array_key_exists($entity_type, $cache)) {
        $cache[$entity_type] = $this->getGroupEntityIds((int) $group_id, $entity_type);
      }

      $allowed = $cache[$entity_type];

      // NULL means no group filter for this entity type — pass through.
      if ($allowed === NULL) {
        $result[] = $batch;
        continue;
      }

      if (empty($allowed)) {
        continue;
      }

      $ids = array_values(array_intersect($batch['id'], $allowed));
      if (!empty($ids)) {
        $result[] = ['entity_type' => $entity_type, 'id' => $ids];
      }
    }

    return $result;
  }

  /**
   * {@inheritdoc}
   */
  protected function getUrlVariants(array $path_data, Url $url): array {
    $microsite_base_url = $this->resolveMicrositeBaseUrl();

    if (!$microsite_base_url || !$url->isRouted()) {
      return parent::getUrlVariants($path_data, $url);
    }

    $alternate_urls = $this->buildMicrositeAlternateUrls($url, $microsite_base_url);
    if (empty($alternate_urls)) {
      return [];
    }

    $url_variants = [];
    foreach ($alternate_urls as $langcode => $base_url) {
      $url_variants[] = $path_data + [
        'langcode' => $langcode,
        'url' => $base_url,
        'alternate_urls' => $alternate_urls,
      ];
    }

    return $url_variants;
  }

  /**
   * Builds language-variant URLs for the microsite.
   *
   * @param \Drupal\Core\Url $url
   *   The URL object.
   * @param string $microsite_base_url
   *   The base url of the microsite.
   *
   * @return array
   *   Array keyed by language code, values are
   *   absolute URLs on the microsite domain.
   */
  protected function buildMicrositeAlternateUrls(Url $url, string $microsite_base_url): array {
    $microsite_base_url = rtrim($microsite_base_url, '/');
    $excluded = $this->settings->get('excluded_languages') ?? [];

    $entity = $this->entityHelper->getEntityFromUrlObject($url);

    // Skip unpublished content regardless of domain context.
    if ($entity instanceof EntityPublishedInterface && !$entity->isPublished()) {
      return [];
    }

    $internal_path = $entity instanceof ContentEntityInterface
      ? '/' . $entity->toUrl()->getInternalPath()
      : NULL;

    // Apply front/403/404 rules when we have an internal path.
    $override_path = NULL;
    if ($internal_path) {
      $pages = $this->getMicrositePagePaths();

      if ($internal_path === $pages['403'] || $internal_path === $pages['404']) {
        return [];
      }

      if ($internal_path === $pages['front']) {
        $override_path = '/';
      }
    }

    if (!$this->sitemap->isMultilingual()) {
      $langcode = $this->defaultLanguageId;
      return [
        $langcode => $this->buildSingleUrl($url, $this->languages[$langcode], $internal_path, $microsite_base_url, $override_path),
      ];
    }

    // Multilingual: mirror parent logic for skip_untranslated.
    if ($this->settings->get('skip_untranslated') && $entity instanceof ContentEntityInterface) {
      $translation_languages = $entity->getTranslationLanguages();
      if (isset($translation_languages[LanguageInterface::LANGCODE_NOT_SPECIFIED])
        || isset($translation_languages[LanguageInterface::LANGCODE_NOT_APPLICABLE])) {
        $languages = [$this->defaultLanguageId => $this->languages[$this->defaultLanguageId]];
      }
      else {
        $languages = $translation_languages;
      }
    }
    else {
      $languages = $this->languages;
    }

    $alternate_urls = [];
    foreach ($languages as $langcode => $language) {
      if (isset($excluded[$langcode]) && !$language->isDefault()) {
        continue;
      }
      $alternate_urls[$langcode] = $this->buildSingleUrl($url, $language, $internal_path, $microsite_base_url, $override_path);
    }

    return $alternate_urls;
  }

  /**
   * Builds the absolute URL for a single language variant on the microsite.
   *
   * @param \Drupal\Core\Url $url
   *   The entity URL object.
   * @param \Drupal\Core\Language\LanguageInterface $language
   *   The language for this variant.
   * @param string|null $internal_path
   *   The entity's internal system path (e.g. /node/5), or NULL if unavailable.
   * @param string $microsite_base_url
   *   The microsite domain base URL (no trailing slash).
   * @param string $override_path
   *   A specific path to override the generated one, e.g. for front page.
   *
   * @return string
   *   The absolute URL on the microsite domain.
   */
  protected function buildSingleUrl(Url $url, $language, ?string $internal_path, string $microsite_base_url, ?string $override_path = NULL): string {
    if ($override_path !== NULL) {
      return $microsite_base_url . $override_path;
    }

    $langcode = $language->getId();

    // Prefer a domain-specific path alias.
    if ($internal_path && $this->micrositeDomain) {
      $domain_paths = $this->entityTypeManager->getStorage('domain_path')->loadByProperties([
        'source' => $internal_path,
        'language' => $langcode,
        'domain_id' => $this->micrositeDomain->id(),
      ]);
      if ($domain_path = reset($domain_paths)) {
        if ($domain_path instanceof DomainPathInterface) {
          return $microsite_base_url . $domain_path->getAlias();
        }
      }
    }

    // Fall back to the default alias, replacing the generation base URL.
    $source_base_url = rtrim(
      !empty($this->settings->get('base_url')) ? $this->settings->get('base_url') : $GLOBALS['base_url'],
      '/'
    );
    $generated = $url->setAbsolute()->setOption('language', $language)->toString();
    return str_replace($source_base_url, $microsite_base_url, $generated);
  }

  /**
   * Returns frontpage, 403 and 404 nodes for the microsite.
   *
   * @return array
   *   The array of configured paths.
   */
  protected function getMicrositePagePaths(): array {
    if ($this->micrositePagePaths !== NULL) {
      return $this->micrositePagePaths;
    }

    $base = $this->configFactory->get('system.site');
    $this->micrositePagePaths = [
      'front' => $base->get('page.front'),
      '403' => $base->get('page.403'),
      '404' => $base->get('page.404'),
    ];

    if ($this->micrositeDomain) {
      $override = $this->configFactory->get(
        'domain.config.' . $this->micrositeDomain->id() . '.system.site'
      );
      foreach (['front', '403', '404'] as $key) {
        $value = $override->get('page.' . $key);
        if ($value !== NULL) {
          $this->micrositePagePaths[$key] = $value;
        }
      }
    }

    return $this->micrositePagePaths;
  }

  /**
   * Returns the scheme + host for this variant's microsite group, or NULL.
   *
   * @return string|null
   *   The base Url for the microsite.
   */
  protected function resolveMicrositeBaseUrl(): ?string {
    if ($this->micrositeBaseUrl !== NULL) {
      return $this->micrositeBaseUrl ?: NULL;
    }

    $group_id = $this->sitemap->getThirdPartySetting(
      MicrositeSitemapManager::MODULE_NAME,
      MicrositeSitemapManager::THIRD_PARTY_SETTING_GROUP_ID_KEY
    );

    if (!$group_id) {
      $this->micrositeBaseUrl = '';
      return NULL;
    }

    $group = $this->entityTypeManager->getStorage('group')->load($group_id);
    if (!$group) {
      $this->micrositeBaseUrl = '';
      return NULL;
    }

    $this->micrositeDomain = $this->getDomainFromGroup($group);
    if ($this->micrositeDomain) {
      $this->micrositeBaseUrl = $this->micrositeDomain->getPath();
    }
    return $this->micrositeBaseUrl;
  }

  /**
   * Returns entity IDs belonging to the group for supported entity types.
   *
   * @param int $group_id
   *   The group id.
   * @param string $entity_type
   *   The entity type.
   *
   * @return array|null
   *   The entity IDs for the given group and entity type.
   */
  protected function getGroupEntityIds(int $group_id, string $entity_type): ?array {
    $plugin_prefix = match ($entity_type) {
      'node' => 'group_node:%',
      'media' => 'group_media:%',
      default => NULL,
    };

    if ($plugin_prefix === NULL) {
      return NULL;
    }

    return $this->database
      ->select('group_relationship_field_data', 'gr')
      ->fields('gr', ['entity_id'])
      ->condition('gr.gid', $group_id)
      ->condition('gr.plugin_id', $plugin_prefix, 'LIKE')
      ->distinct()
      ->execute()
      ->fetchCol();
  }

}
