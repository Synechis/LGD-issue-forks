<?php

namespace Drupal\localgov_microsites_sitemap\Plugin\simple_sitemap\UrlGenerator;

use Drupal\localgov_microsites_sitemap\MicrositeSitemapManager;
use Drupal\Core\Entity\EntityTypeManagerInterface;
use Drupal\simple_sitemap\Entity\SimpleSitemap;
use Drupal\simple_sitemap\Exception\SkipElementException;
use Drupal\simple_sitemap\Logger;
use Drupal\simple_sitemap\Plugin\simple_sitemap\SimpleSitemapPluginBase;
use Drupal\simple_sitemap\Plugin\simple_sitemap\UrlGenerator\SitemapIndexUrlGenerator;
use Drupal\simple_sitemap\Settings;
use Symfony\Component\DependencyInjection\ContainerInterface;

/**
 * Generates the sitemap index for a single microsite.
 *
 * @UrlGenerator(
 *   id = "localgov_microsites_sitemap_index",
 *   label = @Translation("LocalGov Microsite sitemap index URL generator"),
 *   description = @Translation("Generates a sitemap index for a single microsite group."),
 * )
 */
final class MicrositeIndexUrlGenerator extends SitemapIndexUrlGenerator {

  /**
   * Cached microsite base URL for the current sitemap variant.
   *
   * NULL = not yet resolved; empty string = no domain found.
   */
  protected ?string $micrositeBaseUrl = NULL;

  /**
   * Undocumented function.
   *
   * @param array $configuration
   *   The plugin configuration array.
   * @param string $plugin_id
   *   The plugin id.
   * @param mixed $plugin_definition
   *   The plugin definition.
   * @param \Drupal\simple_sitemap\Logger $logger
   *   The simple sitemap logger service.
   * @param \Drupal\simple_sitemap\Settings $settings
   *   The simple sitemap logger setting service.
   * @param \Drupal\Core\Entity\EntityTypeManagerInterface $entityTypeManager
   *   The entity type manager service.
   */
  public function __construct(
    array $configuration,
    $plugin_id,
    $plugin_definition,
    Logger $logger,
    Settings $settings,
    protected EntityTypeManagerInterface $entityTypeManager,
  ) {
    parent::__construct($configuration, $plugin_id, $plugin_definition, $logger, $settings);
  }

  /**
   * {@inheritdoc}
   */
  public static function create(
    ContainerInterface $container,
    array $configuration,
    $plugin_id,
    $plugin_definition,
  ): SimpleSitemapPluginBase {
    return new static(
      $configuration,
      $plugin_id,
      $plugin_definition,
      $container->get('simple_sitemap.logger'),
      $container->get('simple_sitemap.settings'),
      $container->get('entity_type.manager'),
    );
  }

  /**
   * {@inheritdoc}
   */
  protected function processDataSet($data_set): array {
    $sitemap = SimpleSitemap::load($data_set);

    if (!$sitemap || !$sitemap->status()) {
      throw new SkipElementException();
    }

    if ($sitemap->getType()->getSitemapGenerator()->getPluginId() === 'index') {
      throw new SkipElementException();
    }

    // If the current sitemap processed group is the same as the sitemap
    // from the dataset.
    $current_group_id = $this->sitemap->getThirdPartySetting(
      MicrositeSitemapManager::MODULE_NAME,
      MicrositeSitemapManager::THIRD_PARTY_SETTING_GROUP_ID_KEY
    );
    $candidate_group_id = $sitemap->getThirdPartySetting(
      MicrositeSitemapManager::MODULE_NAME,
      MicrositeSitemapManager::THIRD_PARTY_SETTING_GROUP_ID_KEY
    );

    if (!$current_group_id || $candidate_group_id != $current_group_id) {
      throw new SkipElementException();
    }

    $created = $sitemap->fromPublished()->getCreated();
    $settings = $created ? ['lastmod' => date('c', $created)] : [];
    $path_data = $this->constructPathData($sitemap->toUrl(), $settings);

    // Replace the generated URL (/{variant}/sitemap.xml on the CLI base URL)
    // with /sitemap.xml on the microsite's own domain. That is the canonical
    // entry point: SitemapDomainSubscriber routes it to the correct variant.
    $microsite_base_url = $this->resolveMicrositeBaseUrl();
    if ($microsite_base_url) {
      $path_data['url'] = rtrim($microsite_base_url, '/') . '/sitemap.xml';
    }

    $path_data['meta']['entity_info'] = [
      'entity_type' => $sitemap->getEntityTypeId(),
      'bundle' => $sitemap->bundle(),
      'id' => $sitemap->id(),
    ];

    return $path_data;
  }

  /**
   * Returns the base URL for this variant's microsite group, or NULL.
   *
   * @return string|null
   *   The microsite base url.
   */
  protected function resolveMicrositeBaseUrl(): ?string {
    if ($this->micrositeBaseUrl !== NULL) {
      return $this->micrositeBaseUrl ?: NULL;
    }

    $group_id = $this->sitemap->getThirdPartySetting(
      MicrositeSitemapManager::MODULE_NAME,
      MicrositeSitemapManager::THIRD_PARTY_SETTING_GROUP_ID_KEY
    );

    if (!$group_id) {
      $this->micrositeBaseUrl = '';
      return NULL;
    }

    $group = $this->entityTypeManager->getStorage('group')->load($group_id);
    if (!$group) {
      $this->micrositeBaseUrl = '';
      return NULL;
    }

    $group_uuid = $group->uuid();

    /** @var \Drupal\domain\DomainInterface[] $domains */
    $domains = $this->entityTypeManager->getStorage('domain')->loadMultiple();
    foreach ($domains as $domain) {
      if ($domain->getThirdPartySetting('group_context_domain', 'group_uuid') === $group_uuid) {
        $this->micrositeBaseUrl = $domain->getPath();
        return $this->micrositeBaseUrl;
      }
    }

    $this->micrositeBaseUrl = '';
    return NULL;
  }

}
