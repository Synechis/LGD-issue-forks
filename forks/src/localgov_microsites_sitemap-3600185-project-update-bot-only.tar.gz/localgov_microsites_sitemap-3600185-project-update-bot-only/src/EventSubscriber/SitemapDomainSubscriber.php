<?php

namespace Drupal\localgov_microsites_sitemap\EventSubscriber;

use Drupal\localgov_microsites_sitemap\MicrositeSitemapManager;
use Drupal\Core\Entity\EntityRepositoryInterface;
use Drupal\domain\DomainInterface;
use Drupal\domain\DomainNegotiatorInterface;
use Drupal\group\Entity\GroupInterface;
use Symfony\Component\EventDispatcher\EventSubscriberInterface;
use Symfony\Component\HttpKernel\Event\RequestEvent;
use Symfony\Component\HttpKernel\Exception\NotFoundHttpException;
use Symfony\Component\HttpKernel\KernelEvents;

/**
 * Routes /sitemap.xml to the correct microsite variant based on active domain.
 */
class SitemapDomainSubscriber implements EventSubscriberInterface {

  /**
   * SitemapDomainSubscriber constructor.
   *
   * @param \Drupal\domain\DomainNegotiatorInterface $domainNegotiator
   *   The Domain negotiator service.
   * @param \Drupal\Core\Entity\EntityRepositoryInterface $entityRepository
   *   The Entity repository service.
   * @param \Drupal\localgov_microsites_sitemap\MicrositeSitemapManager $sitemapManager
   *   The microsite sitemap manager service.
   */
  public function __construct(
    protected DomainNegotiatorInterface $domainNegotiator,
    protected EntityRepositoryInterface $entityRepository,
    protected MicrositeSitemapManager $sitemapManager,
  ) {}

  /**
   * {@inheritdoc}
   */
  public static function getSubscribedEvents(): array {
    return [
      KernelEvents::REQUEST => ['onRequest', 20],
    ];
  }

  /**
   * Injects the microsite sitemap variant for /sitemap.xml requests.
   *
   * @param \Symfony\Component\HttpKernel\Event\RequestEvent $event
   *   The request event.
   *
   * @throws \Symfony\Component\HttpKernel\Exception\NotFoundHttpException
   *   When the request is for a microsite that has no sitemap to serve.
   */
  public function onRequest(RequestEvent $event): void {
    // Skip any non main request.
    if (!$event->isMainRequest()) {
      return;
    }

    $request = $event->getRequest();

    // Continue only for sitemap.xml.
    if ($request->getPathInfo() !== '/sitemap.xml') {
      return;
    }

    // Respect an already-resolved variant (e.g. /{variant}/sitemap.xml path).
    if ($request->attributes->has('variant')) {
      return;
    }

    $domain = $this->domainNegotiator->getActiveDomain();
    if (!$domain instanceof DomainInterface) {
      return;
    }

    $group_uuid = $domain->getThirdPartySetting('group_context_domain', 'group_uuid');
    if (!$group_uuid) {
      // Not a microsite domain, so the control site's default sitemap is the
      // right response and simple_sitemap can handle the request unaided.
      return;
    }

    // Past this point the request is for a microsite. Returning early would
    // leave simple_sitemap to fall back to the default sitemap, which belongs
    // to the control site and would expose its content on the microsite
    // domain, so a missing microsite sitemap has to be a 404 instead.
    $group = $this->entityRepository->loadEntityByUuid('group', $group_uuid);
    if (!$group instanceof GroupInterface) {
      throw new NotFoundHttpException();
    }

    $sitemap_id = $this->resolveSitemapVariant($group);
    if ($sitemap_id === NULL) {
      throw new NotFoundHttpException();
    }

    // Inject as a route attribute. Symfony's argument resolver reads controller
    // parameters from $request->attributes, so this causes the controller to
    // receive $variant = $sitemap_id as if the /{variant}/sitemap.xml route
    // had been matched directly.
    $request->attributes->set('variant', $sitemap_id);
  }

  /**
   * Returns the best available sitemap variant ID for the given group.
   *
   * The hreflang variant is the one meant to be served at /sitemap.xml. Any
   * other enabled variant belonging to the group is preferable to a 404, so it
   * is used as a fallback.
   *
   * @param \Drupal\group\Entity\GroupInterface $group
   *   The microsite group.
   *
   * @return string|null
   *   The sitemap variant ID, or NULL if the group has no enabled variant.
   */
  protected function resolveSitemapVariant(GroupInterface $group): ?string {
    $fallback = NULL;

    foreach ($this->sitemapManager->loadForGroup($group) as $sitemap_id => $sitemap) {
      // isEnabled() is the config flag; status() also requires the sitemap to
      // have been generated already, which is the controller's business, not
      // ours. Serving an ungenerated variant 404s with the right reason.
      if (!$sitemap->isEnabled()) {
        continue;
      }
      if ($sitemap->get('type') === MicrositeSitemapManager::SITEMAP_TYPE_HREFLANG) {
        return $sitemap_id;
      }
      $fallback ??= $sitemap_id;
    }

    return $fallback;
  }

}
