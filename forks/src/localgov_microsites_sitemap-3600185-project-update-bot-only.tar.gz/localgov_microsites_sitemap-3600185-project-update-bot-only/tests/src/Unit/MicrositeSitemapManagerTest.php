<?php

declare(strict_types=1);

namespace Drupal\Tests\localgov_microsites_sitemap\Unit;

use PHPUnit\Framework\Attributes\Group;
use Drupal\Core\Config\ConfigFactoryInterface;
use Drupal\Core\Entity\EntityStorageInterface;
use Drupal\Core\Entity\EntityTypeManagerInterface;
use Drupal\Tests\UnitTestCase;
use Drupal\group\Entity\GroupInterface;
use Drupal\group\Plugin\Group\Relation\GroupRelationTypeManagerInterface;
use Drupal\localgov_microsites_group\ContentTypeHelper;
use Drupal\localgov_microsites_sitemap\MicrositeSitemapManager;

/**
 * Tests variant naming and group scoped lookups.
 *
 * @coversDefaultClass \Drupal\localgov_microsites_sitemap\MicrositeSitemapManager
 *
 * @group localgov_microsites_sitemap
 */
#[Group('localgov_microsites_sitemap')]
class MicrositeSitemapManagerTest extends UnitTestCase {

  /**
   * Variant IDs are derived from the group ID.
   *
   * @covers ::getHreflangSitemapId
   * @covers ::getIndexSitemapId
   */
  public function testSitemapIdsAreDerivedFromTheGroup(): void {
    $manager = $this->createManager($this->createMock(EntityStorageInterface::class));
    $group = $this->createGroup(7);

    $this->assertSame('lgd_ms_7', $manager->getHreflangSitemapId($group));
    $this->assertSame('lgd_ms_index_7', $manager->getIndexSitemapId($group));
  }

  /**
   * The two variant IDs for a group never collide.
   *
   * @covers ::getHreflangSitemapId
   * @covers ::getIndexSitemapId
   */
  public function testSitemapIdsAreDistinct(): void {
    $manager = $this->createManager($this->createMock(EntityStorageInterface::class));
    $group = $this->createGroup(7);

    $this->assertNotSame(
      $manager->getHreflangSitemapId($group),
      $manager->getIndexSitemapId($group)
    );
  }

  /**
   * Variants are looked up by third party setting, not by ID.
   *
   * The group ID is stored as an integer, so the query has to match on one.
   *
   * @covers ::loadForGroup
   */
  public function testLoadForGroupQueriesTheThirdPartySetting(): void {
    $expected = [
      'third_party_settings.localgov_microsites_sitemap.localgov_microsites_group_id' => 7,
    ];

    $storage = $this->createMock(EntityStorageInterface::class);
    $storage->expects($this->once())
      ->method('loadByProperties')
      ->with($this->identicalTo($expected))
      ->willReturn([]);

    $this->createManager($storage)->loadForGroup($this->createGroup(7));
  }

  /**
   * Whatever the storage reports for the group is returned untouched.
   *
   * @covers ::loadForGroup
   */
  public function testLoadForGroupReturnsTheStorageResult(): void {
    $variants = ['lgd_ms_7_1' => (object) ['id' => 'lgd_ms_7_1']];

    $storage = $this->createMock(EntityStorageInterface::class);
    $storage->method('loadByProperties')->willReturn($variants);

    $this->assertSame(
      $variants,
      $this->createManager($storage)->loadForGroup($this->createGroup(7))
    );
  }

  /**
   * Builds a manager whose sitemap storage is the given mock.
   *
   * @param \Drupal\Core\Entity\EntityStorageInterface $storage
   *   The sitemap variant storage.
   *
   * @return \Drupal\localgov_microsites_sitemap\MicrositeSitemapManager
   *   The manager under test.
   */
  protected function createManager(EntityStorageInterface $storage): MicrositeSitemapManager {
    $entity_type_manager = $this->createMock(EntityTypeManagerInterface::class);
    $entity_type_manager->method('getStorage')
      ->with('simple_sitemap')
      ->willReturn($storage);

    return new MicrositeSitemapManager(
      $entity_type_manager,
      $this->createMock(ConfigFactoryInterface::class),
      $this->createMock(ContentTypeHelper::class),
      $this->createMock(GroupRelationTypeManagerInterface::class),
    );
  }

  /**
   * Builds a group reporting the given ID.
   *
   * @param int $id
   *   The group ID.
   *
   * @return \Drupal\group\Entity\GroupInterface
   *   The mocked group.
   */
  protected function createGroup(int $id): GroupInterface {
    $group = $this->createMock(GroupInterface::class);
    // Entity IDs come back from storage as strings.
    $group->method('id')->willReturn((string) $id);

    return $group;
  }

}
