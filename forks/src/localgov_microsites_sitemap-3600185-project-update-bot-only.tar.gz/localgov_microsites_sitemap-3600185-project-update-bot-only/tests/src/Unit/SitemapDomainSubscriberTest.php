<?php

declare(strict_types=1);

namespace Drupal\Tests\localgov_microsites_sitemap\Unit;

use PHPUnit\Framework\Attributes\Group;
use Drupal\Core\Entity\EntityRepositoryInterface;
use Drupal\Tests\UnitTestCase;
use Drupal\domain\DomainInterface;
use Drupal\domain\DomainNegotiatorInterface;
use Drupal\group\Entity\GroupInterface;
use Drupal\localgov_microsites_sitemap\EventSubscriber\SitemapDomainSubscriber;
use Drupal\localgov_microsites_sitemap\MicrositeSitemapManager;
use Drupal\simple_sitemap\Entity\SimpleSitemapInterface;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpKernel\Event\RequestEvent;
use Symfony\Component\HttpKernel\Exception\NotFoundHttpException;
use Symfony\Component\HttpKernel\HttpKernelInterface;

/**
 * Tests the routing of /sitemap.xml to a microsite's own sitemap variant.
 *
 * @coversDefaultClass \Drupal\localgov_microsites_sitemap\EventSubscriber\SitemapDomainSubscriber
 *
 * @group localgov_microsites_sitemap
 */
#[Group('localgov_microsites_sitemap')]
class SitemapDomainSubscriberTest extends UnitTestCase {

  /**
   * The UUID of the group used throughout these tests.
   */
  const GROUP_UUID = 'a0e1b2c3-d4e5-6789-abcd-ef0123456789';

  /**
   * Requests that are none of the subscriber's business are left untouched.
   *
   * @covers ::onRequest
   */
  public function testSubRequestIsIgnored(): void {
    $subscriber = $this->createSubscriber($this->createMicrositeDomain());
    $event = $this->createEvent('/sitemap.xml', HttpKernelInterface::SUB_REQUEST);

    $subscriber->onRequest($event);

    $this->assertFalse($event->getRequest()->attributes->has('variant'));
  }

  /**
   * Only /sitemap.xml is handled; other paths pass through.
   *
   * @covers ::onRequest
   */
  public function testOtherPathIsIgnored(): void {
    $subscriber = $this->createSubscriber($this->createMicrositeDomain());
    $event = $this->createEvent('/node/1');

    $subscriber->onRequest($event);

    $this->assertFalse($event->getRequest()->attributes->has('variant'));
  }

  /**
   * An explicitly requested variant is not overridden.
   *
   * @covers ::onRequest
   */
  public function testExistingVariantAttributeIsRespected(): void {
    $subscriber = $this->createSubscriber($this->createMicrositeDomain());
    $event = $this->createEvent('/sitemap.xml', HttpKernelInterface::MAIN_REQUEST, [
      'variant' => 'some_other_sitemap',
    ]);

    $subscriber->onRequest($event);

    $this->assertSame('some_other_sitemap', $event->getRequest()->attributes->get('variant'));
  }

  /**
   * With no active domain there is no microsite to resolve.
   *
   * @covers ::onRequest
   */
  public function testNoActiveDomainIsIgnored(): void {
    $subscriber = $this->createSubscriber(NULL);
    $event = $this->createEvent('/sitemap.xml');

    $subscriber->onRequest($event);

    $this->assertFalse($event->getRequest()->attributes->has('variant'));
  }

  /**
   * The control site keeps serving the default sitemap.
   *
   * A domain with no group attached is not a microsite, so simple_sitemap is
   * left to handle the request on its own.
   *
   * @covers ::onRequest
   */
  public function testControlSiteRequestPassesThrough(): void {
    $domain = $this->createMock(DomainInterface::class);
    $domain->method('getThirdPartySetting')->willReturn(NULL);

    $subscriber = $this->createSubscriber($domain);
    $event = $this->createEvent('/sitemap.xml');

    $subscriber->onRequest($event);

    $this->assertFalse($event->getRequest()->attributes->has('variant'));
  }

  /**
   * A microsite domain pointing at a missing group is a 404.
   *
   * @covers ::onRequest
   */
  public function testUnloadableGroupIsNotFound(): void {
    $subscriber = $this->createSubscriber($this->createMicrositeDomain(), NULL);
    $event = $this->createEvent('/sitemap.xml');

    $this->expectException(NotFoundHttpException::class);
    $subscriber->onRequest($event);
  }

  /**
   * A microsite with no sitemap variant at all is a 404.
   *
   * It must not fall through to the control site's default sitemap.
   *
   * @covers ::onRequest
   */
  public function testMicrositeWithoutVariantIsNotFound(): void {
    $subscriber = $this->createSubscriber(
      $this->createMicrositeDomain(),
      $this->createMock(GroupInterface::class),
      []
    );
    $event = $this->createEvent('/sitemap.xml');

    $this->expectException(NotFoundHttpException::class);
    $subscriber->onRequest($event);
  }

  /**
   * A microsite whose only variant is disabled is a 404.
   *
   * @covers ::onRequest
   */
  public function testMicrositeWithOnlyDisabledVariantIsNotFound(): void {
    $subscriber = $this->createSubscriber(
      $this->createMicrositeDomain(),
      $this->createMock(GroupInterface::class),
      [
        'lgd_ms_7' => $this->createVariant(MicrositeSitemapManager::SITEMAP_TYPE_HREFLANG, FALSE),
      ]
    );
    $event = $this->createEvent('/sitemap.xml');

    $this->expectException(NotFoundHttpException::class);
    $subscriber->onRequest($event);
  }

  /**
   * The hreflang variant is the one served at /sitemap.xml.
   *
   * @covers ::onRequest
   * @covers ::resolveSitemapVariant
   */
  public function testHreflangVariantIsPreferred(): void {
    $subscriber = $this->createSubscriber(
      $this->createMicrositeDomain(),
      $this->createMock(GroupInterface::class),
      [
        'lgd_ms_index_7' => $this->createVariant(MicrositeSitemapManager::SITEMAP_TYPE_INDEX, TRUE),
        'lgd_ms_7' => $this->createVariant(MicrositeSitemapManager::SITEMAP_TYPE_HREFLANG, TRUE),
      ]
    );
    $event = $this->createEvent('/sitemap.xml');

    $subscriber->onRequest($event);

    $this->assertSame('lgd_ms_7', $event->getRequest()->attributes->get('variant'));
  }

  /**
   * A disabled hreflang variant is skipped in favour of an enabled sibling.
   *
   * @covers ::resolveSitemapVariant
   */
  public function testFallsBackToOtherEnabledVariant(): void {
    $subscriber = $this->createSubscriber(
      $this->createMicrositeDomain(),
      $this->createMock(GroupInterface::class),
      [
        'lgd_ms_7' => $this->createVariant(MicrositeSitemapManager::SITEMAP_TYPE_HREFLANG, FALSE),
        'lgd_ms_index_7' => $this->createVariant(MicrositeSitemapManager::SITEMAP_TYPE_INDEX, TRUE),
      ]
    );
    $event = $this->createEvent('/sitemap.xml');

    $subscriber->onRequest($event);

    $this->assertSame('lgd_ms_index_7', $event->getRequest()->attributes->get('variant'));
  }

  /**
   * A variant ID carrying a uniqueness suffix still resolves.
   *
   * The subscriber must not reconstruct IDs from the group; it reads whatever
   * the manager reports for the group.
   *
   * @covers ::resolveSitemapVariant
   */
  public function testSuffixedVariantIdIsResolved(): void {
    $subscriber = $this->createSubscriber(
      $this->createMicrositeDomain(),
      $this->createMock(GroupInterface::class),
      [
        'lgd_ms_7_1' => $this->createVariant(MicrositeSitemapManager::SITEMAP_TYPE_HREFLANG, TRUE),
      ]
    );
    $event = $this->createEvent('/sitemap.xml');

    $subscriber->onRequest($event);

    $this->assertSame('lgd_ms_7_1', $event->getRequest()->attributes->get('variant'));
  }

  /**
   * Builds a subscriber with the given collaborators stubbed out.
   *
   * @param \Drupal\domain\DomainInterface|null $domain
   *   The domain the negotiator should report as active.
   * @param \Drupal\group\Entity\GroupInterface|null $group
   *   The group the entity repository should resolve the UUID to.
   * @param array $variants
   *   Sitemap variants the manager should report for the group.
   *
   * @return \Drupal\localgov_microsites_sitemap\EventSubscriber\SitemapDomainSubscriber
   *   The subscriber under test.
   */
  protected function createSubscriber(?DomainInterface $domain, ?GroupInterface $group = NULL, array $variants = []): SitemapDomainSubscriber {
    $negotiator = $this->createMock(DomainNegotiatorInterface::class);
    $negotiator->method('getActiveDomain')->willReturn($domain);

    $repository = $this->createMock(EntityRepositoryInterface::class);
    $repository->method('loadEntityByUuid')->willReturn($group);

    $manager = $this->createMock(MicrositeSitemapManager::class);
    $manager->method('loadForGroup')->willReturn($variants);

    return new SitemapDomainSubscriber($negotiator, $repository, $manager);
  }

  /**
   * Builds a domain that belongs to a microsite group.
   *
   * @return \Drupal\domain\DomainInterface
   *   The mocked domain.
   */
  protected function createMicrositeDomain(): DomainInterface {
    $domain = $this->createMock(DomainInterface::class);
    $domain->method('getThirdPartySetting')
      ->with('group_context_domain', 'group_uuid')
      ->willReturn(self::GROUP_UUID);

    return $domain;
  }

  /**
   * Builds a sitemap variant of the given type.
   *
   * @param string $type
   *   The sitemap type ID.
   * @param bool $enabled
   *   Whether the variant is enabled. Note this is isEnabled(), the config
   *   flag, and not status(), which additionally requires the sitemap to have
   *   been generated.
   *
   * @return \Drupal\simple_sitemap\Entity\SimpleSitemapInterface
   *   The mocked variant.
   */
  protected function createVariant(string $type, bool $enabled): SimpleSitemapInterface {
    $sitemap = $this->createMock(SimpleSitemapInterface::class);
    $sitemap->method('isEnabled')->willReturn($enabled);
    $sitemap->method('get')->with('type')->willReturn($type);

    return $sitemap;
  }

  /**
   * Builds a request event for the given path.
   *
   * @param string $path
   *   The requested path.
   * @param int $type
   *   The request type, main or sub request.
   * @param array $attributes
   *   Request attributes to set, as routing would have done.
   *
   * @return \Symfony\Component\HttpKernel\Event\RequestEvent
   *   The request event.
   */
  protected function createEvent(string $path, int $type = HttpKernelInterface::MAIN_REQUEST, array $attributes = []): RequestEvent {
    $request = Request::create('http://microsite.example.com' . $path);
    foreach ($attributes as $key => $value) {
      $request->attributes->set($key, $value);
    }

    return new RequestEvent($this->createMock(HttpKernelInterface::class), $request, $type);
  }

}
