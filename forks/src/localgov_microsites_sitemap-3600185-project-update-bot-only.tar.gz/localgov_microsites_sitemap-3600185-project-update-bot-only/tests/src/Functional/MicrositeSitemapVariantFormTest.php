<?php

declare(strict_types=1);

namespace Drupal\Tests\localgov_microsites_sitemap\Functional;

use PHPUnit\Framework\Attributes\Group;
use PHPUnit\Framework\Attributes\RunTestsInSeparateProcesses;
use Drupal\Tests\BrowserTestBase;
use Drupal\Tests\localgov_microsites_group\Traits\GroupCreationTrait;
use Drupal\Tests\localgov_microsites_group\Traits\InitializeGroupsTrait;
use Drupal\localgov_microsites_sitemap\MicrositeSitemapManager;

/**
 * Tests the microsite group selector on the sitemap variant form.
 *
 * @group localgov_microsites_sitemap
 */
#[Group('localgov_microsites_sitemap')]
#[RunTestsInSeparateProcesses]
class MicrositeSitemapVariantFormTest extends BrowserTestBase {

  use InitializeGroupsTrait;
  use GroupCreationTrait;

  /**
   * The form field added to microsite sitemap variants.
   */
  const FIELD_NAME = MicrositeSitemapManager::THIRD_PARTY_SETTING_GROUP_ID_KEY;

  /**
   * {@inheritdoc}
   */
  protected static $modules = [
    'localgov_core',
    'localgov_media',
  ];

  /**
   * {@inheritdoc}
   *
   * Prevent check for config schema raising errors.
   */
  protected static $configSchemaCheckerExclusions = [
    'pathauto.pattern.localgov_page',
    'core.entity_form_display.paragraph.localgov_image.default',
    'core.entity_form_display.paragraph.localgov_featured_campaign.default',
    'core.entity_form_display.paragraph.localgov_newsroom_teaser.default',
    'core.entity_form_display.paragraph.localgov_banner_primary.default',
    'core.entity_form_display.paragraph.localgov_banner_secondary.default',
    'core.entity_form_display.paragraph.localgov_box_link.default',
    'core.entity_form_display.paragraph.localgov_call_out_box.default',
    'core.entity_form_display.paragraph.localgov_featured_subsite.default',
    'core.entity_form_display.paragraph.localgov_featured_teaser.default',
    'core.entity_form_display.paragraph.localgov_key_contact_item.default',
    'core.entity_form_display.paragraph.localgov_media_with_text.default',
  ];

  /**
   * {@inheritdoc}
   */
  protected $defaultTheme = 'stark';

  /**
   * The microsite sitemap manager.
   *
   * @var \Drupal\localgov_microsites_sitemap\MicrositeSitemapManager
   */
  protected MicrositeSitemapManager $sitemapManager;

  /**
   * {@inheritdoc}
   */
  protected function setUp(): void {
    parent::setUp();

    $this->container->get('module_installer')->install([
      'localgov_microsites_group',
      'simple_sitemap',
      'localgov_microsites_sitemap',
    ]);
    $this->rebuildContainer();

    $this->sitemapManager = $this->container->get('localgov_microsites_sitemap.manager');

    $this->drupalLogin($this->drupalCreateUser(['administer sitemap settings']));
  }

  /**
   * A microsite variant's form shows the group it is scoped to.
   */
  public function testGroupSelectorShowsCurrentMicrosite(): void {
    $this->createMicrositeGroups([], 1);
    $group = $this->groups[1];

    $this->drupalGet('/admin/config/search/simplesitemap/variants/lgd_ms_' . $group->id());

    $this->assertSession()->statusCodeEquals(200);
    $this->assertSession()->fieldExists(self::FIELD_NAME);
    $this->assertSession()->fieldValueEquals(self::FIELD_NAME, $group->id());
  }

  /**
   * The selector is not offered on variants that are not microsite ones.
   */
  public function testGroupSelectorAbsentFromDefaultVariant(): void {
    $this->drupalGet('/admin/config/search/simplesitemap/variants/default');

    $this->assertSession()->statusCodeEquals(200);
    $this->assertSession()->fieldNotExists(self::FIELD_NAME);
  }

  /**
   * Clearing the selector detaches the variant from its microsite.
   */
  public function testDetachingVariantFromMicrosite(): void {
    $this->createMicrositeGroups([], 1);
    $group = $this->groups[1];

    $this->drupalGet('/admin/config/search/simplesitemap/variants/lgd_ms_' . $group->id());
    $this->submitForm([self::FIELD_NAME => ''], 'Save');

    $variants = $this->sitemapManager->loadForGroup($group);

    $this->assertArrayNotHasKey('lgd_ms_' . $group->id(), $variants);
    $this->assertArrayHasKey('lgd_ms_index_' . $group->id(), $variants);
  }

  /**
   * Reassigning the selector moves the variant to another microsite.
   */
  public function testReassigningVariantToAnotherMicrosite(): void {
    $this->createMicrositeGroups([], 2);
    $from = $this->groups[1];
    $to = $this->groups[2];

    $this->drupalGet('/admin/config/search/simplesitemap/variants/lgd_ms_' . $from->id());
    $this->submitForm([self::FIELD_NAME => $to->id()], 'Save');

    $this->assertArrayNotHasKey('lgd_ms_' . $from->id(), $this->sitemapManager->loadForGroup($from));
    $this->assertArrayHasKey('lgd_ms_' . $from->id(), $this->sitemapManager->loadForGroup($to));
  }

}
