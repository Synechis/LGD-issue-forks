<?php

declare(strict_types=1);

namespace Drupal\Tests\localgov_microsites_sitemap\Functional;

use PHPUnit\Framework\Attributes\Group;
use PHPUnit\Framework\Attributes\RunTestsInSeparateProcesses;
use Drupal\Tests\BrowserTestBase;
use Drupal\Tests\localgov_microsites_group\Traits\GroupCreationTrait;
use Drupal\Tests\localgov_microsites_group\Traits\InitializeGroupsTrait;
use Drupal\group\Entity\GroupType;
use Drupal\group\Entity\Storage\GroupRelationshipTypeStorageInterface;
use Drupal\localgov_microsites_sitemap\MicrositeSitemapManager;

/**
 * Tests that sitemap variants follow the lifecycle of microsite groups.
 *
 * @group localgov_microsites_sitemap
 */
#[Group('localgov_microsites_sitemap')]
#[RunTestsInSeparateProcesses]
class MicrositeSitemapLifecycleTest extends BrowserTestBase {

  use InitializeGroupsTrait;
  use GroupCreationTrait;

  /**
   * {@inheritdoc}
   */
  protected static $modules = [
    'localgov_core',
    'localgov_media',
  ];

  /**
   * {@inheritdoc}
   *
   * Prevent check for config schema raising errors.
   */
  protected static $configSchemaCheckerExclusions = [
    'pathauto.pattern.localgov_page',
    'core.entity_form_display.paragraph.localgov_image.default',
    'core.entity_form_display.paragraph.localgov_featured_campaign.default',
    'core.entity_form_display.paragraph.localgov_newsroom_teaser.default',
    'core.entity_form_display.paragraph.localgov_banner_primary.default',
    'core.entity_form_display.paragraph.localgov_banner_secondary.default',
    'core.entity_form_display.paragraph.localgov_box_link.default',
    'core.entity_form_display.paragraph.localgov_call_out_box.default',
    'core.entity_form_display.paragraph.localgov_featured_subsite.default',
    'core.entity_form_display.paragraph.localgov_featured_teaser.default',
    'core.entity_form_display.paragraph.localgov_key_contact_item.default',
    'core.entity_form_display.paragraph.localgov_media_with_text.default',
  ];

  /**
   * {@inheritdoc}
   */
  protected $defaultTheme = 'stark';

  /**
   * The microsite sitemap manager.
   *
   * @var \Drupal\localgov_microsites_sitemap\MicrositeSitemapManager
   */
  protected MicrositeSitemapManager $sitemapManager;

  /**
   * {@inheritdoc}
   */
  protected function setUp(): void {
    parent::setUp();

    $this->container->get('module_installer')->install([
      'localgov_microsites_group',
      'simple_sitemap',
      'localgov_microsites_sitemap',
    ]);
    $this->rebuildContainer();

    // A content type the microsite group type can hold, so that there is a
    // predictable bundle to assert against.
    $this->drupalCreateContentType([
      'type' => 'test_page',
      'name' => 'Test page',
    ]);

    $group_type = $this->getEntityTypeManager()->getStorage('group_type')->load('microsite');
    assert($group_type instanceof GroupType);
    $storage = $this->getEntityTypeManager()->getStorage('group_relationship_type');
    assert($storage instanceof GroupRelationshipTypeStorageInterface);
    $storage->save($storage->createFromPlugin($group_type, 'group_node:test_page'));

    $this->sitemapManager = $this->container->get('localgov_microsites_sitemap.manager');
  }

  /**
   * Creating a microsite creates its two sitemap variants.
   */
  public function testVariantsCreatedForNewMicrosite(): void {
    $this->createMicrositeGroups([], 1);
    $group = $this->groups[1];

    $variants = $this->sitemapManager->loadForGroup($group);

    $this->assertCount(2, $variants);
    $this->assertArrayHasKey('lgd_ms_' . $group->id(), $variants);
    $this->assertArrayHasKey('lgd_ms_index_' . $group->id(), $variants);

    $hreflang = $variants['lgd_ms_' . $group->id()];
    $this->assertSame(MicrositeSitemapManager::SITEMAP_TYPE_HREFLANG, $hreflang->get('type'));
    // isEnabled() is the config flag. status() would be FALSE here because the
    // sitemap has not been generated yet.
    $this->assertTrue($hreflang->isEnabled());
    $this->assertSame(
      (int) $group->id(),
      $hreflang->getThirdPartySetting(
        MicrositeSitemapManager::MODULE_NAME,
        MicrositeSitemapManager::THIRD_PARTY_SETTING_GROUP_ID_KEY
      )
    );

    $index = $variants['lgd_ms_index_' . $group->id()];
    $this->assertSame(MicrositeSitemapManager::SITEMAP_TYPE_INDEX, $index->get('type'));
  }

  /**
   * Each microsite gets its own variants, scoped to its own group.
   */
  public function testVariantsAreScopedPerMicrosite(): void {
    $this->createMicrositeGroups([], 2);

    $first = $this->sitemapManager->loadForGroup($this->groups[1]);
    $second = $this->sitemapManager->loadForGroup($this->groups[2]);

    $this->assertCount(2, $first);
    $this->assertCount(2, $second);
    $this->assertEmpty(array_intersect_key($first, $second));
  }

  /**
   * Content types available to the microsite are indexed by its sitemap.
   */
  public function testBundleSettingsCoverMicrositeContentTypes(): void {
    $this->createMicrositeGroups([], 1);
    $group = $this->groups[1];

    $settings = $this->config('simple_sitemap.bundle_settings.lgd_ms_' . $group->id() . '.node.test_page');

    $this->assertFalse($settings->isNew(), 'Bundle settings were written for the microsite content type.');
    $this->assertTrue((bool) $settings->get('index'));
  }

  /**
   * Deleting a microsite removes its variants and their bundle settings.
   */
  public function testVariantsRemovedWithMicrosite(): void {
    $this->createMicrositeGroups([], 1);
    $group = $this->groups[1];
    $hreflang_id = 'lgd_ms_' . $group->id();

    // Guard the precondition, so a failure below means what it says.
    $this->assertNotEmpty($this->sitemapManager->loadForGroup($group));
    $this->assertNotEmpty(
      $this->container->get('config.factory')->listAll('simple_sitemap.bundle_settings.' . $hreflang_id . '.')
    );

    $group->delete();

    $this->assertEmpty($this->sitemapManager->loadForGroup($group));
    $this->assertEmpty(
      $this->container->get('config.factory')->listAll('simple_sitemap.bundle_settings.' . $hreflang_id . '.'),
      'Bundle settings are not config dependencies of the variant, so they must be deleted explicitly.'
    );
  }

  /**
   * Deleting one microsite leaves the others' sitemaps alone.
   */
  public function testDeletingOneMicrositeKeepsOthers(): void {
    $this->createMicrositeGroups([], 2);

    $this->groups[1]->delete();

    $this->assertEmpty($this->sitemapManager->loadForGroup($this->groups[1]));
    $this->assertCount(2, $this->sitemapManager->loadForGroup($this->groups[2]));
  }

}
