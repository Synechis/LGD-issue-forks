<?php

namespace Drupal\localgov_waste_collection\Plugin\paragraphs\Behavior;

use Drupal\Core\Entity\Display\EntityViewDisplayInterface;
use Drupal\Core\Entity\EntityFieldManagerInterface;
use Drupal\Core\Form\FormBuilderInterface;
use Drupal\Core\StringTranslation\TranslatableMarkup;
use Drupal\localgov_waste_collection\Form\PostcodeForm;
use Drupal\paragraphs\Attribute\ParagraphsBehavior;
use Drupal\paragraphs\Entity\Paragraph;
use Drupal\paragraphs\ParagraphsBehaviorBase;
use Symfony\Component\DependencyInjection\ContainerInterface;

/**
 * Paragraph behaviour which shows the waste collection postcode lookup form.
 */
#[ParagraphsBehavior(
  id: 'localgov_waste_collection_form',
  label: new TranslatableMarkup('LocalGov waste collection postcode form'),
  description: new TranslatableMarkup('Shows a form for the user to enter their postcode to look up waste collection details.'),
)]
class LocalgovWasteCollectionParagraphBehaviour extends ParagraphsBehaviorBase {

  /**
   * The form builder service.
   *
   * @var \Drupal\Core\Form\FormBuilderInterface
   */
  protected $formBuilder;

  /**
   * {@inheritdoc}
   */
  public static function create(ContainerInterface $container, array $configuration, $plugin_id, $plugin_definition) {
    return new static(
      $configuration,
      $plugin_id,
      $plugin_definition,
      $container->get('entity_field.manager'),
      $container->get('form_builder'),
    );
  }

  /**
   * Creates a LocalgovWasteCollectionParagraphBehaviour instance.
   *
   * @param array $configuration
   *   A configuration array containing information about the plugin instance.
   * @param string $plugin_id
   *   The plugin_id for the plugin instance.
   * @param mixed $plugin_definition
   *   The plugin implementation definition.
   * @param \Drupal\Core\Entity\EntityFieldManagerInterface $entity_field_manager
   *   The entity field manager.
   * @param \Drupal\Core\Form\FormBuilderInterface $form_builder
   *   The form builder service.
   */
  public function __construct(
    array $configuration,
    $plugin_id,
    $plugin_definition,
    EntityFieldManagerInterface $entity_field_manager,
    FormBuilderInterface $form_builder,
  ) {
    parent::__construct($configuration, $plugin_id, $plugin_definition, $entity_field_manager);
    $this->formBuilder = $form_builder;
  }

  /**
   * {@inheritdoc}
   */
  public function view(array &$build, Paragraph $paragraph, EntityViewDisplayInterface $display, $view_mode) {
    $build['localgov_waste_collection'] = [
      '#type' => 'container',
    ];

    if ($view_mode == 'preview') {
      // Don't show the form in the preview mode in a paragraph field widget,
      // as it will interfere with saving the host entity.
      $build['localgov_waste_collection']['form'] = [
        '#markup' => $this->t('Postcode form'),
      ];
    }
    else {
      $build['localgov_waste_collection']['form'] = $this->formBuilder->getForm(PostcodeForm::class);
    }
  }

}
