<?php

namespace Drupal\Tests\localgov_services_page\FunctionalJavascript;

use Drupal\FunctionalJavascriptTests\WebDriverTestBase;
use Drupal\node\NodeInterface;
use Drupal\paragraphs_library\Entity\LibraryItem;
use Drupal\Tests\node\Traits\NodeCreationTrait;
use PHPUnit\Framework\Attributes\Group;
use PHPUnit\Framework\Attributes\RunTestsInSeparateProcesses;

/**
 * Tests reusing a paragraph across service pages.
 *
 * Promote should be a button on this widget, not a dropdown action.
 *
 * @group localgov_services
 */
#[Group('localgov_services')]
#[RunTestsInSeparateProcesses]
class ReusableParagraphEditorTest extends WebDriverTestBase {

  use NodeCreationTrait;

  /**
   * The field.
   */
  const FIELD = 'localgov_trad_paragraph_content';

  /**
   * Initial content snippet.
   */
  const FIRST = 'Recycling centres close at 4pm on Sundays.';

  /**
   * Snippet for the change in the library.
   */
  const SECOND = 'Recycling centres close at 5pm on Sundays from October.';

  /**
   * {@inheritdoc}
   */
  protected $defaultTheme = 'claro';

  /**
   * {@inheritdoc}
   */
  protected static $modules = [
    'localgov_media',
  ];

  /**
   * The first service page.
   *
   * @var \Drupal\node\NodeInterface
   */
  protected $pageA;

  /**
   * The second service page.
   *
   * @var \Drupal\node\NodeInterface
   */
  protected $pageB;

  /**
   * {@inheritdoc}
   */
  protected function setUp(): void {
    parent::setUp();
    // Install dependencies here to include optional configuration in D11.
    // Note: localgov_core installed separately to install body field storage.
    $installer = $this->container->get('module_installer');
    $installer->install(['localgov_core']);
    $installer->install(['localgov_services_page']);
    $this->rebuildContainer();

    foreach (['A', 'B'] as $letter) {
      $this->{'page' . $letter} = $this->createNode([
        'type' => 'localgov_services_page',
        'title' => 'Recycling page ' . $letter,
        'body' => ['value' => 'Where to take it.', 'summary' => 'Recycling.', 'format' => 'wysiwyg'],
        'status' => NodeInterface::PUBLISHED,
      ]);
    }

    $this->drupalLogin($this->drupalCreateUser([
      'access content',
      'edit any localgov_services_page content',
      'create paragraph library item',
      'edit paragraph library item',
      'administer paragraphs library',
      'access paragraphs_library_items entity browser pages',
      'use text format wysiwyg',
    ]));
  }

  /**
   * Write once, promote, reuse, edit once; check both pages.
   */
  public function testPromoteReuseAndEdit(): void {
    $assert = $this->assertSession();
    $page = $this->getSession()->getPage();

    $this->drupalGet($this->pageA->toUrl('edit-form'));
    $page->pressButton('Add Paragraph');
    $dialog = $assert->waitForElementVisible('css', 'div.ui-dialog');
    $dialog->pressButton('Text');
    $assert->assertWaitOnAjaxRequest();
    $this->writeInParagraphEditor(0, self::FIRST);

    $promote = $assert->waitForElementVisible('css', 'input[name="' . self::FIELD . '_0_promote_to_library"]');
    $this->assertFalse($promote->hasClass('paragraphs-dropdown-action'), 'Promote to library is a header button.');
    $promote->press();
    $assert->assertWaitOnAjaxRequest();
    $assert->waitForElementVisible('css', 'input[name="' . self::FIELD . '_0_unlink_from_library"]');

    $items = LibraryItem::loadMultiple();
    $this->assertCount(1, $items, 'One reusable paragraph now exists in the library.');
    $item = reset($items);
    $this->assertStringContainsString(self::FIRST, $item->get('paragraphs')->entity->get('localgov_text')->value);

    $page->pressButton('Save');
    $assert->waitForText(self::FIRST);
    $assert->pageTextContains(self::FIRST);
    $this->assertSame(self::FIELD, $this->fieldShowing(self::FIRST), 'The text renders from the Rich content field.');

    $this->drupalGet($this->pageB->toUrl('edit-form'));
    $page->pressButton('Add Paragraph');
    $dialog = $assert->waitForElementVisible('css', 'div.ui-dialog');
    $dialog->pressButton('From reusable paragraph library');
    $assert->assertWaitOnAjaxRequest();

    $assert->waitForElementVisible('css', 'input[value="Select reusable paragraph"]')->press();
    $assert->waitForElementVisible('css', 'iframe[name="entity_browser_iframe_paragraphs_library_items"]');
    $this->getSession()->switchToIFrame('entity_browser_iframe_paragraphs_library_items');
    $assert->waitForElementVisible('css', 'input[name^="entity_browser_select"]')->click();
    $page->pressButton('Select reusable paragraph');
    $this->getSession()->switchToIFrame();
    $assert->assertWaitOnAjaxRequest();
    $assert->waitForElementRemoved('css', 'iframe[name="entity_browser_iframe_paragraphs_library_items"]');
    $assert->waitForText($item->label());

    $page->pressButton('Save');
    $assert->waitForText(self::FIRST);
    $assert->pageTextContains(self::FIRST);

    $this->drupalGet($item->toUrl('edit-form'));
    $this->writeInLibraryEditor(self::SECOND);
    $page->pressButton('Save');

    foreach ([$this->pageA, $this->pageB] as $node) {
      $this->drupalGet($node->toUrl());
      $assert->pageTextContains(self::SECOND);
      $assert->pageTextNotContains(self::FIRST);
    }
  }

  /**
   * Replaces the content on the node form.
   */
  protected function writeInParagraphEditor(int $delta, string $text): void {
    $selector = 'textarea[name="' . self::FIELD . '[' . $delta . '][subform][localgov_text][0][value]"]';
    $this->setEditorData($selector, $text);
  }

  /**
   * Replaces the content on the library item form.
   */
  protected function writeInLibraryEditor(string $text): void {
    $this->setEditorData('textarea[name="paragraphs[0][subform][localgov_text][0][value]"]', $text);
  }

  /**
   * Sets a CKEditor 5 instance's content through its API.
   */
  protected function setEditorData(string $textarea_selector, string $text): void {
    $textarea = $this->assertSession()->waitForElement('css', $textarea_selector);
    $this->assertNotNull($textarea, 'The text field is on the form.');
    $this->assertSession()->waitForElementVisible('css', '.ck-editor__editable');
    $this->getSession()->wait(10000, "document.querySelector('$textarea_selector').dataset.ckeditor5Id !== undefined && Drupal.CKEditor5Instances.get(document.querySelector('$textarea_selector').dataset.ckeditor5Id) !== undefined");
    $this->getSession()->executeScript("Drupal.CKEditor5Instances.get(document.querySelector('$textarea_selector').dataset.ckeditor5Id).setData('<p>$text</p>');");
  }

  /**
   * Gets the node field whose rendered output has the text snippet.
   */
  protected function fieldShowing(string $text): ?string {
    foreach ($this->getSession()->getPage()->findAll('css', '.node [class*="field--name-"]') as $element) {
      if (str_contains($element->getText(), $text)) {
        preg_match('/field--name-([a-z0-9-]+)/', $element->getAttribute('class'), $matches);
        return str_replace('-', '_', $matches[1]);
      }
    }
    return NULL;
  }

}
