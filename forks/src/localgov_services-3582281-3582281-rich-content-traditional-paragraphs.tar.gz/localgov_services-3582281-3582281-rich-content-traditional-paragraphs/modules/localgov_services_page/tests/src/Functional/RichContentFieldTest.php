<?php

namespace Drupal\Tests\localgov_services_page\Functional;

use Drupal\Core\Config\FileStorage;
use Drupal\Core\Entity\Entity\EntityFormDisplay;
use Drupal\Core\Entity\Entity\EntityViewDisplay;
use Drupal\field\Entity\FieldConfig;
use Drupal\field\Entity\FieldStorageConfig;
use Drupal\node\NodeInterface;
use Drupal\paragraphs\Entity\Paragraph;
use Drupal\paragraphs\Entity\ParagraphsType;
use Drupal\Tests\BrowserTestBase;
use Drupal\Tests\node\Traits\NodeCreationTrait;
use PHPUnit\Framework\Attributes\Group;
use PHPUnit\Framework\Attributes\RunTestsInSeparateProcesses;

/**
 * Tests the Rich content field on service pages.
 *
 * @group localgov_services
 */
#[Group('localgov_services')]
#[RunTestsInSeparateProcesses]
class RichContentFieldTest extends BrowserTestBase {

  use NodeCreationTrait;

  /**
   * The field on service pages.
   */
  const FIELD = 'localgov_trad_paragraph_content';

  /**
   * The widget on the default form display.
   */
  const WIDGET = 'paragraphs';

  /**
   * The formatter on the default view display.
   */
  const FORMATTER = 'entity_reference_revisions_entity_view';

  /**
   * Paragraphs widget button helper.
   */
  const HELPER = 'localgov_paragraphs_library_buttons';

  /**
   * Configuration storage
   */
  const STORAGE_MODULE = 'localgov_paragraphs_traditional';

  /**
   * Field accepts these paragraph types.
   */
  const TARGETS = ['from_library', 'localgov_contact', 'localgov_link', 'localgov_text'];

  /**
   * {@inheritdoc}
   */
  protected $defaultTheme = 'stark';

  /**
   * {@inheritdoc}
   */
  protected static $modules = [
    'localgov_media',
  ];

  /**
   * {@inheritdoc}
   */
  protected function setUp(): void {
    parent::setUp();
    // Install dependencies here to include optional configuration in D11.
    // Note: localgov_core installed separately to install body field storage.
    $this->container->get('module_installer')->install(['localgov_core']);
    $this->container->get('module_installer')->install(['localgov_services_page']);
    $this->rebuildContainer();
  }

  /**
   * The field, displays and modules from localgov_services_page.
   */
  public function testNewSite(): void {
    $field = FieldConfig::loadByName('node', 'localgov_services_page', static::FIELD);
    $this->assertNotNull($field);
    $this->assertSame('Rich content', $field->getLabel());
    $this->assertSame('entity_reference_revisions', $field->getType());
    $this->assertSame(-1, $field->getFieldStorageDefinition()->getCardinality());
    $this->assertFalse($field->isRequired());
    $targets = array_keys($field->getSetting('handler_settings')['target_bundles']);
    sort($targets);
    $this->assertSame(static::TARGETS, $targets);
    $this->assertNull(FieldConfig::loadByName('node', 'localgov_services_page', 'localgov_page_components'), 'A new site does not get Page components on the service page.');

    $display = EntityFormDisplay::load('node.localgov_services_page.default');
    $form = $display->getComponent(static::FIELD);
    $this->assertSame(static::WIDGET, $form['type']);
    $this->assertSame(10, $form['weight']);
    $this->assertSame(['localgov_services_parent', 'title', 'body', static::FIELD], $display->getThirdPartySetting('field_group', 'group_description')['children']);

    $view = EntityViewDisplay::load('node.localgov_services_page.default')->getComponent(static::FIELD);
    $this->assertSame(static::FORMATTER, $view['type']);
    $this->assertSame('hidden', $view['label']);
    foreach (['teaser', 'search_index', 'search_result'] as $mode) {
      $this->assertNull(EntityViewDisplay::load('node.localgov_services_page.' . $mode)->getComponent(static::FIELD), "Hidden on $mode.");
    }

    $storage = FieldStorageConfig::loadByName('node', static::FIELD);
    $this->assertNotNull($storage);
    $paths = $this->container->get('extension.list.module');
    $storage_file = '/config/install/field.storage.node.' . static::FIELD . '.yml';
    $this->assertFileExists($paths->getPath(static::STORAGE_MODULE) . $storage_file);
    $this->assertFileDoesNotExist($paths->getPath('localgov_services_page') . $storage_file, 'The storage is shared, so localgov_services_page does not carry it.');

    $modules = $this->container->get('module_handler');
    foreach ([static::STORAGE_MODULE, static::HELPER, 'paragraphs_library'] as $module) {
      $this->assertTrue($modules->moduleExists($module), "$module is installed with localgov_services_page.");
    }

    foreach (['localgov_text', 'localgov_link'] as $type) {
      $this->assertTrue((bool) ParagraphsType::load($type)->getThirdPartySetting('paragraphs_library', 'allow_library_conversion'), "$type can be promoted to the library.");
    }
    $this->assertSame('From reusable paragraph library', ParagraphsType::load('from_library')->label());
    $this->assertNotNull(EntityFormDisplay::load('paragraphs_library_item.paragraphs_library_item.default'));

    $registry = $this->container->get('update.update_hook_registry');
    foreach (['localgov_services_page', 'localgov_paragraphs', static::STORAGE_MODULE, static::HELPER] as $module) {
      $pending = array_filter($registry->getAvailableUpdates($module), fn (int $number) => $number > $registry->getInstalledVersion($module));
      $this->assertSame([], $pending, "Nothing is left for drush updb to run for $module.");
    }

    $this->assertEditorSeesTheField();
    $this->assertParagraphRenders();
  }

  /**
   * Displays are compared on the field's entries only: a display's dependency
   * list is recalculated on save.
   */
  public function testShippedConfigurationIsActive(): void {
    $path = $this->container->get('extension.list.module')->getPath('localgov_services_page') . '/config/install/';
    $shipped = new FileStorage($path);
    $field_config = 'field.field.node.localgov_services_page.' . static::FIELD;

    $active = $this->config($field_config)->get();
    unset($active['uuid'], $active['_core']);
    $this->assertSame($this->sortKeys($shipped->read($field_config)), $this->sortKeys($active));

    foreach ([
      'core.entity_form_display.node.localgov_services_page.default',
      'core.entity_view_display.node.localgov_services_page.default',
      'core.entity_view_display.node.localgov_services_page.teaser',
      'core.entity_view_display.node.localgov_services_page.search_index',
      'core.entity_view_display.node.localgov_services_page.search_result',
    ] as $name) {
      $file = $shipped->read($name);
      $active = $this->config($name)->get();
      $this->assertContains($field_config, $active['dependencies']['config'], "$name depends on the field.");
      $this->assertSame($this->sortKeys($file['content'][static::FIELD] ?? []), $this->sortKeys($active['content'][static::FIELD] ?? []), "$name shows the field as shipped.");
      $this->assertSame($file['hidden'][static::FIELD] ?? NULL, $active['hidden'][static::FIELD] ?? NULL, "$name hides the field as shipped.");
    }
  }

  /**
   * An editor should get the field, inside the Content tab, on a new service page.
   */
  protected function assertEditorSeesTheField(): void {
    $this->drupalLogin($this->drupalCreateUser([
      'create localgov_services_page content',
      'access content',
    ]));
    $this->drupalGet('node/add/localgov_services_page');
    $this->assertSession()->statusCodeEquals(200);
    $this->assertSession()->pageTextContains('Rich content');
    $this->assertSession()->elementExists('css', '#edit-group-description .field--name-' . str_replace('_', '-', static::FIELD));
    $this->drupalLogout();
  }

  /**
   * A Text paragraph in the field shows on the page and not in the teaser.
   */
  protected function assertParagraphRenders(): void {
    $text = 'Recycling centres close at 4pm on Sundays.';
    $paragraph = Paragraph::create([
      'type' => 'localgov_text',
      'localgov_text' => ['value' => '<p>' . $text . '</p>', 'format' => 'wysiwyg'],
    ]);
    $paragraph->save();
    $node = $this->createNode([
      'type' => 'localgov_services_page',
      'title' => 'Recycling',
      'body' => ['value' => 'Where to take it.', 'summary' => 'Recycling.'],
      static::FIELD => [$paragraph],
      'status' => NodeInterface::PUBLISHED,
    ]);

    $this->drupalGet($node->toUrl());
    $this->assertSession()->pageTextContains($text);

    $this->container->get('module_handler')->loadAll();
    $teaser = $this->container->get('entity_type.manager')->getViewBuilder('node')->view($node, 'teaser');
    $html = (string) $this->container->get('renderer')->renderRoot($teaser);
    $this->assertStringNotContainsString($text, $html, 'The teaser does not carry the rich content.');
  }

  /**
   * Sorts an array by key, recursively; lists names by value.
   *
   * Drupal sorts dependency lists on save.
   */
  protected function sortKeys(array $data): array {
    foreach ($data as &$value) {
      if (is_array($value)) {
        $value = $this->sortKeys($value);
      }
    }
    if (array_is_list($data) && $data === array_filter($data, 'is_string')) {
      sort($data);
      return $data;
    }
    ksort($data);
    return $data;
  }

}
