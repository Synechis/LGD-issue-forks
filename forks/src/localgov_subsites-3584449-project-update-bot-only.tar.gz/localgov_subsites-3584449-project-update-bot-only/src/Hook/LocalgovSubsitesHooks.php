<?php

namespace Drupal\localgov_subsites\Hook;

use Drupal\localgov_subsites\Subsite;
use Drupal\node\NodeInterface;
use Drupal\Core\Hook\Attribute\Hook;

/**
 * Hook implementations for localgov_subsites.
 */
class LocalgovSubsitesHooks {

  /**
   * Implements hook_theme().
   */
  #[Hook('theme')]
  public function theme($existing, $type, $theme, $path): array {
    return [
      'subsite_navigation' => [
        'variables' => [
          'menu_name' => '',
          'items' => [],
          'current_entity' => NULL,
          'overview_entity' => NULL,
        ],
      ],
      'subsite_banner' => [
        'variables' => [
          'tag' => '',
          'heading' => '',
          'image' => '',
        ],
      ],
      'node__localgov_subsites_page__full' => [
        'template' => 'node--localgov-subsites-page--full',
        'base hook' => 'node',
      ],
    ];
  }

  /**
   * Implements hook_preprocess_page().
   *
   * Adds a class to the page wrapper with the name of the theme
   * if the current node is within a subsite.
   */
  #[Hook('preprocess_page')]
  public function preprocessPage(&$variables): void {
    $node = \Drupal::routeMatch()->getParameter('node');
    if (!$node instanceof NodeInterface) {
      return;
    }
    if (in_array($node->bundle(), [
      'localgov_subsites_overview',
      'localgov_subsites_page',
    ], TRUE)) {
      $subsite = \Drupal::service('class_resolver')->getInstanceFromDefinition(Subsite::class)->getSubsite($node);
      if ($subsite instanceof NodeInterface && isset($subsite->localgov_subsites_theme->value) && $theme = $subsite->localgov_subsites_theme->value) {
        $variables['attributes']['class'][] = str_replace('_', '--', $theme);
      }
    }
  }

}
