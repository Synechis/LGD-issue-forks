<?php

namespace Drupal\localgov_elections\Plugin\views\field;

use Drupal\Core\Entity\EntityTypeManagerInterface;
use Drupal\views\Plugin\views\field\FieldPluginBase;
use Drupal\views\ResultRow;
use Symfony\Component\DependencyInjection\ContainerInterface;

/**
 * Field handler to flag the node type.
 *
 * @ViewsField("election_turnout")
 */
class ElectionTurnout extends FieldPluginBase {

  /**
   * Constructs a new plugin instance.
   */
  public function __construct(array $configuration, $plugin_id, $plugin_definition, protected EntityTypeManagerInterface $entityTypeManager) {
    parent::__construct($configuration, $plugin_id, $plugin_definition);
  }

  /**
   * {@inheritdoc}
   */
  public static function create(ContainerInterface $container, array $configuration, $plugin_id, $plugin_definition) {
    return new static(
      $configuration,
      $plugin_id,
      $plugin_definition,
      $container->get('entity_type.manager'),
    );
  }

  /**
   * Leave empty to avoid a query on this field.
   */
  public function query():void {

  }

  /**
   * Per-request cache of turnout data, keyed by election NID.
   *
   * @var array<int, array{turnout: int, electorate: int}>
   */
  protected static array $turnoutCache = [];

  /**
   * Render function for the election_turnout field.
   *
   * Displays the turnout percentage and total votes for an election.
   *
   * @{inheritdoc}
   */
  public function render(ResultRow $values): string {
    $node = $values->_entity;
    $election_id = (int) $node->id();

    $data = $this->getElectionTurnout($election_id);

    if ($data['electorate'] == 0) {
      return "0%";
    }

    $percentage = round(($data['turnout'] / $data['electorate'] * 100), 1);

    return '(' . $percentage . '%) ' . $data['turnout'];
  }

  /**
   * Loads and caches turnout data for an election.
   */
  protected function getElectionTurnout(int $election_id): array {
    if (isset(static::$turnoutCache[$election_id])) {
      return static::$turnoutCache[$election_id];
    }

    $area_ids = $this->entityTypeManager->getStorage('node')->getQuery()
      ->condition('type', 'localgov_area_vote')
      ->condition('localgov_election', $election_id)
      ->accessCheck(FALSE)
      ->execute();

    $areas = $this->entityTypeManager->getStorage('node')->loadMultiple($area_ids);

    $turnout = 0;
    $electorate = 0;

    foreach ($areas as $area) {
      if ($area->get("localgov_election_no_contest")?->value == "1") {
        continue;
      }

      $turnout += (int) $area->get('localgov_election_spoils')->value;

      foreach ($area->get('localgov_election_candidates')->referencedEntities() as $candidate) {
        $turnout += (int) $candidate->get('localgov_election_votes')->value;
      }

      if ($area->localgov_election_votes_final?->value == 1) {
        $electorate += (int) $area->get('localgov_election_electorate')->value;
      }
    }

    static::$turnoutCache[$election_id] = [
      'turnout' => $turnout,
      'electorate' => $electorate,
    ];

    return static::$turnoutCache[$election_id];
  }

}
