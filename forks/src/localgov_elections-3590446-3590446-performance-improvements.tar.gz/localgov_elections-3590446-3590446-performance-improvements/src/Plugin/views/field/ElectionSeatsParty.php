<?php

namespace Drupal\localgov_elections\Plugin\views\field;

use Drupal\Core\Entity\EntityTypeManagerInterface;
use Drupal\Core\Routing\RouteMatchInterface;
use Drupal\node\NodeInterface;
use Drupal\views\Plugin\views\field\FieldPluginBase;
use Drupal\views\ResultRow;
use Symfony\Component\DependencyInjection\ContainerInterface;

/**
 * Field handler to flag the node type.
 *
 * @ViewsField("election_seats_party")
 */
class ElectionSeatsParty extends FieldPluginBase {

  /**
   * Constructs a new plugin instance.
   */
  public function __construct(array $configuration, $plugin_id, $plugin_definition, protected RouteMatchInterface $routeMatch, protected EntityTypeManagerInterface $entityTypeManager) {
    parent::__construct($configuration, $plugin_id, $plugin_definition);
  }

  /**
   * {@inheritdoc}
   */
  public static function create(ContainerInterface $container, array $configuration, $plugin_id, $plugin_definition) {
    return new static(
      $configuration,
      $plugin_id,
      $plugin_definition,
      $container->get('current_route_match'),
      $container->get('entity_type.manager'),
    );
  }

  /**
   * Leave empty to avoid a query on this field.
   */
  public function query(): void {

  }

  /**
   * Per-request cache of election data, keyed by election NID.
   *
   * @var array<int, array{standing: array<int, bool>, seats: array<int, int>}>
   */
  protected static array $electionData = [];

  /**
   * Render function for the election_seats_party.
   *
   * Displays the number of seats won by the party in this row.
   *
   * @{inheritdoc}
   */
  public function render(ResultRow $values): ?int {
    $party = $values->_entity;
    $party_tid = $party->id();

    $node = $this->routeMatch->getParameter('node');
    if (!$node instanceof NodeInterface || $node->getType() !== 'localgov_election') {
      return NULL;
    }

    $data = $this->getElectionData($node);

    if (empty($data['standing'][$party_tid])) {
      return NULL;
    }
    return $data['seats'][$party_tid] ?? 0;
  }

  /**
   * Loads and caches per-party standing/seats data for an election.
   */
  protected function getElectionData(NodeInterface $election): array {
    $election_id = (int) $election->id();
    if (isset(static::$electionData[$election_id])) {
      return static::$electionData[$election_id];
    }

    $standing = [];
    $seats = [];

    $area_ids = $this->entityTypeManager->getStorage('node')->getQuery()
      ->condition('type', 'localgov_area_vote')
      ->condition('localgov_election', $election_id)
      ->accessCheck(FALSE)
      ->execute();

    $areas = $this->entityTypeManager->getStorage('node')->loadMultiple($area_ids);

    foreach ($areas as $area) {
      foreach ($area->get('localgov_election_candidates')->referencedEntities() as $candidate) {
        $cand_party = $candidate->get('localgov_election_party')->target_id;
        if ($cand_party) {
          $standing[$cand_party] = TRUE;
        }
      }

      if (!$area->get('localgov_election_winner')->isEmpty()) {
        foreach ($area->get('localgov_election_winner')->referencedEntities() as $winner) {
          $winning_party = $winner->get('localgov_election_party')->target_id ?? NULL;
          if ($winning_party) {
            $standing[$winning_party] = TRUE;
            $seats[$winning_party] = ($seats[$winning_party] ?? 0) + 1;
          }
        }
      }
    }

    static::$electionData[$election_id] = [
      'standing' => $standing,
      'seats' => $seats,
    ];

    return static::$electionData[$election_id];
  }

}
