<?php

namespace Drupal\localgov_elections\Plugin\views\field;

use Drupal\Core\Entity\EntityTypeManagerInterface;
use Drupal\views\Plugin\views\field\FieldPluginBase;
use Drupal\views\ResultRow;
use Symfony\Component\DependencyInjection\ContainerInterface;

/**
 * Field handler to flag the node type.
 *
 * @ViewsField("party_name")
 */
class PartyName extends FieldPluginBase {

  /**
   * Constructs a new plugin instance.
   */
  public function __construct(array $configuration, $plugin_id, $plugin_definition, protected EntityTypeManagerInterface $entityTypeManager) {
    parent::__construct($configuration, $plugin_id, $plugin_definition);
  }

  /**
   * {@inheritdoc}
   */
  public static function create(ContainerInterface $container, array $configuration, $plugin_id, $plugin_definition) {
    return new static(
      $configuration,
      $plugin_id,
      $plugin_definition,
      $container->get('entity_type.manager'),
    );
  }

  /**
   * Leave empty to avoid a query on this field.
   */
  public function query():void {

  }

  /**
   * Per-request cache of party names, keyed by election NID.
   *
   * @var array<int, array<int, string>>
   */
  protected static array $partyNameCache = [];

  /**
   * Render function for the party_name field.
   *
   * Displays a participating party in an electoral area (Ward).
   *
   * @{inheritdoc}
   */
  public function render(ResultRow $values): mixed {
    $election = $values->_entity;
    $election_id = (int) $election->id();

    $party_names = $this->getPartyNames($election_id);

    return $party_names ? reset($party_names) : NULL;
  }

  /**
   * Loads and caches party names for an election.
   */
  protected function getPartyNames(int $election_id): array {
    if (isset(static::$partyNameCache[$election_id])) {
      return static::$partyNameCache[$election_id];
    }

    $party_names = [];

    $area_ids = $this->entityTypeManager->getStorage('node')->getQuery()
      ->condition('type', 'localgov_area_vote')
      ->condition('localgov_election', $election_id)
      ->accessCheck(FALSE)
      ->execute();

    $areas = $this->entityTypeManager->getStorage('node')->loadMultiple($area_ids);

    $party_tids = [];
    foreach ($areas as $area) {
      foreach ($area->get('localgov_election_candidates')->referencedEntities() as $candidate) {
        $tid = $candidate->get('localgov_election_party')->target_id;
        if ($tid) {
          $party_tids[$tid] = $tid;
        }
      }
    }

    if ($party_tids) {
      $terms = $this->entityTypeManager->getStorage('taxonomy_term')->loadMultiple($party_tids);
      foreach ($terms as $tid => $term) {
        $party_names[$tid] = $term->label();
      }
    }

    static::$partyNameCache[$election_id] = $party_names;

    return static::$partyNameCache[$election_id];
  }

}
