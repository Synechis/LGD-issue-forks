<?php

namespace Drupal\localgov_elections\Plugin\views\field;

use Drupal\Core\Entity\EntityTypeManagerInterface;
use Drupal\Core\Routing\RouteMatchInterface;
use Drupal\node\NodeInterface;
use Drupal\views\Plugin\views\field\FieldPluginBase;
use Drupal\views\ResultRow;
use Symfony\Component\DependencyInjection\ContainerInterface;

/**
 * Field handler to flag the node type.
 *
 * @ViewsField("election_majority")
 */
class ElectionMajority extends FieldPluginBase {

  /**
   * Constructs a new plugin instance.
   */
  public function __construct(array $configuration, $plugin_id, $plugin_definition, protected RouteMatchInterface $routeMatch, protected EntityTypeManagerInterface $entityTypeManager) {
    parent::__construct($configuration, $plugin_id, $plugin_definition);
  }

  /**
   * {@inheritdoc}
   */
  public static function create(ContainerInterface $container, array $configuration, $plugin_id, $plugin_definition) {
    return new static(
      $configuration,
      $plugin_id,
      $plugin_definition,
      $container->get('current_route_match'),
      $container->get('entity_type.manager'),
    );
  }

  /**
   * Leave empty to avoid a query on this field.
   */
  public function query(): void {

  }

  /**
   * Per-request cache of majority value, keyed by election NID.
   *
   * @var array<int, float|null>
   */
  protected static array $majorityCache = [];

  /**
   * Render function for the election_majority field.
   *
   * Rounds down 50% of number of seats in election, adds 1 to
   * calculate majority required.
   *
   * @{inheritdoc}
   */
  public function render(ResultRow $values): ?float {
    $node = $this->routeMatch->getParameter('node');
    if (!$node instanceof NodeInterface || $node->getType() !== 'localgov_election') {
      return NULL;
    }

    $election_id = (int) $node->id();
    if (array_key_exists($election_id, static::$majorityCache)) {
      return static::$majorityCache[$election_id];
    }

    $area_ids = $this->entityTypeManager->getStorage('node')->getQuery()
      ->condition('type', 'localgov_area_vote')
      ->condition('localgov_election', $election_id)
      ->accessCheck(FALSE)
      ->execute();

    $areas = $this->entityTypeManager->getStorage('node')->loadMultiple($area_ids);
    $total_seats = 0;

    foreach ($areas as $area) {
      $total_seats += count($area->get('localgov_election_seats')->referencedEntities());
    }

    $majority = $total_seats > 0 ? floor($total_seats / 2) + 1 : NULL;
    static::$majorityCache[$election_id] = $majority;

    return $majority;
  }

}
