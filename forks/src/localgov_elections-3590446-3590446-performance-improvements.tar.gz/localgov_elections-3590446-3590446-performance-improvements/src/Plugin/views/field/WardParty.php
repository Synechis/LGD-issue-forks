<?php

namespace Drupal\localgov_elections\Plugin\views\field;

use Drupal\Core\Render\Markup;
use Drupal\taxonomy\Entity\Term;
use Drupal\views\Plugin\views\field\FieldPluginBase;
use Drupal\views\ResultRow;

/**
 * Field handler to flag the node type.
 *
 * @ViewsField("area_party")
 */
class WardParty extends FieldPluginBase {

  /**
   * Leave empty to avoid a query on this field.
   */
  public function query(): void {

  }

  /**
   * Render function for the area_party field.
   *
   * Displays the winning party in an electoral area (Ward).
   *
   * @{inheritdoc}
   */
  public function render(ResultRow $values): mixed {
    $node = $values->_entity;

    $party_name = NULL;
    $abbr = NULL;
    $results = [];
    $candidate_entities = $node->get('localgov_election_candidates')->referencedEntities();

    $party_tids = [];
    foreach ($candidate_entities as $candidate) {
      $tid = $candidate->get('localgov_election_party')->target_id;
      if ($tid) {
        $party_tids[$tid] = $tid;
      }
    }

    $parties = $party_tids ? Term::loadMultiple($party_tids) : [];

    foreach ($candidate_entities as $candidate) {
      $votes = $candidate->get('localgov_election_votes')->value;
      $tid = $candidate->get('localgov_election_party')->target_id;
      $party = $parties[$tid] ?? NULL;

      $results[] = [
        'abbr' => $party?->get('localgov_election_abbreviation')->value,
        'votes' => $votes,
        'name' => $party?->label(),
      ];
    }

    if ($results) {
      $votes = array_column($results, 'votes');
      $sorted = array_multisort($votes, SORT_DESC, $results);
      if ($sorted) {
        $party_name = $results[0]['name'];
        $abbr = $results[0]['abbr'];
        if ($abbr) {
          $abbr = strtolower($abbr);
        }
      }
    }

    return Markup::create("<div class='party " . $abbr . "'>" . $party_name . "</div>");
  }

}
