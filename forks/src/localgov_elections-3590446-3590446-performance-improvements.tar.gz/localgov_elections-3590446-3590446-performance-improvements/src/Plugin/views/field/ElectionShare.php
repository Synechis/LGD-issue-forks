<?php

namespace Drupal\localgov_elections\Plugin\views\field;

use Drupal\Core\Entity\EntityTypeManagerInterface;
use Drupal\node\NodeInterface;
use Drupal\views\Plugin\views\field\FieldPluginBase;
use Drupal\views\ResultRow;
use Symfony\Component\DependencyInjection\ContainerInterface;

/**
 * Field handler to calculate percentage share of votes cast for a party.
 *
 * @ViewsField("election_share")
 */
class ElectionShare extends FieldPluginBase {

  /**
   * Constructs a new plugin instance.
   */
  public function __construct(array $configuration, $plugin_id, $plugin_definition, protected EntityTypeManagerInterface $entityTypeManager) {
    parent::__construct($configuration, $plugin_id, $plugin_definition);
  }

  /**
   * {@inheritdoc}
   */
  public static function create(ContainerInterface $container, array $configuration, $plugin_id, $plugin_definition) {
    return new static(
      $configuration,
      $plugin_id,
      $plugin_definition,
      $container->get('entity_type.manager'),
    );
  }

  /**
   * Leave empty to avoid a query on this field.
   */
  public function query(): void {

  }

  /**
   * Per-request cache of vote share data, keyed by election NID.
   *
   * @var array<int, array{total_votes: int, party_votes: array<int, int>}>
   */
  protected static array $electionData = [];

  /**
   * Render function for the election_share field.
   *
   * Displays the percentage share of a political party.
   *
   * @{inheritdoc}
   */
  public function render(ResultRow $values): ?float {
    $entity = $values->_entity;
    $election = $entity->get('localgov_election')->target_id;
    $party = $values->_relationship_entities['localgov_election_party'];
    $party_id = $party?->id();

    $node = $this->entityTypeManager->getStorage('node')->load($election);
    if (!$node instanceof NodeInterface || $node->getType() !== 'localgov_election') {
      return NULL;
    }

    $data = $this->getElectionData((int) $election);

    if ($data['total_votes'] > 0 && $party_id) {
      $party_votes = $data['party_votes'][$party_id] ?? 0;
      return round(($party_votes / $data['total_votes'] * 100), 1);
    }

    return NULL;
  }

  /**
   * Loads and caches per-party vote totals for an election.
   */
  protected function getElectionData(int $election_id): array {
    if (isset(static::$electionData[$election_id])) {
      return static::$electionData[$election_id];
    }

    $total_votes = 0;
    $party_votes = [];

    $area_ids = $this->entityTypeManager->getStorage('node')->getQuery()
      ->condition('type', 'localgov_area_vote')
      ->condition('localgov_election', $election_id)
      ->accessCheck(FALSE)
      ->execute();

    $areas = $this->entityTypeManager->getStorage('node')->loadMultiple($area_ids);

    foreach ($areas as $area) {
      foreach ($area->get('localgov_election_candidates')->referencedEntities() as $candidate) {
        $votes = (int) $candidate->get('localgov_election_votes')->value;
        $cand_party = $candidate->get('localgov_election_party')->target_id;
        $total_votes += $votes;
        if ($cand_party) {
          $party_votes[$cand_party] = ($party_votes[$cand_party] ?? 0) + $votes;
        }
      }
    }

    static::$electionData[$election_id] = [
      'total_votes' => $total_votes,
      'party_votes' => $party_votes,
    ];

    return static::$electionData[$election_id];
  }

}
