<?php

namespace Drupal\localgov_replicate\Hook;

use Drupal\Core\Entity\EntityInterface;
use Drupal\localgov_roles\RolesHelper;
use Drupal\Core\Hook\Attribute\Hook;
use Drupal\Core\StringTranslation\StringTranslationTrait;

/**
 * Hook implementations for localgov_replicate.
 */
class LocalgovReplicateHooks {
  use StringTranslationTrait;

  /**
   * Implements hook_localgov_roles_default().
   */
  #[Hook('localgov_roles_default')]
  public function localgovRolesDefault(): array {
    $perms = [
      RolesHelper::EDITOR_ROLE => [
        'replicate entities',
      ],
    ];
    return $perms;
  }

  /**
   * Implements hook_menu_local_tasks_alter().
   */
  #[Hook('menu_local_tasks_alter')]
  public function menuLocalTasksAlter(&$data, $route_name): void {
    // Apply the 'Clone' title for any route that starts with the
    // "entity.node." prefix.
    if (strpos($route_name, 'entity.node.') === 0) {
      $data['tabs'][0]['replicate_ui.local_tasks:entity.node.replicate']['#link']['title'] = $this->t('Clone');
    }
  }

  /**
   * Implements hook_entity_operation_alter().
   *
   * Change the operations dropbutton label from "Replicate" to "Clone"
   * so the operations dropbutton matches the local task tab label.
   */
  #[Hook('entity_operation_alter')]
  public function entityOperationAlter(array &$operations, EntityInterface $entity): void {
    if (isset($operations['replicate'])) {
      $operations['replicate']['title'] = $this->t('Clone');
    }
  }

}
