<?php

declare(strict_types=1);

namespace Drupal\localgov_bus_data_homepage\Form;

use Drupal\Core\Extension\ModuleHandlerInterface;
use Drupal\Core\Form\ConfigFormBase;
use Drupal\Core\Form\FormStateInterface;
use Drupal\Core\Url;
use Drupal\localgov_bus_data_homepage\Service\BusPathUpdater;
use Symfony\Component\DependencyInjection\ContainerInterface;

/**
 * Settings form for the Bus Timetables homepage submodule.
 *
 * Allows site builders to configure the intro text, interchange/station links,
 * and area browse groups without touching PHP code — making the submodule
 * reusable across different councils.
 */
final class HomepageSettingsForm extends ConfigFormBase {

  /**
   * The bus path updater service.
   *
   * Must be protected (not private/readonly) for DependencySerializationTrait.
   */
  protected BusPathUpdater $pathUpdater;

  /**
   * The module handler.
   */
  protected ModuleHandlerInterface $moduleHandler;

  /**
   * {@inheritdoc}
   *
   * Post-construction property injection is used here because ConfigFormBase
   * owns the constructor and injects its own dependencies via parent::create().
   * Overriding __construct() would require re-declaring and passing all parent
   * dependencies manually. The protected visibility is required so that
   * DependencySerializationTrait::__sleep() can detect the property via
   * get_object_vars() when called from the parent class scope.
   */
  public static function create(ContainerInterface $container): static {
    $instance = parent::create($container);
    $instance->pathUpdater = $container->get('localgov_bus_data_homepage.path_updater');
    $instance->moduleHandler = $container->get('module_handler');
    return $instance;
  }

  /**
   * {@inheritdoc}
   */
  protected function getEditableConfigNames(): array {
    return ['localgov_bus_data_homepage.settings'];
  }

  /**
   * {@inheritdoc}
   */
  public function getFormId(): string {
    return 'localgov_bus_data_homepage_settings';
  }

  /**
   * {@inheritdoc}
   */
  public function buildForm(array $form, FormStateInterface $form_state): array {
    $config = $this->config('localgov_bus_data_homepage.settings');

    if (!$this->config('localgov_bus_data.settings')->get('naptan.enabled')) {
      $this->messenger()->addWarning($this->t(
        '<strong>NaPTAN enrichment is not enabled.</strong> The interchange links and area browse sections on the homepage rely on locality data that is only available after NaPTAN enrichment runs. Enable NaPTAN in the <a href=":url">bus data settings</a> for these sections to work.',
        [':url' => Url::fromRoute('localgov_bus_data.settings')->toString()],
      ));
    }

    $form['page_title'] = [
      '#type'          => 'textfield',
      '#title'         => $this->t('Page title'),
      '#description'   => $this->t('Title shown in the browser tab and page heading for the bus timetables landing page.'),
      '#default_value' => $config->get('page_title') ?? 'Bus Timetables',
      '#required'      => TRUE,
    ];

    $form['page_path'] = [
      '#type'          => 'textfield',
      '#title'         => $this->t('Bus section base path'),
      '#description'   => $this->t('URL path for the bus timetables section. Changing this updates all bus View paths automatically. Default: <code>buses</code>.'),
      '#default_value' => $config->get('page_path') ?? 'buses',
      '#required'      => TRUE,
    ];

    if ($this->moduleHandler->moduleExists('localgov_core')) {
      $form['use_lgd_page_header'] = [
        '#type'          => 'checkbox',
        '#title'         => $this->t('Use LocalGov page header block pattern'),
        '#description'   => $this->t('When enabled, the LocalGov page header block pattern will display the page title and intro text together.'),
        '#default_value' => (bool) ($config->get('use_lgd_page_header') ?? FALSE),
      ];
    }

    $form['intro_text'] = [
      '#type'          => 'textarea',
      '#title'         => $this->t('Intro text'),
      '#description'   => $this->t('Introductory paragraph shown at the top of the bus timetables landing page. Example: <em>Find bus timetables and stops across your area. You can search by service number, find a stop near you, or browse by area.</em>'),
      '#default_value' => $config->get('intro_text') ?? '',
      '#rows'          => 4,
    ];

    $form['section_text'] = [
      '#type'  => 'details',
      '#title' => $this->t('Section titles and descriptions'),
      '#open'  => TRUE,
    ];

    $defaults = [
      'route_search_title'       => 'Search by route number',
      'route_search_description' => 'Enter a bus route number to see its timetable.',
      'stop_search_title'        => 'Find a bus stop',
      'stop_search_description'  => 'Enter a stop name or part of a street name to find nearby stops.',
      'operator_search_title'       => 'Search by operator',
      'operator_search_description' => 'Enter a bus company name to see all of its routes.',
      'interchanges_title'       => 'Bus interchanges and stations',
      'interchanges_description' => 'Direct links to major bus stations and interchange points.',
      'area_browse_title'        => 'Search by area',
      'area_browse_description'  => 'Select an area to see the places you can search for bus stops in.',
    ];

    $sections = [
      'route_search'    => $this->t('Route search'),
      'stop_search'     => $this->t('Stop search'),
      'operator_search' => $this->t('Operator search'),
      'interchanges' => $this->t('Interchanges'),
      'area_browse'  => $this->t('Area browse'),
    ];

    foreach ($sections as $key => $label) {
      $form['section_text'][$key . '_title'] = [
        '#type'          => 'textfield',
        '#title'         => $this->t('@section title', ['@section' => $label]),
        '#default_value' => $config->get($key . '_title') ?? $defaults[$key . '_title'],
        '#required'      => TRUE,
      ];
      $form['section_text'][$key . '_description'] = [
        '#type'          => 'textfield',
        '#title'         => $this->t('@section description', ['@section' => $label]),
        '#default_value' => $config->get($key . '_description') ?? $defaults[$key . '_description'],
      ];
    }

    $form['interchanges'] = [
      '#type'          => 'textarea',
      '#title'         => $this->t('Interchanges and bus stations'),
      '#description'   => $this->t('
        <ul>
          <li>One entry per line.</li>
          <li>Format: <code>Display label|locality|stop name</code></li>
          <li>The stop name is optional — omit it (and the second pipe) to link to all stops in that locality.</li>
          <li>Example: <code>Carlisle Bus Station|Carlisle|Bus Station</code></li>
        </ul>
        <details>
        <summary>Example (Cumberland)</summary>
            Carlisle Bus Station|Carlisle|Bus Station<br>
            Workington Bus Station|Workington|Bus Station<br>
            Penrith Bus Station|Penrith|Bus Station<br>
            Keswick Bus Station|Keswick|Bus Station<br>
            Kendal Bus Station|Kendal|Bus Station<br>
            Whitehaven Town Centre|Whitehaven<br>
            Maryport Town Centre|Maryport
        </details>
        '),
      '#default_value' => $this->interchangesToText($config->get('interchanges') ?? []),
      '#rows'          => 10,
    ];

    $form['area_browse_dropdown'] = [
      '#type'          => 'checkbox',
      '#title'         => $this->t('Use dropdown for area browse'),
      '#description'   => $this->t('When enabled, replaces the two-column tab widget with a simple select dropdown that submits directly to the stop search.'),
      '#default_value' => (bool) ($config->get('area_browse_dropdown') ?? FALSE),
    ];

    $form['areas'] = [
      '#type'          => 'textarea',
      '#title'         => $this->t('Area browse groups'),
      '#description'   => $this->t('
        <ul>
          <li>One entry per line.</li>
          <li>Format: <code>Area display name|ATCO prefix</code></li>
          <li>The ATCO prefix is the first 6 characters of stop IDs in that area (e.g. <code>090033</code> for Carlisle).</li>
          <li>Example: <code>Carlisle|090033</code></li>
        </ul>
        <details>
          <summary>Example (Cumberland)</summary>
          Allerdale|090002<br>
          Carlisle|090033<br>
          Copeland|090050<br>
          Eden|090074<br>
          South Lakeland|090079<br>
          Barrow-in-Furness|090010<br>
        </details>
        '),
      '#default_value' => $this->areasToText($config->get('areas') ?? []),
      '#rows'          => 10,
    ];

    return parent::buildForm($form, $form_state);
  }

  /**
   * {@inheritdoc}
   */
  public function validateForm(array &$form, FormStateInterface $form_state): void {
    parent::validateForm($form, $form_state);

    $path = trim((string) $form_state->getValue('page_path'));
    if (!preg_match('#^[a-z0-9]([a-z0-9_\-]*(/[a-z0-9][a-z0-9_\-]*)*)?$#', $path)) {
      $form_state->setErrorByName('page_path', $this->t(
        'The base path must start with a letter or digit and contain only lowercase letters, digits, hyphens, underscores, and forward slashes.',
      ));
    }

    foreach ($this->splitLines((string) $form_state->getValue('interchanges')) as $i => $line) {
      $parts = explode('|', $line);
      if (count($parts) < 2 || trim($parts[0]) === '' || trim($parts[1]) === '') {
        $form_state->setErrorByName('interchanges', $this->t(
          'Line @n of Interchanges is invalid. Each line must have at least a label and a locality separated by a pipe: <code>Label|locality</code>.',
          ['@n' => $i + 1],
        ));
      }
    }

    foreach ($this->splitLines((string) $form_state->getValue('areas')) as $i => $line) {
      $parts = explode('|', $line);
      if (count($parts) !== 2 || trim($parts[0]) === '' || trim($parts[1]) === '') {
        $form_state->setErrorByName('areas', $this->t(
          'Line @n of Areas is invalid. Each line must be <code>Area name|ATCO prefix</code>.',
          ['@n' => $i + 1],
        ));
      }
    }
  }

  /**
   * {@inheritdoc}
   */
  public function submitForm(array &$form, FormStateInterface $form_state): void {
    $config  = $this->config('localgov_bus_data_homepage.settings');
    $oldPath = $config->get('page_path') ?? 'buses';
    $newPath = trim((string) $form_state->getValue('page_path'));

    $config
      ->set('page_title', trim((string) $form_state->getValue('page_title')))
      ->set('page_path', $newPath)
      ->set('intro_text', trim((string) $form_state->getValue('intro_text')))
      ->set('use_lgd_page_header', (bool) $form_state->getValue('use_lgd_page_header'))
      ->set('route_search_title', trim((string) $form_state->getValue('route_search_title')))
      ->set('route_search_description', trim((string) $form_state->getValue('route_search_description')))
      ->set('stop_search_title', trim((string) $form_state->getValue('stop_search_title')))
      ->set('stop_search_description', trim((string) $form_state->getValue('stop_search_description')))
      ->set('operator_search_title', trim((string) $form_state->getValue('operator_search_title')))
      ->set('operator_search_description', trim((string) $form_state->getValue('operator_search_description')))
      ->set('interchanges_title', trim((string) $form_state->getValue('interchanges_title')))
      ->set('interchanges_description', trim((string) $form_state->getValue('interchanges_description')))
      ->set('area_browse_title', trim((string) $form_state->getValue('area_browse_title')))
      ->set('area_browse_description', trim((string) $form_state->getValue('area_browse_description')))
      ->set('area_browse_dropdown', (bool) $form_state->getValue('area_browse_dropdown'))
      ->set('interchanges', $this->textToInterchanges((string) $form_state->getValue('interchanges')))
      ->set('areas', $this->textToAreas((string) $form_state->getValue('areas')))
      ->save();

    if ($oldPath !== $newPath) {
      $this->pathUpdater->update($oldPath, $newPath);
    }

    parent::submitForm($form, $form_state);
  }

  /**
   * Converts the stored interchanges array to the textarea text format.
   *
   * @param array<int, array<string, string>> $interchanges
   *   Stored interchange entries from config.
   *
   * @return string
   *   Pipe-delimited textarea text, one entry per line.
   */
  private function interchangesToText(array $interchanges): string {
    $lines = [];
    foreach ($interchanges as $entry) {
      $line = ($entry['label'] ?? '') . '|' . ($entry['bustimes_locality'] ?? '');
      if (!empty($entry['bustimes_stop_name'])) {
        $line .= '|' . $entry['bustimes_stop_name'];
      }
      $lines[] = $line;
    }
    return implode("\n", $lines);
  }

  /**
   * Parses the textarea text format into the interchanges config array.
   *
   * @param string $text
   *   Pipe-delimited textarea value, one entry per line.
   *
   * @return array<int, array<string, string>>
   *   Interchange entries suitable for storing in config.
   */
  private function textToInterchanges(string $text): array {
    $result = [];
    foreach ($this->splitLines($text) as $line) {
      $parts = explode('|', $line, 3);
      $entry = [
        'label'              => trim($parts[0]),
        'bustimes_locality'  => trim($parts[1]),
        'bustimes_stop_name' => isset($parts[2]) ? trim($parts[2]) : '',
      ];
      $result[] = $entry;
    }
    return $result;
  }

  /**
   * Converts the stored areas array to the textarea text format.
   *
   * @param array<int, array<string, string>> $areas
   *   Stored area entries from config.
   *
   * @return string
   *   Pipe-delimited textarea text, one entry per line.
   */
  private function areasToText(array $areas): string {
    $lines = [];
    foreach ($areas as $entry) {
      $lines[] = ($entry['label'] ?? '') . '|' . ($entry['atco_prefix'] ?? '');
    }
    return implode("\n", $lines);
  }

  /**
   * Parses the textarea text format into the areas config array.
   *
   * @param string $text
   *   Pipe-delimited textarea value, one entry per line.
   *
   * @return array<int, array<string, string>>
   *   Area entries suitable for storing in config.
   */
  private function textToAreas(string $text): array {
    $result = [];
    foreach ($this->splitLines($text) as $line) {
      $parts    = explode('|', $line, 2);
      $result[] = [
        'label'       => trim($parts[0]),
        'atco_prefix' => trim($parts[1]),
      ];
    }
    return $result;
  }

  /**
   * Splits a textarea value into non-empty trimmed lines.
   *
   * @param string $text
   *   Raw textarea value with possible Windows or Unix line endings.
   *
   * @return string[]
   *   Array of non-empty trimmed line strings.
   */
  private function splitLines(string $text): array {
    return array_values(array_filter(
      array_map('trim', explode("\n", str_replace("\r\n", "\n", $text))),
    ));
  }

}
