/**
 * @file
 * Area browse two-column tab widget for the /buses landing page.
 *
 * Progressively enhances the bus-area-browse widget. Without JS the first
 * panel is visible (hidden attribute absent) and all others are hidden;
 * clicking area buttons has no effect but the first area is still browseable.
 * With JS, all buttons activate their respective panel.
 */
(function localgovBusAreaBrowseScript(Drupal, once) {
  Drupal.behaviors.localgovBusAreaBrowse = {
    attach(context) {
      once('bus-area-browse', '[data-bus-area-browse]', context).forEach(
        (widget) => {
          const buttons = widget.querySelectorAll('[role="tab"]');
          const panels = widget.querySelectorAll('[role="tabpanel"]');

          function activateTab(button) {
            const targetId = button.getAttribute('aria-controls');

            // Deactivate all tabs.
            buttons.forEach((item) => {
              item.setAttribute('aria-selected', 'false');
              item.classList.remove('is-active');
            });

            // Hide all panels.
            panels.forEach((panel) => {
              panel.setAttribute('hidden', '');
              panel.classList.add('is-hidden');
            });

            // Activate clicked tab and its panel.
            button.setAttribute('aria-selected', 'true');
            button.classList.add('is-active');

            const panel = widget.querySelector(`#${targetId}`);
            if (panel) {
              panel.removeAttribute('hidden');
              panel.classList.remove('is-hidden');
            }
          }

          function handleTabClick(event) {
            activateTab(event.currentTarget);
          }

          buttons.forEach((button) => {
            button.addEventListener('click', handleTabClick);
          });
        },
      );
    },
  };
})(Drupal, once);

(function localgovBusAreaBrowseDropdownScript(Drupal, once) {
  Drupal.behaviors.localgovBusAreaBrowseDropdown = {
    attach(context) {
      once(
        'bus-area-browse-dropdown',
        '[data-bus-area-browse-dropdown]',
        context,
      ).forEach((widget) => {
        const select = widget.querySelector('[data-bus-area-select]');
        const panels = widget.querySelectorAll('.bus-area-browse__panel');

        if (!select) return;

        function handleSelectChange() {
          panels.forEach((panel) => {
            panel.setAttribute('hidden', '');
            panel.classList.add('is-hidden');
          });

          if (select.value) {
            const panel = widget.querySelector(`#${CSS.escape(select.value)}`);
            if (panel) {
              panel.removeAttribute('hidden');
              panel.classList.remove('is-hidden');
            }
          }
        }

        select.addEventListener('change', handleSelectChange);
      });
    },
  };
})(Drupal, once);
