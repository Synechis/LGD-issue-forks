<?php

/**
 * @file
 * Post update functions for the LocalGov Bus Data module.
 */

declare(strict_types=1);

use Drupal\Core\StringTranslation\TranslatableMarkup;

/**
 * Backfills bustimes_slug on routes imported before the field existed.
 *
 * The field storage is installed by update_10010, which also calls this same
 * backfill immediately, so that slugs exist before update_10011 moves the
 * timetable view onto the three-segment path. This hook is kept as an
 * idempotent safety net: it runs once all schema updates have completed,
 * which is the safe point to load and re-save every route entity if the
 * entity definitions were not fully settled when update_10010 ran.
 *
 * Deliberately a single pass rather than a $sandbox batch: slug uniqueness is
 * resolved across the whole route set at once (the -2, -3 suffixes are
 * assigned in bustimes_route_id order within each agency and route number
 * group), so a chunked run would have to reload each chunk's siblings anyway.
 * Route counts are in the thousands for a county-sized feed, which one pass
 * handles comfortably.
 *
 * Idempotent: GtfsImportService::populateRouteSlugs() only writes where
 * bustimes_slug is currently empty, so a second run is a no-op and, in
 * particular, will not renumber the -2, -3 suffixes on published URLs.
 *
 * @return \Drupal\Core\StringTranslation\TranslatableMarkup
 *   The number of routes given a slug.
 */
function localgov_bus_data_post_update_populate_route_slugs(): TranslatableMarkup {
  $populated = \Drupal::service('localgov_bus_data.gtfs_import')->populateRouteSlugs();

  return new TranslatableMarkup(
    'Populated bustimes_slug on @count routes.',
    ['@count' => $populated],
  );
}
