<?php

declare(strict_types=1);

namespace Drupal\Tests\localgov_bus_data\Unit\Plugin\views\style;

use PHPUnit\Framework\Attributes\Group;
use Drupal\localgov_bus_data\Plugin\views\style\BusTimetableStyle;
use Drupal\Tests\UnitTestCase;

/**
 * Unit tests for the timetable pivot built by BusTimetableStyle.
 *
 * The pivot is exercised through buildPivot(), which takes the plain call
 * records that render() extracts from the view result. That keeps these tests
 * free of the entity and views plumbing while covering the row keying, row
 * ordering, column ordering, and duplicate-trip logic that render() relies on.
 *
 * @coversDefaultClass \Drupal\localgov_bus_data\Plugin\views\style\BusTimetableStyle
 * @group localgov_bus_data
 */
#[Group('localgov_bus_data')]
final class BusTimetableStyleTest extends UnitTestCase {

  /**
   * The style plugin under test.
   */
  private BusTimetableStyle $style;

  /**
   * {@inheritdoc}
   */
  protected function setUp(): void {
    parent::setUp();
    $this->style = new BusTimetableStyle([], 'localgov_bus_timetable', []);
  }

  /**
   * Builds a call record in the shape render() passes to buildPivot().
   *
   * @param string $trip_id
   *   Trip entity ID.
   * @param string $stop_id
   *   Stop entity ID, or '' when the stop reference is missing.
   * @param string $stop_name
   *   Display name for the stop.
   * @param int $sequence
   *   The GTFS stop sequence within this trip.
   * @param string $time
   *   Departure time as "HH:MM".
   *
   * @return array
   *   One call record.
   */
  private function call(
    string $trip_id,
    string $stop_id,
    string $stop_name,
    int $sequence,
    string $time,
  ): array {
    return [
      'trip_id'   => $trip_id,
      'stop_id'   => $stop_id,
      'stop_name' => $stop_name,
      'sequence'  => $sequence,
      'time'      => $time,
    ];
  }

  /**
   * Reduces the pivot rows to a "Stop Name" => times map for readable asserts.
   *
   * @param array $stops
   *   The 'stops' element of a buildPivot() result.
   *
   * @return array
   *   Ordered list of [name, times] pairs.
   */
  private function summarise(array $stops): array {
    return array_map(
      static fn(array $stop): array => [$stop['name'], $stop['times']],
      $stops,
    );
  }

  /**
   * A single trip pivots to one row per call in stop-sequence order.
   *
   * @covers ::buildPivot
   */
  public function testSingleTripPivotsInSequenceOrder(): void {
    // Deliberately unordered input: the view result order must not matter.
    $calls = [
      $this->call('1', '30', 'Keswick', 3, '10:00'),
      $this->call('1', '10', 'Workington', 1, '09:00'),
      $this->call('1', '20', 'Cockermouth', 2, '09:30'),
    ];

    $pivot = $this->style->buildPivot($calls);

    $this->assertSame(['1'], $pivot['trips']);
    $this->assertSame([
      ['Workington', ['1' => '09:00']],
      ['Cockermouth', ['1' => '09:30']],
      ['Keswick', ['1' => '10:00']],
    ], $this->summarise($pivot['stops']));
  }

  /**
   * Two trips with different stop patterns keep their times on their own stops.
   *
   * Both trips number their calls from sequence 1, so a sequence-keyed pivot
   * prints the variant's times against the full journey's stop names. Keying
   * by stop puts every time against the stop the trip actually serves, and
   * the extra stop the variant calls at is inserted in the right place.
   *
   * @covers ::buildPivot
   */
  public function testVariantPatternKeepsTimesAgainstItsOwnStops(): void {
    $calls = [
      // Full journey: Workington to Penrith.
      $this->call('1', '10', 'Workington', 1, '09:00'),
      $this->call('1', '20', 'Cockermouth', 2, '09:30'),
      $this->call('1', '30', 'Keswick', 3, '10:00'),
      $this->call('1', '40', 'Penrith', 4, '10:45'),
      // Variant: calls at Maryport, terminates at Keswick.
      $this->call('2', '10', 'Workington', 1, '11:00'),
      $this->call('2', '50', 'Maryport', 2, '11:20'),
      $this->call('2', '20', 'Cockermouth', 3, '11:40'),
      $this->call('2', '30', 'Keswick', 4, '12:10'),
    ];

    $pivot = $this->style->buildPivot($calls);

    $this->assertSame(['1', '2'], $pivot['trips']);
    $this->assertSame([
      ['Workington', ['1' => '09:00', '2' => '11:00']],
      ['Maryport', ['2' => '11:20']],
      ['Cockermouth', ['1' => '09:30', '2' => '11:40']],
      ['Keswick', ['1' => '10:00', '2' => '12:10']],
      ['Penrith', ['1' => '10:45']],
    ], $this->summarise($pivot['stops']));
  }

  /**
   * A short working is ordered by the first stop it shares with the full run.
   *
   * The short working leaves its own first stop (Keswick, 09:50) later than
   * the full journey left Workington (09:00), but it is ahead of the full
   * journey at every stop the two have in common, so it belongs in the left
   * column.
   *
   * @covers ::buildPivot
   */
  public function testShortWorkingIsOrderedByFirstSharedStop(): void {
    $calls = [
      // Full journey, listed first so a stable sort cannot supply the answer.
      $this->call('1', '10', 'Workington', 1, '09:00'),
      $this->call('1', '20', 'Cockermouth', 2, '09:30'),
      $this->call('1', '30', 'Keswick', 3, '10:00'),
      $this->call('1', '40', 'Penrith', 4, '10:45'),
      // Short working starting partway along at Keswick.
      $this->call('2', '30', 'Keswick', 1, '09:50'),
      $this->call('2', '40', 'Penrith', 2, '10:35'),
    ];

    $pivot = $this->style->buildPivot($calls);

    $this->assertSame(['2', '1'], $pivot['trips']);
    $this->assertSame([
      ['Workington', ['1' => '09:00']],
      ['Cockermouth', ['1' => '09:30']],
      ['Keswick', ['2' => '09:50', '1' => '10:00']],
      ['Penrith', ['2' => '10:35', '1' => '10:45']],
    ], $this->summarise($pivot['stops']));
  }

  /**
   * Trips with no stop in common fall back to their own first departure.
   *
   * @covers ::buildPivot
   */
  public function testDisjointTripsOrderByFirstDeparture(): void {
    $calls = [
      $this->call('1', '10', 'Workington', 1, '14:00'),
      $this->call('1', '20', 'Cockermouth', 2, '14:30'),
      $this->call('2', '60', 'Carlisle', 1, '08:00'),
      $this->call('2', '70', 'Brampton', 2, '08:30'),
    ];

    $pivot = $this->style->buildPivot($calls);

    $this->assertSame(['2', '1'], $pivot['trips']);
  }

  /**
   * A circular route calling twice at one stop gets a row for each call.
   *
   * @covers ::buildPivot
   */
  public function testCircularRouteGetsOneRowPerCall(): void {
    $calls = [
      $this->call('1', '10', 'Depot', 1, '08:00'),
      $this->call('1', '20', 'Town Centre', 2, '08:10'),
      $this->call('1', '30', 'Village', 3, '08:25'),
      $this->call('1', '20', 'Town Centre', 4, '08:40'),
      $this->call('1', '10', 'Depot', 5, '08:55'),
    ];

    $pivot = $this->style->buildPivot($calls);

    $this->assertSame([
      ['Depot', ['1' => '08:00']],
      ['Town Centre', ['1' => '08:10']],
      ['Village', ['1' => '08:25']],
      ['Town Centre', ['1' => '08:40']],
      ['Depot', ['1' => '08:55']],
    ], $this->summarise($pivot['stops']));
  }

  /**
   * A second circular trip merges onto the same repeated rows, not new ones.
   *
   * @covers ::buildPivot
   */
  public function testSecondCircularTripReusesTheRepeatedRows(): void {
    $calls = [
      $this->call('1', '10', 'Depot', 1, '08:00'),
      $this->call('1', '20', 'Town Centre', 2, '08:10'),
      $this->call('1', '20', 'Town Centre', 3, '08:40'),
      $this->call('2', '10', 'Depot', 1, '09:00'),
      $this->call('2', '20', 'Town Centre', 2, '09:10'),
      $this->call('2', '20', 'Town Centre', 3, '09:40'),
    ];

    $pivot = $this->style->buildPivot($calls);

    $this->assertSame(['1', '2'], $pivot['trips']);
    $this->assertSame([
      ['Depot', ['1' => '08:00', '2' => '09:00']],
      ['Town Centre', ['1' => '08:10', '2' => '09:10']],
      ['Town Centre', ['1' => '08:40', '2' => '09:40']],
    ], $this->summarise($pivot['stops']));
  }

  /**
   * Pins the known limitation in partial working versus circular route keying.
   *
   * A partial working that joins a circular route after the repeated stop has
   * already been called once still keys its call as occurrence 0, so its time
   * lands on the first occurrence's row rather than the second. This asserts
   * the current behaviour so a change to it is deliberate; it is not a
   * statement that this placement is correct.
   *
   * See the known limitation paragraph in the BusTimetableStyle class
   * docblock.
   *
   * @covers ::buildPivot
   */
  public function testKnownLimitationPartialWorkingLandsOnFirstCircularRow(): void {
    $calls = [
      // Circular trip: Depot, Town Centre, back to Depot.
      $this->call('1', '10', 'Depot', 1, '08:00'),
      $this->call('1', '20', 'Town Centre', 2, '08:10'),
      $this->call('1', '10', 'Depot', 3, '08:20'),
      // Partial working joining at Town Centre and running to Depot.
      $this->call('2', '20', 'Town Centre', 1, '09:10'),
      $this->call('2', '10', 'Depot', 2, '09:20'),
    ];

    $pivot = $this->style->buildPivot($calls);

    $this->assertSame(['1', '2'], $pivot['trips']);
    // The partial's 09:20 Depot call sits on the first Depot row, above its
    // own 09:10 Town Centre call, so that column reads out of order.
    $this->assertSame([
      ['Depot', ['1' => '08:00', '2' => '09:20']],
      ['Town Centre', ['1' => '08:10', '2' => '09:10']],
      ['Depot', ['1' => '08:20']],
    ], $this->summarise($pivot['stops']));
  }

  /**
   * Two genuinely identical trips collapse to a single column.
   *
   * @covers ::buildPivot
   */
  public function testIdenticalTripsAreDeduplicated(): void {
    $calls = [
      $this->call('1', '10', 'Workington', 1, '09:00'),
      $this->call('1', '20', 'Cockermouth', 2, '09:30'),
      $this->call('2', '10', 'Workington', 1, '09:00'),
      $this->call('2', '20', 'Cockermouth', 2, '09:30'),
    ];

    $pivot = $this->style->buildPivot($calls);

    $this->assertSame(['1'], $pivot['trips']);
    $this->assertSame([
      ['Workington', ['1' => '09:00']],
      ['Cockermouth', ['1' => '09:30']],
    ], $this->summarise($pivot['stops']));
  }

  /**
   * Trips sharing times but not stops are not treated as duplicates.
   *
   * A fingerprint built from sequence-keyed rows reduces both trips to
   * "09:00|09:30" and drops the second. Building it from (stop, time) pairs
   * keeps them apart.
   *
   * @covers ::buildPivot
   */
  public function testSameTimesAtDifferentStopsAreNotDeduplicated(): void {
    $calls = [
      $this->call('1', '10', 'Workington', 1, '09:00'),
      $this->call('1', '20', 'Cockermouth', 2, '09:30'),
      $this->call('2', '60', 'Carlisle', 1, '09:00'),
      $this->call('2', '70', 'Brampton', 2, '09:30'),
    ];

    $pivot = $this->style->buildPivot($calls);

    $this->assertCount(2, $pivot['trips']);
  }

  /**
   * Trips over the same stops at different times are not deduplicated.
   *
   * @covers ::buildPivot
   */
  public function testSameStopsAtDifferentTimesAreNotDeduplicated(): void {
    $calls = [
      $this->call('1', '10', 'Workington', 1, '09:00'),
      $this->call('1', '20', 'Cockermouth', 2, '09:30'),
      $this->call('2', '10', 'Workington', 1, '10:00'),
      $this->call('2', '20', 'Cockermouth', 2, '10:30'),
    ];

    $pivot = $this->style->buildPivot($calls);

    $this->assertSame(['1', '2'], $pivot['trips']);
    $this->assertSame([
      ['Workington', ['1' => '09:00', '2' => '10:00']],
      ['Cockermouth', ['1' => '09:30', '2' => '10:30']],
    ], $this->summarise($pivot['stops']));
  }

  /**
   * Times past midnight sort after evening times rather than wrapping.
   *
   * @covers ::buildPivot
   */
  public function testTimesPastMidnightSortLast(): void {
    $calls = [
      $this->call('1', '10', 'Workington', 1, '25:10'),
      $this->call('1', '20', 'Cockermouth', 2, '25:40'),
      $this->call('2', '10', 'Workington', 1, '23:10'),
      $this->call('2', '20', 'Cockermouth', 2, '23:40'),
    ];

    $pivot = $this->style->buildPivot($calls);

    $this->assertSame(['2', '1'], $pivot['trips']);
  }

  /**
   * Calls with no stop reference still produce a row keyed by their sequence.
   *
   * @covers ::buildPivot
   */
  public function testCallWithoutStopReferenceStillGetsRow(): void {
    $calls = [
      $this->call('1', '10', 'Workington', 1, '09:00'),
      $this->call('1', '', '', 2, '09:15'),
      $this->call('1', '20', 'Cockermouth', 3, '09:30'),
    ];

    $pivot = $this->style->buildPivot($calls);

    $this->assertSame([
      ['Workington', ['1' => '09:00']],
      ['', ['1' => '09:15']],
      ['Cockermouth', ['1' => '09:30']],
    ], $this->summarise($pivot['stops']));
  }

  /**
   * Unresolvable stop references in two trips do not share a row.
   *
   * A sequence number is only unique within one trip, so a fallback row key
   * built from the sequence alone would merge these two unrelated trips onto
   * one row and print both times against it.
   *
   * @covers ::buildPivot
   */
  public function testUnresolvedStopsInDifferentTripsStayApart(): void {
    $calls = [
      $this->call('1', '10', 'Workington', 1, '09:00'),
      $this->call('1', '', '', 2, '09:15'),
      $this->call('1', '20', 'Cockermouth', 3, '09:30'),
      $this->call('2', '60', 'Carlisle', 1, '14:00'),
      $this->call('2', '', '', 2, '14:15'),
      $this->call('2', '70', 'Brampton', 3, '14:30'),
    ];

    $pivot = $this->style->buildPivot($calls);

    $this->assertCount(6, $pivot['stops']);

    $unnamed = array_values(array_map(
      static fn(array $stop): array => $stop['times'],
      array_filter(
        $pivot['stops'],
        static fn(array $stop): bool => $stop['name'] === '',
      ),
    ));

    $this->assertCount(2, $unnamed);
    $this->assertContains(['1' => '09:15'], $unnamed);
    $this->assertContains(['2' => '14:15'], $unnamed);
  }

  /**
   * Trips that disagree on the order of shared stops do not duplicate rows.
   *
   * There is no correct merged order for two stops visited in opposite
   * orders, so the row order established first is kept rather than a second
   * row being created for a stop that already has one.
   *
   * @covers ::buildPivot
   */
  public function testConflictingStopOrderDoesNotDuplicateRows(): void {
    $calls = [
      $this->call('1', '10', 'Workington', 1, '09:00'),
      $this->call('1', '20', 'Cockermouth', 2, '09:30'),
      $this->call('2', '20', 'Cockermouth', 1, '10:00'),
      $this->call('2', '10', 'Workington', 2, '10:30'),
    ];

    $pivot = $this->style->buildPivot($calls);

    $this->assertSame(['1', '2'], $pivot['trips']);
    $this->assertSame([
      ['Workington', ['1' => '09:00', '2' => '10:30']],
      ['Cockermouth', ['1' => '09:30', '2' => '10:00']],
    ], $this->summarise($pivot['stops']));
  }

  /**
   * Three patterns merge into one row order, each inserting its own stops.
   *
   * @covers ::buildPivot
   */
  public function testThreePatternsMergeIntoOneRowOrder(): void {
    $calls = [
      // Full journey.
      $this->call('1', '10', 'Workington', 1, '09:00'),
      $this->call('1', '20', 'Cockermouth', 2, '09:30'),
      $this->call('1', '30', 'Keswick', 3, '10:00'),
      $this->call('1', '40', 'Penrith', 4, '10:45'),
      // Adds Threlkeld between Cockermouth and Keswick.
      $this->call('2', '10', 'Workington', 1, '11:00'),
      $this->call('2', '20', 'Cockermouth', 2, '11:30'),
      $this->call('2', '50', 'Threlkeld', 3, '11:45'),
      $this->call('2', '30', 'Keswick', 4, '12:00'),
      $this->call('2', '40', 'Penrith', 5, '12:45'),
      // Adds Maryport between Workington and Cockermouth, terminates there.
      $this->call('3', '10', 'Workington', 1, '13:00'),
      $this->call('3', '60', 'Maryport', 2, '13:20'),
      $this->call('3', '20', 'Cockermouth', 3, '13:40'),
    ];

    $pivot = $this->style->buildPivot($calls);

    $this->assertSame(['1', '2', '3'], $pivot['trips']);
    $this->assertSame([
      ['Workington', ['1' => '09:00', '2' => '11:00', '3' => '13:00']],
      ['Maryport', ['3' => '13:20']],
      ['Cockermouth', ['1' => '09:30', '2' => '11:30', '3' => '13:40']],
      ['Threlkeld', ['2' => '11:45']],
      ['Keswick', ['1' => '10:00', '2' => '12:00']],
      ['Penrith', ['1' => '10:45', '2' => '12:45']],
    ], $this->summarise($pivot['stops']));
  }

  /**
   * An empty call list produces no rows and no columns.
   *
   * @covers ::buildPivot
   */
  public function testEmptyCallListProducesNothing(): void {
    $pivot = $this->style->buildPivot([]);

    $this->assertSame([], $pivot['stops']);
    $this->assertSame([], $pivot['trips']);
  }

}
