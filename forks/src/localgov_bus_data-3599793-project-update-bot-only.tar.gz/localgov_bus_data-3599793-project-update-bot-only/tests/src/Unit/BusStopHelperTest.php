<?php

declare(strict_types=1);

namespace Drupal\Tests\localgov_bus_data\Unit\Utility;

use PHPUnit\Framework\Attributes\Group;
use Drupal\Core\Entity\FieldableEntityInterface;
use Drupal\Core\Field\FieldItemListInterface;
use Drupal\localgov_bus_data\Utility\BusStopHelper;
use Drupal\Tests\UnitTestCase;

/**
 * Unit tests for BusStopHelper::getEnrichedName().
 *
 * @coversDefaultClass \Drupal\localgov_bus_data\Utility\BusStopHelper
 * @group localgov_bus_data
 */
#[Group('localgov_bus_data')]
final class BusStopHelperTest extends UnitTestCase {

  /**
   * Builds a mock bus stop entity with the given field values.
   *
   * @param string $name
   *   Value for bustimes_stop_name.
   * @param string $indicator
   *   Value for bustimes_indicator.
   * @param string $street
   *   Value for bustimes_street.
   * @param string $locality
   *   Value for bustimes_locality.
   *
   * @return \Drupal\Core\Entity\FieldableEntityInterface
   *   Mock entity.
   */
  private function makeStop(
    string $name,
    string $indicator = '',
    string $street = '',
    string $locality = '',
  ): FieldableEntityInterface {
    $values = [
      'bustimes_stop_name' => $name,
      'bustimes_indicator' => $indicator,
      'bustimes_street'    => $street,
      'bustimes_locality'  => $locality,
    ];

    $stop = $this->createMock(FieldableEntityInterface::class);

    $stop->method('hasField')->willReturnCallback(
      static fn(string $field): bool => isset($values[$field]),
    );

    $stop->method('get')->willReturnCallback(
      function (string $field) use ($values): FieldItemListInterface {
        $list = $this->createMock(FieldItemListInterface::class);
        $list->method('getString')->willReturn($values[$field] ?? '');
        return $list;
      },
    );

    $stop->method('label')->willReturn($name);

    return $stop;
  }

  /**
   * All parts present produces the canonical enriched string.
   *
   * @covers ::getEnrichedName
   */
  public function testAllPartsEnriched(): void {
    $stop = $this->makeStop('Bus Station', 'Stand A', 'Station Road', 'Workington');
    $this->assertSame(
      'Bus Station (Stand A) Station Road, Workington',
      BusStopHelper::getEnrichedName($stop),
    );
  }

  /**
   * When indicator, street, and locality are all empty, returns the plain name.
   *
   * @covers ::getEnrichedName
   */
  public function testFallbackWhenAllEmpty(): void {
    $stop = $this->makeStop('Bus Station', '', '', '');
    $this->assertSame(
      'Bus Station',
      BusStopHelper::getEnrichedName($stop),
    );
  }

  /**
   * Indicator only — no street or locality.
   *
   * @covers ::getEnrichedName
   */
  public function testIndicatorOnly(): void {
    $stop = $this->makeStop('High Street', 'opp', '', '');
    $this->assertSame('High Street (opp)', BusStopHelper::getEnrichedName($stop));
  }

  /**
   * Street only — no indicator or locality.
   *
   * @covers ::getEnrichedName
   */
  public function testStreetOnly(): void {
    $stop = $this->makeStop('High Street', '', 'Market Road', '');
    $this->assertSame('High Street Market Road', BusStopHelper::getEnrichedName($stop));
  }

  /**
   * Locality only — no indicator or street.
   *
   * @covers ::getEnrichedName
   */
  public function testLocalityOnly(): void {
    $stop = $this->makeStop('High Street', '', '', 'Carlisle');
    $this->assertSame('High Street, Carlisle', BusStopHelper::getEnrichedName($stop));
  }

  /**
   * Indicator and locality without street.
   *
   * @covers ::getEnrichedName
   */
  public function testIndicatorAndLocality(): void {
    $stop = $this->makeStop('Bus Station', 'Stand A', '', 'Workington');
    $this->assertSame(
      'Bus Station (Stand A), Workington',
      BusStopHelper::getEnrichedName($stop),
    );
  }

  /**
   * Whitespace-only enrichment fields are treated as absent (trim behaviour).
   *
   * @covers ::getEnrichedName
   */
  public function testWhitespaceOnlyFieldsTreatedAsEmpty(): void {
    $stop = $this->makeStop('Bus Station', '   ', '  ', ' ');
    $this->assertSame('Bus Station', BusStopHelper::getEnrichedName($stop));
  }

  /**
   * Timetable and stop search produce the same string for the same stop.
   *
   * Both call sites use BusStopHelper::getEnrichedName(), so a single call
   * verifies that the shared helper produces a consistent result regardless
   * of which rendering path invoked it.
   *
   * @covers ::getEnrichedName
   */
  public function testTimetableAndStopSearchProduceSameString(): void {
    $stop = $this->makeStop('Lowther Street', 'adj', 'Lowther Street', 'Whitehaven');
    $expected = 'Lowther Street (adj) Lowther Street, Whitehaven';

    $this->assertSame($expected, BusStopHelper::getEnrichedName($stop));
    // Calling again simulates both render paths using the same helper.
    $this->assertSame($expected, BusStopHelper::getEnrichedName($stop));
  }

}
