<?php

declare(strict_types=1);

namespace Drupal\Tests\localgov_bus_data\Unit\Controller;

use PHPUnit\Framework\Attributes\Group;
use Drupal\Core\Database\Connection;
use Drupal\Core\Database\Query\SelectInterface;
use Drupal\Core\Database\StatementInterface;
use Drupal\Core\Entity\EntityTypeInterface;
use Drupal\Core\Entity\EntityTypeManagerInterface;
use Drupal\localgov_bus_data\Controller\OperatorAutocompleteController;
use Drupal\Tests\UnitTestCase;
use Symfony\Component\HttpFoundation\Request;

/**
 * Unit tests for the operator autocomplete controller.
 *
 * The DISTINCT query is verified manually against the site; these tests cover
 * the minimum-length guard (no query is run for short fragments) and the
 * mapping of returned names to autocomplete suggestion objects.
 *
 * @coversDefaultClass \Drupal\localgov_bus_data\Controller\OperatorAutocompleteController
 * @group localgov_bus_data
 */
#[Group('localgov_bus_data')]
final class OperatorAutocompleteControllerTest extends UnitTestCase {

  /**
   * A fragment shorter than the minimum returns no matches and hits no DB.
   *
   * @covers ::autocomplete
   */
  public function testShortFragmentReturnsEmptyWithoutQuerying(): void {
    $database = $this->createMock(Connection::class);
    // The guard must short-circuit before any query is built.
    $database->expects($this->never())->method('select');

    $controller = new OperatorAutocompleteController(
      $database,
      $this->createMock(EntityTypeManagerInterface::class),
    );

    $response = $controller->autocomplete(new Request(['q' => 'a']));

    $this->assertSame('[]', $response->getContent());
  }

  /**
   * Distinct operator names are mapped to value/label suggestion objects.
   *
   * @covers ::autocomplete
   */
  public function testMatchesMappedToSuggestions(): void {
    $statement = $this->createMock(StatementInterface::class);
    $statement->method('fetchCol')->willReturn(['Border Buses', 'Stagecoach']);

    $select = $this->createMock(SelectInterface::class);
    $select->method('fields')->willReturnSelf();
    $select->method('condition')->willReturnSelf();
    $select->method('distinct')->willReturnSelf();
    $select->method('orderBy')->willReturnSelf();
    $select->method('range')->willReturnSelf();
    $select->method('execute')->willReturn($statement);

    $database = $this->createMock(Connection::class);
    $database->method('escapeLike')->willReturnArgument(0);
    $database->method('select')->willReturn($select);

    $entity_type = $this->createMock(EntityTypeInterface::class);
    $entity_type->method('getBaseTable')->willReturn('localgov_bus_route');
    $entity_type_manager = $this->createMock(EntityTypeManagerInterface::class);
    $entity_type_manager->method('getDefinition')
      ->with('localgov_bus_route')
      ->willReturn($entity_type);

    $controller = new OperatorAutocompleteController($database, $entity_type_manager);

    $response = $controller->autocomplete(new Request(['q' => 'Bus']));

    $this->assertSame(
      [
        ['value' => 'Border Buses', 'label' => 'Border Buses'],
        ['value' => 'Stagecoach', 'label' => 'Stagecoach'],
      ],
      json_decode((string) $response->getContent(), TRUE),
    );
  }

  /**
   * A long-enough fragment with no matches returns an empty JSON array.
   *
   * @covers ::autocomplete
   */
  public function testNoMatchesReturnsEmptyArray(): void {
    $statement = $this->createMock(StatementInterface::class);
    $statement->method('fetchCol')->willReturn([]);

    $select = $this->createMock(SelectInterface::class);
    $select->method('fields')->willReturnSelf();
    $select->method('condition')->willReturnSelf();
    $select->method('distinct')->willReturnSelf();
    $select->method('orderBy')->willReturnSelf();
    $select->method('range')->willReturnSelf();
    $select->method('execute')->willReturn($statement);

    $database = $this->createMock(Connection::class);
    $database->method('escapeLike')->willReturnArgument(0);
    $database->method('select')->willReturn($select);

    $entity_type = $this->createMock(EntityTypeInterface::class);
    $entity_type->method('getBaseTable')->willReturn('localgov_bus_route');
    $entity_type_manager = $this->createMock(EntityTypeManagerInterface::class);
    $entity_type_manager->method('getDefinition')->willReturn($entity_type);

    $controller = new OperatorAutocompleteController($database, $entity_type_manager);

    $response = $controller->autocomplete(new Request(['q' => 'zzz']));

    $this->assertSame('[]', $response->getContent());
  }

}
