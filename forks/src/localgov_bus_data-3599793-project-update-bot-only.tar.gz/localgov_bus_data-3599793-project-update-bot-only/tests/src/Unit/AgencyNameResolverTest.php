<?php

declare(strict_types=1);

namespace Drupal\Tests\localgov_bus_data\Unit\Service;

use PHPUnit\Framework\Attributes\Group;
use Drupal\Core\File\FileSystemInterface;
use Drupal\localgov_bus_data\Service\AgencyNameResolver;
use Drupal\Tests\UnitTestCase;

/**
 * Unit tests for AgencyNameResolver.
 *
 * Uses real temporary CSV files so the fgetcsv parsing logic is exercised
 * without any filesystem mocking; the Drupal stream wrapper is replaced by a
 * mocked FileSystemInterface where the resolved path is needed.
 *
 * @coversDefaultClass \Drupal\localgov_bus_data\Service\AgencyNameResolver
 * @group localgov_bus_data
 */
#[Group('localgov_bus_data')]
final class AgencyNameResolverTest extends UnitTestCase {

  /**
   * Temporary directory for agency.txt fixtures.
   *
   * @var string
   */
  private string $tmpDir;

  /**
   * {@inheritdoc}
   */
  protected function setUp(): void {
    parent::setUp();
    $this->tmpDir = sys_get_temp_dir() . '/agency_name_resolver_test_' . bin2hex(random_bytes(8));
    mkdir($this->tmpDir, 0750, TRUE);
  }

  /**
   * {@inheritdoc}
   */
  protected function tearDown(): void {
    foreach (glob($this->tmpDir . '/*') ?: [] as $file) {
      if (is_file($file)) {
        unlink($file);
      }
    }
    rmdir($this->tmpDir);
    parent::tearDown();
  }

  /**
   * Builds a resolver with a mocked file system (path not exercised here).
   */
  private function makeResolver(): AgencyNameResolver {
    return new AgencyNameResolver($this->createMock(FileSystemInterface::class));
  }

  /**
   * Writes an agency fixture file and returns its absolute path.
   */
  private function writeFixture(string $contents): string {
    $path = $this->tmpDir . '/agency.txt';
    file_put_contents($path, $contents);
    return $path;
  }

  /**
   * A well-formed file parses into an agency_id => agency_name map.
   *
   * @covers ::parseAgencyFile
   */
  public function testWellFormedFile(): void {
    $path = $this->writeFixture(
      "agency_id,agency_name,agency_url\n" .
      "OP539,Stagecoach North East,https://example.com\n" .
      "ARBA,Arriva,https://example.com\n",
    );

    $this->assertSame(
      [
        'OP539' => 'Stagecoach North East',
        'ARBA'  => 'Arriva',
      ],
      $this->makeResolver()->parseAgencyFile($path),
    );
  }

  /**
   * Column order is taken from the header, not assumed positionally.
   *
   * @covers ::parseAgencyFile
   */
  public function testRespectsHeaderColumnOrder(): void {
    $path = $this->writeFixture(
      "agency_url,agency_name,agency_id\n" .
      "https://example.com,Go North East,GNE\n",
    );

    $this->assertSame(
      ['GNE' => 'Go North East'],
      $this->makeResolver()->parseAgencyFile($path),
    );
  }

  /**
   * A missing file returns an empty map.
   *
   * @covers ::parseAgencyFile
   */
  public function testMissingFileReturnsEmpty(): void {
    $this->assertSame(
      [],
      $this->makeResolver()->parseAgencyFile($this->tmpDir . '/does-not-exist.txt'),
    );
  }

  /**
   * A file missing the required columns returns an empty map.
   *
   * @covers ::parseAgencyFile
   */
  public function testMissingColumnsReturnsEmpty(): void {
    $path = $this->writeFixture(
      "agency_id,agency_url\n" .
      "OP539,https://example.com\n",
    );

    $this->assertSame([], $this->makeResolver()->parseAgencyFile($path));
  }

  /**
   * Rows with an empty agency_name are skipped.
   *
   * @covers ::parseAgencyFile
   */
  public function testEmptyNameRowSkipped(): void {
    $path = $this->writeFixture(
      "agency_id,agency_name\n" .
      "OP539,Stagecoach\n" .
      "BLANK,\n" .
      "ARBA,Arriva\n",
    );

    $this->assertSame(
      [
        'OP539' => 'Stagecoach',
        'ARBA'  => 'Arriva',
      ],
      $this->makeResolver()->parseAgencyFile($path),
    );
  }

  /**
   * GetAgencyNames() resolves the stream wrapper path then parses the file.
   *
   * @covers ::getAgencyNames
   */
  public function testGetAgencyNamesResolvesPath(): void {
    $path = $this->writeFixture(
      "agency_id,agency_name\n" .
      "OP539,Stagecoach\n",
    );

    $fileSystem = $this->createMock(FileSystemInterface::class);
    $fileSystem->method('realpath')
      ->with('public://bus-times/gtfs/agency.txt')
      ->willReturn($path);

    $resolver = new AgencyNameResolver($fileSystem);

    $this->assertSame(['OP539' => 'Stagecoach'], $resolver->getAgencyNames());
  }

  /**
   * GetAgencyNames() returns an empty map when the path cannot be resolved.
   *
   * @covers ::getAgencyNames
   */
  public function testGetAgencyNamesUnresolvablePath(): void {
    $fileSystem = $this->createMock(FileSystemInterface::class);
    $fileSystem->method('realpath')->willReturn(FALSE);

    $resolver = new AgencyNameResolver($fileSystem);

    $this->assertSame([], $resolver->getAgencyNames());
  }

  /**
   * An unknown id is not present in the map (callers fall back to the id).
   *
   * @covers ::parseAgencyFile
   */
  public function testUnknownIdAbsentFromMap(): void {
    $path = $this->writeFixture(
      "agency_id,agency_name\n" .
      "OP539,Stagecoach\n",
    );

    $names = $this->makeResolver()->parseAgencyFile($path);
    $this->assertArrayNotHasKey('UNKNOWN', $names);
    // Mirror the caller's fallback: unknown id resolves to itself.
    $this->assertSame('UNKNOWN', $names['UNKNOWN'] ?? 'UNKNOWN');
  }

}
