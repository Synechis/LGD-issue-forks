<?php

declare(strict_types=1);

namespace Drupal\Tests\localgov_bus_data\Unit\Service;

use PHPUnit\Framework\Attributes\Group;
use Drupal\Core\Database\Connection;
use Drupal\localgov_bus_data\Service\RoutePolylineService;
use Drupal\Tests\UnitTestCase;

/**
 * Unit tests for the pure segment-building logic of RoutePolylineService.
 *
 * The direction/day/service-period SQL filtering is verified manually; these
 * tests cover only the DB-free segment union, deduplication, and coordinate
 * filtering.
 *
 * @coversDefaultClass \Drupal\localgov_bus_data\Service\RoutePolylineService
 * @group localgov_bus_data
 */
#[Group('localgov_bus_data')]
final class RoutePolylineServiceTest extends UnitTestCase {

  /**
   * The service under test.
   */
  private RoutePolylineService $service;

  /**
   * {@inheritdoc}
   */
  protected function setUp(): void {
    parent::setUp();
    // The database connection is never touched by the pure methods.
    $this->service = new RoutePolylineService($this->createMock(Connection::class));
  }

  /**
   * Builds a coordinate row as returned by the query.
   *
   * @param mixed $lat
   *   Latitude value.
   * @param mixed $lon
   *   Longitude value.
   *
   * @return array{lat: mixed, lon: mixed}
   *   The coordinate row.
   */
  private function point(mixed $lat, mixed $lon): array {
    return ['lat' => $lat, 'lon' => $lon];
  }

  /**
   * Reduces segments to comparable "lat,lon-lat,lon" strings.
   *
   * @param array $segments
   *   Segments returned by buildSegments().
   *
   * @return list<string>
   *   One string per segment.
   */
  private function flatten(array $segments): array {
    return array_map(
      static fn(array $s): string => sprintf(
        '%s,%s-%s,%s',
        $s[0]['lat'], $s[0]['lon'], $s[1]['lat'], $s[1]['lon'],
      ),
      $segments,
    );
  }

  /**
   * Consecutive stops within a trip are joined into consecutive segments.
   *
   * @covers ::buildSegments
   * @covers ::cleanPoints
   */
  public function testConsecutiveStopsJoinedWithinTrip(): void {
    $trips = [
      1 => [
        $this->point(54.0, -3.0),
        $this->point(54.1, -3.1),
        $this->point(54.2, -3.2),
      ],
    ];

    $this->assertSame(
      ['54,-3-54.1,-3.1', '54.1,-3.1-54.2,-3.2'],
      $this->flatten($this->service->buildSegments($trips)),
    );
  }

  /**
   * A shared trunk across trips produces each segment only once.
   *
   * @covers ::buildSegments
   */
  public function testSharedTrunkDedupedAcrossTrips(): void {
    // Two trips share the A->B->C trunk, then branch.
    $trips = [
      1 => [
        $this->point(54.0, -3.0),
        $this->point(54.1, -3.1),
        $this->point(54.2, -3.2),
        $this->point(54.3, -3.3),
      ],
      2 => [
        $this->point(54.0, -3.0),
        $this->point(54.1, -3.1),
        $this->point(54.2, -3.2),
        $this->point(54.9, -3.9),
      ],
    ];

    $this->assertSame(
      [
        '54,-3-54.1,-3.1',
        '54.1,-3.1-54.2,-3.2',
        '54.2,-3.2-54.3,-3.3',
        '54.2,-3.2-54.9,-3.9',
      ],
      $this->flatten($this->service->buildSegments($trips)),
    );
  }

  /**
   * Multiple patterns combine to cover every filtered stop.
   *
   * @covers ::buildSegments
   */
  public function testMultiplePatternsCoverAllStops(): void {
    // One trip serves an extra intermediate stop the other skips. The union
    // must include the segments unique to each pattern.
    $trips = [
      1 => [
        $this->point(54.0, -3.0),
        $this->point(54.2, -3.2),
      ],
      2 => [
        $this->point(54.0, -3.0),
        $this->point(54.1, -3.1),
        $this->point(54.2, -3.2),
      ],
    ];

    $segments = $this->flatten($this->service->buildSegments($trips));
    $this->assertContains('54,-3-54.2,-3.2', $segments);
    $this->assertContains('54,-3-54.1,-3.1', $segments);
    $this->assertContains('54.1,-3.1-54.2,-3.2', $segments);
    $this->assertCount(3, $segments);
  }

  /**
   * Undirected dedup: a reversed segment is treated as the same edge.
   *
   * @covers ::buildSegments
   */
  public function testReversedSegmentDeduped(): void {
    $trips = [
      1 => [
        $this->point(54.0, -3.0),
        $this->point(54.1, -3.1),
      ],
      2 => [
        $this->point(54.1, -3.1),
        $this->point(54.0, -3.0),
      ],
    ];

    $this->assertCount(1, $this->service->buildSegments($trips));
  }

  /**
   * Null, empty, and 0,0 coordinates are skipped.
   *
   * @covers ::buildSegments
   * @covers ::cleanPoints
   */
  public function testInvalidCoordinatesSkipped(): void {
    $trips = [
      1 => [
        $this->point(54.0, -3.0),
        $this->point(NULL, NULL),
        $this->point(0, 0),
        $this->point('', ''),
        $this->point(54.2, -3.2),
      ],
    ];

    // The invalid points drop out, leaving a single segment between the two
    // valid stops.
    $this->assertSame(
      ['54,-3-54.2,-3.2'],
      $this->flatten($this->service->buildSegments($trips)),
    );
  }

  /**
   * Consecutive duplicate points are collapsed (no zero-length segment).
   *
   * @covers ::buildSegments
   * @covers ::cleanPoints
   */
  public function testConsecutiveDuplicatesCollapsed(): void {
    $trips = [
      1 => [
        $this->point(54.0, -3.0),
        $this->point(54.0, -3.0),
        $this->point(54.1, -3.1),
      ],
    ];

    $this->assertSame(
      ['54,-3-54.1,-3.1'],
      $this->flatten($this->service->buildSegments($trips)),
    );
  }

  /**
   * A single-stop trip yields no segments.
   *
   * @covers ::buildSegments
   */
  public function testSingleStopTripYieldsNothing(): void {
    $trips = [
      1 => [$this->point(54.0, -3.0)],
    ];

    $this->assertSame([], $this->service->buildSegments($trips));
  }

  /**
   * A trip whose only valid point survives cleaning yields no segments.
   *
   * @covers ::buildSegments
   * @covers ::cleanPoints
   */
  public function testTripWithOneValidPointYieldsNothing(): void {
    $trips = [
      1 => [
        $this->point(0, 0),
        $this->point(54.0, -3.0),
        $this->point(NULL, NULL),
      ],
    ];

    $this->assertSame([], $this->service->buildSegments($trips));
  }

  /**
   * Empty input yields no segments.
   *
   * @covers ::buildSegments
   */
  public function testEmptyInput(): void {
    $this->assertSame([], $this->service->buildSegments([]));
  }

  /**
   * Reduces polylines to comparable "lat,lon-lat,lon-…" strings.
   *
   * @param array $polylines
   *   Polylines returned by buildPolylines() or buildShapePolylines().
   *
   * @return list<string>
   *   One string per polyline.
   */
  private function flattenPolylines(array $polylines): array {
    return array_map(
      static fn(array $line): string => implode('-', array_map(
        static fn(array $p): string => sprintf('%s,%s', $p['lat'], $p['lon']),
        $line,
      )),
      $polylines,
    );
  }

  /**
   * A usable shape is preferred and drawn as a single road-following polyline.
   *
   * @covers ::buildPolylines
   * @covers ::buildShapePolylines
   */
  public function testShapePolylinePreferredOverSegments(): void {
    // The shape bends through a midpoint well off the straight A->C line (the
    // stop segments would only draw that direct line), so simplification must
    // not remove it. Preferring the shape must yield the three-point polyline
    // and ignore the stop segment.
    $shapePoints = [
      'A' => [
        $this->point(54.0, -3.0),
        $this->point(54.08, -3.02),
        $this->point(54.1, -3.1),
      ],
    ];
    $tripStops = [
      1 => [
        $this->point(54.0, -3.0),
        $this->point(54.1, -3.1),
      ],
    ];

    $this->assertSame(
      ['54,-3-54.08,-3.02-54.1,-3.1'],
      $this->flattenPolylines($this->service->buildPolylines($shapePoints, $tripStops)),
    );
  }

  /**
   * Fallback: with no shape present, straight segments are used.
   *
   * @covers ::buildPolylines
   * @covers ::buildShapePolylines
   */
  public function testFallbackToSegmentsWhenShapeAbsent(): void {
    $tripStops = [
      1 => [
        $this->point(54.0, -3.0),
        $this->point(54.1, -3.1),
        $this->point(54.2, -3.2),
      ],
    ];

    // No shapes at all: each straight segment becomes a two-point polyline,
    // matching the segment union exactly.
    $this->assertSame(
      ['54,-3-54.1,-3.1', '54.1,-3.1-54.2,-3.2'],
      $this->flattenPolylines($this->service->buildPolylines([], $tripStops)),
    );
  }

  /**
   * Fallback: a shape that cleans to fewer than two points does not win.
   *
   * @covers ::buildPolylines
   * @covers ::buildShapePolylines
   */
  public function testDegenerateShapeFallsBackToSegments(): void {
    // The only "shape" collapses to a single distinct point, so it cannot form
    // a polyline; the builder must fall back to the stop segments.
    $shapePoints = [
      'A' => [
        $this->point(54.0, -3.0),
        $this->point(54.0, -3.0),
        $this->point(0, 0),
      ],
    ];
    $tripStops = [
      1 => [
        $this->point(54.0, -3.0),
        $this->point(54.1, -3.1),
      ],
    ];

    $this->assertSame(
      ['54,-3-54.1,-3.1'],
      $this->flattenPolylines($this->service->buildPolylines($shapePoints, $tripStops)),
    );
  }

  /**
   * Each usable shape produces its own polyline.
   *
   * @covers ::buildShapePolylines
   */
  public function testMultipleShapesProduceMultiplePolylines(): void {
    $shapePoints = [
      'A' => [
        $this->point(54.0, -3.0),
        $this->point(54.1, -3.1),
      ],
      'B' => [
        $this->point(55.0, -2.0),
        $this->point(55.1, -2.1),
      ],
    ];

    $this->assertSame(
      ['54,-3-54.1,-3.1', '55,-2-55.1,-2.1'],
      $this->flattenPolylines($this->service->buildShapePolylines($shapePoints)),
    );
  }

  /**
   * Shape points are cleaned: invalid points drop, duplicates collapse.
   *
   * @covers ::buildShapePolylines
   * @covers ::cleanPoints
   */
  public function testShapePointsCleaned(): void {
    $shapePoints = [
      'A' => [
        $this->point(54.0, -3.0),
        $this->point(54.0, -3.0),
        $this->point(NULL, NULL),
        $this->point(0, 0),
        $this->point(54.2, -3.2),
      ],
    ];

    $this->assertSame(
      ['54,-3-54.2,-3.2'],
      $this->flattenPolylines($this->service->buildShapePolylines($shapePoints)),
    );
  }

  /**
   * No shapes and no trips yields no polylines.
   *
   * @covers ::buildPolylines
   */
  public function testNoShapesNoTripsYieldsNothing(): void {
    $this->assertSame([], $this->service->buildPolylines([], []));
  }

  /**
   * A point exactly on the straight line between its neighbours is dropped.
   *
   * @covers ::simplifyPolyline
   */
  public function testSimplifyDropsRedundantCollinearPoint(): void {
    // (54.05, -3.05) is the exact midpoint of the line from A to C: it adds
    // nothing visually and must be removed.
    $points = [
      $this->point(54.0, -3.0),
      $this->point(54.05, -3.05),
      $this->point(54.1, -3.1),
    ];

    $this->assertSame(
      ['54,-3-54.1,-3.1'],
      $this->flattenPolylines([$this->service->simplifyPolyline($points, 12.0)]),
    );
  }

  /**
   * A point that genuinely bends away from the line is kept.
   *
   * @covers ::simplifyPolyline
   */
  public function testSimplifyKeepsGenuineBend(): void {
    // (54.08, -3.02) deviates from the A-C line by roughly 3.4km, far beyond
    // any sane tolerance, so it must survive simplification.
    $points = [
      $this->point(54.0, -3.0),
      $this->point(54.08, -3.02),
      $this->point(54.1, -3.1),
    ];

    $this->assertSame(
      ['54,-3-54.08,-3.02-54.1,-3.1'],
      $this->flattenPolylines([$this->service->simplifyPolyline($points, 12.0)]),
    );
  }

  /**
   * Many collinear points collapse to just the two endpoints.
   *
   * Models a dense GTFS shape trace along an essentially straight road: no
   * matter how many recorded points lie on the line, only the endpoints carry
   * any information.
   *
   * @covers ::simplifyPolyline
   */
  public function testSimplifyReducesManyCollinearPointsToEndpoints(): void {
    $points = [];
    for ($i = 0; $i < 20; $i++) {
      $t = $i / 19;
      $points[] = $this->point(54.0 + 0.1 * $t, -3.0 - 0.1 * $t);
    }

    $this->assertSame(
      ['54,-3-54.1,-3.1'],
      $this->flattenPolylines([$this->service->simplifyPolyline($points, 12.0)]),
    );
  }

  /**
   * Fewer than three points are returned unchanged (nothing to simplify).
   *
   * @covers ::simplifyPolyline
   */
  public function testSimplifyPassesThroughFewerThanThreePoints(): void {
    $points = [
      $this->point(54.0, -3.0),
      $this->point(54.1, -3.1),
    ];

    $this->assertSame($points, $this->service->simplifyPolyline($points, 12.0));
  }

}
