<?php

declare(strict_types=1);

namespace Drupal\Tests\localgov_bus_data\Unit;

use PHPUnit\Framework\Attributes\Group;
use Drupal\Component\Serialization\Yaml;
use Drupal\localgov_bus_data\Utility\BusMessages;
use Drupal\Tests\UnitTestCase;

/**
 * Guards the wiring of the configurable bank holiday notice.
 *
 * The notice is rendered by an area handler that reads its wording from
 * localgov_bus_data.settings. Re-exporting a view from the Views UI is the
 * likely way to lose that wiring, which would silently drop the notice, so
 * the shipped config is asserted here rather than left to review.
 *
 * @group localgov_bus_data
 */
#[Group('localgov_bus_data')]
final class BankHolidayNoticeConfigTest extends UnitTestCase {

  private const PLUGIN_ID = 'localgov_bus_data_bank_holiday_notice';

  private const CACHE_TAG = 'config:localgov_bus_data.settings';

  private const VIEW_IDS = [
    'localgov_bus_routes',
    'localgov_bus_stop_detail',
    'localgov_bus_stop_search',
    'localgov_bus_timetable',
  ];

  /**
   * Decodes a file from the module's config/install directory.
   *
   * @param string $file
   *   File name, for example views.view.localgov_bus_timetable.yml.
   *
   * @return array
   *   The decoded config.
   */
  private function loadConfig(string $file): array {
    $contents = file_get_contents(dirname(__DIR__, 3) . '/config/install/' . $file);
    $this->assertIsString($contents, sprintf('%s is readable.', $file));

    return Yaml::decode($contents);
  }

  /**
   * The shipped settings carry both editable messages.
   *
   * The same wording is held in code as a fallback for sites whose saved
   * settings predate the messages key, so the two must not drift apart.
   */
  public function testDefaultMessagesMatchTheCodeFallback(): void {
    $settings = $this->loadConfig('localgov_bus_data.settings.yml');

    $this->assertArrayHasKey('messages', $settings);
    foreach (BusMessages::DEFAULTS as $key => $default) {
      $this->assertNotSame('', trim($default), sprintf('%s has wording.', $key));
      $this->assertArrayHasKey($key, $settings['messages']);
      $this->assertSame(
        $default,
        $settings['messages'][$key],
        sprintf('Shipped %s matches BusMessages::DEFAULTS.', $key),
      );
    }
  }

  /**
   * Every affected view renders the notice through the area handler.
   */
  public function testViewsUseTheNoticeAreaHandler(): void {
    foreach (self::VIEW_IDS as $view_id) {
      $view = $this->loadConfig('views.view.' . $view_id . '.yml');
      $footer = $view['display']['default']['display_options']['footer'] ?? [];

      $this->assertArrayHasKey(
        self::PLUGIN_ID,
        $footer,
        sprintf('View %s footer uses the notice area handler.', $view_id),
      );
      $this->assertSame(
        self::PLUGIN_ID,
        $footer[self::PLUGIN_ID]['plugin_id'] ?? NULL,
        sprintf('View %s footer handler has the expected plugin_id.', $view_id),
      );
      $this->assertArrayNotHasKey(
        'area_text_custom',
        $footer,
        sprintf('View %s no longer hardcodes the notice text.', $view_id),
      );
    }
  }

  /**
   * Displays that render the notice carry the settings cache tag.
   *
   * Views stores calculated cache metadata in the view itself, so without this
   * tag an edit on the settings form would leave stale pages cached.
   */
  public function testDisplaysRenderingTheNoticeCarryTheCacheTag(): void {
    foreach (self::VIEW_IDS as $view_id) {
      $view = $this->loadConfig('views.view.' . $view_id . '.yml');

      foreach ($view['display'] as $display_id => $display) {
        $overrides_footer = ($display['display_options']['defaults']['footer'] ?? NULL) === FALSE;
        $tags = $display['cache_metadata']['tags'] ?? [];
        $message = sprintf('%s display %s cache tags.', $view_id, $display_id);

        if ($display_id !== 'default' && $overrides_footer) {
          $this->assertNotContains(self::CACHE_TAG, $tags, $message);
          continue;
        }
        $this->assertContains(self::CACHE_TAG, $tags, $message);
      }
    }
  }

}
