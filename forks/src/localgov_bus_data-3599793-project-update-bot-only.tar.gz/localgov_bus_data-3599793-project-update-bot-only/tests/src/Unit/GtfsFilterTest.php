<?php

declare(strict_types=1);

namespace Drupal\Tests\localgov_bus_data\Unit\Service;

use PHPUnit\Framework\Attributes\Group;
use Drupal\localgov_bus_data\Service\GtfsFilter;
use Drupal\Core\Config\ConfigFactoryInterface;
use Drupal\Core\Config\ImmutableConfig;
use Drupal\Tests\UnitTestCase;
use Psr\Log\LoggerInterface;

/**
 * Unit tests for GtfsFilter.
 *
 * Uses real temporary CSV files so that file I/O logic (fgetcsv, fputcsv,
 * rename) is exercised without any filesystem mocking.
 *
 * @coversDefaultClass \Drupal\localgov_bus_data\Service\GtfsFilter
 * @group localgov_bus_data
 */
#[Group('localgov_bus_data')]
final class GtfsFilterTest extends UnitTestCase {

  /**
   * Temporary directory for GTFS CSV fixtures.
   *
   * @var string
   */
  private string $tmpDir;

  /**
   * {@inheritdoc}
   */
  protected function setUp(): void {
    parent::setUp();
    $this->tmpDir = sys_get_temp_dir() . '/gtfs_filter_test_' . uniqid();
    mkdir($this->tmpDir, 0750, TRUE);
  }

  /**
   * {@inheritdoc}
   */
  protected function tearDown(): void {
    foreach (glob($this->tmpDir . '/*') ?: [] as $file) {
      if (is_file($file)) {
        unlink($file);
      }
    }
    rmdir($this->tmpDir);
    parent::tearDown();
  }

  /**
   * Creates a GtfsFilter backed by config stubs for bbox and/or GeoJSON.
   *
   * @param array{north: float, south: float, east: float, west: float}|null $bbox
   *   Bounding box or NULL to simulate no bbox configured.
   * @param string|null $geojson
   *   GeoJSON string or NULL to simulate no polygon configured.
   *
   * @return \Drupal\localgov_bus_data\Service\GtfsFilter
   *   Configured GtfsFilter instance.
   */
  private function makeFilter(?array $bbox, ?string $geojson = NULL): GtfsFilter {
    $config = $this->createMock(ImmutableConfig::class);
    $config->method('get')
      ->willReturnMap([
        ['source.boundary_geojson', $geojson],
        ['source.bounding_box', $bbox],
      ]);

    $configFactory = $this->createMock(ConfigFactoryInterface::class);
    $configFactory->method('get')->willReturn($config);

    return new GtfsFilter($configFactory, $this->createMock(LoggerInterface::class));
  }

  /**
   * Writes rows to a CSV file in the temp directory.
   *
   * @param string $filename
   *   Filename relative to the test temp directory.
   * @param array<int, list<string>> $rows
   *   Array of rows (each row is an array of strings).
   */
  private function writeCsv(string $filename, array $rows): void {
    $fh = fopen($this->tmpDir . '/' . $filename, 'w');
    assert($fh !== FALSE);
    foreach ($rows as $row) {
      fputcsv($fh, $row, escape: '');
    }
    fclose($fh);
  }

  /**
   * Reads all rows from a CSV file in the temp directory.
   *
   * @param string $filename
   *   Filename relative to the test temp directory.
   *
   * @return list<list<string>>
   *   All rows including the header.
   */
  private function readCsv(string $filename): array {
    $rows = [];
    $fh = fopen($this->tmpDir . '/' . $filename, 'r');
    assert($fh !== FALSE);
    while (($row = fgetcsv($fh, escape: '')) !== FALSE) {
      $rows[] = $row;
    }
    fclose($fh);
    return $rows;
  }

  /**
   * When no filter is configured, files are left untouched.
   *
   * @covers ::filterByGeography
   */
  public function testNoFilterConfiguredSkipsFiltering(): void {
    $this->writeCsv('stops.txt', [
      ['stop_id', 'stop_lat', 'stop_lon'],
      ['S1', '54.900', '-3.500'],
    ]);
    $this->writeCsv('stop_times.txt', [
      ['trip_id', 'stop_id'],
      ['T1', 'S1'],
    ]);
    $this->writeCsv('trips.txt', [
      ['trip_id', 'route_id'],
      ['T1', 'R1'],
    ]);
    $this->writeCsv('routes.txt', [
      ['route_id', 'route_short_name'],
      ['R1', '1'],
    ]);

    $result = $this->makeFilter(NULL)->filterByGeography($this->tmpDir);

    $this->assertSame(['stops' => 0, 'stop_times' => 0, 'trips' => 0, 'routes' => 0], $result);
    // Files must not be modified.
    $this->assertCount(2, $this->readCsv('stops.txt'));
    $this->assertCount(2, $this->readCsv('stop_times.txt'));
    $this->assertCount(2, $this->readCsv('trips.txt'));
    $this->assertCount(2, $this->readCsv('routes.txt'));
  }

  /**
   * Trips that serve only out-of-box stops are removed; in-box trips remain.
   *
   * Bounding box used: N=55.1, S=54.3, E=-2.0, W=-3.75 (roughly Cumberland).
   *
   * @covers ::filterByGeography
   */
  public function testInBoxTripsRetainedOutBoxTripsRemoved(): void {
    $bbox = ['north' => 55.1, 'south' => 54.3, 'east' => -2.0, 'west' => -3.75];

    $this->writeCsv('stops.txt', [
      ['stop_id', 'stop_lat', 'stop_lon'],
    // Inside.
      ['S1', '54.900', '-3.500'],
    // Inside.
      ['S2', '54.800', '-3.200'],
    // Outside (north of box)
      ['S3', '56.000', '-1.500'],
    ]);
    $this->writeCsv('stop_times.txt', [
      ['trip_id', 'stop_id', 'stop_sequence'],
    // T1 calls in-box stop → valid.
      ['T1', 'S1', '1'],
      ['T1', 'S2', '2'],
    // T2 only calls out-of-box stop → removed.
      ['T2', 'S3', '1'],
    ]);
    $this->writeCsv('trips.txt', [
      ['trip_id', 'route_id'],
      ['T1', 'R1'],
      ['T2', 'R2'],
    ]);
    $this->writeCsv('routes.txt', [
      ['route_id', 'route_short_name'],
      ['R1', '1'],
      ['R2', '2'],
    ]);

    $result = $this->makeFilter($bbox)->filterByGeography($this->tmpDir);

    $this->assertSame(2, $result['stops']);
    $this->assertSame(1, $result['trips']);
    $this->assertSame(1, $result['routes']);

    // stops.txt: header + S1 + S2 only.
    $stops = $this->readCsv('stops.txt');
    $this->assertCount(3, $stops);
    $stopIds = array_column(array_slice($stops, 1), 0);
    $this->assertContains('S1', $stopIds);
    $this->assertContains('S2', $stopIds);
    $this->assertNotContains('S3', $stopIds);

    // trips.txt: header + T1 only.
    $trips = $this->readCsv('trips.txt');
    $this->assertCount(2, $trips);
    $this->assertSame('T1', $trips[1][0]);

    // routes.txt: header + R1 only (R2 has no retained trips).
    $routes = $this->readCsv('routes.txt');
    $this->assertCount(2, $routes);
    $this->assertSame('R1', $routes[1][0]);
  }

  /**
   * A cross-boundary trip retains stops inside AND outside the bounding box.
   *
   * A route like Carlisle → Gretna (Scotland) must keep the Gretna stop even
   * though it is outside the box, so the timetable shows the correct terminal.
   *
   * @covers ::filterByGeography
   */
  public function testCrossBoundaryRouteRetainsBothStops(): void {
    $bbox = ['north' => 55.1, 'south' => 54.3, 'east' => -2.0, 'west' => -3.75];

    $this->writeCsv('stops.txt', [
      ['stop_id', 'stop_lat', 'stop_lon'],
    // Inside box.
      ['S-in', '54.900', '-3.500'],
    // Outside box.
      ['S-out', '56.000', '-1.500'],
    ]);
    $this->writeCsv('stop_times.txt', [
      ['trip_id', 'stop_id', 'stop_sequence'],
      ['T1', 'S-in', '1'],
      ['T1', 'S-out', '2'],
    ]);
    $this->writeCsv('trips.txt', [
      ['trip_id', 'route_id'],
      ['T1', 'R1'],
    ]);
    $this->writeCsv('routes.txt', [
      ['route_id', 'route_short_name'],
      ['R1', '685'],
    ]);

    $result = $this->makeFilter($bbox)->filterByGeography($this->tmpDir);

    $this->assertSame(1, $result['trips']);
    $this->assertSame(1, $result['routes']);
    // Both stops must be retained.
    $this->assertSame(2, $result['stops']);
    $stopIds = array_column(array_slice($this->readCsv('stops.txt'), 1), 0);
    $this->assertContains('S-in', $stopIds);
    $this->assertContains('S-out', $stopIds);
  }

  /**
   * Columns in a non-standard order in the CSV header are resolved correctly.
   *
   * @covers ::filterByGeography
   */
  public function testNonStandardColumnOrderFiltersCorrectly(): void {
    $bbox = ['north' => 55.1, 'south' => 54.3, 'east' => -2.0, 'west' => -3.75];

    // Deliberately reorder columns: lon before lat, name before id.
    $this->writeCsv('stops.txt', [
      ['stop_name', 'stop_lon', 'stop_lat', 'stop_id'],
      ['In-box stop', '-3.500', '54.900', 'S1'],
      ['Out-box stop', '-1.500', '56.000', 'S2'],
    ]);
    // trip_id and stop_id in reverse order.
    $this->writeCsv('stop_times.txt', [
      ['stop_sequence', 'stop_id', 'trip_id'],
      ['1', 'S1', 'T1'],
      ['1', 'S2', 'T2'],
    ]);
    // route_id before trip_id.
    $this->writeCsv('trips.txt', [
      ['route_id', 'trip_id'],
      ['R1', 'T1'],
      ['R2', 'T2'],
    ]);
    // route_short_name before route_id (non-standard column order).
    $this->writeCsv('routes.txt', [
      ['route_short_name', 'route_id'],
      ['1', 'R1'],
      ['2', 'R2'],
    ]);

    $result = $this->makeFilter($bbox)->filterByGeography($this->tmpDir);

    $this->assertSame(1, $result['stops']);
    $this->assertSame(1, $result['trips']);
    $this->assertSame(1, $result['routes']);

    // trip_id is at column index 1 in the rewritten trips.txt.
    $trips = $this->readCsv('trips.txt');
    $this->assertSame('T1', $trips[1][1]);
  }

  /**
   * A missing required CSV column triggers a logged error and returns zeros.
   *
   * @covers ::filterByGeography
   */
  public function testMissingRequiredColumnLogsErrorAndReturnsZeros(): void {
    $bbox = ['north' => 55.1, 'south' => 54.3, 'east' => -2.0, 'west' => -3.75];

    // stops.txt is missing the 'stop_lat' column.
    $this->writeCsv('stops.txt', [
      ['stop_id', 'stop_lon'],
      ['S1', '-3.500'],
    ]);
    $this->writeCsv('stop_times.txt', [
      ['trip_id', 'stop_id'],
      ['T1', 'S1'],
    ]);
    $this->writeCsv('trips.txt', [
      ['trip_id', 'route_id'],
      ['T1', 'R1'],
    ]);
    $this->writeCsv('routes.txt', [
      ['route_id', 'route_short_name'],
      ['R1', '1'],
    ]);

    $config = $this->createMock(ImmutableConfig::class);
    $config->method('get')
      ->willReturnMap([
        ['source.boundary_geojson', NULL],
        ['source.bounding_box', $bbox],
      ]);
    $configFactory = $this->createMock(ConfigFactoryInterface::class);
    $configFactory->method('get')->willReturn($config);

    $logger = $this->createMock(LoggerInterface::class);
    $logger->expects($this->once())
      ->method('error')
      ->with(
        $this->stringContains('missing required column'),
        $this->arrayHasKey('@col'),
      );

    $result = (new GtfsFilter($configFactory, $logger))->filterByGeography($this->tmpDir);

    // No in-area stops → no valid trips → all counts zero.
    $this->assertSame(
      ['stops' => 0, 'stop_times' => 0, 'trips' => 0, 'routes' => 0],
      $result
    );
    // routes.txt must be unmodified: rewriteByRouteId() guards empty input.
    $this->assertCount(2, $this->readCsv('routes.txt'));
  }

  /**
   * GeoJSON polygon correctly filters stops to within the polygon boundary.
   *
   * Uses a simple square polygon in WGS84:
   *   SW (-4.0, 54.0) → NW (-4.0, 56.0) → NE (-2.0, 56.0) → SE (-2.0, 54.0)
   *
   * Stop S1 (lat 54.9, lon -3.5) is inside; S2 (lat 57.0, lon -3.0) is
   * outside (north). The GeoJSON path must retain S1's trip and drop S2's.
   *
   * @covers ::filterByGeography
   */
  public function testGeoJsonPolygonFiltersCorrectly(): void {
    // Simple square polygon: [lon, lat] pairs (GeoJSON order).
    $geojson = json_encode([
      'type' => 'Polygon',
      'coordinates' => [[
        [-4.0, 54.0],
        [-4.0, 56.0],
        [-2.0, 56.0],
        [-2.0, 54.0],
        [-4.0, 54.0],
      ],
      ],
    ]);

    $this->writeCsv('stops.txt', [
      ['stop_id', 'stop_lat', 'stop_lon'],
    // Inside polygon.
      ['S1', '54.900', '-3.500'],
    // Outside polygon (north).
      ['S2', '57.000', '-3.000'],
    ]);
    $this->writeCsv('stop_times.txt', [
      ['trip_id', 'stop_id', 'stop_sequence'],
      ['T1', 'S1', '1'],
      ['T2', 'S2', '1'],
    ]);
    $this->writeCsv('trips.txt', [
      ['trip_id', 'route_id'],
      ['T1', 'R1'],
      ['T2', 'R2'],
    ]);
    $this->writeCsv('routes.txt', [
      ['route_id', 'route_short_name'],
      ['R1', '1'],
      ['R2', '2'],
    ]);

    $result = $this->makeFilter(NULL, $geojson)->filterByGeography($this->tmpDir);

    $this->assertSame(1, $result['stops']);
    $this->assertSame(1, $result['trips']);
    $this->assertSame(1, $result['routes']);

    $stopIds = array_column(array_slice($this->readCsv('stops.txt'), 1), 0);
    $this->assertContains('S1', $stopIds);
    $this->assertNotContains('S2', $stopIds);

    $trips = $this->readCsv('trips.txt');
    $this->assertCount(2, $trips);
    $this->assertSame('T1', $trips[1][0]);
  }

  /**
   * A GeoJSON Feature wrapper is unwrapped and the inner Polygon is used.
   *
   * @covers ::filterByGeography
   */
  public function testGeoJsonFeatureWrapperIsUnwrapped(): void {
    $geojson = json_encode([
      'type'     => 'Feature',
      'geometry' => [
        'type'        => 'Polygon',
        'coordinates' => [[
          [-4.0, 54.0],
          [-4.0, 56.0],
          [-2.0, 56.0],
          [-2.0, 54.0],
          [-4.0, 54.0],
        ],
        ],
      ],
    ]);

    $this->writeCsv('stops.txt', [
      ['stop_id', 'stop_lat', 'stop_lon'],
      ['S1', '54.900', '-3.500'],
      ['S2', '57.000', '-3.000'],
    ]);
    $this->writeCsv('stop_times.txt', [
      ['trip_id', 'stop_id', 'stop_sequence'],
      ['T1', 'S1', '1'],
      ['T2', 'S2', '1'],
    ]);
    $this->writeCsv('trips.txt', [
      ['trip_id', 'route_id'],
      ['T1', 'R1'],
      ['T2', 'R2'],
    ]);
    $this->writeCsv('routes.txt', [
      ['route_id', 'route_short_name'],
      ['R1', '1'],
      ['R2', '2'],
    ]);

    $result = $this->makeFilter(NULL, $geojson)->filterByGeography($this->tmpDir);

    $this->assertSame(1, $result['stops']);
    $stopIds = array_column(array_slice($this->readCsv('stops.txt'), 1), 0);
    $this->assertContains('S1', $stopIds);
    $this->assertNotContains('S2', $stopIds);
  }

  /**
   * A GeoJSON FeatureCollection is unwrapped and all features' rings are used.
   *
   * Two separate square polygons side by side: the west polygon covers S1,
   * the east polygon covers S3. S2 sits between them and must be excluded.
   *
   * @covers ::filterByGeography
   */
  public function testGeoJsonFeatureCollectionAllFeaturesUsed(): void {
    $geojson = json_encode([
      'type'     => 'FeatureCollection',
      'features' => [
        [
          'type'     => 'Feature',
          'geometry' => [
            'type'        => 'Polygon',
            // West square: lon -4 to -3, lat 54 to 56.
            'coordinates' => [[
              [-4.0, 54.0],
              [-4.0, 56.0],
              [-3.0, 56.0],
              [-3.0, 54.0],
              [-4.0, 54.0],
            ],
            ],
          ],
        ],
        [
          'type'     => 'Feature',
          'geometry' => [
            'type'        => 'Polygon',
            // East square: lon -2.5 to -1.5, lat 54 to 56.
            'coordinates' => [[
              [-2.5, 54.0],
              [-2.5, 56.0],
              [-1.5, 56.0],
              [-1.5, 54.0],
              [-2.5, 54.0],
            ],
            ],
          ],
        ],
      ],
    ]);

    $this->writeCsv('stops.txt', [
      ['stop_id', 'stop_lat', 'stop_lon'],
    // Inside west polygon.
      ['S1', '55.000', '-3.500'],
    // Between polygons — outside both.
      ['S2', '55.000', '-2.750'],
    // Inside east polygon.
      ['S3', '55.000', '-2.000'],
    ]);
    $this->writeCsv('stop_times.txt', [
      ['trip_id', 'stop_id', 'stop_sequence'],
      ['T1', 'S1', '1'],
      ['T2', 'S2', '1'],
      ['T3', 'S3', '1'],
    ]);
    $this->writeCsv('trips.txt', [
      ['trip_id', 'route_id'],
      ['T1', 'R1'],
      ['T2', 'R2'],
      ['T3', 'R3'],
    ]);
    $this->writeCsv('routes.txt', [
      ['route_id', 'route_short_name'],
      ['R1', '1'],
      ['R2', '2'],
      ['R3', '3'],
    ]);

    $result = $this->makeFilter(NULL, $geojson)->filterByGeography($this->tmpDir);

    // S1 (west) and S3 (east) retained; S2 (between) removed.
    $this->assertSame(2, $result['stops']);
    $this->assertSame(2, $result['trips']);
    $stopIds = array_column(array_slice($this->readCsv('stops.txt'), 1), 0);
    $this->assertContains('S1', $stopIds);
    $this->assertNotContains('S2', $stopIds);
    $this->assertContains('S3', $stopIds);
  }

  /**
   * GeoJSON takes precedence over the bounding box when both are configured.
   *
   * The bbox would exclude S1 (too far south) but the polygon includes it.
   * S2 is inside the bbox but outside the polygon. After filtering only S1's
   * trip should survive — proving the polygon was used, not the bbox.
   *
   * @covers ::filterByGeography
   */
  public function testGeoJsonTakesPrecedenceOverBbox(): void {
    // Polygon covers lat 54–56, lon -4 to -2.
    $geojson = json_encode([
      'type' => 'Polygon',
      'coordinates' => [[
        [-4.0, 54.0],
        [-4.0, 56.0],
        [-2.0, 56.0],
        [-2.0, 54.0],
        [-4.0, 54.0],
      ],
      ],
    ]);
    // Bbox covers lat 55–56 only — would exclude S1 at lat 54.9.
    $bbox = ['north' => 56.0, 'south' => 55.0, 'east' => -2.0, 'west' => -4.0];

    $this->writeCsv('stops.txt', [
      ['stop_id', 'stop_lat', 'stop_lon'],
    // Inside polygon, outside bbox (lat 54.9 < bbox south 55.0).
      ['S1', '54.900', '-3.500'],
    // Outside polygon (lon -1.0 > polygon east -2.0), inside bbox.
      ['S2', '55.500', '-1.000'],
    ]);
    $this->writeCsv('stop_times.txt', [
      ['trip_id', 'stop_id', 'stop_sequence'],
      ['T1', 'S1', '1'],
      ['T2', 'S2', '1'],
    ]);
    $this->writeCsv('trips.txt', [
      ['trip_id', 'route_id'],
      ['T1', 'R1'],
      ['T2', 'R2'],
    ]);
    $this->writeCsv('routes.txt', [
      ['route_id', 'route_short_name'],
      ['R1', '1'],
      ['R2', '2'],
    ]);

    $result = $this->makeFilter($bbox, $geojson)->filterByGeography($this->tmpDir);

    // Only T1/R1 should survive: polygon includes S1, bbox would exclude it.
    $this->assertSame(1, $result['trips']);
    $stopIds = array_column(array_slice($this->readCsv('stops.txt'), 1), 0);
    $this->assertContains('S1', $stopIds);
    $this->assertNotContains('S2', $stopIds);
  }

}
