<?php

declare(strict_types=1);

namespace Drupal\Tests\localgov_bus_data\Unit\Service;

use PHPUnit\Framework\Attributes\Group;
use Drupal\Core\Config\Config;
use Drupal\Core\Config\ConfigFactoryInterface;
use Drupal\Core\Config\ImmutableConfig;
use Drupal\Core\Entity\EntityStorageInterface;
use Drupal\Core\Entity\EntityTypeManagerInterface;
use Drupal\Core\File\FileSystemInterface;
use Drupal\Core\State\StateInterface;
use Drupal\file\FileInterface;
use Drupal\file\FileUsage\FileUsageInterface;
use Drupal\localgov_bus_data\Service\CustomCsvManager;
use Drupal\localgov_bus_data\Service\CustomCsvValidator;
use Drupal\Tests\UnitTestCase;
use Psr\Log\LoggerInterface;

/**
 * Unit tests for CustomCsvManager's merge-into-staging logic.
 *
 * Uses real temporary CSV files for the custom and staged data (following
 * the fixture approach in GtfsFilterTest) and mocks the Drupal services
 * CustomCsvManager depends on: config, entity storage (for the stored
 * managed files), the file system (for URI-to-path resolution), file usage,
 * state, and the logger.
 *
 * @coversDefaultClass \Drupal\localgov_bus_data\Service\CustomCsvManager
 * @group localgov_bus_data
 */
#[Group('localgov_bus_data')]
final class CustomCsvManagerTest extends UnitTestCase {

  /**
   * Temporary directory for custom CSV fixtures.
   *
   * @var string
   */
  private string $tmpDir;

  /**
   * Temporary directory standing in for the GTFS staging directory.
   *
   * @var string
   */
  private string $stagingDir;

  /**
   * {@inheritdoc}
   */
  protected function setUp(): void {
    parent::setUp();
    $this->tmpDir = sys_get_temp_dir() . '/custom_csv_manager_test_' . uniqid();
    mkdir($this->tmpDir, 0750, TRUE);
    $this->stagingDir = $this->tmpDir . '/staging';
    mkdir($this->stagingDir, 0750, TRUE);
  }

  /**
   * {@inheritdoc}
   */
  protected function tearDown(): void {
    $this->removeDir($this->tmpDir);
    parent::tearDown();
  }

  /**
   * Recursively removes a directory tree.
   */
  private function removeDir(string $dir): void {
    if (!is_dir($dir)) {
      return;
    }
    foreach (glob($dir . '/*') ?: [] as $path) {
      is_dir($path) ? $this->removeDir($path) : unlink($path);
    }
    rmdir($dir);
  }

  /**
   * Writes rows to a CSV file.
   *
   * @param string $path
   *   Absolute path to write.
   * @param array<int, array<int, string>> $rows
   *   Rows including the header.
   */
  private function writeCsv(string $path, array $rows): void {
    $fh = fopen($path, 'w');
    assert($fh !== FALSE);
    foreach ($rows as $row) {
      fputcsv($fh, $row, escape: '');
    }
    fclose($fh);
  }

  /**
   * Reads all rows from a CSV file.
   *
   * @param string $path
   *   Absolute path to read.
   *
   * @return array<int, array<int, string|null>>
   *   All rows including the header.
   */
  private function readCsv(string $path): array {
    $rows = [];
    $fh = fopen($path, 'r');
    assert($fh !== FALSE);
    while (($row = fgetcsv($fh, escape: '')) !== FALSE) {
      $rows[] = $row;
    }
    fclose($fh);
    return $rows;
  }

  /**
   * Builds a CustomCsvManager with mocked Drupal services.
   *
   * @param bool $enabled
   *   The custom_data.enabled config value.
   * @param array<string, string|null> $fileMap
   *   File key => absolute path to the stored custom file. A NULL value
   *   simulates a config entry whose managed file entity no longer exists.
   *
   * @return \Drupal\localgov_bus_data\Service\CustomCsvManager
   *   Configured manager instance.
   */
  private function makeManager(bool $enabled, array $fileMap): CustomCsvManager {
    $fileIds = [];
    $entityPaths = [];
    $fid = 1;
    foreach ($fileMap as $key => $path) {
      $fileIds[$key] = $fid;
      $entityPaths[$fid] = $path;
      $fid++;
    }

    $config = $this->createMock(ImmutableConfig::class);
    $config->method('get')
      ->willReturnMap([
        ['custom_data.enabled', $enabled],
        ['custom_data.files', $fileIds],
      ]);
    $configFactory = $this->createMock(ConfigFactoryInterface::class);
    $configFactory->method('get')->willReturn($config);

    $storage = $this->createMock(EntityStorageInterface::class);
    $storage->method('load')->willReturnCallback(function ($loadFid) use ($entityPaths) {
      $path = $entityPaths[$loadFid] ?? NULL;
      if ($path === NULL) {
        return NULL;
      }
      $file = $this->createMock(FileInterface::class);
      $file->method('getFileUri')->willReturn($path);
      return $file;
    });

    $entityTypeManager = $this->createMock(EntityTypeManagerInterface::class);
    $entityTypeManager->method('getStorage')->with('file')->willReturn($storage);

    $fileSystem = $this->createMock(FileSystemInterface::class);
    $fileSystem->method('realpath')->willReturnArgument(0);

    $fileUsage = $this->createMock(FileUsageInterface::class);
    $state = $this->createMock(StateInterface::class);
    $logger = $this->createMock(LoggerInterface::class);
    $validator = new CustomCsvValidator();

    return new CustomCsvManager($configFactory, $entityTypeManager, $fileSystem, $fileUsage, $state, $logger, $validator);
  }

  /**
   * Custom rows are appended in staged column order, not custom order.
   *
   * @covers ::mergeIntoStaging
   */
  public function testColumnReordering(): void {
    $stagedPath = $this->stagingDir . '/stops.txt';
    $this->writeCsv($stagedPath, [
      ['stop_id', 'stop_name', 'stop_lat', 'stop_lon'],
      ['S1', 'Feed Stop', '54.90', '-3.50'],
    ]);

    $customPath = $this->tmpDir . '/custom_stops.txt';
    $this->writeCsv($customPath, [
      ['stop_lon', 'stop_id', 'stop_lat', 'stop_name'],
      ['-3.51', 'CUSTOM_S1', '54.91', 'Custom Stop'],
    ]);

    $manager = $this->makeManager(TRUE, ['stops' => $customPath]);
    $counts = $manager->mergeIntoStaging($this->stagingDir);

    $this->assertSame(['stops' => 1], $counts);
    $rows = $this->readCsv($stagedPath);
    $this->assertCount(3, $rows);
    $this->assertSame(['CUSTOM_S1', 'Custom Stop', '54.91', '-3.51'], $rows[2]);
  }

  /**
   * @covers ::mergeIntoStaging
   */
  public function testMissingOptionalColumnsFilledEmpty(): void {
    $stagedPath = $this->stagingDir . '/stops.txt';
    $this->writeCsv($stagedPath, [
      ['stop_id', 'stop_name', 'stop_lat', 'stop_lon', 'wheelchair_boarding'],
      ['S1', 'Feed Stop', '54.90', '-3.50', '1'],
    ]);

    $customPath = $this->tmpDir . '/custom_stops.txt';
    $this->writeCsv($customPath, [
      ['stop_id', 'stop_name', 'stop_lat', 'stop_lon'],
      ['CUSTOM_S1', 'Custom Stop', '54.91', '-3.51'],
    ]);

    $manager = $this->makeManager(TRUE, ['stops' => $customPath]);
    $manager->mergeIntoStaging($this->stagingDir);

    $rows = $this->readCsv($stagedPath);
    $this->assertSame(['CUSTOM_S1', 'Custom Stop', '54.91', '-3.51', ''], $rows[2]);
  }

  /**
   * Padded cells are trimmed before writing, matching what was validated.
   *
   * CustomCsvValidator::cell() trims every cell, so a hand-authored CSV
   * with spaces after commas validates against the trimmed values. The
   * merge must write those same trimmed values, or a staged route_id like
   * " R1" (with a leading space) fails to match "R1" elsewhere in the
   * staged data despite the upload having been reported valid.
   *
   * @covers ::mergeIntoStaging
   */
  public function testPaddedCellsAreTrimmedWhenAppendedToExistingStagedFile(): void {
    $stagedPath = $this->stagingDir . '/stops.txt';
    $this->writeCsv($stagedPath, [
      ['stop_id', 'stop_name', 'stop_lat', 'stop_lon'],
      ['S1', 'Feed Stop', '54.90', '-3.50'],
    ]);

    $customPath = $this->tmpDir . '/custom_stops.txt';
    // Written directly (not via writeCsv()/fputcsv()) so the padding
    // after each comma survives into the file.
    file_put_contents(
      $customPath,
      "stop_id,stop_name,stop_lat,stop_lon\n CUSTOM_S1 , Custom Stop , 54.91 , -3.51 \n",
    );

    $manager = $this->makeManager(TRUE, ['stops' => $customPath]);
    $manager->mergeIntoStaging($this->stagingDir);

    $rows = $this->readCsv($stagedPath);
    $this->assertSame(['CUSTOM_S1', 'Custom Stop', '54.91', '-3.51'], $rows[2]);
  }

  /**
   * Padded cells are trimmed when the custom file becomes the staged file.
   *
   * @covers ::mergeIntoStaging
   */
  public function testPaddedCellsAreTrimmedWhenWrittenAsNewStagedFile(): void {
    $customPath = $this->tmpDir . '/custom_agency.txt';
    file_put_contents(
      $customPath,
      "agency_id,agency_name\n CUSTOM_A1 , Custom Agency \n",
    );

    $manager = $this->makeManager(TRUE, ['agency' => $customPath]);
    $manager->mergeIntoStaging($this->stagingDir);

    $rows = $this->readCsv($this->stagingDir . '/agency.txt');
    $this->assertSame(['CUSTOM_A1', 'Custom Agency'], $rows[1]);
  }

  /**
   * A staged file with no corresponding custom file is left untouched.
   *
   * @covers ::mergeIntoStaging
   */
  public function testUntouchedStagedFiles(): void {
    $routesPath = $this->stagingDir . '/routes.txt';
    $originalRows = [
      ['route_id', 'route_short_name', 'agency_id', 'route_type'],
      ['R1', '1', 'A1', '3'],
    ];
    $this->writeCsv($routesPath, $originalRows);

    $stopsPath = $this->stagingDir . '/stops.txt';
    $this->writeCsv($stopsPath, [
      ['stop_id', 'stop_name', 'stop_lat', 'stop_lon'],
    ]);
    $customPath = $this->tmpDir . '/custom_stops.txt';
    $this->writeCsv($customPath, [
      ['stop_id', 'stop_name', 'stop_lat', 'stop_lon'],
      ['CUSTOM_S1', 'Custom Stop', '54.91', '-3.51'],
    ]);

    $manager = $this->makeManager(TRUE, ['stops' => $customPath]);
    $manager->mergeIntoStaging($this->stagingDir);

    $this->assertSame($originalRows, $this->readCsv($routesPath));
  }

  /**
   * Appended row counts are returned per file.
   *
   * @covers ::mergeIntoStaging
   */
  public function testAppendedRowCounts(): void {
    $this->writeCsv($this->stagingDir . '/agency.txt', [
      ['agency_id', 'agency_name'],
    ]);
    $this->writeCsv($this->stagingDir . '/stops.txt', [
      ['stop_id', 'stop_name', 'stop_lat', 'stop_lon'],
    ]);

    $agencyCustomPath = $this->tmpDir . '/custom_agency.txt';
    $this->writeCsv($agencyCustomPath, [
      ['agency_id', 'agency_name'],
      ['CUSTOM_A1', 'Custom Agency'],
    ]);
    $stopsCustomPath = $this->tmpDir . '/custom_stops.txt';
    $this->writeCsv($stopsCustomPath, [
      ['stop_id', 'stop_name', 'stop_lat', 'stop_lon'],
      ['CUSTOM_S1', 'Custom Stop 1', '54.90', '-3.50'],
      ['CUSTOM_S2', 'Custom Stop 2', '54.91', '-3.51'],
    ]);

    $manager = $this->makeManager(TRUE, [
      'agency' => $agencyCustomPath,
      'stops'  => $stopsCustomPath,
    ]);
    $counts = $manager->mergeIntoStaging($this->stagingDir);

    $this->assertSame(['agency' => 1, 'stops' => 2], $counts);
  }

  /**
   * A missing staged counterpart makes the custom file the staged file.
   *
   * @covers ::mergeIntoStaging
   */
  public function testMissingStagedCounterpart(): void {
    $customPath = $this->tmpDir . '/custom_agency.txt';
    $this->writeCsv($customPath, [
      ['agency_id', 'agency_name'],
      ['CUSTOM_A1', 'Custom Agency'],
    ]);

    $manager = $this->makeManager(TRUE, ['agency' => $customPath]);
    $counts = $manager->mergeIntoStaging($this->stagingDir);

    $this->assertSame(['agency' => 1], $counts);
    $stagedPath = $this->stagingDir . '/agency.txt';
    $this->assertFileExists($stagedPath);
    $this->assertSame([
      ['agency_id', 'agency_name'],
      ['CUSTOM_A1', 'Custom Agency'],
    ], $this->readCsv($stagedPath));
  }

  /**
   * A staged file with no readable header is treated as a missing one.
   *
   * @covers ::mergeIntoStaging
   */
  public function testStagedFileWithUnreadableHeaderIsTreatedAsMissing(): void {
    $stagedPath = $this->stagingDir . '/agency.txt';
    // A staged file consisting only of a blank line has no header row.
    file_put_contents($stagedPath, "\n");

    $customPath = $this->tmpDir . '/custom_agency.txt';
    $this->writeCsv($customPath, [
      ['agency_id', 'agency_name'],
      ['CUSTOM_A1', 'Custom Agency'],
    ]);

    $manager = $this->makeManager(TRUE, ['agency' => $customPath]);
    $counts = $manager->mergeIntoStaging($this->stagingDir);

    $this->assertSame(['agency' => 1], $counts);
    $this->assertSame([
      ['agency_id', 'agency_name'],
      ['CUSTOM_A1', 'Custom Agency'],
    ], $this->readCsv($stagedPath));
  }

  /**
   * @covers ::mergeIntoStaging
   */
  public function testDisabledFlagProducesNoOp(): void {
    $stagedPath = $this->stagingDir . '/agency.txt';
    $originalRows = [['agency_id', 'agency_name']];
    $this->writeCsv($stagedPath, $originalRows);

    $customPath = $this->tmpDir . '/custom_agency.txt';
    $this->writeCsv($customPath, [
      ['agency_id', 'agency_name'],
      ['CUSTOM_A1', 'Custom Agency'],
    ]);

    $manager = $this->makeManager(FALSE, ['agency' => $customPath]);
    $counts = $manager->mergeIntoStaging($this->stagingDir);

    $this->assertSame([], $counts);
    $this->assertSame($originalRows, $this->readCsv($stagedPath));
  }

  /**
   * @covers ::mergeIntoStaging
   */
  public function testEmptyConfigProducesNoOp(): void {
    $manager = $this->makeManager(TRUE, []);
    $counts = $manager->mergeIntoStaging($this->stagingDir);
    $this->assertSame([], $counts);
  }

  /**
   * @covers ::hasStoredFiles
   */
  public function testHasStoredFilesReflectsConfig(): void {
    $customPath = $this->tmpDir . '/custom_agency.txt';
    $this->writeCsv($customPath, [
      ['agency_id', 'agency_name'],
      ['A1', 'Custom Agency'],
    ]);

    $this->assertFalse($this->makeManager(TRUE, [])->hasStoredFiles());
    $this->assertTrue($this->makeManager(TRUE, ['agency' => $customPath])->hasStoredFiles());
  }

  /**
   * A config entry referencing a deleted managed file is skipped, not fatal.
   *
   * @covers ::mergeIntoStaging
   */
  public function testMissingFileEntityHandledGracefully(): void {
    $stopsCustomPath = $this->tmpDir . '/custom_stops.txt';
    $this->writeCsv($stopsCustomPath, [
      ['stop_id', 'stop_name', 'stop_lat', 'stop_lon'],
      ['CUSTOM_S1', 'Custom Stop', '54.90', '-3.50'],
    ]);
    $this->writeCsv($this->stagingDir . '/stops.txt', [
      ['stop_id', 'stop_name', 'stop_lat', 'stop_lon'],
    ]);

    $manager = $this->makeManager(TRUE, [
      // Simulates config referencing a file entity that has been deleted.
      'agency' => NULL,
      'stops'  => $stopsCustomPath,
    ]);
    $counts = $manager->mergeIntoStaging($this->stagingDir);

    $this->assertSame(['stops' => 1], $counts);
  }

  /**
   * An unresolvable file URI is skipped, distinct from a missing entity.
   *
   * @covers ::mergeIntoStaging
   */
  public function testUnresolvableFileUriHandledGracefully(): void {
    $stopsCustomPath = $this->tmpDir . '/custom_stops.txt';
    $this->writeCsv($stopsCustomPath, [
      ['stop_id', 'stop_name', 'stop_lat', 'stop_lon'],
      ['CUSTOM_S1', 'Custom Stop', '54.90', '-3.50'],
    ]);
    $this->writeCsv($this->stagingDir . '/stops.txt', [
      ['stop_id', 'stop_name', 'stop_lat', 'stop_lon'],
    ]);

    $config = $this->createMock(ImmutableConfig::class);
    $config->method('get')
      ->willReturnMap([
        ['custom_data.enabled', TRUE],
        ['custom_data.files', ['agency' => 1, 'stops' => 2]],
      ]);
    $configFactory = $this->createMock(ConfigFactoryInterface::class);
    $configFactory->method('get')->willReturn($config);

    $unresolvableFile = $this->createMock(FileInterface::class);
    $unresolvableFile->method('getFileUri')->willReturn('public://bus-times/custom/agency.csv');
    $resolvableFile = $this->createMock(FileInterface::class);
    $resolvableFile->method('getFileUri')->willReturn($stopsCustomPath);

    $storage = $this->createMock(EntityStorageInterface::class);
    $storage->method('load')->willReturnMap([
      [1, $unresolvableFile],
      [2, $resolvableFile],
    ]);
    $entityTypeManager = $this->createMock(EntityTypeManagerInterface::class);
    $entityTypeManager->method('getStorage')->with('file')->willReturn($storage);

    $fileSystem = $this->createMock(FileSystemInterface::class);
    $fileSystem->method('realpath')->willReturnMap([
      ['public://bus-times/custom/agency.csv', FALSE],
      [$stopsCustomPath, $stopsCustomPath],
    ]);

    $fileUsage = $this->createMock(FileUsageInterface::class);
    $state = $this->createMock(StateInterface::class);
    $logger = $this->createMock(LoggerInterface::class);

    $manager = new CustomCsvManager(
      $configFactory,
      $entityTypeManager,
      $fileSystem,
      $fileUsage,
      $state,
      $logger,
      new CustomCsvValidator(),
    );

    $counts = $manager->mergeIntoStaging($this->stagingDir);
    $this->assertSame(['stops' => 1], $counts);
  }

  /**
   * Validating the stored files records the validation report in State.
   *
   * @covers ::validateStoredFiles
   */
  public function testValidateStoredFilesRecordsReportInState(): void {
    $customPath = $this->tmpDir . '/custom_agency.txt';
    $this->writeCsv($customPath, [
      ['agency_id', 'agency_name'],
      ['CUSTOM_A1', 'Custom Agency'],
    ]);

    $fileIds = ['agency' => 1];
    $config = $this->createMock(ImmutableConfig::class);
    $config->method('get')
      ->willReturnMap([
        ['custom_data.enabled', TRUE],
        ['custom_data.files', $fileIds],
      ]);
    $configFactory = $this->createMock(ConfigFactoryInterface::class);
    $configFactory->method('get')->willReturn($config);

    $file = $this->createMock(FileInterface::class);
    $file->method('getFileUri')->willReturn($customPath);
    $storage = $this->createMock(EntityStorageInterface::class);
    $storage->method('load')->with(1)->willReturn($file);
    $entityTypeManager = $this->createMock(EntityTypeManagerInterface::class);
    $entityTypeManager->method('getStorage')->with('file')->willReturn($storage);

    $fileSystem = $this->createMock(FileSystemInterface::class);
    $fileSystem->method('realpath')->willReturnArgument(0);
    $fileUsage = $this->createMock(FileUsageInterface::class);
    $logger = $this->createMock(LoggerInterface::class);

    $state = $this->createMock(StateInterface::class);
    $state->expects($this->once())
      ->method('set')
      ->with(
        CustomCsvManager::STATE_KEY,
        $this->callback(function (array $value): bool {
          return $value['valid'] === TRUE
            && $value['accepted_row_counts'] === ['agency' => 1]
            && $value['errors'] === [];
        }),
      );

    $manager = new CustomCsvManager(
      $configFactory,
      $entityTypeManager,
      $fileSystem,
      $fileUsage,
      $state,
      $logger,
      new CustomCsvValidator(),
    );

    $report = $manager->validateStoredFiles($this->stagingDir);
    $this->assertTrue($report->isValid());
  }

  /**
   * Regression test for the self-collision bug found during manual QA.
   *
   * The merge method (mergeIntoStaging()) appends custom rows directly into
   * the live GTFS staging directory, and that merge is only undone at the
   * start of the next import (prepareStagingDirectory() rebuilds it).
   * Between imports, the live directory still contains the previous
   * merge's custom rows.
   * Revalidating the same stored custom set against that live directory
   * sees its own already-merged agency_id and reports it as colliding with
   * staged data: a false positive against itself. This is exactly what
   * CustomCsvForm's submitValidateNow(), saveUpload(), and removeFile()
   * call sites must avoid by validating against the clean pre-merge
   * snapshot (GtfsImportService::getCleanStagingDirPath()) instead of the
   * live staging directory (GtfsImportService::getStagingDirPath()).
   *
   * @covers ::validateStoredFiles
   */
  public function testValidateStoredFilesCollidesAgainstLiveDirButNotCleanSnapshot(): void {
    $customPath = $this->tmpDir . '/custom_agency.txt';
    $this->writeCsv($customPath, [
      ['agency_id', 'agency_name'],
      ['CUSTOM_A1', 'Custom Agency'],
    ]);

    // The clean snapshot reflects only the feed, as it would immediately
    // after this cycle's staging rebuild.
    $cleanDir = $this->tmpDir . '/clean';
    mkdir($cleanDir, 0750, TRUE);
    $this->writeCsv($cleanDir . '/agency.txt', [
      ['agency_id', 'agency_name'],
    ]);

    // The live directory still carries CUSTOM_A1 from a previous merge
    // that has not yet been rebuilt away.
    $this->writeCsv($this->stagingDir . '/agency.txt', [
      ['agency_id', 'agency_name'],
      ['CUSTOM_A1', 'Custom Agency'],
    ]);

    $fileIds = ['agency' => 1];
    $config = $this->createMock(ImmutableConfig::class);
    $config->method('get')
      ->willReturnMap([
        ['custom_data.enabled', TRUE],
        ['custom_data.files', $fileIds],
      ]);
    $configFactory = $this->createMock(ConfigFactoryInterface::class);
    $configFactory->method('get')->willReturn($config);

    $file = $this->createMock(FileInterface::class);
    $file->method('getFileUri')->willReturn($customPath);
    $storage = $this->createMock(EntityStorageInterface::class);
    $storage->method('load')->with(1)->willReturn($file);
    $entityTypeManager = $this->createMock(EntityTypeManagerInterface::class);
    $entityTypeManager->method('getStorage')->with('file')->willReturn($storage);

    $fileSystem = $this->createMock(FileSystemInterface::class);
    $fileSystem->method('realpath')->willReturnArgument(0);
    $fileUsage = $this->createMock(FileUsageInterface::class);
    $state = $this->createMock(StateInterface::class);
    $logger = $this->createMock(LoggerInterface::class);

    $manager = new CustomCsvManager(
      $configFactory,
      $entityTypeManager,
      $fileSystem,
      $fileUsage,
      $state,
      $logger,
      new CustomCsvValidator(),
    );

    // Validating against the stale live directory reproduces the bug: a
    // false "collides with staged data" error against the custom set's own
    // previously-merged row.
    $liveReport = $manager->validateStoredFiles($this->stagingDir);
    $this->assertFalse($liveReport->isValid());

    // Validating against the clean snapshot (what CustomCsvForm now uses)
    // avoids the false positive.
    $cleanReport = $manager->validateStoredFiles($cleanDir);
    $this->assertTrue($cleanReport->isValid());
  }

  /**
   * A proposed set combines a new upload with an already-stored, kept file.
   *
   * @covers ::validateProposedSet
   */
  public function testValidateProposedSetCombinesNewAndStoredFiles(): void {
    $storedStopsPath = $this->tmpDir . '/stored_stops.txt';
    $this->writeCsv($storedStopsPath, [
      ['stop_id', 'stop_name', 'stop_lat', 'stop_lon'],
      ['S1', 'Stored Stop', '54.90', '-3.50'],
    ]);
    $newAgencyPath = $this->tmpDir . '/new_agency.txt';
    $this->writeCsv($newAgencyPath, [
      ['agency_id', 'agency_name'],
      ['A1', 'New Agency'],
    ]);

    $config = $this->createMock(ImmutableConfig::class);
    $config->method('get')
      ->willReturnMap([
        ['custom_data.enabled', TRUE],
        ['custom_data.files', ['stops' => 1]],
      ]);
    $configFactory = $this->createMock(ConfigFactoryInterface::class);
    $configFactory->method('get')->willReturn($config);

    $storedFile = $this->createMock(FileInterface::class);
    $storedFile->method('getFileUri')->willReturn($storedStopsPath);
    $newFile = $this->createMock(FileInterface::class);
    $newFile->method('getFileUri')->willReturn($newAgencyPath);

    $storage = $this->createMock(EntityStorageInterface::class);
    $storage->method('load')->willReturnMap([
      [1, $storedFile],
      [2, $newFile],
    ]);
    $entityTypeManager = $this->createMock(EntityTypeManagerInterface::class);
    $entityTypeManager->method('getStorage')->with('file')->willReturn($storage);

    $fileSystem = $this->createMock(FileSystemInterface::class);
    $fileSystem->method('realpath')->willReturnArgument(0);
    $fileUsage = $this->createMock(FileUsageInterface::class);
    $state = $this->createMock(StateInterface::class);
    $logger = $this->createMock(LoggerInterface::class);

    $manager = new CustomCsvManager(
      $configFactory,
      $entityTypeManager,
      $fileSystem,
      $fileUsage,
      $state,
      $logger,
      new CustomCsvValidator(),
    );

    $report = $manager->validateProposedSet(['agency' => 2], $this->stagingDir);
    $this->assertTrue($report->isValid(), (string) json_encode($report->getErrors()));
    $this->assertSame(['agency' => 1, 'stops' => 1], $report->getAcceptedRowCounts());
  }

  /**
   * A valid upload is made permanent, tracked via file.usage, and saved.
   *
   * @covers ::saveUpload
   */
  public function testSaveUploadPersistsValidUploadAndTracksUsage(): void {
    $newAgencyPath = $this->tmpDir . '/new_agency.txt';
    $this->writeCsv($newAgencyPath, [
      ['agency_id', 'agency_name'],
      ['A1', 'New Agency'],
    ]);

    $config = $this->createMock(ImmutableConfig::class);
    $config->method('get')
      ->willReturnMap([
        ['custom_data.enabled', TRUE],
        ['custom_data.files', []],
      ]);
    $configFactory = $this->createMock(ConfigFactoryInterface::class);
    $configFactory->method('get')->willReturn($config);

    $editableConfig = $this->createMock(Config::class);
    $editableConfig->method('get')->with('custom_data.files')->willReturn([]);
    $editableConfig->expects($this->once())->method('set')->with('custom_data.files', ['agency' => 5])->willReturnSelf();
    $editableConfig->expects($this->once())->method('save')->with(TRUE);
    $configFactory->method('getEditable')->willReturn($editableConfig);

    $newFile = $this->createMock(FileInterface::class);
    $newFile->method('getFileUri')->willReturn($newAgencyPath);
    $newFile->expects($this->once())->method('setPermanent');
    $newFile->expects($this->once())->method('save');

    $storage = $this->createMock(EntityStorageInterface::class);
    $storage->method('load')->with(5)->willReturn($newFile);
    $entityTypeManager = $this->createMock(EntityTypeManagerInterface::class);
    $entityTypeManager->method('getStorage')->with('file')->willReturn($storage);

    $fileSystem = $this->createMock(FileSystemInterface::class);
    $fileSystem->method('realpath')->willReturnArgument(0);

    $fileUsage = $this->createMock(FileUsageInterface::class);
    $fileUsage->expects($this->once())->method('add')->with($newFile, 'localgov_bus_data', 'custom_data', 'agency');
    $fileUsage->expects($this->never())->method('delete');

    $state = $this->createMock(StateInterface::class);
    $logger = $this->createMock(LoggerInterface::class);

    $manager = new CustomCsvManager(
      $configFactory,
      $entityTypeManager,
      $fileSystem,
      $fileUsage,
      $state,
      $logger,
      new CustomCsvValidator(),
    );

    $report = $manager->saveUpload(['agency' => 5], $this->stagingDir);
    $this->assertTrue($report->isValid(), (string) json_encode($report->getErrors()));
  }

  /**
   * Replacing a stored slot releases and deletes the previous file.
   *
   * @covers ::saveUpload
   */
  public function testSaveUploadReplacingSlotReleasesOldUsage(): void {
    $oldPath = $this->tmpDir . '/old_agency.txt';
    $this->writeCsv($oldPath, [
      ['agency_id', 'agency_name'],
      ['OLD1', 'Old Agency'],
    ]);
    $newPath = $this->tmpDir . '/new_agency.txt';
    $this->writeCsv($newPath, [
      ['agency_id', 'agency_name'],
      ['NEW1', 'New Agency'],
    ]);

    $config = $this->createMock(ImmutableConfig::class);
    $config->method('get')
      ->willReturnMap([
        ['custom_data.enabled', TRUE],
        ['custom_data.files', ['agency' => 1]],
      ]);
    $configFactory = $this->createMock(ConfigFactoryInterface::class);
    $configFactory->method('get')->willReturn($config);

    $editableConfig = $this->createMock(Config::class);
    $editableConfig->method('get')->with('custom_data.files')->willReturn(['agency' => 1]);
    $editableConfig->expects($this->once())->method('set')->with('custom_data.files', ['agency' => 2])->willReturnSelf();
    $editableConfig->expects($this->once())->method('save')->with(TRUE);
    $configFactory->method('getEditable')->willReturn($editableConfig);

    $oldFile = $this->createMock(FileInterface::class);
    $oldFile->method('getFileUri')->willReturn($oldPath);
    $oldFile->expects($this->once())->method('delete');
    $newFile = $this->createMock(FileInterface::class);
    $newFile->method('getFileUri')->willReturn($newPath);
    $newFile->expects($this->once())->method('setPermanent');
    $newFile->expects($this->once())->method('save');

    $storage = $this->createMock(EntityStorageInterface::class);
    $storage->method('load')->willReturnMap([
      [1, $oldFile],
      [2, $newFile],
    ]);
    $entityTypeManager = $this->createMock(EntityTypeManagerInterface::class);
    $entityTypeManager->method('getStorage')->with('file')->willReturn($storage);

    $fileSystem = $this->createMock(FileSystemInterface::class);
    $fileSystem->method('realpath')->willReturnArgument(0);

    $fileUsage = $this->createMock(FileUsageInterface::class);
    $fileUsage->expects($this->once())->method('delete')->with($oldFile, 'localgov_bus_data', 'custom_data', 'agency');
    $fileUsage->expects($this->once())->method('add')->with($newFile, 'localgov_bus_data', 'custom_data', 'agency');

    $state = $this->createMock(StateInterface::class);
    $logger = $this->createMock(LoggerInterface::class);

    $manager = new CustomCsvManager(
      $configFactory,
      $entityTypeManager,
      $fileSystem,
      $fileUsage,
      $state,
      $logger,
      new CustomCsvValidator(),
    );

    $report = $manager->saveUpload(['agency' => 2], $this->stagingDir);
    $this->assertTrue($report->isValid(), (string) json_encode($report->getErrors()));
  }

  /**
   * An invalid upload saves nothing: no permanent file, no config change.
   *
   * @covers ::saveUpload
   */
  public function testSaveUploadRejectsInvalidUploadWithoutSavingAnything(): void {
    // Missing the required agency_name column.
    $badAgencyPath = $this->tmpDir . '/bad_agency.txt';
    $this->writeCsv($badAgencyPath, [
      ['agency_id'],
      ['A1'],
    ]);

    $config = $this->createMock(ImmutableConfig::class);
    $config->method('get')
      ->willReturnMap([
        ['custom_data.enabled', TRUE],
        ['custom_data.files', []],
      ]);
    $configFactory = $this->createMock(ConfigFactoryInterface::class);
    $configFactory->method('get')->willReturn($config);
    $configFactory->expects($this->never())->method('getEditable');

    $badFile = $this->createMock(FileInterface::class);
    $badFile->method('getFileUri')->willReturn($badAgencyPath);
    $badFile->expects($this->never())->method('setPermanent');
    $badFile->expects($this->never())->method('save');

    $storage = $this->createMock(EntityStorageInterface::class);
    $storage->method('load')->with(9)->willReturn($badFile);
    $entityTypeManager = $this->createMock(EntityTypeManagerInterface::class);
    $entityTypeManager->method('getStorage')->with('file')->willReturn($storage);

    $fileSystem = $this->createMock(FileSystemInterface::class);
    $fileSystem->method('realpath')->willReturnArgument(0);

    $fileUsage = $this->createMock(FileUsageInterface::class);
    $fileUsage->expects($this->never())->method('add');
    $fileUsage->expects($this->never())->method('delete');

    $state = $this->createMock(StateInterface::class);
    $logger = $this->createMock(LoggerInterface::class);

    $manager = new CustomCsvManager(
      $configFactory,
      $entityTypeManager,
      $fileSystem,
      $fileUsage,
      $state,
      $logger,
      new CustomCsvValidator(),
    );

    $report = $manager->saveUpload(['agency' => 9], $this->stagingDir);
    $this->assertFalse($report->isValid());
  }

  /**
   * Removing a stored file deletes its usage and config, then revalidates.
   *
   * @covers ::removeFile
   */
  public function testRemoveFileDeletesFileUsageAndConfigThenRevalidates(): void {
    $config = $this->createMock(ImmutableConfig::class);
    $config->method('get')
      ->willReturnMap([
        ['custom_data.enabled', TRUE],
        // Revalidation (after removal) reads the post-removal state.
        ['custom_data.files', []],
      ]);
    $configFactory = $this->createMock(ConfigFactoryInterface::class);
    $configFactory->method('get')->willReturn($config);

    $editableConfig = $this->createMock(Config::class);
    $editableConfig->method('get')->with('custom_data.files')->willReturn(['stops' => 3]);
    $editableConfig->expects($this->once())->method('set')->with('custom_data.files', [])->willReturnSelf();
    $editableConfig->expects($this->once())->method('save')->with(TRUE);
    $configFactory->method('getEditable')->willReturn($editableConfig);

    $storedFile = $this->createMock(FileInterface::class);
    $storedFile->expects($this->once())->method('delete');

    $storage = $this->createMock(EntityStorageInterface::class);
    $storage->method('load')->with(3)->willReturn($storedFile);
    $entityTypeManager = $this->createMock(EntityTypeManagerInterface::class);
    $entityTypeManager->method('getStorage')->with('file')->willReturn($storage);

    $fileSystem = $this->createMock(FileSystemInterface::class);
    $fileSystem->method('realpath')->willReturnArgument(0);

    $fileUsage = $this->createMock(FileUsageInterface::class);
    $fileUsage->expects($this->once())->method('delete')->with($storedFile, 'localgov_bus_data', 'custom_data', 'stops');

    $state = $this->createMock(StateInterface::class);
    $logger = $this->createMock(LoggerInterface::class);

    $manager = new CustomCsvManager(
      $configFactory,
      $entityTypeManager,
      $fileSystem,
      $fileUsage,
      $state,
      $logger,
      new CustomCsvValidator(),
    );

    $report = $manager->removeFile('stops', $this->stagingDir);
    // After removal, custom_data.files is empty, so nothing remains to
    // validate.
    $this->assertTrue($report->isValid());
  }

}
