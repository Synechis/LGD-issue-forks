<?php

declare(strict_types=1);

namespace Drupal\Tests\localgov_bus_data\Unit\Service;

use PHPUnit\Framework\Attributes\Group;
use Drupal\localgov_bus_data\Service\ValidationReport;
use Drupal\Tests\UnitTestCase;

/**
 * Unit tests for ValidationReport.
 *
 * @coversDefaultClass \Drupal\localgov_bus_data\Service\ValidationReport
 * @group localgov_bus_data
 */
#[Group('localgov_bus_data')]
final class ValidationReportTest extends UnitTestCase {

  /**
   * A freshly constructed report is valid and has no errors.
   *
   * @covers ::isValid
   * @covers ::errorCount
   * @covers ::getErrors
   */
  public function testEmptyReportIsValid(): void {
    $report = new ValidationReport();
    $this->assertTrue($report->isValid());
    $this->assertSame(0, $report->errorCount());
    $this->assertSame([], $report->getErrors());
  }

  /**
   * Adding an error makes the report invalid and records the error fields.
   *
   * @covers ::addError
   * @covers ::isValid
   * @covers ::getErrors
   */
  public function testAddErrorRecordsFieldsAndInvalidatesReport(): void {
    $report = new ValidationReport();
    $report->addError('stops', 3, 'stop_lat', 'stop_lat must be numeric.');

    $this->assertFalse($report->isValid());
    $this->assertSame([
      [
        'file'    => 'stops',
        'line'    => 3,
        'column'  => 'stop_lat',
        'message' => 'stop_lat must be numeric.',
      ],
    ], $report->getErrors());
  }

  /**
   * ErrorCount() counts every recorded error, including repeats in one file.
   *
   * @covers ::errorCount
   */
  public function testErrorCountCountsAllErrors(): void {
    $report = new ValidationReport();
    $report->addError('stops', 2, 'stop_id', 'stop_id is required.');
    $report->addError('stops', 3, 'stop_lat', 'stop_lat must be numeric.');
    $report->addError('routes', 2, 'route_id', 'route_id is required.');

    $this->assertSame(3, $report->errorCount());
  }

  /**
   * FileErrorCount() counts distinct files, not distinct errors.
   *
   * @covers ::fileErrorCount
   */
  public function testFileErrorCountCountsDistinctFiles(): void {
    $report = new ValidationReport();
    $report->addError('stops', 2, 'stop_id', 'stop_id is required.');
    $report->addError('stops', 3, 'stop_lat', 'stop_lat must be numeric.');
    $report->addError('routes', 2, 'route_id', 'route_id is required.');

    $this->assertSame(2, $report->fileErrorCount());
  }

  /**
   * Accepted row counts are recorded and retrieved per file.
   *
   * @covers ::setAcceptedRowCount
   * @covers ::getAcceptedRowCounts
   */
  public function testAcceptedRowCounts(): void {
    $report = new ValidationReport();
    $report->setAcceptedRowCount('stops', 4);
    $report->setAcceptedRowCount('routes', 1);

    $this->assertSame(['stops' => 4, 'routes' => 1], $report->getAcceptedRowCounts());
  }

}
