<?php

declare(strict_types=1);

namespace Drupal\Tests\localgov_bus_data\Unit\Service;

use PHPUnit\Framework\Attributes\Group;
use Drupal\Core\Config\ConfigFactoryInterface;
use Drupal\Core\Config\ImmutableConfig;
use Drupal\localgov_bus_data\Service\GtfsFilter;
use Drupal\Tests\localgov_bus_data\Traits\MakesDatabaseKeepaliveTrait;
use Drupal\Tests\UnitTestCase;
use Psr\Log\LoggerInterface;

/**
 * Tests the chunked shapes filter against the whole-file CLI pass.
 *
 * Since 1.3.0 the shapes rewrite ran inside rewriteStopTimesFinalize(), which
 * meant the batch request that finished the last stop_times chunk also read
 * and rewrote the whole of shapes.txt, the step that exceeded the client's
 * 100 second proxy timeout. The rewrite is now resumable, and the invariant
 * under test is that resuming across many small chunks produces byte-for-byte
 * the same shapes.txt as the single-process pass the CLI runs.
 *
 * Uses real temporary CSV files so fseek(), fgetcsv(), fputcsv() and rename()
 * are exercised without mocking.
 *
 * @coversDefaultClass \Drupal\localgov_bus_data\Service\GtfsFilter
 * @group localgov_bus_data
 */
#[Group('localgov_bus_data')]
final class GtfsFilterShapesChunkedTest extends UnitTestCase {

  use MakesDatabaseKeepaliveTrait;

  /**
   * Temporary directories created by the test, removed on teardown.
   *
   * @var string[]
   */
  private array $tmpDirs = [];

  /**
   * {@inheritdoc}
   */
  protected function tearDown(): void {
    foreach ($this->tmpDirs as $dir) {
      foreach (glob($dir . '/*') ?: [] as $file) {
        if (is_file($file)) {
          unlink($file);
        }
      }
      if (is_dir($dir)) {
        rmdir($dir);
      }
    }
    parent::tearDown();
  }

  /**
   * Creates a GTFS fixture directory.
   *
   * Stops.txt holds one in-area stop and one out-of-area stop; trips T1 and T2
   * call at the in-area stop and reference shapes SH1 and SH3, while trip T9
   * is entirely out of area and references SH2. After filtering, shapes.txt
   * must retain only the SH1 and SH3 points, in their original order.
   *
   * @return string
   *   Absolute path to the new fixture directory.
   */
  private function makeFixture(): string {
    $dir = sys_get_temp_dir() . '/gtfs_shapes_test_' . uniqid('', TRUE);
    $this->assertTrue(
      mkdir($dir, 0750, TRUE),
      'Could not create the fixture directory under ' . sys_get_temp_dir(),
    );
    $this->tmpDirs[] = $dir;

    file_put_contents($dir . '/stops.txt', <<<CSV
    stop_id,stop_name,stop_lat,stop_lon
    S1,Carlisle,54.9,-2.93
    S9,London,51.5,-0.12

    CSV);

    file_put_contents($dir . '/stop_times.txt', <<<CSV
    trip_id,arrival_time,departure_time,stop_id,stop_sequence
    T1,09:00:00,09:00:00,S1,1
    T1,09:10:00,09:10:00,S9,2
    T2,10:00:00,10:00:00,S1,1
    T9,11:00:00,11:00:00,S9,1

    CSV);

    file_put_contents($dir . '/trips.txt', <<<CSV
    route_id,service_id,trip_id,shape_id
    R1,SV1,T1,SH1
    R1,SV1,T2,SH3
    R9,SV1,T9,SH2

    CSV);

    file_put_contents($dir . '/routes.txt', <<<CSV
    route_id,agency_id,route_short_name
    R1,OP1,554
    R9,OP9,999

    CSV);

    file_put_contents($dir . '/shapes.txt', <<<CSV
    shape_id,shape_pt_lat,shape_pt_lon,shape_pt_sequence
    SH1,54.90,-2.93,1
    SH2,51.50,-0.12,1
    SH1,54.91,-2.94,2
    SH2,51.51,-0.13,2
    SH3,54.80,-2.80,1
    SH1,54.92,-2.95,3
    SH3,54.81,-2.81,2

    CSV);

    return $dir;
  }

  /**
   * The shapes.txt content this fixture must reduce to after filtering.
   *
   * @return string
   *   Expected file content.
   */
  private function expectedFilteredShapes(): string {
    return "shape_id,shape_pt_lat,shape_pt_lon,shape_pt_sequence\n"
      . "SH1,54.90,-2.93,1\n"
      . "SH1,54.91,-2.94,2\n"
      . "SH3,54.80,-2.80,1\n"
      . "SH1,54.92,-2.95,3\n"
      . "SH3,54.81,-2.81,2\n";
  }

  /**
   * Builds a GtfsFilter filtering to a Cumberland bounding box.
   *
   * @return \Drupal\localgov_bus_data\Service\GtfsFilter
   *   The configured filter.
   */
  private function makeFilter(): GtfsFilter {
    $config = $this->createMock(ImmutableConfig::class);
    $config->method('get')->willReturnMap([
      ['source.boundary_geojson', NULL],
      ['source.bounding_box', [
        'north' => 55.1,
        'south' => 54.3,
        'east'  => -2.0,
        'west'  => -3.75,
      ],
      ],
    ]);
    $configFactory = $this->createMock(ConfigFactoryInterface::class);
    $configFactory->method('get')->willReturn($config);

    return new GtfsFilter(
      $configFactory,
      $this->createMock(LoggerInterface::class),
      $this->makeKeepalive(),
    );
  }

  /**
   * Runs the geographic filter up to, but not including, the shapes rewrite.
   *
   * The chunked shapes methods read the already-filtered trips.txt, so the
   * earlier phases have to run first.
   *
   * @param \Drupal\localgov_bus_data\Service\GtfsFilter $filter
   *   The filter.
   * @param string $dir
   *   Fixture directory.
   */
  private function filterUpToShapes(GtfsFilter $filter, string $dir): void {
    $filter->collectValidTrips($dir);
    $init = $filter->rewriteStopTimesInit($dir);
    $offset = $init['header_offset'];
    do {
      $result = $filter->rewriteStopTimesChunk($dir, $init['tmp_file'], $offset, 50000);
      $offset = $result['offset'];
    } while (!$result['done']);
    $filter->rewriteStopTimesFinalize($dir);
  }

  /**
   * The chunked pass matches the CLI whole-file pass byte for byte.
   *
   * @covers ::filterShapesInit
   * @covers ::filterShapesChunk
   * @covers ::filterShapesFinalize
   * @covers ::filterByGeography
   */
  public function testChunkedPassMatchesSinglePass(): void {
    // Whole-file pass: the CLI path, which filters shapes in one process.
    $singleDir = $this->makeFixture();
    $this->makeFilter()->filterByGeography($singleDir);

    // Chunked pass: two shape rows per call, as the batch runs it.
    $chunkedDir = $this->makeFixture();
    $filter     = $this->makeFilter();
    $this->filterUpToShapes($filter, $chunkedDir);

    $init = $filter->filterShapesInit($chunkedDir);
    $this->assertFalse($init['skip']);

    $offset   = $init['header_offset'];
    $tmpBytes = $init['tmp_bytes'];
    $kept     = 0;
    $calls    = 0;
    do {
      $result   = $filter->filterShapesChunk($chunkedDir, $init['tmp_file'], $offset, 2, $tmpBytes);
      $offset   = $result['offset'];
      $tmpBytes = $result['tmp_bytes'];
      $kept    += $result['kept'];
      $calls++;
    } while (!$result['done'] && $calls < 20);
    $this->assertTrue($result['done'], 'The chunked pass never reached the end of the file.');
    $filter->filterShapesFinalize($chunkedDir, $init['tmp_file'], $kept);

    $this->assertSame(
      file_get_contents($singleDir . '/shapes.txt'),
      file_get_contents($chunkedDir . '/shapes.txt'),
      'Chunked shape filtering must produce the same file as the single pass.',
    );
    $this->assertSame(
      $this->expectedFilteredShapes(),
      file_get_contents($chunkedDir . '/shapes.txt'),
    );
  }

  /**
   * A seven-row shapes.txt at two rows a call resumes across four calls.
   *
   * The resumption itself is what the 100 second proxy timeout needs: the
   * batch has to be able to stop after any chunk and pick up where it left
   * off in the next HTTP request.
   *
   * @covers ::filterShapesChunk
   */
  public function testChunkResumesAcrossCalls(): void {
    $dir    = $this->makeFixture();
    $filter = $this->makeFilter();
    $this->filterUpToShapes($filter, $dir);

    $init = $filter->filterShapesInit($dir);
    $this->assertFalse($init['skip']);

    $offsets = [];
    $kept    = 0;
    $offset  = $init['header_offset'];
    $calls   = 0;

    $tmpBytes = $init['tmp_bytes'];
    do {
      $result    = $filter->filterShapesChunk($dir, $init['tmp_file'], $offset, 2, $tmpBytes);
      $offsets[] = $result['offset'];
      $kept     += $result['kept'];
      $offset    = $result['offset'];
      $tmpBytes  = $result['tmp_bytes'];
      $calls++;
    } while (!$result['done'] && $calls < 20);

    // 7 data rows at 2 per call: 2, 2, 2, then a short final read.
    $this->assertSame(4, $calls);
    $this->assertTrue($result['done']);
    // Each call must advance past the previous one.
    $this->assertSame($offsets, array_unique($offsets));
    $this->assertSame(5, $kept);

    $this->assertSame(5, $filter->filterShapesFinalize($dir, $init['tmp_file'], $kept));
    $this->assertSame(
      $this->expectedFilteredShapes(),
      file_get_contents($dir . '/shapes.txt'),
    );
  }

  /**
   * A feed without shapes.txt is a silent no-op, not an error.
   *
   * @covers ::filterShapesInit
   */
  public function testMissingShapesFileIsSilentNoOp(): void {
    $dir = $this->makeFixture();
    unlink($dir . '/shapes.txt');

    $filter = $this->makeFilter();
    $this->filterUpToShapes($filter, $dir);

    $init = $filter->filterShapesInit($dir);

    $this->assertTrue($init['skip']);
    $this->assertSame('', $init['tmp_file']);
    $this->assertFileDoesNotExist($dir . '/shapes.txt');
  }

  /**
   * A feed without shapes.txt does not break the whole-file CLI pass either.
   *
   * @covers ::filterByGeography
   */
  public function testMissingShapesFileDoesNotBreakSinglePass(): void {
    $dir = $this->makeFixture();
    unlink($dir . '/shapes.txt');

    $counts = $this->makeFilter()->filterByGeography($dir);

    $this->assertSame(3, $counts['stop_times']);
    $this->assertFileDoesNotExist($dir . '/shapes.txt');
  }

  /**
   * A trips.txt without a shape_id column leaves shapes.txt untouched.
   *
   * An empty shape ID set means two different things. If trips.txt has the
   * column and none of the retained trips fill it, dropping every point is
   * right. If the column is absent the feed does not use shapes at all, and
   * reducing shapes.txt to its header would destroy geometry the feed never
   * said was unused.
   *
   * @covers ::filterShapesInit
   */
  public function testTripsWithoutShapeIdColumnLeavesShapesUntouched(): void {
    $dir = $this->makeFixture();
    file_put_contents($dir . '/trips.txt', <<<CSV
    route_id,service_id,trip_id
    R1,SV1,T1
    R1,SV1,T2
    R9,SV1,T9

    CSV);
    $before = (string) file_get_contents($dir . '/shapes.txt');

    $filter = $this->makeFilter();
    $this->filterUpToShapes($filter, $dir);

    $init = $filter->filterShapesInit($dir);

    $this->assertTrue($init['skip']);
    $this->assertSame($before, file_get_contents($dir . '/shapes.txt'));
  }

  /**
   * With no geographic filter configured, shapes.txt is left alone.
   *
   * The CLI path returns early on the null sentinel and never reaches the
   * shapes rewrite. The batch path runs the shapes operation unconditionally,
   * so the skip has to be decided here or the two paths produce different
   * files from the same feed.
   *
   * @covers ::filterShapesInit
   */
  public function testNoGeographicFilterLeavesShapesUntouched(): void {
    $dir = $this->makeFixture();
    $before = (string) file_get_contents($dir . '/shapes.txt');

    // No bounding box and no GeoJSON: collectValidTrips writes the sentinel.
    $config = $this->createMock(ImmutableConfig::class);
    $config->method('get')->willReturn(NULL);
    $configFactory = $this->createMock(ConfigFactoryInterface::class);
    $configFactory->method('get')->willReturn($config);
    $filter = new GtfsFilter(
      $configFactory,
      $this->createMock(LoggerInterface::class),
      $this->makeKeepalive(),
    );

    $filter->collectValidTrips($dir);
    $this->assertSame('null', file_get_contents($dir . '/valid_trip_ids.json'));

    $init = $filter->filterShapesInit($dir);

    $this->assertTrue($init['skip']);
    $this->assertSame($before, file_get_contents($dir . '/shapes.txt'));
  }

  /**
   * Replaying a chunk whose progress was never recorded does not duplicate.
   *
   * The batch persists its sandbox at the end of the request. A worker killed
   * after a chunk wrote rows but before that happened replays the chunk from
   * the same byte offset, which must not append the rows a second time.
   *
   * @covers ::filterShapesChunk
   */
  public function testReplayedChunkDoesNotDuplicateRows(): void {
    $dir    = $this->makeFixture();
    $filter = $this->makeFilter();
    $this->filterUpToShapes($filter, $dir);

    $init = $filter->filterShapesInit($dir);

    // Run a chunk, then discard its result as a killed request would.
    $lost = $filter->filterShapesChunk($dir, $init['tmp_file'], $init['header_offset'], 4, $init['tmp_bytes']);
    $this->assertGreaterThan(0, $lost['kept']);

    // Replay from the last recorded position, which is still the header.
    $offset   = $init['header_offset'];
    $tmpBytes = $init['tmp_bytes'];
    $kept     = 0;
    $calls    = 0;
    do {
      $result   = $filter->filterShapesChunk($dir, $init['tmp_file'], $offset, 4, $tmpBytes);
      $offset   = $result['offset'];
      $tmpBytes = $result['tmp_bytes'];
      $kept    += $result['kept'];
      $calls++;
    } while (!$result['done'] && $calls < 20);

    $filter->filterShapesFinalize($dir, $init['tmp_file'], $kept);

    $this->assertSame(
      $this->expectedFilteredShapes(),
      file_get_contents($dir . '/shapes.txt'),
      'A replayed chunk must not append its rows twice.',
    );
  }

  /**
   * A shapes.txt that becomes unreadable mid-run fails loudly.
   *
   * Reporting done would make finalize rename a header-only temp file over
   * real geometry and call it success.
   *
   * @covers ::filterShapesChunk
   */
  public function testChunkThrowsWhenShapesBecomeUnreadable(): void {
    $dir    = $this->makeFixture();
    $filter = $this->makeFilter();
    $this->filterUpToShapes($filter, $dir);

    $init = $filter->filterShapesInit($dir);

    // Simulate the file being replaced mid-run by one with no shape_id.
    file_put_contents($dir . '/shapes.txt', "a,b,c\n1,2,3\n");

    $this->expectException(\RuntimeException::class);
    $this->expectExceptionMessage('became unreadable');
    $filter->filterShapesChunk($dir, $init['tmp_file'], $init['header_offset'], 2, $init['tmp_bytes']);
  }

}
