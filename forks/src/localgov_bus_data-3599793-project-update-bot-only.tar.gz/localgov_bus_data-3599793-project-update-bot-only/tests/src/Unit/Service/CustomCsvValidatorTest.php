<?php

declare(strict_types=1);

namespace Drupal\Tests\localgov_bus_data\Unit\Service;

use PHPUnit\Framework\Attributes\Group;
use Drupal\localgov_bus_data\Service\ValidationReport;
use Drupal\localgov_bus_data\Service\CustomCsvValidator;
use Drupal\Tests\UnitTestCase;

/**
 * Unit tests for CustomCsvValidator.
 *
 * Uses real temporary CSV files (custom uploads and a separate staging
 * directory) so that file I/O and CSV-parsing edge cases are exercised
 * without any filesystem mocking, following the fixture approach in
 * GtfsFilterTest.
 *
 * @coversDefaultClass \Drupal\localgov_bus_data\Service\CustomCsvValidator
 * @group localgov_bus_data
 */
#[Group('localgov_bus_data')]
final class CustomCsvValidatorTest extends UnitTestCase {

  /**
   * The calendar.txt header row, reused across several fixtures.
   *
   * @var array<int, string>
   */
  private const CALENDAR_HEADER = [
    'service_id', 'monday', 'tuesday', 'wednesday', 'thursday',
    'friday', 'saturday', 'sunday', 'start_date', 'end_date',
  ];

  /**
   * Temporary directory for custom CSV fixtures.
   *
   * @var string
   */
  private string $tmpDir;

  /**
   * Temporary directory standing in for the GTFS staging directory.
   *
   * @var string
   */
  private string $stagingDir;

  /**
   * The validator under test.
   *
   * @var \Drupal\localgov_bus_data\Service\CustomCsvValidator
   */
  private CustomCsvValidator $validator;

  /**
   * {@inheritdoc}
   */
  protected function setUp(): void {
    parent::setUp();
    $this->tmpDir = sys_get_temp_dir() . '/custom_csv_validator_test_' . uniqid();
    mkdir($this->tmpDir, 0750, TRUE);
    $this->stagingDir = $this->tmpDir . '/staging';
    mkdir($this->stagingDir, 0750, TRUE);
    $this->validator = new CustomCsvValidator();
  }

  /**
   * {@inheritdoc}
   */
  protected function tearDown(): void {
    $this->removeDir($this->tmpDir);
    parent::tearDown();
  }

  /**
   * Recursively removes a directory tree.
   */
  private function removeDir(string $dir): void {
    if (!is_dir($dir)) {
      return;
    }
    foreach (glob($dir . '/*') ?: [] as $path) {
      is_dir($path) ? $this->removeDir($path) : unlink($path);
    }
    rmdir($dir);
  }

  /**
   * Writes rows to a CSV file and returns its absolute path.
   *
   * @param string $dir
   *   Directory to write into.
   * @param string $filename
   *   Filename, e.g. "stops.txt".
   * @param array<int, array<int, string>> $rows
   *   Rows including the header.
   *
   * @return string
   *   Absolute path to the written file.
   */
  private function writeCsv(string $dir, string $filename, array $rows): string {
    $path = $dir . '/' . $filename;
    $fh = fopen($path, 'w');
    assert($fh !== FALSE);
    foreach ($rows as $row) {
      fputcsv($fh, $row, escape: '');
    }
    fclose($fh);
    return $path;
  }

  /**
   * Writes a staged GTFS file (in $this->stagingDir).
   *
   * @param string $fileKey
   *   File key, e.g. "stops".
   * @param array<int, array<int, string>> $rows
   *   Rows including the header.
   */
  private function writeStaged(string $fileKey, array $rows): void {
    $this->writeCsv($this->stagingDir, CustomCsvValidator::FILE_NAMES[$fileKey], $rows);
  }

  /**
   * Writes a custom file (in $this->tmpDir) and returns the files map entry.
   *
   * @param string $fileKey
   *   File key, e.g. "stops".
   * @param array<int, array<int, string>> $rows
   *   Rows including the header.
   *
   * @return array<string, string>
   *   A one-entry files map suitable for merging into validate()'s $files
   *   argument.
   */
  private function customFile(string $fileKey, array $rows): array {
    return [$fileKey => $this->writeCsv($this->tmpDir, CustomCsvValidator::FILE_NAMES[$fileKey], $rows)];
  }

  /**
   * Builds a minimal, internally consistent custom set (no staged refs).
   *
   * Agency A1 -> route R1 -> trip T1 (calendar C1) -> stop_times on S1, S2.
   *
   * @return array<string, string>
   *   Files map for validate().
   */
  private function buildValidSelfContainedSet(): array {
    $files = [];
    $files += $this->customFile('agency', [
      ['agency_id', 'agency_name'],
      ['A1', 'Custom Agency'],
    ]);
    $files += $this->customFile('routes', [
      ['route_id', 'route_short_name', 'agency_id', 'route_type'],
      ['R1', '99', 'A1', '3'],
    ]);
    $files += $this->customFile('stops', [
      ['stop_id', 'stop_name', 'stop_lat', 'stop_lon'],
      ['S1', 'Custom Stop 1', '54.90', '-3.50'],
      ['S2', 'Custom Stop 2', '54.91', '-3.51'],
    ]);
    $files += $this->customFile('calendar', [
      self::CALENDAR_HEADER,
      ['C1', '1', '1', '1', '1', '1', '0', '0', '20260101', '20261231'],
    ]);
    $files += $this->customFile('trips', [
      ['trip_id', 'route_id', 'service_id'],
      ['T1', 'R1', 'C1'],
    ]);
    $files += $this->customFile('stop_times', [
      ['trip_id', 'arrival_time', 'departure_time', 'stop_id', 'stop_sequence'],
      ['T1', '08:00:00', '08:00:00', 'S1', '0'],
      ['T1', '08:10:00', '08:10:00', 'S2', '1'],
    ]);
    return $files;
  }

  /**
   * @covers ::validate
   */
  public function testValidSelfContainedSetPasses(): void {
    $report = $this->validator->validate($this->buildValidSelfContainedSet(), $this->stagingDir);
    $this->assertTrue($report->isValid(), (string) json_encode($report->getErrors()));
    $this->assertSame(1, $report->getAcceptedRowCounts()['agency']);
    $this->assertSame(2, $report->getAcceptedRowCounts()['stops']);
    $this->assertSame(2, $report->getAcceptedRowCounts()['stop_times']);
  }

  /**
   * A custom trip may reference staged routes, calendars, and stops.
   *
   * @covers ::validate
   */
  public function testValidSetReferencingStagedIdsPasses(): void {
    $this->writeStaged('routes', [
      ['route_id', 'route_short_name', 'agency_id', 'route_type'],
      ['STAGED_R1', '1', 'STAGED_A1', '3'],
    ]);
    $this->writeStaged('stops', [
      ['stop_id', 'stop_name', 'stop_lat', 'stop_lon'],
      ['STAGED_S1', 'Staged Stop 1', '54.90', '-3.50'],
      ['STAGED_S2', 'Staged Stop 2', '54.91', '-3.51'],
    ]);
    $this->writeStaged('calendar', [
      self::CALENDAR_HEADER,
      ['STAGED_C1', '1', '1', '1', '1', '1', '0', '0', '20260101', '20261231'],
    ]);

    $files = $this->customFile('trips', [
      ['trip_id', 'route_id', 'service_id'],
      ['T1', 'STAGED_R1', 'STAGED_C1'],
    ]);
    $files += $this->customFile('stop_times', [
      ['trip_id', 'arrival_time', 'departure_time', 'stop_id', 'stop_sequence'],
      ['T1', '08:00:00', '08:00:00', 'STAGED_S1', '0'],
      ['T1', '08:10:00', '08:10:00', 'STAGED_S2', '1'],
    ]);

    $report = $this->validator->validate($files, $this->stagingDir);
    $this->assertTrue($report->isValid(), (string) json_encode($report->getErrors()));
  }

  /**
   * @covers ::validate
   */
  public function testMissingRequiredColumnIsRejected(): void {
    $files = $this->customFile('stops', [
      ['stop_id', 'stop_name', 'stop_lat'],
      ['S1', 'Custom Stop', '54.90'],
    ]);
    $report = $this->validator->validate($files, $this->stagingDir);
    $this->assertFalse($report->isValid());
    $this->assertErrorContains($report, 'stops', 'stop_lon', 'Missing required column');
  }

  /**
   * @covers ::validate
   */
  public function testUnsupportedExtraColumnIsRejected(): void {
    $this->writeStaged('stops', [
      ['stop_id', 'stop_name', 'stop_lat', 'stop_lon'],
      ['STAGED_S1', 'Staged Stop', '54.90', '-3.50'],
    ]);
    $files = $this->customFile('stops', [
      ['stop_id', 'stop_name', 'stop_lat', 'stop_lon', 'not_a_real_column'],
      ['S1', 'Custom Stop', '54.90', '-3.50', 'oops'],
    ]);
    $report = $this->validator->validate($files, $this->stagingDir);
    $this->assertFalse($report->isValid());
    $this->assertErrorContains($report, 'stops', 'not_a_real_column', 'does not exist in the staged file');
  }

  /**
   * @covers ::validate
   */
  public function testEmptyRequiredCellIsRejected(): void {
    $files = $this->customFile('agency', [
      ['agency_id', 'agency_name'],
      ['A1', ''],
    ]);
    $report = $this->validator->validate($files, $this->stagingDir);
    $this->assertFalse($report->isValid());
    $this->assertErrorContains($report, 'agency', 'agency_name', 'required');
  }

  /**
   * @covers ::validate
   */
  public function testBadArrivalTimeIsRejected(): void {
    $files = $this->buildValidSelfContainedSet();
    $files['stop_times'] = $this->writeCsv($this->tmpDir, 'stop_times.txt', [
      ['trip_id', 'arrival_time', 'departure_time', 'stop_id', 'stop_sequence'],
      ['T1', '48:00:00', '08:00:00', 'S1', '0'],
    ]);
    $report = $this->validator->validate($files, $this->stagingDir);
    $this->assertFalse($report->isValid());
    $this->assertErrorContains($report, 'stop_times', 'arrival_time', 'must match H:MM:SS');
  }

  /**
   * @covers ::validate
   */
  public function testBadStartDateIsRejected(): void {
    $files = $this->buildValidSelfContainedSet();
    $files['calendar'] = $this->writeCsv($this->tmpDir, 'calendar.txt', [
      self::CALENDAR_HEADER,
      ['C1', '1', '1', '1', '1', '1', '0', '0', '20260231', '20261231'],
    ]);
    $report = $this->validator->validate($files, $this->stagingDir);
    $this->assertFalse($report->isValid());
    $this->assertErrorContains($report, 'calendar', 'start_date', 'valid YYYYMMDD date');
  }

  /**
   * @covers ::validate
   */
  public function testEndDateBeforeStartDateIsRejected(): void {
    $files = $this->buildValidSelfContainedSet();
    $files['calendar'] = $this->writeCsv($this->tmpDir, 'calendar.txt', [
      self::CALENDAR_HEADER,
      ['C1', '1', '1', '1', '1', '1', '0', '0', '20261231', '20260101'],
    ]);
    $report = $this->validator->validate($files, $this->stagingDir);
    $this->assertFalse($report->isValid());
    $this->assertErrorContains($report, 'calendar', 'end_date', 'not be earlier than start_date');
  }

  /**
   * @covers ::validate
   */
  public function testBadLatitudeIsRejected(): void {
    $files = $this->customFile('stops', [
      ['stop_id', 'stop_name', 'stop_lat', 'stop_lon'],
      ['S1', 'Custom Stop', '95.00', '-3.50'],
    ]);
    $report = $this->validator->validate($files, $this->stagingDir);
    $this->assertFalse($report->isValid());
    $this->assertErrorContains($report, 'stops', 'stop_lat', 'numeric between -90 and 90');
  }

  /**
   * @covers ::validate
   */
  public function testBadLongitudeIsRejected(): void {
    $files = $this->customFile('stops', [
      ['stop_id', 'stop_name', 'stop_lat', 'stop_lon'],
      ['S1', 'Custom Stop', '54.90', '200.00'],
    ]);
    $report = $this->validator->validate($files, $this->stagingDir);
    $this->assertFalse($report->isValid());
    $this->assertErrorContains($report, 'stops', 'stop_lon', 'numeric between -180 and 180');
  }

  /**
   * @covers ::validate
   */
  public function testBadDayFlagIsRejected(): void {
    $files = $this->customFile('calendar', [
      self::CALENDAR_HEADER,
      ['C1', '2', '1', '1', '1', '1', '0', '0', '20260101', '20261231'],
    ]);
    $report = $this->validator->validate($files, $this->stagingDir);
    $this->assertFalse($report->isValid());
    $this->assertErrorContains($report, 'calendar', 'monday', 'must be 0 or 1');
  }

  /**
   * @covers ::validate
   */
  public function testBadDirectionIdIsRejected(): void {
    $files = $this->customFile('trips', [
      ['trip_id', 'route_id', 'service_id', 'direction_id'],
      ['T1', 'R1', 'C1', '2'],
    ]);
    $report = $this->validator->validate($files, $this->stagingDir);
    $this->assertFalse($report->isValid());
    $this->assertErrorContains($report, 'trips', 'direction_id', 'must be 0 or 1');
  }

  /**
   * @covers ::validate
   */
  public function testUnknownRouteIdIsRejected(): void {
    $files = $this->customFile('trips', [
      ['trip_id', 'route_id', 'service_id'],
      ['T1', 'NOPE', 'C1'],
    ]);
    $report = $this->validator->validate($files, $this->stagingDir);
    $this->assertFalse($report->isValid());
    $this->assertErrorContains($report, 'trips', 'route_id', 'does not exist');
  }

  /**
   * @covers ::validate
   */
  public function testUnknownServiceIdIsRejected(): void {
    $files = $this->customFile('trips', [
      ['trip_id', 'route_id', 'service_id'],
      ['T1', 'R1', 'NOPE'],
    ]);
    $report = $this->validator->validate($files, $this->stagingDir);
    $this->assertFalse($report->isValid());
    $this->assertErrorContains($report, 'trips', 'service_id', 'does not exist');
  }

  /**
   * @covers ::validate
   */
  public function testUnknownTripIdIsRejected(): void {
    $files = $this->customFile('stop_times', [
      ['trip_id', 'arrival_time', 'departure_time', 'stop_id', 'stop_sequence'],
      ['NOPE', '08:00:00', '08:00:00', 'S1', '0'],
    ]);
    $report = $this->validator->validate($files, $this->stagingDir);
    $this->assertFalse($report->isValid());
    $this->assertErrorContains($report, 'stop_times', 'trip_id', 'does not exist');
  }

  /**
   * @covers ::validate
   */
  public function testUnknownStopIdIsRejected(): void {
    $files = $this->buildValidSelfContainedSet();
    $files['stop_times'] = $this->writeCsv($this->tmpDir, 'stop_times.txt', [
      ['trip_id', 'arrival_time', 'departure_time', 'stop_id', 'stop_sequence'],
      ['T1', '08:00:00', '08:00:00', 'NOPE', '0'],
    ]);
    $report = $this->validator->validate($files, $this->stagingDir);
    $this->assertFalse($report->isValid());
    $this->assertErrorContains($report, 'stop_times', 'stop_id', 'does not exist');
  }

  /**
   * A custom trip referencing a custom route passes validation.
   *
   * @covers ::validate
   */
  public function testCustomTripReferencingCustomRoutePasses(): void {
    $report = $this->validator->validate($this->buildValidSelfContainedSet(), $this->stagingDir);
    $this->assertTrue($report->isValid(), (string) json_encode($report->getErrors()));
  }

  /**
   * @covers ::validate
   */
  public function testIdCollisionWithStagedDataIsRejected(): void {
    $this->writeStaged('stops', [
      ['stop_id', 'stop_name', 'stop_lat', 'stop_lon'],
      ['S1', 'Staged Stop', '54.90', '-3.50'],
    ]);
    $files = $this->customFile('stops', [
      ['stop_id', 'stop_name', 'stop_lat', 'stop_lon'],
      ['S1', 'Custom Stop', '54.91', '-3.51'],
    ]);
    $report = $this->validator->validate($files, $this->stagingDir);
    $this->assertFalse($report->isValid());
    $this->assertErrorContains($report, 'stops', 'stop_id', 'collides with staged data');
  }

  /**
   * @covers ::validate
   */
  public function testDuplicateWithinCustomSetIsRejected(): void {
    $files = $this->customFile('stops', [
      ['stop_id', 'stop_name', 'stop_lat', 'stop_lon'],
      ['S1', 'Custom Stop 1', '54.90', '-3.50'],
      ['S1', 'Custom Stop 1 Again', '54.91', '-3.51'],
    ]);
    $report = $this->validator->validate($files, $this->stagingDir);
    $this->assertFalse($report->isValid());
    $this->assertErrorContains($report, 'stops', 'stop_id', 'Duplicate stop_id');
  }

  /**
   * @covers ::validate
   */
  public function testTripIdStopSequenceCollisionIsRejected(): void {
    $files = $this->buildValidSelfContainedSet();
    $files['stop_times'] = $this->writeCsv($this->tmpDir, 'stop_times.txt', [
      ['trip_id', 'arrival_time', 'departure_time', 'stop_id', 'stop_sequence'],
      ['T1', '08:00:00', '08:00:00', 'S1', '0'],
      ['T1', '08:10:00', '08:10:00', 'S2', '0'],
    ]);
    $report = $this->validator->validate($files, $this->stagingDir);
    $this->assertFalse($report->isValid());
    $this->assertErrorContains($report, 'stop_times', 'stop_sequence', 'Duplicate (trip_id, stop_sequence)');
  }

  /**
   * @covers ::validate
   */
  public function testTripIdStopSequenceCollisionWithStagedDataIsRejected(): void {
    $this->writeStaged('stop_times', [
      ['trip_id', 'arrival_time', 'departure_time', 'stop_id', 'stop_sequence'],
      ['T1', '08:00:00', '08:00:00', 'STAGED_S1', '0'],
    ]);
    $files = $this->buildValidSelfContainedSet();
    $files['stop_times'] = $this->writeCsv($this->tmpDir, 'stop_times.txt', [
      ['trip_id', 'arrival_time', 'departure_time', 'stop_id', 'stop_sequence'],
      ['T1', '08:00:00', '08:00:00', 'S1', '0'],
    ]);
    $report = $this->validator->validate($files, $this->stagingDir);
    $this->assertFalse($report->isValid());
    $this->assertErrorContains($report, 'stop_times', 'stop_sequence', 'collides with staged data');
  }

  /**
   * A header-only file (no data rows) is valid, with zero accepted rows.
   *
   * @covers ::validate
   */
  public function testHeaderOnlyFileIsValid(): void {
    $files = $this->customFile('agency', [
      ['agency_id', 'agency_name'],
    ]);
    $report = $this->validator->validate($files, $this->stagingDir);
    $this->assertTrue($report->isValid(), (string) json_encode($report->getErrors()));
    $this->assertSame(0, $report->getAcceptedRowCounts()['agency']);
  }

  /**
   * @covers ::validate
   */
  public function testFileWithNoHeaderIsRejected(): void {
    $path = $this->tmpDir . '/agency.txt';
    file_put_contents($path, '');
    $report = $this->validator->validate(['agency' => $path], $this->stagingDir);
    $this->assertFalse($report->isValid());
    $this->assertErrorContains($report, 'agency', NULL, 'no header row');
  }

  /**
   * A UTF-8 BOM on the header row is stripped before header matching.
   *
   * @covers ::validate
   */
  public function testUtf8BomOnHeaderIsStripped(): void {
    $path = $this->tmpDir . '/agency.txt';
    file_put_contents($path, "\xEF\xBB\xBFagency_id,agency_name\nA1,Custom Agency\n");
    $report = $this->validator->validate(['agency' => $path], $this->stagingDir);
    $this->assertTrue($report->isValid(), (string) json_encode($report->getErrors()));
  }

  /**
   * Blank lines are tolerated and skipped without error.
   *
   * @covers ::validate
   */
  public function testBlankLinesAreTolerated(): void {
    $path = $this->tmpDir . '/agency.txt';
    file_put_contents($path, "agency_id,agency_name\n\nA1,Custom Agency\n\n");
    $report = $this->validator->validate(['agency' => $path], $this->stagingDir);
    $this->assertTrue($report->isValid(), (string) json_encode($report->getErrors()));
    $this->assertSame(1, $report->getAcceptedRowCounts()['agency']);
  }

  /**
   * A semicolon-delimited header is rejected with a single named error.
   *
   * Rather than a cascade of missing-column errors.
   *
   * @covers ::validate
   */
  public function testSemicolonDelimitedFileIsRejected(): void {
    $path = $this->tmpDir . '/agency.txt';
    file_put_contents($path, "agency_id;agency_name\nA1;Custom Agency\n");
    $report = $this->validator->validate(['agency' => $path], $this->stagingDir);
    $this->assertFalse($report->isValid());
    $this->assertErrorContains($report, 'agency', NULL, 'semicolon-delimited');
    $this->assertCount(1, $report->getErrors());
  }

  /**
   * A duplicated header column is rejected with a single named error.
   *
   * The validator maps columns via array_flip(), which resolves a
   * duplicate to the last occurrence, while CustomCsvManager's merge maps
   * columns via array_search() (first occurrence wins). Left undetected,
   * a file with a duplicated column would validate one cell and merge
   * the other, bypassing reject-with-report.
   *
   * @covers ::validate
   */
  public function testDuplicateHeaderColumnIsRejected(): void {
    $path = $this->tmpDir . '/agency.txt';
    file_put_contents($path, "agency_id,agency_name,agency_id\nA1,Custom Agency,A1\n");
    $report = $this->validator->validate(['agency' => $path], $this->stagingDir);
    $this->assertFalse($report->isValid());
    $this->assertErrorContains($report, 'agency', NULL, 'duplicate column names');
    $this->assertCount(1, $report->getErrors());
  }

  /**
   * A duplicate introduced only by header-cell trimming is also rejected.
   *
   * The normaliseHeader() call trims each cell before the duplicate check
   * runs, so a padded column name that only matches an unpadded one after
   * trimming must still be caught.
   *
   * @covers ::validate
   */
  public function testDuplicateHeaderColumnAfterTrimmingIsRejected(): void {
    $path = $this->tmpDir . '/agency.txt';
    file_put_contents($path, "agency_id,agency_name, agency_id \nA1,Custom Agency,A1\n");
    $report = $this->validator->validate(['agency' => $path], $this->stagingDir);
    $this->assertFalse($report->isValid());
    $this->assertErrorContains($report, 'agency', NULL, 'duplicate column names');
    $this->assertCount(1, $report->getErrors());
  }

  /**
   * @covers ::validate
   */
  public function testDepartureBeforeArrivalIsRejected(): void {
    $files = $this->buildValidSelfContainedSet();
    $files['stop_times'] = $this->writeCsv($this->tmpDir, 'stop_times.txt', [
      ['trip_id', 'arrival_time', 'departure_time', 'stop_id', 'stop_sequence'],
      ['T1', '08:10:00', '08:00:00', 'S1', '0'],
    ]);
    $report = $this->validator->validate($files, $this->stagingDir);
    $this->assertFalse($report->isValid());
    $this->assertErrorContains($report, 'stop_times', 'departure_time', 'not be earlier than arrival_time');
  }

  /**
   * @covers ::validate
   */
  public function testTimesDecreasingAlongTripIsRejected(): void {
    $files = $this->buildValidSelfContainedSet();
    $files['stop_times'] = $this->writeCsv($this->tmpDir, 'stop_times.txt', [
      ['trip_id', 'arrival_time', 'departure_time', 'stop_id', 'stop_sequence'],
      ['T1', '08:10:00', '08:10:00', 'S1', '0'],
      ['T1', '08:00:00', '08:00:00', 'S2', '1'],
    ]);
    $report = $this->validator->validate($files, $this->stagingDir);
    $this->assertFalse($report->isValid());
    $this->assertErrorContains($report, 'stop_times', 'stop_sequence', 'Times decrease along trip');
  }

  /**
   * Each file's primary key is required; an empty cell is a named error.
   *
   * @covers ::validate
   */
  public function testRequiredPrimaryKeyCellIsRejectedForEveryFile(): void {
    $report = $this->validator->validate($this->customFile('agency', [
      ['agency_id', 'agency_name'],
      ['', 'Custom Agency'],
    ]), $this->stagingDir);
    $this->assertErrorContains($report, 'agency', 'agency_id', 'agency_id is required');

    $report = $this->validator->validate($this->customFile('routes', [
      ['route_id', 'route_short_name', 'agency_id', 'route_type'],
      ['', '1', 'A1', '3'],
    ]), $this->stagingDir);
    $this->assertErrorContains($report, 'routes', 'route_id', 'route_id is required');

    $report = $this->validator->validate($this->customFile('trips', [
      ['trip_id', 'route_id', 'service_id'],
      ['', 'R1', 'C1'],
    ]), $this->stagingDir);
    $this->assertErrorContains($report, 'trips', 'trip_id', 'trip_id is required');

    $report = $this->validator->validate($this->customFile('calendar', [
      self::CALENDAR_HEADER,
      ['', '1', '1', '1', '1', '1', '0', '0', '20260101', '20261231'],
    ]), $this->stagingDir);
    $this->assertErrorContains($report, 'calendar', 'service_id', 'service_id is required');

    $report = $this->validator->validate($this->customFile('stop_times', [
      ['trip_id', 'arrival_time', 'departure_time', 'stop_id', 'stop_sequence'],
      ['T1', '08:00:00', '08:00:00', '', '0'],
    ]), $this->stagingDir);
    $this->assertErrorContains($report, 'stop_times', 'stop_id', 'stop_id is required');
  }

  /**
   * @covers ::validate
   */
  public function testMissingRouteTypeIsRejected(): void {
    $files = $this->customFile('routes', [
      ['route_id', 'route_short_name', 'agency_id', 'route_type'],
      ['R1', '1', 'A1', ''],
    ]);
    $report = $this->validator->validate($files, $this->stagingDir);
    $this->assertFalse($report->isValid());
    $this->assertErrorContains($report, 'routes', 'route_type', 'must be a non-negative integer');
  }

  /**
   * @covers ::validate
   */
  public function testNegativeRouteTypeIsRejected(): void {
    $files = $this->customFile('routes', [
      ['route_id', 'route_short_name', 'agency_id', 'route_type'],
      ['R1', '1', 'A1', '-1'],
    ]);
    $report = $this->validator->validate($files, $this->stagingDir);
    $this->assertFalse($report->isValid());
    $this->assertErrorContains($report, 'routes', 'route_type', 'must be a non-negative integer');
  }

  /**
   * @covers ::validate
   */
  public function testBadWheelchairBoardingIsRejected(): void {
    $files = $this->customFile('stops', [
      ['stop_id', 'stop_name', 'stop_lat', 'stop_lon', 'wheelchair_boarding'],
      ['S1', 'Custom Stop', '54.90', '-3.50', '3'],
    ]);
    $report = $this->validator->validate($files, $this->stagingDir);
    $this->assertFalse($report->isValid());
    $this->assertErrorContains($report, 'stops', 'wheelchair_boarding', 'must be 0, 1, or 2');
  }

  /**
   * @covers ::validate
   */
  public function testTripHeadsignTooLongIsRejected(): void {
    $files = $this->customFile('trips', [
      ['trip_id', 'route_id', 'service_id', 'trip_headsign'],
      ['T1', 'R1', 'C1', str_repeat('x', 256)],
    ]);
    $report = $this->validator->validate($files, $this->stagingDir);
    $this->assertFalse($report->isValid());
    $this->assertErrorContains($report, 'trips', 'trip_headsign', 'at most 255 characters');
  }

  /**
   * @covers ::validate
   */
  public function testNonNumericStopSequenceIsRejected(): void {
    $files = $this->customFile('stop_times', [
      ['trip_id', 'arrival_time', 'departure_time', 'stop_id', 'stop_sequence'],
      ['T1', '08:00:00', '08:00:00', 'S1', 'abc'],
    ]);
    $report = $this->validator->validate($files, $this->stagingDir);
    $this->assertFalse($report->isValid());
    $this->assertErrorContains($report, 'stop_times', 'stop_sequence', 'must be a non-negative integer');
  }

  /**
   * @covers ::validate
   */
  public function testNegativeStopSequenceIsRejected(): void {
    $files = $this->customFile('stop_times', [
      ['trip_id', 'arrival_time', 'departure_time', 'stop_id', 'stop_sequence'],
      ['T1', '08:00:00', '08:00:00', 'S1', '-1'],
    ]);
    $report = $this->validator->validate($files, $this->stagingDir);
    $this->assertFalse($report->isValid());
    $this->assertErrorContains($report, 'stop_times', 'stop_sequence', 'must be a non-negative integer');
  }

  /**
   * An unreadable file path (e.g. a directory) is rejected, not fatal.
   *
   * @covers ::validate
   */
  public function testUnreadableFileIsRejected(): void {
    $dirAsFile = $this->tmpDir . '/not_really_a_file';
    mkdir($dirAsFile);
    $report = $this->validator->validate(['agency' => $dirAsFile], $this->stagingDir);
    $this->assertFalse($report->isValid());
  }

  /**
   * Accepted row counts omit files that failed structural parsing.
   *
   * @covers ::validate
   */
  public function testAcceptedRowCountsExcludeStructurallyRejectedFiles(): void {
    $files = $this->customFile('agency', [
      ['agency_id', 'agency_name'],
      ['A1', 'Custom Agency'],
    ]);
    // stops.txt is missing a required column, so it is structurally rejected.
    $files += $this->customFile('stops', [
      ['stop_id', 'stop_name', 'stop_lat'],
      ['S1', 'Custom Stop', '54.90'],
    ]);
    $report = $this->validator->validate($files, $this->stagingDir);
    $this->assertFalse($report->isValid());
    $counts = $report->getAcceptedRowCounts();
    $this->assertArrayHasKey('agency', $counts);
    $this->assertArrayNotHasKey('stops', $counts);
  }

  /**
   * Errors across multiple files in one upload are all aggregated.
   *
   * @covers ::validate
   */
  public function testCombinedFailureAcrossMultipleFilesAggregatesErrors(): void {
    $files = $this->customFile('agency', [
      ['agency_id', 'agency_name'],
      ['A1', ''],
    ]);
    $files += $this->customFile('stops', [
      ['stop_id', 'stop_name', 'stop_lat', 'stop_lon'],
      ['S1', 'Custom Stop', '95.00', '-3.50'],
    ]);
    $report = $this->validator->validate($files, $this->stagingDir);
    $this->assertFalse($report->isValid());
    $this->assertSame(2, $report->fileErrorCount());
    $this->assertErrorContains($report, 'agency', 'agency_name', 'required');
    $this->assertErrorContains($report, 'stops', 'stop_lat', 'numeric between -90 and 90');
  }

  /**
   * When no staged counterpart exists, extra custom columns are accepted.
   *
   * @covers ::validate
   */
  public function testExtraColumnAcceptedWhenNoStagedCounterpartExists(): void {
    // No staged stops.txt has been written, so nothing exists to compare
    // the custom header against.
    $files = $this->customFile('stops', [
      ['stop_id', 'stop_name', 'stop_lat', 'stop_lon', 'an_extra_column'],
      ['S1', 'Custom Stop', '54.90', '-3.50', 'anything'],
    ]);
    $report = $this->validator->validate($files, $this->stagingDir);
    $this->assertTrue($report->isValid(), (string) json_encode($report->getErrors()));
  }

  /**
   * Asserts at least one error matches the given file, column, and message.
   *
   * @param \Drupal\localgov_bus_data\Service\ValidationReport $report
   *   The report to search.
   * @param string $file
   *   Expected file key.
   * @param string|null $column
   *   Expected column, or NULL to match any column.
   * @param string $messageContains
   *   Substring expected in the error message.
   */
  private function assertErrorContains(
    ValidationReport $report,
    string $file,
    ?string $column,
    string $messageContains,
  ): void {
    foreach ($report->getErrors() as $error) {
      if ($error['file'] === $file
        && ($column === NULL || $error['column'] === $column)
        && str_contains($error['message'], $messageContains)) {
        $this->assertTrue(TRUE);
        return;
      }
    }
    $this->fail(sprintf(
      'No error found for file "%s", column "%s", containing "%s". Errors: %s',
      $file,
      $column ?? '(any)',
      $messageContains,
      json_encode($report->getErrors()),
    ));
  }

}
