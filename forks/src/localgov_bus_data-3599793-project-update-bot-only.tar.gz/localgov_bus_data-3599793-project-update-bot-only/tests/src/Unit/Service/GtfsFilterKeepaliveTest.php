<?php

declare(strict_types=1);

namespace Drupal\Tests\localgov_bus_data\Unit\Service;

use PHPUnit\Framework\Attributes\Group;
use Drupal\Core\Config\ConfigFactoryInterface;
use Drupal\Core\Config\ImmutableConfig;
use Drupal\localgov_bus_data\Service\GtfsFilter;
use Drupal\Tests\localgov_bus_data\Traits\MakesDatabaseKeepaliveTrait;
use Drupal\Tests\UnitTestCase;
use Psr\Log\LoggerInterface;

/**
 * Tests that GtfsFilter keeps the database connection alive on long passes.
 *
 * Filtering the national stop_times.txt is minutes of pure file work. On hosts
 * that reap idle connections the connection is gone by the time the import
 * reaches its first TRUNCATE, so the row loops must ping periodically, but not
 * on every row, which would put a query between every two CSV lines.
 *
 * @coversDefaultClass \Drupal\localgov_bus_data\Service\GtfsFilter
 * @group localgov_bus_data
 */
#[Group('localgov_bus_data')]
final class GtfsFilterKeepaliveTest extends UnitTestCase {

  use MakesDatabaseKeepaliveTrait;

  /**
   * Rows between pings, mirroring GtfsFilter::KEEPALIVE_ROWS.
   */
  private const KEEPALIVE_ROWS = 10000;

  /**
   * Temporary directory for GTFS CSV fixtures.
   *
   * @var string
   */
  private string $tmpDir;

  /**
   * {@inheritdoc}
   */
  protected function setUp(): void {
    parent::setUp();
    $this->tmpDir = sys_get_temp_dir() . '/gtfs_keepalive_test_' . uniqid('', TRUE);
    $this->assertTrue(
      mkdir($this->tmpDir, 0750, TRUE),
      'Could not create the fixture directory under ' . sys_get_temp_dir(),
    );
  }

  /**
   * {@inheritdoc}
   */
  protected function tearDown(): void {
    foreach (glob($this->tmpDir . '/*') ?: [] as $file) {
      if (is_file($file)) {
        unlink($file);
      }
    }
    if (is_dir($this->tmpDir)) {
      rmdir($this->tmpDir);
    }
    parent::tearDown();
  }

  /**
   * Writes a GTFS fixture whose stop_times.txt has the given number of rows.
   *
   * Every stop is inside the bounding box and every row belongs to one trip,
   * so no row is filtered out and both the scan and the rewrite pass see the
   * full row count.
   *
   * @param int $stopTimeRows
   *   Number of stop_times data rows to generate.
   */
  private function writeFixture(int $stopTimeRows): void {
    file_put_contents(
      $this->tmpDir . '/stops.txt',
      "stop_id,stop_name,stop_lat,stop_lon\nS1,Carlisle,54.9,-2.9\n",
    );
    file_put_contents(
      $this->tmpDir . '/trips.txt',
      "route_id,service_id,trip_id\nR1,SV1,T1\n",
    );
    file_put_contents(
      $this->tmpDir . '/routes.txt',
      "route_id,agency_id,route_short_name\nR1,OP1,554\n",
    );

    $handle = fopen($this->tmpDir . '/stop_times.txt', 'w');
    $this->assertNotFalse($handle, 'Could not open the stop_times fixture for writing.');
    fwrite($handle, "trip_id,arrival_time,departure_time,stop_id,stop_sequence\n");
    for ($i = 1; $i <= $stopTimeRows; $i++) {
      fwrite($handle, "T1,09:00:00,09:00:00,S1,{$i}\n");
    }
    fclose($handle);

    // A silently truncated fixture would make the ping assertions meaningless.
    $this->assertCount(
      $stopTimeRows + 1,
      file($this->tmpDir . '/stop_times.txt'),
      'The stop_times fixture was not written in full.',
    );
  }

  /**
   * Builds a GtfsFilter with a Cumberland bounding box and a spy keepalive.
   *
   * @param int $queryCount
   *   Counter incremented once per keepalive query. Passed by reference.
   *
   * @return \Drupal\localgov_bus_data\Service\GtfsFilter
   *   The configured filter.
   */
  private function makeFilter(int &$queryCount): GtfsFilter {
    $config = $this->createMock(ImmutableConfig::class);
    $config->method('get')->willReturnMap([
      ['source.boundary_geojson', NULL],
      ['source.bounding_box', [
        'north' => 55.1,
        'south' => 54.3,
        'east'  => -2.0,
        'west'  => -3.75,
      ],
      ],
    ]);
    $configFactory = $this->createMock(ConfigFactoryInterface::class);
    $configFactory->method('get')->willReturn($config);

    return new GtfsFilter(
      $configFactory,
      $this->createMock(LoggerInterface::class),
      $this->makeSpyKeepalive($queryCount),
    );
  }

  /**
   * A pass over more than KEEPALIVE_ROWS rows pings the database.
   *
   * @covers ::filterByGeography
   */
  public function testLongPassPingsTheDatabase(): void {
    $this->writeFixture(self::KEEPALIVE_ROWS + 1);

    $queryCount = 0;
    $filter = $this->makeFilter($queryCount);
    $filter->filterByGeography($this->tmpDir);

    $this->assertGreaterThanOrEqual(
      1,
      $queryCount,
      'Filtering a file longer than the keepalive interval must ping at least once.',
    );
  }

  /**
   * A short pass never pings: the connection has not been idle long enough.
   *
   * @covers ::filterByGeography
   */
  public function testShortPassNeverPings(): void {
    $this->writeFixture(100);

    $queryCount = 0;
    $filter = $this->makeFilter($queryCount);
    $filter->filterByGeography($this->tmpDir);

    $this->assertSame(
      0,
      $queryCount,
      'A hundred-row file must not put a keepalive query into the row loop.',
    );
  }

}
