<?php

declare(strict_types=1);

namespace Drupal\Tests\localgov_bus_data\Unit\Service;

use PHPUnit\Framework\Attributes\Group;
use Drupal\Component\Datetime\TimeInterface;
use Drupal\Core\Database\Connection;
use Drupal\Core\Database\DatabaseExceptionWrapper;
use Drupal\Core\Database\StatementInterface;
use Drupal\localgov_bus_data\Service\DatabaseKeepalive;
use Drupal\Tests\UnitTestCase;
use Psr\Log\LoggerInterface;

/**
 * Unit tests for DatabaseKeepalive.
 *
 * The time service is mocked so the interval throttle can be driven
 * deterministically rather than with real sleeps.
 *
 * @coversDefaultClass \Drupal\localgov_bus_data\Service\DatabaseKeepalive
 * @group localgov_bus_data
 */
#[Group('localgov_bus_data')]
final class DatabaseKeepaliveTest extends UnitTestCase {

  /**
   * Builds a time service returning the given timestamps in sequence.
   *
   * @param int ...$timestamps
   *   Values returned by successive getCurrentTime() calls.
   *
   * @return \Drupal\Component\Datetime\TimeInterface
   *   The mocked time service.
   */
  private function makeTime(int ...$timestamps): TimeInterface {
    $time = $this->createMock(TimeInterface::class);
    $time->method('getCurrentTime')->willReturnOnConsecutiveCalls(...$timestamps);
    return $time;
  }

  /**
   * Two pings inside the interval issue only one query.
   *
   * @covers ::ping
   */
  public function testPingWithinIntervalIsThrottled(): void {
    $statement = $this->createMock(StatementInterface::class);
    $database  = $this->createMock(Connection::class);
    $database->expects($this->once())
      ->method('query')
      ->with('SELECT 1')
      ->willReturn($statement);

    $keepalive = new DatabaseKeepalive(
      $database,
      $this->createMock(LoggerInterface::class),
      // Second call is 29 s later: inside the 30 s interval.
      $this->makeTime(1000, 1029),
      30,
    );

    $this->assertTrue($keepalive->ping());
    $this->assertTrue($keepalive->ping());
  }

  /**
   * A ping after the interval has elapsed issues a second query.
   *
   * @covers ::ping
   */
  public function testPingAfterIntervalQueriesAgain(): void {
    $statement = $this->createMock(StatementInterface::class);
    $database  = $this->createMock(Connection::class);
    $database->expects($this->exactly(2))
      ->method('query')
      ->with('SELECT 1')
      ->willReturn($statement);

    $keepalive = new DatabaseKeepalive(
      $database,
      $this->createMock(LoggerInterface::class),
      // 1000 → query; 1029 throttled; 1031 is > 30 s after 1000 → query.
      $this->makeTime(1000, 1029, 1031),
      30,
    );

    $this->assertTrue($keepalive->ping());
    $this->assertTrue($keepalive->ping());
    $this->assertTrue($keepalive->ping());
  }

  /**
   * The first ping always queries, whatever the clock reads.
   *
   * @covers ::ping
   */
  public function testFirstPingAlwaysQueries(): void {
    $statement = $this->createMock(StatementInterface::class);
    $database  = $this->createMock(Connection::class);
    $database->expects($this->once())->method('query')->willReturn($statement);

    $keepalive = new DatabaseKeepalive(
      $database,
      $this->createMock(LoggerInterface::class),
      $this->makeTime(0),
      30,
    );

    $this->assertTrue($keepalive->ping());
  }

  /**
   * A dead connection is logged and reported, never rethrown.
   *
   * @covers ::ping
   */
  public function testPingOnDeadConnectionLogsAndReturnsFalse(): void {
    $database = $this->createMock(Connection::class);
    $database->method('query')
      ->willThrowException(new DatabaseExceptionWrapper('MySQL server has gone away'));

    $logger = $this->createMock(LoggerInterface::class);
    $logger->expects($this->once())
      ->method('warning')
      ->with(
        $this->stringContains('keepalive ping failed'),
        $this->callback(static fn (array $context): bool
          => str_contains($context['@msg'], 'MySQL server has gone away')),
      );

    $keepalive = new DatabaseKeepalive(
      $database,
      $logger,
      $this->makeTime(1000),
      30,
    );

    $this->assertFalse($keepalive->ping());
  }

  /**
   * A logger that also fails does not turn a failed ping into an exception.
   *
   * @covers ::ping
   */
  public function testPingSurvivesFailingLogger(): void {
    $database = $this->createMock(Connection::class);
    $database->method('query')
      ->willThrowException(new DatabaseExceptionWrapper('gone away'));

    $logger = $this->createMock(LoggerInterface::class);
    $logger->method('warning')
      ->willThrowException(new DatabaseExceptionWrapper('dblog is on the dead connection too'));

    $keepalive = new DatabaseKeepalive(
      $database,
      $logger,
      $this->makeTime(1000),
      30,
    );

    $this->assertFalse($keepalive->ping());
  }

  /**
   * A failed ping is throttled too, so a row loop cannot flood the log.
   *
   * @covers ::ping
   */
  public function testFailedPingIsAlsoThrottled(): void {
    $database = $this->createMock(Connection::class);
    $database->expects($this->once())
      ->method('query')
      ->willThrowException(new DatabaseExceptionWrapper('gone away'));

    $keepalive = new DatabaseKeepalive(
      $database,
      $this->createMock(LoggerInterface::class),
      $this->makeTime(1000, 1005),
      30,
    );

    $this->assertFalse($keepalive->ping());
    // Throttled: repeats the known-bad result without a second failed query.
    $this->assertFalse($keepalive->ping());
  }

}
