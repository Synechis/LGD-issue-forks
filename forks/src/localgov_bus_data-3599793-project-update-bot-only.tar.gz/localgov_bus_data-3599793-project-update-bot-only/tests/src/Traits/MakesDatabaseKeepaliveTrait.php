<?php

declare(strict_types=1);

namespace Drupal\Tests\localgov_bus_data\Traits;

use Drupal\Component\Datetime\TimeInterface;
use Drupal\Core\Database\Connection;
use Drupal\Core\Database\StatementInterface;
use Drupal\localgov_bus_data\Service\DatabaseKeepalive;
use Psr\Log\LoggerInterface;

/**
 * Builds DatabaseKeepalive instances for services that take one.
 *
 * DatabaseKeepalive is final and deliberately has no interface, so tests that
 * need to observe pings build a real one over a mocked Connection and count
 * the queries it issues.
 */
trait MakesDatabaseKeepaliveTrait {

  /**
   * Builds a keepalive whose pings succeed and are not observed.
   *
   * @return \Drupal\localgov_bus_data\Service\DatabaseKeepalive
   *   A keepalive over mocked services.
   */
  protected function makeKeepalive(): DatabaseKeepalive {
    $ignored = 0;
    return $this->makeSpyKeepalive($ignored);
  }

  /**
   * Builds a keepalive that counts the "SELECT 1" queries it actually issues.
   *
   * The clock advances a full minute on every read, so the interval throttle
   * never suppresses a ping: the count is the number of times the caller
   * asked, which is what the caller's ping frequency is being tested on.
   *
   * @param int $queryCount
   *   Counter, incremented once per query issued. Passed by reference.
   *
   * @return \Drupal\localgov_bus_data\Service\DatabaseKeepalive
   *   A keepalive over mocked services.
   */
  protected function makeSpyKeepalive(int &$queryCount): DatabaseKeepalive {
    $queryCount = 0;

    $statement = $this->createMock(StatementInterface::class);
    $database  = $this->createMock(Connection::class);
    $database->method('query')
      ->willReturnCallback(static function () use (&$queryCount, $statement): StatementInterface {
        $queryCount++;
        return $statement;
      });

    $clock = 0;
    $time  = $this->createMock(TimeInterface::class);
    $time->method('getCurrentTime')
      ->willReturnCallback(static function () use (&$clock): int {
        return $clock += 60;
      });

    return new DatabaseKeepalive(
      $database,
      $this->createMock(LoggerInterface::class),
      $time,
    );
  }

}
