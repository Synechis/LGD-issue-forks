<?php

declare(strict_types=1);

namespace Drupal\Tests\localgov_bus_data\Traits;

use Symfony\Component\Yaml\Yaml;

/**
 * Installs the module's shipped views into kernel tests without localgov_core.
 *
 * The localgov_core module is a soft dependency: localgov_bus_data supports
 * vanilla Drupal too, and PageHeaderSubscriber only engages when the module
 * is present. CI does not have localgov_core installed, so kernel tests must
 * not enable it. But every shipped view display carries a
 * localgov_page_header_display_extender key in its display_extenders, and
 * that plugin is only available when localgov_core is enabled, so loading a
 * view's config as-is without the module would fail when the display
 * extender plugin cannot be found. This trait strips that key from the
 * decoded YAML before the config is saved, so the view renders without the
 * plugin exactly as it would on a site that never installs localgov_core.
 */
trait InstallsBusDataViewsTrait {

  /**
   * Decodes a shipped view's config/install YAML and saves it as active config.
   *
   * @param string $view_id
   *   The view's config ID, e.g. 'localgov_bus_routes'.
   */
  protected function installBusDataView(string $view_id): void {
    $path = \Drupal::service('extension.list.module')->getPath('localgov_bus_data') . "/config/install/views.view.$view_id.yml";
    $data = Yaml::parseFile($path);

    // Every view has at least one display, and foreach-by-reference over a
    // '??' expression would iterate a temporary copy instead of $data,
    // silently leaving the extender key in place.
    foreach ($data['display'] as &$display) {
      unset($display['display_options']['display_extenders']['localgov_page_header_display_extender']);
    }
    unset($display);

    \Drupal::configFactory()->getEditable("views.view.$view_id")->setData($data)->save();
  }

}
