<?php

declare(strict_types=1);

namespace Drupal\Tests\localgov_bus_data\Kernel;

use PHPUnit\Framework\Attributes\Group;
use PHPUnit\Framework\Attributes\RunTestsInSeparateProcesses;
use Drupal\Core\Form\FormState;
use Drupal\KernelTests\KernelTestBase;
use Drupal\localgov_bus_data\Form\CustomCsvForm;

/**
 * Kernel tests for CustomCsvForm::submitForm().
 *
 * Exercises submitForm() directly (bypassing a full form build, since
 * submitForm() only reads submitted values and never touches $form) via the
 * real container-wired form object, so $this->t(), $this->messenger(), and
 * $this->config() all resolve as they would in a real request.
 *
 * @group localgov_bus_data
 */
#[Group('localgov_bus_data')]
#[RunTestsInSeparateProcesses]
final class CustomCsvFormKernelTest extends KernelTestBase {

  /**
   * {@inheritdoc}
   */
  protected static $modules = [
    'system',
    'user',
    'field',
    'file',
    'datetime',
    'geofield',
    'migrate',
    'localgov_bus_data',
  ];

  /**
   * The form under test.
   */
  private CustomCsvForm $form;

  /**
   * {@inheritdoc}
   */
  protected function setUp(): void {
    parent::setUp();
    $this->installEntitySchema('user');
    $this->installEntitySchema('file');
    $this->installSchema('file', ['file_usage']);

    $this->form = CustomCsvForm::create($this->container);
  }

  /**
   * A slot whose submitted value is empty but config still stores a fid warns.
   *
   * Two distinct causes produce this same shape: the admin used
   * managed_file's own built-in AJAX Remove button (which only clears the
   * widget's client-side value, separate from the form's dedicated
   * "Remove @label" submit action, which actually deletes the file, its
   * usage record, and the config entry), or the stored file entity no
   * longer resolves (core's ManagedFile::valueCallback() silently drops a
   * fid that File::load() cannot resolve). Either way, saving the form in
   * that state must not silently keep the file active in config while
   * implying success via a plain "Settings saved." message, and the
   * warning must not assert a cause it cannot actually distinguish.
   */
  public function testEmptySlotWithStoredFidWarnsAndKeepsConfig(): void {
    $this->config('localgov_bus_data.settings')
      ->set('custom_data.files', ['stops' => 5])
      ->save();

    $form = [];
    $formState = new FormState();
    $formState->setValues([
      'enabled' => FALSE,
      'files' => [
        'stops' => ['upload' => []],
      ],
    ]);

    $this->form->submitForm($form, $formState);

    $messenger = \Drupal::messenger();
    $warnings = $messenger->deleteByType('warning');
    $this->assertNotEmpty($warnings, 'A warning was shown for a slot with an empty submitted value but a stored fid.');
    $this->assertStringContainsString('Stops', (string) $warnings[0]);

    $storedFileIds = $this->config('localgov_bus_data.settings')->get('custom_data.files');
    $this->assertSame(['stops' => 5], $storedFileIds, 'The stored file ID is untouched: only the dedicated Remove button deletes it.');
  }

  /**
   * The form survives the serialise/unserialise cycle managed_file AJAX does.
   *
   * The managed_file element uploads via AJAX, which serialises the form
   * object mid-request and unserialises it on the next request.
   * DependencySerializationTrait::__sleep() only keeps properties visible to
   * get_object_vars() called from FormBase's own scope, so any state the
   * form needs after that round trip must be readable from there, not just
   * from CustomCsvForm's own scope. This must fail on a commit where a
   * subclass-private property holds that state, and pass once the state
   * survives serialisation (or is rebuilt without needing to survive it).
   */
  public function testFormSurvivesSerializationRoundTrip(): void {
    // Deliberately reproducing the exact serialise/unserialise cycle
    // managed_file's AJAX request performs on this known, trusted object;
    // this is not untrusted input.
    // phpcs:ignore DrupalPractice.FunctionCalls.InsecureUnserialize.InsecureUnserialize
    $restored = unserialize(serialize($this->form));

    $form = [];
    $formState = new FormState();
    $formState->setValues([
      'enabled' => FALSE,
      'files' => [
        'stops' => ['upload' => []],
      ],
    ]);
    $this->config('localgov_bus_data.settings')
      ->set('custom_data.files', ['stops' => 5])
      ->save();

    $restored->submitForm($form, $formState);

    $messenger = \Drupal::messenger();
    $warnings = $messenger->deleteByType('warning');
    $this->assertNotEmpty($warnings, 'A warning naming the file label was shown after the round trip.');
    $this->assertStringContainsString('Stops', (string) $warnings[0]);
  }

  /**
   * Saving with no changes to the file set produces no spurious warning.
   */
  public function testSavingUnchangedFileSetProducesNoWarning(): void {
    $this->config('localgov_bus_data.settings')
      ->set('custom_data.files', ['stops' => 5])
      ->save();

    $form = [];
    $formState = new FormState();
    $formState->setValues([
      'enabled' => FALSE,
      'files' => [
        'stops' => ['upload' => [5]],
      ],
    ]);

    $this->form->submitForm($form, $formState);

    $messenger = \Drupal::messenger();
    $this->assertEmpty($messenger->deleteByType('warning'));
    $statuses = $messenger->deleteByType('status');
    $this->assertNotEmpty($statuses);
    $this->assertStringContainsString('Settings saved.', (string) $statuses[0]);
  }

}
