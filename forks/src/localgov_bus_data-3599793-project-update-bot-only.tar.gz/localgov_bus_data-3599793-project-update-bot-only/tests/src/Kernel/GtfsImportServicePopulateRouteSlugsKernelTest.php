<?php

declare(strict_types=1);

namespace Drupal\Tests\localgov_bus_data\Kernel;

use PHPUnit\Framework\Attributes\Group;
use PHPUnit\Framework\Attributes\RunTestsInSeparateProcesses;
use Drupal\KernelTests\KernelTestBase;
use Drupal\localgov_bus_data\Drush\Commands\BusTimesCommands;
use Drupal\localgov_bus_data\Entity\BusRoute;
use Drupal\localgov_bus_data\Service\GtfsImportService;
use Drush\Commands\DrushCommands;
use Drush\Log\DrushLoggerManager;

/**
 * Kernel tests for GtfsImportService::populateRouteSlugs().
 *
 * Covers derivation from the headsign, transliteration, the empty-headsign
 * fallback chain, deterministic collision suffixing, and that an existing
 * slug is never overwritten (the incremental-import invariant that keeps
 * URLs stable between full imports). One test also drives the real
 * bus-times:seed Drush command to prove that call site is wired, and two
 * cover the backfill's other call site,
 * localgov_bus_data_post_update_populate_route_slugs().
 *
 * @group localgov_bus_data
 */
#[Group('localgov_bus_data')]
#[RunTestsInSeparateProcesses]
final class GtfsImportServicePopulateRouteSlugsKernelTest extends KernelTestBase {

  /**
   * {@inheritdoc}
   */
  protected static $modules = [
    'system',
    'field',
    'file',
    'datetime',
    'geofield',
    'migrate',
    'localgov_bus_data',
  ];

  /**
   * The service under test.
   */
  private GtfsImportService $service;

  /**
   * {@inheritdoc}
   */
  protected function setUp(): void {
    parent::setUp();

    $this->installEntitySchema('localgov_bus_route');

    $this->service = $this->container->get('localgov_bus_data.gtfs_import');
  }

  /**
   * Creates a route entity with the given denormalised fields.
   */
  private function createRoute(
    string $routeId,
    string $agencyId,
    string $shortName,
    string $headsign = '',
    string $longName = '',
    string $slug = '',
  ): BusRoute {
    $route = BusRoute::create([
      'bustimes_route_id' => $routeId,
      'bustimes_agency_id' => $agencyId,
      'bustimes_route_short_name' => $shortName,
      'bustimes_headsign' => $headsign,
      'bustimes_route_long_name' => $longName,
      'bustimes_slug' => $slug,
    ]);
    $route->save();
    return $route;
  }

  /**
   * Reloads a route's slug from storage, bypassing the static entity cache.
   */
  private function reloadSlug(BusRoute $route): string {
    $storage = $this->container->get('entity_type.manager')->getStorage('localgov_bus_route');
    $storage->resetCache([$route->id()]);
    /** @var \Drupal\localgov_bus_data\Entity\BusRoute $reloaded */
    $reloaded = $storage->load($route->id());
    return (string) $reloaded->get('bustimes_slug')->value;
  }

  /**
   * Reads a route's headsign straight from the database, bypassing storage.
   */
  private function readHeadsignFromDatabase(BusRoute $route): string {
    return (string) $this->container->get('database')
      ->select('localgov_bus_route', 'r')
      ->fields('r', ['bustimes_headsign'])
      ->condition('id', $route->id())
      ->execute()
      ->fetchField();
  }

  /**
   * Derives from the headsign: transliterated, lowercased, hyphen-collapsed.
   */
  public function testDerivesSlugFromHeadsignCollapsingNonAlphanumerics(): void {
    $route = $this->createRoute('R1', 'OP539', 'X5', headsign: 'Carlisle - Wigton (via Dalston)');

    $this->service->populateRouteSlugs();

    $this->assertSame('carlisle-wigton-via-dalston', $this->reloadSlug($route));
  }

  /**
   * Non-ASCII characters in the headsign are transliterated before slugging.
   */
  public function testTransliteratesNonAsciiHeadsign(): void {
    $route = $this->createRoute('R2', 'OP539', 'X6', headsign: 'Pénrith Café');

    $this->service->populateRouteSlugs();

    $this->assertSame('penrith-cafe', $this->reloadSlug($route));
  }

  /**
   * A straight apostrophe is stripped, not collapsed to a hyphen.
   *
   * Mutation check: dropping the str_replace() apostrophe strip from
   * slugify() makes this test fail with 'booth-s-supermarket', because the
   * apostrophe would instead fall through to the general
   * non-alphanumeric-collapse rule like any other punctuation.
   */
  public function testStraightApostropheIsStrippedNotHyphenated(): void {
    $route = $this->createRoute('R12', 'OP539', 'X15', headsign: "Booth's Supermarket");

    $this->service->populateRouteSlugs();

    $this->assertSame('booths-supermarket', $this->reloadSlug($route));
  }

  /**
   * A curly apostrophe (U+2019) is stripped the same way as a straight one.
   *
   * GTFS feeds sometimes use the Unicode right single quotation mark as a
   * typographic apostrophe rather than the ASCII character.
   *
   * Mutation check: dropping the curly-apostrophe entry from slugify()'s
   * str_replace() makes this test fail with 'booth-s-supermarket'.
   */
  public function testCurlyApostropheIsStrippedNotHyphenated(): void {
    $route = $this->createRoute('R13', 'OP539', 'X16', headsign: "Booth\u{2019}s Supermarket");

    $this->service->populateRouteSlugs();

    $this->assertSame('booths-supermarket', $this->reloadSlug($route));
  }

  /**
   * An empty headsign falls back to the route long name.
   */
  public function testEmptyHeadsignFallsBackToRouteLongName(): void {
    $route = $this->createRoute('R3', 'OP539', 'X7', headsign: '', longName: 'Keswick - Penrith');

    $this->service->populateRouteSlugs();

    $this->assertSame('keswick-penrith', $this->reloadSlug($route));
  }

  /**
   * An empty headsign and long name fall back to the route ID.
   *
   * Mirrors X70 under OP261 on the live site, which has no headsign.
   */
  public function testEmptyHeadsignAndLongNameFallsBackToRouteId(): void {
    $route = $this->createRoute('OP261-X70-1', 'OP261', 'X70', headsign: '', longName: '');

    $this->service->populateRouteSlugs();

    $this->assertSame('op261-x70-1', $this->reloadSlug($route));
  }

  /**
   * A headsign that is non-empty but slugifies to nothing falls through.
   *
   * The fallback chain must test the slugified result, not the raw source:
   * a punctuation-only headsign is non-empty as a string but must still
   * fall back to the long name, otherwise the route would be left with an
   * empty (or, once suffixed, leading-hyphen) slug.
   */
  public function testHeadsignThatSlugifiesToEmptyFallsBackToRouteLongName(): void {
    $route = $this->createRoute('R4', 'OP539', 'X8', headsign: '---', longName: 'Keswick');

    $this->service->populateRouteSlugs();

    $this->assertSame('keswick', $this->reloadSlug($route));
  }

  /**
   * If every candidate slugifies to empty, falls back to the entity ID.
   *
   * The entity ID is guaranteed present and unique once the route is saved,
   * so no route can ever end up with an empty slug or, once suffixed, a
   * leading-hyphen slug like "-2".
   */
  public function testAllCandidatesEmptyFallsBackToEntityId(): void {
    $route = $this->createRoute('###', 'OP539', 'X10', headsign: '###', longName: '###');

    $this->service->populateRouteSlugs();

    $this->assertSame('route-' . $route->id(), $this->reloadSlug($route));
  }

  /**
   * A slug source longer than the field is truncated, not rejected.
   *
   * Bustimes_slug is varchar(100) but its sources (bustimes_headsign,
   * bustimes_route_long_name) are varchar(255), so a long GTFS value must
   * not be written past the column limit: this DDEV database runs
   * STRICT_TRANS_TABLES, so an over-length write throws and would abort the
   * rest of populateRouteSlugs() for every remaining route.
   */
  public function testLongHeadsignIsTruncatedToFitField(): void {
    $route = $this->createRoute('R5', 'OP539', 'X9', headsign: str_repeat('a', 150));

    $this->service->populateRouteSlugs();

    $slug = $this->reloadSlug($route);
    $this->assertLessThanOrEqual(100, strlen($slug));
    $this->assertSame(str_repeat('a', 90), $slug);
  }

  /**
   * Colliding slugs within (agency, short name) get deterministic suffixes.
   *
   * Mirrors X12 under OP261 on the live site, where two routes share the
   * headsign "The Crown". Entities are created out of route_id order to
   * prove suffixing follows bustimes_route_id, not creation order.
   */
  public function testCollisionAppendsSuffixInRouteIdOrder(): void {
    $second = $this->createRoute('OP261-X12-2', 'OP261', 'X12', headsign: 'The Crown');
    $first = $this->createRoute('OP261-X12-1', 'OP261', 'X12', headsign: 'The Crown');

    $this->service->populateRouteSlugs();

    $this->assertSame('the-crown', $this->reloadSlug($first));
    $this->assertSame('the-crown-2', $this->reloadSlug($second));
  }

  /**
   * An existing slug is left alone, and blocks new routes from colliding.
   *
   * This is the incremental-import invariant: the headsign is a MIN() over
   * trip headsigns and can shift when a new trip variant is imported, but
   * the slug must not follow it, so URLs stay put between full imports.
   */
  public function testExistingSlugIsNotOverwrittenAndBlocksNewCollisions(): void {
    $withSlug = $this->createRoute('OP539-X5-1', 'OP539', 'X5', headsign: 'Somewhere Else', slug: 'keswick');
    $withoutSlug = $this->createRoute('OP539-X5-2', 'OP539', 'X5', headsign: 'Keswick');

    $this->service->populateRouteSlugs();

    $this->assertSame('keswick', $this->reloadSlug($withSlug));
    $this->assertSame('keswick-2', $this->reloadSlug($withoutSlug));
  }

  /**
   * A derived slug of 'all' is reserved and always gets suffixed.
   *
   * 'all' is the Views exception value configured on the timetable page's
   * contextual filters, so a route slug of literally 'all' would let a
   * three-segment URL ending in /all skip the slug filter and merge this
   * route with any sibling sharing its agency and route number instead of
   * naming it (see _localgov_bus_data_require_known_route()).
   *
   * Mutation check: dropping the `$slug === 'all'` disjunct from
   * populateRouteSlugs()'s collision loop makes this test fail, because the
   * route would keep the bare 'all' slug.
   */
  public function testDerivedSlugOfAllIsReservedAndSuffixed(): void {
    $route = $this->createRoute('R6', 'OP539', 'X11', headsign: 'All');

    $this->service->populateRouteSlugs();

    $this->assertSame('all-2', $this->reloadSlug($route));
  }

  /**
   * A second route also headsigned 'All' still gets a distinct slug.
   *
   * Proves the reservation is folded into the normal suffix search rather
   * than a special case that only fires once: the '-2' slot is already
   * taken by the first route, so the second must carry on to '-3'.
   *
   * Mutation check: dropping the `$slug === 'all'` disjunct from
   * populateRouteSlugs()'s collision loop makes the sort() assertion fail,
   * because the first route would keep the bare 'all' slug instead of
   * moving to 'all-2'.
   */
  public function testTwoRoutesDerivingAllBothAvoidTheReservedSlug(): void {
    $first = $this->createRoute('R7', 'OP539', 'X11', headsign: 'All');
    $second = $this->createRoute('R8', 'OP539', 'X11', headsign: 'All');

    $this->service->populateRouteSlugs();

    $slugs = [$this->reloadSlug($first), $this->reloadSlug($second)];
    sort($slugs);
    $this->assertSame(['all-2', 'all-3'], $slugs);
  }

  /**
   * A headsign changed under it by raw SQL is not reverted.
   *
   * Its sibling, populateRouteHeadsigns(), runs immediately before this at
   * every real call site and writes bustimes_headsign via a raw SQL UPDATE,
   * which bypasses the entity storage cache. Loading routes here without
   * first resetting that cache would return the pre-update entity, and this
   * method's own save() (writing the derived slug) would then persist that
   * stale headsign straight back over the value populateRouteHeadsigns()
   * just set.
   *
   * Mutation check: removing the $storage->resetCache() call from the start
   * of populateRouteSlugs() makes this test fail, because the route object
   * loaded and re-saved here would still carry the original 'Keswick'
   * headsign cached from createRoute()'s save().
   */
  public function testRawSqlHeadsignChangeIsNotReverted(): void {
    $route = $this->createRoute('R11', 'OP539', 'X13', headsign: 'Keswick');

    $this->container->get('database')
      ->update('localgov_bus_route')
      ->fields(['bustimes_headsign' => 'Penrith'])
      ->condition('id', $route->id())
      ->execute();

    $this->service->populateRouteSlugs();

    $this->assertSame('Penrith', $this->readHeadsignFromDatabase($route));
  }

  /**
   * The bus-times:seed Drush command path populates slugs.
   *
   * BusTimesCommands::seed() is instantiated directly rather than via
   * Drush's CLI runner. Its logger defaults to null outside a real Drush
   * bootstrap, so it is set explicitly to a no-op logger: an anonymous
   * subclass of DrushLoggerManager that overrides success() to call log()
   * directly rather than through Drush 13's deprecated success() proxy,
   * which would otherwise fail this suite via the Symfony deprecation
   * listener. Its dt() helper is not part of Composer's autoloaded files
   * map, so it is loaded explicitly too.
   */
  public function testSeedCommandPopulatesSlugs(): void {
    $this->installEntitySchema('localgov_bus_stop');
    $this->installEntitySchema('localgov_bus_calendar');
    $this->installEntitySchema('localgov_bus_trip');
    $this->installEntitySchema('localgov_bus_stop_time');

    if (!function_exists('dt')) {
      $drushCommandsFile = (new \ReflectionClass(DrushCommands::class))->getFileName();
      require_once dirname($drushCommandsFile, 3) . '/includes/output.inc';
    }

    $commands = new BusTimesCommands(
      $this->service,
      $this->container->get('entity_type.manager'),
    );
    $commands->setLogger(new class() extends DrushLoggerManager {

      /**
       * {@inheritdoc}
       */
      public function success(string $message, array $context = []): void {
        $this->log(self::SUCCESS, $message, $context);
      }

    });

    $commands->seed();

    $storage = $this->container->get('entity_type.manager')->getStorage('localgov_bus_route');
    $routes = $storage->loadByProperties(['bustimes_route_id' => '685']);
    /** @var \Drupal\localgov_bus_data\Entity\BusRoute $route */
    $route = reset($routes);

    $this->assertSame('newcastle', (string) $route->get('bustimes_slug')->value);
  }

  /**
   * The field storage update populates slugs itself, right after installing.
   *
   * This update hook calls populateRouteSlugs() immediately after installing
   * the field storage. Slugs must exist by the time update_10011 runs, so it
   * can move the timetable view onto the three-segment path without leaving
   * routes unreachable in between.
   *
   * Mutation check: removing the populateRouteSlugs() call from the end of
   * localgov_bus_data_update_10010() makes this test fail, as the field
   * would install but stay empty.
   */
  public function testUpdate10010PopulatesSlugsImmediately(): void {
    $route = $this->createRoute('R9', 'OP539', 'X14', headsign: 'Keswick');

    \Drupal::moduleHandler()->loadInclude('localgov_bus_data', 'install');
    localgov_bus_data_update_10010();

    $this->assertSame('keswick', $this->reloadSlug($route));
  }

  /**
   * The slug backfill post update populates and reports the count.
   *
   * The backfill call is duplicated: update_10010 (which installs the field
   * storage) also calls it immediately, but this hook_post_update_NAME
   * implementation is kept as an idempotent safety net that runs once all
   * schema updates have completed and the entity definitions have settled.
   *
   * Mutation check: emptying the post update body (leaving the call only in
   * update_10010) makes both assertions fail, as the post update would
   * populate nothing and report zero.
   */
  public function testPostUpdatePopulatesSlugsAndReportsTheCount(): void {
    $first = $this->createRoute('R1', 'OP539', 'X5', headsign: 'Keswick');
    $second = $this->createRoute('R2', 'OP539', 'X6', headsign: 'Penrith');

    \Drupal::moduleHandler()->loadInclude('localgov_bus_data', 'php', 'localgov_bus_data.post_update');
    $message = (string) localgov_bus_data_post_update_populate_route_slugs();

    $this->assertSame('keswick', $this->reloadSlug($first));
    $this->assertSame('penrith', $this->reloadSlug($second));
    $this->assertStringContainsString('2 routes', $message);
  }

  /**
   * Re-running the post update changes nothing and reports zero.
   *
   * Slugs are part of published URLs, so a second run must not renumber the
   * -2, -3 collision suffixes.
   *
   * Mutation check: removing populateRouteSlugs()'s
   * `if ((string) $route->get('bustimes_slug')->value !== '') { continue; }`
   * guard makes both assertions fail, because every route would be given a
   * fresh slug (and the colliding pair would swap suffixes) on each run.
   */
  public function testPostUpdateIsIdempotent(): void {
    $first = $this->createRoute('R4', 'OP261', 'X12', headsign: 'The Crown');
    $second = $this->createRoute('R5', 'OP261', 'X12', headsign: 'The Crown');

    \Drupal::moduleHandler()->loadInclude('localgov_bus_data', 'php', 'localgov_bus_data.post_update');
    localgov_bus_data_post_update_populate_route_slugs();
    $slugs_after_first = [$this->reloadSlug($first), $this->reloadSlug($second)];

    $message = (string) localgov_bus_data_post_update_populate_route_slugs();

    $this->assertSame($slugs_after_first, [$this->reloadSlug($first), $this->reloadSlug($second)]);
    $this->assertStringContainsString('0 routes', $message);
  }

}
