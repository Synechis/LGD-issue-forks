<?php

declare(strict_types=1);

namespace Drupal\Tests\localgov_bus_data\Kernel;

use PHPUnit\Framework\Attributes\Group;
use PHPUnit\Framework\Attributes\RunTestsInSeparateProcesses;
use Drupal\Core\Render\HtmlResponse;
use Drupal\Core\Routing\LocalRedirectResponse;
use Drupal\KernelTests\KernelTestBase;
use Drupal\Tests\localgov_bus_data\Traits\InstallsBusDataViewsTrait;
use Drupal\localgov_bus_data\Entity\BusRoute;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;

/**
 * Kernel tests for the old two-segment bus route URL redirect.
 *
 * Issue #3599802 moved the timetable page from
 * buses/routes/{agency_id}/{route_short_name} to
 * buses/routes/{agency_id}/{route_short_name}/{slug}. The old two-segment
 * path is dead but is still the path in existing external links, bookmarks
 * and search results, so localgov_bus_data.route_redirect looks up the
 * matching route(s) and redirects instead of leaving the old links to 404
 * or show the wrong merged timetable.
 *
 * @group localgov_bus_data
 */
#[Group('localgov_bus_data')]
#[RunTestsInSeparateProcesses]
final class BusRouteRedirectControllerKernelTest extends KernelTestBase {

  use InstallsBusDataViewsTrait;

  /**
   * {@inheritdoc}
   */
  protected static $modules = [
    'system',
    'user',
    'path_alias',
    'field',
    'text',
    'options',
    'file',
    'datetime',
    'geofield',
    'migrate',
    'migrate_plus',
    'views',
    'leaflet',
    'leaflet_markercluster',
    'leaflet_views',
    'localgov_bus_data',
  ];

  /**
   * {@inheritdoc}
   */
  protected function setUp(): void {
    parent::setUp();

    $this->installEntitySchema('localgov_bus_route');
    $this->installEntitySchema('path_alias');
    $this->installConfig(['system']);

    // Only the two views the redirect targets are needed, not the whole
    // module's config: localgov_bus_stop_search ships with a pre-existing,
    // unrelated config schema gap that would otherwise abort
    // installConfig() for every test in this class.
    foreach (['localgov_bus_routes', 'localgov_bus_timetable'] as $view_id) {
      $this->installBusDataView($view_id);
    }

    $this->container->get('router.builder')->rebuild();
  }

  /**
   * Creates a route entity with the given denormalised fields.
   */
  private function createRoute(string $routeId, string $agencyId, string $shortName, string $slug): BusRoute {
    $route = BusRoute::create([
      'bustimes_route_id' => $routeId,
      'bustimes_agency_id' => $agencyId,
      'bustimes_route_short_name' => $shortName,
      'bustimes_slug' => $slug,
    ]);
    $route->save();
    return $route;
  }

  /**
   * Dispatches a request to the old two-segment route path.
   *
   * @param string $agencyId
   *   GTFS agency ID for the first URL segment.
   * @param string $shortName
   *   Route short name for the second URL segment.
   * @param array<string, string> $query
   *   Query parameters to send with the request.
   */
  private function requestOldPath(string $agencyId, string $shortName, array $query = []): Response {
    $request = Request::create("/buses/routes/$agencyId/$shortName", 'GET', $query);
    return $this->container->get('http_kernel')->handle($request);
  }

  /**
   * A single match redirects (302) to the route's three-segment URL.
   *
   * The controller returns a CacheableRedirectResponse, but core's
   * RedirectResponseSubscriber replaces any plain RedirectResponse with a
   * LocalRedirectResponse on kernel.response (to guard against open
   * redirects), copying over cache metadata in the process. That is the
   * response the client actually receives, so it is what this test checks.
   *
   * Mutation check: swapping the 302 for 301 in the controller (single-match
   * branch) makes the status assertion fail; swapping arg_2 for the wrong
   * field value makes the target-URL assertion fail.
   */
  public function testSingleMatchRedirectsTemporarilyToSlugUrl(): void {
    $this->createRoute('R1', 'OP539', 'X5', 'keswick-penrith');

    $response = $this->requestOldPath('OP539', 'X5');

    $this->assertInstanceOf(LocalRedirectResponse::class, $response);
    $this->assertSame(302, $response->getStatusCode());
    $this->assertSame('/buses/routes/OP539/X5/keswick-penrith', $response->getTargetUrl());
  }

  /**
   * A single match's redirect carries the route-list cache tag.
   *
   * Mutation check: removing addCacheableDependency($cache) from the
   * single-match branch makes this assertion fail.
   */
  public function testSingleMatchRedirectCarriesRouteListCacheTag(): void {
    $this->createRoute('R1', 'OP539', 'X5', 'keswick-penrith');

    $response = $this->requestOldPath('OP539', 'X5');

    $this->assertInstanceOf(LocalRedirectResponse::class, $response);
    $this->assertContains('localgov_bus_route_list', $response->getCacheableMetadata()->getCacheTags());
  }

  /**
   * Multiple matches redirect (302) to the filtered search results page.
   *
   * Mutation check: reverting the multi-match branch to redirect to the
   * single-route timetable URL (e.g. the first match) instead of the search
   * page makes the target-URL assertion fail; swapping 302 for 301 makes
   * the status assertion fail.
   */
  public function testMultipleMatchesRedirectTemporarilyToFilteredSearch(): void {
    $this->createRoute('R4', 'OP261', 'X12', 'the-crown');
    $this->createRoute('R5', 'OP261', 'X12', 'the-crown-2');

    $response = $this->requestOldPath('OP261', 'X12');

    $this->assertInstanceOf(LocalRedirectResponse::class, $response);
    $this->assertSame(302, $response->getStatusCode());
    $this->assertSame('/buses/routes?bustimes_route_short_name=X12', $response->getTargetUrl());
    $this->assertContains('localgov_bus_route_list', $response->getCacheableMetadata()->getCacheTags());
  }

  /**
   * A single match with no slug yet redirects to search, not a broken URL.
   *
   * GtfsImportService backfills bustimes_slug on routes that lack one as a
   * step after routes are saved, so a route entity can briefly exist
   * without one during import. Building the three-segment URL anyway would
   * produce a URL with an empty final segment that the timetable route
   * would not match.
   *
   * Mutation check: removing the `|| $slug === NULL || $slug === ''` guard
   * from the controller makes the target-URL assertion fail, because the
   * single-match branch would then redirect to the broken
   * '/buses/routes/OP539/X7' three-segment URL instead of the search page.
   */
  public function testSingleMatchWithMissingSlugRedirectsToSearch(): void {
    $this->createRoute('R6', 'OP539', 'X7', '');

    $response = $this->requestOldPath('OP539', 'X7');

    $this->assertInstanceOf(LocalRedirectResponse::class, $response);
    $this->assertSame(302, $response->getStatusCode());
    $this->assertSame('/buses/routes?bustimes_route_short_name=X7', $response->getTargetUrl());
  }

  /**
   * A literal slug of "0" is a real slug, not a missing one.
   *
   * PHP's empty() treats the string "0" as empty, which would wrongly divert
   * a route whose headsign-derived slug happens to be "0" to the search
   * page instead of its three-segment timetable URL.
   *
   * Mutation check: reverting the controller's guard to `empty($slug)` makes
   * the target-URL assertion fail, because the single-match branch would
   * then redirect to the search page instead of the timetable URL.
   */
  public function testSingleMatchWithZeroSlugRedirectsToTimetable(): void {
    $this->createRoute('R7', 'OP539', 'X8', '0');

    $response = $this->requestOldPath('OP539', 'X8');

    $this->assertInstanceOf(LocalRedirectResponse::class, $response);
    $this->assertSame(302, $response->getStatusCode());
    $this->assertSame('/buses/routes/OP539/X8/0', $response->getTargetUrl());
  }

  /**
   * The 302 single-match target carries the incoming query string through.
   *
   * The old and new timetable pages are the same view with the same exposed
   * filter identifiers, so a bookmarked URL keeps the direction the visitor
   * had selected instead of landing on the view's default.
   *
   * Mutation check: dropping ['query' => $query] from the single-match
   * Url::fromRoute() call makes the target-URL assertion fail, because the
   * redirect would land on the bare three-segment path.
   */
  public function testSingleMatchRedirectPreservesQueryString(): void {
    $this->createRoute('R1', 'OP539', 'X5', 'keswick-penrith');

    $response = $this->requestOldPath('OP539', 'X5', ['bustimes_direction_id' => '1']);

    $this->assertInstanceOf(LocalRedirectResponse::class, $response);
    $this->assertSame(302, $response->getStatusCode());
    $this->assertSame(
      '/buses/routes/OP539/X5/keswick-penrith?bustimes_direction_id=1',
      $response->getTargetUrl(),
    );
  }

  /**
   * The 302 search target carries the incoming query string through too.
   *
   * The route number filter still wins over any same-named incoming
   * parameter, so the search page is always narrowed to the route the
   * visitor asked for.
   *
   * Mutation check: dropping $query from the multi-match Url::fromRoute()
   * call loses bustimes_direction_id from the target and fails the first
   * assertion; swapping array_merge() for the `+` operator lets the incoming
   * bustimes_route_short_name win and fails the second.
   */
  public function testMultiMatchRedirectPreservesQueryStringButKeepsItsFilter(): void {
    $this->createRoute('R4', 'OP261', 'X12', 'the-crown');
    $this->createRoute('R5', 'OP261', 'X12', 'the-crown-2');

    $response = $this->requestOldPath('OP261', 'X12', [
      'bustimes_direction_id' => '1',
      'bustimes_route_short_name' => 'SPOOFED',
    ]);

    $this->assertInstanceOf(LocalRedirectResponse::class, $response);
    $this->assertStringContainsString('bustimes_direction_id=1', $response->getTargetUrl());
    $this->assertStringContainsString('bustimes_route_short_name=X12', $response->getTargetUrl());
    $this->assertStringNotContainsString('SPOOFED', $response->getTargetUrl());
  }

  /**
   * The redirect varies on the query string it now passes through.
   *
   * Mutation check: removing addCacheContexts(['url.query_args']) from the
   * controller makes this assertion fail, and a cached redirect could then be
   * served to a request that arrived with different exposed filter values.
   */
  public function testRedirectVariesOnQueryArgs(): void {
    $this->createRoute('R1', 'OP539', 'X5', 'keswick-penrith');

    $response = $this->requestOldPath('OP539', 'X5', ['bustimes_direction_id' => '1']);

    $this->assertInstanceOf(LocalRedirectResponse::class, $response);
    $this->assertContains('url.query_args', $response->getCacheableMetadata()->getCacheContexts());
  }

  /**
   * No match gives the site's themed 404 page, not a bare empty one.
   *
   * The controller used to return CacheableResponse('', 404), which reached
   * the visitor as a 404 with an empty body: no navigation, no search, no
   * theme. It now throws, and core's exception handling turns that into the
   * site's rendered 404 page: an HtmlResponse carrying a full document,
   * which is what these assertions pin down.
   *
   * Mutation check: reverting the no-match branch to return
   * CacheableResponse('', 404) makes both the instanceof and the body
   * assertions fail.
   */
  public function testNoMatchGives404(): void {
    $response = $this->requestOldPath('NOPE', '999');

    $this->assertInstanceOf(HtmlResponse::class, $response);
    $this->assertSame(404, $response->getStatusCode());
    $this->assertStringContainsString('<!DOCTYPE html>', (string) $response->getContent());
  }

  /**
   * The 404 stays cacheable and keeps the route list tag.
   *
   * Core's DefaultExceptionHtmlSubscriber does
   * $response->addCacheableDependency($exception) on the rendered 404 page,
   * and CacheableMetadata::createFromObject() assigns max-age 0 to anything
   * that is not a CacheableDependencyInterface. Throwing a plain
   * NotFoundHttpException therefore makes every 404 this controller produces
   * uncacheable, which on a public site is an easy thing for a crawler to
   * exploit, and drops the tag that lets a later import clear the 404.
   *
   * Mutation check: swapping CacheableNotFoundHttpException for a plain
   * NotFoundHttpException makes both assertions fail, with max-age 0 and no
   * localgov_bus_route_list tag.
   */
  public function testNoMatch404IsCacheableAndTagged(): void {
    $response = $this->requestOldPath('NOPE', '999');

    $metadata = $response->getCacheableMetadata();
    $this->assertNotSame(0, $metadata->getCacheMaxAge());
    $this->assertContains('localgov_bus_route_list', $metadata->getCacheTags());
  }

}
