<?php

declare(strict_types=1);

namespace Drupal\Tests\localgov_bus_data\Kernel;

use PHPUnit\Framework\Attributes\Group;
use PHPUnit\Framework\Attributes\RunTestsInSeparateProcesses;
use Drupal\Core\Logger\RfcLogLevel;
use Drupal\KernelTests\KernelTestBase;
use Drupal\localgov_bus_data\Service\GtfsImportService;

/**
 * Kernel tests for GtfsImportService::importShapes().
 *
 * ImportShapes() used to truncate localgov_bus_shape before checking whether
 * shapes.txt had been staged at all, so an import whose feed shipped no
 * shapes emptied the table and imported nothing over it: every route map
 * silently fell back to straight lines. The truncate now happens only once a
 * replacement is known to be readable.
 *
 * importShapes() is private, so it is invoked reflectively rather than
 * through a full 300k-row import run.
 *
 * @coversDefaultClass \Drupal\localgov_bus_data\Service\GtfsImportService
 * @group localgov_bus_data
 */
#[Group('localgov_bus_data')]
#[RunTestsInSeparateProcesses]
final class GtfsImportServiceShapesKernelTest extends KernelTestBase {

  /**
   * {@inheritdoc}
   */
  protected static $modules = [
    'system',
    'user',
    'field',
    'file',
    'datetime',
    'geofield',
    'migrate',
    'dblog',
    'localgov_bus_data',
  ];

  /**
   * The service under test.
   */
  private GtfsImportService $service;

  /**
   * Absolute path to the live GTFS staging directory.
   */
  private string $stagingDir;

  /**
   * {@inheritdoc}
   */
  protected function setUp(): void {
    parent::setUp();

    $this->installEntitySchema('user');
    $this->installEntitySchema('file');
    $this->installSchema('localgov_bus_data', ['localgov_bus_shape']);
    // bulkTruncate() clears every bus entity table, so they all have to exist.
    foreach ([
      'localgov_bus_route',
      'localgov_bus_stop',
      'localgov_bus_calendar',
      'localgov_bus_trip',
      'localgov_bus_stop_time',
    ] as $entityTypeId) {
      $this->installEntitySchema($entityTypeId);
    }
    $this->installSchema('dblog', ['watchdog']);

    $this->service    = $this->container->get('localgov_bus_data.gtfs_import');
    $this->stagingDir = $this->service->getStagingDirPath();

    foreach (glob($this->stagingDir . '/*') ?: [] as $file) {
      if (is_file($file)) {
        unlink($file);
      }
    }
  }

  /**
   * Invokes the private importShapes() method.
   *
   * @return int
   *   Number of shape point rows inserted.
   */
  private function importShapes(): int {
    $method = new \ReflectionMethod(GtfsImportService::class, 'importShapes');
    return (int) $method->invoke($this->service);
  }

  /**
   * Inserts a shape point row so the table is not empty to begin with.
   *
   * @param string $shapeId
   *   Shape identifier.
   */
  private function seedShapePoint(string $shapeId): void {
    $this->container->get('database')->insert('localgov_bus_shape')
      ->fields([
        'shape_id'          => $shapeId,
        'shape_pt_lat'      => 54.9,
        'shape_pt_lon'      => -2.93,
        'shape_pt_sequence' => 1,
      ])
      ->execute();
  }

  /**
   * Counts the rows currently in localgov_bus_shape.
   *
   * @return int
   *   Row count.
   */
  private function countShapePoints(): int {
    return (int) $this->container->get('database')
      ->select('localgov_bus_shape', 's')
      ->countQuery()
      ->execute()
      ->fetchField();
  }

  /**
   * A missing shapes.txt leaves the existing rows alone and warns.
   */
  public function testMissingShapesFileLeavesExistingRowsUntouched(): void {
    $this->seedShapePoint('SH_EXISTING');
    $this->assertSame(1, $this->countShapePoints());
    $this->assertFileDoesNotExist($this->stagingDir . '/shapes.txt');

    $this->assertSame(0, $this->importShapes());

    $this->assertSame(
      1,
      $this->countShapePoints(),
      'A feed without shapes.txt must not empty the shape geometry table.',
    );

    $log = $this->container->get('database')
      ->select('watchdog', 'w')
      ->fields('w', ['severity', 'message'])
      ->condition('w.type', 'localgov_bus_data')
      ->execute()
      ->fetchAll();

    $warnings = array_filter(
      $log,
      static fn (object $row): bool => (int) $row->severity === RfcLogLevel::WARNING,
    );
    $this->assertNotEmpty($warnings, 'The skip must be logged at warning level.');
    $this->assertStringContainsString(
      'No shapes.txt staged',
      (string) reset($warnings)->message,
    );
  }

  /**
   * A staged shapes.txt replaces the existing rows.
   */
  public function testStagedShapesFileReplacesExistingRows(): void {
    $this->seedShapePoint('SH_EXISTING');

    file_put_contents($this->stagingDir . '/shapes.txt', <<<CSV
    shape_id,shape_pt_lat,shape_pt_lon,shape_pt_sequence
    SH_NEW,54.90,-2.93,1
    SH_NEW,54.91,-2.94,2

    CSV);

    $this->assertSame(2, $this->importShapes());
    $this->assertSame(2, $this->countShapePoints());

    $ids = $this->container->get('database')
      ->select('localgov_bus_shape', 's')
      ->fields('s', ['shape_id'])
      ->distinct()
      ->execute()
      ->fetchCol();
    $this->assertSame(['SH_NEW'], $ids);
  }

  /**
   * A full import that stages no shapes.txt keeps the existing geometry.
   *
   * This is the whole point of the change, and it only holds because
   * bulkTruncate() no longer clears localgov_bus_shape itself. Guarding
   * importShapes() alone would have been useless on the full-import path,
   * where bulkTruncate() runs first and had already emptied the table.
   */
  public function testBulkTruncateThenMissingShapesFileKeepsExistingRows(): void {
    $this->seedShapePoint('SH_EXISTING');

    $this->service->bulkTruncate();
    $this->assertSame(
      1,
      $this->countShapePoints(),
      'bulkTruncate() must leave shape geometry alone.',
    );

    $this->assertSame(0, $this->importShapes());
    $this->assertSame(1, $this->countShapePoints());
  }

  /**
   * A staged shapes.txt missing required columns does not empty the table.
   *
   * ProcessShapesChunk() falls back to positional indices, so a readable
   * header is not on its own enough to justify discarding what is there.
   */
  public function testShapesFileWithWrongColumnsLeavesExistingRows(): void {
    $this->seedShapePoint('SH_EXISTING');

    file_put_contents($this->stagingDir . '/shapes.txt', <<<CSV
    id,lat,lon,seq
    SH_NEW,54.90,-2.93,1

    CSV);

    $this->assertSame(0, $this->importShapes());
    $this->assertSame(
      1,
      $this->countShapePoints(),
      'A shapes.txt with the wrong columns must not empty the table.',
    );
  }

  /**
   * An unreadable header aborts before anything is truncated.
   */
  public function testUnreadableHeaderLeavesExistingRows(): void {
    $this->seedShapePoint('SH_EXISTING');
    file_put_contents($this->stagingDir . '/shapes.txt', '');

    try {
      $this->importShapes();
      $this->fail('An unreadable shapes.txt header must throw.');
    }
    catch (\RuntimeException $e) {
      $this->assertStringContainsString('no readable header row', $e->getMessage());
    }

    $this->assertSame(1, $this->countShapePoints());
  }

  /**
   * The chunk loop keeps reading past a chunk that inserts nothing.
   *
   * ProcessShapesChunk() reports rows inserted, not rows read, so a run of
   * unusable rows must not be mistaken for the end of the file.
   */
  public function testChunkLoopReadsPastRowsThatInsertNothing(): void {
    $rows = "shape_id,shape_pt_lat,shape_pt_lon,shape_pt_sequence\n";
    // A full chunk of rows with non-numeric coordinates: all are skipped, so
    // the chunk inserts nothing even though the file continues past it.
    for ($i = 1; $i <= 10000; $i++) {
      $rows .= "SH_BAD,not-a-number,not-a-number,{$i}\n";
    }
    $rows .= "SH_GOOD,54.90,-2.93,1\n";
    file_put_contents($this->stagingDir . '/shapes.txt', $rows);

    $this->assertSame(
      1,
      $this->importShapes(),
      'The loop must reach the usable row after the unusable ones.',
    );
    $this->assertSame(1, $this->countShapePoints());
  }

}
