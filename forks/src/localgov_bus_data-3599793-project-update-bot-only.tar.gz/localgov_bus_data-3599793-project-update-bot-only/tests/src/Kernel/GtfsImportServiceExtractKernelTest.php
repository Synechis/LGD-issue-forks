<?php

declare(strict_types=1);

namespace Drupal\Tests\localgov_bus_data\Kernel;

use PHPUnit\Framework\Attributes\Group;
use PHPUnit\Framework\Attributes\RunTestsInSeparateProcesses;
use Drupal\KernelTests\KernelTestBase;
use Drupal\localgov_bus_data\Service\GtfsImportService;

/**
 * Kernel tests for GtfsImportService::extractZipSafely().
 *
 * The bulk GTFS archive is extracted entry by entry so each extraction can be
 * checked and the database keepalive can run between entries. That rewrote a
 * path-traversal guard, and a rewritten security guard needs a test that says
 * it still rejects rather than an assumption that it does.
 *
 * extractZipSafely() is private and shared by run() and batchExtract(), so it
 * is invoked reflectively rather than through a full import.
 *
 * @group localgov_bus_data
 */
#[Group('localgov_bus_data')]
#[RunTestsInSeparateProcesses]
final class GtfsImportServiceExtractKernelTest extends KernelTestBase {

  /**
   * {@inheritdoc}
   */
  protected static $modules = [
    'system',
    'user',
    'field',
    'file',
    'datetime',
    'geofield',
    'migrate',
    'localgov_bus_data',
  ];

  /**
   * The service under test.
   */
  private GtfsImportService $service;

  /**
   * Absolute path to a real working directory.
   *
   * KernelTestBase mounts the public files directory on vfs://, and
   * ZipArchive is a C extension that cannot see PHP stream wrappers, so the
   * fixtures need somewhere on the real filesystem.
   */
  private string $workDir;

  /**
   * {@inheritdoc}
   */
  protected function setUp(): void {
    parent::setUp();

    $this->installEntitySchema('user');
    $this->installEntitySchema('file');

    $this->service = $this->container->get('localgov_bus_data.gtfs_import');

    $this->workDir = sys_get_temp_dir() . '/gtfs_extract_test_' . uniqid('', TRUE);
    $this->assertTrue(
      mkdir($this->workDir, 0755, TRUE),
      'Could not create the fixture directory under ' . sys_get_temp_dir(),
    );
  }

  /**
   * {@inheritdoc}
   */
  protected function tearDown(): void {
    $this->deleteRecursive($this->workDir);
    parent::tearDown();
  }

  /**
   * Removes a directory and everything below it.
   *
   * @param string $dir
   *   Absolute path.
   */
  private function deleteRecursive(string $dir): void {
    if (!is_dir($dir)) {
      return;
    }
    foreach (scandir($dir) ?: [] as $entry) {
      if ($entry === '.' || $entry === '..') {
        continue;
      }
      $path = $dir . '/' . $entry;
      is_dir($path) ? $this->deleteRecursive($path) : unlink($path);
    }
    rmdir($dir);
  }

  /**
   * Invokes the private extractZipSafely() method.
   *
   * @param string $zipPath
   *   Absolute path to the archive.
   * @param string $targetDir
   *   Absolute path to extract into.
   */
  private function extractZipSafely(string $zipPath, string $targetDir): void {
    $method = new \ReflectionMethod(GtfsImportService::class, 'extractZipSafely');
    $method->invoke($this->service, $zipPath, $targetDir);
  }

  /**
   * Builds a ZIP archive from a map of entry name to contents.
   *
   * @param array<string, string> $entries
   *   Entry name keyed to file contents.
   *
   * @return string
   *   Absolute path to the archive.
   */
  private function makeZip(array $entries): string {
    $path = $this->workDir . '/fixture_' . count($entries) . '_' . mt_rand() . '.zip';
    $zip  = new \ZipArchive();
    $this->assertTrue($zip->open($path, \ZipArchive::CREATE | \ZipArchive::OVERWRITE));
    foreach ($entries as $name => $contents) {
      $zip->addFromString($name, $contents);
    }
    $zip->close();
    return $path;
  }

  /**
   * A well-formed archive extracts every entry.
   */
  public function testExtractZipSafelyExtractsEveryEntry(): void {
    $zipPath = $this->makeZip([
      'agency.txt' => "agency_id,agency_name\nOP1,Stagecoach\n",
      'stops.txt'  => "stop_id,stop_name\nS1,Carlisle\n",
    ]);

    $target = $this->workDir . '/extract_ok';
    mkdir($target, 0755, TRUE);

    $this->extractZipSafely($zipPath, $target);

    $this->assertFileExists($target . '/agency.txt');
    $this->assertFileExists($target . '/stops.txt');
    $this->assertStringContainsString('Stagecoach', (string) file_get_contents($target . '/agency.txt'));
  }

  /**
   * A traversal entry is rejected and never written outside the target.
   *
   * This is the guard that was rewritten when extraction moved to a per-entry
   * loop, so it is asserted directly rather than assumed.
   */
  public function testExtractZipSafelyRejectsTraversalEntry(): void {
    $zipPath = $this->makeZip([
      'agency.txt'      => "agency_id,agency_name\nOP1,Stagecoach\n",
      '../escaped.txt'  => "pwned\n",
    ]);

    $target = $this->workDir . '/extract_traversal';
    mkdir($target, 0755, TRUE);
    $escapee = dirname($target) . '/escaped.txt';

    try {
      $this->extractZipSafely($zipPath, $target);
      $this->fail('A traversal ZIP entry must be rejected.');
    }
    catch (\RuntimeException $e) {
      $this->assertStringContainsString('Unsafe ZIP entry', $e->getMessage());
    }

    $this->assertFileDoesNotExist($escapee, 'A traversal entry must never be written.');
    $this->assertFileDoesNotExist($target . '/escaped.txt');
  }

  /**
   * An absolute entry path is rejected too.
   */
  public function testExtractZipSafelyRejectsAbsoluteEntry(): void {
    $zipPath = $this->makeZip(['/etc/evil.txt' => "pwned\n"]);

    $target = $this->workDir . '/extract_absolute';
    mkdir($target, 0755, TRUE);

    $this->expectException(\RuntimeException::class);
    $this->expectExceptionMessage('Unsafe ZIP entry');
    $this->extractZipSafely($zipPath, $target);
  }

}
