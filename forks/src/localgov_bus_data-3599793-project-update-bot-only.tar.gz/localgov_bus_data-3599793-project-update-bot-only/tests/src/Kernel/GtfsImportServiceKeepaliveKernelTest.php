<?php

declare(strict_types=1);

namespace Drupal\Tests\localgov_bus_data\Kernel;

use PHPUnit\Framework\Attributes\Group;
use PHPUnit\Framework\Attributes\RunTestsInSeparateProcesses;
use Drupal\KernelTests\KernelTestBase;
use Drupal\localgov_bus_data\Service\GtfsImportService;
use Drupal\Tests\localgov_bus_data\Traits\MakesDatabaseKeepaliveTrait;

/**
 * Kernel tests for the keepalive pings inside GtfsImportService.
 *
 * GtfsFilter's row loops are covered at the unit level. The two phases either
 * side of them are not, and they are long: unpacking the archive, and copying
 * the filtered files into staging. Both sit between the last query of one
 * phase and the first query of the next, which is exactly the window that
 * gets the connection reaped.
 *
 * A spy keepalive is substituted in the container so the pings can be counted
 * without a real import.
 *
 * @group localgov_bus_data
 */
#[Group('localgov_bus_data')]
#[RunTestsInSeparateProcesses]
final class GtfsImportServiceKeepaliveKernelTest extends KernelTestBase {

  use MakesDatabaseKeepaliveTrait;

  /**
   * {@inheritdoc}
   */
  protected static $modules = [
    'system',
    'user',
    'field',
    'file',
    'datetime',
    'geofield',
    'migrate',
    'localgov_bus_data',
  ];

  /**
   * The service under test.
   */
  private GtfsImportService $service;

  /**
   * Number of keepalive queries issued so far.
   */
  private int $queryCount = 0;

  /**
   * Absolute path to a real working directory (ZipArchive cannot use vfs).
   */
  private string $workDir;

  /**
   * {@inheritdoc}
   */
  protected function setUp(): void {
    parent::setUp();

    $this->installEntitySchema('user');
    $this->installEntitySchema('file');

    // Substitute the spy before the import service is instantiated.
    $this->container->set(
      'localgov_bus_data.database_keepalive',
      $this->makeSpyKeepalive($this->queryCount),
    );
    $this->service = $this->container->get('localgov_bus_data.gtfs_import');

    $this->workDir = sys_get_temp_dir() . '/gtfs_keepalive_kernel_' . uniqid('', TRUE);
    $this->assertTrue(
      mkdir($this->workDir, 0755, TRUE),
      'Could not create the fixture directory under ' . sys_get_temp_dir(),
    );
  }

  /**
   * {@inheritdoc}
   */
  protected function tearDown(): void {
    foreach (glob($this->workDir . '/*') ?: [] as $file) {
      if (is_file($file)) {
        unlink($file);
      }
    }
    if (is_dir($this->workDir)) {
      rmdir($this->workDir);
    }
    parent::tearDown();
  }

  /**
   * Invokes a private method on the service under test.
   *
   * @param string $name
   *   Method name.
   * @param mixed ...$args
   *   Arguments.
   *
   * @return mixed
   *   The method's return value.
   */
  private function invokePrivate(string $name, ...$args): mixed {
    $method = new \ReflectionMethod(GtfsImportService::class, $name);
    return $method->invoke($this->service, ...$args);
  }

  /**
   * Unpacking the archive pings between entries.
   */
  public function testExtractionPingsBetweenEntries(): void {
    $zipPath = $this->workDir . '/bulk.zip';
    $zip     = new \ZipArchive();
    $this->assertTrue($zip->open($zipPath, \ZipArchive::CREATE | \ZipArchive::OVERWRITE));
    $zip->addFromString('agency.txt', "agency_id,agency_name\nOP1,Stagecoach\n");
    $zip->addFromString('stops.txt', "stop_id,stop_name\nS1,Carlisle\n");
    $zip->addFromString('trips.txt', "route_id,service_id,trip_id\nR1,SV1,T1\n");
    $zip->close();

    $target = $this->workDir . '/out';
    mkdir($target, 0755, TRUE);

    $this->assertSame(0, $this->queryCount);
    $this->invokePrivate('extractZipSafely', $zipPath, $target);

    $this->assertGreaterThanOrEqual(
      3,
      $this->queryCount,
      'Unpacking the archive must ping once per entry.',
    );

    foreach (glob($target . '/*') ?: [] as $file) {
      unlink($file);
    }
    rmdir($target);
  }

  /**
   * Copying a large filtered file into staging pings during the row loop.
   */
  public function testMergePingsDuringLongCopy(): void {
    $sourceDir  = $this->workDir;
    $stagingDir = $this->service->getStagingDirPath();

    $handle = fopen($sourceDir . '/stop_times.txt', 'w');
    $this->assertNotFalse($handle);
    fwrite($handle, "trip_id,arrival_time,departure_time,stop_id,stop_sequence\n");
    // One row past the ping interval, so exactly one ping is due.
    for ($i = 1; $i <= 10001; $i++) {
      fwrite($handle, "T1,09:00:00,09:00:00,S1,{$i}\n");
    }
    fclose($handle);

    $this->assertSame(0, $this->queryCount);
    $this->invokePrivate('mergeGtfsFiles', $sourceDir, $stagingDir);

    $this->assertGreaterThanOrEqual(
      1,
      $this->queryCount,
      'Copying a file longer than the ping interval into staging must ping.',
    );
    $this->assertFileExists($stagingDir . '/stop_times.txt');
  }

  /**
   * A short copy does not put a query into the row loop.
   */
  public function testShortMergeNeverPings(): void {
    $sourceDir  = $this->workDir;
    $stagingDir = $this->service->getStagingDirPath();

    file_put_contents(
      $sourceDir . '/stops.txt',
      "stop_id,stop_name\nS1,Carlisle\nS2,Penrith\n",
    );

    $this->invokePrivate('mergeGtfsFiles', $sourceDir, $stagingDir);

    $this->assertSame(0, $this->queryCount);
  }

}
