<?php

declare(strict_types=1);

namespace Drupal\Tests\localgov_bus_data\Kernel;

use PHPUnit\Framework\Attributes\Group;
use PHPUnit\Framework\Attributes\RunTestsInSeparateProcesses;
use Drupal\KernelTests\KernelTestBase;
use Drupal\localgov_bus_data\Entity\BusCalendar;
use Drupal\localgov_bus_data\Entity\BusRoute;
use Drupal\localgov_bus_data\Entity\BusStop;
use Drupal\localgov_bus_data\Entity\BusStopTime;
use Drupal\localgov_bus_data\Entity\BusTrip;
use Drupal\localgov_bus_data\Service\RoutePolylineService;

/**
 * Kernel tests for the DB-touching parts of RoutePolylineService.
 *
 * The unit suite covers the pure segment/polyline builders in isolation.
 * These tests exercise the real entity queries and the localgov_bus_shape
 * table together, proving that a trip carrying a shape_id draws the
 * road-following geometry and that a trip without one falls back to
 * straight stop-to-stop segments.
 *
 * @group localgov_bus_data
 */
#[Group('localgov_bus_data')]
#[RunTestsInSeparateProcesses]
final class RoutePolylineServiceKernelTest extends KernelTestBase {

  /**
   * {@inheritdoc}
   */
  protected static $modules = [
    'system',
    'field',
    'file',
    'datetime',
    'geofield',
    'migrate',
    'localgov_bus_data',
  ];

  /**
   * The service under test.
   */
  private RoutePolylineService $service;

  /**
   * {@inheritdoc}
   */
  protected function setUp(): void {
    parent::setUp();

    $this->installEntitySchema('localgov_bus_route');
    $this->installEntitySchema('localgov_bus_trip');
    $this->installEntitySchema('localgov_bus_calendar');
    $this->installEntitySchema('localgov_bus_stop');
    $this->installEntitySchema('localgov_bus_stop_time');
    $this->installSchema('localgov_bus_data', ['localgov_bus_shape']);

    $this->service = $this->container->get('localgov_bus_data.route_polyline');
  }

  /**
   * Creates a route entity.
   */
  private function createRoute(string $agencyId, string $shortName): BusRoute {
    $route = BusRoute::create([
      'bustimes_route_id' => $agencyId . '-' . $shortName,
      'bustimes_route_short_name' => $shortName,
      'bustimes_agency_id' => $agencyId,
    ]);
    $route->save();
    return $route;
  }

  /**
   * Creates a calendar entity that runs on weekdays and covers today.
   */
  private function createWeekdayCalendar(string $serviceId): BusCalendar {
    $calendar = BusCalendar::create([
      'bustimes_service_id' => $serviceId,
      'bustimes_weekday' => TRUE,
      'bustimes_start_date' => '2020-01-01',
      'bustimes_end_date' => '2099-12-31',
    ]);
    $calendar->save();
    return $calendar;
  }

  /**
   * Creates a stop entity at the given coordinates.
   */
  private function createStop(string $stopId, float $lat, float $lon): BusStop {
    $stop = BusStop::create([
      'bustimes_stop_id' => $stopId,
      'bustimes_stop_name' => 'Stop ' . $stopId,
      'bustimes_stop_lat' => $lat,
      'bustimes_stop_lon' => $lon,
    ]);
    $stop->save();
    return $stop;
  }

  /**
   * Inserts an ordered shape point into localgov_bus_shape.
   */
  private function insertShapePoint(string $shapeId, float $lat, float $lon, int $sequence): void {
    $this->container->get('database')->insert('localgov_bus_shape')
      ->fields([
        'shape_id' => $shapeId,
        'shape_pt_lat' => $lat,
        'shape_pt_lon' => $lon,
        'shape_pt_sequence' => $sequence,
      ])
      ->execute();
  }

  /**
   * Reduces polylines to comparable "lat,lon-lat,lon-…" strings.
   *
   * @param array $polylines
   *   Polylines returned by getRoutePolylines().
   *
   * @return list<string>
   *   One string per polyline.
   */
  private function flatten(array $polylines): array {
    return array_map(
      static fn(array $line): string => implode('-', array_map(
        static fn(array $p): string => sprintf('%s,%s', $p['lat'], $p['lon']),
        $line,
      )),
      $polylines,
    );
  }

  /**
   * A trip with an imported shape draws the road-following polyline.
   *
   * The stop-to-stop straight segment must not win over the shape geometry.
   */
  public function testTripWithShapeDrawsRoadFollowingPolyline(): void {
    $route = $this->createRoute('ARBA', '685');
    $calendar = $this->createWeekdayCalendar('SVC1');
    $trip = BusTrip::create([
      'bustimes_trip_id' => 'T1',
      'bustimes_route_id' => $route->id(),
      'bustimes_service_id' => $calendar->id(),
      'bustimes_direction_id' => 0,
      'bustimes_shape_id' => 'SHAPE1',
    ]);
    $trip->save();

    $stopA = $this->createStop('S1', 54.0, -3.0);
    $stopB = $this->createStop('S2', 54.1, -3.1);
    BusStopTime::create([
      'bustimes_trip_id' => $trip->id(),
      'bustimes_stop_id' => $stopA->id(),
      'bustimes_stop_sequence' => 1,
    ])->save();
    BusStopTime::create([
      'bustimes_trip_id' => $trip->id(),
      'bustimes_stop_id' => $stopB->id(),
      'bustimes_stop_sequence' => 2,
    ])->save();

    // The shape bends through a midpoint the straight stop segment does not
    // pass through, so the two are distinguishable in the assertion.
    $this->insertShapePoint('SHAPE1', 54.0, -3.0, 1);
    $this->insertShapePoint('SHAPE1', 54.05, -3.08, 2);
    $this->insertShapePoint('SHAPE1', 54.1, -3.1, 3);

    $polylines = $this->service->getRoutePolylines('ARBA', '685', '0', 'weekdays', '2026-07-24');

    $this->assertSame(
      ['54,-3-54.05,-3.08-54.1,-3.1'],
      $this->flatten($polylines),
    );
  }

  /**
   * A trip with no shape_id falls back to the straight stop-to-stop segment.
   */
  public function testTripWithoutShapeFallsBackToStraightSegments(): void {
    $route = $this->createRoute('ARBA', '686');
    $calendar = $this->createWeekdayCalendar('SVC2');
    $trip = BusTrip::create([
      'bustimes_trip_id' => 'T2',
      'bustimes_route_id' => $route->id(),
      'bustimes_service_id' => $calendar->id(),
      'bustimes_direction_id' => 0,
    ]);
    $trip->save();

    $stopA = $this->createStop('S3', 55.0, -2.0);
    $stopB = $this->createStop('S4', 55.1, -2.1);
    BusStopTime::create([
      'bustimes_trip_id' => $trip->id(),
      'bustimes_stop_id' => $stopA->id(),
      'bustimes_stop_sequence' => 1,
    ])->save();
    BusStopTime::create([
      'bustimes_trip_id' => $trip->id(),
      'bustimes_stop_id' => $stopB->id(),
      'bustimes_stop_sequence' => 2,
    ])->save();

    $polylines = $this->service->getRoutePolylines('ARBA', '686', '0', 'weekdays', '2026-07-24');

    $this->assertSame(
      ['55,-2-55.1,-2.1'],
      $this->flatten($polylines),
    );
  }

}
