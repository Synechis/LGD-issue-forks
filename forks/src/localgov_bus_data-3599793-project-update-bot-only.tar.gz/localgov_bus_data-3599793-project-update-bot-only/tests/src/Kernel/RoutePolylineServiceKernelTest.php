<?php

declare(strict_types=1);

namespace Drupal\Tests\localgov_bus_data\Kernel;

use PHPUnit\Framework\Attributes\Group;
use PHPUnit\Framework\Attributes\RunTestsInSeparateProcesses;
use Drupal\KernelTests\KernelTestBase;
use Drupal\localgov_bus_data\Entity\BusCalendar;
use Drupal\localgov_bus_data\Entity\BusRoute;
use Drupal\localgov_bus_data\Entity\BusStop;
use Drupal\localgov_bus_data\Entity\BusStopTime;
use Drupal\localgov_bus_data\Entity\BusTrip;
use Drupal\localgov_bus_data\Service\RoutePolylineService;

/**
 * Kernel tests for the DB-touching parts of RoutePolylineService.
 *
 * The unit suite covers the pure segment/polyline builders in isolation.
 * These tests exercise the real entity queries and the localgov_bus_shape
 * table together, proving that a trip carrying a shape_id draws the
 * road-following geometry and that a trip without one falls back to
 * straight stop-to-stop segments.
 *
 * @group localgov_bus_data
 */
#[Group('localgov_bus_data')]
#[RunTestsInSeparateProcesses]
final class RoutePolylineServiceKernelTest extends KernelTestBase {

  /**
   * {@inheritdoc}
   */
  protected static $modules = [
    'system',
    'field',
    'file',
    'datetime',
    'geofield',
    'migrate',
    'localgov_bus_data',
  ];

  /**
   * The service under test.
   */
  private RoutePolylineService $service;

  /**
   * {@inheritdoc}
   */
  protected function setUp(): void {
    parent::setUp();

    $this->installEntitySchema('localgov_bus_route');
    $this->installEntitySchema('localgov_bus_trip');
    $this->installEntitySchema('localgov_bus_calendar');
    $this->installEntitySchema('localgov_bus_stop');
    $this->installEntitySchema('localgov_bus_stop_time');
    $this->installSchema('localgov_bus_data', ['localgov_bus_shape']);

    $this->service = $this->container->get('localgov_bus_data.route_polyline');
  }

  /**
   * Creates a route entity.
   */
  private function createRoute(string $agencyId, string $shortName, string $slug): BusRoute {
    $route = BusRoute::create([
      'bustimes_route_id' => $agencyId . '-' . $shortName . '-' . $slug,
      'bustimes_route_short_name' => $shortName,
      'bustimes_agency_id' => $agencyId,
      'bustimes_slug' => $slug,
    ]);
    $route->save();
    return $route;
  }

  /**
   * Creates a calendar entity that runs on weekdays and covers today.
   */
  private function createWeekdayCalendar(string $serviceId): BusCalendar {
    $calendar = BusCalendar::create([
      'bustimes_service_id' => $serviceId,
      'bustimes_weekday' => TRUE,
      'bustimes_start_date' => '2020-01-01',
      'bustimes_end_date' => '2099-12-31',
    ]);
    $calendar->save();
    return $calendar;
  }

  /**
   * Creates a stop entity at the given coordinates.
   */
  private function createStop(string $stopId, float $lat, float $lon): BusStop {
    $stop = BusStop::create([
      'bustimes_stop_id' => $stopId,
      'bustimes_stop_name' => 'Stop ' . $stopId,
      'bustimes_stop_lat' => $lat,
      'bustimes_stop_lon' => $lon,
    ]);
    $stop->save();
    return $stop;
  }

  /**
   * Inserts an ordered shape point into localgov_bus_shape.
   */
  private function insertShapePoint(string $shapeId, float $lat, float $lon, int $sequence): void {
    $this->container->get('database')->insert('localgov_bus_shape')
      ->fields([
        'shape_id' => $shapeId,
        'shape_pt_lat' => $lat,
        'shape_pt_lon' => $lon,
        'shape_pt_sequence' => $sequence,
      ])
      ->execute();
  }

  /**
   * Reduces polylines to comparable "lat,lon-lat,lon-…" strings.
   *
   * @param array $polylines
   *   Polylines returned by getRoutePolylines().
   *
   * @return list<string>
   *   One string per polyline.
   */
  private function flatten(array $polylines): array {
    return array_map(
      static fn(array $line): string => implode('-', array_map(
        static fn(array $p): string => sprintf('%s,%s', $p['lat'], $p['lon']),
        $line,
      )),
      $polylines,
    );
  }

  /**
   * A trip with an imported shape draws the road-following polyline.
   *
   * The stop-to-stop straight segment must not win over the shape geometry.
   */
  public function testTripWithShapeDrawsRoadFollowingPolyline(): void {
    $route = $this->createRoute('ARBA', '685', 'keswick');
    $calendar = $this->createWeekdayCalendar('SVC1');
    $trip = BusTrip::create([
      'bustimes_trip_id' => 'T1',
      'bustimes_route_id' => $route->id(),
      'bustimes_service_id' => $calendar->id(),
      'bustimes_direction_id' => 0,
      'bustimes_shape_id' => 'SHAPE1',
    ]);
    $trip->save();

    $stopA = $this->createStop('S1', 54.0, -3.0);
    $stopB = $this->createStop('S2', 54.1, -3.1);
    BusStopTime::create([
      'bustimes_trip_id' => $trip->id(),
      'bustimes_stop_id' => $stopA->id(),
      'bustimes_stop_sequence' => 1,
    ])->save();
    BusStopTime::create([
      'bustimes_trip_id' => $trip->id(),
      'bustimes_stop_id' => $stopB->id(),
      'bustimes_stop_sequence' => 2,
    ])->save();

    // The shape bends through a midpoint the straight stop segment does not
    // pass through, so the two are distinguishable in the assertion.
    $this->insertShapePoint('SHAPE1', 54.0, -3.0, 1);
    $this->insertShapePoint('SHAPE1', 54.05, -3.08, 2);
    $this->insertShapePoint('SHAPE1', 54.1, -3.1, 3);

    $polylines = $this->service->getRoutePolylines('ARBA', '685', 'keswick', '0', 'weekdays', '2026-07-24');

    $this->assertSame(
      ['54,-3-54.05,-3.08-54.1,-3.1'],
      $this->flatten($polylines),
    );
  }

  /**
   * A trip with no shape_id falls back to the straight stop-to-stop segment.
   */
  public function testTripWithoutShapeFallsBackToStraightSegments(): void {
    $route = $this->createRoute('ARBA', '686', 'penrith');
    $calendar = $this->createWeekdayCalendar('SVC2');
    $trip = BusTrip::create([
      'bustimes_trip_id' => 'T2',
      'bustimes_route_id' => $route->id(),
      'bustimes_service_id' => $calendar->id(),
      'bustimes_direction_id' => 0,
    ]);
    $trip->save();

    $stopA = $this->createStop('S3', 55.0, -2.0);
    $stopB = $this->createStop('S4', 55.1, -2.1);
    BusStopTime::create([
      'bustimes_trip_id' => $trip->id(),
      'bustimes_stop_id' => $stopA->id(),
      'bustimes_stop_sequence' => 1,
    ])->save();
    BusStopTime::create([
      'bustimes_trip_id' => $trip->id(),
      'bustimes_stop_id' => $stopB->id(),
      'bustimes_stop_sequence' => 2,
    ])->save();

    $polylines = $this->service->getRoutePolylines('ARBA', '686', 'penrith', '0', 'weekdays', '2026-07-24');

    $this->assertSame(
      ['55,-2-55.1,-2.1'],
      $this->flatten($polylines),
    );
  }

  /**
   * Two GTFS routes sharing an operator and route short name stay separate.
   *
   * This is the scenario bustimes_slug exists to disambiguate: distinct GTFS
   * routes that happen to share (agency_id, route_short_name). Without the
   * slug in the lookup, both routes' trips would match and their stops would
   * be blended into one segment union.
   */
  public function testSlugDisambiguatesRoutesSharingAgencyAndShortName(): void {
    $routeA = $this->createRoute('ARBA', '685', 'keswick');
    $calendarA = $this->createWeekdayCalendar('SVC3');
    $tripA = BusTrip::create([
      'bustimes_trip_id' => 'T3',
      'bustimes_route_id' => $routeA->id(),
      'bustimes_service_id' => $calendarA->id(),
      'bustimes_direction_id' => 0,
    ]);
    $tripA->save();
    $stopA1 = $this->createStop('S5', 54.0, -3.0);
    $stopA2 = $this->createStop('S6', 54.1, -3.1);
    BusStopTime::create([
      'bustimes_trip_id' => $tripA->id(),
      'bustimes_stop_id' => $stopA1->id(),
      'bustimes_stop_sequence' => 1,
    ])->save();
    BusStopTime::create([
      'bustimes_trip_id' => $tripA->id(),
      'bustimes_stop_id' => $stopA2->id(),
      'bustimes_stop_sequence' => 2,
    ])->save();

    $routeB = $this->createRoute('ARBA', '685', 'carlisle');
    $calendarB = $this->createWeekdayCalendar('SVC4');
    $tripB = BusTrip::create([
      'bustimes_trip_id' => 'T4',
      'bustimes_route_id' => $routeB->id(),
      'bustimes_service_id' => $calendarB->id(),
      'bustimes_direction_id' => 0,
    ]);
    $tripB->save();
    $stopB1 = $this->createStop('S7', 60.0, -1.0);
    $stopB2 = $this->createStop('S8', 60.1, -1.1);
    BusStopTime::create([
      'bustimes_trip_id' => $tripB->id(),
      'bustimes_stop_id' => $stopB1->id(),
      'bustimes_stop_sequence' => 1,
    ])->save();
    BusStopTime::create([
      'bustimes_trip_id' => $tripB->id(),
      'bustimes_stop_id' => $stopB2->id(),
      'bustimes_stop_sequence' => 2,
    ])->save();

    $polylines = $this->service->getRoutePolylines('ARBA', '685', 'keswick', '0', 'weekdays', '2026-07-24');

    $this->assertSame(
      ['54,-3-54.1,-3.1'],
      $this->flatten($polylines),
    );
  }

  /**
   * The slug also disambiguates the shape-geometry query, not only stops.
   *
   * LoadShapePoints() and loadTripPoints() are separate queries with their
   * own slug condition. This proves the shape-resolving query honours the
   * slug too: without it, route B's shape would be pulled in and preferred
   * over route A's.
   */
  public function testSlugDisambiguatesRoutesWithShapeGeometry(): void {
    $routeA = $this->createRoute('ARBA', '685', 'keswick');
    $calendarA = $this->createWeekdayCalendar('SVC5');
    $tripA = BusTrip::create([
      'bustimes_trip_id' => 'T5',
      'bustimes_route_id' => $routeA->id(),
      'bustimes_service_id' => $calendarA->id(),
      'bustimes_direction_id' => 0,
      'bustimes_shape_id' => 'SHAPE_A',
    ]);
    $tripA->save();
    $stopA1 = $this->createStop('S9', 54.0, -3.0);
    $stopA2 = $this->createStop('S10', 54.1, -3.1);
    BusStopTime::create([
      'bustimes_trip_id' => $tripA->id(),
      'bustimes_stop_id' => $stopA1->id(),
      'bustimes_stop_sequence' => 1,
    ])->save();
    BusStopTime::create([
      'bustimes_trip_id' => $tripA->id(),
      'bustimes_stop_id' => $stopA2->id(),
      'bustimes_stop_sequence' => 2,
    ])->save();
    $this->insertShapePoint('SHAPE_A', 54.0, -3.0, 1);
    $this->insertShapePoint('SHAPE_A', 54.05, -3.08, 2);
    $this->insertShapePoint('SHAPE_A', 54.1, -3.1, 3);

    $routeB = $this->createRoute('ARBA', '685', 'carlisle');
    $calendarB = $this->createWeekdayCalendar('SVC6');
    $tripB = BusTrip::create([
      'bustimes_trip_id' => 'T6',
      'bustimes_route_id' => $routeB->id(),
      'bustimes_service_id' => $calendarB->id(),
      'bustimes_direction_id' => 0,
      'bustimes_shape_id' => 'SHAPE_B',
    ]);
    $tripB->save();
    $stopB1 = $this->createStop('S11', 60.0, -1.0);
    $stopB2 = $this->createStop('S12', 60.1, -1.1);
    BusStopTime::create([
      'bustimes_trip_id' => $tripB->id(),
      'bustimes_stop_id' => $stopB1->id(),
      'bustimes_stop_sequence' => 1,
    ])->save();
    BusStopTime::create([
      'bustimes_trip_id' => $tripB->id(),
      'bustimes_stop_id' => $stopB2->id(),
      'bustimes_stop_sequence' => 2,
    ])->save();
    $this->insertShapePoint('SHAPE_B', 60.0, -1.0, 1);
    $this->insertShapePoint('SHAPE_B', 60.05, -1.08, 2);
    $this->insertShapePoint('SHAPE_B', 60.1, -1.1, 3);

    $polylines = $this->service->getRoutePolylines('ARBA', '685', 'keswick', '0', 'weekdays', '2026-07-24');

    $this->assertSame(
      ['54,-3-54.05,-3.08-54.1,-3.1'],
      $this->flatten($polylines),
    );
  }

}
