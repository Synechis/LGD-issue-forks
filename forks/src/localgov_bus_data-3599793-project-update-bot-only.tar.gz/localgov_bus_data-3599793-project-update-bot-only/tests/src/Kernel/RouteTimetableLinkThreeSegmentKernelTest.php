<?php

declare(strict_types=1);

namespace Drupal\Tests\localgov_bus_data\Kernel;

use PHPUnit\Framework\Attributes\Group;
use PHPUnit\Framework\Attributes\RunTestsInSeparateProcesses;
use Drupal\Core\Render\RenderContext;
use Drupal\KernelTests\KernelTestBase;
use Drupal\Tests\localgov_bus_data\Traits\InstallsBusDataViewsTrait;
use Drupal\localgov_bus_data\Entity\BusRoute;
use Drupal\views\ViewExecutable;
use Drupal\views\Views;

/**
 * Kernel tests for the three-segment bus route timetable URL.
 *
 * Issue #3599802 moved the timetable page from
 * buses/routes/{agency_id}/{route_short_name} to
 * buses/routes/{agency_id}/{route_short_name}/{slug}, so that distinct GTFS
 * routes merged onto one operator/route-number resolve to their own page
 * instead of colliding. These tests cover the two link-building call sites
 * that changed:
 * - The hook_preprocess_views_view_field() link built in
 *   localgov_bus_data.module for the stop detail page, which calls
 *   Url::fromRoute() directly against the real timetable route.
 * - The config-driven Views token link on the routes listing
 *   (page_search_bus_services), which needed the new excluded bustimes_slug
 *   field to make the token available.
 *
 * @group localgov_bus_data
 */
#[Group('localgov_bus_data')]
#[RunTestsInSeparateProcesses]
final class RouteTimetableLinkThreeSegmentKernelTest extends KernelTestBase {

  use InstallsBusDataViewsTrait;

  /**
   * {@inheritdoc}
   */
  protected static $modules = [
    'system',
    'user',
    'path_alias',
    'field',
    'text',
    'options',
    'file',
    'datetime',
    'geofield',
    'migrate',
    'migrate_plus',
    'views',
    'leaflet',
    'leaflet_markercluster',
    'leaflet_views',
    'localgov_bus_data',
  ];

  /**
   * {@inheritdoc}
   */
  protected function setUp(): void {
    parent::setUp();

    $this->installEntitySchema('localgov_bus_route');
    $this->installEntitySchema('path_alias');
    $this->installConfig(['system']);

    // Install only the three views this fix touches, rather than the whole
    // module's config: localgov_bus_stop_search ships with a pre-existing,
    // unrelated config schema gap (its entity-field columns are missing
    // schema for click_sort_column, settings, etc.) that would otherwise
    // abort installConfig() for every test in this class.
    foreach (['localgov_bus_routes', 'localgov_bus_stop_detail', 'localgov_bus_timetable'] as $view_id) {
      $this->installBusDataView($view_id);
    }

    $this->container->get('router.builder')->rebuild();
  }

  /**
   * Creates a route entity with the given denormalised fields.
   */
  private function createRoute(string $routeId, string $agencyId, string $shortName, string $slug): BusRoute {
    $route = BusRoute::create([
      'bustimes_route_id' => $routeId,
      'bustimes_agency_id' => $agencyId,
      'bustimes_route_short_name' => $shortName,
      'bustimes_slug' => $slug,
    ]);
    $route->save();
    return $route;
  }

  /**
   * A minimal duck-typed stand-in for the Views objects the hook reads.
   *
   * Localgov_bus_data_preprocess_views_view_field() only ever accesses
   * $view->id(), $view->current_display and $view->getExposedInput(), so a
   * full ViewExecutable (which needs a built display to be meaningful) is
   * unnecessary scaffolding for exercising the link-building logic itself.
   */
  private function stubView(string $id, string $currentDisplay): object {
    return new class($id, $currentDisplay) {

      /**
       * Mirrors ViewExecutable::$current_display, which the hook reads.
       */
      // phpcs:ignore Drupal.NamingConventions.ValidVariableName.LowerCamelName
      public string $current_display;

      public function __construct(private readonly string $id, string $currentDisplay) {
        $this->current_display = $currentDisplay;
      }

      /**
       * Mirrors ViewExecutable::id().
       */
      public function id(): string {
        return $this->id;
      }

      /**
       * Mirrors ViewExecutable::getExposedInput().
       */
      public function getExposedInput(): array {
        return [];
      }

    };
  }

  /**
   * The stop detail preprocess hook links to the three-segment timetable URL.
   *
   * Mutation check: reverting the hook to omit 'arg_2' => $slug reproduces
   * the pre-fix two-segment URL and fails this assertion.
   */
  public function testStopDetailPreprocessBuildsThreeSegmentLink(): void {
    $route = $this->createRoute('R1', 'OP539', 'X5', 'keswick-penrith');

    $variables = [
      'view' => $this->stubView('localgov_bus_stop_detail', 'page_bus_stop_detail'),
      'field' => (object) ['options' => ['id' => 'bustimes_route_short_name_1']],
      'row' => (object) ['_relationship_entities' => ['bustimes_route_id' => $route]],
      'output' => 'X5',
    ];

    localgov_bus_data_preprocess_views_view_field($variables);

    $this->assertIsArray($variables['output']);
    $url = $variables['output']['#url'];
    $this->assertSame('/buses/routes/OP539/X5/keswick-penrith?bustimes_direction_id=0', $url->toString());
  }

  /**
   * A route with no slug yet is not linked.
   *
   * Rather than linking to a broken two-segment path or a path with a
   * trailing empty segment.
   *
   * Mutation check: removing the `|| $slug === ''` guard from the hook makes
   * this test fail, because $variables['output'] would be overwritten with
   * a link array instead of being left as the original string.
   */
  public function testStopDetailPreprocessSkipsLinkWhenSlugMissing(): void {
    $route = $this->createRoute('R2', 'OP539', 'X6', '');

    $variables = [
      'view' => $this->stubView('localgov_bus_stop_detail', 'page_bus_stop_detail'),
      'field' => (object) ['options' => ['id' => 'bustimes_route_short_name_1']],
      'row' => (object) ['_relationship_entities' => ['bustimes_route_id' => $route]],
      'output' => 'X6',
    ];

    localgov_bus_data_preprocess_views_view_field($variables);

    $this->assertSame('X6', $variables['output']);
  }

  /**
   * The routes listing links routes to their own three-segment URL.
   *
   * Covers both a unique route and each route of a colliding pair.
   *
   * Mutation check: reverting the view's 'Route' field path token to
   * '/buses/routes/{{ bustimes_agency_id_2 }}/{{ bustimes_route_short_name }}'
   * (dropping the {{ bustimes_slug }} segment) makes the colliding-pair
   * assertion fail, because both rows would render the same href.
   */
  public function testRoutesListingLinksUniqueAndCollidingRoutesToDistinctUrls(): void {
    $this->createRoute('R3', 'OP539', 'X5', 'keswick-penrith');
    $this->createRoute('R4', 'OP261', 'X12', 'the-crown');
    $this->createRoute('R5', 'OP261', 'X12', 'the-crown-2');

    $view = Views::getView('localgov_bus_routes');
    $view->setDisplay('page_search_bus_services');
    $this->assertTrue($view->execute());

    $renderer = $this->container->get('renderer');
    $rendered = $renderer->executeInRenderContext(
      new RenderContext(),
      function () use ($view): array {
        $rendered = [];
        foreach ($view->result as $row) {
          $entity = $row->_entity;
          $this->assertInstanceOf(BusRoute::class, $entity);
          // The link's path tokens reference sibling fields, so those must
          // be rendered first for this row: Views populates a field's token
          // value from $field->last_render, which advancedRender() sets.
          $view->field['bustimes_agency_id_2']->advancedRender($row);
          $view->field['bustimes_slug']->advancedRender($row);
          $rendered[$entity->id()] = (string) $view->field['bustimes_route_short_name']->advancedRender($row);
        }
        return $rendered;
      },
    );

    $unique = $rendered[$this->routeEntityIdFor($view, 'R3')];
    $crown1 = $rendered[$this->routeEntityIdFor($view, 'R4')];
    $crown2 = $rendered[$this->routeEntityIdFor($view, 'R5')];

    $this->assertStringContainsString('href="/buses/routes/OP539/X5/keswick-penrith"', $unique);
    $this->assertStringContainsString('href="/buses/routes/OP261/X12/the-crown"', $crown1);
    $this->assertStringContainsString('href="/buses/routes/OP261/X12/the-crown-2"', $crown2);
    $this->assertNotSame($crown1, $crown2);
  }

  /**
   * The stop detail view's non-page displays also store the new path.
   *
   * Covers 'default' and 'attachment_bus_stop_detail_map', so the config is
   * correct wherever the field might be rendered as a link, even though
   * today those two displays keep make_link disabled and the page
   * display's real link is built by the .module hook covered above.
   *
   * Mutation check: reverting either display's path back to the
   * two-segment token string makes the matching assertion fail.
   */
  public function testStopDetailViewConfigStoresThreeSegmentPathOnBothDisplays(): void {
    $expected = '/buses/routes/{{ bustimes_agency_id__value }}/{{ bustimes_route_short_name_1__value }}/{{ bustimes_slug__value }}';

    /** @var \Drupal\views\Entity\View $view */
    $view = $this->container->get('entity_type.manager')
      ->getStorage('view')
      ->load('localgov_bus_stop_detail');

    $default = $view->getDisplay('default');
    $attachment = $view->getDisplay('attachment_bus_stop_detail_map');

    $this->assertSame($expected, $default['display_options']['fields']['bustimes_route_short_name_1']['alter']['path']);
    $this->assertSame($expected, $attachment['display_options']['fields']['bustimes_route_short_name_1']['alter']['path']);
    $this->assertArrayHasKey('bustimes_slug', $default['display_options']['fields']);
    $this->assertArrayHasKey('bustimes_slug', $attachment['display_options']['fields']);
  }

  /**
   * Resolves the entity ID Drupal assigned to a route's GTFS route_id.
   *
   * Lets result rows (keyed by entity ID) be matched back to the fixture
   * that created them.
   */
  private function routeEntityIdFor(ViewExecutable $view, string $gtfsRouteId): int {
    $storage = $this->container->get('entity_type.manager')->getStorage('localgov_bus_route');
    $routes = $storage->loadByProperties(['bustimes_route_id' => $gtfsRouteId]);
    /** @var \Drupal\localgov_bus_data\Entity\BusRoute $route */
    $route = reset($routes);
    return (int) $route->id();
  }

}
