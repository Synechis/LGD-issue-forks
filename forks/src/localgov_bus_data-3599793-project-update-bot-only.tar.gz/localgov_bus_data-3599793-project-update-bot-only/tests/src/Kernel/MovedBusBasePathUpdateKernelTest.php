<?php

declare(strict_types=1);

namespace Drupal\Tests\localgov_bus_data\Kernel;

use PHPUnit\Framework\Attributes\Group;
use PHPUnit\Framework\Attributes\RunTestsInSeparateProcesses;
use Drupal\Core\Routing\LocalRedirectResponse;
use Drupal\KernelTests\KernelTestBase;
use Drupal\Tests\localgov_bus_data\Traits\InstallsBusDataViewsTrait;
use Drupal\localgov_bus_data\Entity\BusRoute;
use Symfony\Component\HttpFoundation\Request;

/**
 * Kernel tests for issue #3599802 on a site that moved the bus base path.
 *
 * The homepage submodule's settings form can move the bus pages off /buses
 * (BusPathUpdater rewrites the leading segments of every View display path
 * and field link path), so a live site's timetable page can sit at, say,
 * parking-roads-and-transport/bus-services/buses/routes/%/%. update_10011 and
 * update_10012 originally compared those paths with the default string, so on
 * a moved site the timetable view gained its third argument while the path
 * kept two segments and every timetable page rendered empty; the legacy
 * redirect route was hardcoded to /buses/routes and so never fired either.
 *
 * These tests build a pre-update fixture on a moved base path and check that
 * both are handled.
 *
 * @group localgov_bus_data
 */
#[Group('localgov_bus_data')]
#[RunTestsInSeparateProcesses]
final class MovedBusBasePathUpdateKernelTest extends KernelTestBase {

  use InstallsBusDataViewsTrait;

  /**
   * The moved base path this fixture puts the bus pages on.
   */
  private const MOVED_BASE = 'transport/buses/routes';

  /**
   * {@inheritdoc}
   */
  protected static $modules = [
    'system',
    'user',
    'path_alias',
    'field',
    'text',
    'options',
    'file',
    'datetime',
    'geofield',
    'migrate',
    'migrate_plus',
    'views',
    'leaflet',
    'leaflet_markercluster',
    'leaflet_views',
    'localgov_bus_data',
  ];

  /**
   * {@inheritdoc}
   */
  protected function setUp(): void {
    parent::setUp();

    $this->installEntitySchema('localgov_bus_route');
    $this->installEntitySchema('path_alias');
    $this->installConfig(['system']);

    // Only the three views these updates touch, not the whole module's
    // config: localgov_bus_stop_search ships with a pre-existing, unrelated
    // config schema gap that would otherwise abort installConfig() for every
    // test in this class.
    foreach (['localgov_bus_routes', 'localgov_bus_stop_detail', 'localgov_bus_timetable'] as $view_id) {
      $this->installBusDataView($view_id);
    }

    $this->rewindViewsToPreUpdateOnMovedBase();

    \Drupal::moduleHandler()->loadInclude('localgov_bus_data', 'install');
    $this->container->get('router.builder')->rebuild();
  }

  /**
   * Rewinds the shipped views to their pre-#3599802 state on a moved base.
   *
   * The module's config/install already carries the three-segment path, so
   * the fixture has to undo it: strip the slug argument, slug fields and slug
   * path tokens, and move everything from 'buses/routes' onto
   * 'transport/buses/routes' the way BusPathUpdater would have.
   */
  private function rewindViewsToPreUpdateOnMovedBase(): void {
    $config_factory = \Drupal::configFactory();

    $timetable = $config_factory->getEditable('views.view.localgov_bus_timetable');
    $timetable->clear('display.default.display_options.arguments.bustimes_slug');
    $timetable->set('display.page_bus_timetable.display_options.path', self::MOVED_BASE . '/%/%');
    $timetable->save();

    $routes = $config_factory->getEditable('views.view.localgov_bus_routes');
    $fields_key = 'display.page_search_bus_services.display_options.fields';
    $fields = $routes->get($fields_key);
    unset($fields['bustimes_slug']);
    $fields['bustimes_route_short_name']['alter']['path'] =
      '/' . self::MOVED_BASE . '/{{ bustimes_agency_id_2 }}/{{ bustimes_route_short_name }}';
    $routes->set($fields_key, $fields);
    $routes->set('display.page_search_bus_services.display_options.path', self::MOVED_BASE);
    $routes->save();

    $stop_detail = $config_factory->getEditable('views.view.localgov_bus_stop_detail');
    foreach (['default', 'attachment_bus_stop_detail_map'] as $display_id) {
      $fields_key = "display.$display_id.display_options.fields";
      $fields = $stop_detail->get($fields_key);
      unset($fields['bustimes_slug']);
      $fields['bustimes_route_short_name_1']['alter']['path'] =
        '/' . self::MOVED_BASE . '/{{ bustimes_agency_id__value }}/{{ bustimes_route_short_name_1__value }}';
      $stop_detail->set($fields_key, $fields);
    }
    $stop_detail->save();
  }

  /**
   * Runs the two config updates this issue ships.
   */
  private function runUpdates(): void {
    localgov_bus_data_update_10011();
    localgov_bus_data_update_10012();
    $this->container->get('router.builder')->rebuild();
  }

  /**
   * Reads a stored config value.
   */
  private function configValue(string $name, string $key): mixed {
    return \Drupal::configFactory()->get($name)->get($key);
  }

  /**
   * The updates extend a moved timetable path and its links.
   *
   * Mutation check: restoring the equality tests in update_10011
   * ($config->get($path_key) === 'buses/routes/%/%') and update_10012
   * (=== '/buses/routes/{{ bustimes_agency_id_2 }}/...') in place of the
   * str_ends_with() suffix matches makes every assertion here fail, because
   * none of the moved paths equal the default string.
   */
  public function testUpdatesExtendMovedPathAndLinks(): void {
    $this->runUpdates();

    $this->assertSame(
      self::MOVED_BASE . '/%/%/%',
      $this->configValue('views.view.localgov_bus_timetable', 'display.page_bus_timetable.display_options.path'),
    );
    $this->assertNotNull(
      $this->configValue('views.view.localgov_bus_timetable', 'display.default.display_options.arguments.bustimes_slug'),
    );

    $routes_fields = $this->configValue('views.view.localgov_bus_routes', 'display.page_search_bus_services.display_options.fields');
    $this->assertArrayHasKey('bustimes_slug', $routes_fields);
    $this->assertSame(
      '/' . self::MOVED_BASE . '/{{ bustimes_agency_id_2 }}/{{ bustimes_route_short_name }}/{{ bustimes_slug }}',
      $routes_fields['bustimes_route_short_name']['alter']['path'],
    );

    foreach (['default', 'attachment_bus_stop_detail_map'] as $display_id) {
      $fields = $this->configValue('views.view.localgov_bus_stop_detail', "display.$display_id.display_options.fields");
      $this->assertArrayHasKey('bustimes_slug', $fields, $display_id);
      $this->assertSame(
        '/' . self::MOVED_BASE . '/{{ bustimes_agency_id__value }}/{{ bustimes_route_short_name_1__value }}/{{ bustimes_slug__value }}',
        $fields['bustimes_route_short_name_1']['alter']['path'],
        $display_id,
      );
    }
  }

  /**
   * Re-running the updates on already-updated config changes nothing.
   *
   * Mutation check: replacing update_10011's str_ends_with($path,
   * 'routes/%/%') guard with str_contains() makes the path assertion fail on
   * the second run, because an already-extended path would gain a fourth
   * segment.
   */
  public function testUpdatesAreIdempotent(): void {
    $this->runUpdates();
    $after_first = \Drupal::configFactory()->get('views.view.localgov_bus_timetable')->getRawData();
    $routes_after_first = \Drupal::configFactory()->get('views.view.localgov_bus_routes')->getRawData();

    $this->runUpdates();

    $this->assertSame(
      self::MOVED_BASE . '/%/%/%',
      $this->configValue('views.view.localgov_bus_timetable', 'display.page_bus_timetable.display_options.path'),
    );
    $this->assertSame($after_first, \Drupal::configFactory()->get('views.view.localgov_bus_timetable')->getRawData());
    $this->assertSame($routes_after_first, \Drupal::configFactory()->get('views.view.localgov_bus_routes')->getRawData());
  }

  /**
   * The legacy redirect route follows the timetable page onto the moved base.
   *
   * Mutation check: removing the localgov_bus_data.route_redirect_route_
   * subscriber service tag (or reverting alterRoutes() to leave the routing.yml
   * path alone) makes this request 404 instead of redirecting, because the
   * route would still be mounted on /buses/routes.
   */
  public function testRedirectRouteRespondsOnTheMovedBase(): void {
    $this->runUpdates();

    $route = BusRoute::create([
      'bustimes_route_id' => 'R1',
      'bustimes_agency_id' => 'OP539',
      'bustimes_route_short_name' => 'X5',
      'bustimes_slug' => 'keswick-penrith',
    ]);
    $route->save();

    $request = Request::create('/' . self::MOVED_BASE . '/OP539/X5');
    $response = $this->container->get('http_kernel')->handle($request);

    $this->assertInstanceOf(LocalRedirectResponse::class, $response);
    $this->assertSame(302, $response->getStatusCode());
    $this->assertSame('/' . self::MOVED_BASE . '/OP539/X5/keswick-penrith', $response->getTargetUrl());
  }

}
