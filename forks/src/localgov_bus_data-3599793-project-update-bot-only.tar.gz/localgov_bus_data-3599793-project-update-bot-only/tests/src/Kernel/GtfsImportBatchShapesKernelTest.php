<?php

declare(strict_types=1);

namespace Drupal\Tests\localgov_bus_data\Kernel;

use PHPUnit\Framework\Attributes\Group;
use PHPUnit\Framework\Attributes\RunTestsInSeparateProcesses;
use Drupal\KernelTests\KernelTestBase;
use Drupal\localgov_bus_data\Batch\GtfsImportBatch;

/**
 * Kernel tests for the filterShapes batch operation.
 *
 * GtfsFilter's three phases are covered at the unit level. This covers the
 * batch wiring around them: the sandbox handshake that carries the byte
 * offset and temp-file length between requests, the skip short-circuit, error
 * propagation, and the fact that the operation is registered at all.
 *
 * @group localgov_bus_data
 */
#[Group('localgov_bus_data')]
#[RunTestsInSeparateProcesses]
final class GtfsImportBatchShapesKernelTest extends KernelTestBase {

  /**
   * {@inheritdoc}
   */
  protected static $modules = [
    'system',
    'user',
    'field',
    'file',
    'datetime',
    'geofield',
    'migrate',
    'localgov_bus_data',
  ];

  /**
   * Absolute path to the fixture GTFS temp directory.
   */
  private string $tmpDir;

  /**
   * {@inheritdoc}
   */
  protected function setUp(): void {
    parent::setUp();

    $this->installEntitySchema('user');
    $this->installEntitySchema('file');
    $this->installSchema('localgov_bus_data', ['localgov_bus_shape']);

    $this->config('localgov_bus_data.settings')
      ->set('source.bounding_box', [
        'north' => 55.1,
        'south' => 54.3,
        'east'  => -2.0,
        'west'  => -3.75,
      ])
      ->save();

    $this->tmpDir = sys_get_temp_dir() . '/gtfs_batch_shapes_' . uniqid('', TRUE);
    $this->assertTrue(mkdir($this->tmpDir, 0755, TRUE));
    $this->writeFixture();
  }

  /**
   * {@inheritdoc}
   */
  protected function tearDown(): void {
    foreach (glob($this->tmpDir . '/*') ?: [] as $file) {
      if (is_file($file)) {
        unlink($file);
      }
    }
    if (is_dir($this->tmpDir)) {
      rmdir($this->tmpDir);
    }
    parent::tearDown();
  }

  /**
   * Writes a GTFS fixture whose trips reference SH1 and SH3 but not SH2.
   */
  private function writeFixture(): void {
    file_put_contents($this->tmpDir . '/trips.txt', <<<CSV
    route_id,service_id,trip_id,shape_id
    R1,SV1,T1,SH1
    R1,SV1,T2,SH3

    CSV);

    file_put_contents($this->tmpDir . '/shapes.txt', <<<CSV
    shape_id,shape_pt_lat,shape_pt_lon,shape_pt_sequence
    SH1,54.90,-2.93,1
    SH2,51.50,-0.12,1
    SH1,54.91,-2.94,2
    SH3,54.80,-2.80,1
    SH2,51.51,-0.13,2

    CSV);

    // A non-null sentinel: a geographic filter is configured.
    file_put_contents($this->tmpDir . '/valid_trip_ids.json', json_encode(['T1', 'T2']));
  }

  /**
   * Runs the batch operation to completion.
   *
   * @param array<string, mixed> $context
   *   Batch context, passed by reference so the caller can inspect it.
   *
   * @return int
   *   Number of passes the operation took.
   */
  private function runOperation(array &$context): int {
    $passes = 0;
    do {
      GtfsImportBatch::filterShapes($context);
      $passes++;
    } while (($context['finished'] ?? 0) < 1.0 && $passes < 50);
    return $passes;
  }

  /**
   * The operation filters shapes.txt across several passes.
   */
  public function testOperationFiltersShapesAcrossPasses(): void {
    $context = [
      'results'  => ['tmp_dir' => $this->tmpDir],
      'sandbox'  => [],
      'finished' => 0.0,
      'message'  => '',
    ];

    $passes = $this->runOperation($context);

    $this->assertGreaterThan(1, $passes, 'Init and at least one chunk are expected.');
    $this->assertArrayNotHasKey('error', $context['results']);
    $this->assertSame(
      "shape_id,shape_pt_lat,shape_pt_lon,shape_pt_sequence\n"
      . "SH1,54.90,-2.93,1\n"
      . "SH1,54.91,-2.94,2\n"
      . "SH3,54.80,-2.80,1\n",
      file_get_contents($this->tmpDir . '/shapes.txt'),
    );
    $this->assertStringContainsString('Shape geometry filtered', (string) $context['message']);
    $this->assertFileDoesNotExist($this->tmpDir . '/shapes.txt.rewrite_tmp');
    $this->assertFileDoesNotExist($this->tmpDir . '/valid_shape_ids.json');
  }

  /**
   * A feed without shapes.txt finishes in one pass without an error.
   */
  public function testOperationSkipsWhenNoShapesFile(): void {
    unlink($this->tmpDir . '/shapes.txt');

    $context = [
      'results'  => ['tmp_dir' => $this->tmpDir],
      'sandbox'  => [],
      'finished' => 0.0,
      'message'  => '',
    ];

    $this->assertSame(1, $this->runOperation($context));
    $this->assertSame(1.0, $context['finished']);
    $this->assertArrayNotHasKey('error', $context['results']);
  }

  /**
   * A missing temp directory is reported as a batch error, not a crash.
   */
  public function testOperationReportsMissingTempDir(): void {
    $context = [
      'results'  => ['tmp_dir' => $this->tmpDir . '_gone'],
      'sandbox'  => [],
      'finished' => 0.0,
      'message'  => '',
    ];

    GtfsImportBatch::filterShapes($context);

    $this->assertSame(1.0, $context['finished']);
    $this->assertArrayHasKey('error', $context['results']);
  }

  /**
   * The operation is registered directly after filterGeographyRewrite.
   *
   * Without this, a rebase that drops the line from buildBatchDefinition()
   * silently removes shape filtering from the admin import and every other
   * test stays green.
   */
  public function testOperationIsRegisteredAfterGeographyRewrite(): void {
    $operations = $this->container
      ->get('localgov_bus_data.gtfs_import')
      ->buildBatchDefinition()['operations'];

    $callbacks = array_map(static fn (array $op): string => $op[0], $operations);

    $rewriteIndex = array_search(
      '\Drupal\localgov_bus_data\Batch\GtfsImportBatch::filterGeographyRewrite',
      $callbacks,
      TRUE,
    );
    $this->assertNotFalse($rewriteIndex);
    $this->assertSame(
      '\Drupal\localgov_bus_data\Batch\GtfsImportBatch::filterShapes',
      $callbacks[$rewriteIndex + 1] ?? '',
      'Shape filtering must run immediately after the geography rewrite.',
    );
  }

  /**
   * ProcessShapes() clears the table itself before appending.
   *
   * BulkTruncate() no longer clears localgov_bus_shape, so this operation has
   * to, or every admin import would append a second copy of every point on
   * top of the last one.
   */
  public function testProcessShapesTruncatesBeforeAppending(): void {
    $database = $this->container->get('database');
    $database->insert('localgov_bus_shape')
      ->fields([
        'shape_id'          => 'SH_STALE',
        'shape_pt_lat'      => 54.9,
        'shape_pt_lon'      => -2.93,
        'shape_pt_sequence' => 1,
      ])
      ->execute();

    $stagingDir = $this->container
      ->get('localgov_bus_data.gtfs_import')
      ->getStagingDirPath();
    file_put_contents($stagingDir . '/shapes.txt', <<<CSV
    shape_id,shape_pt_lat,shape_pt_lon,shape_pt_sequence
    SH_NEW,54.90,-2.93,1
    SH_NEW,54.91,-2.94,2

    CSV);

    $context = [
      'results'  => [],
      'sandbox'  => [],
      'finished' => 0.0,
      'message'  => '',
    ];
    $passes = 0;
    do {
      GtfsImportBatch::processShapes($context);
      $passes++;
    } while (($context['finished'] ?? 0) < 1.0 && $passes < 50);

    $ids = $database->select('localgov_bus_shape', 's')
      ->fields('s', ['shape_id'])
      ->distinct()
      ->execute()
      ->fetchCol();

    $this->assertSame(['SH_NEW'], $ids, 'The stale points must be cleared, not appended to.');
  }

  /**
   * A staging directory with no shapes.txt leaves existing points in place.
   */
  public function testProcessShapesKeepsExistingRowsWhenNoStagedFile(): void {
    $database = $this->container->get('database');
    $database->insert('localgov_bus_shape')
      ->fields([
        'shape_id'          => 'SH_EXISTING',
        'shape_pt_lat'      => 54.9,
        'shape_pt_lon'      => -2.93,
        'shape_pt_sequence' => 1,
      ])
      ->execute();

    $stagingDir = $this->container
      ->get('localgov_bus_data.gtfs_import')
      ->getStagingDirPath();
    if (file_exists($stagingDir . '/shapes.txt')) {
      unlink($stagingDir . '/shapes.txt');
    }

    $context = [
      'results'  => [],
      'sandbox'  => [],
      'finished' => 0.0,
      'message'  => '',
    ];
    GtfsImportBatch::processShapes($context);

    $this->assertSame(1.0, $context['finished']);
    $this->assertSame(
      '1',
      (string) $database->select('localgov_bus_shape', 's')
        ->countQuery()
        ->execute()
        ->fetchField(),
    );
  }

}
