<?php

declare(strict_types=1);

namespace Drupal\Tests\localgov_bus_data\Kernel;

use PHPUnit\Framework\Attributes\Group;
use PHPUnit\Framework\Attributes\RunTestsInSeparateProcesses;
use Drupal\Core\Http\Exception\CacheableNotFoundHttpException;
use Drupal\KernelTests\KernelTestBase;
use Drupal\Tests\localgov_bus_data\Traits\InstallsBusDataViewsTrait;
use Drupal\localgov_bus_data\Entity\BusRoute;
use Drupal\views\ViewExecutable;
use Drupal\views\Views;
use Symfony\Component\HttpKernel\Exception\NotFoundHttpException;

/**
 * Kernel tests for the timetable page's response to an unknown route.
 *
 * The timetable page's three URL arguments have no Views argument validator,
 * so before this fix a three-segment URL whose slug matched no route
 * rendered an empty result set as a 200: a page that looked like a real
 * timetable that happened to have no services on it. The empty result is
 * still correct for a route that exists but has no trips on the selected
 * day, so the two cases have to stay distinguishable, and both are covered
 * here.
 *
 * @group localgov_bus_data
 */
#[Group('localgov_bus_data')]
#[RunTestsInSeparateProcesses]
final class TimetableUnknownRouteKernelTest extends KernelTestBase {

  use InstallsBusDataViewsTrait;

  /**
   * {@inheritdoc}
   */
  protected static $modules = [
    'system',
    'user',
    'path_alias',
    'field',
    'text',
    'options',
    'file',
    'datetime',
    'geofield',
    'migrate',
    'migrate_plus',
    'views',
    'leaflet',
    'leaflet_markercluster',
    'leaflet_views',
    'localgov_bus_data',
  ];

  /**
   * {@inheritdoc}
   */
  protected function setUp(): void {
    parent::setUp();

    foreach ([
      'localgov_bus_route',
      'localgov_bus_trip',
      'localgov_bus_stop',
      'localgov_bus_stop_time',
      'localgov_bus_calendar',
    ] as $entity_type_id) {
      $this->installEntitySchema($entity_type_id);
    }
    $this->installEntitySchema('path_alias');
    $this->installConfig(['system']);

    // Only the timetable view, not the whole module's config:
    // localgov_bus_stop_search ships with a pre-existing, unrelated config
    // schema gap that would otherwise abort installConfig() for every test
    // in this class.
    $this->installBusDataView('localgov_bus_timetable');

    $this->container->get('router.builder')->rebuild();
  }

  /**
   * Returns the timetable page display set up with the given URL arguments.
   */
  private function timetableView(string $agencyId, string $shortName, string $slug): ViewExecutable {
    $view = Views::getView('localgov_bus_timetable');
    $view->setDisplay('page_bus_timetable');
    $view->setArguments([$agencyId, $shortName, $slug]);
    return $view;
  }

  /**
   * A slug that matches no route gives a 404, not an empty timetable.
   *
   * Mutation check: removing the _localgov_bus_data_require_known_route()
   * call from localgov_bus_data_views_pre_build() makes this test fail, as
   * the view builds and executes to an empty 200 result instead of throwing.
   */
  public function testUnknownSlugThrowsNotFound(): void {
    BusRoute::create([
      'bustimes_route_id' => 'R1',
      'bustimes_agency_id' => 'OP539',
      'bustimes_route_short_name' => 'X5',
      'bustimes_slug' => 'keswick-penrith',
    ])->save();

    $this->expectException(NotFoundHttpException::class);
    $this->timetableView('OP539', 'X5', 'no-such-destination')->build();
  }

  /**
   * A known route with no trips still renders its empty result.
   *
   * This is the case the 404 must not swallow: a real route that simply has
   * no services on the day the exposed filters select is a correct, if
   * empty, answer.
   *
   * Mutation check: broadening the guard to throw whenever the view has no
   * result rows (rather than whenever no route entity matches) makes this
   * test fail with an unexpected NotFoundHttpException.
   */
  public function testKnownRouteWithNoTripsStillRenders(): void {
    BusRoute::create([
      'bustimes_route_id' => 'R1',
      'bustimes_agency_id' => 'OP539',
      'bustimes_route_short_name' => 'X5',
      'bustimes_slug' => 'keswick-penrith',
    ])->save();

    $view = $this->timetableView('OP539', 'X5', 'keswick-penrith');
    $view->execute();

    $this->assertSame([], $view->result);
  }

  /**
   * Only the page display 404s; the map attachment must not throw.
   *
   * Hook_views_pre_build fires for every display of the view. The map
   * attachment inherits the page's contextual filters, so without a display
   * guard the lookup would repeat on every timetable page render, and the
   * Views UI preview and any embed of this view would throw mid-render
   * rather than degrading to an empty result.
   *
   * Mutation check: removing the
   * `$view->current_display === 'page_bus_timetable'` guard from
   * localgov_bus_data_views_pre_build() makes this test fail with an
   * unexpected NotFoundHttpException.
   */
  public function testAttachmentDisplayDoesNotThrowOnUnknownSlug(): void {
    $view = Views::getView('localgov_bus_timetable');
    $view->setDisplay('attachment_bus_timetable_map');
    $view->setArguments(['OP539', 'X5', 'no-such-destination']);

    $view->execute();

    $this->assertSame([], $view->result);
  }

  /**
   * A live preview of the page display does not 404 either.
   *
   * A site builder typing arguments into the Views UI preview box should get
   * the view's normal empty output, not a 404 on the preview AJAX request.
   *
   * Mutation check: removing the `empty($view->live_preview)` guard from
   * localgov_bus_data_views_pre_build() makes this test fail.
   */
  public function testLivePreviewDoesNotThrowOnUnknownSlug(): void {
    $view = $this->timetableView('OP539', 'X5', 'no-such-destination');
    $view->live_preview = TRUE;

    $view->execute();

    $this->assertSame([], $view->result);
  }

  /**
   * The unknown-slug 404 is cacheable and carries the route list tag.
   *
   * Core's DefaultExceptionHtmlSubscriber adds the exception to the rendered
   * 404 page as a cacheable dependency, and a non-cacheable exception forces
   * max-age 0 on it. The tag means a later import that creates the missing
   * route clears the cached 404.
   *
   * Mutation check: swapping CacheableNotFoundHttpException for a plain
   * NotFoundHttpException in _localgov_bus_data_require_known_route() makes
   * both assertions fail.
   */
  public function testUnknownSlug404IsCacheableAndTagged(): void {
    try {
      $this->timetableView('OP539', 'X5', 'no-such-destination')->build();
      $this->fail('Expected a not-found exception.');
    }
    catch (CacheableNotFoundHttpException $exception) {
      $this->assertNotSame(0, $exception->getCacheMaxAge());
      $this->assertContains('localgov_bus_route_list', $exception->getCacheTags());
    }
  }

  /**
   * A route matching on agency and number but not slug is still unknown.
   *
   * The whole point of the slug segment is that an operator can run several
   * distinct routes under one route number, so matching on two of the three
   * arguments is not a match.
   *
   * Mutation check: dropping the bustimes_slug condition from the entity
   * query in _localgov_bus_data_require_known_route() makes this test fail,
   * because the sibling route would satisfy the lookup.
   */
  public function testSiblingRouteDoesNotSatisfyTheSlugLookup(): void {
    BusRoute::create([
      'bustimes_route_id' => 'R4',
      'bustimes_agency_id' => 'OP261',
      'bustimes_route_short_name' => 'X12',
      'bustimes_slug' => 'the-crown',
    ])->save();

    $this->expectException(NotFoundHttpException::class);
    $this->timetableView('OP261', 'X12', 'the-crown-2')->build();
  }

  /**
   * A literal 'all' slug 404s instead of rendering the merged timetable.
   *
   * 'all' is the Views exception value for these arguments, letting a
   * shorter URL browse unfiltered. Smuggled into the full three-segment URL
   * as the slug itself, it used to skip the slug filter instead, merging two
   * distinct routes that share an agency and route number into one
   * timetable: the bug issue #3599802 exists to fix.
   *
   * Mutation check: restoring the `$arg === 'all'` exemption in
   * _localgov_bus_data_require_known_route() makes this test fail, because
   * the guard would return early instead of throwing.
   */
  public function testLiteralAllSlugThrowsNotFoundInsteadOfMerging(): void {
    BusRoute::create([
      'bustimes_route_id' => 'R5',
      'bustimes_agency_id' => 'OP261',
      'bustimes_route_short_name' => 'X12',
      'bustimes_slug' => 'the-crown',
    ])->save();
    BusRoute::create([
      'bustimes_route_id' => 'R6',
      'bustimes_agency_id' => 'OP261',
      'bustimes_route_short_name' => 'X12',
      'bustimes_slug' => 'the-anchor',
    ])->save();

    $this->expectException(NotFoundHttpException::class);
    $this->timetableView('OP261', 'X12', 'all')->build();
  }

  /**
   * A literal 'all' agency ID also 404s, not just the slug position.
   *
   * The guard drops the 'all' exemption for all three URL arguments, not
   * only the slug: no real GTFS agency ID is ever literally 'all', so
   * closing the loophole there too costs nothing and keeps the guard
   * consistent across the three positions it checks.
   *
   * Mutation check: restoring the `$arg === 'all'` exemption in
   * _localgov_bus_data_require_known_route() makes this test fail, because
   * the guard would return early instead of throwing.
   */
  public function testLiteralAllAgencyIdThrowsNotFound(): void {
    BusRoute::create([
      'bustimes_route_id' => 'R7',
      'bustimes_agency_id' => 'OP261',
      'bustimes_route_short_name' => 'X12',
      'bustimes_slug' => 'the-crown',
    ])->save();

    $this->expectException(NotFoundHttpException::class);
    $this->timetableView('all', 'X12', 'the-crown')->build();
  }

  /**
   * A literal 'all' route short name also 404s, not just the slug position.
   *
   * Mutation check: restoring the `$arg === 'all'` exemption in
   * _localgov_bus_data_require_known_route() makes this test fail, because
   * the guard would return early instead of throwing.
   */
  public function testLiteralAllRouteShortNameThrowsNotFound(): void {
    BusRoute::create([
      'bustimes_route_id' => 'R8',
      'bustimes_agency_id' => 'OP261',
      'bustimes_route_short_name' => 'X12',
      'bustimes_slug' => 'the-crown',
    ])->save();

    $this->expectException(NotFoundHttpException::class);
    $this->timetableView('OP261', 'all', 'the-crown')->build();
  }

}
