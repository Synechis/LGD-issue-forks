<?php

declare(strict_types=1);

namespace Drupal\Tests\localgov_bus_data\Kernel;

use PHPUnit\Framework\Attributes\Group;
use PHPUnit\Framework\Attributes\RunTestsInSeparateProcesses;
use Drupal\file\Entity\File;
use Drupal\KernelTests\KernelTestBase;
use Drupal\localgov_bus_data\Service\GtfsImportService;

/**
 * Kernel tests for GtfsImportService::batchMergeCustomData().
 *
 * The mergeCustomData() call chain (CustomCsvManager, CustomCsvValidator)
 * is already covered at the unit level by CustomCsvManagerTest. These tests
 * cover the small amount of new orchestration in GtfsImportService itself:
 * the enabled/no-files short-circuit, a real merge, a real validation
 * failure, and the clean-snapshot fix for the self-collision bug found
 * during manual QA, using the actual container-wired services (config,
 * file entity storage, the real file system) that a plain unit test cannot
 * exercise without mocking several `final` classes GtfsImportService also
 * depends on (GtfsDownloader, GtfsFilter, NaptanImportService,
 * AgencyNameResolver), which PHPUnit's createMock() cannot do.
 *
 * @group localgov_bus_data
 */
#[Group('localgov_bus_data')]
#[RunTestsInSeparateProcesses]
final class GtfsImportServiceCustomDataKernelTest extends KernelTestBase {

  /**
   * {@inheritdoc}
   */
  protected static $modules = [
    'system',
    'user',
    'field',
    'file',
    'datetime',
    'geofield',
    'migrate',
    'localgov_bus_data',
  ];

  /**
   * The service under test.
   */
  private GtfsImportService $service;

  /**
   * Absolute path to the live GTFS staging directory.
   */
  private string $stagingDir;

  /**
   * Absolute path to the clean pre-merge snapshot directory.
   */
  private string $cleanDir;

  /**
   * {@inheritdoc}
   */
  protected function setUp(): void {
    parent::setUp();

    $this->installEntitySchema('user');
    $this->installEntitySchema('file');
    $this->installSchema('file', ['file_usage']);

    $this->service = $this->container->get('localgov_bus_data.gtfs_import');
    $this->stagingDir = $this->service->getStagingDirPath();
    $this->cleanDir = $this->service->getCleanStagingDirPath();
  }

  /**
   * Writes a staged file to both the live directory and the clean snapshot.
   *
   * In real usage, GtfsImportService::snapshotCleanStaging() keeps the two
   * in sync immediately after mergeGtfsFiles() and before mergeCustomData()
   * runs, so a test exercising batchMergeCustomData() in isolation must
   * mirror that invariant to get a representative "freshly staged" state.
   *
   * @param string $filename
   *   Staged filename, e.g. "agency.txt".
   * @param array<int, array<int, string>> $rows
   *   Rows including the header.
   */
  private function stageFile(string $filename, array $rows): void {
    $this->writeCsv($this->stagingDir . '/' . $filename, $rows);
    $this->writeCsv($this->cleanDir . '/' . $filename, $rows);
  }

  /**
   * Writes rows to a staged CSV file.
   *
   * @param string $path
   *   Absolute path to write.
   * @param array<int, array<int, string>> $rows
   *   Rows including the header.
   */
  private function writeCsv(string $path, array $rows): void {
    $fh = fopen($path, 'w');
    assert($fh !== FALSE);
    foreach ($rows as $row) {
      fputcsv($fh, $row, escape: '');
    }
    fclose($fh);
  }

  /**
   * Reads all rows from a CSV file.
   *
   * @param string $path
   *   Absolute path to read.
   *
   * @return array<int, array<int, string|null>>
   *   All rows including the header.
   */
  private function readCsv(string $path): array {
    $rows = [];
    $fh = fopen($path, 'r');
    assert($fh !== FALSE);
    while (($row = fgetcsv($fh, escape: '')) !== FALSE) {
      $rows[] = $row;
    }
    fclose($fh);
    return $rows;
  }

  /**
   * Stores a permanent managed file under a custom_data key, enabled.
   *
   * @param string $fileKey
   *   File key (e.g. "agency").
   * @param string $filename
   *   Filename for the managed file.
   * @param string $content
   *   Raw file content.
   */
  private function storeCustomFile(string $fileKey, string $filename, string $content): void {
    $uri = 'public://' . $filename;
    file_put_contents($uri, $content);
    $file = File::create([
      'uri' => $uri,
      'filename' => $filename,
      'status' => 1,
    ]);
    $file->save();

    $this->config('localgov_bus_data.settings')
      ->set('custom_data.enabled', TRUE)
      ->set('custom_data.files', [$fileKey => (int) $file->id()])
      ->save();
  }

  /**
   * Custom data disabled (the install default) is skipped silently.
   */
  public function testDisabledCustomDataIsSkippedSilently(): void {
    $this->stageFile('agency.txt', [
      ['agency_id', 'agency_name'],
    ]);

    $this->assertSame('', $this->service->batchMergeCustomData());
  }

  /**
   * A valid stored file is merged into the staging directory.
   */
  public function testEnabledWithStoredFileMergesIntoStaging(): void {
    $this->stageFile('agency.txt', [
      ['agency_id', 'agency_name'],
    ]);
    $this->storeCustomFile('agency', 'custom_agency.txt', "agency_id,agency_name\nCUSTOM_A1,Custom Agency\n");

    $note = $this->service->batchMergeCustomData();

    $this->assertSame('Custom data: 1 rows merged.', $note);
    $this->assertSame([
      ['agency_id', 'agency_name'],
      ['CUSTOM_A1', 'Custom Agency'],
    ], $this->readCsv($this->stagingDir . '/agency.txt'));
  }

  /**
   * A stored file that no longer validates skips the merge with a note.
   */
  public function testInvalidStoredFileSkipsMergeWithNote(): void {
    $originalRows = [
      ['agency_id', 'agency_name'],
    ];
    $this->stageFile('agency.txt', $originalRows);
    // Missing the required agency_name column.
    $this->storeCustomFile('agency', 'bad_agency.txt', "agency_id\nCUSTOM_A1\n");

    $note = $this->service->batchMergeCustomData();

    $this->assertSame('Custom data skipped: validation failed, see the custom data page.', $note);
    $this->assertSame($originalRows, $this->readCsv($this->stagingDir . '/agency.txt'));
  }

  /**
   * The batch merge validates against the clean snapshot, not the live dir.
   *
   * The self-collision bug found during manual QA (mergeIntoStaging()
   * appending custom rows into the live staging directory, then a later
   * revalidation against that same live directory seeing its own
   * already-merged row as a false collision) actually surfaces in
   * CustomCsvForm's validation-only handlers, which run between imports;
   * see CustomCsvManagerTest::
   * testValidateStoredFilesCollidesAgainstLiveDirButNotCleanSnapshot() for
   * a direct reproduction. batchMergeCustomData() itself always runs
   * immediately after a fresh staging rebuild, so the live directory can
   * never be carrying a stale previous merge at this call site. This test
   * instead confirms the orchestration: batchMergeCustomData() passes the
   * clean directory (not the live one) to validateStoredFiles(), by
   * constructing a live directory that would fail validation and a clean
   * snapshot that would not, and confirming the merge proceeds and appends
   * exactly once rather than being skipped or duplicating the row.
   */
  public function testBatchMergeCustomDataValidatesAgainstCleanSnapshotNotLiveDir(): void {
    // The clean snapshot reflects only the feed, as it would immediately
    // after this cycle's staging rebuild.
    $this->writeCsv($this->cleanDir . '/agency.txt', [
      ['agency_id', 'agency_name'],
    ]);
    // The live directory carries CUSTOM_A1 already, as if a previous merge
    // had run and not yet been rebuilt away. If batchMergeCustomData()
    // mistakenly validated against this directory instead of the clean
    // snapshot, the merge would be rejected as colliding with itself.
    $this->writeCsv($this->stagingDir . '/agency.txt', [
      ['agency_id', 'agency_name'],
      ['CUSTOM_A1', 'Custom Agency'],
    ]);
    $this->storeCustomFile('agency', 'custom_agency.txt', "agency_id,agency_name\nCUSTOM_A1,Custom Agency\n");

    $note = $this->service->batchMergeCustomData();

    $this->assertSame('Custom data: 1 rows merged.', $note);
    // mergeIntoStaging() appends without deduplicating, so if validation
    // had run against the clean snapshot but the merge itself also read
    // from the clean snapshot, CUSTOM_A1 would appear twice. Confirming a
    // single appended copy proves the merge step correctly still targets
    // the live directory.
    $this->assertSame([
      ['agency_id', 'agency_name'],
      ['CUSTOM_A1', 'Custom Agency'],
      ['CUSTOM_A1', 'Custom Agency'],
    ], $this->readCsv($this->stagingDir . '/agency.txt'));
  }

  /**
   * Uses the clean snapshot when it already holds data.
   */
  public function testValidationStagingDirPathUsesCleanSnapshotWhenPopulated(): void {
    $this->writeCsv($this->cleanDir . '/stops.txt', [
      ['stop_id', 'stop_name', 'stop_lat', 'stop_lon'],
    ]);
    $this->writeCsv($this->stagingDir . '/stops.txt', [
      ['stop_id', 'stop_name', 'stop_lat', 'stop_lon'],
      ['LIVE_ONLY_STOP', 'Should not be seen', '54.0', '-3.0'],
    ]);

    $this->assertSame($this->cleanDir, $this->service->getValidationStagingDirPath());
  }

  /**
   * Falls back to live staging when the clean snapshot is empty.
   *
   * Reproduces the scenario found in review #3599801: a site deploys this
   * feature with staged data already present (from before the clean
   * snapshot existed) but has not run an import since, so
   * snapshotCleanStaging() has never populated public://bus-times/gtfs-clean.
   * Validating against that empty snapshot would falsely reject every
   * reference to real feed IDs.
   */
  public function testValidationStagingDirPathFallsBackToLiveWhenCleanSnapshotEmpty(): void {
    // The clean snapshot directory exists (getCleanStagingDirPath() always
    // creates it) but holds no files, as on a freshly upgraded site.
    $this->writeCsv($this->stagingDir . '/stops.txt', [
      ['stop_id', 'stop_name', 'stop_lat', 'stop_lon'],
      ['REAL_STOP', 'Real Stop', '54.0', '-3.0'],
    ]);

    $this->assertSame($this->stagingDir, $this->service->getValidationStagingDirPath());
  }

  /**
   * Returns the (empty) clean snapshot when neither directory has data yet.
   *
   * There is nothing to fall back to in that case.
   */
  public function testValidationStagingDirPathUsesCleanSnapshotWhenNeitherHasData(): void {
    $this->assertSame($this->cleanDir, $this->service->getValidationStagingDirPath());
  }

}
