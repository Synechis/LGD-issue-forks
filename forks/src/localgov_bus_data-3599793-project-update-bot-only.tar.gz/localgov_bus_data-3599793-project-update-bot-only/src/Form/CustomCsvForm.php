<?php

declare(strict_types=1);

namespace Drupal\localgov_bus_data\Form;

use Drupal\Core\Config\ConfigFactoryInterface;
use Drupal\Core\Config\TypedConfigManagerInterface;
use Drupal\Core\Extension\ModuleExtensionList;
use Drupal\Core\Form\ConfigFormBase;
use Drupal\Core\Form\FormStateInterface;
use Drupal\Core\Link;
use Drupal\Core\Site\Settings;
use Drupal\Core\State\StateInterface;
use Drupal\Core\Url;
use Drupal\localgov_bus_data\Service\CustomCsvManager;
use Drupal\localgov_bus_data\Service\CustomCsvValidator;
use Drupal\localgov_bus_data\Service\GtfsImportService;
use Symfony\Component\DependencyInjection\ContainerInterface;

/**
 * Admin form for uploading custom GTFS-format CSV rows.
 *
 * No property on this class may be subclass-private, whatever it holds:
 * the managed_file elements upload via AJAX, which serialises this form
 * object, and DependencySerializationTrait's __sleep() only detects
 * properties visible via get_object_vars() called from FormBase's own
 * scope, not from this subclass's scope. A private property here is
 * invisible to that call and is silently dropped from serialisation, so
 * a private typed property throws on first read after the AJAX request
 * unserialises the form. Use protected for state that must survive the
 * round trip (as the injected services below do), or avoid storing the
 * state in a property at all (as fileLabels() does). __sleep() itself
 * must never be overridden here.
 */
final class CustomCsvForm extends ConfigFormBase {

  /**
   * Required columns shown in each upload element's description.
   *
   * @var array<string, string>
   */
  private const REQUIRED_COLUMNS_DESCRIPTION = [
    'agency'     => 'agency_id, agency_name',
    'routes'     => 'route_id, route_short_name, agency_id, route_type (optional: route_long_name)',
    'stops'      => 'stop_id, stop_name, stop_lat, stop_lon (optional: wheelchair_boarding)',
    'calendar'   => 'service_id, monday…sunday, start_date, end_date',
    'trips'      => 'trip_id, route_id, service_id (optional: direction_id, trip_headsign)',
    'stop_times' => 'trip_id, arrival_time, departure_time, stop_id, stop_sequence',
  ];

  public function __construct(
    ConfigFactoryInterface $configFactory,
    TypedConfigManagerInterface $typedConfigManager,
    protected CustomCsvManager $customCsvManager,
    protected GtfsImportService $importService,
    protected ModuleExtensionList $moduleExtensionList,
    protected StateInterface $state,
  ) {
    parent::__construct($configFactory, $typedConfigManager);
  }

  /**
   * Human-readable labels per file key.
   *
   * A method rather than a property: caching these in a property would
   * mean either making it protected purely so it survives the AJAX
   * serialise/unserialise cycle (state kept only for that, not because
   * any caller needs it to persist), or a class constant, which cannot
   * hold translated markup because const expressions must be compile-time
   * literals. Rebuilding the array keeps the $this->t() calls literal, so
   * the string extractor still finds them, at the cost of re-translating
   * on each call, which is cheap.
   *
   * @return array<string, \Drupal\Core\StringTranslation\TranslatableMarkup>
   *   Human-readable labels keyed by file key.
   */
  private function fileLabels(): array {
    return [
      'agency'     => $this->t('Agency'),
      'routes'     => $this->t('Routes'),
      'stops'      => $this->t('Stops'),
      'calendar'   => $this->t('Calendar'),
      'trips'      => $this->t('Trips'),
      'stop_times' => $this->t('Stop times'),
    ];
  }

  /**
   * {@inheritdoc}
   */
  public static function create(ContainerInterface $container): static {
    return new static(
      $container->get('config.factory'),
      $container->get('config.typed'),
      $container->get('localgov_bus_data.custom_csv_manager'),
      $container->get('localgov_bus_data.gtfs_import'),
      $container->get('extension.list.module'),
      $container->get('state'),
    );
  }

  /**
   * {@inheritdoc}
   */
  public function getFormId(): string {
    return 'localgov_bus_data_custom_data';
  }

  /**
   * {@inheritdoc}
   */
  protected function getEditableConfigNames(): array {
    return ['localgov_bus_data.settings'];
  }

  /**
   * {@inheritdoc}
   */
  public function buildForm(array $form, FormStateInterface $form_state): array {
    $config = $this->config('localgov_bus_data.settings');
    $stagingDir = $this->importService->getStagingDirPath();
    $hasStagedData = file_exists($stagingDir . '/stops.txt');

    $storedFileIds = $config->get('custom_data.files');
    $storedFileIds = is_array($storedFileIds) ? $storedFileIds : [];

    $form['help'] = $this->buildHelpSection();

    if (!$hasStagedData) {
      $form['precondition'] = [
        '#type' => 'container',
        'message' => [
          '#type' => 'item',
          '#markup' => $this->t('An import must complete before custom data can be uploaded, because uploads must reconcile against the staged GTFS data.'),
        ],
      ];
    }

    $form['enabled'] = [
      '#type' => 'checkbox',
      '#title' => $this->t('Enable custom data'),
      '#description' => $this->t('When disabled, stored files are kept but the merge step is skipped at the next import.'),
      '#default_value' => (bool) $config->get('custom_data.enabled'),
    ];

    $modulePath = $this->moduleExtensionList->getPath('localgov_bus_data');
    $fileLabels = $this->fileLabels();

    $form['files'] = [
      '#type' => 'container',
      '#tree' => TRUE,
    ];

    foreach (CustomCsvValidator::FILE_NAMES as $key => $filename) {
      $templateUrl = Url::fromUri('base:' . $modulePath . '/assets/templates/' . $key . '.csv')->toString();

      $form['files'][$key] = [
        '#type' => 'container',
      ];
      $form['files'][$key]['upload'] = [
        '#type' => 'managed_file',
        '#title' => $fileLabels[$key],
        '#description' => $this->t('Required columns: @columns. <a href=":url">Download template</a>.', [
          '@columns' => self::REQUIRED_COLUMNS_DESCRIPTION[$key],
          ':url' => $templateUrl,
        ]),
        '#upload_location' => $this->uploadLocation(),
        '#upload_validators' => [
          'FileExtension' => ['extensions' => 'csv txt'],
          'FileSizeLimit' => ['fileLimit' => 10 * 1024 * 1024],
        ],
        '#default_value' => isset($storedFileIds[$key]) ? [(int) $storedFileIds[$key]] : [],
        '#disabled' => !$hasStagedData,
      ];

      if (isset($storedFileIds[$key])) {
        $form['files'][$key]['remove'] = [
          '#type' => 'submit',
          '#value' => $this->t('Remove @label', ['@label' => $fileLabels[$key]]),
          '#name' => 'remove_' . $key,
          '#file_key' => $key,
          '#submit' => ['::submitRemoveFile'],
          '#limit_validation_errors' => [],
        ];
      }
    }

    $form['status'] = $this->buildStatusSection($storedFileIds);

    $form['validate_now'] = [
      '#type' => 'submit',
      '#value' => $this->t('Validate now'),
      '#submit' => ['::submitValidateNow'],
      '#limit_validation_errors' => [],
      '#disabled' => !$hasStagedData || $storedFileIds === [],
    ];

    return parent::buildForm($form, $form_state);
  }

  /**
   * Returns the upload destination for custom CSV files.
   *
   * Uses the private file scheme when one is configured (a non-empty
   * file_private_path setting, the same check PrivateStream itself uses),
   * otherwise falls back to public, since timetable data is public anyway.
   */
  private function uploadLocation(): string {
    $scheme = ((bool) Settings::get('file_private_path')) ? 'private' : 'public';
    return $scheme . '://bus-times/custom';
  }

  /**
   * Builds the introductory help section shown above the upload slots.
   *
   * @return array<string, mixed>
   *   Render array for the help section.
   */
  private function buildHelpSection(): array {
    return [
      '#type' => 'details',
      '#title' => $this->t('How to use custom data'),
      '#open' => TRUE,
      // No '#value' set here, so preRenderHtmlTag() emits an empty
      // '#markup' and the renderer falls through to concatenating child
      // elements: the nested 'em' below renders as '#children' before the
      // 'p' tag's '#prefix'/'#suffix' wrap it.
      'note' => [
        '#type' => 'html_tag',
        '#tag' => 'p',
        'text' => [
          '#type' => 'html_tag',
          '#tag' => 'em',
          '#value' => $this->t('Uploaded files take effect only after this form is saved and the upload passes validation.'),
        ],
      ],
      'steps' => [
        '#theme' => 'item_list',
        '#list_type' => 'ol',
        '#items' => [
          $this->t('Custom data is not a substitute for a GTFS import. It is intended only for small, temporary, or emergency changes to the timetable data.'),
          $this->t('Run a GTFS import first. Custom rows are validated against the imported data, so uploads are unavailable until an import has completed.'),
          $this->t('Download the <a href="#custom-csv-templates">template</a> for the files you want to provide and add your rows. Keep the header row and the column names.'),
          $this->t('Upload your files and save this form. All stored files are validated together as one set. If any row fails, the whole upload is rejected with a per-row report and nothing is changed.'),
          $this->t('Accepted files are merged into every future import. Run an import to see your changes on the site.'),
          $this->t('To update a file, upload a replacement into its slot and save. Use Remove to delete a stored file. Use Validate now to re-check stored files against the latest imported data.'),
        ],
      ],
      'templates' => [
        '#type' => 'container',
        'heading' => [
          '#type' => 'html_tag',
          // h2, not h3: the route renders under the admin theme, whose
          // page title block is the only h1 on this page, and the two
          // sibling <details><summary> labels are not headings, so h2 is
          // the next level down without a skip.
          '#tag' => 'h2',
          '#value' => $this->t('Templates'),
          // tabindex="-1" makes the heading a valid focus target: the
          // in-page link from step 3 above must move keyboard and screen
          // reader focus here on activation, not just scroll the
          // viewport, per WCAG 2.2 AA. A heading id alone only scrolls.
          '#attributes' => [
            'id' => 'custom-csv-templates',
            'tabindex' => '-1',
          ],
        ],
        'list' => [
          '#theme' => 'item_list',
          '#items' => array_map(
            fn(string $key): array => Link::fromTextAndUrl(
              $key . '.csv',
              Url::fromUri('base:' . $this->moduleExtensionList->getPath('localgov_bus_data') . '/assets/templates/' . $key . '.csv')
            )->toRenderable(),
            array_keys(CustomCsvValidator::FILE_NAMES)
          ),
        ],
      ],
    ];
  }

  /**
   * Builds the current-status section: stored files, counts, and report.
   *
   * @param array<string, int> $storedFileIds
   *   Currently stored file IDs, keyed by file key.
   *
   * @return array<string, mixed>
   *   Render array for the status section.
   */
  private function buildStatusSection(array $storedFileIds): array {
    $build = [
      '#type' => 'details',
      '#title' => $this->t('Current status'),
      '#open' => TRUE,
    ];

    $reportData = $this->state->get(CustomCsvManager::STATE_KEY);
    $acceptedCounts = is_array($reportData) ? ($reportData['accepted_row_counts'] ?? []) : [];
    $fileLabels = $this->fileLabels();

    $items = [];
    foreach (CustomCsvValidator::FILE_NAMES as $key => $filename) {
      if (!isset($storedFileIds[$key])) {
        $items[] = $this->t('@label: not uploaded.', ['@label' => $fileLabels[$key]]);
        continue;
      }
      $count = $acceptedCounts[$key] ?? NULL;
      $items[] = $count === NULL
        ? $this->t('@label: stored, not yet validated.', ['@label' => $fileLabels[$key]])
        : $this->t('@label: @count rows.', ['@label' => $fileLabels[$key], '@count' => $count]);
    }
    $build['stored_files'] = [
      '#theme' => 'item_list',
      '#items' => $items,
    ];

    if (is_array($reportData) && ($reportData['valid'] ?? NULL) === FALSE) {
      $errors = $reportData['errors'] ?? [];
      $build['report_summary'] = [
        '#type' => 'item',
        '#markup' => $this->t('Upload rejected: @errors errors in @files file(s).', [
          '@errors' => count($errors),
          '@files' => count(array_unique(array_column($errors, 'file'))),
        ]),
      ];
      $build['report_table'] = $this->buildReportTable($errors);
    }

    return $build;
  }

  /**
   * Builds the reject-with-report table.
   *
   * Caps the rendered report at 100 rows per file with a note stating how
   * many more exist; CustomCsvManager also logs up to
   * CustomCsvManager::MAX_LOGGED_ERRORS errors (currently 1000), so the log
   * is not a complete record for a report exceeding that count either.
   * Cell values are rendered only through #plain_text, never raw markup.
   *
   * @param array<int, array{file: string, line: int, column: string|null, message: string}> $errors
   *   Validation errors to render.
   *
   * @return array<string, mixed>
   *   A table render array.
   */
  private function buildReportTable(array $errors): array {
    $byFile = [];
    foreach ($errors as $error) {
      $byFile[$error['file']][] = $error;
    }

    $rows = [];
    foreach ($byFile as $file => $fileErrors) {
      $total = count($fileErrors);
      foreach (array_slice($fileErrors, 0, 100) as $error) {
        $rows[] = [
          ['data' => ['#plain_text' => $file]],
          ['data' => ['#plain_text' => (string) $error['line']]],
          ['data' => ['#plain_text' => (string) ($error['column'] ?? '')]],
          ['data' => ['#plain_text' => $error['message']]],
        ];
      }
      if ($total > 100) {
        $rows[] = [
          ['data' => ['#plain_text' => $file]],
          [
            'data' => $this->t('…and @count more error(s) in this file. See the recent log messages for more (up to 1000 total across the report).', ['@count' => $total - 100]),
            'colspan' => 3,
          ],
        ];
      }
    }

    return [
      '#type' => 'table',
      '#header' => [
        ['data' => $this->t('File'), 'scope' => 'col'],
        ['data' => $this->t('Line'), 'scope' => 'col'],
        ['data' => $this->t('Column'), 'scope' => 'col'],
        ['data' => $this->t('Problem'), 'scope' => 'col'],
      ],
      '#rows' => $rows,
      '#empty' => $this->t('No errors.'),
    ];
  }

  /**
   * {@inheritdoc}
   *
   * Deliberately does not call parent::submitForm(): unlike a plain
   * #config_target form, saving the file set requires validating it first
   * and branching on the result, so the messenger calls below replace
   * rather than follow the parent's generic "configuration saved" message.
   * The "enabled" flag is saved unconditionally regardless of upload
   * outcome: it is an orthogonal setting, not part of the file set that
   * the reject-with-report validation protects.
   */
  public function submitForm(array &$form, FormStateInterface $form_state): void {
    $config = $this->config('localgov_bus_data.settings');
    $storedFileIds = $config->get('custom_data.files');
    $storedFileIds = is_array($storedFileIds) ? $storedFileIds : [];

    $newFileIds = [];
    $unremovedFileKeys = [];
    foreach (CustomCsvValidator::FILE_NAMES as $key => $filename) {
      // managed_file's submitted value (with the default #extended => FALSE)
      // is the plain list of file IDs, e.g. ["11"], not nested under a
      // 'fids' key.
      $value = $form_state->getValue(['files', $key, 'upload']);
      $fids = is_array($value) ? array_values($value) : [];
      $fid = (int) reset($fids);
      $storedFid = (int) ($storedFileIds[$key] ?? 0);
      if ($fid <= 0) {
        if ($storedFid > 0) {
          // The submitted value is empty even though config still holds a
          // fid for this slot. Two distinct causes produce this same shape:
          // the admin used managed_file's own built-in AJAX Remove button
          // (which only clears the widget's client-side value, unlike the
          // dedicated "Remove @label" button below, which actually deletes
          // the file, its usage record, and the config entry), or the
          // stored file entity no longer resolves (ManagedFile::
          // valueCallback() silently drops a fid that File::load() cannot
          // resolve, the same case CustomCsvManager::resolveFileIdToPath()
          // already handles elsewhere). Warn without asserting which one it
          // was, rather than silently leaving config as-is while the widget
          // looks empty.
          $unremovedFileKeys[] = $key;
        }
        continue;
      }
      if ($fid !== $storedFid) {
        $newFileIds[$key] = $fid;
      }
    }

    $this->config('localgov_bus_data.settings')
      ->set('custom_data.enabled', (bool) $form_state->getValue('enabled'))
      ->save();

    if ($unremovedFileKeys !== []) {
      $fileLabels = $this->fileLabels();
      $this->messenger()->addWarning($this->t('@labels no longer show an uploaded file, but a file is still recorded in configuration for @them. Use the dedicated "Remove @example" button below to fully remove @it, or re-upload if this was not intended.', [
        '@labels' => implode(', ', array_map(fn(string $key): string => (string) $fileLabels[$key], $unremovedFileKeys)),
        '@them' => count($unremovedFileKeys) > 1 ? 'them' : 'it',
        '@it' => count($unremovedFileKeys) > 1 ? 'them' : 'it',
        '@example' => $fileLabels[$unremovedFileKeys[0]],
      ]));
    }

    if ($newFileIds === []) {
      $this->messenger()->addStatus($this->t('Settings saved.'));
      return;
    }

    // Validate against the clean snapshot, not the live staging directory:
    // saveUpload() only validates here, it never merges into staging (that
    // happens later, during the next import), so it must not see its own
    // rows from a previous merge sitting in the live directory as a false
    // collision. See GtfsImportService::getValidationStagingDirPath().
    $stagingDir = $this->importService->getValidationStagingDirPath();
    $report = $this->customCsvManager->saveUpload($newFileIds, $stagingDir);

    if ($report->isValid()) {
      $this->messenger()->addStatus($this->t('Custom data upload accepted: @counts.', [
        '@counts' => $this->formatRowCounts($report->getAcceptedRowCounts()),
      ]));
    }
    else {
      $this->messenger()->addError($this->t('Upload rejected: @errors errors in @files file(s). See the report below.', [
        '@errors' => $report->errorCount(),
        '@files' => $report->fileErrorCount(),
      ]));
    }
  }

  /**
   * Submit handler for a per-file "Remove" action button.
   */
  public function submitRemoveFile(array &$form, FormStateInterface $form_state): void {
    $triggeringElement = $form_state->getTriggeringElement();
    $fileKey = $triggeringElement['#file_key'] ?? NULL;
    if (!is_string($fileKey) || !isset(CustomCsvValidator::FILE_NAMES[$fileKey])) {
      return;
    }

    // Revalidation-only call; use the clean snapshot for the same reason
    // as submitForm() above.
    $stagingDir = $this->importService->getValidationStagingDirPath();
    $report = $this->customCsvManager->removeFile($fileKey, $stagingDir);

    $this->messenger()->addStatus($this->t('@label removed.', ['@label' => $this->fileLabels()[$fileKey]]));
    if (!$report->isValid()) {
      $this->messenger()->addWarning($this->t('The retained custom data no longer reconciles: @errors errors in @files file(s). See the report below.', [
        '@errors' => $report->errorCount(),
        '@files' => $report->fileErrorCount(),
      ]));
    }
  }

  /**
   * Submit handler for the "Validate now" action button.
   */
  public function submitValidateNow(array &$form, FormStateInterface $form_state): void {
    // Pure validation; use the clean snapshot for the same reason as
    // submitForm() above.
    $stagingDir = $this->importService->getValidationStagingDirPath();
    $report = $this->customCsvManager->validateStoredFiles($stagingDir);

    if ($report->isValid()) {
      $this->messenger()->addStatus($this->t('Custom data is valid: @counts.', [
        '@counts' => $this->formatRowCounts($report->getAcceptedRowCounts()),
      ]));
    }
    else {
      $this->messenger()->addError($this->t('Validation failed: @errors errors in @files file(s). See the report below.', [
        '@errors' => $report->errorCount(),
        '@files' => $report->fileErrorCount(),
      ]));
    }
  }

  /**
   * Formats accepted row counts for a status message.
   *
   * @param array<string, int> $counts
   *   Accepted row counts, keyed by file key.
   */
  private function formatRowCounts(array $counts): string {
    $fileLabels = $this->fileLabels();
    $parts = [];
    foreach ($counts as $key => $count) {
      $label = (string) ($fileLabels[$key] ?? $key);
      $parts[] = $label . ': ' . $count;
    }
    return implode(', ', $parts);
  }

}
