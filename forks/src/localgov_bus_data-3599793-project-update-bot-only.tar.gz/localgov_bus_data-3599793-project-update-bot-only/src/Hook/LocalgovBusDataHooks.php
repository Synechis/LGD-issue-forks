<?php

namespace Drupal\localgov_bus_data\Hook;

use Drupal\views\Plugin\views\query\Sql;
use Drupal\views\Plugin\views\query\QueryPluginBase;
use Drupal\views\Plugin\views\cache\CachePluginBase;
use Drupal\views\Plugin\views\ViewsPluginInterface;
use Drupal\Core\Cache\Cache;
use Drupal\views\ViewExecutable;
use Drupal\Core\Form\FormStateInterface;
use Drupal\Core\Url;
use Drupal\Core\Render\Markup;
use Drupal\localgov_bus_data\Utility\BusStopHelper;
use Drupal\Core\Entity\FieldableEntityInterface;
use Drupal\Core\Entity\EntityInterface;
use Drupal\Core\Hook\Attribute\Hook;
use Drupal\Core\StringTranslation\StringTranslationTrait;

/**
 * Hook implementations for localgov_bus_data.
 */
class LocalgovBusDataHooks {
  use StringTranslationTrait;

  /**
   * Implements hook_theme().
   */
  #[Hook('theme')]
  public function theme(): array {
    return [
      'views_view_localgov_bus_timetable' => [
        'variables' => [
          'stops' => [],
          'trips' => [],
          'view' => NULL,
          'options' => [],
        ],
      ],
    ];
  }

  /**
   * Implements hook_preprocess_views_view_field().
   *
   * - Routes list: shows the operator name (bustimes_agency_name, resolved at
   *   import time) in place of the raw GTFS agency_id, falling back to the id
   *   when no name is stored. A separate field instance keeps the raw id for the
   *   route link URL token, so only the displayed value changes.
   * - Stop search: appends indicator, street, and locality to the stop name so
   *   users can distinguish stops with the same name (e.g. "opp Market Road").
   * - Stop detail: strips a leading "to " from trip headsign (Destination).
   * - Stop detail: bus route links to the timetable using GTFS route_id (URL
   *   segment), with direction and schedule query parameters preserved.
   */
  #[Hook('preprocess_views_view_field')]
  public function preprocessViewsViewField(array &$variables): void {
    $view = $variables['view'];
    $field = $variables['field'];
    $field_id = $field->options['id'] ?? '';
    if ($view->id() === 'localgov_bus_routes' && $field_id === 'bustimes_agency_id') {
      $row = $variables['row'];
      $entity = $row->_entity ?? NULL;
      $name = '';
      if ($entity instanceof EntityInterface && $entity->getEntityTypeId() === 'localgov_bus_route' && $entity->hasField('bustimes_agency_name')) {
        $name = trim((string) $entity->get('bustimes_agency_name')->value);
      }
      $agency_id = trim((string) $variables['output']);
      if ($name === '' && $agency_id === '') {
        return;
      }
      $variables['output'] = [
        '#plain_text' => $name !== '' ? $name : $agency_id,
      ];
      return;
    }
    if ($view->id() === 'localgov_bus_stop_search' && $field_id === 'bustimes_stop_name') {
      $row = $variables['row'];
      $stop = $row->_entity ?? NULL;
      if (!$stop instanceof FieldableEntityInterface || $stop->getEntityTypeId() !== 'localgov_bus_stop') {
        return;
      }
      $enriched = BusStopHelper::getEnrichedName($stop);
      if ($enriched === $stop->get('bustimes_stop_name')->getString()) {
        return;
      }
      // The view field may be rendered as a link (make_link: true). Detect a
      // wrapping <a> tag and replace only the link text, preserving the href.
      $output_str = (string) $variables['output'];
      if (str_contains($output_str, '<a ')) {
        $replaced = preg_replace_callback('/(<a\b[^>]*>).*?(<\/a>)/s', static fn(array $m): string => $m[1] . htmlspecialchars($enriched, ENT_QUOTES | ENT_HTML5, 'UTF-8') . $m[2], $output_str);
        if ($replaced !== NULL) {
          $variables['output'] = Markup::create($replaced);
          return;
        }
      }
      $variables['output'] = [
        '#plain_text' => $enriched,
      ];
      return;
    }
    if ($view->id() !== 'localgov_bus_stop_detail' || $view->current_display !== 'page_bus_stop_detail') {
      return;
    }
    if ($field_id === 'bustimes_trip_headsign') {
      $row = $variables['row'];
      $entities = $row->_relationship_entities ?? [];
      $trip = $entities['bustimes_trip_id'] ?? NULL;
      if ($trip instanceof EntityInterface && $trip->getEntityTypeId() === 'localgov_bus_trip' && $trip->hasField('bustimes_trip_headsign')) {
        $text = $trip->get('bustimes_trip_headsign')->getString();
        $text = (string) (preg_replace('/^to\s+/i', '', $text) ?? '');
        $variables['output'] = [
          '#plain_text' => $text,
        ];
      }
      return;
    }
    if ($field_id !== 'bustimes_route_short_name_1') {
      return;
    }
    $row = $variables['row'];
    $entities = $row->_relationship_entities ?? [];
    $route = $entities['bustimes_route_id'] ?? NULL;
    $trip = $entities['bustimes_trip_id'] ?? NULL;
    if (!$route instanceof EntityInterface || $route->getEntityTypeId() !== 'localgov_bus_route') {
      return;
    }
    $direction = '0';
    if ($trip instanceof EntityInterface && $trip->getEntityTypeId() === 'localgov_bus_trip' && $trip->hasField('bustimes_direction_id') && !$trip->get('bustimes_direction_id')->isEmpty()) {
      $direction = (string) $trip->get('bustimes_direction_id')->value;
    }
    $query = [
      'bustimes_direction_id' => $direction,
    ];
    $exposed = $view->getExposedInput();
    foreach ([
      'bustimes_weekdays',
      'bustimes_saturday',
      'bustimes_sunday',
    ] as $key) {
      if (!array_key_exists($key, $exposed)) {
        continue;
      }
      $val = $exposed[$key];
      if (!is_scalar($val) || $val === '' || $val === NULL || $val === FALSE) {
        continue;
      }
      $query[$key] = $val;
    }
    $agency_id = $route->get('bustimes_agency_id')->getString();
    $route_short_name = $route->get('bustimes_route_short_name')->getString();
    if ($agency_id === '' || $route_short_name === '') {
      return;
    }
    $url = Url::fromRoute('view.localgov_bus_timetable.page_bus_timetable', [
      'arg_0' => $agency_id,
      'arg_1' => $route_short_name,
    ], [
      'query' => $query,
    ]);
    $variables['output'] = [
      '#type' => 'link',
      '#title' => $route_short_name,
      '#url' => $url,
    ];
  }

  /**
   * Implements hook_cron().
   *
   * Checks the configured cron expression against the current time and calls
   * GtfsImportService::run() if the schedule matches.
   */
  #[Hook('cron')]
  public function cron(): void {
    $config = \Drupal::config('localgov_bus_data.settings');
    if (!$config->get('source.enabled')) {
      return;
    }
    $state = \Drupal::state();
    $lastRun = (int) $state->get('localgov_bus_data.cron_last_run', 0);
    $schedule = (string) ($config->get('import.schedule') ?? '0 3 * * *');
    $window = (array) ($config->get('import.schedule_window') ?? [
      2,
      4,
    ]);
    if (!_localgov_bus_data_cron_matches($schedule, $window, $lastRun)) {
      return;
    }
    if (time() - $lastRun < 3600) {
      return;
    }
    $state->set('localgov_bus_data.cron_last_run', time());
    $lastFullImport = (int) $state->get('localgov_bus_data.cron_last_full_import', 0);
    $incremental = time() - $lastFullImport < 6 * 86400;
    \Drupal::logger('localgov_bus_data')->notice('hook_cron: @type import triggered by schedule "@schedule".', [
      '@type' => $incremental ? 'incremental' : 'full',
      '@schedule' => $schedule,
    ]);
    try {
      \Drupal::service('localgov_bus_data.gtfs_import')->run(FALSE, $incremental);
      if (!$incremental) {
        $state->set('localgov_bus_data.cron_last_full_import', time());
      }
    }
    catch (\RuntimeException $e) {
      \Drupal::logger('localgov_bus_data')->error('Scheduled GTFS import failed: @msg', [
        '@msg' => $e->getMessage(),
      ]);
    }
  }

  /**
   * Implements hook_form_views_exposed_form_alter().
   *
   * - Stop Search view: adds autocomplete to the stop name text field.
   * - Timetable page: replaces the direction filter with a labelled select
   *   (GTFS 0 = outbound, 1 = inbound).
   */
  #[Hook('form_views_exposed_form_alter')]
  public function formViewsExposedFormAlter(array &$form, FormStateInterface $form_state, string $form_id): void {
    /** @var \Drupal\views\ViewExecutable $view */
    $view = $form_state->get('view');
    if (!$view instanceof ViewExecutable) {
      return;
    }
    if ($view->id() === 'localgov_bus_stop_search') {
      if (isset($form['bustimes_stop_name'])) {
        $form['bustimes_stop_name']['#autocomplete_route_name'] = 'localgov_bus_data.bus_stop_autocomplete';
      }
    }
    if ($view->id() === 'localgov_bus_timetable') {
      _localgov_bus_data_apply_day_filter_defaults($form);
      if (isset($form['bustimes_direction_id'])) {
        $form['bustimes_direction_id']['#type'] = 'select';
        $form['bustimes_direction_id']['#options'] = [
          '0' => $this->t('Outbound'),
          '1' => $this->t('Inbound'),
        ];
        unset($form['bustimes_direction_id']['#size'], $form['bustimes_direction_id']['#maxlength'], $form['bustimes_direction_id']['#min'], $form['bustimes_direction_id']['#max'], $form['bustimes_direction_id']['#step']);
      }
    }
    if ($view->id() === 'localgov_bus_stop_detail') {
      _localgov_bus_data_apply_day_filter_defaults($form);
    }
  }

  /**
   * Implements hook_views_pre_render().
   *
   * Ensures bus timetable spacing CSS loads for every display of these views.
   */
  #[Hook('views_pre_render')]
  public function viewsPreRender(ViewExecutable $view): void {
    $localgov_bus_data_ids = [
      'localgov_bus_timetable',
      'localgov_bus_stop_detail',
      'localgov_bus_stop_search',
      'localgov_bus_routes',
    ];
    if (in_array($view->id(), $localgov_bus_data_ids, TRUE)) {
      $view->element['#attached']['library'][] = 'localgov_bus_data/localgov-bus-data';
    }
    // The route map line varies by the active direction and day, and depends on
    // the bus data entities. Vary the rendered output by the relevant query args,
    // invalidate on the bus entity list cache tags, and cap the lifetime to the
    // end of the current UTC day so the service-period restriction stays correct.
    if ($view->id() === 'localgov_bus_timetable') {
      $cache =& $view->element['#cache'];
      $cache['contexts'] = Cache::mergeContexts($cache['contexts'] ?? [], [
        'url.query_args:bustimes_direction_id',
        'url.query_args:bustimes_weekdays',
        'url.query_args:bustimes_saturday',
        'url.query_args:bustimes_sunday',
      ]);
      $cache['tags'] = Cache::mergeTags($cache['tags'] ?? [], [
        'localgov_bus_route_list',
        'localgov_bus_trip_list',
        'localgov_bus_stop_time_list',
        'localgov_bus_stop_list',
      ]);
      $request_time = \Drupal::service('datetime.time')->getRequestTime();
      $until_midnight = 86400 - $request_time % 86400;
      $cache['max-age'] = isset($cache['max-age']) ? Cache::mergeMaxAges($cache['max-age'], $until_midnight) : $until_midnight;
    }
  }

  /**
   * Implements hook_leaflet_views_features_alter().
   *
   * Draws a connecting line on the route map attachment of the bus timetable
   * view. Resolves the active direction and day type from the exposed input
   * (matching localgov_bus_data_views_pre_build), asks RoutePolylineService for
   * the polylines covering the filtered route in service order, and appends one
   * 'linestring' feature per polyline. Road-following shape geometry is used when
   * available, otherwise straight stop-to-stop segments. Markers are produced by
   * the view itself, so no point features are added here.
   */
  #[Hook('leaflet_views_features_alter')]
  public function leafletViewsFeaturesAlter(array &$features, ViewsPluginInterface &$view_style): void {
    $view = $view_style->view ?? NULL;
    if (!$view instanceof ViewExecutable || $view->id() !== 'localgov_bus_timetable') {
      return;
    }
    if (count($view->args) < 2) {
      return;
    }
    // The alter fires once per result row; only add the line once per render.
    $added =& drupal_static('localgov_bus_data_leaflet_views_features_alter', []);
    $dom_id = (string) ($view->dom_id ?? 'default');
    if (isset($added[$dom_id])) {
      return;
    }
    $added[$dom_id] = TRUE;
    $exposed = $view->getExposedInput();
    // Same keys and defaults as localgov_bus_data_views_pre_build.
    $direction = in_array($exposed['bustimes_direction_id'] ?? '', [
      '0',
      '1',
    ], TRUE) ? (string) $exposed['bustimes_direction_id'] : '0';
    $day_type = 'weekdays';
    if (($exposed['bustimes_saturday'] ?? '') === '1') {
      $day_type = 'saturday';
    }
    elseif (($exposed['bustimes_sunday'] ?? '') === '1') {
      $day_type = 'sunday';
    }
    $agency_id = (string) $view->args[0];
    $route_short_name = (string) $view->args[1];
    if ($agency_id === '' || $route_short_name === '') {
      return;
    }
    // Match the UTC date used by localgov_bus_data_views_query_alter.
    $today = \Drupal::service('date.formatter')->format(\Drupal::service('datetime.time')->getRequestTime(), 'custom', 'Y-m-d', 'UTC');
    /** @var \Drupal\localgov_bus_data\Service\RoutePolylineService $polyline */
    $polyline = \Drupal::service('localgov_bus_data.route_polyline');
    $polylines = $polyline->getRoutePolylines($agency_id, $route_short_name, $direction, $day_type, $today);
    if (!$polylines) {
      return;
    }
    // Carry the view's path option so the fill:false styling applies.
    $path = (string) ($view_style->options['path'] ?? '');
    foreach ($polylines as $line) {
      $points = [];
      foreach ($line as $point) {
        $points[] = [
          'lat' => $point['lat'],
          'lon' => $point['lon'],
        ];
      }
      if (count($points) < 2) {
        continue;
      }
      $feature = [
        'type' => 'linestring',
        'points' => $points,
      ];
      if ($path !== '') {
        $feature['path'] = $path;
      }
      $features[] = $feature;
    }
  }

  /**
   * Implements hook_preprocess_views_view_localgov_bus_timetable().
   */
  #[Hook('preprocess_views_view_localgov_bus_timetable')]
  public function preprocessViewsViewLocalgovBusTimetable(array &$variables): void {
    $view = $variables['view'] ?? NULL;
    if (!$view instanceof ViewExecutable) {
      return;
    }
    if ($view->id() !== 'localgov_bus_timetable' || $view->current_display !== 'page_bus_timetable' || count($view->args) < 2) {
      return;
    }
    $agency_id = (string) $view->args[0];
    $route_short_name = (string) $view->args[1];
    if (strlen($agency_id) > 100 || strlen($route_short_name) > 100) {
      return;
    }
    $exposed = $view->getExposedInput();
    $direction = in_array($exposed['bustimes_direction_id'] ?? '', [
      '0',
      '1',
    ], TRUE) ? (string) $exposed['bustimes_direction_id'] : '0';
    $route = \Drupal::database()->select('localgov_bus_route', 'r')->fields('r', [
      'bustimes_route_short_name',
      'bustimes_headsign',
      'bustimes_headsign_inbound',
    ])->condition('r.bustimes_agency_id', $agency_id)->condition('r.bustimes_route_short_name', $route_short_name)->range(0, 1)->execute()->fetchObject();
    if (!$route) {
      return;
    }
    $headsign = $direction === '1' ? $route->bustimes_headsign_inbound ?: $route->bustimes_headsign : $route->bustimes_headsign;
    if (!$headsign) {
      return;
    }
    $variables['route_subtitle'] = $this->t('Route @route to @destination', [
      '@route' => $route->bustimes_route_short_name,
      '@destination' => $headsign,
    ]);
  }

  /**
   * Implements hook_views_post_render().
   *
   * On the weekday tab, prepends a note when services do not cover every
   *   Monday–Friday; or a "specific dates" note for calendar_dates.txt-only
   *   services.
   */
  #[Hook('views_post_render')]
  public function viewsPostRender(ViewExecutable $view, array &$output, CachePluginBase $cache): void {
    if ($view->id() !== 'localgov_bus_timetable' || $view->current_display !== 'page_bus_timetable') {
      return;
    }
    if (empty($view->result)) {
      return;
    }
    if (($view->getExposedInput()['bustimes_weekdays'] ?? '') !== '1') {
      return;
    }
    $trip_ids = [];
    foreach ($view->result as $row) {
      $trip_field = $row->_entity->get('bustimes_trip_id');
      if (!$trip_field->isEmpty()) {
        $trip_ids[$trip_field->target_id] = TRUE;
      }
    }
    if (empty($trip_ids)) {
      return;
    }
    $query = \Drupal::database()->select('localgov_bus_trip', 't');
    $query->join('localgov_bus_calendar', 'c', 'c.id = t.bustimes_service_id');
    $query->addExpression('MAX(c.bustimes_monday)', 'mon');
    $query->addExpression('MAX(c.bustimes_tuesday)', 'tue');
    $query->addExpression('MAX(c.bustimes_wednesday)', 'wed');
    $query->addExpression('MAX(c.bustimes_thursday)', 'thu');
    $query->addExpression('MAX(c.bustimes_friday)', 'fri');
    $query->condition('t.id', array_keys($trip_ids), 'IN');
    $days = $query->execute()->fetchObject();
    if (!$days || $days->mon && $days->tue && $days->wed && $days->thu && $days->fri) {
      return;
    }
    $day_labels = [
      'mon' => (string) $this->t('Monday'),
      'tue' => (string) $this->t('Tuesday'),
      'wed' => (string) $this->t('Wednesday'),
      'thu' => (string) $this->t('Thursday'),
      'fri' => (string) $this->t('Friday'),
    ];
    $active = [];
    foreach ($day_labels as $key => $label) {
      if ($days->{$key}) {
        $active[] = $label;
      }
    }
    if (empty($active)) {
      // All day flags zero: service runs only on specific dates from
      // calendar_dates.txt.
      $note = $this->t('Note: Services on this route may only run on specific dates. Please contact the operator or Traveline 0871 200 22 33 for details.');
    }
    else {
      if (count($active) === 1) {
        $days_text = reset($active);
      }
      else {
        $last = array_pop($active);
        $days_text = implode(', ', $active) . ' ' . $this->t('and') . ' ' . $last;
      }
      $note = $this->t('Note: Services on this route do not run every weekday. They run on @days.', [
        '@days' => $days_text,
      ]);
    }
    // Use #prefix rather than a child element: the Views render array
    // (#type: view) does not process arbitrary child keys, so only #prefix
    // is reliably prepended to the rendered output.
    $prefix = isset($output['#prefix']) ? (string) $output['#prefix'] : '';
    $output['#prefix'] = Markup::create('<p class="bus-timetable-days-note">' . $note . '</p>' . $prefix);
    // Ensure the note is invalidated when calendar data changes.
    $output['#cache']['tags'][] = 'localgov_bus_calendar_list';
  }

  /**
   * Implements hook_views_pre_build().
   *
   * Sets sensible query defaults for the timetable page view so that the first
   * page load (no query params) shows Monday-to-Friday outbound services rather
   * than every stop time in the database.
   */
  #[Hook('views_pre_build')]
  public function viewsPreBuild(ViewExecutable $view): void {
    $day_views = [
      'localgov_bus_timetable',
      'localgov_bus_stop_detail',
    ];
    if (!in_array($view->id(), $day_views, TRUE)) {
      return;
    }
    $exposed = $view->getExposedInput();
    $has_day = FALSE;
    foreach ([
      'bustimes_weekdays',
      'bustimes_saturday',
      'bustimes_sunday',
    ] as $day_key) {
      if (!array_key_exists($day_key, $exposed)) {
        continue;
      }
      $day_val = $exposed[$day_key];
      if (is_scalar($day_val) && $day_val !== '' && $day_val !== NULL && $day_val !== FALSE) {
        $has_day = TRUE;
        break;
      }
    }
    if (!$has_day) {
      $exposed['bustimes_weekdays'] = '1';
      $exposed['bustimes_saturday'] = '';
      $exposed['bustimes_sunday'] = '';
    }
    if ($view->id() === 'localgov_bus_timetable') {
      if (!isset($exposed['bustimes_direction_id']) || $exposed['bustimes_direction_id'] === '') {
        $exposed['bustimes_direction_id'] = '0';
      }
    }
    $view->setExposedInput($exposed);
  }

  /**
   * Implements hook_views_query_alter().
   *
   * Restricts the calendar join to service periods that are currently valid
   * (start_date <= today <= end_date). Without this, the view shows stop times
   * from all timetable periods simultaneously, producing apparent duplicates
   * when overlapping old and new schedules are both present in the GTFS data.
   */
  #[Hook('views_query_alter')]
  public function viewsQueryAlter(ViewExecutable $view, QueryPluginBase $query): void {
    if (!in_array($view->id(), [
      'localgov_bus_stop_detail',
      'localgov_bus_timetable',
    ], TRUE)) {
      return;
    }
    if (!$query instanceof Sql) {
      return;
    }
    // Only apply if the bustimes_service_id → localgov_bus_calendar relationship
    // is active in this display. Without it the alias below does not exist.
    if (empty($view->relationship['bustimes_service_id'])) {
      return;
    }
    // Views generates the SQL alias as {joined_table}_{join.left_table}.
    // bustimes_service_id joins localgov_bus_calendar from localgov_bus_trip,
    // Therefore the alias is deterministically
    // 'localgov_bus_calendar_localgov_bus_trip'.
    $cal_alias = 'localgov_bus_calendar_localgov_bus_trip';
    // Use the Drupal datetime service so the date is consistent with the UTC
    // offset the site is configured for, rather than the PHP process timezone.
    $today = \Drupal::service('date.formatter')->format(\Drupal::service('datetime.time')->getRequestTime(), 'custom', 'Y-m-d', 'UTC');
    $query->addWhereExpression(0, "{$cal_alias}.bustimes_start_date <= :cal_today_a AND {$cal_alias}.bustimes_end_date >= :cal_today_b", [
      ':cal_today_a' => $today,
      ':cal_today_b' => $today,
    ]);
  }

}
