<?php

declare(strict_types=1);

namespace Drupal\localgov_bus_data\Entity;

use Drupal\Core\Entity\EntityInterface;

/**
 * List builder for bus routes.
 */
final class BusRouteListBuilder extends BusDataEntityListBuilder {

  /**
   * {@inheritdoc}
   */
  public function buildHeader(): array {
    $header['route'] = $this->t('Route');
    $header['long_name'] = $this->t('Long name');
    $header['operator'] = $this->t('Operator');
    $header['operator_name'] = $this->t('Operator name');
    $header['type'] = $this->t('Type');

    return $header + parent::buildHeader();
  }

  /**
   * {@inheritdoc}
   */
  public function buildRow(EntityInterface $entity): array {
    assert($entity instanceof BusRoute);

    $agencyId = (string) $entity->get('bustimes_agency_id')->value;
    $agencyName = trim((string) $entity->get('bustimes_agency_name')->value);

    $row['route'] = ['data' => ['#plain_text' => $entity->get('bustimes_route_short_name')->value]];
    $row['long_name'] = ['data' => ['#plain_text' => $entity->get('bustimes_route_long_name')->value]];
    $row['operator'] = ['data' => ['#plain_text' => $agencyId]];
    $row['operator_name'] = ['data' => ['#plain_text' => $agencyName !== '' ? $agencyName : $agencyId]];
    $row['type'] = ['data' => ['#plain_text' => $entity->get('bustimes_route_type')->value]];

    return $row + parent::buildRow($entity);
  }

}
