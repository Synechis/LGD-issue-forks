<?php

declare(strict_types=1);

namespace Drupal\localgov_bus_data\Utility;

use Drupal\Core\Config\Config;
use Drupal\Core\Config\ConfigFactoryInterface;

/**
 * Shipped wording for the site-editable front-end notices.
 *
 * The wording councils edit lives in localgov_bus_data.settings, but the
 * defaults are held here too so a site whose saved settings predate the
 * messages key still shows the standard notices instead of nothing. That
 * happens on any site that imports an exported settings object created before
 * this feature, and on a site that has not yet run the database updates.
 *
 * An empty string saved by an admin is respected: only a missing key falls
 * back to the default.
 */
final class BusMessages {

  /**
   * Wording shipped with the module, keyed by settings key.
   *
   * Kept in step with config/install/localgov_bus_data.settings.yml by
   * \Drupal\Tests\localgov_bus_data\Unit\BankHolidayNoticeConfigTest.
   */
  public const DEFAULTS = [
    'bank_holiday_notice' => "Please note that on a Bank Holiday most bus timetables operate to a 'Sunday' timetable. For further information or details of other holiday periods, please contact the bus operator.",
    'specific_dates_notice' => 'Note: Services on this route may only run on specific dates. Please contact the operator for details.',
  ];

  /**
   * Returns the configured wording for a message, or the shipped default.
   *
   * @param \Drupal\Core\Config\ConfigFactoryInterface $config_factory
   *   The config factory.
   * @param string $key
   *   Message key, one of the keys of self::DEFAULTS.
   *
   * @return string
   *   The wording, which may be empty if an admin cleared the message.
   */
  public static function get(ConfigFactoryInterface $config_factory, string $key): string {
    return self::getFrom($config_factory->get('localgov_bus_data.settings'), $key);
  }

  /**
   * Returns the wording held in an already loaded settings object.
   *
   * Use this from the settings form, where the config object must be the
   * editable one: ConfigFactoryInterface::get() applies settings.php and
   * language overrides, so reading through it would show an override in the
   * textarea and then persist that override on save, destroying the stored
   * wording. Render paths should use self::get(), where overrides do apply.
   *
   * @param \Drupal\Core\Config\Config $config
   *   The localgov_bus_data.settings config object. ImmutableConfig extends
   *   Config, so either kind is accepted.
   * @param string $key
   *   Message key, one of the keys of self::DEFAULTS.
   *
   * @return string
   *   The wording, which may be empty if an admin cleared the message.
   */
  public static function getFrom(Config $config, string $key): string {
    $value = $config->get('messages.' . $key);

    return $value === NULL ? (self::DEFAULTS[$key] ?? '') : (string) $value;
  }

}
