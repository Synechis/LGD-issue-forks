<?php

declare(strict_types=1);

namespace Drupal\localgov_bus_data\Utility;

use Drupal\Core\Entity\FieldableEntityInterface;

/**
 * Utility methods for bus stop entity display.
 */
final class BusStopHelper {

  private function __construct() {}

  /**
   * Returns the enriched stop name: "Stop Name (Indicator) Street, Locality".
   *
   * Parts are omitted when empty. Falls back to the plain bustimes_stop_name
   * when indicator, street, and locality are all absent.
   *
   * Callers are responsible for passing a localgov_bus_stop entity; the
   * bustimes_stop_name field is accessed without a hasField() guard.
   *
   * @param \Drupal\Core\Entity\FieldableEntityInterface $stop
   *   A localgov_bus_stop entity.
   *
   * @return string
   *   Enriched display name.
   */
  public static function getEnrichedName(FieldableEntityInterface $stop): string {
    $name = $stop->get('bustimes_stop_name')->getString();

    $indicator = $stop->hasField('bustimes_indicator')
      ? trim($stop->get('bustimes_indicator')->getString())
      : '';
    $street = $stop->hasField('bustimes_street')
      ? trim($stop->get('bustimes_street')->getString())
      : '';
    $locality = $stop->hasField('bustimes_locality')
      ? trim($stop->get('bustimes_locality')->getString())
      : '';

    if ($indicator === '' && $street === '' && $locality === '') {
      return $name;
    }

    $parts = [];
    if ($indicator !== '') {
      $parts[] = '(' . $indicator . ')';
    }
    if ($street !== '') {
      $parts[] = $street;
    }
    $detail = implode(' ', $parts);

    $enriched = $name;
    if ($detail !== '') {
      $enriched .= ' ' . $detail;
    }
    if ($locality !== '') {
      $enriched .= ', ' . $locality;
    }

    return $enriched;
  }

}
