<?php

declare(strict_types=1);

namespace Drupal\localgov_bus_data\Batch;

use Drupal\Core\Url;

/**
 * Static Batch API callbacks for the multi-step GTFS timetable import.
 *
 * Each public method is one batch operation. The Batch API calls the same
 * operation repeatedly (with an updated $context['sandbox']) until
 * $context['finished'] reaches 1.0, then moves to the next operation.
 *
 * This pattern ensures every HTTP request during the web-UI import completes
 * quickly — well within a typical nginx fastcgi_read_timeout — regardless of
 * the total dataset size.
 *
 * The download operation uses HTTP Range requests (5 MB per pass). Trips and
 * stop-times are inserted directly (10 000 rows per pass) rather than via
 * MigrateExecutable to avoid single-request timeouts on large datasets.
 */
final class GtfsImportBatch {

  /**
   * Batch operation: download the bulk GTFS ZIP using Range-request chunking.
   *
   * On the first pass the remote file size is probed and sandbox state is
   * initialised. Each subsequent pass downloads a 5 MB chunk. If the server
   * does not honour the Range header (returns HTTP 200 instead of 206) the
   * full file is written on the first pass and the operation completes.
   *
   * @param array<string, mixed> $context
   *   Batch API context array (passed by reference).
   */
  public static function download(array &$context): void {
    if (!empty($context['results']['error'])) {
      $context['finished'] = 1.0;
      return;
    }

    /** @var \Drupal\localgov_bus_data\Service\GtfsDownloader $downloader */
    $downloader = \Drupal::service('localgov_bus_data.gtfs_downloader');
    /** @var \Drupal\localgov_bus_data\Service\GtfsImportService $service */
    $service = \Drupal::service('localgov_bus_data.gtfs_import');

    if (!isset($context['sandbox']['initialized'])) {
      $url    = $service->getDownloadUrl();
      $tmpZip = sys_get_temp_dir() . '/gtfs_bulk_' . uniqid('', TRUE) . '.zip';

      $context['sandbox']['initialized'] = TRUE;
      $context['sandbox']['url']         = $url;
      $context['sandbox']['tmp_zip']     = $tmpZip;
      $context['sandbox']['offset']      = 0;
      $context['sandbox']['chunk_size']  = 5 * 1024 * 1024;
      $context['sandbox']['total_size']  = $downloader->getRemoteFileSize($url) ?? 0;

      if (!isset($context['results']['start_ms'])) {
        $context['results']['start_ms'] = (int) (microtime(TRUE) * 1000);
      }
    }

    try {
      $result = $downloader->downloadChunk(
        $context['sandbox']['url'],
        $context['sandbox']['tmp_zip'],
        $context['sandbox']['offset'],
        $context['sandbox']['chunk_size'],
      );
    }
    catch (\RuntimeException $e) {
      $context['results']['error'] = $e->getMessage();
      $context['finished']         = 1.0;
      return;
    }

    $context['sandbox']['offset'] += $result['bytes'];
    $downloaded                    = $context['sandbox']['offset'];
    $total                         = $context['sandbox']['total_size'];

    // Complete when Range is unsupported (full file on first pass) or done.
    $done = !$result['is_range'] || ($total > 0 && $downloaded >= $total);

    if ($done) {
      $context['results']['tmp_zip'] = $context['sandbox']['tmp_zip'];
      $context['finished']           = 1.0;
      $context['message']            = (string) t('GTFS data downloaded (@mb MB).', [
        '@mb' => round($downloaded / 1024 / 1024, 1),
      ]);
      return;
    }

    $context['finished'] = $total > 0 ? min(0.99, $downloaded / $total) : 0.5;
    $context['message']  = (string) t('Downloading GTFS data… @dl of @total MB', [
      '@dl'    => round($downloaded / 1024 / 1024, 1),
      '@total' => $total > 0 ? round($total / 1024 / 1024, 1) : '?',
    ]);
  }

  /**
   * Batch operation: extract the bulk GTFS ZIP archive file by file.
   *
   * On the first pass the ZIP is opened, entries are validated, the temp
   * directory is created, and the first file is extracted. Each subsequent pass
   * extracts one more file. This keeps every HTTP request within the server
   * timeout even for large archives.
   *
   * @param array<string, mixed> $context
   *   Batch API context array (passed by reference).
   */
  public static function extract(array &$context): void {
    if (!empty($context['results']['error'])) {
      $context['finished'] = 1.0;
      return;
    }

    $tmpZip = $context['results']['tmp_zip'] ?? '';
    if ($tmpZip === '' || !file_exists($tmpZip)) {
      $context['results']['error'] = 'Downloaded GTFS file not found.';
      $context['finished']         = 1.0;
      return;
    }

    // Initialisation pass: validate the archive and create the temp directory.
    if (!isset($context['sandbox']['extract_index'])) {
      $zip = new \ZipArchive();
      if ($zip->open($tmpZip) !== TRUE) {
        $context['results']['error'] = 'Could not open bulk GTFS ZIP archive.';
        $context['finished']         = 1.0;
        return;
      }

      $numFiles = $zip->numFiles;
      for ($i = 0; $i < $numFiles; $i++) {
        $name = $zip->getNameIndex($i);
        if ($name === FALSE || str_contains($name, '..') || str_starts_with($name, '/') || str_starts_with($name, '\\')) {
          $zip->close();
          $context['results']['error'] = sprintf(
            'Unsafe ZIP entry "%s" in bulk GTFS archive — aborting.',
            $name === FALSE ? '(unknown)' : $name,
          );
          $context['finished'] = 1.0;
          return;
        }
      }
      $zip->close();

      $tmpDir = sys_get_temp_dir() . '/gtfs_bulk_' . uniqid('', TRUE);
      if (!mkdir($tmpDir, 0755, TRUE)) {
        $context['results']['error'] = 'Could not create temp extraction directory.';
        $context['finished']         = 1.0;
        return;
      }

      $context['sandbox']['extract_index']     = 0;
      $context['sandbox']['extract_num_files'] = $numFiles;
      $context['sandbox']['extract_tmp_dir']   = $tmpDir;
      $context['results']['tmp_dir']           = $tmpDir;
      $context['message']                      = (string) t('Extracting GTFS archive…');
      $context['finished']                     = 0.0;
      return;
    }

    $index    = $context['sandbox']['extract_index'];
    $numFiles = $context['sandbox']['extract_num_files'];
    $tmpDir   = $context['sandbox']['extract_tmp_dir'];

    if ($index < $numFiles) {
      $zip = new \ZipArchive();
      if ($zip->open($tmpZip) !== TRUE) {
        $context['results']['error'] = 'Could not re-open bulk GTFS ZIP archive during extraction.';
        $context['finished']         = 1.0;
        return;
      }
      $name = $zip->getNameIndex($index);
      if (is_string($name)) {
        $zip->extractTo($tmpDir, [$name]);
      }
      $zip->close();
      $context['sandbox']['extract_index'] = $index + 1;
    }

    $done = $context['sandbox']['extract_index'] >= $numFiles;
    if ($done) {
      @unlink($tmpZip);
      $context['finished'] = 1.0;
      $context['message']  = (string) t('GTFS archive extracted.');
    }
    else {
      $context['finished'] = $numFiles > 0 ? $context['sandbox']['extract_index'] / $numFiles : 0.5;
      $context['message']  = (string) t('Extracting GTFS archive… (@done of @total files)', [
        '@done'  => $context['sandbox']['extract_index'],
        '@total' => $numFiles,
      ]);
    }
  }

  /**
   * Batch operation: scan stops and stop_times to identify in-area trips.
   *
   * Uses a three-phase approach so no single HTTP request has to scan the full
   * national stop_times.txt:
   *   1. Init — scan stops.txt; write in_area_stop_ids.json; return finished=0.
   *   2. Chunk — scan stop_times.txt in chunks; append trip IDs to disk.
   *   3. Finalise — deduplicate and write valid_trip_ids.json; finished=1.
   *
   * Intermediate state is written to the GTFS temp directory rather than
   * $context['sandbox'] to avoid serialisation size limits.
   *
   * @param array<string, mixed> $context
   *   Batch API context array (passed by reference).
   */
  public static function filterGeographyCollect(array &$context): void {
    if (!empty($context['results']['error'])) {
      $context['finished'] = 1.0;
      return;
    }

    $tmpDir = $context['results']['tmp_dir'] ?? '';
    if ($tmpDir === '' || !is_dir($tmpDir)) {
      $context['results']['error'] = 'Extracted GTFS temp directory not found.';
      $context['finished']         = 1.0;
      return;
    }

    /** @var \Drupal\localgov_bus_data\Service\GtfsFilter $filter */
    $filter = \Drupal::service('localgov_bus_data.gtfs_filter');

    // Phase 1: scan stops.txt, write in_area_stop_ids.json.
    if (!isset($context['sandbox']['fc_initialized'])) {
      try {
        $totalBytes = $filter->collectValidTripsInit($tmpDir);
      }
      catch (\RuntimeException $e) {
        $context['results']['error'] = $e->getMessage();
        $context['finished']         = 1.0;
        return;
      }

      $context['sandbox']['fc_initialized'] = TRUE;
      $context['sandbox']['fc_byte_offset'] = 0;
      $context['sandbox']['fc_total_bytes'] = $totalBytes;
      $context['message'] = (string) t('Scanning GTFS stops for in-area stops…');
      $context['finished'] = 0.0;
      return;
    }

    // Phase 2: chunk through stop_times.txt.
    if (!isset($context['sandbox']['fc_scan_done'])) {
      try {
        $result = $filter->collectValidTripsChunk(
          $tmpDir,
          $context['sandbox']['fc_byte_offset'],
          100000,
        );
      }
      catch (\RuntimeException $e) {
        $context['results']['error'] = $e->getMessage();
        $context['finished']         = 1.0;
        return;
      }

      $context['sandbox']['fc_byte_offset'] = $result['offset'];

      if ($result['done']) {
        // Run finalise in the same pass: it is fast (read temp file, write
        // JSON).
        try {
          $filter->collectValidTripsFinalize($tmpDir);
        }
        catch (\RuntimeException $e) {
          $context['results']['error'] = $e->getMessage();
          $context['finished']         = 1.0;
          return;
        }

        $context['finished'] = 1.0;
        $context['message']  = (string) t('In-area trips identified.');
        return;
      }

      $totalBytes = $context['sandbox']['fc_total_bytes'];
      $bytesRead = $result['offset'];
      $context['finished'] = $totalBytes > 0 ? min(0.99, $bytesRead / $totalBytes) : 0.5;
      $context['message']  = (string) t('Scanning GTFS stop times… @done of @total MB', [
        '@done'  => round($bytesRead / 1024 / 1024, 1),
        '@total' => $totalBytes > 0 ? round($totalBytes / 1024 / 1024, 1) : '?',
      ]);
      return;
    }
  }

  /**
   * Batch operation: rewrite GTFS files retaining only in-area trips.
   *
   * Uses a three-phase approach mirroring filterGeographyCollect():
   *   1. Init — open temp output file for stop_times; return finished=0.
   *   2. Chunk — rewrite stop_times.txt in chunks; accumulate needed stop IDs.
   *   3. Finalise — rename temp file; rewrite stops/trips/routes in one pass.
   *
   * @param array<string, mixed> $context
   *   Batch API context array (passed by reference).
   */
  public static function filterGeographyRewrite(array &$context): void {
    if (!empty($context['results']['error'])) {
      $context['finished'] = 1.0;
      return;
    }

    $tmpDir = $context['results']['tmp_dir'] ?? '';
    if ($tmpDir === '' || !is_dir($tmpDir)) {
      $context['results']['error'] = 'Extracted GTFS temp directory not found.';
      $context['finished']         = 1.0;
      return;
    }

    /** @var \Drupal\localgov_bus_data\Service\GtfsFilter $filter */
    $filter = \Drupal::service('localgov_bus_data.gtfs_filter');

    // Phase 1: initialise the stop_times rewrite.
    if (!isset($context['sandbox']['fr_initialized'])) {
      try {
        $init = $filter->rewriteStopTimesInit($tmpDir);
      }
      catch (\RuntimeException $e) {
        $context['results']['error'] = $e->getMessage();
        $context['finished']         = 1.0;
        return;
      }

      if ($init['skip']) {
        // No filter configured — nothing to rewrite.
        $context['finished'] = 1.0;
        $context['message']  = (string) t('No geographic filter — GTFS files unchanged.');
        return;
      }

      $context['sandbox']['fr_initialized'] = TRUE;
      $context['sandbox']['fr_byte_offset'] = $init['header_offset'] ?? 0;
      $context['sandbox']['fr_total_bytes'] = $init['total_bytes'];
      $context['sandbox']['fr_tmp_file']    = $init['tmp_file'];
      $context['sandbox']['fr_kept']        = 0;
      $context['message']                   = (string) t('Filtering GTFS files to configured area…');
      $context['finished']                  = 0.0;
      return;
    }

    try {
      $result = $filter->rewriteStopTimesChunk(
        $tmpDir,
        $context['sandbox']['fr_tmp_file'],
        $context['sandbox']['fr_byte_offset'],
        50000,
      );
    }
    catch (\RuntimeException $e) {
      $context['results']['error'] = $e->getMessage();
      $context['finished']         = 1.0;
      return;
    }

    $context['sandbox']['fr_byte_offset'] = $result['offset'];
    $context['sandbox']['fr_kept']       += $result['kept'];

    if ($result['done']) {
      // Phase 3: rename temp file and rewrite stops/trips/routes.
      try {
        $filter->rewriteStopTimesFinalize($tmpDir);
      }
      catch (\RuntimeException $e) {
        $context['results']['error'] = $e->getMessage();
        $context['finished']         = 1.0;
        return;
      }

      $context['finished'] = 1.0;
      $context['message']  = (string) t('GTFS files filtered to configured area.');
      return;
    }

    $totalBytes = $context['sandbox']['fr_total_bytes'];
    $bytesRead = $result['offset'];
    $context['finished'] = $totalBytes > 0 ? min(0.99, $bytesRead / $totalBytes) : 0.5;
    $context['message']  = (string) t('Filtering GTFS files… @done of @total MB', [
      '@done'  => round($bytesRead / 1024 / 1024, 1),
      '@total' => $totalBytes > 0 ? round($totalBytes / 1024 / 1024, 1) : '?',
    ]);
  }

  /**
   * Batch operation: merge filtered files into the staging directory.
   *
   * Reads tmp_dir from results, calls mergeGtfsFiles(), then cleans up the
   * temp directory.
   *
   * @param array<string, mixed> $context
   *   Batch API context array (passed by reference).
   */
  public static function mergeAndStage(array &$context): void {
    if (!empty($context['results']['error'])) {
      $context['finished'] = 1.0;
      return;
    }

    $tmpDir = $context['results']['tmp_dir'] ?? '';
    if ($tmpDir === '' || !is_dir($tmpDir)) {
      $context['results']['error'] = 'Filtered GTFS temp directory not found.';
      $context['finished']         = 1.0;
      return;
    }

    $context['message'] = (string) t('Staging GTFS data…');

    try {
      /** @var \Drupal\localgov_bus_data\Service\GtfsImportService $service */
      $service = \Drupal::service('localgov_bus_data.gtfs_import');
      $service->batchMergeAndStage($tmpDir);
      // Clear tmp_dir from results — the directory has been deleted by the
      // service. This prevents the batchFinished() safety-net from doing
      // unnecessary work on the happy path.
      unset($context['results']['tmp_dir']);
    }
    catch (\RuntimeException $e) {
      $context['results']['error'] = $e->getMessage();
    }

    $context['finished'] = 1.0;
  }

  /**
   * Batch operation: revalidate and merge the stored custom data set.
   *
   * Runs between mergeAndStage and truncate, so the merge happens after the
   * staging directory is rebuilt but before the entity tables are cleared
   * and repopulated. Unlike the other operations in this class, a failure
   * here is never treated as an import-aborting error: custom data must
   * never block the real timetable from publishing, so any exception is
   * caught, logged, and recorded as a skip note rather than propagated. The
   * note (merged row count, or the skip reason) is stored in
   * $context['results'] so finalize() can append it to the import log
   * message.
   *
   * @param array<string, mixed> $context
   *   Batch API context array (passed by reference).
   */
  public static function mergeCustomData(array &$context): void {
    if (!empty($context['results']['error'])) {
      $context['finished'] = 1.0;
      return;
    }

    $context['message'] = (string) t('Merging custom data…');

    try {
      /** @var \Drupal\localgov_bus_data\Service\GtfsImportService $service */
      $service = \Drupal::service('localgov_bus_data.gtfs_import');
      $context['results']['custom_data_note'] = $service->batchMergeCustomData();
    }
    catch (\Throwable $e) {
      \Drupal::logger('localgov_bus_data')->warning(
        'Custom data merge failed (non-fatal): @msg @trace',
        ['@msg' => $e->getMessage(), '@trace' => $e->getTraceAsString()],
      );
      $context['results']['custom_data_note'] = 'Custom data skipped: an unexpected error occurred, see the log.';
    }

    $context['finished'] = 1.0;
  }

  /**
   * Batch operation: truncate all bus-data tables.
   *
   * @param array<string, mixed> $context
   *   Batch API context array (passed by reference).
   */
  public static function truncate(array &$context): void {
    if (!empty($context['results']['error'])) {
      $context['finished'] = 1.0;
      return;
    }

    $context['message'] = (string) t('Truncating existing bus data…');

    try {
      /** @var \Drupal\localgov_bus_data\Service\GtfsImportService $service */
      $service = \Drupal::service('localgov_bus_data.gtfs_import');
      $service->batchTruncate();
      $context['results']['row_counts'] = [];
    }
    catch (\RuntimeException $e) {
      $context['results']['error'] = $e->getMessage();
    }

    $context['finished'] = 1.0;
  }

  /**
   * Batch operation: run a single core migration.
   *
   * Uses a two-pass approach: the first pass returns finished=0.0 to force the
   * Batch API to open a new HTTP request before the migration runs. Without
   * this fence, the Batch API chains all fast-completing operations in a single
   * request, consuming the timeout budget before the actual migration starts.
   *
   * @param string $migrationId
   *   The migration plugin ID to run.
   * @param array<string, mixed> $context
   *   Batch API context array (passed by reference).
   */
  public static function runMigration(string $migrationId, array &$context): void {
    if (!empty($context['results']['error'])) {
      $context['finished'] = 1.0;
      return;
    }

    // First pass: yield so the migration runs in its own HTTP request.
    // The sandbox is shared across all operations in the batch set, so the
    // key must be migration-specific to avoid later migrations skipping the
    // fence because an earlier migration already set a generic 'ready' flag.
    $fenceKey = 'ready_' . $migrationId;
    if (!isset($context['sandbox'][$fenceKey])) {
      $context['sandbox'][$fenceKey] = TRUE;
      $context['message']            = (string) t('Preparing @id…', ['@id' => $migrationId]);
      $context['finished']           = 0.0;
      return;
    }

    $context['message'] = (string) t('Importing @id…', ['@id' => $migrationId]);

    try {
      /** @var \Drupal\localgov_bus_data\Service\GtfsImportService $service */
      $service = \Drupal::service('localgov_bus_data.gtfs_import');
      $context['results']['row_counts'][$migrationId] = $service->batchRunMigration($migrationId);
    }
    catch (\RuntimeException $e) {
      $context['results']['error'] = $e->getMessage();
    }

    $context['finished'] = 1.0;
  }

  /**
   * Batch operation: insert bus stops in chunks using the entity API.
   *
   * Reads stops.txt directly and creates entities via the entity type manager,
   * which correctly handles the geofield lat/lon → WKT conversion. Chunking
   * at 500 entities per pass keeps each HTTP request well within server
   * timeout limits.
   *
   * All sandbox keys are prefixed with "stops_" to avoid collisions with other
   * operations sharing $context['sandbox'] in the same batch set.
   *
   * @param array<string, mixed> $context
   *   Batch API context array (passed by reference).
   */
  public static function processStops(array &$context): void {
    if (!empty($context['results']['error'])) {
      $context['finished'] = 1.0;
      return;
    }

    /** @var \Drupal\localgov_bus_data\Service\GtfsImportService $service */
    $service = \Drupal::service('localgov_bus_data.gtfs_import');

    if (!isset($context['sandbox']['stops_initialized'])) {
      try {
        $stagingDir = $service->getStagingDirPath();
      }
      catch (\RuntimeException $e) {
        $context['results']['error'] = $e->getMessage();
        $context['finished']         = 1.0;
        return;
      }

      $csvFile = $stagingDir . '/stops.txt';
      if (!file_exists($csvFile)) {
        $context['results']['error'] = 'stops.txt not found in staging directory.';
        $context['finished']         = 1.0;
        return;
      }

      $handle = fopen($csvFile, 'r');
      if ($handle === FALSE) {
        $context['results']['error'] = 'Cannot open stops.txt.';
        $context['finished']         = 1.0;
        return;
      }
      $header     = fgetcsv($handle, escape: '');
      $byteOffset = (int) ftell($handle);
      fclose($handle);

      if (!is_array($header)) {
        $context['results']['error'] = 'stops.txt header row could not be read.';
        $context['finished']         = 1.0;
        return;
      }

      $headerCols = array_flip($header);
      $required   = ['stop_id', 'stop_name', 'stop_lat', 'stop_lon'];
      $missing    = array_diff($required, array_keys($headerCols));
      if (!empty($missing)) {
        $context['results']['error'] = sprintf(
          'stops.txt is missing required columns: %s.',
          implode(', ', $missing),
        );
        $context['finished'] = 1.0;
        return;
      }

      clearstatcache(TRUE, $csvFile);
      $context['sandbox']['stops_initialized'] = TRUE;
      $context['sandbox']['stops_file']        = $csvFile;
      $context['sandbox']['stops_offset']      = $byteOffset;
      $context['sandbox']['stops_total_bytes'] = (int) filesize($csvFile);
      $context['sandbox']['stops_processed']   = 0;
      $context['sandbox']['stops_header_cols'] = $headerCols;

      $context['message']  = (string) t('Preparing stops import…');
      $context['finished'] = 0.0;
      return;
    }

    try {
      $result = $service->processStopsChunk(
        $context['sandbox']['stops_file'],
        $context['sandbox']['stops_offset'],
        $context['sandbox']['stops_header_cols'],
        500,
      );
    }
    catch (\RuntimeException $e) {
      $context['results']['error'] = $e->getMessage();
      $context['finished']         = 1.0;
      return;
    }

    $prevOffset                             = $context['sandbox']['stops_offset'];
    $context['sandbox']['stops_offset']     = $result['offset'];
    $context['sandbox']['stops_processed'] += $result['processed'];

    $totalBytes = $context['sandbox']['stops_total_bytes'];
    $bytesRead  = $context['sandbox']['stops_offset'];
    $rowCount   = $context['sandbox']['stops_processed'];

    if ($result['offset'] === $prevOffset) {
      $context['results']['row_counts']['localgov_bus_data_stops'] = $rowCount;
      \Drupal::logger('localgov_bus_data')->notice('Imported localgov_bus_data_stops: @count rows.', [
        '@count' => $rowCount,
      ]);
      $context['finished'] = 1.0;
      $context['message']  = (string) t('Stops imported (@count rows).', [
        '@count' => number_format($rowCount),
      ]);
      return;
    }

    $context['finished'] = $totalBytes > 0 ? min(0.99, $bytesRead / $totalBytes) : 0.5;
    $context['message']  = (string) t('Importing stops… @done of @total MB', [
      '@done'  => round($bytesRead / 1024 / 1024, 1),
      '@total' => $totalBytes > 0 ? round($totalBytes / 1024 / 1024, 1) : '?',
    ]);
  }

  /**
   * Batch operation: insert trips in chunks, bypassing MigrateExecutable.
   *
   * Reads trips.txt directly and inserts via bulk INSERT statements. This
   * avoids the per-entity overhead of MigrateExecutable, keeping each HTTP
   * request well within a typical server timeout on shared-hosting platforms.
   *
   * All sandbox keys are prefixed with "trips_" to avoid collisions with the
   * shared $context['sandbox'] used by other operations in the same batch set.
   *
   * @param array<string, mixed> $context
   *   Batch API context array (passed by reference).
   */
  public static function processTrips(array &$context): void {
    if (!empty($context['results']['error'])) {
      $context['finished'] = 1.0;
      return;
    }

    /** @var \Drupal\localgov_bus_data\Service\GtfsImportService $service */
    $service = \Drupal::service('localgov_bus_data.gtfs_import');

    if (!isset($context['sandbox']['trips_initialized'])) {
      try {
        $stagingDir = $service->getStagingDirPath();
      }
      catch (\RuntimeException $e) {
        $context['results']['error'] = $e->getMessage();
        $context['finished']         = 1.0;
        return;
      }

      $csvFile = $stagingDir . '/trips.txt';
      if (!file_exists($csvFile)) {
        $context['results']['error'] = 'trips.txt not found in staging directory.';
        $context['finished']         = 1.0;
        return;
      }

      $handle = fopen($csvFile, 'r');
      if ($handle === FALSE) {
        $context['results']['error'] = 'Cannot open trips.txt.';
        $context['finished']         = 1.0;
        return;
      }
      $header     = fgetcsv($handle, escape: '');
      $headerCols = is_array($header) ? array_flip($header) : [];
      $byteOffset = (int) ftell($handle);
      fclose($handle);

      $required = ['trip_id', 'route_id', 'service_id'];
      $missing  = array_diff($required, array_keys($headerCols));
      if (!empty($missing)) {
        $context['results']['error'] = sprintf(
          'trips.txt is missing required columns: %s.',
          implode(', ', $missing),
        );
        $context['finished'] = 1.0;
        return;
      }

      clearstatcache(TRUE, $csvFile);
      $context['sandbox']['trips_initialized']  = TRUE;
      $context['sandbox']['trips_file']         = $csvFile;
      $context['sandbox']['trips_offset']       = $byteOffset;
      $context['sandbox']['trips_total_bytes']  = (int) filesize($csvFile);
      $context['sandbox']['trips_processed']    = 0;
      $context['sandbox']['trips_header_cols']  = $headerCols;
      $context['sandbox']['trips_route_map']    = $service->loadRouteIdMap();
      $context['sandbox']['trips_calendar_map'] = $service->loadCalendarIdMap();

      $context['message']  = (string) t('Preparing trips import…');
      $context['finished'] = 0.0;
      return;
    }

    try {
      $result = $service->processTripChunk(
        $context['sandbox']['trips_file'],
        $context['sandbox']['trips_offset'],
        $context['sandbox']['trips_header_cols'],
        $context['sandbox']['trips_route_map'],
        $context['sandbox']['trips_calendar_map'],
        10000,
      );
    }
    catch (\RuntimeException $e) {
      $context['results']['error'] = $e->getMessage();
      $context['finished']         = 1.0;
      return;
    }

    $prevOffset                             = $context['sandbox']['trips_offset'];
    $context['sandbox']['trips_offset']     = $result['offset'];
    $context['sandbox']['trips_processed'] += $result['processed'];

    $totalBytes = $context['sandbox']['trips_total_bytes'];
    $bytesRead  = $context['sandbox']['trips_offset'];
    $rowCount   = $context['sandbox']['trips_processed'];

    if ($result['offset'] === $prevOffset) {
      $context['results']['row_counts']['localgov_bus_data_trips'] = $rowCount;
      \Drupal::logger('localgov_bus_data')->notice('Imported localgov_bus_data_trips: @count rows.', [
        '@count' => $rowCount,
      ]);
      $context['finished'] = 1.0;
      $context['message']  = (string) t('Trips imported (@count rows).', [
        '@count' => number_format($rowCount),
      ]);
      return;
    }

    $context['finished'] = $totalBytes > 0 ? min(0.99, $bytesRead / $totalBytes) : 0.5;
    $context['message']  = (string) t('Importing trips… @done of @total MB', [
      '@done'  => round($bytesRead / 1024 / 1024, 1),
      '@total' => $totalBytes > 0 ? round($totalBytes / 1024 / 1024, 1) : '?',
    ]);
  }

  /**
   * Batch operation: insert stop-times in chunks of 10 000 rows.
   *
   * Uses sandbox state to track the byte position in the CSV between passes;
   * progress is reported as bytes read vs. total file size. Entity ID lookups
   * are resolved per chunk so batch sandbox state stays small.
   *
   * All sandbox keys are prefixed with "stop_times_" to avoid collisions with
   * other operations sharing $context['sandbox'] in the same batch set.
   *
   * @param array<string, mixed> $context
   *   Batch API context array (passed by reference).
   */
  public static function processStopTimes(array &$context): void {
    if (!empty($context['results']['error'])) {
      $context['finished'] = 1.0;
      return;
    }

    /** @var \Drupal\localgov_bus_data\Service\GtfsImportService $service */
    $service = \Drupal::service('localgov_bus_data.gtfs_import');

    if (!isset($context['sandbox']['stop_times_initialized'])) {
      try {
        $stagingDir = $service->getStagingDirPath();
      }
      catch (\RuntimeException $e) {
        $context['results']['error'] = $e->getMessage();
        $context['finished']         = 1.0;
        return;
      }

      $csvFile = $stagingDir . '/stop_times.txt';
      if (!file_exists($csvFile)) {
        $context['results']['error'] = 'stop_times.txt not found in staging directory.';
        $context['finished']         = 1.0;
        return;
      }

      $handle = fopen($csvFile, 'r');
      if ($handle === FALSE) {
        $context['results']['error'] = 'Cannot open stop_times.txt.';
        $context['finished']         = 1.0;
        return;
      }
      $header     = fgetcsv($handle, escape: '');
      $headerCols = is_array($header) ? array_flip($header) : [];
      $byteOffset = (int) ftell($handle);
      fclose($handle);

      $required = ['trip_id', 'arrival_time', 'departure_time', 'stop_id', 'stop_sequence'];
      $missing  = array_diff($required, array_keys($headerCols));
      if (!empty($missing)) {
        $context['results']['error'] = sprintf(
          'stop_times.txt is missing required columns: %s.',
          implode(', ', $missing),
        );
        $context['finished'] = 1.0;
        return;
      }

      clearstatcache(TRUE, $csvFile);
      $context['sandbox']['stop_times_initialized'] = TRUE;
      $context['sandbox']['stop_times_file']        = $csvFile;
      $context['sandbox']['stop_times_byte_offset'] = $byteOffset;
      $context['sandbox']['stop_times_total_bytes'] = (int) filesize($csvFile);
      $context['sandbox']['stop_times_processed']   = 0;
      $context['sandbox']['stop_times_header_cols'] = $headerCols;

      $context['message']  = (string) t('Preparing stop times import…');
      $context['finished'] = 0.0;
      return;
    }

    try {
      $result = $service->processStopTimesChunk(
        $context['sandbox']['stop_times_file'],
        $context['sandbox']['stop_times_byte_offset'],
        $context['sandbox']['stop_times_header_cols'],
        10000,
      );
    }
    catch (\RuntimeException $e) {
      $context['results']['error'] = $e->getMessage();
      $context['finished']         = 1.0;
      return;
    }

    $prevOffset                                   = $context['sandbox']['stop_times_byte_offset'];
    $context['sandbox']['stop_times_byte_offset'] = $result['offset'];
    $context['sandbox']['stop_times_processed']  += $result['processed'];

    $totalBytes = $context['sandbox']['stop_times_total_bytes'];
    $bytesRead  = $context['sandbox']['stop_times_byte_offset'];
    $rowCount   = $context['sandbox']['stop_times_processed'];

    // EOF: the offset did not advance — nothing was read from the file.
    // This is the only reliable signal that the file is exhausted. Checking
    // $result['processed'] === 0 is not sufficient because geographic filtering
    // can produce chunks where every row is orphaned (processed = 0) while the
    // file still has data to read.
    if ($result['offset'] === $prevOffset) {
      $context['results']['row_counts']['localgov_bus_data_stop_times'] = $rowCount;
      $context['finished'] = 1.0;
      $context['message'] = (string) t('Stop times imported (@count rows).', [
        '@count' => number_format($rowCount),
      ]);
      return;
    }

    $context['finished'] = $totalBytes > 0 ? min(0.99, $bytesRead / $totalBytes) : 0.5;
    $context['message']  = (string) t('Importing stop times… @done of @total MB', [
      '@done'  => round($bytesRead / 1024 / 1024, 1),
      '@total' => $totalBytes > 0 ? round($totalBytes / 1024 / 1024, 1) : '?',
    ]);
  }

  /**
   * Batch operation: insert shape geometry points in chunks of 10 000 rows.
   *
   * Populates localgov_bus_shape from the staged shapes.txt so route maps
   * can draw road-following lines. Shapes are optional in GTFS: a missing
   * shapes.txt or missing columns is treated as a non-fatal skip, not an
   * import failure.
   * The table is cleared by the earlier truncate operation, so this step only
   * appends.
   *
   * All sandbox keys are prefixed with "shapes_" to avoid collisions with other
   * operations sharing $context['sandbox'] in the same batch set.
   *
   * @param array<string, mixed> $context
   *   Batch API context array (passed by reference).
   */
  public static function processShapes(array &$context): void {
    if (!empty($context['results']['error'])) {
      $context['finished'] = 1.0;
      return;
    }

    /** @var \Drupal\localgov_bus_data\Service\GtfsImportService $service */
    $service = \Drupal::service('localgov_bus_data.gtfs_import');

    if (!isset($context['sandbox']['shapes_initialized'])) {
      try {
        $stagingDir = $service->getStagingDirPath();
      }
      catch (\RuntimeException $e) {
        $context['results']['error'] = $e->getMessage();
        $context['finished']         = 1.0;
        return;
      }

      $csvFile = $stagingDir . '/shapes.txt';
      if (!file_exists($csvFile)) {
        // Feed has no shapes; straight-line fallback applies.
        \Drupal::logger('localgov_bus_data')->notice('No shapes.txt staged; skipping shape geometry import.');
        $context['finished'] = 1.0;
        return;
      }

      $handle = fopen($csvFile, 'r');
      if ($handle === FALSE) {
        \Drupal::logger('localgov_bus_data')->warning('Cannot open shapes.txt; skipping shape geometry import.');
        $context['finished'] = 1.0;
        return;
      }
      $header     = fgetcsv($handle, escape: '');
      $headerCols = is_array($header) ? array_flip($header) : [];
      $byteOffset = (int) ftell($handle);
      fclose($handle);

      $required = ['shape_id', 'shape_pt_lat', 'shape_pt_lon', 'shape_pt_sequence'];
      $missing  = array_diff($required, array_keys($headerCols));
      if (!empty($missing)) {
        \Drupal::logger('localgov_bus_data')->warning(
          'shapes.txt is missing columns (@missing); skipping shape geometry import.',
          ['@missing' => implode(', ', $missing)],
        );
        $context['finished'] = 1.0;
        return;
      }

      clearstatcache(TRUE, $csvFile);
      $context['sandbox']['shapes_initialized'] = TRUE;
      $context['sandbox']['shapes_file']        = $csvFile;
      $context['sandbox']['shapes_byte_offset'] = $byteOffset;
      $context['sandbox']['shapes_total_bytes'] = (int) filesize($csvFile);
      $context['sandbox']['shapes_processed']   = 0;
      $context['sandbox']['shapes_header_cols'] = $headerCols;

      $context['message']  = (string) t('Preparing shape geometry import…');
      $context['finished'] = 0.0;
      return;
    }

    try {
      $result = $service->processShapesChunk(
        $context['sandbox']['shapes_file'],
        $context['sandbox']['shapes_byte_offset'],
        $context['sandbox']['shapes_header_cols'],
        10000,
      );
    }
    catch (\RuntimeException $e) {
      $context['results']['error'] = $e->getMessage();
      $context['finished']         = 1.0;
      return;
    }

    $prevOffset                               = $context['sandbox']['shapes_byte_offset'];
    $context['sandbox']['shapes_byte_offset'] = $result['offset'];
    $context['sandbox']['shapes_processed']  += $result['processed'];

    $totalBytes = $context['sandbox']['shapes_total_bytes'];
    $bytesRead  = $context['sandbox']['shapes_byte_offset'];
    $rowCount   = $context['sandbox']['shapes_processed'];

    // EOF: the offset did not advance, nothing was read from the file.
    if ($result['offset'] === $prevOffset) {
      $context['results']['row_counts']['localgov_bus_shapes'] = $rowCount;
      \Drupal::logger('localgov_bus_data')->notice('Imported @count shape points.', [
        '@count' => $rowCount,
      ]);
      $context['finished'] = 1.0;
      $context['message']  = (string) t('Shape geometry imported (@count points).', [
        '@count' => number_format($rowCount),
      ]);
      return;
    }

    $context['finished'] = $totalBytes > 0 ? min(0.99, $bytesRead / $totalBytes) : 0.5;
    $context['message']  = (string) t('Importing shape geometry… @done of @total MB', [
      '@done'  => round($bytesRead / 1024 / 1024, 1),
      '@total' => $totalBytes > 0 ? round($totalBytes / 1024 / 1024, 1) : '?',
    ]);
  }

  /**
   * Batch operation: populate denormalized fields and write the import log.
   *
   * @param array<string, mixed> $context
   *   Batch API context array (passed by reference).
   */
  public static function finalize(array &$context): void {
    if (!empty($context['results']['error'])) {
      $context['finished'] = 1.0;
      return;
    }

    $context['message'] = (string) t('Finalising import…');

    /** @var \Drupal\localgov_bus_data\Service\GtfsImportService $service */
    $service = \Drupal::service('localgov_bus_data.gtfs_import');

    $service->populateCalendarWeekdays();
    $service->populateRouteHeadsigns();
    $service->populateRouteOperatorNames();
    $service->populateStopServices();

    $durationMs = (int) (microtime(TRUE) * 1000) - (int) ($context['results']['start_ms'] ?? 0);
    $rowCounts  = $context['results']['row_counts'] ?? [];

    $message = 'Import completed successfully.';
    $customDataNote = $context['results']['custom_data_note'] ?? '';
    if ($customDataNote !== '') {
      $message .= ' ' . $customDataNote;
    }

    $service->writeImportLog('success', $rowCounts, $durationMs, $message);

    $context['finished'] = 1.0;
    $context['message']  = (string) t('Import complete.');
  }

  /**
   * Batch operation: download NaPTAN data to a temp file.
   *
   * Self-skips silently when NaPTAN enrichment is disabled in settings.
   * Downloads via Guzzle with the sink option to avoid loading the full
   * response body into PHP memory.
   *
   * @param array<string, mixed> $context
   *   Batch API context array (passed by reference).
   */
  public static function downloadNaptan(array &$context): void {
    if (!empty($context['results']['error'])) {
      $context['finished'] = 1.0;
      return;
    }

    /** @var \Drupal\localgov_bus_data\Service\NaptanImportService $naptan */
    $naptan = \Drupal::service('localgov_bus_data.naptan_import');

    if (!$naptan->isEnabled()) {
      $context['finished'] = 1.0;
      return;
    }

    $context['message'] = (string) t('Downloading NaPTAN stop data…');

    try {
      $tmpFile = $naptan->downloadToTempFile();
      $context['results']['naptan_tmp_file'] = $tmpFile;
      $context['message'] = (string) t('NaPTAN data downloaded.');
    }
    catch (\RuntimeException $e) {
      // NaPTAN enrichment is optional; log but do not abort the import.
      \Drupal::logger('localgov_bus_data')->warning(
        'NaPTAN download failed (non-fatal): @msg',
        ['@msg' => $e->getMessage()],
      );
      $context['message'] = (string) t('NaPTAN download skipped: @msg', [
        '@msg' => $e->getMessage(),
      ]);
    }

    $context['finished'] = 1.0;
  }

  /**
   * Batch operation: process NaPTAN data in chunks to enrich stop records.
   *
   * Self-skips when no NaPTAN temp file is available (either enrichment is
   * disabled or the download step failed non-fatally).
   *
   * All sandbox keys are prefixed with "naptan_" to avoid collisions with
   * other operations sharing $context['sandbox'] in the same batch set.
   *
   * @param array<string, mixed> $context
   *   Batch API context array (passed by reference).
   */
  public static function processNaptan(array &$context): void {
    if (!empty($context['results']['error'])) {
      $context['finished'] = 1.0;
      return;
    }

    $tmpFile = $context['results']['naptan_tmp_file'] ?? '';
    if ($tmpFile === '' || !file_exists($tmpFile)) {
      // Download was skipped or failed non-fatally.
      $context['finished'] = 1.0;
      return;
    }

    /** @var \Drupal\localgov_bus_data\Service\NaptanImportService $naptan */
    $naptan = \Drupal::service('localgov_bus_data.naptan_import');

    if (!isset($context['sandbox']['naptan_initialized'])) {
      $handle = fopen($tmpFile, 'r');
      if ($handle === FALSE) {
        // Non-fatal.
        $context['finished'] = 1.0;
        return;
      }
      // Skip header row.
      fgetcsv($handle, escape: '');
      $byteOffset = (int) ftell($handle);
      fclose($handle);

      clearstatcache(TRUE, $tmpFile);
      $context['sandbox']['naptan_initialized'] = TRUE;
      $context['sandbox']['naptan_byte_offset'] = $byteOffset;
      $context['sandbox']['naptan_total_bytes'] = (int) filesize($tmpFile);
      $context['sandbox']['naptan_updated']     = 0;

      $context['message']  = (string) t('Enriching stops from NaPTAN…');
      $context['finished'] = 0.0;
      return;
    }

    try {
      $result = $naptan->processChunk(
        $tmpFile,
        $context['sandbox']['naptan_byte_offset'],
        5000,
      );
    }
    catch (\RuntimeException $e) {
      // Non-fatal.
      \Drupal::logger('localgov_bus_data')->warning(
        'NaPTAN chunk processing failed (non-fatal): @msg',
        ['@msg' => $e->getMessage()],
      );
      @unlink($tmpFile);
      $context['finished'] = 1.0;
      return;
    }

    $prevOffset                               = $context['sandbox']['naptan_byte_offset'];
    $context['sandbox']['naptan_byte_offset'] = $result['offset'];
    $context['sandbox']['naptan_updated']    += $result['updated'];

    if ($result['offset'] === $prevOffset) {
      $count = $context['sandbox']['naptan_updated'];
      \Drupal::logger('localgov_bus_data')->notice(
        'NaPTAN enrichment complete: @count stops updated.',
        ['@count' => $count],
      );
      @unlink($tmpFile);
      $context['message']  = (string) t('NaPTAN enrichment complete (@count stops updated).', [
        '@count' => number_format($count),
      ]);
      $context['finished'] = 1.0;
      return;
    }

    $totalBytes = $context['sandbox']['naptan_total_bytes'];
    $bytesRead = $result['offset'];
    $context['finished'] = $totalBytes > 0 ? min(0.99, $bytesRead / $totalBytes) : 0.5;
    $context['message']  = (string) t('Enriching stops from NaPTAN… @done of @total MB', [
      '@done'  => round($bytesRead / 1024 / 1024, 1),
      '@total' => $totalBytes > 0 ? round($totalBytes / 1024 / 1024, 1) : '?',
    ]);
  }

  /**
   * Batch finished callback.
   *
   * @param bool $success
   *   TRUE if all operations completed without a PHP fatal error.
   * @param array<string, mixed> $results
   *   Accumulated results from all operations.
   * @param array<int, mixed> $operations
   *   Remaining unprocessed operations (non-empty only on fatal failure).
   */
  public static function batchFinished(bool $success, array $results, array $operations): void {
    $tempBase = sys_get_temp_dir() . '/gtfs_bulk_';

    // Safety net: delete the downloaded ZIP if extract() did not already
    // remove it (e.g. a PHP fatal during the download step).
    $tmpZip = $results['tmp_zip'] ?? '';
    if ($tmpZip !== '' && str_starts_with($tmpZip, $tempBase) && file_exists($tmpZip)) {
      @unlink($tmpZip);
    }

    // Safety net: delete the extracted temp dir if a later step did not clean
    // it up (e.g., a PHP fatal between extract and mergeAndStage).
    $tmpDir = $results['tmp_dir'] ?? '';
    if ($tmpDir !== '' && str_starts_with($tmpDir, $tempBase) && is_dir($tmpDir)) {
      try {
        /** @var \Drupal\localgov_bus_data\Service\GtfsImportService $cleanupService */
        $cleanupService = \Drupal::service('localgov_bus_data.gtfs_import');
        $cleanupService->cleanupTempDir($tmpDir);
      }
      catch (\Exception) {
        // Best-effort cleanup; ignore errors.
      }
    }

    $importLogUrl = Url::fromRoute('localgov_bus_data.import_log')->toString();

    $error = $results['error'] ?? NULL;

    if ($success && $error === NULL) {
      \Drupal::messenger()->addStatus(
        t('Bus data import completed. See the <a href=":url">import log</a> for row counts.', [
          ':url' => $importLogUrl,
        ])
      );
      return;
    }

    try {
      /** @var \Drupal\localgov_bus_data\Service\GtfsImportService $service */
      $service    = \Drupal::service('localgov_bus_data.gtfs_import');
      $durationMs = isset($results['start_ms'])
        ? (int) (microtime(TRUE) * 1000) - (int) $results['start_ms']
        : 0;
      $service->writeImportLog(
        'error',
        [],
        $durationMs,
        $error ?? 'Batch processing was interrupted.',
      );
    }
    catch (\Exception) {
      // If the service itself is unavailable, fall back to the logger.
      \Drupal::logger('localgov_bus_data')->error(
        'Batch import failed and import log could not be written: @error',
        ['@error' => $error ?? 'unknown']
      );
    }

    \Drupal::messenger()->addError(
      t('Bus data import failed. Check the <a href=":url">import log</a> for details.', [
        ':url' => $importLogUrl,
      ])
    );
  }

}
