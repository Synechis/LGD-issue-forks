<?php

declare(strict_types=1);

namespace Drupal\localgov_bus_data\Plugin\views\area;

use Drupal\Core\Cache\Cache;
use Drupal\Core\Cache\CacheableDependencyInterface;
use Drupal\Core\Config\ConfigFactoryInterface;
use Drupal\Core\Language\LanguageInterface;
use Drupal\localgov_bus_data\Utility\BusMessages;
use Drupal\views\Attribute\ViewsArea;
use Drupal\views\Plugin\views\area\AreaPluginBase;
use Symfony\Component\DependencyInjection\ContainerInterface;

/**
 * Views area handler for the site-configurable bank holiday notice.
 *
 * The wording lives in localgov_bus_data.settings rather than in each view, so
 * a council can reword it on the module settings form instead of through the
 * Views UI, and a change of operator or phone number no longer needs a module
 * release. Placed in the footer of the bus timetable, route, stop, and stop
 * search views.
 */
#[ViewsArea('localgov_bus_data_bank_holiday_notice')]
final class BankHolidayNotice extends AreaPluginBase implements CacheableDependencyInterface {

  /**
   * The config factory.
   */
  protected ConfigFactoryInterface $configFactory;

  /**
   * {@inheritdoc}
   */
  public static function create(
    ContainerInterface $container,
    array $configuration,
    $plugin_id,
    $plugin_definition,
  ): static {
    $instance = parent::create($container, $configuration, $plugin_id, $plugin_definition);
    $instance->configFactory = $container->get('config.factory');
    return $instance;
  }

  /**
   * {@inheritdoc}
   */
  public function render($empty = FALSE): array {
    // Mirrors core area handlers: hide on an empty result set unless the
    // handler is explicitly configured to show then.
    if ($empty && empty($this->options['empty'])) {
      return [];
    }

    $notice = trim(BusMessages::get($this->configFactory, 'bank_holiday_notice'));
    // A council that clears the setting gets no notice, not an empty tag.
    if ($notice === '') {
      return [];
    }

    return [
      // #value is run through Xss::filterAdmin() by the html_tag element, so
      // the stored text may contain the usual admin tag list and nothing more.
      '#type' => 'html_tag',
      '#tag' => 'p',
      '#attributes' => ['class' => ['bus-service-notice']],
      '#value' => $notice,
      '#cache' => [
        'tags' => $this->getCacheTags(),
        'contexts' => $this->getCacheContexts(),
      ],
    ];
  }

  /**
   * {@inheritdoc}
   */
  public function getCacheTags(): array {
    return ['config:localgov_bus_data.settings'];
  }

  /**
   * {@inheritdoc}
   */
  public function getCacheContexts(): array {
    // The wording is read through the config factory, so language config
    // overrides apply and the output varies by interface language. The four
    // shipped views already carry this context, but the handler is offered for
    // use in any view, including displays that do not.
    return ['languages:' . LanguageInterface::TYPE_INTERFACE];
  }

  /**
   * {@inheritdoc}
   */
  public function getCacheMaxAge(): int {
    return Cache::PERMANENT;
  }

}
