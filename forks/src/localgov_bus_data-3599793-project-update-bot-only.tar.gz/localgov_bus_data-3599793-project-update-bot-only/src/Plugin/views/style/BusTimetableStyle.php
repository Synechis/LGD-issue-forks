<?php

declare(strict_types=1);

namespace Drupal\localgov_bus_data\Plugin\views\style;

use Drupal\Core\Entity\FieldableEntityInterface;
use Drupal\Core\StringTranslation\TranslatableMarkup;
use Drupal\localgov_bus_data\Utility\BusStopHelper;
use Drupal\views\Attribute\ViewsStyle;
use Drupal\views\Plugin\views\style\StylePluginBase;

/**
 * Style plugin that pivots BusStopTime rows into a stop × trip timetable.
 *
 * Rows are keyed by the stop called at and how many times the trip has
 * already called there, not by the GTFS stop sequence number: sequence
 * numbers restart at 1 on every trip, so trips running different stop
 * patterns over the same route would otherwise collide and print their times
 * against stops they do not serve. The row order is an ordered merge of each
 * trip's own stop list, so a variant pattern inserts its extra stops in the
 * right place and a circular route gets one row per call.
 *
 * Known limitation: because the occurrence count is per trip, a partial
 * working that joins a circular route after the repeated stop's first call
 * keys that call as occurrence 0 and so lands on the first occurrence's row.
 * Times are never shown against a stop the trip does not serve, but that
 * column can then read out of order. Matching such a call to the right row
 * would need time-aware alignment, which is out of scope.
 *
 * Each trip becomes a column, ordered by comparing pairs of trips at the
 * first stop both of them serve.
 */
#[ViewsStyle(
  id: 'localgov_bus_timetable',
  title: new TranslatableMarkup('Bus Timetable'),
  help: new TranslatableMarkup('Renders stop times as a pivot table: stops as rows, trips as columns.'),
  theme: 'views_view_localgov_bus_timetable',
  display_types: ['normal'],
)]
final class BusTimetableStyle extends StylePluginBase {

  /**
   * {@inheritdoc}
   */
  protected $usesRowPlugin = FALSE;

  /**
   * {@inheritdoc}
   */
  protected $usesFields = TRUE;

  /**
   * {@inheritdoc}
   */
  public function render(): array {
    $view = $this->view;

    // Render all configured fields (including excluded ones) so their values
    // are stored in $this->rendered_fields and made available to the header
    // and footer area handlers for token replacement. Without this call our
    // custom render() bypass means [bustimes_route_short_name] etc. never get
    // resolved in the header text area.
    if (!empty($view->result)) {
      $this->renderFields($view->result);
    }

    $calls = [];

    foreach ($view->result as $row) {
      /** @var \Drupal\localgov_bus_data\Entity\BusStopTime $entity */
      $entity = $row->_entity;

      $trip_field = $entity->get('bustimes_trip_id');
      if ($trip_field->isEmpty()) {
        continue;
      }
      $trip_entity = $trip_field->entity;
      if ($trip_entity === NULL) {
        continue;
      }

      $departure = (string) ($entity->get('bustimes_departure_time')->value ?? '');
      if (strlen($departure) === 8) {
        $departure = substr($departure, 0, 5);
      }

      $stop_id    = '';
      $stop_name  = '';
      $stop_field = $entity->get('bustimes_stop_id');
      if (!$stop_field->isEmpty()) {
        $stop_entity = $stop_field->entity;
        if ($stop_entity instanceof FieldableEntityInterface) {
          $stop_id   = (string) $stop_entity->id();
          $stop_name = BusStopHelper::getEnrichedName($stop_entity);
        }
      }

      $calls[] = [
        'trip_id'   => (string) $trip_entity->id(),
        'stop_id'   => $stop_id,
        'stop_name' => $stop_name,
        'sequence'  => (int) ($entity->get('bustimes_stop_sequence')->value ?? 0),
        'time'      => $departure,
      ];
    }

    $pivot = $this->buildPivot($calls);

    if ($pivot['stops'] === []) {
      return [];
    }

    return [
      '#theme' => 'views_view_localgov_bus_timetable',
      '#stops' => $pivot['stops'],
      '#trips' => $pivot['trips'],
      '#view' => $view,
      '#cache' => [
        'tags' => [
          'localgov_bus_stop_time_list',
          'localgov_bus_trip_list',
          'localgov_bus_stop_list',
          'localgov_bus_route_list',
        ],
        'contexts' => ['url'],
        'max-age' => 3600,
      ],
    ];
  }

  /**
   * Pivots stop-time call records into timetable rows and ordered columns.
   *
   * Public so the pivot can be unit tested without the entity and views
   * plumbing that render() needs; it is not part of this plugin's API.
   *
   * @param array $calls
   *   List of call records, each an array with:
   *   - trip_id: (string) Trip entity ID.
   *   - stop_id: (string) Stop entity ID, or '' when the stop reference is
   *     missing.
   *   - stop_name: (string) Display name for the stop.
   *   - sequence: (int) GTFS stop sequence number within the trip.
   *   - time: (string) Departure time as "HH:MM".
   *
   * @return array
   *   An array with:
   *   - stops: Ordered list of rows, each an array with 'name' (string) and
   *     'times' (trip ID => departure time).
   *   - trips: Ordered list of trip ID strings, one per column.
   *
   * @internal
   */
  public function buildPivot(array $calls): array {
    // Group calls by trip and put each trip's calls in stop-sequence order.
    // Sequence numbers are only meaningful within a single trip.
    $trips = [];
    foreach ($calls as $call) {
      $trips[$call['trip_id']][] = $call;
    }
    foreach ($trips as &$trip_calls) {
      usort(
        $trip_calls,
        static fn(array $a, array $b): int => $a['sequence'] <=> $b['sequence'],
      );
    }
    unset($trip_calls);

    // Key each call by the stop it serves plus how many times this trip has
    // already called there. Keying on the stop alone would collapse the two
    // calls a circular route makes at the same stop into one row.
    //
    // A call whose stop reference does not resolve (a dangling target left
    // behind by a deleted stop) falls back to its trip and sequence number.
    // The sequence alone is only unique within one trip, so an unscoped
    // fallback would merge unrelated trips onto a single row, which is the
    // very collision this keying exists to prevent.
    $patterns = [];
    $times    = [];
    $names    = [];
    foreach ($trips as $trip_id => $trip_calls) {
      $counts = [];
      foreach ($trip_calls as $call) {
        $stop          = $call['stop_id'] !== ''
          ? 'stop:' . $call['stop_id']
          : 'seq:' . $trip_id . ':' . $call['sequence'];
        $occurrence    = $counts[$stop] ?? 0;
        $counts[$stop] = $occurrence + 1;

        $key                   = $stop . '#' . $occurrence;
        $patterns[$trip_id][]  = $key;
        $times[$trip_id][$key] = $call['time'];
        $names[$key]         ??= $call['stop_name'];
      }
    }

    if ($patterns === []) {
      return ['stops' => [], 'trips' => []];
    }

    // Merge every trip's stop list into a single row order, longest pattern
    // first so the fullest journey forms the spine and variant patterns only
    // insert the rows they add.
    $merge_order = array_keys($patterns);
    usort($merge_order, static function ($a, $b) use ($patterns): int {
      $by_length = count($patterns[$b]) <=> count($patterns[$a]);
      return $by_length !== 0 ? $by_length : ($a <=> $b);
    });

    $rows = [];
    foreach ($merge_order as $trip_id) {
      $rows = self::mergePattern($rows, $patterns[$trip_id]);
    }

    // Deduplicate trips whose entire schedule is identical (duplicate GTFS
    // source records from BODS). Fingerprint each trip from its (stop, time)
    // pairs, so two trips running to the same clock times over different
    // stops are not mistaken for each other.
    $seen   = [];
    $unique = [];
    foreach ($patterns as $trip_id => $pattern) {
      $fingerprint = implode('|', array_map(
        static fn(string $key): string => $key . '@' . $times[$trip_id][$key],
        $pattern,
      ));
      if (!isset($seen[$fingerprint])) {
        $seen[$fingerprint] = TRUE;
        $unique[]           = $trip_id;
      }
    }

    // Order columns by comparing each pair of trips at the first row both of
    // them serve. Sorting on each trip's own first departure instead would
    // place a short working that starts partway along after a full journey it
    // is in fact running ahead of at every stop they share.
    //
    // Trips form a partial order, so this pairwise comparison is not
    // guaranteed to be transitive: three trips whose shared stops imply
    // conflicting orders land in some arbitrary but stable order rather
    // than a demonstrably correct one. Real timetables share enough stops
    // for this to be well behaved in practice.
    usort($unique, static function ($a, $b) use ($rows, $times, $patterns): int {
      foreach ($rows as $key) {
        if (isset($times[$a][$key], $times[$b][$key])) {
          $shared = strcmp($times[$a][$key], $times[$b][$key]);
          if ($shared !== 0) {
            return $shared;
          }
        }
      }
      // No stop in common, or the same time at every stop they share: fall
      // back to each trip's own first departure.
      return strcmp(
        $times[$a][$patterns[$a][0]] ?? '',
        $times[$b][$patterns[$b][0]] ?? '',
      );
    });

    $stops = [];
    foreach ($rows as $key) {
      $row_times = [];
      foreach ($unique as $trip_id) {
        if (isset($times[$trip_id][$key])) {
          $row_times[$trip_id] = $times[$trip_id][$key];
        }
      }
      // Safety net only: a deduplicated trip has the same (stop, time)
      // pairs as the trip it duplicates, so every row it contributed is
      // still served by a surviving trip.
      if ($row_times === []) {
        continue;
      }
      $stops[] = [
        'name'  => $names[$key],
        'times' => $row_times,
      ];
    }

    return [
      'stops' => $stops,
      'trips' => array_map(static fn($trip_id): string => (string) $trip_id, $unique),
    ];
  }

  /**
   * Merges one trip's ordered stop list into the running row order.
   *
   * Rows the running order already holds fix the insertion point; rows it
   * does not hold yet are spliced in where this trip reaches them. Where two
   * trips disagree about the order of a shared stop the existing row is kept,
   * so a conflicting pattern never duplicates a row.
   *
   * @param string[] $rows
   *   The running row order.
   * @param string[] $pattern
   *   One trip's ordered row keys.
   *
   * @return string[]
   *   The merged row order.
   */
  private static function mergePattern(array $rows, array $pattern): array {
    $insert = 0;
    foreach ($pattern as $key) {
      $offset = array_search($key, array_slice($rows, $insert), TRUE);
      if ($offset !== FALSE) {
        $insert += $offset + 1;
        continue;
      }
      if (in_array($key, $rows, TRUE)) {
        continue;
      }
      array_splice($rows, $insert, 0, [$key]);
      $insert++;
    }

    return $rows;
  }

}
