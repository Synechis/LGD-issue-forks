<?php

declare(strict_types=1);

namespace Drupal\localgov_bus_data\Plugin\views\style;

use Drupal\Core\Entity\FieldableEntityInterface;
use Drupal\Core\StringTranslation\TranslatableMarkup;
use Drupal\localgov_bus_data\Utility\BusStopHelper;
use Drupal\views\Attribute\ViewsStyle;
use Drupal\views\Plugin\views\style\StylePluginBase;

/**
 * Style plugin that pivots BusStopTime rows into a stop × trip timetable.
 *
 * Each stop appears once as a row header; each trip becomes a column with its
 * departure time at that stop. Columns are ordered by the departure time at
 * the first stop in sequence.
 */
#[ViewsStyle(
  id: 'localgov_bus_timetable',
  title: new TranslatableMarkup('Bus Timetable'),
  help: new TranslatableMarkup('Renders stop times as a pivot table: stops as rows, trips as columns.'),
  theme: 'views_view_localgov_bus_timetable',
  display_types: ['normal'],
)]
final class BusTimetableStyle extends StylePluginBase {

  /**
   * {@inheritdoc}
   */
  protected $usesRowPlugin = FALSE;

  /**
   * {@inheritdoc}
   */
  protected $usesFields = TRUE;

  /**
   * {@inheritdoc}
   */
  public function render(): array {
    $view = $this->view;

    // Render all configured fields (including excluded ones) so their values
    // are stored in $this->rendered_fields and made available to the header
    // and footer area handlers for token replacement. Without this call our
    // custom render() bypass means [bustimes_route_short_name] etc. never get
    // resolved in the header text area.
    if (!empty($view->result)) {
      $this->renderFields($view->result);
    }

    $stops    = [];
    $trip_ids = [];

    foreach ($view->result as $row) {
      /** @var \Drupal\localgov_bus_data\Entity\BusStopTime $entity */
      $entity = $row->_entity;

      $sequence = (int) ($entity->get('bustimes_stop_sequence')->value ?? 0);

      $departure = (string) ($entity->get('bustimes_departure_time')->value ?? '');
      if (strlen($departure) === 8) {
        $departure = substr($departure, 0, 5);
      }

      $stop_name = '';
      $stop_field = $entity->get('bustimes_stop_id');
      if (!$stop_field->isEmpty()) {
        $stop_entity = $stop_field->entity;
        if ($stop_entity instanceof FieldableEntityInterface) {
          $stop_name = BusStopHelper::getEnrichedName($stop_entity);
        }
      }

      $trip_field = $entity->get('bustimes_trip_id');
      if ($trip_field->isEmpty()) {
        continue;
      }
      $trip_entity = $trip_field->entity;
      if ($trip_entity === NULL) {
        continue;
      }
      $trip_id = (string) $trip_entity->id();

      if (!isset($stops[$sequence])) {
        $stops[$sequence] = [
          'name' => $stop_name,
          'times' => [],
        ];
      }
      $stops[$sequence]['times'][$trip_id] = $departure;

      if (!isset($trip_ids[$trip_id])) {
        $trip_ids[$trip_id] = TRUE;
      }
    }

    if (empty($stops)) {
      return [];
    }

    ksort($stops);

    // Deduplicate trips whose entire schedule is identical (duplicate GTFS
    // source records from BODS). Fingerprint each trip by joining its
    // departure times across all stops in sequence order; keep only the first
    // trip seen for each unique fingerprint.
    $seen_fingerprints = [];
    $unique_trip_ids   = [];
    foreach (array_keys($trip_ids) as $tid) {
      $fingerprint = implode('|', array_map(
        static fn(array $stop) => $stop['times'][$tid] ?? '',
        $stops,
      ));
      if (!isset($seen_fingerprints[$fingerprint])) {
        $seen_fingerprints[$fingerprint] = TRUE;
        $unique_trip_ids[$tid]           = TRUE;
      }
    }

    foreach ($stops as $seq => $stop) {
      foreach (array_keys($stop['times']) as $tid) {
        if (!isset($unique_trip_ids[$tid])) {
          unset($stops[$seq]['times'][$tid]);
        }
      }
    }

    $ordered_trips = array_keys($unique_trip_ids);
    $first_stop = reset($stops);
    usort($ordered_trips, static function (string $a, string $b) use ($first_stop): int {
      $time_a = $first_stop['times'][$a] ?? '99:99';
      $time_b = $first_stop['times'][$b] ?? '99:99';
      return strcmp($time_a, $time_b);
    });

    return [
      '#theme' => 'views_view_localgov_bus_timetable',
      '#stops' => $stops,
      '#trips' => $ordered_trips,
      '#view' => $view,
      '#cache' => [
        'tags' => [
          'localgov_bus_stop_time_list',
          'localgov_bus_trip_list',
          'localgov_bus_stop_list',
          'localgov_bus_route_list',
        ],
        'contexts' => ['url'],
        'max-age' => 3600,
      ],
    ];
  }

}
