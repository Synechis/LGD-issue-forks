<?php

declare(strict_types=1);

namespace Drupal\localgov_bus_data\Controller;

use Drupal\Core\Controller\ControllerBase;
use Drupal\Core\Database\Connection;
use Drupal\Core\Entity\EntityTypeManagerInterface;
use Symfony\Component\DependencyInjection\ContainerInterface;
use Symfony\Component\HttpFoundation\JsonResponse;
use Symfony\Component\HttpFoundation\Request;

/**
 * Returns autocomplete suggestions for bus operator (agency) names.
 */
final class OperatorAutocompleteController extends ControllerBase {

  /**
   * Minimum fragment length before any matches are returned.
   */
  private const MIN_QUERY_LENGTH = 2;

  /**
   * Maximum number of suggestions returned.
   */
  private const MAX_RESULTS = 10;

  public function __construct(
    private readonly Connection $database,
    EntityTypeManagerInterface $entityTypeManager,
  ) {
    $this->entityTypeManager = $entityTypeManager;
  }

  /**
   * {@inheritdoc}
   */
  public static function create(ContainerInterface $container): static {
    return new static(
      $container->get('database'),
      $container->get('entity_type.manager'),
    );
  }

  /**
   * Returns JSON autocomplete matches for an operator name fragment.
   *
   * An operator repeats across many routes, so this reads distinct
   * bustimes_agency_name values with a DISTINCT query rather than loading
   * route entities. Operator names are public, non-sensitive data.
   *
   * @param \Symfony\Component\HttpFoundation\Request $request
   *   The current request; the "q" query parameter holds the fragment.
   *
   * @return \Symfony\Component\HttpFoundation\JsonResponse
   *   A list of {value, label} suggestion objects.
   */
  public function autocomplete(Request $request): JsonResponse {
    $query = mb_substr((string) $request->query->get('q', ''), 0, 128);

    $suggestions = [];
    if (mb_strlen($query) >= self::MIN_QUERY_LENGTH) {
      $table = $this->entityTypeManager
        ->getDefinition('localgov_bus_route')
        ->getBaseTable();
      $names = $this->database->select($table, 'r')
        ->fields('r', ['bustimes_agency_name'])
        ->condition('r.bustimes_agency_name', '%' . $this->database->escapeLike($query) . '%', 'LIKE')
        ->condition('r.bustimes_agency_name', '', '<>')
        ->distinct()
        ->orderBy('r.bustimes_agency_name')
        ->range(0, self::MAX_RESULTS)
        ->execute()
        ->fetchCol();

      foreach ($names as $name) {
        $suggestions[] = ['value' => $name, 'label' => $name];
      }
    }

    $response = new JsonResponse($suggestions);
    $response->setMaxAge(60);
    $response->setPublic();
    return $response;
  }

}
