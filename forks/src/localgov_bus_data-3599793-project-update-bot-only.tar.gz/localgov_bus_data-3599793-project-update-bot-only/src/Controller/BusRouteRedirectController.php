<?php

declare(strict_types=1);

namespace Drupal\localgov_bus_data\Controller;

use Drupal\Core\Cache\CacheableMetadata;
use Drupal\Core\Cache\CacheableRedirectResponse;
use Drupal\Core\Controller\ControllerBase;
use Drupal\Core\Entity\EntityTypeManagerInterface;
use Drupal\Core\Http\Exception\CacheableNotFoundHttpException;
use Drupal\Core\Url;
use Symfony\Component\DependencyInjection\ContainerInterface;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;

/**
 * Redirects the old two-segment bus route URL to its current destination.
 *
 * The timetable page grew a third (slug) segment in issue #3599802 so that
 * distinct GTFS routes sharing an agency and route short name no longer
 * merge onto one page. The old two-segment path is dead but is still the
 * path in existing external links, bookmarks and search results, so this
 * controller looks up the intended destination instead of leaving those
 * links to 404 or (previously) show the wrong merged timetable.
 */
final class BusRouteRedirectController extends ControllerBase {

  public function __construct(
    EntityTypeManagerInterface $entityTypeManager,
  ) {
    $this->entityTypeManager = $entityTypeManager;
  }

  /**
   * {@inheritdoc}
   */
  public static function create(ContainerInterface $container): static {
    return new static(
      $container->get('entity_type.manager'),
    );
  }

  /**
   * Redirects /buses/routes/{agency_id}/{route_short_name}.
   *
   * One matching route redirects (302) to its three-segment timetable URL.
   * A 302, not a 301, because a later feed change can retire that slug, and
   * a 301 risks the browser caching a redirect to a URL that stops existing.
   * More than one match redirects (302) to the route search results,
   * filtered to that route number, which already lists each match with its
   * destination and links to the right page. No match throws
   * NotFoundHttpException so the visitor gets the site's themed 404 page,
   * with its navigation and search, rather than a bare empty body.
   *
   * All three outcomes carry the localgov_bus_route entity type's list cache
   * tag, so a route added or removed by a later import is not hidden behind a
   * cached redirect or 404. Drupal invalidates that tag automatically
   * whenever a localgov_bus_route entity is saved or deleted.
   *
   * The no-match case has to throw a *cacheable* exception to keep that tag.
   * Core's DefaultExceptionHtmlSubscriber does
   * $response->addCacheableDependency($exception) on the rendered 404 page,
   * and CacheableMetadata::createFromObject() assigns max-age 0 to anything
   * that is not a CacheableDependencyInterface. A plain
   * NotFoundHttpException would therefore make every 404 this controller
   * produces uncacheable, on top of dropping the tag.
   *
   * The incoming query string is carried onto both targets. The old and new
   * timetable pages are the same view with the same exposed filter
   * identifiers (bustimes_direction_id, the day filters), so a bookmarked
   * URL keeps the direction and day the visitor had selected rather than
   * silently landing them on the view's defaults.
   *
   * @throws \Drupal\Core\Http\Exception\CacheableNotFoundHttpException
   *   When no route matches the agency ID and route short name.
   */
  public function redirectLegacyPath(Request $request, string $agency_id, string $route_short_name): Response {
    $storage = $this->entityTypeManager->getStorage('localgov_bus_route');
    $routes = $storage->loadByProperties([
      'bustimes_agency_id' => $agency_id,
      'bustimes_route_short_name' => $route_short_name,
    ]);

    // url.query_args: both redirect targets carry the incoming query string
    // through, so a cached redirect must not be reused for a request that
    // arrived with different exposed filter values.
    $cache = (new CacheableMetadata())
      ->addCacheTags(['localgov_bus_route_list'])
      ->addCacheContexts(['url.query_args']);

    if (count($routes) === 0) {
      throw new CacheableNotFoundHttpException($cache);
    }

    $query = $request->query->all();

    /** @var \Drupal\localgov_bus_data\Entity\BusRoute|null $route */
    $route = count($routes) === 1 ? reset($routes) : NULL;
    $slug = $route?->get('bustimes_slug')->value;

    // More than one match, or a single match whose slug has not been
    // backfilled yet by GtfsImportService (a route entity can exist briefly
    // without one during import), both go to the search results: building a
    // three-segment URL with an empty final segment would not match the
    // timetable route at all.
    if ($route === NULL || $slug === NULL || $slug === '') {
      // array_merge, not +, so the route number filter wins: an incoming
      // query must not override the one thing this redirect exists to narrow
      // the list down to.
      $generated_url = Url::fromRoute('view.localgov_bus_routes.page_search_bus_services', [], [
        'query' => array_merge($query, ['bustimes_route_short_name' => $route_short_name]),
      ])->toString(TRUE);

      $response = new CacheableRedirectResponse($generated_url->getGeneratedUrl(), 302);
      $response->addCacheableDependency($cache);
      $response->addCacheableDependency($generated_url);
      return $response;
    }

    $generated_url = Url::fromRoute('view.localgov_bus_timetable.page_bus_timetable', [
      'arg_0' => $route->get('bustimes_agency_id')->value,
      'arg_1' => $route->get('bustimes_route_short_name')->value,
      'arg_2' => $slug,
    ], ['query' => $query])->toString(TRUE);

    $response = new CacheableRedirectResponse($generated_url->getGeneratedUrl(), 302);
    $response->addCacheableDependency($cache);
    $response->addCacheableDependency($generated_url);
    return $response;
  }

}
