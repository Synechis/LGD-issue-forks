<?php

declare(strict_types=1);

namespace Drupal\localgov_bus_data\EventSubscriber;

use Drupal\Core\Config\ConfigFactoryInterface;
use Drupal\Core\Routing\RouteSubscriberBase;
use Symfony\Component\Routing\RouteCollection;

/**
 * Keeps the legacy route redirect underneath the timetable page path.
 *
 * The localgov_bus_data.route_redirect route is declared in routing.yml
 * with the default /buses/routes base, but a site can move the bus pages
 * elsewhere through the homepage submodule's settings form, which rewrites
 * the Views display paths. With a hardcoded route path, a moved site's old
 * two-segment URLs got no redirect at all. This subscriber reads the
 * timetable view's live page path and puts the redirect route directly
 * underneath it instead.
 *
 * The path is read from raw config rather than through the View entity so
 * that no entity storage is needed during a route rebuild, and from the
 * timetable view rather than the homepage submodule's settings because the
 * main module must not depend on that submodule.
 */
final class BusRouteRedirectRouteSubscriber extends RouteSubscriberBase {

  /**
   * Base path used when the timetable page path cannot be read.
   */
  private const DEFAULT_BASE = 'buses/routes';

  /**
   * The three argument segments on the timetable page path.
   */
  private const ARGUMENT_SUFFIX = '/%/%/%';

  public function __construct(
    private readonly ConfigFactoryInterface $configFactory,
  ) {}

  /**
   * {@inheritdoc}
   */
  protected function alterRoutes(RouteCollection $collection): void {
    $route = $collection->get('localgov_bus_data.route_redirect');
    if (!$route) {
      return;
    }

    $route->setPath('/' . $this->timetableBasePath() . '/{agency_id}/{route_short_name}');
  }

  /**
   * Returns the timetable page path with its argument segments stripped.
   *
   * @return string
   *   The base path with no leading or trailing slash, e.g.
   *   'parking-roads-and-transport/bus-services/buses/routes'.
   */
  private function timetableBasePath(): string {
    $path = (string) $this->configFactory
      ->get('views.view.localgov_bus_timetable')
      ->get('display.page_bus_timetable.display_options.path');

    // Anything else (the view is missing, or update_10011 has not run yet and
    // the page is still on a two-segment path) falls back to the default.
    // That at worst leaves the redirect where routing.yml put it, rather than
    // placing it on top of the timetable page's own path.
    if (!str_ends_with($path, self::ARGUMENT_SUFFIX)) {
      return self::DEFAULT_BASE;
    }

    $base = trim(substr($path, 0, -strlen(self::ARGUMENT_SUFFIX)), '/');

    return $base === '' ? self::DEFAULT_BASE : $base;
  }

}
