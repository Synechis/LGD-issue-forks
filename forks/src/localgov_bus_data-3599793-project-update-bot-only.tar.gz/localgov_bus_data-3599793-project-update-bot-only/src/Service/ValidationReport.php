<?php

declare(strict_types=1);

namespace Drupal\localgov_bus_data\Service;

/**
 * Collects validation errors and accepted row counts for a custom CSV set.
 *
 * Built up incrementally by CustomCsvValidator as it works through each
 * staged file, then read back by CustomCsvManager and CustomCsvForm to
 * decide whether to save the upload and to render the reject-with-report
 * table.
 */
final class ValidationReport {

  /**
   * Validation errors found so far.
   *
   * @var array<int, array{file: string, line: int, column: string|null, message: string}>
   */
  private array $errors = [];

  /**
   * Accepted row counts, keyed by file key (e.g. "stops").
   *
   * @var array<string, int>
   */
  private array $acceptedRowCounts = [];

  /**
   * Records a single validation error.
   *
   * @param string $file
   *   File key the error relates to (e.g. "stops").
   * @param int $line
   *   One-based line number, counting from the header row.
   * @param string|null $column
   *   Column name the error relates to, or NULL when not column-specific.
   * @param string $message
   *   Human-readable description of the problem.
   */
  public function addError(string $file, int $line, ?string $column, string $message): void {
    $this->errors[] = [
      'file'    => $file,
      'line'    => $line,
      'column'  => $column,
      'message' => $message,
    ];
  }

  /**
   * Returns all recorded errors in the order they were added.
   *
   * @return array<int, array{file: string, line: int, column: string|null, message: string}>
   *   The recorded errors.
   */
  public function getErrors(): array {
    return $this->errors;
  }

  /**
   * Whether the validated set contains no errors.
   */
  public function isValid(): bool {
    return $this->errors === [];
  }

  /**
   * Total number of recorded errors across all files.
   */
  public function errorCount(): int {
    return count($this->errors);
  }

  /**
   * Number of distinct files that have at least one recorded error.
   */
  public function fileErrorCount(): int {
    $files = [];
    foreach ($this->errors as $error) {
      $files[$error['file']] = TRUE;
    }
    return count($files);
  }

  /**
   * Records the number of accepted rows for a file.
   *
   * @param string $file
   *   File key (e.g. "stops").
   * @param int $count
   *   Number of data rows read from the file (excluding the header).
   */
  public function setAcceptedRowCount(string $file, int $count): void {
    $this->acceptedRowCounts[$file] = $count;
  }

  /**
   * Returns accepted row counts keyed by file key.
   *
   * @return array<string, int>
   *   Row counts.
   */
  public function getAcceptedRowCounts(): array {
    return $this->acceptedRowCounts;
  }

}
