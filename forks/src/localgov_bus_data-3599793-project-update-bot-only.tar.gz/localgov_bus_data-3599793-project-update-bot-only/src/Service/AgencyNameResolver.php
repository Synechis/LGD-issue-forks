<?php

declare(strict_types=1);

namespace Drupal\localgov_bus_data\Service;

use Drupal\Core\File\FileSystemInterface;

/**
 * Parses the staged GTFS agency.txt into an agency_id => agency_name map.
 *
 * Used at import time to denormalise the operator name onto each bus route, so
 * display paths can read the stored name instead of re-parsing the file on
 * every render.
 */
final class AgencyNameResolver {

  /**
   * URI of the staged GTFS agency file.
   */
  private const AGENCY_FILE_URI = 'public://bus-times/gtfs/agency.txt';

  public function __construct(
    private readonly FileSystemInterface $fileSystem,
  ) {}

  /**
   * Returns agency_id => agency_name from the staged agency.txt.
   *
   * @return array<string, string>
   *   Map of GTFS agency IDs to agency names. Empty if the file is missing,
   *   unreadable, or has no usable header.
   */
  public function getAgencyNames(): array {
    $path = $this->fileSystem->realpath(self::AGENCY_FILE_URI);
    if ($path === FALSE) {
      return [];
    }
    return $this->parseAgencyFile($path);
  }

  /**
   * Parses a GTFS agency.txt file into an agency_id => agency_name map.
   *
   * Separated from getAgencyNames() so it can be unit-tested against a fixture
   * path without a Drupal stream wrapper.
   *
   * @param string $path
   *   Absolute filesystem path to an agency.txt file.
   *
   * @return array<string, string>
   *   Map of GTFS agency IDs to agency names. Rows with an empty id or name
   *   are skipped.
   */
  public function parseAgencyFile(string $path): array {
    if (!is_file($path) || !is_readable($path)) {
      return [];
    }

    $handle = fopen($path, 'r');
    if ($handle === FALSE) {
      return [];
    }

    $names = [];

    try {
      $header = fgetcsv($handle, escape: '');
      if (!is_array($header) || $header === [NULL]) {
        return [];
      }

      $columns = array_flip($header);
      if (!isset($columns['agency_id']) || !isset($columns['agency_name'])) {
        return [];
      }

      $idIndex   = $columns['agency_id'];
      $nameIndex = $columns['agency_name'];

      while (($row = fgetcsv($handle, escape: '')) !== FALSE) {
        $id   = trim((string) ($row[$idIndex] ?? ''));
        $name = trim((string) ($row[$nameIndex] ?? ''));
        if ($id === '' || $name === '') {
          continue;
        }
        $names[$id] = $name;
      }
    }
    finally {
      fclose($handle);
    }

    return $names;
  }

}
