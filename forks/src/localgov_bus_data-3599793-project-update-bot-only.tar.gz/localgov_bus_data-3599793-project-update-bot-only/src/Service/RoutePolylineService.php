<?php

declare(strict_types=1);

namespace Drupal\localgov_bus_data\Service;

use Drupal\Core\Database\Connection;

/**
 * Builds connecting line segments for the route map from filtered trips.
 *
 * Given a route, an active direction and an active day type, this selects the
 * matching trips (mirroring the timetable view's query filtering), joins
 * consecutive stops within each trip in service order, and deduplicates the
 * resulting segments across those trips. The result is a "segment union" that
 * covers every filtered stop once, with the shared trunk drawn a single time
 * and no cross-trip zigzag.
 *
 * When the matching trips carry a GTFS shape_id and shape geometry has been
 * imported into localgov_bus_shape, the road-following shape polyline is
 * preferred. Where no shape is present the service falls back to the
 * segment-union straight lines described above, so bends and loops are
 * approximate only for shape-less routes.
 */
final class RoutePolylineService {

  /**
   * Maps an active day type to its calendar boolean column.
   *
   * Keys mirror the timetable view's exposed day identifiers; values are the
   * localgov_bus_calendar columns. Used as a whitelist so the day type can be
   * interpolated into the query safely.
   */
  private const DAY_COLUMNS = [
    'weekdays' => 'bustimes_weekday',
    'saturday' => 'bustimes_saturday',
    'sunday'   => 'bustimes_sunday',
  ];

  /**
   * Douglas-Peucker simplification tolerance, in metres.
   *
   * GTFS shapes.txt traces are far denser than a road-map line needs to look
   * correct: long rural routes can carry 1,000-5,000+ points, most of them
   * within a metre or two of the simplified path. Left unsimplified, this
   * bloats the page's GeoJSON payload and Leaflet's client-side rendering
   * cost in proportion to route length. 12m keeps the line visually
   * indistinguishable from the raw trace at normal map zoom while cutting
   * point counts substantially on long shapes.
   */
  private const SIMPLIFY_TOLERANCE_METRES = 12.0;

  /**
   * Mean Earth radius in metres, for the flat-plane projection below.
   */
  private const EARTH_RADIUS_METRES = 6371000.0;

  public function __construct(
    private readonly Connection $database,
  ) {}

  /**
   * Returns deduplicated line segments for a filtered route.
   *
   * @param string $agencyId
   *   GTFS agency id (bustimes_agency_id).
   * @param string $routeShortName
   *   Route short name (bustimes_route_short_name).
   * @param string $directionId
   *   Active direction: '0' (outbound) or '1' (inbound).
   * @param string $dayType
   *   Active day type: 'weekdays', 'saturday', or 'sunday'.
   * @param string $today
   *   Current date as 'Y-m-d' (UTC), for the service-period restriction.
   *
   * @return list<array{0: array{lat: float, lon: float}, 1: array{lat: float, lon: float}}>
   *   List of two-point segments. Empty if no trips or coordinates match.
   */
  public function getRouteSegments(
    string $agencyId,
    string $routeShortName,
    string $directionId,
    string $dayType,
    string $today,
  ): array {
    $trips = $this->loadTripPoints($agencyId, $routeShortName, $directionId, $dayType, $today);
    return $this->buildSegments($trips);
  }

  /**
   * Returns the polylines to draw for a filtered route.
   *
   * Prefers the road-following GTFS shape geometry when the matching trips
   * carry a shape that has been imported into localgov_bus_shape. Falls back to
   * the straight-line segment union (as two-point polylines) when no shape is
   * available. Each polyline is an ordered list of points; the caller renders
   * one Leaflet linestring feature per polyline.
   *
   * @param string $agencyId
   *   GTFS agency id (bustimes_agency_id).
   * @param string $routeShortName
   *   Route short name (bustimes_route_short_name).
   * @param string $directionId
   *   Active direction: '0' (outbound) or '1' (inbound).
   * @param string $dayType
   *   Active day type: 'weekdays', 'saturday', or 'sunday'.
   * @param string $today
   *   Current date as 'Y-m-d' (UTC), for the service-period restriction.
   *
   * @return list<list<array{lat: float, lon: float}>>
   *   List of polylines. Empty if nothing matches.
   */
  public function getRoutePolylines(
    string $agencyId,
    string $routeShortName,
    string $directionId,
    string $dayType,
    string $today,
  ): array {
    $shapePoints = $this->loadShapePoints($agencyId, $routeShortName, $directionId, $dayType, $today);
    $trips = $this->loadTripPoints($agencyId, $routeShortName, $directionId, $dayType, $today);
    return $this->buildPolylines($shapePoints, $trips);
  }

  /**
   * Loads ordered shape points for the shapes used by the matching trips.
   *
   * Applies the same direction/day/service-period filter as loadTripPoints(),
   * resolves the distinct shape_ids of those trips, then reads their points
   * from localgov_bus_shape ordered by sequence. Returns an empty array when no
   * matching trip carries a shape or no geometry has been imported.
   *
   * @param string $agencyId
   *   GTFS agency id.
   * @param string $routeShortName
   *   Route short name.
   * @param string $directionId
   *   Active direction ('0' or '1').
   * @param string $dayType
   *   Active day type ('weekdays', 'saturday', or 'sunday').
   * @param string $today
   *   Current date as 'Y-m-d' (UTC).
   *
   * @return array<string, list<array{lat: mixed, lon: mixed}>>
   *   Map of shape_id to its ordered list of points.
   */
  private function loadShapePoints(
    string $agencyId,
    string $routeShortName,
    string $directionId,
    string $dayType,
    string $today,
  ): array {
    $dayColumn = self::DAY_COLUMNS[$dayType] ?? NULL;
    if ($dayColumn === NULL) {
      return [];
    }

    // Shape geometry is optional; the table only exists once the update hook
    // has run. Guard so a pre-update install falls back cleanly.
    if (!$this->database->schema()->tableExists('localgov_bus_shape')) {
      return [];
    }

    $shapeIdQuery = $this->database->select('localgov_bus_route', 'r');
    $shapeIdQuery->join('localgov_bus_trip', 't', 't.bustimes_route_id = r.id');
    $shapeIdQuery->join('localgov_bus_calendar', 'c', 'c.id = t.bustimes_service_id');
    $shapeIdQuery->addField('t', 'bustimes_shape_id', 'shape_id');
    $shapeIdQuery->condition('r.bustimes_agency_id', $agencyId);
    $shapeIdQuery->condition('r.bustimes_route_short_name', $routeShortName);
    $shapeIdQuery->condition('t.bustimes_direction_id', $directionId);
    $shapeIdQuery->isNotNull('t.bustimes_shape_id');
    $shapeIdQuery->condition('t.bustimes_shape_id', '', '<>');
    $shapeIdQuery->condition("c.$dayColumn", 1);
    $shapeIdQuery->where(
      'c.bustimes_start_date <= :today AND c.bustimes_end_date >= :today',
      [':today' => $today],
    );
    $shapeIdQuery->distinct();

    $shapeIds = $shapeIdQuery->execute()->fetchCol();
    $shapeIds = array_values(array_filter(array_map('strval', $shapeIds), static fn(string $id): bool => $id !== ''));
    if ($shapeIds === []) {
      return [];
    }

    $pointsQuery = $this->database->select('localgov_bus_shape', 's');
    $pointsQuery->addField('s', 'shape_id', 'shape_id');
    $pointsQuery->addField('s', 'shape_pt_lat', 'lat');
    $pointsQuery->addField('s', 'shape_pt_lon', 'lon');
    $pointsQuery->condition('s.shape_id', $shapeIds, 'IN');
    $pointsQuery->orderBy('s.shape_id');
    $pointsQuery->orderBy('s.shape_pt_sequence');

    $shapes = [];
    foreach ($pointsQuery->execute() as $row) {
      $shapes[(string) $row->shape_id][] = ['lat' => $row->lat, 'lon' => $row->lon];
    }
    return $shapes;
  }

  /**
   * Loads ordered stop coordinates per matching trip.
   *
   * Selects trips for the route whose direction matches, whose calendar has the
   * active day flag set, and whose service period currently covers today. This
   * mirrors localgov_bus_data_views_query_alter so the line matches the markers
   * and the timetable.
   *
   * @param string $agencyId
   *   GTFS agency id.
   * @param string $routeShortName
   *   Route short name.
   * @param string $directionId
   *   Active direction ('0' or '1').
   * @param string $dayType
   *   Active day type ('weekdays', 'saturday', or 'sunday').
   * @param string $today
   *   Current date as 'Y-m-d' (UTC).
   *
   * @return array<int|string, list<array{lat: mixed, lon: mixed}>>
   *   Map of trip id to its ordered list of stop coordinates.
   */
  private function loadTripPoints(
    string $agencyId,
    string $routeShortName,
    string $directionId,
    string $dayType,
    string $today,
  ): array {
    // Whitelist the day column; never interpolate caller input directly. An
    // unrecognised day type yields no line rather than an unvalidated column.
    $dayColumn = self::DAY_COLUMNS[$dayType] ?? NULL;
    if ($dayColumn === NULL) {
      return [];
    }

    $query = $this->database->select('localgov_bus_route', 'r');
    $query->join('localgov_bus_trip', 't', 't.bustimes_route_id = r.id');
    $query->join('localgov_bus_calendar', 'c', 'c.id = t.bustimes_service_id');
    $query->join('localgov_bus_stop_time', 'st', 'st.bustimes_trip_id = t.id');
    $query->join('localgov_bus_stop', 's', 's.id = st.bustimes_stop_id');
    $query->addField('t', 'id', 'trip_id');
    $query->addField('st', 'bustimes_stop_sequence', 'seq');
    $query->addField('s', 'bustimes_stop_lat', 'lat');
    $query->addField('s', 'bustimes_stop_lon', 'lon');
    $query->condition('r.bustimes_agency_id', $agencyId);
    $query->condition('r.bustimes_route_short_name', $routeShortName);
    $query->condition('t.bustimes_direction_id', $directionId);
    $query->condition("c.$dayColumn", 1);
    $query->where(
      'c.bustimes_start_date <= :today AND c.bustimes_end_date >= :today',
      [':today' => $today],
    );
    $query->orderBy('t.id');
    $query->orderBy('st.bustimes_stop_sequence');

    $trips = [];
    foreach ($query->execute() as $row) {
      $trips[$row->trip_id][] = ['lat' => $row->lat, 'lon' => $row->lon];
    }
    return $trips;
  }

  /**
   * Builds deduplicated two-point segments from per-trip stop coordinates.
   *
   * Pure and DB-free so it can be unit-tested. For each trip the coordinates
   * are cleaned (invalid points dropped, consecutive duplicates collapsed) and
   * then joined into consecutive segments. Segments are deduplicated across all
   * trips on an undirected basis, so the shared trunk is emitted once. Trips
   * with fewer than two valid points contribute no segments.
   *
   * @param array<int|string, list<array{lat: mixed, lon: mixed}>> $trips
   *   Map of trip id to its ordered list of stop coordinates.
   *
   * @return list<array{0: array{lat: float, lon: float}, 1: array{lat: float, lon: float}}>
   *   List of deduplicated two-point segments.
   */
  public function buildSegments(array $trips): array {
    $segments = [];
    $seen = [];

    foreach ($trips as $points) {
      $clean = $this->cleanPoints($points);
      $count = count($clean);
      if ($count < 2) {
        continue;
      }

      for ($i = 0; $i < $count - 1; $i++) {
        $a = $clean[$i];
        $b = $clean[$i + 1];
        $keyA = $this->pointKey($a);
        $keyB = $this->pointKey($b);
        // Undirected dedup: order the endpoint keys so A-B and B-A collapse.
        $segmentKey = $keyA < $keyB ? "$keyA|$keyB" : "$keyB|$keyA";
        if (isset($seen[$segmentKey])) {
          continue;
        }
        $seen[$segmentKey] = TRUE;
        $segments[] = [$a, $b];
      }
    }

    return $segments;
  }

  /**
   * Chooses the polylines to draw, preferring shape geometry over segments.
   *
   * If any shape yields a usable (>= 2 point) cleaned polyline, the shape
   * polylines are returned and the stop segments are ignored. Otherwise the
   * straight-line segment union is returned as two-point polylines. Pure and
   * DB-free so both the preference and the fallback are unit-testable.
   *
   * @param array<string, list<array{lat: mixed, lon: mixed}>> $shapePoints
   *   Map of shape_id to its ordered list of raw shape points.
   * @param array<int|string, list<array{lat: mixed, lon: mixed}>> $tripStopPoints
   *   Map of trip id to its ordered list of stop coordinates (fallback source).
   *
   * @return list<list<array{lat: float, lon: float}>>
   *   List of polylines, each an ordered list of points.
   */
  public function buildPolylines(array $shapePoints, array $tripStopPoints): array {
    $shapePolylines = $this->buildShapePolylines($shapePoints);
    if ($shapePolylines !== []) {
      return $shapePolylines;
    }

    // Fallback: represent each straight-line segment as a two-point polyline.
    $polylines = [];
    foreach ($this->buildSegments($tripStopPoints) as $segment) {
      $polylines[] = [$segment[0], $segment[1]];
    }
    return $polylines;
  }

  /**
   * Builds cleaned, simplified road-following polylines from shape points.
   *
   * Each shape's points are cleaned with the same rules as the segment builder
   * (invalid and 0,0 points dropped, consecutive duplicates collapsed), then
   * reduced with Douglas-Peucker simplification so dense GTFS traces don't
   * bloat the map payload on long routes. Shapes that reduce to fewer than
   * two points are discarded. Pure and DB-free.
   *
   * @param array<string, list<array{lat: mixed, lon: mixed}>> $shapePoints
   *   Map of shape_id to its ordered list of raw shape points.
   *
   * @return list<list<array{lat: float, lon: float}>>
   *   One cleaned, simplified polyline per usable shape.
   */
  public function buildShapePolylines(array $shapePoints): array {
    $polylines = [];
    foreach ($shapePoints as $points) {
      $clean = $this->cleanPoints($points);
      if (count($clean) >= 2) {
        $polylines[] = $this->simplifyPolyline($clean, self::SIMPLIFY_TOLERANCE_METRES);
      }
    }
    return $polylines;
  }

  /**
   * Reduces a polyline with Douglas-Peucker simplification.
   *
   * Projects the points onto a local flat plane (equirectangular, referenced
   * to the polyline's own first point), then iteratively keeps only the
   * points that deviate from the current simplified line by more than the
   * tolerance. An explicit stack is used instead of recursion so dense
   * shapes (thousands of points) can't exhaust the call stack. The first and
   * last points are always kept, so endpoints never move.
   *
   * @param list<array{lat: float, lon: float}> $points
   *   Ordered list of cleaned coordinates.
   * @param float $toleranceMetres
   *   Maximum perpendicular deviation, in metres, a dropped point may have
   *   from the simplified line.
   *
   * @return list<array{lat: float, lon: float}>
   *   The simplified point list, in original order.
   */
  public function simplifyPolyline(array $points, float $toleranceMetres): array {
    $count = count($points);
    if ($count < 3) {
      return $points;
    }

    $projected = $this->projectToLocalMetres($points);

    $keep = array_fill(0, $count, FALSE);
    $keep[0] = TRUE;
    $keep[$count - 1] = TRUE;

    $stack = [[0, $count - 1]];
    while ($stack !== []) {
      [$start, $end] = array_pop($stack);

      $maxDistance = 0.0;
      $maxIndex = -1;
      for ($i = $start + 1; $i < $end; $i++) {
        $distance = $this->perpendicularDistance($projected[$i], $projected[$start], $projected[$end]);
        if ($distance > $maxDistance) {
          $maxDistance = $distance;
          $maxIndex = $i;
        }
      }

      if ($maxDistance > $toleranceMetres && $maxIndex !== -1) {
        $keep[$maxIndex] = TRUE;
        $stack[] = [$start, $maxIndex];
        $stack[] = [$maxIndex, $end];
      }
    }

    $simplified = [];
    foreach ($points as $index => $point) {
      if ($keep[$index]) {
        $simplified[] = $point;
      }
    }
    return $simplified;
  }

  /**
   * Projects points onto a local flat plane, in metres.
   *
   * Uses an equirectangular approximation referenced to the first point's
   * latitude. This is accurate enough for a simplification tolerance of a
   * few metres over the scale of a single bus route (at most tens of
   * kilometres); it is not intended for general-purpose geodesy.
   *
   * @param list<array{lat: float, lon: float}> $points
   *   Ordered list of coordinates.
   *
   * @return list<array{x: float, y: float}>
   *   Points projected onto the local plane, in metres.
   */
  private function projectToLocalMetres(array $points): array {
    $refLatRad = deg2rad($points[0]['lat']);

    $projected = [];
    foreach ($points as $point) {
      $projected[] = [
        'x' => deg2rad($point['lon']) * cos($refLatRad) * self::EARTH_RADIUS_METRES,
        'y' => deg2rad($point['lat']) * self::EARTH_RADIUS_METRES,
      ];
    }
    return $projected;
  }

  /**
   * Computes the perpendicular distance from a point to a line, in metres.
   *
   * @param array{x: float, y: float} $point
   *   The point to measure from.
   * @param array{x: float, y: float} $lineStart
   *   One end of the line.
   * @param array{x: float, y: float} $lineEnd
   *   The other end of the line.
   *
   * @return float
   *   Perpendicular distance in metres.
   */
  private function perpendicularDistance(array $point, array $lineStart, array $lineEnd): float {
    $dx = $lineEnd['x'] - $lineStart['x'];
    $dy = $lineEnd['y'] - $lineStart['y'];

    if ($dx === 0.0 && $dy === 0.0) {
      // Degenerate "line" (both ends coincide): distance to that single point.
      return sqrt(($point['x'] - $lineStart['x']) ** 2 + ($point['y'] - $lineStart['y']) ** 2);
    }

    $numerator = abs($dy * $point['x'] - $dx * $point['y'] + $lineEnd['x'] * $lineStart['y'] - $lineEnd['y'] * $lineStart['x']);
    $denominator = sqrt($dx ** 2 + $dy ** 2);
    return $numerator / $denominator;
  }

  /**
   * Cleans an ordered coordinate list for one trip.
   *
   * Drops null, empty, and 0,0 coordinates, then collapses consecutive
   * duplicate points so a repeated stop does not create a zero-length segment.
   * Pure and DB-free.
   *
   * @param list<array{lat: mixed, lon: mixed}> $points
   *   Ordered list of raw stop coordinates.
   *
   * @return list<array{lat: float, lon: float}>
   *   Cleaned ordered list of float coordinates.
   */
  public function cleanPoints(array $points): array {
    $clean = [];
    $previousKey = NULL;

    foreach ($points as $point) {
      $lat = $point['lat'] ?? NULL;
      $lon = $point['lon'] ?? NULL;
      if (!$this->isValidCoordinate($lat, $lon)) {
        continue;
      }

      $resolved = ['lat' => (float) $lat, 'lon' => (float) $lon];
      $key = $this->pointKey($resolved);
      if ($key === $previousKey) {
        continue;
      }

      $clean[] = $resolved;
      $previousKey = $key;
    }

    return $clean;
  }

  /**
   * Determines whether a coordinate pair is usable.
   *
   * @param mixed $lat
   *   Latitude value.
   * @param mixed $lon
   *   Longitude value.
   *
   * @return bool
   *   TRUE if both values are present and not the 0,0 null-island point.
   */
  private function isValidCoordinate(mixed $lat, mixed $lon): bool {
    if ($lat === NULL || $lon === NULL || $lat === '' || $lon === '') {
      return FALSE;
    }
    return !((float) $lat === 0.0 && (float) $lon === 0.0);
  }

  /**
   * Builds a stable string key for a coordinate, used for dedup comparison.
   *
   * @param array{lat: float, lon: float} $point
   *   A resolved coordinate.
   *
   * @return string
   *   Canonical "lat,lon" key rounded to 6 decimal places (~0.1m).
   */
  private function pointKey(array $point): string {
    return number_format($point['lat'], 6, '.', '')
      . ',' . number_format($point['lon'], 6, '.', '');
  }

}
