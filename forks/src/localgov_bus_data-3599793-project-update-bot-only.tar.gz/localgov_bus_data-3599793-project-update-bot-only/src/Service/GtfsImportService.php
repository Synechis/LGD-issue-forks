<?php

declare(strict_types=1);

namespace Drupal\localgov_bus_data\Service;

use Drupal\Core\StringTranslation\StringTranslationTrait;
use Drupal\Component\Uuid\UuidInterface;
use Drupal\Core\Cache\Cache;
use Drupal\Core\Config\ConfigFactoryInterface;
use Drupal\Core\Database\Connection;
use Drupal\Core\Entity\EntityTypeManagerInterface;
use Drupal\Core\File\FileSystemInterface;
use Drupal\geofield\WktGeneratorInterface;
use Drupal\migrate\MigrateExecutable;
use Drupal\migrate\MigrateMessage;
use Drupal\migrate\Plugin\MigrationInterface;
use Drupal\migrate\Plugin\MigrationPluginManagerInterface;
use Psr\Log\LoggerInterface;

/**
 * Orchestrates the full GTFS timetable import pipeline.
 *
 * Shared by both the Drush command (direct call) and the web UI "Import now"
 * button (via the Batch API). All import logic lives here so neither entry
 * point depends on the other.
 *
 * The CLI path calls run() which processes everything in a single PHP process.
 * The web-batch path calls the individual public helper methods (one per batch
 * operation) so each HTTP request stays within the server's request timeout.
 */
final class GtfsImportService {

  use StringTranslationTrait;

  /**
   * Migration IDs in dependency order.
   *
   * @var array<int, string>
   */
  private const MIGRATION_IDS = [
    'localgov_bus_data_routes',
    'localgov_bus_data_stops',
    'localgov_bus_data_calendars',
    'localgov_bus_data_trips',
    'localgov_bus_data_stop_times',
  ];

  /**
   * The four migrations run via MigrateExecutable on the CLI/cron path.
   *
   * Stop-times are excluded: both the full and incremental CLI paths bypass
   * MigrateExecutable for stop_times and use processStopTimesChunk() direct
   * inserts instead. The web-batch path handles trips via processTripChunk()
   * and stop-times via processStopTimesChunk() for the same reason.
   *
   * @var array<int, string>
   */
  private const CORE_MIGRATION_IDS = [
    'localgov_bus_data_routes',
    'localgov_bus_data_stops',
    'localgov_bus_data_calendars',
    'localgov_bus_data_trips',
  ];

  /**
   * Maps each migration ID to its entity base table.
   *
   * @var array<string, string>
   */
  private const MIGRATION_TABLES = [
    'localgov_bus_data_routes'     => 'localgov_bus_route',
    'localgov_bus_data_stops'      => 'localgov_bus_stop',
    'localgov_bus_data_calendars'  => 'localgov_bus_calendar',
    'localgov_bus_data_trips'      => 'localgov_bus_trip',
    'localgov_bus_data_stop_times' => 'localgov_bus_stop_time',
  ];

  /**
   * GTFS files merged into the staging directory.
   *
   * @var array<int, string>
   */
  private const GTFS_FILES = [
    'agency.txt',
    'routes.txt',
    'stops.txt',
    'calendar.txt',
    'trips.txt',
    'stop_times.txt',
    'shapes.txt',
  ];

  public function __construct(
    private readonly ConfigFactoryInterface $configFactory,
    private readonly GtfsDownloader $gtfsDownloader,
    private readonly GtfsFilter $gtfsFilter,
    private readonly MigrationPluginManagerInterface $migrationPluginManager,
    private readonly Connection $database,
    private readonly FileSystemInterface $fileSystem,
    private readonly LoggerInterface $logger,
    private readonly UuidInterface $uuid,
    private readonly NaptanImportService $naptanImportService,
    private readonly EntityTypeManagerInterface $entityTypeManager,
    private readonly WktGeneratorInterface $wktGenerator,
    private readonly AgencyNameResolver $agencyNameResolver,
    private readonly CustomCsvManager $customCsvManager,
  ) {}

  /**
   * Runs the full or incremental import pipeline in a single PHP process.
   *
   * Used by the Drush command and hook_cron(). No chunking — the caller is
   * responsible for ensuring the process is not subject to HTTP timeouts.
   *
   * @param bool $dryRun
   *   When TRUE, logs what would happen but makes no changes.
   * @param bool $incremental
   *   When TRUE, runs an incremental import (add/update/delete changed rows).
   *   When FALSE (default), truncates all data and re-imports from scratch.
   *
   * @throws \RuntimeException
   *   Re-thrown after logging so callers can react.
   */
  public function run(bool $dryRun = FALSE, bool $incremental = FALSE): void {
    $config = $this->configFactory->get('localgov_bus_data.settings');

    if (!$config->get('source.enabled')) {
      $this->logger->notice('LocalGov Bus Data import skipped: source is disabled in settings.');
      return;
    }

    if ($dryRun) {
      $this->logger->notice('Dry-run: would download bulk GTFS and filter to configured geographic boundary.');
      $this->logger->notice('Dry-run complete. No data was modified.');
      return;
    }

    $startMs = (int) (microtime(TRUE) * 1000);
    $tmpZip  = sys_get_temp_dir() . '/gtfs_bulk_' . uniqid('', TRUE) . '.zip';
    $tmpDir  = '';

    try {
      $stagingDir = $this->prepareStagingDirectory();

      $this->logger->notice('Downloading bulk GTFS (this may take several minutes)...');
      $this->gtfsDownloader->downloadBulkGtfs($tmpZip);

      $tmpDir = sys_get_temp_dir() . '/gtfs_bulk_' . uniqid('', TRUE);
      if (!mkdir($tmpDir, 0755, TRUE)) {
        throw new \RuntimeException('Could not create temp extraction directory.');
      }

      $zip = new \ZipArchive();
      if ($zip->open($tmpZip) !== TRUE) {
        throw new \RuntimeException('Could not open bulk GTFS ZIP archive.');
      }

      for ($i = 0; $i < $zip->numFiles; $i++) {
        $name = $zip->getNameIndex($i);
        if ($name === FALSE || str_contains($name, '..') || str_starts_with($name, '/') || str_starts_with($name, '\\')) {
          $zip->close();
          throw new \RuntimeException(sprintf(
            'Unsafe ZIP entry "%s" in bulk GTFS archive — aborting.',
            $name === FALSE ? '(unknown)' : $name,
          ));
        }
      }

      $zip->extractTo($tmpDir);
      $zip->close();
      @unlink($tmpZip);
      $tmpZip = '';

      $this->logger->notice('Filtering GTFS data to configured geographic boundary...');
      $this->gtfsFilter->filterByGeography($tmpDir);
      $this->mergeGtfsFiles($tmpDir, $stagingDir);

      try {
        $this->snapshotCleanStaging($stagingDir);
      }
      catch (\Throwable $e) {
        // A failed snapshot must not skip the (unrelated) custom-data merge
        // below; it only means the next "Validate now" or replace/remove
        // action revalidates against a stale snapshot until the following
        // import refreshes it, which is not fatal here.
        $this->logger->warning('Clean GTFS staging snapshot failed (non-fatal): @msg', ['@msg' => $e->getMessage()]);
      }

      try {
        $customDataNote = $this->mergeCustomData($stagingDir);
      }
      catch (\Throwable $e) {
        // Custom data must never fail the import. Catches \Throwable, not
        // \RuntimeException: nothing in CustomCsvManager's call chain
        // currently throws, so this is a defensive net against any future
        // exception or error type, not a documented exception contract.
        $this->logger->warning('Custom data merge failed (non-fatal): @msg @trace', [
          '@msg'   => $e->getMessage(),
          '@trace' => $e->getTraceAsString(),
        ]);
        $customDataNote = 'Custom data skipped: an unexpected error occurred, see the log.';
      }

      $rowCounts = $incremental
        ? $this->runIncrementalMigrations()
        : $this->runAllMigrations();

      if ($this->naptanImportService->isEnabled()) {
        try {
          $this->naptanImportService->enrich();
        }
        catch (\RuntimeException $e) {
          // NaPTAN enrichment is optional; log but do not abort the import.
          $this->logger->warning('NaPTAN enrichment failed (non-fatal): @msg', ['@msg' => $e->getMessage()]);
        }
      }

      $durationMs = (int) (microtime(TRUE) * 1000) - $startMs;
      $message = 'Import completed successfully.';
      if ($customDataNote !== '') {
        $message .= ' ' . $customDataNote;
      }
      $this->writeImportLog('success', $rowCounts, $durationMs, $message);

      $this->logger->notice('Import complete in @ms ms. Row counts: @counts', [
        '@ms'     => $durationMs,
        '@counts' => json_encode($rowCounts),
      ]);
    }
    catch (\RuntimeException $e) {
      $durationMs = (int) (microtime(TRUE) * 1000) - $startMs;
      $this->writeImportLog('error', [], $durationMs, $e->getMessage());
      $this->logger->error('Import failed: @msg', ['@msg' => $e->getMessage()]);
      throw $e;
    }
    finally {
      if ($tmpZip !== '') {
        @unlink($tmpZip);
      }
      if ($tmpDir !== '' && is_dir($tmpDir)) {
        $this->deleteTempDir($tmpDir);
      }
    }
  }

  /**
   * Returns the Batch API definition for a multi-step web-triggered import.
   *
   * Each operation completes quickly enough to stay within a typical nginx
   * fastcgi_read_timeout. The download uses Range-request chunking (5 MB per
   * batch pass); stop-times are written via direct DB inserts (10 000 rows per
   * batch pass) rather than MigrateExecutable.
   *
   * @return array<string, mixed>
   *   Drupal Batch API definition array.
   */
  public function buildBatchDefinition(): array {
    return [
      'title'            => $this->t('Importing GTFS bus timetable data'),
      'init_message'     => $this->t('Starting GTFS import…'),
      'progress_message' => $this->t('Processing step @current of @total…'),
      'error_message'    => $this->t('GTFS import encountered an error. Check the import log.'),
      'operations'       => [
        ['\Drupal\localgov_bus_data\Batch\GtfsImportBatch::download', []],
        ['\Drupal\localgov_bus_data\Batch\GtfsImportBatch::extract', []],
        ['\Drupal\localgov_bus_data\Batch\GtfsImportBatch::filterGeographyCollect', []],
        ['\Drupal\localgov_bus_data\Batch\GtfsImportBatch::filterGeographyRewrite', []],
        ['\Drupal\localgov_bus_data\Batch\GtfsImportBatch::mergeAndStage', []],
        ['\Drupal\localgov_bus_data\Batch\GtfsImportBatch::mergeCustomData', []],
        ['\Drupal\localgov_bus_data\Batch\GtfsImportBatch::truncate', []],
        ['\Drupal\localgov_bus_data\Batch\GtfsImportBatch::runMigration', ['localgov_bus_data_routes']],
        ['\Drupal\localgov_bus_data\Batch\GtfsImportBatch::runMigration', ['localgov_bus_data_calendars']],
        ['\Drupal\localgov_bus_data\Batch\GtfsImportBatch::processStops', []],
        ['\Drupal\localgov_bus_data\Batch\GtfsImportBatch::processTrips', []],
        ['\Drupal\localgov_bus_data\Batch\GtfsImportBatch::processStopTimes', []],
        ['\Drupal\localgov_bus_data\Batch\GtfsImportBatch::processShapes', []],
        ['\Drupal\localgov_bus_data\Batch\GtfsImportBatch::downloadNaptan', []],
        ['\Drupal\localgov_bus_data\Batch\GtfsImportBatch::processNaptan', []],
        ['\Drupal\localgov_bus_data\Batch\GtfsImportBatch::finalize', []],
      ],
      'finished'         => '\Drupal\localgov_bus_data\Batch\GtfsImportBatch::batchFinished',
    ];
  }

  /**
   * Returns the configured bulk GTFS download URL.
   */
  public function getDownloadUrl(): string {
    return (string) ($this->configFactory
      ->get('localgov_bus_data.settings')
      ->get('source.bulk_gtfs_url')
      ?? 'https://data.bus-data.dft.gov.uk/timetable/download/gtfs-file/all/');
  }

  /**
   * Returns the absolute path to the GTFS staging directory.
   *
   * Creates the directory if it does not already exist. Unlike
   * prepareStagingDirectory() this method does NOT clear existing files.
   *
   * @throws \RuntimeException
   */
  public function getStagingDirPath(): string {
    $uri = 'public://bus-times/gtfs';
    $this->fileSystem->prepareDirectory($uri, FileSystemInterface::CREATE_DIRECTORY);
    $path = $this->fileSystem->realpath($uri);
    if ($path === FALSE) {
      throw new \RuntimeException('Cannot locate GTFS staging directory: ' . $uri);
    }
    return $path;
  }

  /**
   * Returns the absolute path to the clean (pre-custom-merge) GTFS snapshot.
   *
   * A copy of the staged GTFS files as rebuilt from the feed, taken before
   * mergeCustomData() appends any custom rows into the live staging
   * directory. mergeIntoStaging() mutates the live staging directory
   * directly, and that merge is only undone at the start of the next
   * import (prepareStagingDirectory() truncates and rebuilds it), so
   * between imports, the live directory still contains the previous
   * merge's custom rows. Revalidating the stored custom set against the
   * live directory at that point would see the set's own already-merged
   * IDs and report them as colliding with staged data, a false positive
   * against itself. This snapshot exists so validation that happens
   * outside the moment right after a staging rebuild, such as "Validate
   * now" and the revalidation after replacing or removing a stored file,
   * has something clean to check against instead.
   *
   * @throws \RuntimeException
   */
  public function getCleanStagingDirPath(): string {
    $uri = 'public://bus-times/gtfs-clean';
    $this->fileSystem->prepareDirectory($uri, FileSystemInterface::CREATE_DIRECTORY);
    $path = $this->fileSystem->realpath($uri);
    if ($path === FALSE) {
      throw new \RuntimeException('Cannot locate clean GTFS staging snapshot directory: ' . $uri);
    }
    return $path;
  }

  /**
   * Returns the staging directory custom-data validation should read from.
   *
   * Normally the clean snapshot (see getCleanStagingDirPath()). But on a site
   * that deployed this feature with staged data already present yet no
   * import has completed since (so snapshotCleanStaging() has never run),
   * the clean snapshot is still an empty directory this method itself would
   * otherwise have just created. Validating against an empty snapshot there
   * would falsely reject every reference to real feed IDs. In that
   * situation the live staging directory is clean by definition, since
   * nothing has merged custom rows into it yet, so fall back to it.
   *
   * @throws \RuntimeException
   */
  public function getValidationStagingDirPath(): string {
    $cleanDir = $this->getCleanStagingDirPath();
    if (file_exists($cleanDir . '/stops.txt')) {
      return $cleanDir;
    }

    $liveDir = $this->getStagingDirPath();
    return file_exists($liveDir . '/stops.txt') ? $liveDir : $cleanDir;
  }

  /**
   * Copies the freshly-staged GTFS files into the clean snapshot directory.
   *
   * Called immediately after mergeGtfsFiles() rebuilds the live staging
   * directory from the feed, and before mergeCustomData() has a chance to
   * append any custom rows into it, so the snapshot always reflects the
   * feed alone. See getCleanStagingDirPath() for why this snapshot exists.
   *
   * Callers treat any failure here as non-fatal (see run() and
   * batchMergeAndStage()): if a copy fails partway through, the files
   * already copied this cycle are refreshed but the remainder keep
   * whatever they held from the previous cycle, so the snapshot may be
   * left in a partially-stale state until the next successful run.
   *
   * @param string $stagingDir
   *   Absolute path to the just-rebuilt live staging directory.
   *
   * @throws \RuntimeException
   */
  private function snapshotCleanStaging(string $stagingDir): void {
    $cleanDir = $this->getCleanStagingDirPath();
    foreach (self::GTFS_FILES as $filename) {
      $source = $stagingDir . '/' . $filename;
      $dest = $cleanDir . '/' . $filename;
      if (file_exists($source)) {
        if (!copy($source, $dest)) {
          throw new \RuntimeException("Could not copy {$filename} to the clean GTFS staging snapshot.");
        }
      }
      elseif (file_exists($dest)) {
        unlink($dest);
      }
    }
  }

  /**
   * Extracts the bulk GTFS ZIP archive into a temporary directory.
   *
   * Called by the batch extract operation. Deletes the source ZIP after
   * extraction. Returns the temp directory path so the subsequent
   * filterGeography batch step can consume it.
   *
   * @param string $tmpZip
   *   Absolute path to the downloaded ZIP file.
   *
   * @return string
   *   Absolute path to the extracted temp directory.
   *
   * @throws \RuntimeException
   */
  public function batchExtract(string $tmpZip): string {
    $tmpDir = sys_get_temp_dir() . '/gtfs_bulk_' . uniqid('', TRUE);
    if (!mkdir($tmpDir, 0755, TRUE)) {
      throw new \RuntimeException('Could not create temp extraction directory.');
    }

    $success = FALSE;
    try {
      $zip = new \ZipArchive();
      if ($zip->open($tmpZip) !== TRUE) {
        throw new \RuntimeException('Could not open bulk GTFS ZIP archive.');
      }

      for ($i = 0; $i < $zip->numFiles; $i++) {
        $name = $zip->getNameIndex($i);
        if ($name === FALSE || str_contains($name, '..') || str_starts_with($name, '/') || str_starts_with($name, '\\')) {
          $zip->close();
          throw new \RuntimeException(sprintf(
            'Unsafe ZIP entry "%s" in bulk GTFS archive — aborting.',
            $name === FALSE ? '(unknown)' : $name,
          ));
        }
      }

      $zip->extractTo($tmpDir);
      $zip->close();
      @unlink($tmpZip);
      $success = TRUE;
    }
    finally {
      if (!$success && is_dir($tmpDir)) {
        $this->deleteTempDir($tmpDir);
      }
    }

    return $tmpDir;
  }

  /**
   * Scans stops and stop_times to identify trips serving the configured area.
   *
   * Called by the batch filterGeographyCollect operation. Writes the result to
   * valid_trip_ids.json in $tmpDir for consumption by batchFilterRewrite().
   *
   * @param string $tmpDir
   *   Absolute path to the extracted temp directory.
   *
   * @throws \RuntimeException
   */
  public function batchFilterCollect(string $tmpDir): void {
    $this->gtfsFilter->collectValidTrips($tmpDir);
  }

  /**
   * Rewrites the GTFS files to retain only the trips identified by the filter.
   *
   * Called by the batch filterGeographyRewrite operation. Reads
   * valid_trip_ids.json written by batchFilterCollect(). The temp directory
   * is left in place for the subsequent mergeAndStage batch step to consume.
   *
   * @param string $tmpDir
   *   Absolute path to the extracted temp directory.
   *
   * @throws \RuntimeException
   */
  public function batchFilterRewrite(string $tmpDir): void {
    $this->gtfsFilter->rewriteByValidTrips($tmpDir);
  }

  /**
   * Merges filtered GTFS files into the staging directory.
   *
   * Called by the batch mergeAndStage operation. Cleans up the temp extraction
   * directory when done, regardless of success or failure.
   *
   * @param string $tmpDir
   *   Absolute path to the extracted, filtered temp directory.
   *
   * @throws \RuntimeException
   */
  public function batchMergeAndStage(string $tmpDir): void {
    try {
      $stagingDir = $this->prepareStagingDirectory();
      $this->mergeGtfsFiles($tmpDir, $stagingDir);
      try {
        $this->snapshotCleanStaging($stagingDir);
      }
      catch (\Throwable $e) {
        // Custom data must never fail the import; a failed snapshot only
        // means the next "Validate now" or replace/remove action
        // revalidates against a stale snapshot until the following import
        // refreshes it, which is not fatal here.
        $this->logger->warning('Clean GTFS staging snapshot failed (non-fatal): @msg', ['@msg' => $e->getMessage()]);
      }
    }
    finally {
      if (is_dir($tmpDir)) {
        $this->deleteTempDir($tmpDir);
      }
    }
  }

  /**
   * Revalidates and merges the stored custom data set, if enabled.
   *
   * Called by the batch mergeCustomData operation, between mergeAndStage and
   * truncate. Resolves the staging directory itself so the batch operation
   * does not need to track it.
   *
   * @return string
   *   A note to append to the import log message; see mergeCustomData().
   */
  public function batchMergeCustomData(): string {
    return $this->mergeCustomData($this->getStagingDirPath());
  }

  /**
   * Removes a temp directory left over from a failed batch run.
   *
   * Public wrapper around deleteTempDir() for use in batch finished callbacks.
   *
   * @param string $dir
   *   Absolute path to the directory to remove.
   */
  public function cleanupTempDir(string $dir): void {
    $this->deleteTempDir($dir);
  }

  /**
   * Truncates all bus-data tables.
   *
   * Called by the batch truncate operation. Separated from the per-migration
   * batch operations so truncation and each migration each get their own
   * HTTP request window on timeout-limited hosts.
   */
  public function batchTruncate(): void {
    $this->logger->notice('Truncating existing bus data tables...');
    $this->bulkTruncate();
    $this->logger->notice('Truncation complete.');
  }

  /**
   * Runs a single migration and returns the imported row count.
   *
   * Called by the batch runMigration operation, one migration at a time, so
   * each migration gets its own HTTP request window.
   *
   * @param string $migrationId
   *   One of the CORE_MIGRATION_IDS values.
   *
   * @return int
   *   Number of rows imported (from the migrate map table).
   *
   * @throws \RuntimeException
   *   If the migration does not complete successfully.
   */
  public function batchRunMigration(string $migrationId): int {
    $migration = $this->migrationPluginManager->createInstance($migrationId);
    $result    = (new MigrateExecutable($migration, new MigrateMessage()))->import();
    if ($result !== MigrationInterface::RESULT_COMPLETED) {
      throw new \RuntimeException("Migration {$migrationId} did not complete (result: {$result}).");
    }

    $mapTable = 'migrate_map_' . $migrationId;
    try {
      $count = (int) $this->database
        ->select($mapTable, 'm')
        ->countQuery()
        ->execute()
        ->fetchField();
    }
    catch (\Exception) {
      $count = 0;
    }

    $this->logger->notice('Imported @id: @count rows.', [
      '@id'    => $migrationId,
      '@count' => $count,
    ]);

    return $count;
  }

  /**
   * Runs the four core migrations (routes, stops, calendars, trips).
   *
   * @return array<string, int>
   *   Row counts keyed by migration ID.
   *
   * @throws \RuntimeException
   */
  private function runCoreMigrations(): array {
    $message   = new MigrateMessage();
    $rowCounts = [];

    foreach (self::CORE_MIGRATION_IDS as $id) {
      $migration = $this->migrationPluginManager->createInstance($id);
      $result    = (new MigrateExecutable($migration, $message))->import();
      if ($result !== MigrationInterface::RESULT_COMPLETED) {
        throw new \RuntimeException("Migration {$id} did not complete (result: {$result}).");
      }

      $mapTable = 'migrate_map_' . $id;
      try {
        $count = (int) $this->database
          ->select($mapTable, 'm')
          ->countQuery()
          ->execute()
          ->fetchField();
      }
      catch (\Exception) {
        $count = 0;
      }

      $rowCounts[$id] = $count;
      $this->logger->notice('Imported @id: @count rows.', [
        '@id'    => $id,
        '@count' => $count,
      ]);
    }

    return $rowCounts;
  }

  /**
   * Returns a map of GTFS route_id strings to Drupal entity IDs.
   *
   * Loaded from the migrate map table after the routes migration has run.
   *
   * @return array<string, string>
   *   Map of GTFS route_id string to Drupal entity ID (as string from DB).
   */
  public function loadRouteIdMap(): array {
    return $this->database
      ->select('migrate_map_localgov_bus_data_routes', 'm')
      ->fields('m', ['sourceid1', 'destid1'])
      ->execute()
      ->fetchAllKeyed();
  }

  /**
   * Returns a map of GTFS service_id strings to Drupal entity IDs.
   *
   * Loaded from the migrate map table after the calendars migration has run.
   *
   * @return array<string, string>
   *   Map of GTFS service_id string to Drupal entity ID (as string from DB).
   */
  public function loadCalendarIdMap(): array {
    return $this->database
      ->select('migrate_map_localgov_bus_data_calendars', 'm')
      ->fields('m', ['sourceid1', 'destid1'])
      ->execute()
      ->fetchAllKeyed();
  }

  /**
   * Returns a map of GTFS trip_id strings to Drupal entity IDs.
   *
   * Loaded from the localgov_bus_trip base table. Reading the base table
   * (rather than the migrate map) ensures this works on the web-batch path
   * where trips are inserted via processTripChunk() without MigrateExecutable.
   *
   * @return array<string, string>
   *   Map of GTFS trip_id string to Drupal entity ID (as string from DB).
   */
  public function loadTripIdMap(): array {
    return $this->database
      ->select('localgov_bus_trip', 't')
      ->fields('t', ['bustimes_trip_id', 'id'])
      ->execute()
      ->fetchAllKeyed();
  }

  /**
   * Returns a map of GTFS stop_id strings to Drupal entity IDs.
   *
   * Loaded from the localgov_bus_stop base table. Reading the base table
   * (rather than the migrate map) ensures this works on the web-batch path
   * where stops are inserted via processStopsChunk() without MigrateExecutable.
   *
   * @return array<string, string>
   *   Map of GTFS stop_id string to Drupal entity ID (as string from DB).
   */
  public function loadStopIdMap(): array {
    return $this->database
      ->select('localgov_bus_stop', 's')
      ->fields('s', ['bustimes_stop_id', 'id'])
      ->execute()
      ->fetchAllKeyed();
  }

  /**
   * Processes a chunk of stops CSV rows and saves them as entities.
   *
   * Uses the entity API so that the geofield bustimes_location is correctly
   * populated from lat/lon via the field's setValue() logic. Keeps each HTTP
   * request well within server timeout limits by processing at most $limit
   * rows per call.
   *
   * @param string $csvFile
   *   Absolute path to stops.txt.
   * @param int $byteOffset
   *   Byte position to seek to before reading.
   * @param array<string, int> $headerCols
   *   Map of column name → zero-based index.
   * @param int $limit
   *   Maximum rows to process in this call.
   *
   * @return array{processed: int, offset: int}
   *   processed — entities saved.
   *   offset — byte position after the last row read (next byteOffset).
   *
   * @throws \RuntimeException
   */
  public function processStopsChunk(
    string $csvFile,
    int $byteOffset,
    array $headerCols,
    int $limit,
  ): array {
    $stopIdIdx     = $headerCols['stop_id'] ?? 0;
    $nameIdx       = $headerCols['stop_name'] ?? 1;
    $latIdx        = $headerCols['stop_lat'] ?? 2;
    $lonIdx        = $headerCols['stop_lon'] ?? 3;
    $wheelchairIdx = $headerCols['wheelchair_boarding'] ?? NULL;

    $handle = @fopen($csvFile, 'r');
    if ($handle === FALSE) {
      throw new \RuntimeException("Cannot open stops file: {$csvFile}");
    }

    $processed = 0;
    $newOffset = $byteOffset;

    try {
      fseek($handle, $byteOffset);
      $storage = $this->entityTypeManager->getStorage('localgov_bus_stop');

      for ($i = 0; $i < $limit; $i++) {
        $row = fgetcsv($handle, escape: '');
        if ($row === FALSE) {
          break;
        }
        if (count($row) < 4) {
          continue;
        }

        $stopId     = trim((string) ($row[$stopIdIdx] ?? ''));
        $name       = trim((string) ($row[$nameIdx] ?? ''));
        $lat        = (float) ($row[$latIdx] ?? 0);
        $lon        = (float) ($row[$lonIdx] ?? 0);
        $wheelchair = ($wheelchairIdx !== NULL && isset($row[$wheelchairIdx]))
          ? (int) $row[$wheelchairIdx]
          : 0;

        if ($stopId === '') {
          continue;
        }

        $values = [
          'uuid'                         => $this->uuid->generate(),
          'bustimes_stop_id'             => $stopId,
          'bustimes_stop_name'           => $name !== '' ? $name : $stopId,
          'bustimes_stop_lat'            => $lat,
          'bustimes_stop_lon'            => $lon,
          'bustimes_wheelchair_boarding' => $wheelchair,
        ];

        // Only set geofield when we have valid coordinates.
        if ($lat !== 0.0 || $lon !== 0.0) {
          $values['bustimes_location'] = $this->wktGenerator->WktBuildPoint([$lon, $lat]);
        }

        $entity = $storage->create($values);
        $entity->save();
        $processed++;
      }

      $newOffset = (int) ftell($handle);
    }
    finally {
      fclose($handle);
    }

    return ['processed' => $processed, 'offset' => $newOffset];
  }

  /**
   * Processes a chunk of stop_times CSV rows and inserts them directly.
   *
   * Bypasses MigrateExecutable so the caller can control exactly how many rows
   * are processed per HTTP request. Entity IDs are resolved per chunk from
   * the database using only the GTFS IDs present in that chunk.
   *
   * The migrate_map_localgov_bus_data_stop_times table is NOT populated — this
   * is intentional. Nothing in the module uses migration_lookup against
   * stop_times; both import paths use this method instead of MigrateExecutable.
   *
   * @param string $csvFile
   *   Absolute path to stop_times.txt.
   * @param int $byteOffset
   *   Byte position to seek to before reading (skip the header on first call).
   * @param array<string, int> $headerCols
   *   Map of column name → zero-based index, derived from the CSV header.
   * @param int $limit
   *   Maximum rows to process in this call.
   *
   * @return array{processed: int, offset: int}
   *   processed — rows actually inserted (orphaned rows excluded).
   *   offset — byte position after the last row read (next byteOffset).
   *
   * @throws \RuntimeException
   */
  public function processStopTimesChunk(
    string $csvFile,
    int $byteOffset,
    array $headerCols,
    int $limit,
  ): array {
    $tripIdx = $headerCols['trip_id'] ?? 0;
    $arrIdx  = $headerCols['arrival_time'] ?? 1;
    $depIdx  = $headerCols['departure_time'] ?? 2;
    $stopIdx = $headerCols['stop_id'] ?? 3;
    $seqIdx  = $headerCols['stop_sequence'] ?? 4;

    $handle = @fopen($csvFile, 'r');
    if ($handle === FALSE) {
      throw new \RuntimeException("Cannot open stop_times file: {$csvFile}");
    }

    $rawRows   = [];
    $processed = 0;
    $newOffset = $byteOffset;

    try {
      fseek($handle, $byteOffset);

      for ($i = 0; $i < $limit; $i++) {
        $row = fgetcsv($handle, escape: '');
        if ($row === FALSE) {
          break;
        }
        if (count($row) < 5) {
          continue;
        }

        $rawRows[] = [
          'trip_gtfs_id'            => (string) ($row[$tripIdx] ?? ''),
          'stop_gtfs_id'            => (string) ($row[$stopIdx] ?? ''),
          'bustimes_arrival_time'   => substr((string) ($row[$arrIdx] ?? ''), 0, 8),
          'bustimes_departure_time' => substr((string) ($row[$depIdx] ?? ''), 0, 8),
          'bustimes_stop_sequence'  => (int) ($row[$seqIdx] ?? 0),
        ];
      }

      $newOffset = (int) ftell($handle);
    }
    finally {
      fclose($handle);
    }

    $tripIds = [];
    $stopIds = [];
    foreach ($rawRows as $row) {
      if ($row['trip_gtfs_id'] !== '') {
        $tripIds[$row['trip_gtfs_id']] = TRUE;
      }
      if ($row['stop_gtfs_id'] !== '') {
        $stopIds[$row['stop_gtfs_id']] = TRUE;
      }
    }

    $tripMap = $this->resolveIdMapForValues(
      'localgov_bus_trip',
      'bustimes_trip_id',
      array_keys($tripIds),
    );
    $stopMap = $this->resolveIdMapForValues(
      'localgov_bus_stop',
      'bustimes_stop_id',
      array_keys($stopIds),
    );

    $rows = [];
    foreach ($rawRows as $row) {
      $tripEntityId = $tripMap[$row['trip_gtfs_id']] ?? NULL;
      $stopEntityId = $stopMap[$row['stop_gtfs_id']] ?? NULL;
      if ($tripEntityId === NULL || $stopEntityId === NULL) {
        continue;
      }

      $rows[] = [
        'uuid'                    => $this->uuid->generate(),
        'bustimes_trip_id'        => (int) $tripEntityId,
        'bustimes_stop_id'        => (int) $stopEntityId,
        'bustimes_arrival_time'   => $row['bustimes_arrival_time'],
        'bustimes_departure_time' => $row['bustimes_departure_time'],
        'bustimes_stop_sequence'  => $row['bustimes_stop_sequence'],
      ];
    }

    $processed = count($rows);

    // Batch inserts — 500 rows per statement to stay within max_allowed_packet.
    foreach (array_chunk($rows, 500) as $chunk) {
      $query = $this->database->insert('localgov_bus_stop_time')
        ->fields([
          'uuid',
          'bustimes_trip_id',
          'bustimes_stop_id',
          'bustimes_arrival_time',
          'bustimes_departure_time',
          'bustimes_stop_sequence',
        ]);
      foreach ($chunk as $insertRow) {
        $query->values($insertRow);
      }
      $query->execute();
    }

    return ['processed' => $processed, 'offset' => $newOffset];
  }

  /**
   * Processes a chunk of shapes CSV rows and inserts them directly.
   *
   * Follows the same chunked direct-insert pattern as processStopTimesChunk():
   * bypasses MigrateExecutable so the caller controls how many rows run per
   * HTTP request. Shape points are standalone geometry (no entity references),
   * so no per-chunk ID resolution is needed. Rows with an empty shape_id or a
   * non-numeric coordinate are skipped.
   *
   * @param string $csvFile
   *   Absolute path to shapes.txt.
   * @param int $byteOffset
   *   Byte position to seek to before reading (skip the header on first call).
   * @param array<string, int> $headerCols
   *   Map of column name → zero-based index, derived from the CSV header.
   * @param int $limit
   *   Maximum rows to process in this call.
   *
   * @return array{processed: int, offset: int}
   *   processed: rows actually inserted.
   *   offset: byte position after the last row read (next byteOffset).
   *
   * @throws \RuntimeException
   */
  public function processShapesChunk(
    string $csvFile,
    int $byteOffset,
    array $headerCols,
    int $limit,
  ): array {
    $shapeIdx = $headerCols['shape_id'] ?? 0;
    $latIdx   = $headerCols['shape_pt_lat'] ?? 1;
    $lonIdx   = $headerCols['shape_pt_lon'] ?? 2;
    $seqIdx   = $headerCols['shape_pt_sequence'] ?? 3;

    $handle = @fopen($csvFile, 'r');
    if ($handle === FALSE) {
      throw new \RuntimeException("Cannot open shapes file: {$csvFile}");
    }

    $rows      = [];
    $newOffset = $byteOffset;

    try {
      fseek($handle, $byteOffset);

      for ($i = 0; $i < $limit; $i++) {
        $row = fgetcsv($handle, escape: '');
        if ($row === FALSE) {
          break;
        }
        if (count($row) < 4) {
          continue;
        }

        $shapeId = trim((string) ($row[$shapeIdx] ?? ''));
        if ($shapeId === '') {
          continue;
        }

        $lat = trim((string) ($row[$latIdx] ?? ''));
        $lon = trim((string) ($row[$lonIdx] ?? ''));
        if (!is_numeric($lat) || !is_numeric($lon)) {
          continue;
        }

        $rows[] = [
          'shape_id'          => substr($shapeId, 0, 255),
          'shape_pt_lat'      => (float) $lat,
          'shape_pt_lon'      => (float) $lon,
          'shape_pt_sequence' => (int) ($row[$seqIdx] ?? 0),
        ];
      }

      $newOffset = (int) ftell($handle);
    }
    finally {
      fclose($handle);
    }

    // Batch inserts: 500 rows per statement to stay within max_allowed_packet.
    foreach (array_chunk($rows, 500) as $chunk) {
      $query = $this->database->insert('localgov_bus_shape')
        ->fields(['shape_id', 'shape_pt_lat', 'shape_pt_lon', 'shape_pt_sequence']);
      foreach ($chunk as $insertRow) {
        $query->values($insertRow);
      }
      $query->execute();
    }

    return ['processed' => count($rows), 'offset' => $newOffset];
  }

  /**
   * Imports the full staged shapes.txt via chunked direct inserts.
   *
   * Shared by the CLI (run()) and incremental paths. Truncates
   * localgov_bus_shape first so re-runs do not accumulate duplicate points.
   * A missing shapes.txt (feed without shapes) is treated as zero rows.
   *
   * @return int
   *   Number of shape point rows inserted.
   *
   * @throws \RuntimeException
   */
  private function importShapes(): int {
    $this->database->truncate('localgov_bus_shape')->execute();

    $csvPath = $this->getStagingDirPath() . '/shapes.txt';
    if (!file_exists($csvPath)) {
      $this->logger->notice('No shapes.txt staged; skipping shape geometry import.');
      return 0;
    }

    $handle = fopen($csvPath, 'r');
    if ($handle === FALSE) {
      throw new \RuntimeException("Cannot open shapes file: {$csvPath}");
    }
    $header = fgetcsv($handle, escape: '');
    if (!is_array($header) || $header === [NULL]) {
      fclose($handle);
      throw new \RuntimeException("shapes.txt has no readable header row: {$csvPath}");
    }
    $headerCols = array_flip($header);
    $byteOffset = ftell($handle);
    fclose($handle);
    if ($byteOffset === FALSE) {
      throw new \RuntimeException("ftell failed on shapes file: {$csvPath}");
    }

    $total = 0;
    do {
      $result     = $this->processShapesChunk($csvPath, $byteOffset, $headerCols, 10000);
      $byteOffset = $result['offset'];
      $total     += $result['processed'];
    } while ($result['processed'] !== 0);

    $this->logger->notice('Imported @count shape points.', ['@count' => $total]);

    return $total;
  }

  /**
   * Resolves GTFS IDs to entity IDs using bounded IN() lookups.
   *
   * @param string $table
   *   Entity base table name.
   * @param string $sourceIdColumn
   *   Column containing the GTFS identifier string.
   * @param array<int, string> $sourceIds
   *   GTFS IDs to resolve.
   *
   * @return array<string, string>
   *   Map of source GTFS ID to destination entity ID (as DB string).
   */
  private function resolveIdMapForValues(
    string $table,
    string $sourceIdColumn,
    array $sourceIds,
  ): array {
    if ($sourceIds === []) {
      return [];
    }

    $map = [];

    foreach (array_chunk($sourceIds, 1000) as $chunk) {
      $result = $this->database
        ->select($table, 't')
        ->fields('t', [$sourceIdColumn, 'id'])
        ->condition($sourceIdColumn, $chunk, 'IN')
        ->execute();

      while ($row = $result->fetchAssoc()) {
        $map[(string) ($row[$sourceIdColumn] ?? '')] = (string) ($row['id'] ?? '');
      }
    }

    return $map;
  }

  /**
   * Processes a chunk of trips CSV rows and inserts them directly.
   *
   * Bypasses MigrateExecutable so the web-batch path can stay within
   * Pantheon's 59-second Varnish timeout. Route and calendar IDs are
   * resolved via in-memory maps built from the respective migrate map
   * tables.
   *
   * Rows whose route_id or service_id has no matching entity (orphaned due to
   * geographic filtering) are silently skipped.
   *
   * @param string $csvFile
   *   Absolute path to trips.txt.
   * @param int $byteOffset
   *   Byte position to seek to before reading (skip already-processed rows).
   * @param array<string, int> $headerCols
   *   Map of column name to zero-based column index (from array_flip of
   *   header).
   * @param array<string, string> $routeMap
   *   GTFS route_id string → Drupal entity ID (as string from DB).
   * @param array<string, string> $calendarMap
   *   GTFS service_id string → Drupal entity ID (as string from DB).
   * @param int $limit
   *   Maximum number of CSV rows to read per call.
   *
   * @return array{processed: int, offset: int}
   *   processed — rows actually inserted.
   *   offset — byte position after the last row read (next byteOffset).
   *
   * @throws \RuntimeException
   */
  public function processTripChunk(
    string $csvFile,
    int $byteOffset,
    array $headerCols,
    array $routeMap,
    array $calendarMap,
    int $limit,
  ): array {
    $tripIdx      = $headerCols['trip_id'] ?? 0;
    $routeIdx     = $headerCols['route_id'] ?? 1;
    $serviceIdx   = $headerCols['service_id'] ?? 2;
    $directionIdx = $headerCols['direction_id'] ?? NULL;
    $headsignIdx  = $headerCols['trip_headsign'] ?? NULL;
    $shapeIdx     = $headerCols['shape_id'] ?? NULL;

    $handle = @fopen($csvFile, 'r');
    if ($handle === FALSE) {
      throw new \RuntimeException("Cannot open trips file: {$csvFile}");
    }

    $rows      = [];
    $processed = 0;
    $newOffset = $byteOffset;

    try {
      fseek($handle, $byteOffset);

      for ($i = 0; $i < $limit; $i++) {
        $row = fgetcsv($handle, escape: '');
        if ($row === FALSE) {
          break;
        }
        if (count($row) < 3) {
          continue;
        }

        $gtfsTripId    = trim((string) ($row[$tripIdx] ?? ''));
        $gtfsRouteId   = trim((string) ($row[$routeIdx] ?? ''));
        $gtfsServiceId = trim((string) ($row[$serviceIdx] ?? ''));

        $routeEntityId    = $routeMap[$gtfsRouteId] ?? NULL;
        $calendarEntityId = $calendarMap[$gtfsServiceId] ?? NULL;

        if ($routeEntityId === NULL || $calendarEntityId === NULL) {
          continue;
        }

        $directionId = ($directionIdx !== NULL && isset($row[$directionIdx]))
          ? (int) $row[$directionIdx]
          : 0;
        $headsign = ($headsignIdx !== NULL && isset($row[$headsignIdx]))
          ? substr(trim((string) $row[$headsignIdx]), 0, 255)
          : '';
        $shapeId = ($shapeIdx !== NULL && isset($row[$shapeIdx]))
          ? substr(trim((string) $row[$shapeIdx]), 0, 255)
          : '';

        $rows[] = [
          'uuid'                   => $this->uuid->generate(),
          'bustimes_trip_id'       => $gtfsTripId,
          'bustimes_route_id'      => (int) $routeEntityId,
          'bustimes_service_id'    => (int) $calendarEntityId,
          'bustimes_direction_id'  => $directionId,
          'bustimes_trip_headsign' => $headsign !== '' ? $headsign : NULL,
          'bustimes_shape_id'      => $shapeId !== '' ? $shapeId : NULL,
        ];

        $processed++;
      }

      $newOffset = (int) ftell($handle);
    }
    finally {
      fclose($handle);
    }

    foreach (array_chunk($rows, 500) as $chunk) {
      $query = $this->database->insert('localgov_bus_trip')
        ->fields([
          'uuid',
          'bustimes_trip_id',
          'bustimes_route_id',
          'bustimes_service_id',
          'bustimes_direction_id',
          'bustimes_trip_headsign',
          'bustimes_shape_id',
        ]);
      foreach ($chunk as $insertRow) {
        $query->values($insertRow);
      }
      $query->execute();
    }

    return ['processed' => $processed, 'offset' => $newOffset];
  }

  /**
   * Populates bustimes_weekday on each BusCalendar.
   *
   * Sets bustimes_weekday = 1 if the service runs on any weekday (Mon–Fri).
   * Public so the seed command can call it after inserting fixture data.
   */
  public function populateCalendarWeekdays(): void {
    $count = $this->database->update('localgov_bus_calendar')
      ->expression(
        'bustimes_weekday',
        'bustimes_monday | bustimes_tuesday | bustimes_wednesday | bustimes_thursday | bustimes_friday',
      )
      ->execute();

    // Fallback for services defined only via calendar_dates.txt: their
    // calendar.txt row has all-zero day flags so the bitwise update above
    // leaves bustimes_weekday = 0. Mark them as weekday services so they
    // appear on the timetable rather than being invisible on every tab.
    // A "specific dates" UI note is added via hook_views_post_render().
    $fallback = $this->database->update('localgov_bus_calendar')
      ->fields(['bustimes_weekday' => 1])
      ->condition('bustimes_monday', 0)
      ->condition('bustimes_tuesday', 0)
      ->condition('bustimes_wednesday', 0)
      ->condition('bustimes_thursday', 0)
      ->condition('bustimes_friday', 0)
      ->condition('bustimes_saturday', 0)
      ->condition('bustimes_sunday', 0)
      ->execute();

    $this->logger->notice(
      'Populated bustimes_weekday for @count calendars (@fallback specific-dates fallbacks).',
      ['@count' => $count, '@fallback' => $fallback],
    );
  }

  /**
   * Populates bustimes_headsign and bustimes_headsign_inbound on each BusRoute.
   *
   * Uses the alphabetically-first trip headsign for direction_id=0 (outbound)
   * and direction_id=1 (inbound) respectively.
   *
   * Public so the seed command can call it after inserting fixture data.
   */
  public function populateRouteHeadsigns(): void {
    foreach ([0 => 'bustimes_headsign', 1 => 'bustimes_headsign_inbound'] as $direction => $column) {
      $stmt = $this->database->prepareStatement(
        "UPDATE {localgov_bus_route} r
         INNER JOIN (
           SELECT bustimes_route_id, MIN(bustimes_trip_headsign) AS headsign
           FROM {localgov_bus_trip}
           WHERE bustimes_direction_id = :direction
           GROUP BY bustimes_route_id
         ) sub ON r.id = sub.bustimes_route_id
         SET r.{$column} = sub.headsign",
        [],
        TRUE,
      );
      $stmt->execute([':direction' => $direction]);

      $this->logger->notice('Populated @column for @count routes.', [
        '@column' => $column,
        '@count'  => $stmt->rowCount(),
      ]);
    }
  }

  /**
   * Populates bustimes_agency_name on each BusRoute from staged agency.txt.
   *
   * Resolves the GTFS agency_id to its operator name at import time so display
   * paths can read the stored name instead of re-parsing agency.txt on render.
   * Routes whose agency_id has no matching name are left untouched.
   *
   * Public so the seed command can call it after inserting fixture data.
   */
  public function populateRouteOperatorNames(): void {
    $names = $this->agencyNameResolver->getAgencyNames();
    if ($names === []) {
      $this->logger->notice('No agency names found in staged agency.txt; skipping operator-name population.');
      return;
    }

    $updated = 0;
    foreach ($names as $agencyId => $agencyName) {
      $updated += $this->database->update('localgov_bus_route')
        ->fields(['bustimes_agency_name' => $agencyName])
        ->condition('bustimes_agency_id', $agencyId)
        ->execute();
    }

    $this->logger->notice('Populated operator name for @count routes.', ['@count' => $updated]);
  }

  /**
   * Populates bustimes_services on each BusStop with route short names.
   *
   * Public so the seed command can call it after inserting fixture data.
   *
   * @note Requires MySQL/MariaDB — uses GROUP_CONCAT with ORDER BY, which is
   *   not available in SQLite or PostgreSQL. Given the dataset scale (150k+
   *   stop-time rows) MySQL is a hard requirement for this module.
   */
  public function populateStopServices(): void {
    $stmt = $this->database->prepareStatement(
      "UPDATE {localgov_bus_stop} s
       INNER JOIN (
         SELECT st.bustimes_stop_id AS stop_entity_id,
                GROUP_CONCAT(DISTINCT r.bustimes_route_short_name
                             ORDER BY r.bustimes_route_short_name
                             SEPARATOR ', ') AS services
         FROM {localgov_bus_stop_time} st
         INNER JOIN {localgov_bus_trip} t ON t.id = st.bustimes_trip_id
         INNER JOIN {localgov_bus_route} r ON r.id = t.bustimes_route_id
         GROUP BY st.bustimes_stop_id
       ) sub ON s.id = sub.stop_entity_id
       SET s.bustimes_services = sub.services",
      [],
      TRUE,
    );
    $stmt->execute([]);

    $count = $stmt->rowCount();
    $this->logger->notice('Populated services for @count stops.', ['@count' => $count]);
  }

  /**
   * Prepares the fixed staging directory, clearing any previous staging files.
   *
   * @throws \RuntimeException
   */
  public function prepareStagingDirectory(): string {
    $stagingUri = 'public://bus-times/gtfs';

    $this->fileSystem->prepareDirectory(
      $stagingUri,
      FileSystemInterface::CREATE_DIRECTORY | FileSystemInterface::MODIFY_PERMISSIONS
    );

    $path = $this->fileSystem->realpath($stagingUri);
    if ($path === FALSE) {
      throw new \RuntimeException('Could not create GTFS staging directory: ' . $stagingUri);
    }

    foreach (self::GTFS_FILES as $file) {
      $stagingFile = $path . '/' . $file;
      if (file_exists($stagingFile)) {
        unlink($stagingFile);
      }
    }

    return $path;
  }

  /**
   * Clears all bus-data entity tables and migrate tracking tables in bulk.
   *
   * @throws \RuntimeException
   */
  public function bulkTruncate(): void {
    $schema = $this->database->schema();

    foreach (array_reverse(self::MIGRATION_IDS) as $id) {
      $entityTable = self::MIGRATION_TABLES[$id];
      $mapTable    = 'migrate_map_' . $id;
      $msgTable    = 'migrate_message_' . $id;

      $this->database->truncate($entityTable)->execute();

      if ($schema->tableExists($mapTable)) {
        $this->database->truncate($mapTable)->execute();
      }
      if ($schema->tableExists($msgTable)) {
        $this->database->truncate($msgTable)->execute();
      }

      $this->logger->notice('Truncated @entity, @map, @msg.', [
        '@entity' => $entityTable,
        '@map'    => $mapTable,
        '@msg'    => $msgTable,
      ]);
    }

    // Shape geometry is a plain table outside the migrate pipeline; clear
    // it alongside the entity tables so a full re-import starts clean.
    if ($schema->tableExists('localgov_bus_shape')) {
      $this->database->truncate('localgov_bus_shape')->execute();
      $this->logger->notice('Truncated localgov_bus_shape.');
    }

    Cache::invalidateTags([
      'localgov_bus_route_list',
      'localgov_bus_stop_list',
      'localgov_bus_calendar_list',
      'localgov_bus_trip_list',
      'localgov_bus_stop_time_list',
    ]);
  }

  /**
   * Writes a record to the import log table.
   *
   * @param string $status
   *   Either 'success' or 'error'.
   * @param array<string, int> $rowCounts
   *   Map of migration ID to row count.
   * @param int $durationMs
   *   Elapsed wall-clock milliseconds.
   * @param string $message
   *   Summary or error message.
   */
  public function writeImportLog(string $status, array $rowCounts, int $durationMs, string $message): void {
    try {
      $this->database->insert('localgov_bus_data_import_log')
        ->fields([
          'timestamp'     => time(),
          'status'        => $status,
          'rows_imported' => json_encode($rowCounts),
          'duration_ms'   => $durationMs,
          'message'       => $this->truncateLogMessage($message),
        ])
        ->execute();
    }
    catch (\Exception $e) {
      $this->logger->error('Could not write import log entry: @msg', ['@msg' => $e->getMessage()]);
    }
  }

  /**
   * Caps a log message to fit the import log TEXT column.
   *
   * A failing bulk INSERT surfaces as an exception whose message embeds the
   * full SQL and every bound parameter, which can exceed the 64 KB TEXT limit.
   * Without capping, writing that message would itself fail and mask the real
   * error. The head of the message carries the useful detail, so keep the first
   * 16000 characters (safe under 65535 bytes even for 4-byte UTF-8) and mark
   * any truncation. The original message is still logged in full via the
   * watchdog logger by the caller's error handling.
   *
   * @param string $message
   *   The raw message.
   *
   * @return string
   *   The message, truncated if necessary.
   */
  private function truncateLogMessage(string $message): string {
    $limit = 16000;
    if (mb_strlen($message) <= $limit) {
      return $message;
    }
    return mb_substr($message, 0, $limit) . ' [truncated]';
  }

  /**
   * Runs all five migrations incrementally (add/update/delete).
   *
   * Routes, stops, calendars, and trips run via MigrateExecutable with
   * track_changes: true; their migrate map tables are preserved for change
   * detection and orphan removal. Stop-times are truncated and reimported via
   * chunked direct inserts (the same path as the full import) to avoid the
   * Pantheon connection-timeout that MigrateExecutable causes on 300k+ rows.
   * Any stuck "Importing" migration status is reset before the stop-times step
   * so a prior failed run does not block subsequent imports.
   *
   * @return array<string, int>
   *   Row counts keyed by migration ID.
   *
   * @throws \RuntimeException
   */
  public function runIncrementalMigrations(): array {
    // Routes, stops, calendars, and trips run via MigrateExecutable: they are
    // small enough to stay within Pantheon's connection timeout.
    $rowCounts = $this->runCoreMigrations();

    // Stop-times: MigrateExecutable scans all 300k+ rows even when few have
    // changed, reliably timing out on Pantheon. Instead we reset any stuck
    // migration status, truncate the entity and map tables, then reinsert via
    // the same chunked direct-insert path used by the full import. Orphan
    // detection is implicit: rows absent from the fresh GTFS snapshot are
    // simply not reinserted.
    $id        = 'localgov_bus_data_stop_times';
    $migration = $this->migrationPluginManager->createInstance($id);
    // Reset any stuck "Importing" status left by a prior timed-out run.
    // Safe because this method is always invoked from a single CLI process;
    // concurrent import runs are not supported and would corrupt the data
    // regardless of locking strategy.
    $migration->setStatus(MigrationInterface::STATUS_IDLE);

    $schema = $this->database->schema();
    $this->database->truncate('localgov_bus_stop_time')->execute();
    foreach (['migrate_map_' . $id, 'migrate_message_' . $id] as $auxTable) {
      if ($schema->tableExists($auxTable)) {
        $this->database->truncate($auxTable)->execute();
      }
    }

    $csvPath = $this->getStagingDirPath() . '/stop_times.txt';
    $handle  = fopen($csvPath, 'r');
    if ($handle === FALSE) {
      throw new \RuntimeException("Cannot open stop_times file: {$csvPath}");
    }
    $header = fgetcsv($handle, escape: '');
    if (!is_array($header) || $header === [NULL]) {
      fclose($handle);
      throw new \RuntimeException("stop_times.txt has no readable header row: {$csvPath}");
    }
    $headerCols = array_flip($header);
    $byteOffset = ftell($handle);
    fclose($handle);
    if ($byteOffset === FALSE) {
      throw new \RuntimeException("ftell failed on stop_times file: {$csvPath}");
    }

    $total = 0;
    do {
      $result     = $this->processStopTimesChunk($csvPath, $byteOffset, $headerCols, 10000);
      $byteOffset = $result['offset'];
      $total     += $result['processed'];
    } while ($result['processed'] !== 0);

    $rowCounts[$id] = $total;
    $this->logger->notice('Imported @id: @count rows.', [
      '@id'    => $id,
      '@count' => $total,
    ]);

    // NOTE: migrate_map_localgov_bus_data_stop_times is truncated and never
    // repopulated by this path. Running `drush migrate:import
    // localgov_bus_data_stop_times` manually after an incremental import will
    // appear to Migrate as a fresh 0-row import and trigger a full
    // MigrateExecutable run (which times out on Pantheon). Always use
    // `drush bus-times:import` (not raw migrate commands) to re-run imports.
    // Detect and remove records deleted from the GTFS source (reverse
    // dependency order). Stop-times are handled above by truncate+reinsert,
    // so only the entity-level orphan checks are needed here.
    $this->deleteOrphanedMigrationEntities('localgov_bus_data_trips', 'trips.txt', 'trip_id');
    $this->deleteOrphanedMigrationEntities('localgov_bus_data_calendars', 'calendar.txt', 'service_id');
    $this->deleteOrphanedMigrationEntities('localgov_bus_data_routes', 'routes.txt', 'route_id');
    $this->deleteOrphanedMigrationEntities('localgov_bus_data_stops', 'stops.txt', 'stop_id');

    // Shapes: truncate and reimport wholesale (same rationale as stop-times).
    // Points absent from the fresh GTFS snapshot are simply not reinserted.
    $rowCounts['localgov_bus_shapes'] = $this->importShapes();

    $this->populateCalendarWeekdays();
    $this->populateRouteHeadsigns();
    $this->populateRouteOperatorNames();
    $this->populateStopServices();

    return $rowCounts;
  }

  /**
   * Runs all five migrations; stop_times via chunked direct inserts.
   *
   * Used by the CLI path (run()) only. The web-batch path uses individual
   * batch operations with direct DB inserts for trips and stop-times.
   *
   * @return array<string, int>
   *   Row counts keyed by migration ID.
   *
   * @throws \RuntimeException
   */
  private function runAllMigrations(): array {
    $this->logger->notice('Truncating existing bus data tables...');
    $this->bulkTruncate();
    $this->logger->notice('Truncation complete.');

    $rowCounts = $this->runCoreMigrations();

    // Stop-times via chunked direct inserts (CLI path).
    $id      = 'localgov_bus_data_stop_times';
    $csvPath = $this->getStagingDirPath() . '/stop_times.txt';

    $handle = fopen($csvPath, 'r');
    if ($handle === FALSE) {
      throw new \RuntimeException("Cannot open stop_times file: {$csvPath}");
    }
    $header = fgetcsv($handle, escape: '');
    if (!is_array($header) || $header === [NULL]) {
      fclose($handle);
      throw new \RuntimeException("stop_times.txt has no readable header row: {$csvPath}");
    }
    $headerCols = array_flip($header);
    $byteOffset = ftell($handle);
    fclose($handle);
    if ($byteOffset === FALSE) {
      throw new \RuntimeException("ftell failed on stop_times file: {$csvPath}");
    }

    $total = 0;
    do {
      $result     = $this->processStopTimesChunk($csvPath, $byteOffset, $headerCols, 10000);
      $byteOffset = $result['offset'];
      $total     += $result['processed'];
    } while ($result['processed'] !== 0);

    $rowCounts[$id] = $total;
    $this->logger->notice('Imported @id: @count rows.', [
      '@id'    => $id,
      '@count' => $total,
    ]);

    $rowCounts['localgov_bus_shapes'] = $this->importShapes();

    $this->populateCalendarWeekdays();
    $this->populateRouteHeadsigns();
    $this->populateRouteOperatorNames();
    $this->populateStopServices();

    return $rowCounts;
  }

  /**
   * Revalidates and merges the stored custom data set into staging.
   *
   * Returns silently (empty string) when custom data is disabled or
   * nothing is stored. Otherwise re-runs full validation against the
   * freshly staged data: a set that reconciled last week may not
   * reconcile today, since the feed changes between imports. If validation
   * passes, merges the custom rows and returns a success note. If it
   * fails, skips the merge and returns a skip note: custom data must never
   * fail the import, since cron imports run unattended and the real
   * timetable must still publish.
   *
   * Nothing in CustomCsvManager's call chain currently throws; this method's
   * only confirmed throw site is getCleanStagingDirPath(), which can throw
   * \RuntimeException if the snapshot directory cannot be resolved. Callers
   * still wrap this whole method in a broad try/catch as a defensive net
   * (see run() and batchMergeCustomData()'s caller), because "must never
   * fail the import" has to hold even against that and any future
   * exception or error type this method cannot anticipate today.
   *
   * @param string $stagingDir
   *   Absolute path to the GTFS staging directory, already rebuilt for this
   *   import.
   *
   * @return string
   *   Empty string, or a note to append to the import log message.
   */
  private function mergeCustomData(string $stagingDir): string {
    if (!$this->customCsvManager->isEnabled() || !$this->customCsvManager->hasStoredFiles()) {
      return '';
    }

    // Validate against the clean snapshot, not the live staging directory:
    // by this point in a fresh import the two happen to be identical, but
    // using the snapshot keeps this validation call identical in shape to
    // the form's "Validate now" and replace/remove revalidation, which
    // must use the snapshot (see getCleanStagingDirPath()). Deliberately
    // does not need getValidationStagingDirPath()'s empty-snapshot
    // fallback either: hasStoredFiles() above already implies a prior
    // successful upload, which itself required staged data to exist, so
    // the snapshot can never be empty by the time this call runs.
    $report = $this->customCsvManager->validateStoredFiles($this->getCleanStagingDirPath());
    if (!$report->isValid()) {
      $this->logger->warning('Custom data skipped: validation failed against the freshly staged data. See the custom data page for the report.');
      return 'Custom data skipped: validation failed, see the custom data page.';
    }

    $counts = $this->customCsvManager->mergeIntoStaging($stagingDir);
    $total = array_sum($counts);
    $this->logger->notice('Custom data merged: @count rows.', ['@count' => $total]);
    return sprintf('Custom data: %d rows merged.', $total);
  }

  /**
   * Copies filtered GTFS files from the extracted directory into staging.
   */
  private function mergeGtfsFiles(string $sourceDir, string $stagingDir): void {
    foreach (self::GTFS_FILES as $filename) {
      $sourceFile  = $sourceDir . '/' . $filename;
      $stagingFile = $stagingDir . '/' . $filename;

      if (!file_exists($sourceFile)) {
        continue;
      }

      $isFirstDataset = !file_exists($stagingFile) || filesize($stagingFile) === 0;

      $in  = fopen($sourceFile, 'r');
      $out = fopen($stagingFile, 'a');

      if ($in === FALSE || $out === FALSE) {
        if ($in !== FALSE) {
          fclose($in);
        }
        if ($out !== FALSE) {
          fclose($out);
        }
        $this->logger->error('Could not open files for merging @filename.', ['@filename' => $filename]);
        continue;
      }

      $header = fgetcsv($in, escape: '');
      if (!is_array($header)) {
        fclose($in);
        fclose($out);
        continue;
      }

      if ($isFirstDataset) {
        fputcsv($out, $header, escape: '');
      }

      while (($row = fgetcsv($in, escape: '')) !== FALSE) {
        fputcsv($out, $row, escape: '');
      }

      fclose($in);
      fclose($out);
    }
  }

  /**
   * Deletes entities for a single-source-key migration whose source has gone.
   *
   * Reads the staged CSV, finds migrate map entries whose source ID is no
   * longer present, and removes the corresponding entities and map rows. Uses
   * targeted SQL deletes (consistent with bulkTruncate()) and invalidates the
   * entity list cache tag so Views caches are cleared.
   *
   * @param string $migrationId
   *   The migration plugin ID, e.g. 'localgov_bus_data_routes'.
   * @param string $csvFilename
   *   The staged GTFS filename, e.g. 'routes.txt'.
   * @param string $sourceColumn
   *   The CSV column that serves as the source ID, e.g. 'route_id'.
   */
  private function deleteOrphanedMigrationEntities(
    string $migrationId,
    string $csvFilename,
    string $sourceColumn,
  ): void {
    $mapTable = 'migrate_map_' . $migrationId;
    if (!$this->database->schema()->tableExists($mapTable)) {
      return;
    }

    $entityTable = self::MIGRATION_TABLES[$migrationId] ?? NULL;
    if ($entityTable === NULL) {
      return;
    }

    $filePath = $this->getStagingDirPath() . '/' . $csvFilename;
    if (!file_exists($filePath)) {
      $this->logger->warning(
        'Incremental delete skipped for @id: @file not found.',
        ['@id' => $migrationId, '@file' => $filePath],
      );
      return;
    }

    $sourceIds = $this->readCsvColumn($filePath, $sourceColumn);
    if (empty($sourceIds)) {
      $this->logger->warning(
        'Incremental delete skipped for @id: source file contains no IDs.',
        ['@id' => $migrationId],
      );
      return;
    }

    // @phpstan-ignore-next-line — fetchAllKeyed() types vary per DB driver.
    $orphans = $this->database->select($mapTable, 'm')
      ->fields('m', ['sourceid1', 'destid1'])
      ->condition('sourceid1', $sourceIds, 'NOT IN')
      ->execute()
      ->fetchAllKeyed();

    if (empty($orphans)) {
      $this->logger->notice(
        'No orphaned entities to delete for migration @id.',
        ['@id' => $migrationId],
      );
      return;
    }

    $destIds = array_values($orphans);

    foreach (array_chunk($destIds, 500) as $chunk) {
      $this->database->delete($entityTable)
        ->condition('id', $chunk, 'IN')
        ->execute();
    }

    foreach (array_chunk($destIds, 500) as $chunk) {
      $this->database->delete($mapTable)
        ->condition('destid1', $chunk, 'IN')
        ->execute();
    }

    Cache::invalidateTags([$entityTable . '_list']);

    $this->logger->notice(
      'Deleted @count orphaned @entity entities (migration @id).',
      [
        '@count'  => count($destIds),
        '@entity' => $entityTable,
        '@id'     => $migrationId,
      ],
    );
  }

  /**
   * Reads all unique values of one named column from a CSV file.
   *
   * @param string $filePath
   *   Absolute path to the CSV file.
   * @param string $columnName
   *   Header column name to extract.
   *
   * @return array<int, string>
   *   Unique non-empty values found in the named column.
   */
  private function readCsvColumn(string $filePath, string $columnName): array {
    $handle = @fopen($filePath, 'r');
    if ($handle === FALSE) {
      return [];
    }

    $header = fgetcsv($handle, escape: '');
    if (!is_array($header)) {
      fclose($handle);
      return [];
    }

    $colIndex = array_search($columnName, $header, TRUE);
    if ($colIndex === FALSE) {
      fclose($handle);
      return [];
    }

    // Use a keyed array so deduplication is O(1) per row rather than a
    // second pass with array_unique().
    $ids = [];
    while (($row = fgetcsv($handle, escape: '')) !== FALSE) {
      if (isset($row[$colIndex]) && $row[$colIndex] !== '') {
        $ids[$row[$colIndex]] = TRUE;
      }
    }

    fclose($handle);
    return array_keys($ids);
  }

  /**
   * Recursively removes a temporary directory and all its contents.
   */
  private function deleteTempDir(string $dir): void {
    if (!is_dir($dir)) {
      return;
    }
    $files = new \RecursiveIteratorIterator(
      new \RecursiveDirectoryIterator($dir, \FilesystemIterator::SKIP_DOTS),
      \RecursiveIteratorIterator::CHILD_FIRST
    );
    foreach ($files as $file) {
      if ($file->isDir()) {
        rmdir($file->getPathname());
      }
      else {
        unlink($file->getPathname());
      }
    }
    rmdir($dir);
  }

}
