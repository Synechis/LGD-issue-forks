<?php

declare(strict_types=1);

namespace Drupal\localgov_bus_data\Service;

use Drupal\Component\Datetime\TimeInterface;
use Drupal\Core\Database\Connection;
use Psr\Log\LoggerInterface;

/**
 * Keeps the database connection alive during long file-only work.
 *
 * The CLI and cron import path (GtfsImportService::run()) is a single PHP
 * process that opens the database connection early, then spends up to twenty
 * minutes downloading, extracting, and filtering GTFS files without issuing a
 * single query. Hosts that kill idle connections between PHP and MySQL drop
 * the connection in that window, and the first query afterwards (the TRUNCATE
 * in bulkTruncate()) fails with "MySQL server has gone away" (2006).
 * Drupal does not reconnect automatically.
 *
 * Callers invoke ping() liberally from inside their row and byte loops. The
 * interval throttle keeps the real cost to one "SELECT 1" per interval no
 * matter how often it is called, so the caller does not need its own counter
 * beyond a coarse one.
 *
 * ping() never throws: it runs inside import loops whose own failure handling
 * needs the connection, so a failure here must not mask the real error. The
 * Guzzle download progress callback is one of those loops, and an exception
 * escaping it would abort a 700 MB download.
 */
final class DatabaseKeepalive {

  /**
   * Unix timestamp of the last ping attempt, or NULL if never pinged.
   */
  private ?int $lastPing = NULL;

  /**
   * Result of the last real query, reported again while throttled.
   */
  private bool $lastResult = TRUE;

  /**
   * Constructs the keepalive service.
   *
   * @param \Drupal\Core\Database\Connection $database
   *   The database connection to keep alive.
   * @param \Psr\Log\LoggerInterface $logger
   *   Logger channel. May itself be backed by the dead connection, so every
   *   call to it is guarded.
   * @param \Drupal\Component\Datetime\TimeInterface $time
   *   Time service. Injected rather than calling time() directly so the
   *   throttle is testable.
   * @param int $intervalSeconds
   *   Minimum seconds between two real queries.
   */
  public function __construct(
    private readonly Connection $database,
    private readonly LoggerInterface $logger,
    private readonly TimeInterface $time,
    private readonly int $intervalSeconds = 30,
  ) {}

  /**
   * Issues "SELECT 1" if the connection has been idle for the interval.
   *
   * Calls made within $intervalSeconds of the previous attempt are no-ops and
   * report success without touching the database.
   *
   * @return bool
   *   TRUE if the connection is believed alive. FALSE if the last real query
   *   failed. A throttled call repeats the last real result rather than
   *   claiming success it has not verified.
   */
  public function ping(): bool {
    $now = $this->time->getCurrentTime();

    if ($this->lastPing !== NULL && ($now - $this->lastPing) < $this->intervalSeconds) {
      return $this->lastResult;
    }

    // Record the attempt before running it. A dropped connection does not come
    // back on its own, so a failed ping must still throttle: otherwise every
    // subsequent call in the row loop would retry and flood the log.
    $this->lastPing = $now;

    try {
      $this->database->query('SELECT 1')->fetchField();
      return $this->lastResult = TRUE;
    }
    catch (\Throwable $e) {
      // A reaped connection surfaces as a DatabaseException, which extends
      // \Throwable, so one arm covers it along with any driver-level failure
      // the abstraction layer did not wrap.
      $this->reportFailure($e);
      return $this->lastResult = FALSE;
    }
  }

  /**
   * Reports a failed ping to error_log() and, if possible, the logger.
   *
   * Error_log() comes first and is unconditional: the logger backend is
   * usually dblog, which writes through the very connection that has just
   * been shown to be dead. Under Drush, error_log() surfaces on stderr.
   *
   * @param \Throwable $e
   *   The failure.
   */
  private function reportFailure(\Throwable $e): void {
    error_log('localgov_bus_data: DatabaseKeepalive ping failed: ' . $e->getMessage());

    try {
      $this->logger->warning('Database keepalive ping failed: @msg', ['@msg' => $e->getMessage()]);
    }
    catch (\Throwable $loggerFailure) {
      error_log(
        'localgov_bus_data: DatabaseKeepalive could not log the ping failure: '
        . $loggerFailure->getMessage()
      );
    }
  }

}
