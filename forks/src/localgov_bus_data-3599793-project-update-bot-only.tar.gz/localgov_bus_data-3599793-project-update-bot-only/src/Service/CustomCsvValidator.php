<?php

declare(strict_types=1);

namespace Drupal\localgov_bus_data\Service;

/**
 * Validates a proposed set of custom GTFS-format CSV rows.
 *
 * Pure validation logic with no container dependencies: every file it reads
 * (custom uploads and staged GTFS files) is passed in as a path, so this
 * class unit-tests cleanly against temp-dir fixtures. Structural checks
 * follow the same CSV parsing rules as the rest of the import pipeline
 * (fgetcsv with escape: ''), and referential checks resolve against the
 * union of the staged data and the proposed custom set.
 *
 * Staged files are read by streaming a single column (or, for stop_times,
 * a restricted (trip_id, stop_sequence) set) at a time, never loaded whole,
 * because staged stop_times.txt can exceed 300 000 rows. Custom files are
 * parsed fully into memory: callers are responsible for size-limiting
 * custom uploads before validation ever runs (the upload form enforces this
 * via a FileSizeLimit constraint), and a previously accepted stored file
 * can never exceed that limit either, so this holds for both upload-time
 * and import-time revalidation.
 */
final class CustomCsvValidator {

  use CustomCsvHeaderTrait;

  /**
   * Per-validate() cache of streamed staged ID sets.
   *
   * Several files reference the same staged column (e.g. both
   * validateAgencyFile() and validateRoutesFile() check staged agency_id).
   * Caching avoids streaming the same staged file twice in one validate()
   * call. Keyed by "fileKey:column"; reset at the start of validate().
   *
   * @var array<string, array<string, true>>
   */
  private array $stagedIdCache = [];

  /**
   * Staged GTFS filenames, keyed by the config/form file key.
   *
   * Shared with CustomCsvManager so both classes agree on file keys and
   * filenames.
   *
   * @var array<string, string>
   */
  public const FILE_NAMES = [
    'agency'     => 'agency.txt',
    'routes'     => 'routes.txt',
    'stops'      => 'stops.txt',
    'calendar'   => 'calendar.txt',
    'trips'      => 'trips.txt',
    'stop_times' => 'stop_times.txt',
  ];

  /**
   * Required columns per file key.
   *
   * @var array<string, array<int, string>>
   */
  private const REQUIRED_COLUMNS = [
    'agency'     => ['agency_id', 'agency_name'],
    'routes'     => ['route_id', 'route_short_name', 'agency_id', 'route_type'],
    'stops'      => ['stop_id', 'stop_name', 'stop_lat', 'stop_lon'],
    'calendar'   => [
      'service_id', 'monday', 'tuesday', 'wednesday', 'thursday',
      'friday', 'saturday', 'sunday', 'start_date', 'end_date',
    ],
    'trips'      => ['trip_id', 'route_id', 'service_id'],
    'stop_times' => ['trip_id', 'arrival_time', 'departure_time', 'stop_id', 'stop_sequence'],
  ];

  /**
   * Calendar day-flag columns, validated identically.
   *
   * @var array<int, string>
   */
  private const DAY_COLUMNS = [
    'monday', 'tuesday', 'wednesday', 'thursday', 'friday', 'saturday', 'sunday',
  ];

  /**
   * Validates a proposed custom CSV set against the staged GTFS data.
   *
   * @param array<string, string> $files
   *   Absolute paths to the proposed custom files, keyed by file key
   *   (a subset or all of self::FILE_NAMES's keys). Callers assemble this
   *   from newly uploaded files plus any already-stored files being kept.
   * @param string $stagingDir
   *   Absolute path to the GTFS staging directory to validate references
   *   against.
   *
   * @return \Drupal\localgov_bus_data\Service\ValidationReport
   *   The validation result: errors (if any) and accepted row counts.
   */
  public function validate(array $files, string $stagingDir): ValidationReport {
    $this->stagedIdCache = [];
    $report = new ValidationReport();

    $parsed = [];
    foreach (self::FILE_NAMES as $key => $filename) {
      if (!isset($files[$key])) {
        continue;
      }
      $parsed[$key] = $this->parseCsvFile($files[$key], $key, $stagingDir, $report);
    }

    $customAgencyIds = isset($parsed['agency'])
      ? $this->validateAgencyFile($parsed['agency'], $stagingDir, $report)
      : [];
    $customStopIds = isset($parsed['stops'])
      ? $this->validateStopsFile($parsed['stops'], $stagingDir, $report)
      : [];
    $customServiceIds = isset($parsed['calendar'])
      ? $this->validateCalendarFile($parsed['calendar'], $stagingDir, $report)
      : [];
    $customRouteIds = isset($parsed['routes'])
      ? $this->validateRoutesFile($parsed['routes'], $stagingDir, $report, $customAgencyIds)
      : [];
    $customTripIds = isset($parsed['trips'])
      ? $this->validateTripsFile($parsed['trips'], $stagingDir, $report, $customRouteIds, $customServiceIds)
      : [];
    if (isset($parsed['stop_times'])) {
      $this->validateStopTimesFile($parsed['stop_times'], $stagingDir, $report, $customTripIds, $customStopIds);
    }

    foreach ($parsed as $key => $data) {
      if ($data !== NULL) {
        $report->setAcceptedRowCount($key, count($data['rows']));
      }
    }

    return $report;
  }

  /**
   * Parses one custom CSV file and checks its header structurally.
   *
   * Follows the same parsing rules as the rest of the pipeline: fgetcsv with
   * escape: '', UTF-8 BOM stripped from the header, header cells trimmed,
   * and blank lines (fgetcsv returning [NULL]) skipped without error. A
   * header that parses as a single semicolon-containing cell is rejected
   * immediately with a named error rather than a cascade of missing-column
   * errors. Custom columns absent from the staged file's header are also
   * flagged here, when a staged counterpart exists. When no staged
   * counterpart exists yet (nothing has been imported), that check is
   * skipped entirely, since there is nothing to compare the custom header
   * against, and any column names are accepted, subject only to the
   * required-column check below.
   *
   * @param string $path
   *   Absolute path to the custom CSV file.
   * @param string $fileKey
   *   File key (e.g. "stops"), used to label errors and resolve required
   *   columns.
   * @param string $stagingDir
   *   Absolute path to the GTFS staging directory.
   * @param \Drupal\localgov_bus_data\Service\ValidationReport $report
   *   Report to append structural errors to.
   *
   * @return array{header: array<int, string>, rows: array<int, array{line: int, data: array<int, string|null>}>}|null
   *   Parsed header and data rows, or NULL if the file could not be parsed
   *   (unreadable, no header, semicolon-delimited, or missing a required
   *   column).
   */
  private function parseCsvFile(string $path, string $fileKey, string $stagingDir, ValidationReport $report): ?array {
    if (!is_file($path)) {
      $report->addError($fileKey, 0, NULL, 'Could not open file for reading.');
      return NULL;
    }
    $handle = @fopen($path, 'r');
    if ($handle === FALSE) {
      $report->addError($fileKey, 0, NULL, 'Could not open file for reading.');
      return NULL;
    }

    $header = NULL;
    $lineNum = 0;
    $rows = [];

    while (($row = fgetcsv($handle, escape: '')) !== FALSE) {
      $lineNum++;
      if ($row === [NULL]) {
        // Blank line: tolerated, skipped without error.
        continue;
      }
      if ($header === NULL) {
        $header = $this->normaliseHeader($row);
        if (count($header) === 1 && str_contains($header[0], ';')) {
          $report->addError($fileKey, $lineNum, NULL, 'Header appears to be semicolon-delimited; expected comma-separated CSV.');
          fclose($handle);
          return NULL;
        }
        if (count($header) !== count(array_unique($header))) {
          $report->addError($fileKey, $lineNum, NULL, 'Header contains duplicate column names.');
          fclose($handle);
          return NULL;
        }
        continue;
      }
      $rows[] = ['line' => $lineNum, 'data' => $row];
    }
    fclose($handle);

    if ($header === NULL) {
      $report->addError($fileKey, 1, NULL, 'File contains no header row.');
      return NULL;
    }

    $stagedHeader = $this->readStagedHeader($stagingDir, $fileKey);
    if ($stagedHeader !== NULL) {
      foreach ($header as $column) {
        if (!in_array($column, $stagedHeader, TRUE)) {
          $report->addError($fileKey, 1, $column, sprintf('Column "%s" does not exist in the staged file.', $column));
        }
      }
    }

    $required = self::REQUIRED_COLUMNS[$fileKey] ?? [];
    $missing = array_diff($required, $header);
    foreach ($missing as $column) {
      $report->addError($fileKey, 1, $column, sprintf('Missing required column "%s".', $column));
    }
    if ($missing !== []) {
      return NULL;
    }

    return ['header' => $header, 'rows' => $rows];
  }

  /**
   * Reads and normalises the header row of a staged GTFS file, if present.
   *
   * @param string $stagingDir
   *   Absolute path to the GTFS staging directory.
   * @param string $fileKey
   *   File key (e.g. "stops").
   *
   * @return array<int, string>|null
   *   Normalised header cells, or NULL if the staged file does not exist
   *   or has no header row.
   */
  private function readStagedHeader(string $stagingDir, string $fileKey): ?array {
    $path = $stagingDir . '/' . self::FILE_NAMES[$fileKey];
    if (!is_file($path)) {
      return NULL;
    }
    $handle = @fopen($path, 'r');
    if ($handle === FALSE) {
      return NULL;
    }
    $header = NULL;
    while (($row = fgetcsv($handle, escape: '')) !== FALSE) {
      if ($row === [NULL]) {
        continue;
      }
      $header = $this->normaliseHeader($row);
      break;
    }
    fclose($handle);
    return $header;
  }

  /**
   * Streams a single ID column from a staged GTFS file into a lookup set.
   *
   * Never loads the file as a whole; reads one row at a time so this stays
   * cheap even against a 300 000+ row staged stop_times.txt.
   *
   * @param string $stagingDir
   *   Absolute path to the GTFS staging directory.
   * @param string $fileKey
   *   File key (e.g. "stops").
   * @param string $column
   *   Column name to collect.
   *
   * @return array<string, true>
   *   Non-empty values found in the column, keyed for O(1) lookup.
   */
  private function collectStagedIds(string $stagingDir, string $fileKey, string $column): array {
    $cacheKey = $fileKey . ':' . $column;
    if (isset($this->stagedIdCache[$cacheKey])) {
      return $this->stagedIdCache[$cacheKey];
    }

    $path = $stagingDir . '/' . self::FILE_NAMES[$fileKey];
    if (!is_file($path)) {
      return $this->stagedIdCache[$cacheKey] = [];
    }
    $handle = @fopen($path, 'r');
    if ($handle === FALSE) {
      return $this->stagedIdCache[$cacheKey] = [];
    }
    $header = NULL;
    $colIdx = NULL;
    $ids = [];
    while (($row = fgetcsv($handle, escape: '')) !== FALSE) {
      if ($row === [NULL]) {
        continue;
      }
      if ($header === NULL) {
        $header = $this->normaliseHeader($row);
        $idx = array_search($column, $header, TRUE);
        if ($idx === FALSE) {
          break;
        }
        $colIdx = $idx;
        continue;
      }
      $value = isset($row[$colIdx]) ? trim((string) $row[$colIdx]) : '';
      if ($value !== '') {
        $ids[$value] = TRUE;
      }
    }
    fclose($handle);
    return $this->stagedIdCache[$cacheKey] = $ids;
  }

  /**
   * Streams staged stop_times.txt, collecting stop_sequence values per trip.
   *
   * Restricted to the trip IDs referenced by the custom stop_times rows: one
   * streaming pass over the (potentially 300 000+ row) staged file, not a
   * full load.
   *
   * @param string $stagingDir
   *   Absolute path to the GTFS staging directory.
   * @param array<string, true> $tripIds
   *   Trip IDs referenced by the custom stop_times rows.
   *
   * @return array<string, array<int, true>>
   *   Map of trip ID to the set of stop_sequence values already staged for
   *   that trip.
   */
  private function collectStagedStopSequences(string $stagingDir, array $tripIds): array {
    $path = $stagingDir . '/' . self::FILE_NAMES['stop_times'];
    if (!is_file($path)) {
      return [];
    }
    $handle = @fopen($path, 'r');
    if ($handle === FALSE) {
      return [];
    }
    $header = NULL;
    $tripIdx = NULL;
    $seqIdx = NULL;
    $sequences = [];
    while (($row = fgetcsv($handle, escape: '')) !== FALSE) {
      if ($row === [NULL]) {
        continue;
      }
      if ($header === NULL) {
        $header = $this->normaliseHeader($row);
        $tripIdx = array_search('trip_id', $header, TRUE);
        $seqIdx = array_search('stop_sequence', $header, TRUE);
        if ($tripIdx === FALSE || $seqIdx === FALSE) {
          break;
        }
        continue;
      }
      $tripId = isset($row[$tripIdx]) ? trim((string) $row[$tripIdx]) : '';
      if ($tripId === '' || !isset($tripIds[$tripId])) {
        continue;
      }
      $seqRaw = isset($row[$seqIdx]) ? trim((string) $row[$seqIdx]) : '';
      if ($seqRaw === '' || !preg_match('/^\d+$/', $seqRaw)) {
        continue;
      }
      $sequences[$tripId][(int) $seqRaw] = TRUE;
    }
    fclose($handle);
    return $sequences;
  }

  /**
   * Reads one cell from a parsed data row by column name.
   *
   * @param array<int, string|null> $rowData
   *   Raw row data as returned by fgetcsv().
   * @param array<string, int> $colIndex
   *   Map of column name to index, from array_flip() of the header.
   * @param string $column
   *   Column name to read.
   *
   * @return string|null
   *   Trimmed cell value, or NULL if the column is absent from the header
   *   or the row has no value at that index.
   */
  private function cell(array $rowData, array $colIndex, string $column): ?string {
    $idx = $colIndex[$column] ?? NULL;
    if ($idx === NULL || !array_key_exists($idx, $rowData)) {
      return NULL;
    }
    return trim((string) $rowData[$idx]);
  }

  /**
   * Validates agency.txt rows and collects custom agency_id values.
   *
   * @param array{header: array<int, string>, rows: array<int, array{line: int, data: array<int, string|null>}>} $parsed
   *   Parsed file data from parseCsvFile().
   * @param string $stagingDir
   *   Absolute path to the GTFS staging directory.
   * @param \Drupal\localgov_bus_data\Service\ValidationReport $report
   *   Report to append errors to.
   *
   * @return array<string, true>
   *   Custom agency_id values found, keyed for O(1) lookup.
   */
  private function validateAgencyFile(array $parsed, string $stagingDir, ValidationReport $report): array {
    $colIndex = array_flip($parsed['header']);
    $stagedIds = $this->collectStagedIds($stagingDir, 'agency', 'agency_id');
    $customIds = [];

    foreach ($parsed['rows'] as $row) {
      $line = $row['line'];
      $data = $row['data'];
      $id = $this->cell($data, $colIndex, 'agency_id');
      $name = $this->cell($data, $colIndex, 'agency_name');

      if ($id === NULL || $id === '') {
        $report->addError('agency', $line, 'agency_id', 'agency_id is required.');
        continue;
      }
      if ($name === NULL || $name === '') {
        $report->addError('agency', $line, 'agency_name', 'agency_name is required.');
      }

      if (isset($customIds[$id])) {
        $report->addError('agency', $line, 'agency_id', sprintf('Duplicate agency_id "%s" within custom data.', $id));
      }
      elseif (isset($stagedIds[$id])) {
        $report->addError('agency', $line, 'agency_id', sprintf('agency_id "%s" collides with staged data.', $id));
      }
      $customIds[$id] = TRUE;
    }

    return $customIds;
  }

  /**
   * Validates stops.txt rows and collects custom stop_id values.
   *
   * @param array{header: array<int, string>, rows: array<int, array{line: int, data: array<int, string|null>}>} $parsed
   *   Parsed file data from parseCsvFile().
   * @param string $stagingDir
   *   Absolute path to the GTFS staging directory.
   * @param \Drupal\localgov_bus_data\Service\ValidationReport $report
   *   Report to append errors to.
   *
   * @return array<string, true>
   *   Custom stop_id values found, keyed for O(1) lookup.
   */
  private function validateStopsFile(array $parsed, string $stagingDir, ValidationReport $report): array {
    $colIndex = array_flip($parsed['header']);
    $stagedIds = $this->collectStagedIds($stagingDir, 'stops', 'stop_id');
    $hasWheelchair = in_array('wheelchair_boarding', $parsed['header'], TRUE);
    $customIds = [];

    foreach ($parsed['rows'] as $row) {
      $line = $row['line'];
      $data = $row['data'];
      $id = $this->cell($data, $colIndex, 'stop_id');
      $name = $this->cell($data, $colIndex, 'stop_name');
      $lat = $this->cell($data, $colIndex, 'stop_lat');
      $lon = $this->cell($data, $colIndex, 'stop_lon');

      if ($id === NULL || $id === '') {
        $report->addError('stops', $line, 'stop_id', 'stop_id is required.');
        continue;
      }
      if ($name === NULL || $name === '') {
        $report->addError('stops', $line, 'stop_name', 'stop_name is required.');
      }
      if (!$this->isNumericInRange($lat, -90.0, 90.0)) {
        $report->addError('stops', $line, 'stop_lat', sprintf('stop_lat "%s" must be numeric between -90 and 90.', (string) $lat));
      }
      if (!$this->isNumericInRange($lon, -180.0, 180.0)) {
        $report->addError('stops', $line, 'stop_lon', sprintf('stop_lon "%s" must be numeric between -180 and 180.', (string) $lon));
      }
      if ($hasWheelchair) {
        $wheelchair = $this->cell($data, $colIndex, 'wheelchair_boarding');
        if ($wheelchair !== NULL && $wheelchair !== '' && !in_array($wheelchair, ['0', '1', '2'], TRUE)) {
          $report->addError('stops', $line, 'wheelchair_boarding', sprintf('wheelchair_boarding "%s" must be 0, 1, or 2.', $wheelchair));
        }
      }

      if (isset($customIds[$id])) {
        $report->addError('stops', $line, 'stop_id', sprintf('Duplicate stop_id "%s" within custom data.', $id));
      }
      elseif (isset($stagedIds[$id])) {
        $report->addError('stops', $line, 'stop_id', sprintf('stop_id "%s" collides with staged data.', $id));
      }
      $customIds[$id] = TRUE;
    }

    return $customIds;
  }

  /**
   * Whether a cell value is numeric and within an inclusive range.
   */
  private function isNumericInRange(?string $value, float $min, float $max): bool {
    if ($value === NULL || $value === '' || !is_numeric($value)) {
      return FALSE;
    }
    $float = (float) $value;
    return $float >= $min && $float <= $max;
  }

  /**
   * Validates calendar.txt rows and collects custom service_id values.
   *
   * @param array{header: array<int, string>, rows: array<int, array{line: int, data: array<int, string|null>}>} $parsed
   *   Parsed file data from parseCsvFile().
   * @param string $stagingDir
   *   Absolute path to the GTFS staging directory.
   * @param \Drupal\localgov_bus_data\Service\ValidationReport $report
   *   Report to append errors to.
   *
   * @return array<string, true>
   *   Custom service_id values found, keyed for O(1) lookup.
   */
  private function validateCalendarFile(array $parsed, string $stagingDir, ValidationReport $report): array {
    $colIndex = array_flip($parsed['header']);
    $stagedIds = $this->collectStagedIds($stagingDir, 'calendar', 'service_id');
    $customIds = [];

    foreach ($parsed['rows'] as $row) {
      $line = $row['line'];
      $data = $row['data'];
      $id = $this->cell($data, $colIndex, 'service_id');

      if ($id === NULL || $id === '') {
        $report->addError('calendar', $line, 'service_id', 'service_id is required.');
        continue;
      }

      foreach (self::DAY_COLUMNS as $day) {
        $value = $this->cell($data, $colIndex, $day);
        if ($value === NULL || $value === '') {
          $report->addError('calendar', $line, $day, sprintf('%s is required.', $day));
        }
        elseif (!in_array($value, ['0', '1'], TRUE)) {
          $report->addError('calendar', $line, $day, sprintf('%s "%s" must be 0 or 1.', $day, $value));
        }
      }

      $start = $this->cell($data, $colIndex, 'start_date');
      $end = $this->cell($data, $colIndex, 'end_date');
      $startValid = $this->isValidGtfsDate($start);
      $endValid = $this->isValidGtfsDate($end);
      if (!$startValid) {
        $report->addError('calendar', $line, 'start_date', sprintf('start_date "%s" must be a valid YYYYMMDD date.', (string) $start));
      }
      if (!$endValid) {
        $report->addError('calendar', $line, 'end_date', sprintf('end_date "%s" must be a valid YYYYMMDD date.', (string) $end));
      }
      if ($startValid && $endValid && (string) $end < (string) $start) {
        $report->addError('calendar', $line, 'end_date', 'end_date must not be earlier than start_date.');
      }

      if (isset($customIds[$id])) {
        $report->addError('calendar', $line, 'service_id', sprintf('Duplicate service_id "%s" within custom data.', $id));
      }
      elseif (isset($stagedIds[$id])) {
        $report->addError('calendar', $line, 'service_id', sprintf('service_id "%s" collides with staged data.', $id));
      }
      $customIds[$id] = TRUE;
    }

    return $customIds;
  }

  /**
   * Whether a value is a valid GTFS Ymd date (e.g. "20260713").
   */
  private function isValidGtfsDate(?string $value): bool {
    if ($value === NULL || !preg_match('/^\d{8}$/', $value)) {
      return FALSE;
    }
    $year = (int) substr($value, 0, 4);
    $month = (int) substr($value, 4, 2);
    $day = (int) substr($value, 6, 2);
    return checkdate($month, $day, $year);
  }

  /**
   * Validates routes.txt rows and collects custom route_id values.
   *
   * @param array{header: array<int, string>, rows: array<int, array{line: int, data: array<int, string|null>}>} $parsed
   *   Parsed file data from parseCsvFile().
   * @param string $stagingDir
   *   Absolute path to the GTFS staging directory.
   * @param \Drupal\localgov_bus_data\Service\ValidationReport $report
   *   Report to append errors to.
   * @param array<string, true> $customAgencyIds
   *   Custom agency_id values from validateAgencyFile().
   *
   * @return array<string, true>
   *   Custom route_id values found, keyed for O(1) lookup.
   */
  private function validateRoutesFile(array $parsed, string $stagingDir, ValidationReport $report, array $customAgencyIds): array {
    $colIndex = array_flip($parsed['header']);
    $stagedIds = $this->collectStagedIds($stagingDir, 'routes', 'route_id');
    $stagedAgencyIds = $this->collectStagedIds($stagingDir, 'agency', 'agency_id');
    $customIds = [];

    foreach ($parsed['rows'] as $row) {
      $line = $row['line'];
      $data = $row['data'];
      $id = $this->cell($data, $colIndex, 'route_id');
      $shortName = $this->cell($data, $colIndex, 'route_short_name');
      $agencyId = $this->cell($data, $colIndex, 'agency_id');
      $routeType = $this->cell($data, $colIndex, 'route_type');

      if ($id === NULL || $id === '') {
        $report->addError('routes', $line, 'route_id', 'route_id is required.');
        continue;
      }
      if ($shortName === NULL || $shortName === '') {
        $report->addError('routes', $line, 'route_short_name', 'route_short_name is required.');
      }
      if ($agencyId === NULL || $agencyId === '') {
        $report->addError('routes', $line, 'agency_id', 'agency_id is required.');
      }
      elseif (!isset($customAgencyIds[$agencyId]) && !isset($stagedAgencyIds[$agencyId])) {
        $report->addError('routes', $line, 'agency_id', sprintf('agency_id "%s" does not exist in staged or custom agency data.', $agencyId));
      }
      if ($routeType === NULL || $routeType === '' || !preg_match('/^\d+$/', $routeType)) {
        $report->addError('routes', $line, 'route_type', sprintf('route_type "%s" must be a non-negative integer.', (string) $routeType));
      }

      if (isset($customIds[$id])) {
        $report->addError('routes', $line, 'route_id', sprintf('Duplicate route_id "%s" within custom data.', $id));
      }
      elseif (isset($stagedIds[$id])) {
        $report->addError('routes', $line, 'route_id', sprintf('route_id "%s" collides with staged data.', $id));
      }
      $customIds[$id] = TRUE;
    }

    return $customIds;
  }

  /**
   * Validates trips.txt rows and collects custom trip_id values.
   *
   * @param array{header: array<int, string>, rows: array<int, array{line: int, data: array<int, string|null>}>} $parsed
   *   Parsed file data from parseCsvFile().
   * @param string $stagingDir
   *   Absolute path to the GTFS staging directory.
   * @param \Drupal\localgov_bus_data\Service\ValidationReport $report
   *   Report to append errors to.
   * @param array<string, true> $customRouteIds
   *   Custom route_id values from validateRoutesFile().
   * @param array<string, true> $customServiceIds
   *   Custom service_id values from validateCalendarFile().
   *
   * @return array<string, true>
   *   Custom trip_id values found, keyed for O(1) lookup.
   */
  private function validateTripsFile(array $parsed, string $stagingDir, ValidationReport $report, array $customRouteIds, array $customServiceIds): array {
    $colIndex = array_flip($parsed['header']);
    $stagedIds = $this->collectStagedIds($stagingDir, 'trips', 'trip_id');
    $stagedRouteIds = $this->collectStagedIds($stagingDir, 'routes', 'route_id');
    $stagedServiceIds = $this->collectStagedIds($stagingDir, 'calendar', 'service_id');
    $hasDirection = in_array('direction_id', $parsed['header'], TRUE);
    $hasHeadsign = in_array('trip_headsign', $parsed['header'], TRUE);
    $customIds = [];

    foreach ($parsed['rows'] as $row) {
      $line = $row['line'];
      $data = $row['data'];
      $id = $this->cell($data, $colIndex, 'trip_id');
      $routeId = $this->cell($data, $colIndex, 'route_id');
      $serviceId = $this->cell($data, $colIndex, 'service_id');

      if ($id === NULL || $id === '') {
        $report->addError('trips', $line, 'trip_id', 'trip_id is required.');
        continue;
      }
      if ($routeId === NULL || $routeId === '') {
        $report->addError('trips', $line, 'route_id', 'route_id is required.');
      }
      elseif (!isset($customRouteIds[$routeId]) && !isset($stagedRouteIds[$routeId])) {
        $report->addError('trips', $line, 'route_id', sprintf('route_id "%s" does not exist in staged or custom routes data.', $routeId));
      }
      if ($serviceId === NULL || $serviceId === '') {
        $report->addError('trips', $line, 'service_id', 'service_id is required.');
      }
      elseif (!isset($customServiceIds[$serviceId]) && !isset($stagedServiceIds[$serviceId])) {
        $report->addError('trips', $line, 'service_id', sprintf('service_id "%s" does not exist in staged or custom calendar data.', $serviceId));
      }
      if ($hasDirection) {
        $direction = $this->cell($data, $colIndex, 'direction_id');
        if ($direction !== NULL && $direction !== '' && !in_array($direction, ['0', '1'], TRUE)) {
          $report->addError('trips', $line, 'direction_id', sprintf('direction_id "%s" must be 0 or 1.', $direction));
        }
      }
      if ($hasHeadsign) {
        $headsign = $this->cell($data, $colIndex, 'trip_headsign');
        if ($headsign !== NULL && mb_strlen($headsign) > 255) {
          $report->addError('trips', $line, 'trip_headsign', 'trip_headsign must be at most 255 characters.');
        }
      }

      if (isset($customIds[$id])) {
        $report->addError('trips', $line, 'trip_id', sprintf('Duplicate trip_id "%s" within custom data.', $id));
      }
      elseif (isset($stagedIds[$id])) {
        $report->addError('trips', $line, 'trip_id', sprintf('trip_id "%s" collides with staged data.', $id));
      }
      $customIds[$id] = TRUE;
    }

    return $customIds;
  }

  /**
   * Validates stop_times.txt rows against custom trips and stops.
   *
   * @param array{header: array<int, string>, rows: array<int, array{line: int, data: array<int, string|null>}>} $parsed
   *   Parsed file data from parseCsvFile().
   * @param string $stagingDir
   *   Absolute path to the GTFS staging directory.
   * @param \Drupal\localgov_bus_data\Service\ValidationReport $report
   *   Report to append errors to.
   * @param array<string, true> $customTripIds
   *   Custom trip_id values from validateTripsFile().
   * @param array<string, true> $customStopIds
   *   Custom stop_id values from validateStopsFile().
   */
  private function validateStopTimesFile(array $parsed, string $stagingDir, ValidationReport $report, array $customTripIds, array $customStopIds): void {
    $colIndex = array_flip($parsed['header']);
    $stagedTripIds = $this->collectStagedIds($stagingDir, 'trips', 'trip_id');
    $stagedStopIds = $this->collectStagedIds($stagingDir, 'stops', 'stop_id');

    $rowsByTrip = [];
    $seenPairs = [];
    $referencedTripIds = [];

    foreach ($parsed['rows'] as $row) {
      $line = $row['line'];
      $data = $row['data'];
      $tripId = $this->cell($data, $colIndex, 'trip_id');
      $arr = $this->cell($data, $colIndex, 'arrival_time');
      $dep = $this->cell($data, $colIndex, 'departure_time');
      $stopId = $this->cell($data, $colIndex, 'stop_id');
      $seqRaw = $this->cell($data, $colIndex, 'stop_sequence');

      if ($tripId === NULL || $tripId === '') {
        $report->addError('stop_times', $line, 'trip_id', 'trip_id is required.');
        continue;
      }
      if (!isset($customTripIds[$tripId]) && !isset($stagedTripIds[$tripId])) {
        $report->addError('stop_times', $line, 'trip_id', sprintf('trip_id "%s" does not exist in staged or custom trips data.', $tripId));
      }
      if ($stopId === NULL || $stopId === '') {
        $report->addError('stop_times', $line, 'stop_id', 'stop_id is required.');
      }
      elseif (!isset($customStopIds[$stopId]) && !isset($stagedStopIds[$stopId])) {
        $report->addError('stop_times', $line, 'stop_id', sprintf('stop_id "%s" does not exist in staged or custom stops data.', $stopId));
      }

      $arrValid = $this->isValidGtfsTime($arr);
      $depValid = $this->isValidGtfsTime($dep);
      if (!$arrValid) {
        $report->addError('stop_times', $line, 'arrival_time', sprintf('arrival_time "%s" must match H:MM:SS (hours 0-47).', (string) $arr));
      }
      if (!$depValid) {
        $report->addError('stop_times', $line, 'departure_time', sprintf('departure_time "%s" must match H:MM:SS (hours 0-47).', (string) $dep));
      }
      if ($arrValid && $depValid && $this->gtfsTimeToSeconds($dep) < $this->gtfsTimeToSeconds($arr)) {
        $report->addError('stop_times', $line, 'departure_time', 'departure_time must not be earlier than arrival_time.');
      }

      $seq = NULL;
      if ($seqRaw === NULL || $seqRaw === '' || !preg_match('/^\d+$/', $seqRaw)) {
        $report->addError('stop_times', $line, 'stop_sequence', sprintf('stop_sequence "%s" must be a non-negative integer.', (string) $seqRaw));
      }
      else {
        $seq = (int) $seqRaw;
      }

      if ($seq !== NULL) {
        $referencedTripIds[$tripId] = TRUE;
        if (isset($seenPairs[$tripId][$seq])) {
          $report->addError('stop_times', $line, 'stop_sequence', sprintf('Duplicate (trip_id, stop_sequence) "%s, %d" within custom data.', $tripId, $seq));
        }
        $seenPairs[$tripId][$seq] = TRUE;

        $rowsByTrip[$tripId][] = [
          'line' => $line,
          'seq'  => $seq,
          'arr'  => $arrValid ? $this->gtfsTimeToSeconds($arr) : NULL,
          'dep'  => $depValid ? $this->gtfsTimeToSeconds($dep) : NULL,
        ];
      }
    }

    // Within each custom trip, times must not decrease as stop_sequence
    // increases: the arrival at each stop must be no earlier than the
    // departure from the previous stop in sequence order.
    foreach ($rowsByTrip as $tripId => $rows) {
      usort($rows, static fn(array $a, array $b): int => $a['seq'] <=> $b['seq']);
      $prevDep = NULL;
      foreach ($rows as $r) {
        if ($r['arr'] === NULL || $r['dep'] === NULL) {
          // Format error already reported for this row; skip it without
          // updating $prevDep, so a single malformed row does not cause a
          // false "times decrease" error on the next valid row.
          continue;
        }
        if ($prevDep !== NULL && $r['arr'] < $prevDep) {
          $report->addError('stop_times', $r['line'], 'stop_sequence', sprintf('Times decrease along trip "%s" at stop_sequence %d.', $tripId, $r['seq']));
        }
        $prevDep = $r['dep'];
      }
    }

    if ($referencedTripIds !== []) {
      $stagedSequences = $this->collectStagedStopSequences($stagingDir, $referencedTripIds);
      foreach ($rowsByTrip as $tripId => $rows) {
        if (!isset($stagedSequences[$tripId])) {
          continue;
        }
        foreach ($rows as $r) {
          if (isset($stagedSequences[$tripId][$r['seq']])) {
            $report->addError('stop_times', $r['line'], 'stop_sequence', sprintf('(trip_id, stop_sequence) "%s, %d" collides with staged data.', $tripId, $r['seq']));
          }
        }
      }
    }
  }

  /**
   * Whether a value matches GTFS time format H:MM:SS with hours 0-47.
   */
  private function isValidGtfsTime(?string $value): bool {
    return $value !== NULL
      && (bool) preg_match('/^(\d{1,2}):([0-5]\d):([0-5]\d)$/', $value, $matches)
      && (int) $matches[1] <= 47;
  }

  /**
   * Converts a validated GTFS time string to seconds since midnight.
   */
  private function gtfsTimeToSeconds(?string $value): int {
    if ($value === NULL || !preg_match('/^(\d{1,2}):([0-5]\d):([0-5]\d)$/', $value, $matches)) {
      return 0;
    }
    return ((int) $matches[1] * 3600) + ((int) $matches[2] * 60) + (int) $matches[3];
  }

}
