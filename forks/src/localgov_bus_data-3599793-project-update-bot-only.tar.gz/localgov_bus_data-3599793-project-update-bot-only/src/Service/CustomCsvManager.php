<?php

declare(strict_types=1);

namespace Drupal\localgov_bus_data\Service;

use Drupal\Core\Config\ConfigFactoryInterface;
use Drupal\Core\Entity\EntityTypeManagerInterface;
use Drupal\Core\File\FileSystemInterface;
use Drupal\Core\State\StateInterface;
use Drupal\file\FileUsage\FileUsageInterface;
use Psr\Log\LoggerInterface;

/**
 * Orchestrates storage, validation, and merge of custom GTFS CSV data.
 *
 * Reads the stored custom file set from config (localgov_bus_data.settings
 * custom_data.files, a map of file key to managed file ID), resolves each
 * entry to an absolute file path, and merges accepted rows into the GTFS
 * staging directory on every import. Missing file entities (e.g. config
 * synced from another environment, or a file deleted outside the form) are
 * treated as an empty slot: logged and skipped, never thrown.
 */
final class CustomCsvManager {

  use CustomCsvHeaderTrait;

  /**
   * State key under which the most recent validation report is stored.
   */
  public const STATE_KEY = 'localgov_bus_data.custom_data_report';

  /**
   * Maximum number of errors written to a single log entry.
   *
   * A cap on the log, not the report itself: State still stores the report
   * in full for the form to read from.
   */
  private const MAX_LOGGED_ERRORS = 1000;

  public function __construct(
    private readonly ConfigFactoryInterface $configFactory,
    private readonly EntityTypeManagerInterface $entityTypeManager,
    private readonly FileSystemInterface $fileSystem,
    private readonly FileUsageInterface $fileUsage,
    private readonly StateInterface $state,
    private readonly LoggerInterface $logger,
    private readonly CustomCsvValidator $validator,
  ) {}

  /**
   * Whether custom data merging is enabled in config.
   */
  public function isEnabled(): bool {
    return (bool) $this->configFactory->get('localgov_bus_data.settings')->get('custom_data.enabled');
  }

  /**
   * Whether any custom file is currently stored in config.
   */
  public function hasStoredFiles(): bool {
    $fileIds = $this->configFactory->get('localgov_bus_data.settings')->get('custom_data.files');
    return is_array($fileIds) && $fileIds !== [];
  }

  /**
   * Validates the currently stored custom file set and records the report.
   *
   * Used both by the "Validate now" form action and by import-time
   * revalidation. The report is stored in State so the admin form can
   * display the result of the most recent validation run.
   *
   * @param string $stagingDir
   *   Absolute path to a staging directory to validate against. Must be
   *   the clean pre-merge snapshot (GtfsImportService::
   *   getCleanStagingDirPath()), not the live staging directory: this
   *   method only validates, it never merges, and the live directory may
   *   still contain this exact custom set from a previous merge, which
   *   would then show up as a false "collides with staged data" error
   *   against itself.
   *
   * @return \Drupal\localgov_bus_data\Service\ValidationReport
   *   The validation result.
   */
  public function validateStoredFiles(string $stagingDir): ValidationReport {
    $report = $this->validator->validate($this->resolveStoredFilePaths(), $stagingDir);
    $this->recordReport($report);
    return $report;
  }

  /**
   * Merges the stored custom file set into the GTFS staging directory.
   *
   * Returns silently with no changes when custom data is disabled or no
   * files are stored. Does not validate first: callers that need
   * revalidate-then-merge-or-skip behaviour (the import pipeline, per spec
   * section 4.7) call validateStoredFiles() themselves first and only call
   * this method when the report is valid. Trusting that contract is what
   * lets the column-index mapping below stay simple: a custom column absent
   * from the staged header is silently ignored here rather than erroring,
   * because the validator is relied on to have already rejected that upload.
   *
   * @param string $stagingDir
   *   Absolute path to the live GTFS staging directory to merge into
   *   (unlike the other public methods on this class, this one actually
   *   writes here: it must be the real staging directory, not the clean
   *   snapshot).
   *
   * @return array<string, int>
   *   Appended row counts, keyed by file key. Only includes file keys that
   *   were actually merged.
   */
  public function mergeIntoStaging(string $stagingDir): array {
    if (!$this->isEnabled()) {
      return [];
    }

    $filePaths = $this->resolveStoredFilePaths();
    if ($filePaths === []) {
      return [];
    }

    $counts = [];
    foreach ($filePaths as $fileKey => $customPath) {
      $stagedPath = $stagingDir . '/' . CustomCsvValidator::FILE_NAMES[$fileKey];
      $counts[$fileKey] = is_file($stagedPath)
        ? $this->appendMappedRows($customPath, $stagedPath)
        : $this->writeAsStagedFile($customPath, $stagedPath);
    }

    return $counts;
  }

  /**
   * Validates a proposed replacement set without saving anything.
   *
   * Combines newly uploaded (still temporary) files with any already-stored
   * files not being replaced, and validates the combined set against the
   * staged data. Used by the form to check an upload before committing it.
   *
   * @param array<string, int> $newFileIds
   *   File key => newly uploaded (still temporary) managed file ID, for
   *   slots being added or replaced.
   * @param string $stagingDir
   *   Absolute path to the clean pre-merge snapshot to validate against
   *   (see validateStoredFiles() for why this must not be the live staging
   *   directory).
   *
   * @return \Drupal\localgov_bus_data\Service\ValidationReport
   *   The validation result.
   */
  public function validateProposedSet(array $newFileIds, string $stagingDir): ValidationReport {
    $paths = $this->resolveStoredFilePaths();

    foreach ($newFileIds as $fileKey => $fid) {
      if (!isset(CustomCsvValidator::FILE_NAMES[$fileKey])) {
        continue;
      }
      $path = $this->resolveFileIdToPath((int) $fid, $fileKey);
      if ($path !== NULL) {
        $paths[$fileKey] = $path;
      }
    }

    $report = $this->validator->validate($paths, $stagingDir);
    $this->recordReport($report);
    return $report;
  }

  /**
   * Validates and, if valid, persists a proposed upload.
   *
   * On success: makes each newly uploaded file permanent, registers
   * file.usage, and, for any replaced slot, releases the previous file's
   * usage and deletes it (so replacing a slot repeatedly never accumulates
   * orphaned permanent files with no usage record), then saves the merged
   * file ID map to config. On failure: nothing is saved. The new uploads
   * are left temporary, so Drupal's normal temporary-file cleanup removes
   * them, and the previously stored set remains active. Either way the
   * report is recorded in State.
   *
   * @param array<string, int> $newFileIds
   *   File key => newly uploaded (still temporary) managed file ID.
   * @param string $stagingDir
   *   Absolute path to the clean pre-merge snapshot to validate against
   *   (see validateStoredFiles()); this method only validates and never
   *   merges into the live staging directory itself.
   *
   * @return \Drupal\localgov_bus_data\Service\ValidationReport
   *   The validation result.
   */
  public function saveUpload(array $newFileIds, string $stagingDir): ValidationReport {
    $report = $this->validateProposedSet($newFileIds, $stagingDir);
    if (!$report->isValid()) {
      return $report;
    }

    $config = $this->configFactory->getEditable('localgov_bus_data.settings');
    $storedFileIds = $config->get('custom_data.files');
    $storedFileIds = is_array($storedFileIds) ? $storedFileIds : [];

    $storage = $this->entityTypeManager->getStorage('file');

    foreach ($newFileIds as $fileKey => $fid) {
      if (!isset(CustomCsvValidator::FILE_NAMES[$fileKey])) {
        continue;
      }
      $file = $storage->load($fid);
      if ($file === NULL) {
        continue;
      }

      $previousFid = $storedFileIds[$fileKey] ?? NULL;
      if (!empty($previousFid) && (int) $previousFid !== (int) $fid) {
        $previousFile = $storage->load($previousFid);
        if ($previousFile !== NULL) {
          $this->fileUsage->delete($previousFile, 'localgov_bus_data', 'custom_data', $fileKey);
          $previousFile->delete();
        }
      }

      $file->setPermanent();
      $file->save();
      $this->fileUsage->add($file, 'localgov_bus_data', 'custom_data', $fileKey);
      $storedFileIds[$fileKey] = (int) $fid;
    }

    $config->set('custom_data.files', $storedFileIds)->save();

    return $report;
  }

  /**
   * Removes a stored custom file slot.
   *
   * Deletes the managed file, its file.usage record, and the config entry
   * for that slot, then revalidates the retained set so a broken reference
   * (for example removing custom agency data that custom routes still
   * point to) is flagged immediately rather than discovered at the next
   * import. The removal itself is never blocked by validation: the
   * import-time skip already protects the real timetable data.
   *
   * @param string $fileKey
   *   File key to remove (e.g. "stops").
   * @param string $stagingDir
   *   Absolute path to the clean pre-merge snapshot for the revalidation
   *   pass (see validateStoredFiles()).
   *
   * @return \Drupal\localgov_bus_data\Service\ValidationReport
   *   The validation result for the retained set.
   */
  public function removeFile(string $fileKey, string $stagingDir): ValidationReport {
    if (isset(CustomCsvValidator::FILE_NAMES[$fileKey])) {
      $config = $this->configFactory->getEditable('localgov_bus_data.settings');
      $storedFileIds = $config->get('custom_data.files');
      $storedFileIds = is_array($storedFileIds) ? $storedFileIds : [];

      $fid = $storedFileIds[$fileKey] ?? NULL;
      if (!empty($fid)) {
        $file = $this->entityTypeManager->getStorage('file')->load($fid);
        if ($file !== NULL) {
          $this->fileUsage->delete($file, 'localgov_bus_data', 'custom_data', $fileKey);
          $file->delete();
        }
      }

      unset($storedFileIds[$fileKey]);
      $config->set('custom_data.files', $storedFileIds)->save();
    }

    return $this->validateStoredFiles($stagingDir);
  }

  /**
   * Resolves the stored custom file set to absolute paths.
   *
   * Reads custom_data.files from config (file key => managed file ID),
   * loads each File entity, and resolves its URI to an absolute path. A
   * config entry referencing a file ID that no longer exists is logged and
   * skipped rather than thrown.
   *
   * @return array<string, string>
   *   Absolute file paths keyed by file key. Only includes file keys with a
   *   resolvable stored file.
   */
  private function resolveStoredFilePaths(): array {
    $fileIds = $this->configFactory->get('localgov_bus_data.settings')->get('custom_data.files');
    if (!is_array($fileIds) || $fileIds === []) {
      return [];
    }

    $paths = [];
    foreach ($fileIds as $fileKey => $fid) {
      if (!isset(CustomCsvValidator::FILE_NAMES[$fileKey]) || empty($fid)) {
        continue;
      }
      $path = $this->resolveFileIdToPath((int) $fid, $fileKey);
      if ($path !== NULL) {
        $paths[$fileKey] = $path;
      }
    }

    return $paths;
  }

  /**
   * Resolves a single managed file ID to an absolute path.
   *
   * A file ID that no longer resolves to a File entity, or whose URI cannot
   * be resolved to a real path, is logged and treated as absent rather than
   * thrown: config synced from another environment, or a file deleted
   * outside the form, must never fail the caller.
   *
   * @param int $fid
   *   Managed file ID.
   * @param string $fileKey
   *   File key (e.g. "stops"), used only to label the log message.
   *
   * @return string|null
   *   Absolute path, or NULL if unresolvable.
   */
  private function resolveFileIdToPath(int $fid, string $fileKey): ?string {
    $file = $this->entityTypeManager->getStorage('file')->load($fid);
    if ($file === NULL) {
      $this->logger->warning(
        'Custom CSV data: file entity @fid for "@key" no longer exists; treating as empty.',
        ['@fid' => $fid, '@key' => $fileKey],
      );
      return NULL;
    }

    $path = $this->fileSystem->realpath($file->getFileUri());
    if ($path === FALSE) {
      $this->logger->warning(
        'Custom CSV data: could not resolve a path for stored file "@key".',
        ['@key' => $fileKey],
      );
      return NULL;
    }

    return $path;
  }

  /**
   * Appends a custom file's rows to an existing staged file.
   *
   * Maps each custom column to its staged column position by name (spec
   * section 4.6): the staged header determines the output column order and
   * count, so migrate_source_csv and the chunk processors, which derive
   * column indexes from the single staged header row, see one consistent
   * layout regardless of how the custom file orders its columns. Staged
   * columns absent from the custom file are filled with an empty string.
   *
   * @param string $customPath
   *   Absolute path to the stored custom CSV file.
   * @param string $stagedPath
   *   Absolute path to the staged GTFS file to append to.
   *
   * @return int
   *   Number of rows appended.
   */
  private function appendMappedRows(string $customPath, string $stagedPath): int {
    $stagedHeader = $this->readHeader($stagedPath);
    if ($stagedHeader === NULL) {
      // Staged file exists but has no readable header: treat the same as
      // a missing counterpart.
      return $this->writeAsStagedFile($customPath, $stagedPath);
    }

    $in = @fopen($customPath, 'r');
    if ($in === FALSE) {
      $this->logger->warning('Custom CSV merge: could not open @path for reading.', ['@path' => $customPath]);
      return 0;
    }
    $out = fopen($stagedPath, 'a');
    if ($out === FALSE) {
      fclose($in);
      $this->logger->warning('Custom CSV merge: could not open @path for appending.', ['@path' => $stagedPath]);
      return 0;
    }

    $customHeader = NULL;
    // Staged column index (0-based, matching $stagedHeader) => custom row
    // index, or NULL when the custom file has no such column.
    $indexMap = [];
    $count = 0;

    while (($row = fgetcsv($in, escape: '')) !== FALSE) {
      if ($row === [NULL]) {
        continue;
      }
      if ($customHeader === NULL) {
        $customHeader = $this->normaliseHeader($row);
        foreach ($stagedHeader as $column) {
          $idx = array_search($column, $customHeader, TRUE);
          $indexMap[] = $idx === FALSE ? NULL : $idx;
        }
        continue;
      }

      $mappedRow = [];
      foreach ($indexMap as $customIdx) {
        $mappedRow[] = $customIdx === NULL ? '' : trim((string) ($row[$customIdx] ?? ''));
      }
      fputcsv($out, $mappedRow, escape: '');
      $count++;
    }

    fclose($in);
    fclose($out);

    return $count;
  }

  /**
   * Writes a custom file as the staged file, verbatim, when none exists yet.
   *
   * Covers the edge case where the source feed lacked this file entirely:
   * the custom file's own header and column order become the staged
   * file's.
   *
   * @param string $customPath
   *   Absolute path to the stored custom CSV file.
   * @param string $stagedPath
   *   Absolute path to write as the new staged file.
   *
   * @return int
   *   Number of data rows written.
   */
  private function writeAsStagedFile(string $customPath, string $stagedPath): int {
    $in = @fopen($customPath, 'r');
    if ($in === FALSE) {
      $this->logger->warning('Custom CSV merge: could not open @path for reading.', ['@path' => $customPath]);
      return 0;
    }
    $out = fopen($stagedPath, 'w');
    if ($out === FALSE) {
      fclose($in);
      $this->logger->warning('Custom CSV merge: could not create @path.', ['@path' => $stagedPath]);
      return 0;
    }

    $wroteHeader = FALSE;
    $count = 0;

    while (($row = fgetcsv($in, escape: '')) !== FALSE) {
      if ($row === [NULL]) {
        continue;
      }
      if (!$wroteHeader) {
        fputcsv($out, $this->normaliseHeader($row), escape: '');
        $wroteHeader = TRUE;
        continue;
      }
      fputcsv($out, $this->trimRowCells($row), escape: '');
      $count++;
    }

    fclose($in);
    fclose($out);

    return $count;
  }

  /**
   * Trims every cell in a data row.
   *
   * CustomCsvValidator::cell() trims each cell before checking it, so a row
   * with spaces after commas (routine in hand-edited CSVs) validates. The
   * merge must write the same trimmed values, or a staged ID like " R1"
   * (untrimmed) fails to match "R1" elsewhere in the staged data despite
   * having been reported as valid.
   *
   * @param array<int, string|null> $row
   *   Raw data row as returned by fgetcsv().
   *
   * @return array<int, string>
   *   Trimmed cell values.
   */
  private function trimRowCells(array $row): array {
    return array_map(static fn($cell): string => trim((string) $cell), $row);
  }

  /**
   * Reads and normalises the header row of a CSV file.
   *
   * @param string $path
   *   Absolute path to the CSV file.
   *
   * @return array<int, string>|null
   *   Normalised header cells, or NULL if the file has no readable header.
   */
  private function readHeader(string $path): ?array {
    if (!is_file($path)) {
      return NULL;
    }
    $handle = @fopen($path, 'r');
    if ($handle === FALSE) {
      return NULL;
    }
    $header = NULL;
    while (($row = fgetcsv($handle, escape: '')) !== FALSE) {
      if ($row === [NULL]) {
        continue;
      }
      $header = $this->normaliseHeader($row);
      break;
    }
    fclose($handle);
    return $header;
  }

  /**
   * Stores a validation report snapshot in State for display on the form.
   *
   * Stored as a plain array rather than the ValidationReport object itself,
   * so State stays readable across code changes to the report class. An
   * invalid report is also logged in full: the form only renders the first
   * 100 rows per file, so the log is the record of anything beyond that
   * cap.
   *
   * @param \Drupal\localgov_bus_data\Service\ValidationReport $report
   *   The report to store.
   */
  private function recordReport(ValidationReport $report): void {
    $this->state->set(self::STATE_KEY, [
      'valid'               => $report->isValid(),
      'errors'              => $report->getErrors(),
      'accepted_row_counts' => $report->getAcceptedRowCounts(),
      'timestamp'           => time(),
    ]);

    if (!$report->isValid()) {
      $this->logger->warning(
        'Custom CSV validation failed: @count errors in @files file(s). Report (@shown of @count shown): @report',
        [
          '@count'  => $report->errorCount(),
          '@files'  => $report->fileErrorCount(),
          '@shown'  => min($report->errorCount(), self::MAX_LOGGED_ERRORS),
          '@report' => $this->encodeErrorsForLog($report->getErrors()),
        ],
      );
    }
  }

  /**
   * JSON-encodes a capped slice of validation errors for the log.
   *
   * A pathological upload (a large file with thousands of malformed rows)
   * could otherwise produce a single log entry many megabytes in size, the
   * same memory-discipline concern this module already applies to reading
   * large CSV files. JSON_INVALID_UTF8_SUBSTITUTE guards against
   * json_encode() silently returning FALSE when a CSV cell contains invalid
   * UTF-8, which would otherwise produce an empty, useless log entry for
   * exactly the malformed uploads that need it most.
   *
   * @param array<int, array{file: string, line: int, column: string|null, message: string}> $errors
   *   Full error list from the report.
   *
   * @return string
   *   JSON-encoded (possibly truncated) error list.
   */
  private function encodeErrorsForLog(array $errors): string {
    $capped = array_slice($errors, 0, self::MAX_LOGGED_ERRORS);
    return (string) json_encode($capped, JSON_INVALID_UTF8_SUBSTITUTE);
  }

}
