<?php

declare(strict_types=1);

namespace Drupal\localgov_bus_data\Service;

/**
 * Shared CSV header normalisation for CustomCsvValidator and CustomCsvManager.
 *
 * Both classes must agree on exactly how a header row is normalised:
 * CustomCsvValidator's "column not in staged header" check and
 * CustomCsvManager's column-index mapping during the merge both depend on
 * comparing normalised header cells for the same file. Sharing this trait
 * keeps that agreement from drifting if the normalisation rules ever change.
 */
trait CustomCsvHeaderTrait {

  /**
   * Trims header cells and strips a UTF-8 BOM from the first cell.
   *
   * @param array<int, string|null> $row
   *   Raw header row as returned by fgetcsv().
   *
   * @return array<int, string>
   *   Normalised header cells.
   */
  private function normaliseHeader(array $row): array {
    $header = [];
    foreach ($row as $i => $cell) {
      $cell = (string) $cell;
      if ($i === 0) {
        $cell = preg_replace('/^\xEF\xBB\xBF/', '', $cell) ?? $cell;
      }
      $header[] = trim($cell);
    }
    return $header;
  }

}
