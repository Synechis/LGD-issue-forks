**LocalGov Bus Data** is a Drupal 10/11 module that imports UK bus timetable data from bulk GTFS feeds, enriches stop data from NaPTAN, and exposes everything as Drupal entities and Views for use on local council websites.

## Requirements

- Drupal 10.2+ or 11
- PHP 8.3+
- MySQL 5.7+ or MariaDB 10.3+ (`GROUP_CONCAT` is used for stop service aggregation, so SQLite and PostgreSQL are not supported)
- `drupal/migrate_plus` ^6.0
- `drupal/migrate_source_csv` ^3.0
- `drupal/geofield` ^1.0 (including the `geofield` submodule)
- `drupal/leaflet` ^10.0 (including the `leaflet_views` and `leaflet_markercluster` submodules)

All dependencies are declared in `localgov_bus_data.info.yml` and enabled automatically when the module is installed via Composer.

## Install with Composer

<pre>
  <code>
    composer require drupal/localgov_bus_data
    drush en localgov_bus_data -y
    drush cr
  </code>
</pre>


## Submodules

### localgov_bus_data_homepage

An optional submodule that provides a public-facing landing page at `/buses` with:

- Configurable intro text
- Route number search form
- Operator search form, with autocomplete on bus company names
- Stop name search form
- Interchange and bus station quick-links
- Area browse widget (lists localities grouped by configurable area, driven by NaPTAN locality data)

> **Note:** The interchange links and area browse sections rely on `bustimes_locality` data, which is only populated after NaPTAN enrichment runs. Enable NaPTAN in the main settings before enabling this submodule.

```bash
drush en localgov_bus_data_homepage -y
```

Configure at `/admin/config/localgov-bus-data/homepage`.


## Public pages

The module has five visitor-facing page displays:

| Path | View | Description |
|---|---|---|
| `/buses/routes` | `localgov_bus_routes` | Lists all routes with service number and name. Exposed filters to search by route number and by operator (bus company name). The homepage operator search submits to this page. |
| `/buses/routes/%/%/%` | `localgov_bus_timetable` | Timetable grid for a route. The three `%` segments are agency ID, route short name, and slug, the last distinguishing distinct GTFS routes merged onto the same operator and route number. Exposed filters for day (Mon–Fri / Sat / Sun) and direction (Outbound / Inbound). Uses the custom `BusTimetableStyle` plugin to render a stop × trip matrix. A Leaflet map attachment displays all stops in the filtered result set as markers below the timetable, joined by a route line (see [Route maps](#route-maps)). |
| `/buses/stops` | `localgov_bus_stop_search` | Stop search: type a stop name or ATCO code. When NaPTAN enrichment has run, results include indicator, street and locality (e.g. *Church Street (opp) Market Road, Carlisle*). |
| `/buses/stops/%` | `localgov_bus_stop_detail` | Scheduled departures for a single stop. The `%` segment is the ATCO stop code. Exposed filter for day. A Leaflet map attachment displays the stop's location as a marker below the departures table. |
| `/buses/map` | `localgov_bus_stop_map` | All stops with lat/lon coordinates (table format). |


## Route URLs and upgrading from 1.3.x

A route timetable lives at three URL segments:

```
/buses/routes/{agency_id}/{route_short_name}/{slug}
```

The slug is derived from the route's headsign (for example `keswick`), and is
what keeps two distinct GTFS routes apart when an operator runs both of them
under the same route number. Before 1.4.x the page had only the first two
segments, so those routes merged onto one timetable showing a mixture of both.

Old two-segment URLs still work. `/buses/routes/{agency_id}/{route_short_name}`
redirects (302) to the single matching route's timetable, or (302) to the route
search filtered to that number when more than one route matches. Any query
string on the old URL (the day and direction filters) is carried through to the
destination. A URL matching no route at all gets the site's 404 page.

### Upgrading

Run the database updates. There is no reimport:

```bash
drush updatedb -y
drush cr
```

Slugs are backfilled from the headsigns already stored on the site, so existing
routes get their URLs without refetching the GTFS feed. Backfilled slugs are
only written where the field is empty, so re-running the updates never
renumbers a published URL.

**If you deploy configuration from a repository, export afterwards.** Updates
10011 and 10012 edit active Views configuration: they add the slug argument and
third path segment to `views.view.localgov_bus_timetable`, and the slug token to
the route link paths in `views.view.localgov_bus_routes` and
`views.view.localgov_bus_stop_detail`. Those edits are not in your exported
config until you export them, so:

```bash
drush updatedb -y
drush config:export -y   # commit the result
```

Skip the export and the next `drush config:import` will revert the timetable
view's path and arguments together, back to two segments. Pages still render,
but distinct routes sharing an operator route number merge back onto one
timetable, the pre-1.4.x behaviour the slug was added to fix.

Sites that moved the bus pages off `/buses` with the homepage submodule's
settings form are handled: the updates match on the trailing path segments
rather than on `/buses`, and the legacy redirect follows the timetable page to
wherever it now lives. Each update reports the displays it changed and any it
left alone, so check the `drush updatedb` output if a page path has been
customised by hand.


## Route maps

The map below a route timetable draws a line through the stops in the filtered
result set, so the shape of the service is visible alongside the grid. The line
follows the day and direction filters: change either and the map redraws for
that selection.

Where the feed supplies shape geometry, the line follows the road. The import
reads `shapes.txt` from the GTFS feed and stores the shape points, and each
trip carries its `shape_id`, so the map can draw the operator's own traced
route rather than an approximation.

Not every route in a feed has shape data. Where a route has none, the map falls
back to straight lines drawn between consecutive stops in `stop_sequence`
order. That still shows the order and direction of travel, but bends and loops
are approximate. No configuration is involved: the map uses shape geometry when
it exists for that route and falls back silently when it does not.


## Configuration

- All settings live in `localgov_bus_data.settings` config and are managed via the settings form at `/admin/config/localgov-bus-data/settings`. There are no council-specific defaults: all values must be configured after installation.

| Key | Default | Description |
|---|---|---|
| `source.bulk_gtfs_url` | _(empty)_ | URL to a regional bulk GTFS ZIP from the BODS timetable download page |
| `source.boundary_geojson` | _(empty)_ | GeoJSON Polygon or MultiPolygon used to filter the feed to your area (takes precedence over bounding box) |
| `source.bounding_box` | _(empty)_ | N/S/E/W coordinates used to filter the national feed to your area |
| `source.enabled` | `false` | Enable to allow imports to run (cron and manual) |
| `import.schedule` | `0 3 * * *` | Cron expression for automatic daily import (supports `*` and exact integers only, not ranges or steps) |
| `import.log_retention` | `30` | Days to keep import log entries |
| `naptan.enabled` | `false` | Enable NaPTAN enrichment step |
| `naptan.url` | _(empty)_ | NaPTAN access-nodes CSV URL |
| `messages.bank_holiday_notice` | Bank holiday wording | Notice shown in the footer of the timetable, routes, stop detail, and stop search views |
| `messages.specific_dates_notice` | Specific dates wording | Notice shown above the weekday timetable when a route only runs on specific calendar dates |

### Front-end messages

The two notices above are edited under **Front-end messages** on the settings
form, not in the Views UI. Both accept the standard Drupal admin HTML tags and
are XSS filtered on output; leaving either empty hides that notice.

The bank holiday notice is rendered by the
`localgov_bus_data_bank_holiday_notice` Views area handler, so it can also be
added to the header, footer, or no-results area of any other view.

All four views render the same string. If a site reworded one view's footer
before upgrading, `localgov_bus_data_update_10009()` carries that wording to
the others and names them in the post-update message rather than changing them
silently. A display that overrides the footer keeps its own hardcoded text and
is reported for manual editing.

Translations do not survive the move. The bank holiday notice source string
moved out of `views.view.*`, and the specific dates notice moved out of a
`t()` call in code, so both need translating again against
`localgov_bus_data.settings` through config translation.

Both fields arrive pre-filled: the wording ships in `config/install`, and
`Drupal\localgov_bus_data\Utility\BusMessages` holds the same text in code as a
fallback, so a site whose saved settings predate the `messages` key still shows
the standard notices. Clearing a field is respected and hides that notice.

Note that these values are config. On a site that deploys config from a
repository, an edit made in the admin UI is reverted by the next
`drush config:import`, and so are the changes made by
`localgov_bus_data_update_10009()`. After running the update, export and commit
(`drush config:export`) before the next import, or make the equivalent edits in
your config repository. The update hook runs once, so a later import that
reverts it will not be re-applied automatically.

## Data source

This module is designed for use with the UK Department for Transport
[Bus Open Data Service (BODS)](https://data.bus-data.dft.gov.uk/timetable/download/).

Select the regional bulk GTFS ZIP for your area and paste the URL into the settings form.

Set the geographic filter to your council's area, either a GeoJSON polygon boundary (most accurate) or a bounding box. Stops outside the area are discarded after download; trips and stop times that no longer serve any in-area stop are also removed. Cross-boundary trips are retained in full.


## Importing timetable data

### Live import

Run an **incremental** import (add new records, update changed records, delete removed records) from the national bulk GTFS feed:

```bash
drush bus-times:import
```

Force a **full** truncate-and-reimport (same as the very first import):

```bash
drush bus-times:import --full
```

Or click **Import now** on the settings page (`/admin/config/localgov-bus-data/settings`).

The web UI button always performs a full truncate-and-reimport.

### Incremental import pipeline (default Drush/cron path)

1. Downloads the bulk GTFS ZIP from the configured URL
2. Extracts and filters stops/trips to the configured bounding box, and filters `shapes.txt` down to the shapes still referenced by the retained trips
3. Stages the filtered CSV files to `public://bus-times/gtfs/`
4. Runs all five Migrate migrations, so only new and changed rows are processed (`track_changes: true` in each migration YAML hashes source rows and skips unchanged ones). Shape points are not migrated: they are standalone geometry with no entity references, so they are inserted directly in chunks
5. Detects and removes deleted records: compares each staged CSV against the migrate map tables and deletes entity rows for source IDs that no longer appear in the feed
6. Writes an entry to the import log

#### Full import pipeline (`--full` flag or web UI)

Same pipeline but step 4 is preceded by a complete truncation of all entity and migrate map tables, ensuring a clean slate regardless of prior state.

### Scheduled imports (cron)

The module hooks into Drupal's standard cron. When cron fires, `hook_cron()` checks the configured schedule expression (default `0 3 * * *`, 3 am daily) and runs the import pipeline if the schedule matches.

> **Note:** The cron expression only supports `*` (any value) and exact integers in each field. Ranges (`1-5`), steps (`*/15`), and lists (`1,3,5`) are not supported.

**Cron import mode:**
- **Incremental** (default): runs on every matching cron fire
- **Full**: automatically triggered once per week (when more than 6 days have passed since the last full import, tracked in Drupal state as `localgov_bus_data.cron_last_full_import`)

This means routine daily cron runs are fast (only changed rows processed), while a weekly full re-import keeps the dataset clean and prevents map-table drift.

To run cron reliably in production, configure a server-level crontab entry:

```bash
# Example: run Drupal cron every 15 minutes
*/15 * * * * /path/to/drush --root=/path/to/drupal cron
```

The module's own import schedule controls *when within those cron fires* the import actually runs. It will be skipped on cron runs that don't match the expression. An overlapping-run guard (Drupal state key `localgov_bus_data.cron_last_run`, minimum 3 600 s gap) prevents a second import starting before the first has finished.

## Custom CSV data

Routes, stops, or other GTFS rows that are missing from the bulk feed (for
example a community transport service not registered with BODS) can be
supplemented by uploading your own CSV files. Configure this at
`/admin/config/localgov-bus-data/custom-data`.

Up to six files can be uploaded, one per GTFS entity:

| File | Required columns | Optional columns |
|---|---|---|
| Agency | `agency_id`, `agency_name` | |
| Routes | `route_id`, `route_short_name`, `agency_id`, `route_type` | `route_long_name` |
| Stops | `stop_id`, `stop_name`, `stop_lat`, `stop_lon` | `wheelchair_boarding` |
| Calendar | `service_id`, `monday`…`sunday`, `start_date`, `end_date` | |
| Trips | `trip_id`, `route_id`, `service_id` | `direction_id`, `trip_headsign` |
| Stop times | `trip_id`, `arrival_time`, `departure_time`, `stop_id`, `stop_sequence` | |

Blank example files with the correct headers are available to download from
the custom data form, or directly from `assets/templates/` in this module
(`agency.csv`, `routes.csv`, `stops.csv`, `calendar.csv`, `trips.csv`,
`stop_times.csv`).

Custom rows may reference either the current staged feed (e.g. a custom trip
using a real `route_id`) or another custom file in the same upload (e.g. a
custom trip using a custom `route_id`), but an ID must not already exist in
the staged feed: custom data supplements the feed, it does not override it.

**Validation is all-or-nothing.** If any row in any uploaded file fails
validation, the entire upload is rejected: nothing is saved, and a report
lists every failing file, line, column, and reason. This also applies at
import time: if previously-accepted custom data no longer reconciles
against a newer feed (for example a custom `stop_times` row referencing a
stop that has since been removed from the feed), the custom merge step is
skipped for that import. The import itself still completes successfully; the
import log and the custom data page both note that the merge was skipped.

Disabling **Enable custom data** on the form keeps the stored files and
configuration but skips the merge step at the next import, without deleting
anything.

## NaPTAN stop enrichment

After a timetable import, stop records can be enriched with NaPTAN data (indicator, street, and locality name). Enable this on the settings page under **NaPTAN Settings**, then click **Update stop details now**. Enrichment also runs automatically as the final step of each scheduled import when enabled.

The NaPTAN endpoint downloads the full GB access nodes CSV and matches stops by ATCO code.

No API key is required.

## Seed data (local development)

For local development with realistic data, use the seed command to insert fixture entities without running a live import:

```bash
drush bus-times:seed
```

This inserts 5 routes, 26 stops, 3 calendars, 40 trips, and ~200 stop times (Mon–Fri, Saturday, Sunday schedules). Safe to re-run. Useful immediately after enabling the module to try out the public pages and Views without a live download.


## Admin paths

**Settings and tools:**
- `/admin/config/localgov-bus-data/settings`: GTFS URL, bounding box, import schedule, display defaults, and NaPTAN enrichment settings
- `/admin/config/localgov-bus-data/import-log`: recent import run history

**Content (data browsing):**
- `/admin/content/bus-data`: landing page, redirects to Bus Stops
- Sub-tabs: Bus Routes, Bus Stops, Bus Calendars, Bus Trips, Bus Stop Times

**Structure (field management):**
- `/admin/structure/bus-data/stops`
- `/admin/structure/bus-data/routes`
- `/admin/structure/bus-data/calendars`
- `/admin/structure/bus-data/trips`
- `/admin/structure/bus-data/stop-times`


This module was sponsored by [Cumberland Council](https://www.cumberland.gov.uk) and contributed as part of the [LocalGov Drupal](https://localgovdrupal.org) initiative.
