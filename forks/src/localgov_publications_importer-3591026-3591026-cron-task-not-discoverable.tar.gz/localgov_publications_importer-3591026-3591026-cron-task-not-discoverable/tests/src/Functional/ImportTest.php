<?php

namespace Drupal\Tests\localgov_publications_importer\Functional;

use Drupal\localgov_publications_importer\Service\Importer;
use Drupal\node\NodeInterface;

/**
 * Tests the full import process via Importer::doImport().
 *
 * @group localgov_publications_importer
 */
class ImportTest extends FunctionalTestBase {

  use FileProviderTrait;

  /**
   * The importer service.
   *
   * @var \Drupal\localgov_publications_importer\Service\Importer
   */
  protected Importer $importer;

  /**
   * {@inheritdoc}
   */
  protected function setUp(): void {
    parent::setUp();
    $this->importer = $this->container->get(Importer::class);
  }

  /**
   * Tests the full import pipeline for each PDF in the test suite.
   *
   * @dataProvider fileProvider
   */
  public function testDoImport(string $fileName, string $title, int $pageCount): void {
    $import = $this->createImport($fileName);

    $node = $this->importer->doImport($import);

    $this->assertInstanceOf(NodeInterface::class, $node, "doImport() should return a publication node.");
    $this->assertEquals($title, $import->getTitle(), "The import title should be populated from the PDF.");
    $this->assertEquals($pageCount, count($import->getPages()), "The page count should match the PDF.");
    $this->assertEquals($import->getCreator()->id(), $node->getOwner()->id(), "The node owner should match the import creator.");
  }

}
