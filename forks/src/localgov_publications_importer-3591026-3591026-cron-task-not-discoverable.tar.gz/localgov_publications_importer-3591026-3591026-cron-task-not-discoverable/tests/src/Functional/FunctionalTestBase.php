<?php

namespace Drupal\Tests\localgov_publications_importer\Functional;

use Drupal\Tests\BrowserTestBase;

/**
 * Base class for functional tests.
 *
 * @group localgov_publications_importer
 */
abstract class FunctionalTestBase extends BrowserTestBase {

  /**
   * {@inheritdoc}
   */
  protected $defaultTheme = 'stark';

  /**
   * {@inheritdoc}
   */
  protected function setUp(): void {
    parent::setUp();
    $this->container->get('module_installer')->install(['localgov_media']);
    // We don't need localgov_core in a real install, but we install it for
    // testing to get the body field that we need.
    $this->container->get('module_installer')->install(['localgov_core']);
    $this->rebuildContainer();
    $this->container->get('module_installer')->install(['localgov_publications_importer']);
    $this->rebuildContainer();
  }

}
