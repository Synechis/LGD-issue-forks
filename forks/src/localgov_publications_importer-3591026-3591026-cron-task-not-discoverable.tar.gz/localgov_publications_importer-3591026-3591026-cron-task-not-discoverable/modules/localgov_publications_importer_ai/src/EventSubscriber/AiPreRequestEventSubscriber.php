<?php

namespace Drupal\localgov_publications_importer_ai\EventSubscriber;

use Drupal\ai\Event\PreGenerateResponseEvent;
use Drupal\ai\OperationType\Chat\ChatInput;
use Symfony\Component\EventDispatcher\EventSubscriberInterface;

/**
 * Subscribes to the Drupal\ai\Event\PreGenerateResponseEvent.
 */
class AiPreRequestEventSubscriber implements EventSubscriberInterface {

  /**
   * {@inheritdoc}
   */
  public static function getSubscribedEvents(): array {
    return [
      PreGenerateResponseEvent::EVENT_NAME => 'aiPreRequest',
    ];
  }

  /**
   * Alter the AI request configuration before it's sent.
   */
  public function aiPreRequest(PreGenerateResponseEvent $event): void {

    if ($event->getProviderId() !== 'bedrock') {
      return;
    }

    $configuration = $event->getConfiguration();
    $modelId = $event->getModelId();

    // Set model-specific max_tokens.
    if (str_contains($modelId, 'anthropic.claude')) {
      // Maximum permitted token limit for Claude models via AWS Bedrock.
      $configuration['maxTokens'] = 128000;
    }
    elseif (str_contains($modelId, 'moonshotai.kimi')) {
      // Maximum output token limit for Kimi models via AWS Bedrock is 262144.
      // If you try to set it to the maximum, you hit the context length limit.
      // Setting maxTokens to 128000 seems to work pretty well.
      $configuration['maxTokens'] = 128000;
    }

    // If the input has a single tool defined (set via setChatTools()), force
    // the model to use it. BedrockProvider reads tool_choice from configuration
    // before normalisation and adds it to toolConfig.toolChoice.
    $input = $event->getInput();
    if ($input instanceof ChatInput) {
      $tools = $input->getChatTools();
      if ($tools && count($tools->getFunctions()) === 1) {
        $names = array_keys($tools->getFunctions());
        $configuration['tool_choice'] = ['tool' => ['name' => $names[0]]];
      }
    }

    $event->setConfiguration($configuration);
  }

}
