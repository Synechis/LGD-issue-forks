<?php

namespace Drupal\localgov_publications_importer_ai\Tool;

use Drupal\ai\OperationType\Chat\Tools\ToolsFunctionInput;

/**
 * Tool definition for the format_pages structured output tool.
 *
 * Define a JSON schema for splitting a document into publication pages.
 */
class FormatPagesTool extends ToolsFunctionInput {

  /**
   * {@inheritdoc}
   */
  public function getName(): string {
    return 'format_pages';
  }

  /**
   * {@inheritdoc}
   */
  public function renderFunctionArray(): array {
    return [
      'name' => 'format_pages',
      'description' => 'Format the document content into structured pages.',
      'parameters' => [
        'type' => 'object',
        'properties' => [
          'pages' => [
            'type' => 'array',
            'items' => [
              'type' => 'object',
              'properties' => [
                'title' => [
                  'type' => 'string',
                  'description' => 'Descriptive title reflecting the page\'s main topic.',
                ],
                'content' => [
                  'type' => 'string',
                  'description' => 'HTML content using only h1, h2, h3, h4, h5, h6, p, ul, ol, li, img tags.',
                ],
              ],
              'required' => ['title', 'content'],
            ],
          ],
        ],
        'required' => ['pages'],
      ],
    ];
  }

}
