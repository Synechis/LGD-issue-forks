<?php

namespace Drupal\localgov_services\Hook;

use Drupal\Core\Hook\Attribute\Hook;

/**
 * Hook implementations for localgov_services.
 */
class LocalgovServicesHooks {
  /**
   * @file
   * LocalGovDrupal Services: Core module file.
   */

  /**
   * Implements hook_theme().
   */
  #[Hook('theme')]
  public function theme() {
    return [
      'services_cta_block' => [
        'variables' => [
          'buttons' => [],
        ],
        'render element' => 'block',
      ],
    ];
  }

}
