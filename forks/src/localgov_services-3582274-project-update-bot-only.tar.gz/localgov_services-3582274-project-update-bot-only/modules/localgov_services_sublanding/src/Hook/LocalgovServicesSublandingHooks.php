<?php

namespace Drupal\localgov_services_sublanding\Hook;

use Drupal\localgov_roles\RolesHelper;
use Drupal\Core\Hook\Attribute\Hook;

/**
 * Hook implementations for localgov_services_sublanding.
 */
class LocalgovServicesSublandingHooks {

  /**
   * Implements hook_theme().
   */
  #[Hook('theme')]
  public function theme($existing, $type, $theme, $path) {
    return [
      'dummy_teaser' => [
        'render element' => 'element',
        'variables' => [
          'title' => '',
          'url' => '',
        ],
      ],
      'field__paragraph__topic_list_links__topic_list_builder' => [
        'template' => 'field--paragraph--topic-list-links--topic-list-builder',
        'base hook' => 'field',
      ],
      'paragraph__topic_list_builder' => [
        'template' => 'paragraph--topic-list-builder',
        'base hook' => 'paragraph',
      ],
    ];
  }

  /**
   * Implements hook_localgov_roles_default().
   */
  #[Hook('localgov_roles_default')]
  public function localgovRolesDefault(): array {
    // Content editing permissions.
    $perms = [
      RolesHelper::EDITOR_ROLE => [
        'create localgov_services_sublanding content',
        'delete any localgov_services_sublanding content',
        'delete localgov_services_sublanding revisions',
        'delete own localgov_services_sublanding content',
        'edit any localgov_services_sublanding content',
        'edit own localgov_services_sublanding content',
        'revert localgov_services_sublanding revisions',
        'view localgov_services_sublanding revisions',
      ],
      RolesHelper::AUTHOR_ROLE => [
        'create localgov_services_sublanding content',
        'delete own localgov_services_sublanding content',
        'edit own localgov_services_sublanding content',
        'revert localgov_services_sublanding revisions',
        'view localgov_services_sublanding revisions',
      ],
      RolesHelper::CONTRIBUTOR_ROLE => [
        'create localgov_services_sublanding content',
        'delete own localgov_services_sublanding content',
        'edit own localgov_services_sublanding content',
        'view localgov_services_sublanding revisions',
      ],
    ];
    // Content scheduling permissions required by localgov_workflows.
    if (\Drupal::moduleHandler()->moduleExists('localgov_workflows')) {
      $perms[RolesHelper::EDITOR_ROLE] = array_merge($perms[RolesHelper::EDITOR_ROLE], [
        'add scheduled transitions node localgov_services_sublanding',
        'reschedule scheduled transitions node localgov_services_sublanding',
        'view scheduled transitions node localgov_services_sublanding',
      ]);
      $perms[RolesHelper::AUTHOR_ROLE] = array_merge($perms[RolesHelper::AUTHOR_ROLE], [
        'add scheduled transitions node localgov_services_sublanding',
        'reschedule scheduled transitions node localgov_services_sublanding',
        'view scheduled transitions node localgov_services_sublanding',
      ]);
      $perms[RolesHelper::CONTRIBUTOR_ROLE] = array_merge($perms[RolesHelper::CONTRIBUTOR_ROLE], [
        'add scheduled transitions node localgov_services_sublanding',
        'reschedule scheduled transitions node localgov_services_sublanding',
        'view scheduled transitions node localgov_services_sublanding',
      ]);
    }
    return $perms;
  }

  /**
   * Implements hook_preprocess_HOOK().
   */
  #[Hook('preprocess_paragraph__topic_list_builder')]
  public function preprocessParagraphTopicListBuilder(&$variables) {
    /** @var \Drupal\paragraphs\Entity\Paragraph $paragraph */
    $paragraph = $variables['paragraph'];
    // We only show the 'More' button if there are more items to show. To
    // calculate this. We count how many items we're showing in this paragraph,
    // then count how many nodes the term has to show. If there are more items
    // in the paragraph then items we're showing, we display the 'More' button.
    if (!$paragraph->get('topic_list_term')->isEmpty()) {
      $topic_tid = $paragraph->get('topic_list_term')->first()->getValue()['target_id'];
      $nodes_in_term = localgov_services_sublanding_count_nodes_with_taxonomy($topic_tid);
      // Count how many nodes this paragraph has.
      $nodes_in_paragraph = $paragraph->get('topic_list_links')->count();
      $variables['show_more'] = $nodes_in_term > $nodes_in_paragraph;
      $variables['show_more_path'] = \Drupal::service('path_alias.manager')->getAliasByPath('/taxonomy/term/' . $topic_tid);
    }
    // The header text is set by default to the topic entity label but can be
    // overwritten by the topic_list_header field.
    if (!$paragraph->get('topic_list_header')->isEmpty()) {
      $variables['header'] = $paragraph->get('topic_list_header')->first()->getValue()['value'];
    }
    elseif (!$paragraph->get('topic_list_term')->isEmpty()) {
      $topic = $paragraph->get('topic_list_term')->entity;
      $variables['header'] = $topic?->label();
    }
  }

}
