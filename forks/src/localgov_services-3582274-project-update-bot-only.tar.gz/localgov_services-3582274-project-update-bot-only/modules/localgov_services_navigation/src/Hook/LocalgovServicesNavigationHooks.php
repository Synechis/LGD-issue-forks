<?php

namespace Drupal\localgov_services_navigation\Hook;

use Drupal\field\Entity\FieldConfig;
use Drupal\field\FieldConfigInterface;
use Drupal\localgov_services_navigation\EntityChildRelationshipUi;
use Drupal\Core\Entity\ContentEntityInterface;
use Drupal\pathauto\Entity\PathautoPattern;
use Drupal\Core\Form\FormStateInterface;
use Drupal\Core\Hook\Attribute\Hook;

/**
 * Hook implementations for localgov_services_navigation.
 */
class LocalgovServicesNavigationHooks {

  /**
   * Implements hook_theme().
   */
  #[Hook('theme')]
  public function theme() {
    return [
      'localgov_services_navigation_children' => [
        'children' => 'render_element',
      ],
      'localgov_services_navigation_child' => [
        'variables' => [
          'title' => '',
          'type' => '',
          'url' => '',
          'topics' => [],
          'id' => '',
        ],
      ],
    ];
  }

  /**
   * Implements hook_preprocess_HOOK().
   */
  #[Hook('preprocess_localgov_services_navigation_child', module: 'template')]
  public function templatePreprocessLocalgovServicesNavigationChild(&$variables) {
    $variables['reference'] = $variables['title'] . ' (' . $variables['id'] . ')';
    $variables['topics_list'] = implode(', ', $variables['topics']);
  }

  /**
   * Implements hook_field_widget_single_element_WIDGET_TYPE_form_alter().
   */
  #[Hook('field_widget_single_element_entity_reference_autocomplete_form_alter')]
  public function fieldWidgetSingleElementEntityReferenceAutocompleteFormAlter(&$element, FormStateInterface $form_state, $context) {
    if (!empty($element['target_id']) && $element['target_id']['#selection_handler'] == 'localgov_services') {
      $element['target_id']['#value_callback'] = [
        'Drupal\localgov_services_navigation\EntityReferenceValue',
        'valueCallback',
      ];
    }
  }

  /**
   * Implements hook_pathauto_pattern_alter().
   */
  #[Hook('pathauto_pattern_alter')]
  public function pathautoPatternAlter(PathautoPattern $pattern, array $context) {
    // If pathauto isn't set to include this entity into services hierarchy, but
    // it has opt-ed in with the field add the (optional) parent to the path.
    $entity = reset($context['data']);
    assert($entity instanceof ContentEntityInterface);
    if ($entity->hasField('localgov_services_parent') && strpos($pattern->getPattern(), '[node:localgov_services_parent:entity:url:path]') === FALSE) {
      $pattern->setPattern('[node:localgov_services_parent:entity:url:path]/' . $pattern->getPattern());
    }
  }

  /**
   * Implements hook_entity_extra_field_info().
   */
  #[Hook('entity_extra_field_info')]
  public function entityExtraFieldInfo() {
    return \Drupal::service('class_resolver')->getInstanceFromDefinition(EntityChildRelationshipUi::class)->entityExtraFieldInfo();
  }

  /**
   * Implements hook_form_alter().
   */
  #[Hook('form_alter')]
  public function formAlter(array &$form, FormStateInterface $form_state, $form_id) {
    return \Drupal::service('class_resolver')->getInstanceFromDefinition(EntityChildRelationshipUi::class)->formAlter($form, $form_state, $form_id);
  }

  /**
   * Implements hook_ENTITY_TYPE_insert().
   */
  #[Hook('field_config_insert')]
  public function fieldConfigInsert(FieldConfigInterface $field) {
    if ($field->getName() == 'localgov_services_parent' && $field->getTargetEntityTypeId() == 'node' && $destinations = FieldConfig::loadByName('node', 'localgov_services_landing', 'localgov_destinations')) {
      $settings = $destinations->getSetting('handler_settings');
      $settings['target_bundles'][$field->getTargetBundle()] = $field->getTargetBundle();
      $destinations->setSetting('handler_settings', $settings);
      $destinations->save();
    }
  }

  /**
   * Implements hook_ENTITY_TYPE_delete().
   */
  #[Hook('field_config_delete')]
  public function fieldConfigDelete(FieldConfigInterface $field) {
    if ($field->getName() == 'localgov_services_parent' && $field->getTargetEntityTypeId() == 'node' && $destinations = FieldConfig::loadByName('node', 'localgov_services_landing', 'localgov_destinations')) {
      $settings = $destinations->getSetting('handler_settings');
      unset($settings['target_bundles'][$field->getTargetBundle()]);
      $destinations->setSetting('handler_settings', $settings);
      $destinations->save();
    }
  }

}
