<?php

namespace Drupal\localgov_services_page\Hook;

use Drupal\localgov_roles\RolesHelper;
use Drupal\Core\Hook\Attribute\Hook;

/**
 * Hook implementations for localgov_services_page.
 */
class LocalgovServicesPageHooks {

  /**
   * Implements hook_theme().
   */
  #[Hook('theme')]
  public function theme() {
    return [
      'services_related_links_block' => [
        'variables' => [
          'links' => [],
        ],
        'render element' => 'block',
      ],
      'services_related_topics_block' => [
        'variables' => [
          'links' => [],
        ],
        'render element' => 'block',
      ],
    ];
  }

  /**
   * Implements hook_localgov_roles_default().
   */
  #[Hook('localgov_roles_default')]
  public function localgovRolesDefault(): array {
    // Content editing permissions.
    $perms = [
      RolesHelper::EDITOR_ROLE => [
        'create localgov_services_page content',
        'delete any localgov_services_page content',
        'delete localgov_services_page revisions',
        'delete own localgov_services_page content',
        'edit any localgov_services_page content',
        'edit own localgov_services_page content',
        'revert localgov_services_page revisions',
        'view localgov_services_page revisions',
      ],
      RolesHelper::AUTHOR_ROLE => [
        'create localgov_services_page content',
        'delete own localgov_services_page content',
        'edit own localgov_services_page content',
        'revert localgov_services_page revisions',
        'view localgov_services_page revisions',
      ],
      RolesHelper::CONTRIBUTOR_ROLE => [
        'create localgov_services_page content',
        'delete own localgov_services_page content',
        'edit own localgov_services_page content',
        'view localgov_services_page revisions',
      ],
    ];
    // Content scheduling permissions required by localgov_workflows.
    if (\Drupal::moduleHandler()->moduleExists('localgov_workflows')) {
      $perms[RolesHelper::EDITOR_ROLE] = array_merge($perms[RolesHelper::EDITOR_ROLE], [
        'add scheduled transitions node localgov_services_page',
        'reschedule scheduled transitions node localgov_services_page',
        'view scheduled transitions node localgov_services_page',
      ]);
      $perms[RolesHelper::AUTHOR_ROLE] = array_merge($perms[RolesHelper::AUTHOR_ROLE], [
        'add scheduled transitions node localgov_services_page',
        'reschedule scheduled transitions node localgov_services_page',
        'view scheduled transitions node localgov_services_page',
      ]);
      $perms[RolesHelper::CONTRIBUTOR_ROLE] = array_merge($perms[RolesHelper::CONTRIBUTOR_ROLE], [
        'add scheduled transitions node localgov_services_page',
        'reschedule scheduled transitions node localgov_services_page',
        'view scheduled transitions node localgov_services_page',
      ]);
    }
    return $perms;
  }

}
