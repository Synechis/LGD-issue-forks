<?php

namespace Drupal\localgov_services_landing\Hook;

use Drupal\localgov_roles\RolesHelper;
use Drupal\Core\Hook\Attribute\Hook;

/**
 * Hook implementations for localgov_services_landing.
 */
class LocalgovServicesLandingHooks {

  /**
   * Implements hook_theme().
   */
  #[Hook('theme')]
  public function theme($existing, $type, $theme, $path) {
    return [
      'node__localgov_services_landing__full' => [
        'template' => 'node--localgov-services-landing--full',
        'base hook' => 'node',
      ],
      'taxonomy_vertical_list' => [
        'template' => 'taxonomy-vertical-list',
        'variables' => [
          'title' => '',
          'items' => [],
        ],
      ],
    ];
  }

  /**
   * Implements hook_localgov_roles_default().
   */
  #[Hook('localgov_roles_default')]
  public function localgovRolesDefault(): array {
    // Content editing permissions.
    $perms = [
      RolesHelper::EDITOR_ROLE => [
        'create localgov_services_landing content',
        'delete any localgov_services_landing content',
        'delete localgov_services_landing revisions',
        'delete own localgov_services_landing content',
        'edit any localgov_services_landing content',
        'edit own localgov_services_landing content',
        'revert localgov_services_landing revisions',
        'view localgov_services_landing revisions',
      ],
      RolesHelper::AUTHOR_ROLE => [
        'create localgov_services_landing content',
        'delete own localgov_services_landing content',
        'edit own localgov_services_landing content',
        'revert localgov_services_landing revisions',
        'view localgov_services_landing revisions',
      ],
      RolesHelper::CONTRIBUTOR_ROLE => [
        'create localgov_services_landing content',
        'delete own localgov_services_landing content',
        'edit own localgov_services_landing content',
        'view localgov_services_landing revisions',
      ],
    ];
    // Content scheduling permissions required by localgov_workflows.
    if (\Drupal::moduleHandler()->moduleExists('localgov_workflows')) {
      $perms[RolesHelper::EDITOR_ROLE] = array_merge($perms[RolesHelper::EDITOR_ROLE], [
        'add scheduled transitions node localgov_services_landing',
        'reschedule scheduled transitions node localgov_services_landing',
        'view scheduled transitions node localgov_services_landing',
      ]);
      $perms[RolesHelper::AUTHOR_ROLE] = array_merge($perms[RolesHelper::AUTHOR_ROLE], [
        'add scheduled transitions node localgov_services_landing',
        'reschedule scheduled transitions node localgov_services_landing',
        'view scheduled transitions node localgov_services_landing',
      ]);
      $perms[RolesHelper::CONTRIBUTOR_ROLE] = array_merge($perms[RolesHelper::CONTRIBUTOR_ROLE], [
        'add scheduled transitions node localgov_services_landing',
        'reschedule scheduled transitions node localgov_services_landing',
        'view scheduled transitions node localgov_services_landing',
      ]);
    }
    return $perms;
  }

}
