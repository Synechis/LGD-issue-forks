<?php

declare(strict_types=1);

namespace Drupal\Tests\content_access_by_path\Functional;

use Drupal\node\Entity\NodeType;
use Drupal\taxonomy\Entity\Vocabulary;
use Drupal\taxonomy\VocabularyInterface;
use Drupal\Tests\BrowserTestBase;
use Drupal\Tests\taxonomy\Traits\TaxonomyTestTrait;
use Drupal\Tests\user\Traits\UserCreationTrait;
use PHPUnit\Framework\Attributes\RunTestsInSeparateProcesses;
use Symfony\Component\HttpFoundation\Response;

/**
 * Tests content access by path behavior.
 */
#[RunTestsInSeparateProcesses]
class ContentAccessTest extends BrowserTestBase {

  use TaxonomyTestTrait;
  use UserCreationTrait;

  /**
   * {@inheritdoc}
   */
  public $defaultTheme = 'stark';

  /**
   * {@inheritdoc}
   */
  public $strictConfigSchema = FALSE;

  /**
   * Modules to enable for this test.
   *
   * @var array<string>
   */
  protected static $modules = [
    // Core.
    'node',
    'path',
    'taxonomy',

    // Contrib.
    'content_access_by_path',
  ];

  /**
   * Vocabulary used to store section paths.
   */
  private VocabularyInterface $vocabulary;

  /**
   * {@inheritdoc}
   */
  public function setUp(): void {
    parent::setUp();

    NodeType::create(['type' => 'article', 'name' => 'Article'])->save();
    NodeType::create(['type' => 'page', 'name' => 'Basic page'])->save();

    $this->vocabulary = Vocabulary::load('content_access_by_path');
  }

  /**
   * Ensures path access does not bypass node-type permissions.
   */
  public function testPathAccessDoesNotBypassNodeTypeEditPermissions(): void {
    $siteSection = $this->createTerm($this->vocabulary, [
      'content_access_by_path' => ['/example'],
      'name' => 'Example',
    ]);

    $user = $this->createUser(
      ['edit any article content'],
      NULL,
      FALSE,
      ['content_access_by_path' => [$siteSection]],
    );

    $this->createNode([
      'title' => 'An article in /example',
      'path' => '/example/article',
      'type' => 'article',
    ]);

    $this->createNode([
      'title' => 'A basic page in /example',
      'path' => '/example/page',
      'type' => 'page',
    ]);

    $this->drupalLogin($user);

    $this->drupalGet('node/1/edit');
    $this->assertSession()->statusCodeEquals(Response::HTTP_OK);

    $this->drupalGet('node/2/edit');
    $this->assertSession()->statusCodeEquals(Response::HTTP_FORBIDDEN);
  }

  /**
   * Ensures users with the news section term can edit news content.
   */
  public function testUsersWithTheNewsSiteSectionTermCanEditNodesWithinTheNewsSection(): void {
    $siteSection = $this->createTerm($this->vocabulary, [
      'content_access_by_path' => ['/news'],
      'name' => 'News',
    ]);

    $user = $this->createUser(
      [
        'access administration pages',
        'administer nodes',
        'edit any article content',
      ],
      NULL,
      FALSE,
      ['content_access_by_path' => $siteSection],
    );

    $this->createNode([
      'title' => 'A news article',
      'path' => '/news/something',
      'type' => 'article',
    ]);

    $this->drupalLogin($user);

    $this->drupalGet('node/1/edit');
    $this->assertSession()->statusCodeEquals(Response::HTTP_OK);
  }

  /**
   * Ensures users with no section terms can still edit news content.
   */
  public function testUsersWithNoSiteSectionTermsCanEditNodesWithinTheNewsSection(): void {
    $siteSection = $this->createTerm($this->vocabulary, [
      'content_access_by_path' => ['/news'],
      'name' => 'News',
    ]);

    $user = $this->createUser(
      ['access administration pages', 'administer nodes', 'edit any article content'],
      NULL,
      FALSE,
      ['content_access_by_path' => []],
    );

    $this->createNode([
      'title' => 'A news article',
      'path' => '/news/something',
      'type' => 'article',
    ]);

    $this->drupalLogin($user);

    $this->drupalGet('node/1/edit');
    $this->assertSession()->statusCodeEquals(Response::HTTP_OK);
  }

  /**
   * Ensures users without the news term cannot edit news content.
   */
  public function testUsersWithoutTheNewsSiteSectionTermCanNotEditNodesWithinTheNewsSection(): void {
    $siteSectionA = $this->createTerm($this->vocabulary, [
      'content_access_by_path' => ['/news'],
      'name' => 'News',
    ]);

    $siteSectionB = $this->createTerm($this->vocabulary, [
      'content_access_by_path' => ['/blog'],
      'name' => 'Banana',
    ]);

    $user = $this->createUser(
      ['access administration pages', 'administer nodes', 'edit any article content'],
      NULL,
      FALSE,
      ['content_access_by_path' => [$siteSectionB]],
    );

    $this->createNode([
      'title' => 'A news article',
      'path' => '/news/something',
      'type' => 'article',
    ]);

    $this->drupalLogin($user);

    $this->drupalGet('node/1/edit');
    $this->assertSession()->statusCodeEquals(Response::HTTP_FORBIDDEN);
  }

  /**
   * Ensures users can edit nodes in assigned sections.
   */
  public function testUsersCanEditNodesWithinSubSection(): void {
    $siteSectionA = $this->createTerm($this->vocabulary, [
      'content_access_by_path' => ['/news'],
      'name' => 'News',
    ]);

    $siteSectionB = $this->createTerm($this->vocabulary, [
      'content_access_by_path' => ['/blog'],
      'name' => 'Sports',
    ]);

    $user = $this->createUser(
      ['access administration pages', 'administer nodes', 'edit any article content'],
      NULL,
      FALSE,
      ['content_access_by_path' => [$siteSectionA, $siteSectionB]],
    );

    $this->createNode([
      'title' => 'A news article',
      'path' => '/news/something',
      'type' => 'article',
    ]);

    $this->createNode([
      'title' => 'A blog post',
      'path' => '/blog/something-else',
      'type' => 'article',
    ]);

    $this->drupalLogin($user);

    $this->drupalGet('node/1/edit');
    $this->assertSession()->statusCodeEquals(Response::HTTP_OK);

    $this->drupalGet('node/2/edit');
    $this->assertSession()->statusCodeEquals(Response::HTTP_OK);
  }

  /**
   * Ensures child-section users cannot edit parent-section content.
   */
  public function testUsersCanNotEditNodesIfTheyAreAssignedTheParentSection(): void {
    $siteSectionA = $this->createTerm($this->vocabulary, [
      'content_access_by_path' => ['/news'],
      'name' => 'News',
    ]);

    $siteSectionB = $this->createTerm($this->vocabulary, [
      'content_access_by_path' => ['/news/sports'],
      'name' => 'Sports',
    ]);

    $user = $this->createUser(
      ['access administration pages', 'administer nodes', 'edit any article content'],
      NULL,
      FALSE,
      ['content_access_by_path' => [$siteSectionB]],
    );

    $this->createNode([
      'title' => 'A news article',
      'path' => '/news/something',
      'type' => 'article',
    ]);

    $this->drupalLogin($user);

    $this->drupalGet('node/1/edit');
    $this->assertSession()->statusCodeEquals(Response::HTTP_FORBIDDEN);
  }

  /**
   * Ensures users in nested sections do not inherit parent-section access.
   */
  public function testUsersCanEditNodesIfTheyAreInMultipleSections(): void {
    $siteSectionA = $this->createTerm($this->vocabulary, [
      'content_access_by_path' => ['/news'],
      'name' => 'News',
    ]);

    $siteSectionB = $this->createTerm($this->vocabulary, [
      'content_access_by_path' => ['/news/sports'],
      'name' => 'Sports',
    ]);

    $user = $this->createUser(
      ['access administration pages', 'administer nodes', 'edit any article content'],
      NULL,
      FALSE,
      ['content_access_by_path' => [$siteSectionB]],
    );

    $this->createNode([
      'title' => 'A news article',
      'path' => '/news/something',
      'type' => 'article',
    ]);

    $this->drupalLogin($user);

    $this->drupalGet('node/1/edit');
    $this->assertSession()->statusCodeEquals(Response::HTTP_FORBIDDEN);
  }

}
