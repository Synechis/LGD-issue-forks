<?php

declare(strict_types=1);

namespace Drupal\localgov_microsites_group\EventSubscriber;

use Drupal\domain\DomainNegotiatorInterface;
use Drupal\layout_paragraphs\Event\LayoutParagraphsAllowedTypesEvent;
use Drupal\localgov_microsites_group\Plugin\DomainGroupSettingsManager;
use Symfony\Component\EventDispatcher\EventSubscriberInterface;

/**
 * Restricts Layout Paragraphs modal choices by microsite settings.
 */
final class LayoutParagraphsAllowedTypesSubscriber implements EventSubscriberInterface {

  /**
   * Constructs a new subscriber.
   *
   * @param \Drupal\domain\DomainNegotiatorInterface $domain_negotiator
   *   The domain negotiator.
   * @param \Drupal\localgov_microsites_group\Plugin\DomainGroupSettingsManager $domain_group_settings_manager
   *   The domain group settings plugin manager.
   */
  public function __construct(
    private readonly DomainNegotiatorInterface $domainNegotiator,
    private readonly DomainGroupSettingsManager $domainGroupSettingsManager,
  ) {}

  /**
   * {@inheritdoc}
   */
  public static function getSubscribedEvents(): array {
    return [
      LayoutParagraphsAllowedTypesEvent::EVENT_NAME => 'restrictTypes',
    ];
  }

  /**
   * Filters allowed component types for the Layout Paragraphs chooser modal.
   *
   * @param \Drupal\layout_paragraphs\Event\LayoutParagraphsAllowedTypesEvent $event
   *   The allowed types event.
   */
  public function restrictTypes(LayoutParagraphsAllowedTypesEvent $event): void {
    $domain = $this->domainNegotiator->getActiveDomain();
    if ($domain === NULL) {
      return;
    }

    $plugin = $this->domainGroupSettingsManager->createInstance('microsites_paragraph_types');
    $restriction = $plugin->getRestrictionForDomain($domain);
    if ($restriction === NULL) {
      return;
    }

    $typesFlip = array_flip($restriction['types']);
    $negate = $restriction['negate'];

    $filteredTypes = array_filter(
      $event->getTypes(),
      static function (array $type) use ($typesFlip, $negate): bool {
        $inList = isset($typesFlip[$type['id']]);
        return $negate ? !$inList : $inList;
      }
    );

    $event->setTypes($filteredTypes);
  }

}
