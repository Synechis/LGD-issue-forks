<?php

declare(strict_types=1);

namespace Drupal\localgov_microsites_group\Plugin\DomainGroupSettings;

use Drupal\Core\Config\Config;
use Drupal\Core\Config\ConfigFactoryInterface;
use Drupal\Core\Entity\EntityTypeBundleInfoInterface;
use Drupal\Core\Form\FormStateInterface;
use Drupal\Core\Language\LanguageManagerInterface;
use Drupal\Core\Plugin\ContainerFactoryPluginInterface;
use Drupal\Core\Session\AccountInterface;
use Drupal\Core\StringTranslation\StringTranslationTrait;
use Drupal\domain\DomainInterface;
use Drupal\group\Access\GroupAccessResult;
use Drupal\group\Entity\GroupInterface;
use Drupal\localgov_microsites_group\DomainFromGroupTrait;
use Drupal\localgov_microsites_group\Plugin\DomainGroupSettingsBase;
use Symfony\Component\DependencyInjection\ContainerInterface;

/**
 * Per-microsite paragraph type restrictions.
 *
 * @DomainGroupSettings(
 *   id = "microsites_paragraph_types",
 *   label = @Translation("Paragraph types"),
 * )
 */
class ParagraphTypeSettings extends DomainGroupSettingsBase implements ContainerFactoryPluginInterface {

  use StringTranslationTrait;
  use DomainFromGroupTrait;

  /**
   * Config ID used to store the allowed paragraph types per domain.
   */
  public const CONFIG_ID = 'localgov_microsites_group.paragraph_types';

  /**
   * Constructs a new ParagraphTypeSettings object.
   */
  public function __construct(
    array $configuration,
    $plugin_id,
    $plugin_definition,
    protected ConfigFactoryInterface $configFactory,
    protected LanguageManagerInterface $languageManager,
    protected EntityTypeBundleInfoInterface $bundleInfo,
  ) {
    parent::__construct($configuration, $plugin_id, $plugin_definition);
  }

  /**
   * {@inheritdoc}
   */
  public static function create(ContainerInterface $container, array $configuration, $plugin_id, $plugin_definition) {
    return new static(
      $configuration,
      $plugin_id,
      $plugin_definition,
      $container->get('config.factory'),
      $container->get('language_manager'),
      $container->get('entity_type.bundle.info'),
    );
  }

  /**
   * {@inheritdoc}
   */
  public function access(GroupInterface $group, AccountInterface $account) {
    return GroupAccessResult::allowedIfHasGroupPermission($group, $account, 'administer group domain settings');
  }

  /**
   * {@inheritdoc}
   */
  public function buildConfigurationForm(array $form, FormStateInterface $form_state, GroupInterface $group): array {
    $saved_types = [];
    $saved_negate = FALSE;
    if (!$group->isNew() && $domain = $this->getDomainFromGroup($group)) {
      $config = $this->loadConfigOverride($domain);
      if (!$config->isNew()) {
        $saved_types = $config->get('types') ?? [];
        $saved_negate = (bool) ($config->get('negate') ?? FALSE);
      }
    }

    // Build a list of all paragraph bundles.
    $bundles = $this->bundleInfo->getBundleInfo('paragraph');
    $options = [];
    foreach ($bundles as $machine_name => $info) {
      $options[$machine_name] = $info['label'];
    }
    asort($options);

    $form['description'] = [
      '#type' => 'markup',
      '#markup' => '<p>' . $this->t('If no types are checked, all types are available.') . '</p>',
    ];

    $form['negate'] = [
      '#type' => 'radios',
      '#title' => $this->t('Selection mode'),
      '#options' => [
        0 => $this->t('Allow only the selected types'),
        1 => $this->t('Allow all types <em>except</em> the selected types'),
      ],
      '#default_value' => (int) $saved_negate,
    ];

    $form['types'] = [
      '#type' => 'checkboxes',
      '#title' => $this->t('Paragraph types'),
      '#options' => $options,
      '#default_value' => $saved_types,
    ];

    return $form;
  }

  /**
   * {@inheritdoc}
   */
  public function validateConfigurationForm(array &$form, FormStateInterface $form_state) {
  }

  /**
   * {@inheritdoc}
   */
  public function submitConfigurationForm(array &$form, FormStateInterface $form_state): void {
    $group = $form_state->get('group');
    $domain = $this->getDomainFromGroup($group);
    if (!$domain) {
      return;
    }

    $config = $this->loadConfigOverride($domain);
    $checked = array_filter($form_state->getValue('types'));
    $config->set('types', array_values(array_keys($checked)));
    $config->set('negate', (bool) $form_state->getValue('negate'));
    $config->save();
  }

  /**
   * Loads the domain config override for this plugin.
   *
   * @param \Drupal\domain\DomainInterface $domain
   *   The domain whose configuration should be loaded.
   *
   * @return \Drupal\Core\Config\Config
   *   The editable domain override config object.
   */
  private function loadConfigOverride(DomainInterface $domain): Config {
    $config_id = 'domain.config.' . $domain->id() . '.' . self::CONFIG_ID;
    return $this->configFactory->getEditable($config_id);
  }

  /**
   * Returns the configured type restriction for a domain.
   *
   * @param \Drupal\domain\DomainInterface $domain
   *   The domain whose paragraph restriction configuration should be loaded.
   *
   * @return array{types: string[], negate: bool}|null
   *   The configured restriction array, or NULL if no restriction is set.
   */
  public function getRestrictionForDomain(DomainInterface $domain): ?array {
    $config = $this->loadConfigOverride($domain);
    if ($config->isNew()) {
      return NULL;
    }
    $types = $config->get('types');
    if (!is_array($types) || empty($types)) {
      return NULL;
    }
    return [
      'types' => $types,
      'negate' => (bool) ($config->get('negate') ?? FALSE),
    ];
  }

}
