<?php

declare(strict_types=1);

namespace Drupal\finders_facets\Plugin\facets\processor;

use Drupal\Core\Entity\EntityTypeManagerInterface;
use Drupal\Core\Plugin\ContainerFactoryPluginInterface;
use Drupal\Core\Routing\RouteMatchInterface;
use Drupal\facets\FacetInterface;
use Drupal\facets\Processor\BuildProcessorInterface;
use Drupal\facets\Processor\ProcessorPluginBase;
use Drupal\facets\Result\ResultInterface;
use Drupal\finders_facets\Facets\FacetPluginSupportsTrait;
use Drupal\finders_facets\Hook\FindersHooks;
use Drupal\node\NodeInterface;
use Symfony\Component\DependencyInjection\ContainerInterface;

/**
 * Removes finders facets that not present in the current Finder channel.
 *
 * This has a very low weight to save other processors in the build stage the
 * bother of working with results that are going to be removed.
 *
 * @FacetsProcessor(
 *   id = "finders_facets_channel_filter",
 *   label = @Translation("Finder channel filter"),
 *   description = @Translation("Remove facets not present in the current Finder channel."),
 *   stages = {
 *     "build" = -50,
 *   }
 * )
 */
class FindersFacetsChannelFilter extends ProcessorPluginBase implements BuildProcessorInterface, ContainerFactoryPluginInterface {

  use FacetPluginSupportsTrait;

  /**
   * {@inheritdoc}
   */
  public static function create(ContainerInterface $container, array $configuration, $plugin_id, $plugin_definition) {
    return new static(
      $configuration,
      $plugin_id,
      $plugin_definition,
      $container->get('entity_type.manager'),
      $container->get('current_route_match'),
    );
  }

  /**
   * Creates a FindersFacetsChannelFilter instance.
   *
   * @param array $configuration
   *   A configuration array containing information about the plugin instance.
   * @param string $plugin_id
   *   The plugin_id for the plugin instance.
   * @param mixed $plugin_definition
   *   The plugin implementation definition.
   * @param \Drupal\Core\Entity\EntityTypeManagerInterface $entityTypeManager
   *   The entity type manager.
   * @param \Drupal\Core\Routing\RouteMatchInterface $currentRouteMatch
   *   The currently active route match object.
   */
  public function __construct(
    array $configuration,
    $plugin_id,
    $plugin_definition,
    protected EntityTypeManagerInterface $entityTypeManager,
    protected RouteMatchInterface $currentRouteMatch,
  ) {
    parent::__construct($configuration, $plugin_id, $plugin_definition);
  }

  /**
   * {@inheritdoc}
   */
  public function build(FacetInterface $facet, array $results) {
    $facet_storage = $this->entityTypeManager->getStorage('finders_facet');

    // Load the finders facet entities.
    $finders_facet_ids = array_map(fn (ResultInterface $result) => $result->getRawValue(), $results);
    $finders_facets = $facet_storage->loadMultiple($finders_facet_ids);

    // Assume this is on a channel node.
    // @todo Handle other entities that can also be finder channels.
    // There's no way to get the host entity other than from the route match -
    // the Facet entity knows the SearchAPI Index and the view it's used for,
    // but the view is embedded in an entity.
    $channel_entity = $this->currentRouteMatch->getParameter('node');

    // Bail if the channel entity doesn't have our facet field.
    if (!$channel_entity instanceof NodeInterface || !$channel_entity->hasField(FindersHooks::FACET_ENABLE_FIELD)) {
      return;
    }

    // Get the active facet types from the channel entity.
    $active_facet_types = array_column($channel_entity->finders_facets_enable->getValue(), 'target_id');

    $filtered_results = array_filter(
      $results,
      // Filter out finders facets whose type is not one of the active finders
      // facet types.
      fn (ResultInterface $result) => in_array($finders_facets[$result->getRawValue()]->bundle(), $active_facet_types),
    );

    return $filtered_results;
  }

}
