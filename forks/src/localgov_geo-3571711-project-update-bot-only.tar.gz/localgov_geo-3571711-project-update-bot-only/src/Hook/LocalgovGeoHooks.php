<?php

namespace Drupal\localgov_geo\Hook;

use Drupal\Core\Cache\RefinableCacheableDependencyInterface;
use Drupal\Core\Hook\Attribute\Hook;
use Drupal\Core\StringTranslation\StringTranslationTrait;

/**
 * Hook implementations for localgov_geo.
 */
class LocalgovGeoHooks {
  use StringTranslationTrait;

  /**
   * Implements hook_localgov_roles_default().
   */
  #[Hook('localgov_roles_default')]
  public function localgovRolesDefault() {
    return [
          // @codingStandardsIgnoreLine
          \Drupal\localgov_roles\RolesHelper::EDITOR_ROLE => [
            'access geo overview',
            'create geo',
            'delete any geo',
            'edit any geo',
            'access geo_entity_library entity browser pages',
          ],
          // @codingStandardsIgnoreLine
          \Drupal\localgov_roles\RolesHelper::AUTHOR_ROLE => [
            'create geo',
            'access geo_entity_library entity browser pages',
          ],
          // @codingStandardsIgnoreLine
          \Drupal\localgov_roles\RolesHelper::CONTRIBUTOR_ROLE => [
            'create geo',
            'access geo_entity_library entity browser pages',
          ],
    ];
  }

  /**
   * Implements hook_menu_local_actions_alter().
   */
  #[Hook('menu_local_actions_alter')]
  public function menuLocalActionsAlter(&$local_actions) {
    // Rename 'Add geo' to 'Add location'.
    if (isset($local_actions['geo_entity.add_page'])) {
      $local_actions['geo_entity.add_page']['title'] = $this->t('Add location');
    }
  }

  /**
   * Implements hook_menu_local_tasks_alter().
   */
  #[Hook('menu_local_tasks_alter')]
  public function menuLocalTasksAlter(&$data, $route_name, RefinableCacheableDependencyInterface &$cacheability) {
    // Rename 'Geo' tab to 'Locations' and increase its weight.
    if (isset($data['tabs'][0]['entity.geo_entity.collection'])) {
      $data['tabs'][0]['entity.geo_entity.collection']['#link']['title'] = $this->t('Locations');
      $data['tabs'][0]['entity.geo_entity.collection']['#weight'] = 50;
    }
  }

  /**
   * Implements hook_preprocess_HOOK() for breadcrumb.
   */
  #[Hook('preprocess_breadcrumb')]
  public function preprocessBreadcrumb(&$variables) {
    // Change breadcrumb items from 'Geos' to 'Locations'.
    $route_name = \Drupal::routeMatch()->getRouteName();
    if ($route_name === 'entity.geo_entity.add_page') {
      $variables['breadcrumb'][3]['text'] = $this->t('Locations');
    }
    elseif ($route_name === 'entity.geo_entity.add_form') {
      $variables['breadcrumb'][3]['text'] = $this->t('Locations');
      $variables['breadcrumb'][4]['text'] = $this->t('Add location');
    }
  }

  /**
   * Implements hook_preprocess_HOOK() for html.
   */
  #[Hook('preprocess_html')]
  public function preprocessHtml(&$variables) {
    // Change HTML title tag from 'Geos' to 'Locations'.
    $route_name = \Drupal::routeMatch()->getRouteName();
    if ($route_name === 'entity.geo_entity.collection') {
      $variables['head_title']['title'] = $this->t('Locations');
    }
    elseif ($route_name === 'entity.geo_entity.add_page') {
      $variables['head_title']['title'] = $this->t('Add location');
    }
  }

  /**
   * Implements hook_preprocess_HOOK() for page_title.
   */
  #[Hook('preprocess_page_title')]
  public function preprocessPageTitle(&$variables) {
    // Change page title tag from 'Geos' to 'Locations'.
    $route_name = \Drupal::routeMatch()->getRouteName();
    if ($route_name === 'entity.geo_entity.collection') {
      $variables['title'] = $this->t('Locations');
    }
    elseif ($route_name === 'entity.geo_entity.add_page') {
      $variables['title'] = $this->t('Add location');
    }
  }

}
