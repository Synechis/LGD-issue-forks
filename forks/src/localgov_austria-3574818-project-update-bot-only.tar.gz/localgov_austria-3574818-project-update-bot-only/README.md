## INTRODUCTION

The LocalGov Austria module provides German language support for LocalGov Drupal installations.

This module:

- Sets German as the default language
- Imports German translations for all interface strings
- Translates configuration entities (content types, fields, taxonomies, etc.)
- Sets the default timezone to Europe/Vienna
- Sets Monday as the first day of the week
- Provides comprehensive translations via `.po` files and YAML configuration
~~- Optionally enables the LocalGov Base Austria theme~~ not supported jet

## REQUIREMENTS

- Drupal 10 or 11
- LocalGov Drupal distribution
- The following core modules (enabled automatically):
  - Language
  - Content Translation
  - Configuration Translation
  - Locale

## INSTALLATION

Install as you would normally install a contributed Drupal module.
See: https://www.drupal.org/node/895232 for further information.

```bash
composer require localgovdrupal/localgov_austria
drush en localgov_austria
```

## CONFIGURATION

The module configures German language settings automatically on installation:

- Sets German (de/at) as the default site language
- Removes English language (if not needed)
- Sets timezone to Europe/Vienna
- Sets Monday as the first day of the week
- Sets country to Austria
- Imports German translations from drupal.org
- Imports custom LocalGov translations from included `.po` file
- Translates all LocalGov configuration entities

### Optional Theme

Use the base Theme from Localgov with Theme Generator https://www.drupal.org/project/localgov_basefor a seamless expereince
for a seamless experience.

## TRANSLATION FILES

The module includes two types of translation files:

1. **Interface translations** (`translations/localgov_austria.de.po`):
   - Translates UI strings from PHP code (`t()` functions)
   - Translates UI strings from Twig templates (`|t` filter and `{% trans %}` tags)
   - Translates JavaScript strings (`Drupal.t()`)

2. **Configuration translations** (`translations/localgov_france.config_translations.yml`):
   - Translates content types, fields, taxonomies
   - Translates workflows, user roles
   - Translates paragraph types, view modes
   - Translates menus and other configuration entities

## MAINTAINERS

Current maintainers:
Nico Grienauer - https://www.drupal.org/u/grienauer
Originally developed by Mark Conroy for the French version - https://www.drupal.org/u/markconroy
