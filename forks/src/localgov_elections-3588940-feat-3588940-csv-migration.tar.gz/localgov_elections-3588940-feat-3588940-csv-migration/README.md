# LocalGov Elections

Election reporting for UK local government elections. Provides content types, services, and views for managing and displaying election results.

## Installation

```bash
composer require localgovdrupal/localgov_elections
```

The Charts library is included via CDN by default. For local installation, see the [Charts module documentation](https://www.drupal.org/docs/contributed-modules/charts/50x-getting-started#s-using-composer-and-wikimediacomposer-merge-plugin).

## Submodules

**Boundary Providers** - fetch electoral area boundaries from external APIs:

- **Configurable Provider** - configure any REST API endpoint through the UI. Includes example configurations for UK wards, divisions, parishes, constituencies, and Irish local electoral areas.

*Deprecated providers (use Configurable Provider instead):*
- ONS Wards 2024, ONS Divisions 2024, ONS Parishes 2024, Parliamentary Constituencies

**Supporting Modules**:

- **UK Parties** - populates party taxonomy with UK political parties, colours, and abbreviations
- **Demo Content** - example election data for testing, including:
  - *General Election July 2024* - single-seat parliamentary constituencies
  - *Local Government Elections 2025* - multi-seat council wards

## Content Structure

- **Election** (`localgov_election`) - the parent election with date, type, and aggregated results
- **Area Vote** (`localgov_area_vote`) - individual electoral areas with seats, candidates, and vote counts

Winners are calculated automatically when votes are marked as final.

## Documentation

See [docs/index.md](docs/index.md) for usage instructions.

## Electoral data migration
### Migration process
- Install the [migrate_plus](https://www.drupal.org/project/migrate_plus) module.  This should install the necessary Yaml configuration files from this module.
- Place the CSV files within the `assets/migration-files/` directory at the root of the codebase.
- While the filenames can be editing within the migration config files, by default, they are:
  - political-parties.csv
  - electoral-areas.csv
  - electoral-candidates.csv
- Try these drush commands to trigger the migrations:
  - `drush migrate:import electoral_party_update`
  - `drush migrate:import electoral_area_update`
  - `drush migrate:import electoral_area_candidate_update`

### Sample CSV file content
#### Party details (political-parties.csv)
```
Party,Abbreviation,Colour,TextColour,Url
"Birthday party",BDT,#028DE6,#FFFFFF,https://www.example.net/
"House warming party",HNSW,#E4003B,#FFFFFF,https://www.example.org/
"Another party",ANT,#FAA61A,#000000,https://www.example.info/
```

#### Area details (electoral-areas.csv)
```
Election_name,Previous_election_year,Ward,Eligible_electorate,Previous_winning_party_1,Previous_winning_party_2,Previous_winning_party_3
Election of councillors 2026,2022,Somewhere East,8780,Birthday party,House warming party,Another party
Election of councillors 2026,2022,Somewhere West,11355,House warming party,House warming party,
```

#### Candidate details (electoral-candidates.csv)
```
Election_name,Electoral_area,Surname,First_name,Party_name
Election of councillors 2026,Somewhere East,Doe,Jane,Another party
Election of councillors 2026,Somewhere East,Bloggs,Joe,Birthday party
```

## Known Issues

**Node Revisions**: Revisions do not work reliably with Area Vote nodes due to the paragraph structure. We prevent revisions on candidate and seat paragraphs as a workaround. See [#94](https://github.com/localgovdrupal/localgov_elections/issues/94).

## Support

- Slack: **#feature_elections** in LocalGov Drupal
- Issues: https://www.drupal.org/project/issues/localgov_elections?categories=All

## Maintainers

- Dan Champion https://www.drupal.org/u/danchamp
- Duncan Davidson https://www.drupal.org/u/ded
- Finn Lewis https://www.drupal.org/u/finn-lewis

Based on work by Rob Carr https://github.com/rgcarr.

