# LocalGov MCP

`localgov_mcp` exposes editorial and site administration work on this LocalGov Drupal installation as tools for the installed MCP Server module. The tools run as the Drupal account attached to the MCP session. Every write checks Drupal entity access, and workflow changes also check the account's permitted moderation transitions. An authenticated MCP connection alone does not grant editorial or administration rights.

This module targets the bundles, workflows, and field names in this repository. It uses the existing MCP Server, content moderation, Search API, scheduled transitions, content lock, alert banner, geo entity, metatag, redirect, and Fix 404 modules. It creates no public route of its own.

## Quick start

1. Install the project dependencies with Composer. On another LocalGov Drupal site, install `drupal/localgov_mcp` with Composer once it is available on Drupal.org. While MCP Server 2.x is in beta, the site project's Composer requirements must explicitly allow its beta releases, for example with `composer require 'drupal/mcp_server:^2.0@beta' drupal/localgov_mcp`.
2. Enable the module with `vendor/bin/drush en localgov_mcp -y`. For this project, you can instead import its site configuration, which already enables the module.
3. Rebuild caches: `vendor/bin/drush cr`.
4. Visit **Configuration → Web services → LocalGov MCP tools** (`/admin/config/services/localgov-mcp`) to choose which tools to expose.
5. Configure an MCP Server transport and authentication using that module's documentation. HTTP sessions require its `access mcp server` permission. For STDIO, `vendor/bin/drush mcp:server ACCOUNT` runs as the named Drupal account.
6. Give that account only the Drupal permissions needed for the operations it should perform. Test a read action and a draft before granting publish or site administration permissions.

The MCP Server discovers the `#[Tool]` plugins in this module after cache rebuild. A local STDIO client and smoke test are available in [client](client/README.md).

## Configuration page

The **LocalGov MCP tools** page is at **Configuration → Web services → LocalGov MCP tools** (`/admin/config/services/localgov-mcp`). Access requires Drupal's `administer site configuration` permission. The page lists this module's tools by name and machine ID. Select the tools you want available to MCP clients and save the form. All tools are selected by default.

Clearing a checkbox hides that tool from MCP discovery and prevents it from being called. The setting applies to all MCP connections on the site; it does not change the Drupal permissions needed to use an enabled tool. Refresh or reconnect an MCP client after changing the selection so its tool list is current.

The selection is stored in `localgov_mcp.settings` as a list of disabled tool IDs (`disabled_tools`). Export and import that configuration through your usual Drupal configuration sync workflow to use the same selection in other environments.

## Tool catalogue

| Tool ID | Actions | Main Drupal object |
| --- | --- | --- |
| `localgov_content` | `get`, `list`, `search`, `create_draft`, `create_revision`, `publish`, `unpublish`, `change_state`, `set_alias`, `promote`, `break_lock` | Node |
| `localgov_media` | `search`, `upload`, `update` | Media |
| `localgov_banner` | `list`, `search`, `create`, `update`, `publish`, `unpublish`, `schedule` | Alert banner |
| `localgov_location` | `add`, `update` | Geo entity address |
| `localgov_schedule` | Schedule a state change | Node or alert banner |
| `localgov_taxonomy` | `list`, `search`, `add`, `update` | Taxonomy term |
| `localgov_administration` | `watchdog`, `maintenance`, `flush_cache`, `cron` | Site |
| `localgov_site_search` | Indexed search with entity-query fallback | Search API `site_search` index, nodes and document media |
| `localgov_metatag` | `get`, `set` | Node metatag field |
| `localgov_redirect` | `list`, `search`, `add`, `update`, `delete`, `fix_404`, `add_for_404` | Redirect or Fix 404 record |

All responses contain `success` and `data`. Failures also contain `message`. Search and list actions return arrays, capped at 50 results unless a tool specifies 100. IDs returned by one tool can be used by the other tools. Actions are supplied as JSON object arguments to the named MCP tool.

To list a content type, use `localgov_content` with `action: "list"` and a supported `bundle`. Its results come from Drupal's entity manager, with entity access checks. Use `localgov_content` `search` for title lookups. `localgov_site_search` is a last resort for indexed full-text requests that entity queries cannot answer. Both content listing and title search accept `limit` and `offset` for paging.

Use `localgov_content` with `action: "get"` and a node `id` to return its metadata and all fields the current account may view. Fields are keyed by machine name and contain Drupal field item arrays. Add `include_fields: true` to list, search, or actions that save a node to include the same field data in their responses. Fields are discovered from the node's content type, so this covers all supported bundles without a per-bundle field list.

If the `site_search` index is unavailable or its backend fails, `localgov_site_search` falls back to access-checked entity queries over node titles and document media names. The response keeps the same result fields and sets `source` to `entity_query` with a message explaining the narrower match scope. Normal indexed results set `source` to `search_api`. If both sources fail, the tool returns `success: false` and records the failures in Drupal's log.

## Supported content types

| Label | Machine name |
| --- | --- |
| Directory channel | `localgov_directory` |
| Directory organisation | `localgov_directories_org` |
| Directory page | `localgov_directories_page` |
| Directory venue | `localgov_directories_venue` |
| Event | `localgov_event` |
| External page | `external_page` |
| Guide overview | `localgov_guides_overview` |
| Guide page | `localgov_guides_page` |
| Homepage | `homepage` |
| News article | `localgov_news_article` |
| Newsroom | `localgov_newsroom` |
| Service landing page | `localgov_services_landing` |
| Service page | `localgov_services_page` |
| Service sub-landing page | `localgov_services_sublanding` |
| Step by step overview | `localgov_step_by_step_overview` |
| Step by step page | `localgov_step_by_step_page` |

The allowlist prevents an MCP caller from editing unrelated node bundles. Content listing and title search use access checked entity queries and return only nodes that also pass `view` access. Other entity searches follow the same pattern.

## Working with fields

Create and update actions accept a `fields` object keyed by Drupal field machine name. Use the shape Drupal expects for each field item. Only configurable fields that pass field `edit` access are accepted. Base fields such as `uid`, `status`, and `moderation_state` have dedicated arguments or actions. Text fields require an explicit format ID that the current account can use. Drupal entity validation runs before saving, so required fields depend on the site's configuration.

For example, a service page draft with a body field can be requested as:

```json
{
  "action": "create_draft",
  "bundle": "localgov_services_page",
  "title": "Applying for a permit",
  "fields": {
    "body": {"value": "<p>Start here.</p>", "format": "basic_html"}
  }
}
```

Some LocalGov bundles require references or additional fields. If validation rejects the draft, supply those fields in the next call. The `fields` input is a Drupal field API value, not a rendered form value. For reference fields use `{"target_id": 123}`. For multi-value fields use an array of field items.

File media use `filename` and `file_base64`; images additionally require `alt`. The uploader accepts the extension configured for the media source field and caps decoded content at 15 MB. Uploaded files go to `public://localgov_mcp/YYYY-MM/`. Remote videos accept HTTPS YouTube or Vimeo URLs.

## Editorial workflow

Content drafts, revisions, alias changes, promotion changes, and metatag changes create revisions. Updates that edit existing page data request a `draft` transition so live content is not silently changed. `publish`, `unpublish`, and `change_state` request the chosen state and require the workflow transition permission. A transition can be unavailable from the entity's current state even when the account can edit the node. The `state` response field shows the resulting moderation state.

The editorial workflow for most bundles in this repository has `draft`, `review`, `approved`, `published`, `unpublished`, and `archived`. News articles may use a separate workflow. The tool reads the entity's active workflow rather than assuming one workflow ID. Alert banners have their own `draft`, `published`, and `unpublished` states.

Scheduling creates a Scheduled Transitions record tied to the current revision. Supply a future ISO 8601 date and time with an explicit timezone, such as `2026-11-02T09:00:00+00:00`. Scheduled changes execute when the site's normal cron and scheduled transitions processing run. The account needs `add scheduled transitions ENTITY_TYPE BUNDLE`, update access, and permission for the requested transition.

## Permissions and operation safety

- The MCP transport enforces its own connection permission. Each tool additionally requires an authenticated account.
- Entity reads and writes use Drupal access control. Create actions use entity type create access; configurable fields use field edit access.
- Content lock breaking requires `break content lock` plus node update access.
- Scheduling requires the relevant scheduled transition permission and a currently allowed moderation transition.
- Watchdog requires `access site reports`. Maintenance mode, cache flush, and cron require `administer site configuration`.
- Redirect work requires `administer redirects`; a redirect destination must be a local site-relative path. The source path has no query string or fragment.
- File uploads accept only field-configured extensions and use Drupal file and media validation.

All combined read/write tools declare a write-capable MCP annotation because one action can change data. `localgov_site_search` is annotated read-only. MCP clients should inspect the `action` value before calling a combined tool.

## Tests and coverage

The module has a local PHPUnit configuration so its unit tests can run without a Drupal database. The small runner bypasses an unrelated PHPUnit class preload conflict in this project's current vendor tree:

```bash
php web/modules/custom/localgov_mcp/tests/run.php \
  -c web/modules/custom/localgov_mcp/phpunit.xml.dist
```

To produce line coverage with Xdebug:

```bash
XDEBUG_MODE=coverage php web/modules/custom/localgov_mcp/tests/run.php \
  -c web/modules/custom/localgov_mcp/phpunit.xml.dist --coverage-text
```

Run syntax, coding standard, and static analysis checks after changes:

```bash
find web/modules/custom/localgov_mcp/src -name '*.php' -print0 | xargs -0 -n1 php -l
vendor/bin/phpcs web/modules/custom/localgov_mcp/src --standard=Drupal
vendor/bin/phpstan analyse web/modules/custom/localgov_mcp/src \
  -c web/modules/custom/localgov_mcp/phpstan.neon.dist --no-progress
```

The unit suite covers input allowlists and permission boundaries. A connected site is still needed for end-to-end tests of its field configuration, media storage, workflow transitions, search backend, and scheduled jobs.

## Feature guides

- [Content](readme/content.md)
- [Media](readme/media.md)
- [Alert banners](readme/alert-banners.md)
- [Locations](readme/locations.md)
- [Scheduling](readme/scheduling.md)
- [Taxonomy](readme/taxonomy.md)
- [Administration](readme/administration.md)
- [Site search](readme/site-search.md)
- [Metatags](readme/metatag.md)
- [Redirects and Fix 404](readme/redirects.md)

Each guide lists the relevant machine names, required arguments, example calls, access rules, and how to interpret the result.
