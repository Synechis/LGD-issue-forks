import assert from "node:assert/strict";
import { connectToDrupal, toolResultText } from "./mcp-client.mjs";

const expectedTools = [
  "localgov_content",
  "localgov_media",
  "localgov_banner",
  "localgov_location",
  "localgov_schedule",
  "localgov_taxonomy",
  "localgov_administration",
  "localgov_site_search",
  "localgov_metatag",
  "localgov_redirect",
];

const client = await connectToDrupal();

try {
  const server = client.getServerVersion();
  const { tools } = await client.listTools();
  const toolNames = new Set(tools.map((tool) => tool.name));

  for (const name of expectedTools) {
    assert.ok(toolNames.has(name), `Drupal did not expose ${name}`);
    assert.equal(tools.find((tool) => tool.name === name).inputSchema.type, "object");
  }
  const contentSchema = tools.find((tool) => tool.name === "localgov_content").inputSchema;
  assert.ok(contentSchema.properties.action.enum.includes("list"));
  assert.ok(contentSchema.properties.action.enum.includes("get"));
  assert.equal(contentSchema.properties.include_fields.type, "boolean");
  assert.ok(contentSchema.properties.bundle.enum.includes("localgov_services_page"));

  // A query that cannot match real titles exercises a read-only operation
  // without making assertions about the site's content.
  const result = await client.callTool({
    name: "localgov_content",
    arguments: { action: "search", query: `mcp-smoke-${Date.now()}`, limit: 1 },
  });

  assert.equal(result.isError, false, toolResultText(result));
  const response = JSON.parse(toolResultText(result));
  assert.equal(response.success, true, response.message);
  assert.ok(Array.isArray(response.data));

  const listResult = await client.callTool({
    name: "localgov_content",
    arguments: { action: "list", bundle: "localgov_services_page", limit: 1 },
  });
  assert.equal(listResult.isError, false, toolResultText(listResult));
  const listResponse = JSON.parse(toolResultText(listResult));
  assert.equal(listResponse.success, true, listResponse.message);
  assert.ok(Array.isArray(listResponse.data));

  const siteSearchResult = await client.callTool({
    name: "localgov_site_search",
    arguments: { query: `mcp-smoke-${Date.now()}`, limit: 1 },
  });
  assert.equal(siteSearchResult.isError, false, toolResultText(siteSearchResult));
  const siteSearchResponse = JSON.parse(toolResultText(siteSearchResult));
  assert.equal(siteSearchResponse.success, true, siteSearchResponse.message);
  assert.ok(["search_api", "entity_query"].includes(siteSearchResponse.source));
  assert.ok(Array.isArray(siteSearchResponse.data));

  console.log(`Connected to ${server?.name ?? "Drupal MCP Server"}.`);
  console.log(`Discovered all ${expectedTools.length} LocalGov tools.`);
  console.log(`Read-only content listing and site search passed (${siteSearchResponse.source}).`);
} finally {
  await client.close();
}
