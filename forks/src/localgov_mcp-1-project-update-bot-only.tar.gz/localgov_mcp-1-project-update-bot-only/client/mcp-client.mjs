import { Client } from "@modelcontextprotocol/sdk/client/index.js";
import { StdioClientTransport } from "@modelcontextprotocol/sdk/client/stdio.js";
import { fileURLToPath } from "node:url";

// client/ lives under web/modules/custom/localgov_mcp/.
const projectRoot = fileURLToPath(new URL("../../../../../", import.meta.url));

/**
 * Start Drupal's MCP server over STDIO and return a connected client.
 *
 * The Drupal account is selected by the person launching the process. The MCP
 * client cannot change it after the server starts.
 */
export async function connectToDrupal() {
  const account = process.env.DRUPAL_MCP_ACCOUNT ?? "1";
  const transport = new StdioClientTransport({
    command: "ddev",
    args: ["drush", "mcp:server", account],
    cwd: projectRoot,
    stderr: "inherit",
  });

  const client = new Client({
    name: "localgov-mcp-client",
    version: "1.0.0",
  });

  await client.connect(transport);
  return client;
}

/** Convert an MCP tool result into text suitable for an AI tool response. */
export function toolResultText(result) {
  if (result.structuredContent) {
    return JSON.stringify(result.structuredContent);
  }

  const text = result.content
    ?.filter((item) => item.type === "text")
    .map((item) => item.text)
    .join("\n");

  return text || JSON.stringify(result);
}
