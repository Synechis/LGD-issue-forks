# LocalGov MCP client

This Node.js client starts this project's Drupal MCP server over STDIO. It
contains a read-only smoke test and an optional AI chat interface. The chat
discovers the tools exposed by Drupal, passes their schemas to the OpenAI
Responses API, and sends tool calls back to Drupal through MCP.

## Requirements

- Node.js 22 or later and npm.
- DDEV installed and running for this project, with a bootstrapped Drupal site.
- The `mcp_server` and `localgov_mcp` Drupal modules enabled.
- An `OPENAI_API_KEY` for the chat interface only; the smoke test needs no key.

From the repository root, prepare Drupal and install the client dependencies:

```bash
ddev start
ddev drush en localgov_mcp -y
ddev drush cr
cd web/modules/custom/localgov_mcp/client
npm ci
```

The client derives the DDEV project root from its location in this repository,
so run `npm` from this folder. `DRUPAL_MCP_ACCOUNT` selects the Drupal account
for the server process; it defaults to user ID `1`. That account must be active
and have the Drupal permissions needed by each operation.

## Check the connection

```bash
npm test
```

The smoke test discovers all ten LocalGov tools, checks the `get` action schema,
and performs read-only `localgov_content` search and list operations plus a
`localgov_site_search` call. It reports whether site search used Search API or the entity fallback.
It does not change content. To test permissions for another account:

```bash
DRUPAL_MCP_ACCOUNT=123 npm test
```

The test requires the selected account to be able to see the tools and search
content. A tool may be listed but still reject a particular operation when
Drupal entity access or moderation permissions do not allow it.

## Chat with the site

Set your API key in the shell and start an interactive session:

```bash
export OPENAI_API_KEY="your-key"
npm run chat
```

Ask, for example, `List service pages`, `List event category terms`, or `Find
redirects containing parking`. The client uses Drupal entity queries for
content-type lists and title lookups; indexed site search is a last resort.
Exit with `/exit` or `/quit`.
For a one-shot request:

```bash
npm run chat -- 'Search service pages for recycling and show their links'
```

The default model is `gpt-5-mini`. Set `OPENAI_MODEL` to use a different model.
Select another Drupal account with `DRUPAL_MCP_ACCOUNT`:

```bash
OPENAI_MODEL=gpt-5-mini DRUPAL_MCP_ACCOUNT=123 npm run chat
```

The chat asks the model to make changes only when your request explicitly asks
for them. Drupal enforces the selected account's permissions on every tool
call. For example, an explicit draft request can be:

```text
Create a draft service page titled "Applying for a permit" with body
<p>Start here.</p> in the basic_html text format.
```

## Available tools

| Tool | Purpose |
| --- | --- |
| `localgov_content` | Get a node with its viewable fields, list or search supported content types; draft, revise, publish, unpublish, change state, set aliases, promote, and break locks. |
| `localgov_media` | Search, upload, and update document, image, and remote video media. |
| `localgov_banner` | Create, update, publish, unpublish, and schedule alert banners. |
| `localgov_location` | Add and update locations. |
| `localgov_schedule` | Schedule a state change. |
| `localgov_taxonomy` | List, search, add, and update supported terms. |
| `localgov_administration` | Read watchdog entries, set maintenance mode, flush caches, and run cron. |
| `localgov_site_search` | Search the site's Search API index, with a node title and document media name fallback if the index is unavailable. |
| `localgov_metatag` | Get and set page titles and meta descriptions. |
| `localgov_redirect` | Manage redirects and Fix 404 records. |

The Drupal module's [README](../README.md) and its `readme/` guides document
the precise arguments, content bundles, and access checks for every tool.
The chat client sends each tool's published JSON schema to the model, so it
does not hard-code individual tool actions.

The STDIO server runs as the Drupal account chosen when the client starts. A
local user who can launch DDEV already has command-line access to the site;
keep this client on a trusted machine. An HTTP MCP transport needs separate
authentication and is outside this client's setup.
