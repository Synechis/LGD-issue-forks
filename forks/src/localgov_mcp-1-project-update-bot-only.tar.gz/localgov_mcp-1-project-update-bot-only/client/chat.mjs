import OpenAI from "openai";
import { createInterface } from "node:readline/promises";
import { stdin, stdout } from "node:process";
import { connectToDrupal, toolResultText } from "./mcp-client.mjs";

if (!process.env.OPENAI_API_KEY) {
  console.error("Set OPENAI_API_KEY before starting the chat.");
  process.exit(1);
}

const openai = new OpenAI();
const model = process.env.OPENAI_MODEL ?? "gpt-5-mini";
const mcp = await connectToDrupal();

/** OpenAI function names have a smaller character set than MCP tool names. */
function functionName(name) {
  return name.replace(/[^a-zA-Z0-9_-]/g, "_").slice(0, 64);
}

const { tools: mcpTools } = await mcp.listTools();
const toolsByFunctionName = new Map();
const openAiTools = mcpTools.map((tool) => {
  const name = functionName(tool.name);
  if (toolsByFunctionName.has(name)) {
    throw new Error(`MCP tool name collision after normalising: ${tool.name}`);
  }
  toolsByFunctionName.set(name, tool);

  return {
    type: "function",
    name,
    description: tool.description ?? `Call Drupal MCP tool ${tool.name}`,
    parameters: tool.inputSchema,
    // MCP servers may publish valid JSON Schema that does not meet the
    // narrower requirements of OpenAI strict function schemas.
    strict: false,
  };
});

const instructions = [
  "You are a concise assistant connected to a LocalGov Drupal website through MCP.",
  "Use a Drupal tool whenever the user asks about the site or asks you to test the connection.",
  "For lists of a content type, use localgov_content action list with its bundle. Use localgov_content search for title lookups. Use localgov_site_search only as a last resort when entity queries cannot answer and indexed full-text search is needed.",
  "For all fields on one content item, use localgov_content action get with its ID. Set include_fields to true on list or search when full field data is needed for those results.",
  "Only call a tool that changes Drupal when the user explicitly asks for that change.",
  mcp.getInstructions(),
]
  .filter(Boolean)
  .join(" ");

async function answer(message, previousResponseId) {
  let response = await openai.responses.create({
    model,
    instructions,
    input: message,
    tools: openAiTools,
    store: true,
    ...(previousResponseId ? { previous_response_id: previousResponseId } : {}),
  });

  for (let round = 0; round < 8; round += 1) {
    const calls = response.output.filter((item) => item.type === "function_call");
    if (calls.length === 0) {
      return response;
    }

    const outputs = [];
    for (const call of calls) {
      const tool = toolsByFunctionName.get(call.name);
      if (!tool) {
        throw new Error(`The model requested unknown tool: ${call.name}`);
      }

      const args = JSON.parse(call.arguments || "{}");
      console.log(`[LocalGov tool] ${tool.name} ${JSON.stringify(args)}`);

      try {
        const result = await mcp.callTool({ name: tool.name, arguments: args });
        outputs.push({
          type: "function_call_output",
          call_id: call.call_id,
          output: toolResultText(result),
        });
      } catch (error) {
        outputs.push({
          type: "function_call_output",
          call_id: call.call_id,
          output: JSON.stringify({ error: error.message }),
        });
      }
    }

    response = await openai.responses.create({
      model,
      instructions,
      input: outputs,
      tools: openAiTools,
      store: true,
      previous_response_id: response.id,
    });
  }

  throw new Error("The model exceeded the maximum number of tool-call rounds.");
}

let previousResponseId;
const oneShotMessage = process.argv.slice(2).join(" ").trim();

try {
  console.log(`Connected to LocalGov Drupal with ${mcpTools.length} MCP tools (${model}).`);

  if (oneShotMessage) {
    const response = await answer(oneShotMessage);
    console.log(response.output_text);
  } else {
    const readline = createInterface({ input: stdin, output: stdout });
    console.log("Ask about Drupal, or type /exit.");

    try {
      while (true) {
        const message = (await readline.question("you> ")).trim();
        if (!message) continue;
        if (["/exit", "/quit"].includes(message.toLowerCase())) break;

        const response = await answer(message, previousResponseId);
        previousResponseId = response.id;
        console.log(`ai> ${response.output_text}\n`);
      }
    } finally {
      readline.close();
    }
  }
} finally {
  await mcp.close();
}
