<?php

declare(strict_types=1);

namespace Drupal\Tests\localgov_mcp\Unit;

use PHPUnit\Framework\Attributes\Group;
use Drupal\Component\Datetime\TimeInterface;
use Drupal\content_lock\ContentLock\ContentLockInterface;
use Drupal\content_moderation\ModerationInformationInterface;
use Drupal\content_moderation\StateTransitionValidationInterface;
use Drupal\Core\Entity\EntityStorageInterface;
use Drupal\Core\Entity\EntityTypeManagerInterface;
use Drupal\Core\Entity\Query\QueryInterface;
use Drupal\Core\Field\FieldItemListInterface;
use Drupal\Core\Session\AccountProxyInterface;
use Drupal\Core\Url;
use Drupal\localgov_mcp\Common;
use Drupal\localgov_mcp\ContentOperations;
use Drupal\node\NodeInterface;
use PHPUnit\Framework\Attributes\AllowMockObjectsWithoutExpectations;
use PHPUnit\Framework\TestCase;

/**
 * Tests access-checked field data for supported node bundles.
 *
 * @group localgov_mcp
 */
#[AllowMockObjectsWithoutExpectations]
#[Group('localgov_mcp')]
final class ContentFieldsTest extends TestCase {

  /**
   * A service page read includes every configured field that is viewable.
   */
  public function testGetServicePageFields(): void {
    $account = $this->createStub(AccountProxyInterface::class);
    $values = [
      'body' => [['value' => '<p>Guidance</p>', 'format' => 'basic_html']],
      'field_bypass_2i' => [['value' => 0]],
      'field_metatag' => [],
      'localgov_download_links' => [['target_id' => 12]],
      'localgov_hide_related_topics' => [['value' => 1]],
      'localgov_page_components' => [['target_id' => 17]],
      'localgov_services_parent' => [['target_id' => 3]],
      'localgov_related_links' => [['uri' => 'internal:/node/6', 'title' => 'Related']],
      'localgov_topic_classified' => [['target_id' => 5]],
      'localgov_common_tasks' => [],
      'field_private' => [['value' => 'restricted']],
    ];
    $node = $this->node('localgov_services_page', $values);
    $manager = $this->createStub(EntityTypeManagerInterface::class);
    $storage = $this->createStub(EntityStorageInterface::class);
    $manager->method('getStorage')->willReturn($storage);
    $storage->method('load')->willReturn($node);

    $result = $this->operations($manager, $account)->handle(['action' => 'get', 'id' => 42]);

    $this->assertTrue($result['success']);
    $this->assertSame(42, $result['data']['id']);
    $this->assertSame(array_diff_key($values, ['field_private' => NULL]), $result['data']['fields']);
  }

  /**
   * Search can return fields from another bundle when explicitly requested.
   */
  public function testSearchIncludesOtherBundleFields(): void {
    $account = $this->createStub(AccountProxyInterface::class);
    $node = $this->node('localgov_event', [
      'localgov_event_date' => [['value' => '2026-10-07']],
      'localgov_event_categories' => [['target_id' => 8]],
    ]);
    $manager = $this->createStub(EntityTypeManagerInterface::class);
    $storage = $this->createStub(EntityStorageInterface::class);
    $query = $this->createStub(QueryInterface::class);
    $manager->method('getStorage')->willReturn($storage);
    $storage->method('getQuery')->willReturn($query);
    $query->method('accessCheck')->willReturnSelf();
    $query->method('condition')->willReturnSelf();
    $query->method('sort')->willReturnSelf();
    $query->method('range')->willReturnSelf();
    $query->method('execute')->willReturn([42]);
    $storage->method('loadMultiple')->willReturn([42 => $node]);

    $result = $this->operations($manager, $account)->handle([
      'action' => 'search',
      'query' => 'festival',
      'include_fields' => TRUE,
    ]);

    $this->assertSame([
      'localgov_event_date' => [['value' => '2026-10-07']],
      'localgov_event_categories' => [['target_id' => 8]],
    ], $result['data'][0]['fields']);
  }

  /**
   * Node view access is required before reading any fields.
   */
  public function testGetDeniedNode(): void {
    $account = $this->createStub(AccountProxyInterface::class);
    $node = $this->createMock(NodeInterface::class);
    $node->method('bundle')->willReturn('localgov_services_page');
    $node->method('access')->with('view', $account)->willReturn(FALSE);
    $node->expects($this->never())->method('getFieldDefinitions');
    $manager = $this->createStub(EntityTypeManagerInterface::class);
    $storage = $this->createStub(EntityStorageInterface::class);
    $manager->method('getStorage')->willReturn($storage);
    $storage->method('load')->willReturn($node);

    $this->expectException(\InvalidArgumentException::class);
    $this->expectExceptionMessage('Access denied for this entity.');
    $this->operations($manager, $account)->handle(['action' => 'get', 'id' => 42]);
  }

  /**
   * Creates an accessible node with viewable and restricted fields.
   */
  private function node(string $bundle, array $values): NodeInterface {
    $node = $this->createStub(NodeInterface::class);
    $node->method('id')->willReturn(42);
    $node->method('bundle')->willReturn($bundle);
    $node->method('label')->willReturn('Example');
    $node->method('getRevisionId')->willReturn(1);
    $node->method('isPublished')->willReturn(TRUE);
    $node->method('access')->willReturn(TRUE);
    $node->method('getFieldDefinitions')->willReturn(array_fill_keys(array_keys($values), NULL));
    $fields = [];
    foreach ($values as $name => $value) {
      $field = $this->createStub(FieldItemListInterface::class);
      $field->method('access')->willReturn($name !== 'field_private');
      $field->method('getValue')->willReturn($value);
      $fields[$name] = $field;
    }
    $state = $this->createStub(FieldItemListInterface::class);
    $state->method('__get')->willReturn('published');
    $node->method('get')->willReturnCallback(static fn (string $name) => $name === 'moderation_state' ? $state : $fields[$name]);
    $url = $this->createStub(Url::class);
    $url->method('toString')->willReturn('https://example.test/node/42');
    $node->method('toUrl')->willReturn($url);
    return $node;
  }

  /**
   * Builds the operation under test.
   */
  private function operations(EntityTypeManagerInterface $manager, AccountProxyInterface $account): ContentOperations {
    return new ContentOperations(
      new Common($manager, $account),
      $manager,
      $account,
      $this->createStub(StateTransitionValidationInterface::class),
      $this->createStub(ModerationInformationInterface::class),
      $this->createStub(TimeInterface::class),
      $this->createStub(ContentLockInterface::class),
    );
  }

}
