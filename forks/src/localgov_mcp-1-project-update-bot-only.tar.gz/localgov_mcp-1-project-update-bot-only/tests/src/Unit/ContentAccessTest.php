<?php

declare(strict_types=1);

namespace Drupal\Tests\localgov_mcp\Unit;

use PHPUnit\Framework\Attributes\Group;
use Drupal\Component\Datetime\TimeInterface;
use Drupal\content_lock\ContentLock\ContentLockInterface;
use Drupal\content_moderation\ModerationInformationInterface;
use Drupal\content_moderation\StateTransitionValidationInterface;
use Drupal\Core\Entity\EntityAccessControlHandlerInterface;
use Drupal\Core\Entity\EntityStorageInterface;
use Drupal\Core\Entity\EntityTypeManagerInterface;
use Drupal\Core\Field\FieldItemList;
use Drupal\Core\Session\AccountProxyInterface;
use Drupal\Core\Url;
use Drupal\localgov_mcp\Common;
use Drupal\localgov_mcp\ContentOperations;
use Drupal\node\NodeInterface;
use PHPUnit\Framework\TestCase;
use PHPUnit\Framework\Attributes\AllowMockObjectsWithoutExpectations;
use Symfony\Component\Validator\ConstraintViolationList;

/**
 * Tests content creation permission handling.
 *
 * @coversDefaultClass \Drupal\localgov_mcp\ContentOperations
 * @group localgov_mcp
 */
#[AllowMockObjectsWithoutExpectations]
#[Group('localgov_mcp')]
final class ContentAccessTest extends TestCase {

  /**
   * An account without create access cannot save a node.
   */
  public function testCreateDraftDenied(): void {
    $manager = $this->createMock(EntityTypeManagerInterface::class);
    $storage = $this->createMock(EntityStorageInterface::class);
    $handler = $this->createMock(EntityAccessControlHandlerInterface::class);
    $account = $this->createMock(AccountProxyInterface::class);
    $manager->method('getStorage')->with('node')->willReturn($storage);
    $manager->method('getAccessControlHandler')->with('node')->willReturn($handler);
    $handler->method('createAccess')->willReturn(FALSE);
    $storage->expects($this->never())->method('create');

    $operations = new ContentOperations(
      new Common($manager, $account),
      $manager,
      $account,
      $this->createMock(StateTransitionValidationInterface::class),
      $this->createMock(ModerationInformationInterface::class),
      $this->createMock(TimeInterface::class),
      $this->createMock(ContentLockInterface::class),
    );
    $result = $operations->handle([
      'action' => 'create_draft',
      'bundle' => 'localgov_services_page',
      'title' => 'New page',
    ]);
    $this->assertFalse($result['success']);
    $this->assertSame('Access denied to create this content type.', $result['message']);
  }

  /**
   * A lock held by another editor prevents a publishing action.
   */
  public function testLockedNodeCannotBePublished(): void {
    $manager = $this->createMock(EntityTypeManagerInterface::class);
    $storage = $this->createMock(EntityStorageInterface::class);
    $account = $this->createStub(AccountProxyInterface::class);
    $node = $this->createMock(NodeInterface::class);
    $manager->method('getStorage')->with('node')->willReturn($storage);
    $storage->method('load')->with(42)->willReturn($node);
    $node->method('bundle')->willReturn('localgov_services_page');
    $node->method('access')->with('update', $account)->willReturn(TRUE);
    $node->expects($this->never())->method('save');
    $account->method('id')->willReturn(7);
    $locks = $this->createMock(ContentLockInterface::class);
    $locks->method('fetchLock')->willReturn((object) ['uid' => 99]);

    $operations = new ContentOperations(
      new Common($manager, $account),
      $manager,
      $account,
      $this->createStub(StateTransitionValidationInterface::class),
      $this->createStub(ModerationInformationInterface::class),
      $this->createStub(TimeInterface::class),
      $locks,
    );
    $result = $operations->handle(['action' => 'publish', 'id' => 42]);
    $this->assertFalse($result['success']);
    $this->assertStringContainsString('locked by another editor', $result['message']);
  }

  /**
   * A permitted draft is validated and saved with the caller as author.
   */
  public function testCreateDraft(): void {
    $manager = $this->createStub(EntityTypeManagerInterface::class);
    $storage = $this->createStub(EntityStorageInterface::class);
    $access = $this->createStub(EntityAccessControlHandlerInterface::class);
    $account = $this->createStub(AccountProxyInterface::class);
    $node = $this->createMock(NodeInterface::class);
    $state = $this->createStub(FieldItemList::class);
    $url = $this->createStub(Url::class);
    $manager->method('getStorage')->willReturn($storage);
    $manager->method('getAccessControlHandler')->willReturn($access);
    $access->method('createAccess')->willReturn(TRUE);
    $account->method('id')->willReturn(7);
    $storage->method('create')->willReturn($node);
    $node->expects($this->once())->method('set')->with('moderation_state', 'draft');
    $node->expects($this->once())->method('save');
    $node->method('validate')->willReturn(new ConstraintViolationList());
    $node->method('id')->willReturn(42);
    $node->method('getRevisionId')->willReturn(1);
    $node->method('bundle')->willReturn('localgov_services_page');
    $node->method('label')->willReturn('New service page');
    $node->method('get')->willReturn($state);
    $node->method('isPublished')->willReturn(FALSE);
    $node->method('toUrl')->willReturn($url);
    $state->method('__get')->willReturn('draft');
    $url->method('toString')->willReturn('https://example.test/node/42');

    $result = (new ContentOperations(
      new Common($manager, $account), $manager, $account,
      $this->createStub(StateTransitionValidationInterface::class),
      $this->createStub(ModerationInformationInterface::class),
      $this->createStub(TimeInterface::class),
      $this->createStub(ContentLockInterface::class),
    ))->handle([
      'action' => 'create_draft',
      'bundle' => 'localgov_services_page',
      'title' => 'New service page',
    ]);
    $this->assertTrue($result['success']);
    $this->assertSame(42, $result['data']['id']);
    $this->assertSame('draft', $result['data']['state']);
  }

}
