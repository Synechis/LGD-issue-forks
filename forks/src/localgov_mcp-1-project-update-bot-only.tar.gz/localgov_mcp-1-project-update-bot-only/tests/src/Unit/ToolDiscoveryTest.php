<?php

declare(strict_types=1);

namespace Drupal\Tests\localgov_mcp\Unit;

use PHPUnit\Framework\Attributes\Group;
use Drupal\mcp_server\Attribute\Tool;
use PHPUnit\Framework\TestCase;
use Symfony\Component\Yaml\Yaml;

/**
 * Checks that every MCP plugin maps to a declared service and input schema.
 *
 * @group localgov_mcp
 */
#[Group('localgov_mcp')]
final class ToolDiscoveryTest extends TestCase {

  /**
   * Tool identifiers and service handlers are unique and defined.
   */
  public function testToolDefinitions(): void {
    $module = dirname(__DIR__, 3);
    $services = Yaml::parseFile($module . '/localgov_mcp.services.yml')['services'];
    $extensions = Yaml::parseFile(dirname($module, 4) . '/config/sync/core.extension.yml');
    $this->assertArrayHasKey('localgov_mcp', $extensions['module']);
    $ids = [];
    $files = glob($module . '/src/Plugin/mcp_server/Tool/*.php');
    $this->assertCount(10, $files);
    foreach ($files as $file) {
      $class = 'Drupal\\localgov_mcp\\Plugin\\mcp_server\\Tool\\' . basename($file, '.php');
      $reflection = new \ReflectionClass($class);
      $attributes = $reflection->getAttributes(Tool::class);
      $this->assertCount(1, $attributes, $class);
      $tool = $attributes[0]->newInstance();
      $this->assertArrayNotHasKey($tool->id, $ids);
      $ids[$tool->id] = TRUE;
      $this->assertSame('object', $tool->inputSchema['type']);
      $this->assertArrayHasKey($reflection->getConstant('HANDLER'), $services);
    }
    foreach ($services as $service) {
      $constructor = (new \ReflectionClass($service['class']))->getConstructor();
      $this->assertNotNull($constructor);
      $this->assertCount($constructor->getNumberOfRequiredParameters(), $service['arguments']);
    }
  }

}
