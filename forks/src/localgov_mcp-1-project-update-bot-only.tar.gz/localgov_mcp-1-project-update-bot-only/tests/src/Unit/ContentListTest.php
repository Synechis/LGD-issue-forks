<?php

declare(strict_types=1);

namespace Drupal\Tests\localgov_mcp\Unit;

use PHPUnit\Framework\Attributes\Group;
use Drupal\Component\Datetime\TimeInterface;
use Drupal\content_lock\ContentLock\ContentLockInterface;
use Drupal\content_moderation\ModerationInformationInterface;
use Drupal\content_moderation\StateTransitionValidationInterface;
use Drupal\Core\Entity\EntityStorageInterface;
use Drupal\Core\Entity\EntityTypeManagerInterface;
use Drupal\Core\Entity\Query\QueryInterface;
use Drupal\Core\Field\FieldItemList;
use Drupal\Core\Session\AccountProxyInterface;
use Drupal\Core\Url;
use Drupal\localgov_mcp\Common;
use Drupal\localgov_mcp\ContentOperations;
use Drupal\node\NodeInterface;
use PHPUnit\Framework\Attributes\AllowMockObjectsWithoutExpectations;
use PHPUnit\Framework\TestCase;

/**
 * Tests listing a content type through the node entity manager.
 *
 * @group localgov_mcp
 */
#[AllowMockObjectsWithoutExpectations]
#[Group('localgov_mcp')]
final class ContentListTest extends TestCase {

  /**
   * A list is bundle-filtered, paginated, and limited to viewable nodes.
   */
  public function testListContentType(): void {
    $manager = $this->createMock(EntityTypeManagerInterface::class);
    $storage = $this->createMock(EntityStorageInterface::class);
    $query = $this->createMock(QueryInterface::class);
    $account = $this->createStub(AccountProxyInterface::class);
    $manager->expects($this->once())->method('getStorage')->with('node')->willReturn($storage);
    $storage->method('getQuery')->willReturn($query);
    $query->expects($this->once())->method('accessCheck')->with(TRUE)->willReturnSelf();
    $conditions = [];
    $query->method('condition')->willReturnCallback(static function ($field, $value, $operator = NULL) use (&$conditions, $query) {
      $conditions[] = [$field, $value, $operator];
      return $query;
    });
    $query->method('sort')->willReturnSelf();
    $query->expects($this->once())->method('range')->with(50, 25)->willReturnSelf();
    $query->method('execute')->willReturn([42 => 42, 43 => 43]);

    $visible = $this->createStub(NodeInterface::class);
    $visible->method('access')->willReturn(TRUE);
    $visible->method('id')->willReturn(42);
    $visible->method('bundle')->willReturn('localgov_services_page');
    $visible->method('label')->willReturn('Permits');
    $visible->method('getRevisionId')->willReturn(8);
    $visible->method('isPublished')->willReturn(TRUE);
    $state = $this->createStub(FieldItemList::class);
    $state->method('__get')->willReturn('published');
    $visible->method('get')->willReturn($state);
    $url = $this->createStub(Url::class);
    $url->method('toString')->willReturn('https://example.test/permits');
    $visible->method('toUrl')->willReturn($url);
    $hidden = $this->createMock(NodeInterface::class);
    $hidden->method('access')->with('view', $account)->willReturn(FALSE);
    $hidden->expects($this->never())->method('toUrl');
    $storage->method('loadMultiple')->willReturn([42 => $visible, 43 => $hidden]);

    $result = $this->operations($manager, $account)->handle([
      'action' => 'list',
      'bundle' => 'localgov_services_page',
      'offset' => 50,
      'limit' => 25,
    ]);

    $this->assertSame([
      ['type', Common::NODE_BUNDLES, 'IN'],
      ['type', 'localgov_services_page', NULL],
    ], $conditions);
    $this->assertTrue($result['success']);
    $this->assertCount(1, $result['data']);
    $this->assertSame(42, $result['data'][0]['id']);
  }

  /**
   * Unsupported bundles are rejected before any storage query.
   */
  public function testListRejectsUnsupportedBundle(): void {
    $manager = $this->createMock(EntityTypeManagerInterface::class);
    $manager->expects($this->never())->method('getStorage');
    $this->expectException(\InvalidArgumentException::class);
    $this->expectExceptionMessage('Unsupported content type');
    $this->operations($manager, $this->createStub(AccountProxyInterface::class))
      ->handle(['action' => 'list', 'bundle' => 'basic_page']);
  }

  /**
   * Builds the operation under test.
   */
  private function operations(EntityTypeManagerInterface $manager, AccountProxyInterface $account): ContentOperations {
    return new ContentOperations(
      new Common($manager, $account),
      $manager,
      $account,
      $this->createStub(StateTransitionValidationInterface::class),
      $this->createStub(ModerationInformationInterface::class),
      $this->createStub(TimeInterface::class),
      $this->createStub(ContentLockInterface::class),
    );
  }

}
