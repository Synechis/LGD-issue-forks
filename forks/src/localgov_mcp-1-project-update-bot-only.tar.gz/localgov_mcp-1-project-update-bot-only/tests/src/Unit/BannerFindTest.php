<?php

declare(strict_types=1);

namespace Drupal\Tests\localgov_mcp\Unit;

use PHPUnit\Framework\Attributes\Group;
use Drupal\Component\Datetime\TimeInterface;
use Drupal\content_moderation\ModerationInformationInterface;
use Drupal\content_moderation\StateTransitionValidationInterface;
use Drupal\Core\Entity\EntityStorageInterface;
use Drupal\Core\Entity\EntityTypeManagerInterface;
use Drupal\Core\Entity\Query\QueryInterface;
use Drupal\Core\Field\FieldItemList;
use Drupal\Core\Session\AccountProxyInterface;
use Drupal\localgov_alert_banner\Entity\AlertBannerEntityInterface;
use Drupal\localgov_mcp\BannerOperations;
use Drupal\localgov_mcp\Common;
use Drupal\localgov_mcp\SchedulingOperations;
use PHPUnit\Framework\Attributes\AllowMockObjectsWithoutExpectations;
use PHPUnit\Framework\TestCase;

/**
 * Tests banner listing and title search.
 *
 * @group localgov_mcp
 */
#[AllowMockObjectsWithoutExpectations]
#[Group('localgov_mcp')]
final class BannerFindTest extends TestCase {

  /**
   * Lists only viewable banners and applies pagination.
   */
  public function testListBanners(): void {
    [$operations, $query, $storage, $account] = $this->setupSearch();
    $conditions = [];
    $query->method('condition')->willReturnCallback(static function ($field, $value, $operator = NULL) use (&$conditions, $query) {
      $conditions[] = [$field, $value, $operator];
      return $query;
    });
    $query->expects($this->once())->method('range')->with(10, 5)->willReturnSelf();
    $query->method('execute')->willReturn([1 => 1, 2 => 2]);
    $visible = $this->createMock(AlertBannerEntityInterface::class);
    $visible->method('access')->with('view', $account)->willReturn(TRUE);
    $visible->method('id')->willReturn(1);
    $visible->method('bundle')->willReturn('localgov_alert_banner');
    $visible->method('label')->willReturn('Road closure');
    $visible->method('getRevisionId')->willReturn(3);
    $state = $this->createStub(FieldItemList::class);
    $state->method('__get')->willReturn('published');
    $visible->method('get')->with('moderation_state')->willReturn($state);
    $hidden = $this->createMock(AlertBannerEntityInterface::class);
    $hidden->method('access')->with('view', $account)->willReturn(FALSE);
    $hidden->expects($this->never())->method('label');
    $storage->method('loadMultiple')->willReturn([1 => $visible, 2 => $hidden]);

    $result = $operations->handle(['action' => 'list', 'offset' => 10, 'limit' => 5]);

    $this->assertSame([], $conditions);
    $this->assertSame([[
      'id' => 1,
      'type' => 'localgov_alert_banner',
      'title' => 'Road closure',
      'revision_id' => 3,
      'state' => 'published',
    ]], $result['data']);
  }

  /**
   * Search matches title text within the requested banner type.
   */
  public function testSearchByTitle(): void {
    [$operations, $query, $storage] = $this->setupSearch();
    $conditions = [];
    $query->method('condition')->willReturnCallback(static function ($field, $value, $operator = NULL) use (&$conditions, $query) {
      $conditions[] = [$field, $value, $operator];
      return $query;
    });
    $query->method('execute')->willReturn([]);
    $storage->method('loadMultiple')->willReturn([]);

    $result = $operations->handle([
      'action' => 'search',
      'bundle' => 'localgov_full_page',
      'query' => 'closure',
    ]);

    $this->assertSame([
      ['type', 'localgov_full_page', NULL],
      ['title', 'closure', 'CONTAINS'],
    ], $conditions);
    $this->assertSame(['success' => TRUE, 'data' => []], $result);
  }

  /**
   * Builds a banner operation with an access checked entity query.
   */
  private function setupSearch(): array {
    $entities = $this->createMock(EntityTypeManagerInterface::class);
    $storage = $this->createMock(EntityStorageInterface::class);
    $query = $this->createMock(QueryInterface::class);
    $account = $this->createStub(AccountProxyInterface::class);
    $entities->method('getStorage')->with('localgov_alert_banner')->willReturn($storage);
    $storage->method('getQuery')->willReturn($query);
    $query->expects($this->once())->method('accessCheck')->with(TRUE)->willReturnSelf();
    $query->method('sort')->willReturnSelf();
    $query->method('range')->willReturnSelf();
    $common = new Common($entities, $account);
    $transitions = $this->createStub(StateTransitionValidationInterface::class);
    $scheduler = new SchedulingOperations(
      $common, $account,
      $this->createStub(ModerationInformationInterface::class),
      $transitions,
      $this->createStub(TimeInterface::class),
    );
    return [new BannerOperations($common, $entities, $account, $transitions, $scheduler), $query, $storage, $account];
  }

}
