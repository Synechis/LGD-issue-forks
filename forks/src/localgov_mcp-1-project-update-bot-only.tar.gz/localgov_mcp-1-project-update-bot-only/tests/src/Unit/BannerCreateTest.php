<?php

declare(strict_types=1);

namespace Drupal\Tests\localgov_mcp\Unit;

use PHPUnit\Framework\Attributes\Group;
use Drupal\Component\Datetime\TimeInterface;
use Drupal\content_moderation\ModerationInformationInterface;
use Drupal\content_moderation\StateTransitionValidationInterface;
use Drupal\Core\Entity\EntityAccessControlHandlerInterface;
use Drupal\Core\Entity\EntityStorageInterface;
use Drupal\Core\Entity\EntityTypeManagerInterface;
use Drupal\Core\Field\FieldItemList;
use Drupal\Core\Session\AccountProxyInterface;
use Drupal\localgov_alert_banner\Entity\AlertBannerEntityInterface;
use Drupal\localgov_mcp\BannerOperations;
use Drupal\localgov_mcp\Common;
use Drupal\localgov_mcp\SchedulingOperations;
use PHPUnit\Framework\TestCase;
use Symfony\Component\Validator\ConstraintViolationList;

/**
 * Tests alert banner creation.
 *
 * @group localgov_mcp
 */
#[Group('localgov_mcp')]
final class BannerCreateTest extends TestCase {

  /**
   * A new alert starts unpublished and is validated before save.
   */
  public function testCreateUnpublishedBanner(): void {
    $entities = $this->createStub(EntityTypeManagerInterface::class);
    $storage = $this->createStub(EntityStorageInterface::class);
    $access = $this->createStub(EntityAccessControlHandlerInterface::class);
    $account = $this->createStub(AccountProxyInterface::class);
    $banner = $this->createMock(AlertBannerEntityInterface::class);
    $state = $this->createStub(FieldItemList::class);
    $entities->method('getStorage')->willReturn($storage);
    $entities->method('getAccessControlHandler')->willReturn($access);
    $access->method('createAccess')->willReturn(TRUE);
    $storage->method('create')->willReturn($banner);
    $banner->expects($this->once())->method('set')->with('moderation_state', 'unpublished');
    $banner->expects($this->once())->method('save');
    $banner->method('validate')->willReturn(new ConstraintViolationList());
    $banner->method('isNew')->willReturn(TRUE);
    $banner->method('id')->willReturn(12);
    $banner->method('bundle')->willReturn('localgov_alert_banner');
    $banner->method('label')->willReturn('Service disruption');
    $banner->method('getRevisionId')->willReturn(1);
    $banner->method('get')->willReturn($state);
    $state->method('__get')->willReturn('unpublished');

    $common = new Common($entities, $account);
    $transitions = $this->createStub(StateTransitionValidationInterface::class);
    $scheduler = new SchedulingOperations(
      $common, $account,
      $this->createStub(ModerationInformationInterface::class),
      $transitions,
      $this->createStub(TimeInterface::class),
    );
    $result = (new BannerOperations(
      $common, $entities, $account, $transitions, $scheduler,
    ))->handle(['action' => 'create', 'title' => 'Service disruption']);
    $this->assertTrue($result['success']);
    $this->assertSame('unpublished', $result['data']['state']);
    $this->assertSame(12, $result['data']['id']);
  }

}
