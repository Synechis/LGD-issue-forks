<?php

declare(strict_types=1);

namespace Drupal\Tests\localgov_mcp\Unit;

use PHPUnit\Framework\Attributes\Group;
use Drupal\Core\Config\ConfigFactoryInterface;
use Drupal\Core\Config\Config;
use Drupal\Core\CronInterface;
use Drupal\Core\Database\Connection;
use Drupal\Core\Session\AccountProxyInterface;
use Drupal\localgov_mcp\AdminOperations;
use PHPUnit\Framework\TestCase;
use PHPUnit\Framework\Attributes\AllowMockObjectsWithoutExpectations;

/**
 * Tests administrative permission boundaries.
 *
 * @coversDefaultClass \Drupal\localgov_mcp\AdminOperations
 * @group localgov_mcp
 */
#[AllowMockObjectsWithoutExpectations]
#[Group('localgov_mcp')]
final class AdminAccessTest extends TestCase {

  /**
   * Maintenance changes require site administration permission.
   */
  public function testMaintenanceDenied(): void {
    $database = $this->createMock(Connection::class);
    $config = $this->createMock(ConfigFactoryInterface::class);
    $account = $this->createMock(AccountProxyInterface::class);
    $cron = $this->createMock(CronInterface::class);
    $account->method('hasPermission')->with('administer site configuration')->willReturn(FALSE);
    $config->expects($this->never())->method('getEditable');
    $result = (new AdminOperations($database, $config, $account, $cron))->handle([
      'action' => 'maintenance',
      'enabled' => TRUE,
    ]);
    $this->assertFalse($result['success']);
  }

  /**
   * Report access alone cannot operate site maintenance.
   */
  public function testWatchdogDenied(): void {
    $database = $this->createMock(Connection::class);
    $database->expects($this->never())->method('select');
    $account = $this->createStub(AccountProxyInterface::class);
    $account->method('hasPermission')->willReturn(FALSE);
    $result = (new AdminOperations(
      $database,
      $this->createStub(ConfigFactoryInterface::class),
      $account,
      $this->createStub(CronInterface::class),
    ))->handle(['action' => 'watchdog']);
    $this->assertFalse($result['success']);
  }

  /**
   * An authorised account can enable maintenance mode.
   */
  public function testMaintenanceEnabled(): void {
    $config = $this->createMock(ConfigFactoryInterface::class);
    $editable = $this->createMock(Config::class);
    $account = $this->createStub(AccountProxyInterface::class);
    $account->method('hasPermission')->willReturn(TRUE);
    $config->expects($this->once())->method('getEditable')->with('system.maintenance')->willReturn($editable);
    $editable->expects($this->once())->method('set')->with('enabled', TRUE)->willReturnSelf();
    $editable->expects($this->once())->method('save');
    $result = (new AdminOperations(
      $this->createStub(Connection::class),
      $config,
      $account,
      $this->createStub(CronInterface::class),
    ))->handle(['action' => 'maintenance', 'enabled' => TRUE]);
    $this->assertTrue($result['success']);
    $this->assertTrue($result['data']['maintenance_enabled']);
  }

}
