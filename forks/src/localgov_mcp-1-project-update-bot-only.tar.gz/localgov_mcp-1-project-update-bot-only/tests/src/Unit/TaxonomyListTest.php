<?php

declare(strict_types=1);

namespace Drupal\Tests\localgov_mcp\Unit;

use PHPUnit\Framework\Attributes\Group;
use Drupal\Core\Entity\EntityStorageInterface;
use Drupal\Core\Entity\EntityTypeManagerInterface;
use Drupal\Core\Entity\Query\QueryInterface;
use Drupal\Core\Session\AccountProxyInterface;
use Drupal\localgov_mcp\Common;
use Drupal\localgov_mcp\TaxonomyOperations;
use Drupal\taxonomy\TermInterface;
use PHPUnit\Framework\TestCase;

/**
 * Tests taxonomy listing through entity access.
 *
 * @group localgov_mcp
 */
#[Group('localgov_mcp')]
final class TaxonomyListTest extends TestCase {

  /**
   * A list request returns only terms the caller can view.
   */
  public function testListFiltersTerms(): void {
    $entities = $this->createStub(EntityTypeManagerInterface::class);
    $storage = $this->createStub(EntityStorageInterface::class);
    $query = $this->createStub(QueryInterface::class);
    $account = $this->createStub(AccountProxyInterface::class);
    $visible = $this->createStub(TermInterface::class);
    $hidden = $this->createStub(TermInterface::class);
    $entities->method('getStorage')->willReturn($storage);
    $storage->method('getQuery')->willReturn($query);
    $query->method('accessCheck')->willReturnSelf();
    $query->method('condition')->willReturnSelf();
    $query->method('sort')->willReturnSelf();
    $query->method('range')->willReturnSelf();
    $query->method('execute')->willReturn([1, 2]);
    $storage->method('loadMultiple')->willReturn([$visible, $hidden]);
    $visible->method('access')->willReturn(TRUE);
    $visible->method('id')->willReturn(1);
    $visible->method('bundle')->willReturn('localgov_topic');
    $visible->method('label')->willReturn('Parks');
    $visible->method('getDescription')->willReturn('Parks and green spaces');
    $hidden->method('access')->willReturn(FALSE);

    $result = (new TaxonomyOperations(new Common($entities, $account), $entities, $account))->handle([
      'action' => 'list',
      'vocabulary' => 'localgov_topic',
    ]);
    $this->assertTrue($result['success']);
    $this->assertCount(1, $result['data']);
    $this->assertSame('Parks', $result['data'][0]['name']);
  }

}
