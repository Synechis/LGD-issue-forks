<?php

declare(strict_types=1);

namespace Drupal\Tests\localgov_mcp\Unit;

use PHPUnit\Framework\Attributes\Group;
use Drupal\Core\Entity\EntityStorageInterface;
use Drupal\Core\Entity\EntityTypeManagerInterface;
use Drupal\Core\Entity\Query\QueryInterface as EntityQueryInterface;
use Drupal\Core\Session\AccountProxyInterface;
use Drupal\Core\Url;
use Drupal\localgov_mcp\FallbackSearch;
use Drupal\localgov_mcp\SearchOperations;
use Drupal\media\MediaInterface;
use Drupal\node\NodeInterface;
use Drupal\search_api\IndexInterface;
use Drupal\search_api\Query\QueryInterface as SearchQueryInterface;
use Drupal\search_api\SearchApiException;
use PHPUnit\Framework\Attributes\AllowMockObjectsWithoutExpectations;
use PHPUnit\Framework\TestCase;
use Psr\Log\LoggerInterface;

/**
 * Tests search fallback when Search API cannot run.
 *
 * @group localgov_mcp
 */
#[AllowMockObjectsWithoutExpectations]
#[Group('localgov_mcp')]
final class SiteSearchFallbackTest extends TestCase {

  /**
   * Missing index falls back to accessible node and document media names.
   */
  public function testUnavailableIndexUsesEntityQueries(): void {
    $indexStorage = $this->createStub(EntityStorageInterface::class);
    $indexStorage->method('load')->willReturn(NULL);
    $nodeStorage = $this->createStub(EntityStorageInterface::class);
    $mediaStorage = $this->createStub(EntityStorageInterface::class);
    $nodeQuery = $this->createMock(EntityQueryInterface::class);
    $mediaQuery = $this->createMock(EntityQueryInterface::class);
    $conditions = [];
    foreach (['node' => $nodeQuery, 'media' => $mediaQuery] as $type => $query) {
      $query->expects($this->once())->method('accessCheck')->with(TRUE)->willReturnSelf();
      $query->method('condition')->willReturnCallback(static function ($field, $value, $operator = NULL) use (&$conditions, $query, $type) {
        $conditions[] = [$type, $field, $value, $operator];
        return $query;
      });
      $query->method('sort')->willReturnSelf();
      $query->expects($this->once())->method('range')->with(0, 2)->willReturnSelf();
    }
    $nodeQuery->method('execute')->willReturn([1 => 1, 2 => 2]);
    $mediaQuery->method('execute')->willReturn([3 => 3]);
    $nodeStorage->method('getQuery')->willReturn($nodeQuery);
    $mediaStorage->method('getQuery')->willReturn($mediaQuery);

    $account = $this->createStub(AccountProxyInterface::class);
    $account->method('hasPermission')->willReturn(TRUE);
    $node = $this->createStub(NodeInterface::class);
    $node->method('access')->willReturn(TRUE);
    $node->method('getChangedTime')->willReturn(100);
    $node->method('getEntityTypeId')->willReturn('node');
    $node->method('id')->willReturn(1);
    $node->method('label')->willReturn('Waste service');
    $nodeUrl = $this->createStub(Url::class);
    $nodeUrl->method('toString')->willReturn('https://example.test/waste');
    $node->method('toUrl')->willReturn($nodeUrl);
    $hidden = $this->createMock(NodeInterface::class);
    $hidden->method('access')->willReturn(FALSE);
    $hidden->expects($this->never())->method('toUrl');
    $nodeStorage->method('loadMultiple')->willReturn([1 => $node, 2 => $hidden]);

    $media = $this->createStub(MediaInterface::class);
    $media->method('access')->willReturn(TRUE);
    $media->method('getChangedTime')->willReturn(200);
    $media->method('getEntityTypeId')->willReturn('media');
    $media->method('id')->willReturn(3);
    $media->method('label')->willReturn('Waste guide');
    $mediaUrl = $this->createStub(Url::class);
    $mediaUrl->method('toString')->willReturn('https://example.test/media/3');
    $media->method('toUrl')->willReturn($mediaUrl);
    $mediaStorage->method('loadMultiple')->willReturn([3 => $media]);

    $manager = $this->manager([
      'search_api_index' => $indexStorage,
      'node' => $nodeStorage,
      'media' => $mediaStorage,
    ]);
    $response = $this->search($manager, $account, $this->createStub(LoggerInterface::class))
      ->handle(['query' => 'waste', 'limit' => 2]);

    $this->assertSame([
      ['node', 'title', 'waste', 'CONTAINS'],
      ['media', 'name', 'waste', 'CONTAINS'],
      ['media', 'bundle', 'document', NULL],
    ], $conditions);
    $this->assertTrue($response['success']);
    $this->assertSame('entity_query', $response['source']);
    $this->assertStringContainsString('title and document media name', $response['message']);
    $this->assertSame(['media', 'node'], array_column($response['data'], 'entity_type'));
  }

  /**
   * A failed backend query also reaches the entity fallback.
   */
  public function testBackendExceptionFallsBack(): void {
    $indexStorage = $this->createStub(EntityStorageInterface::class);
    $index = $this->createStub(IndexInterface::class);
    $query = $this->createStub(SearchQueryInterface::class);
    $indexStorage->method('load')->willReturn($index);
    $index->method('status')->willReturn(TRUE);
    $index->method('query')->willReturn($query);
    $query->method('keys')->willReturnSelf();
    $query->method('range')->willReturnSelf();
    $query->method('execute')->willThrowException(new SearchApiException('Backend unavailable'));
    $logger = $this->createMock(LoggerInterface::class);
    $logger->expects($this->once())->method('warning');
    $account = $this->createStub(AccountProxyInterface::class);
    $account->method('hasPermission')->willReturn(TRUE);
    $manager = $this->manager([
      'search_api_index' => $indexStorage,
      'node' => $this->emptyStorage(),
      'media' => $this->emptyStorage(),
    ]);

    $response = $this->search($manager, $account, $logger)->handle(['query' => 'waste']);
    $this->assertTrue($response['success']);
    $this->assertSame('entity_query', $response['source']);
    $this->assertSame([], $response['data']);
    $this->assertStringContainsString('Search API failed', $response['message']);
  }

  /**
   * Reports a failure if both the index and entity storage are unavailable.
   */
  public function testBothSourcesFail(): void {
    $indexStorage = $this->createStub(EntityStorageInterface::class);
    $indexStorage->method('load')->willReturn(NULL);
    $nodeStorage = $this->createStub(EntityStorageInterface::class);
    $nodeStorage->method('getQuery')->willThrowException(new \RuntimeException('Database unavailable'));
    $logger = $this->createMock(LoggerInterface::class);
    $logger->expects($this->once())->method('error');
    $account = $this->createStub(AccountProxyInterface::class);
    $account->method('hasPermission')->willReturn(TRUE);
    $manager = $this->manager([
      'search_api_index' => $indexStorage,
      'node' => $nodeStorage,
    ]);

    $response = $this->search($manager, $account, $logger)->handle(['query' => 'waste']);
    $this->assertFalse($response['success']);
    $this->assertStringContainsString('fallback are unavailable', $response['message']);
  }

  /**
   * Builds an entity manager restricted to the supplied storages.
   */
  private function manager(array $storages): EntityTypeManagerInterface {
    $manager = $this->createStub(EntityTypeManagerInterface::class);
    $manager->method('getStorage')->willReturnCallback(static fn(string $type) => $storages[$type]);
    return $manager;
  }

  /**
   * Provides a storage with no matches.
   */
  private function emptyStorage(): EntityStorageInterface {
    $storage = $this->createStub(EntityStorageInterface::class);
    $query = $this->createStub(EntityQueryInterface::class);
    $query->method('accessCheck')->willReturnSelf();
    $query->method('condition')->willReturnSelf();
    $query->method('sort')->willReturnSelf();
    $query->method('range')->willReturnSelf();
    $query->method('execute')->willReturn([]);
    $storage->method('getQuery')->willReturn($query);
    $storage->method('loadMultiple')->willReturn([]);
    return $storage;
  }

  /**
   * Creates the search service with the real fallback implementation.
   */
  private function search(EntityTypeManagerInterface $manager, AccountProxyInterface $account, LoggerInterface $logger): SearchOperations {
    return new SearchOperations($manager, $account, new FallbackSearch($manager, $account), $logger);
  }

}
