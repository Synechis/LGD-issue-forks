<?php

declare(strict_types=1);

namespace Drupal\Tests\localgov_mcp\Unit;

use PHPUnit\Framework\Attributes\Group;
use Drupal\Core\Config\ConfigFactoryInterface;
use Drupal\Core\Config\ImmutableConfig;
use Drupal\Core\Session\AccountProxyInterface;
use Drupal\Core\StringTranslation\TranslatableMarkup;
use Drupal\localgov_mcp\Plugin\mcp_server\Tool\Banner;
use Drupal\mcp_server\Definition\ToolDefinition;
use PHPUnit\Framework\Attributes\AllowMockObjectsWithoutExpectations;
use PHPUnit\Framework\TestCase;

/**
 * Tests module configuration of tool availability.
 *
 * @group localgov_mcp
 */
#[AllowMockObjectsWithoutExpectations]
#[Group('localgov_mcp')]
final class ToolEnablementTest extends TestCase {

  /**
   * Tools remain enabled by default and can be disabled individually.
   */
  public function testToolEnablement(): void {
    $settings = $this->createMock(ImmutableConfig::class);
    $factory = $this->createMock(ConfigFactoryInterface::class);
    $factory->method('get')->with('localgov_mcp.settings')->willReturn($settings);
    $definition = new ToolDefinition(
      'localgov_banner',
      new TranslatableMarkup('Manage alert banners'),
      new TranslatableMarkup('Banner operations'),
    );
    $tool = new Banner(
      [],
      'localgov_banner',
      $definition,
      $this->createStub(AccountProxyInterface::class),
      new \stdClass(),
      $factory,
    );

    $settings->method('get')->with('disabled_tools')->willReturnOnConsecutiveCalls(NULL, ['localgov_media'], ['localgov_banner']);
    $this->assertTrue($tool->isEnabled());
    $this->assertTrue($tool->isEnabled());
    $this->assertFalse($tool->isEnabled());
  }

}
