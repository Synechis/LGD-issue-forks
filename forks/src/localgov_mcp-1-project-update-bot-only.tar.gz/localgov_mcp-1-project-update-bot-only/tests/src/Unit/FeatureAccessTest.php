<?php

declare(strict_types=1);

namespace Drupal\Tests\localgov_mcp\Unit;

use PHPUnit\Framework\Attributes\Group;
use Drupal\Component\Datetime\TimeInterface;
use Drupal\content_moderation\ModerationInformationInterface;
use Drupal\content_moderation\StateTransitionValidationInterface;
use Drupal\Core\Entity\EntityAccessControlHandlerInterface;
use Drupal\Core\Entity\EntityStorageInterface;
use Drupal\Core\Entity\EntityTypeManagerInterface;
use Drupal\Core\File\FileSystemInterface;
use Drupal\Core\Session\AccountProxyInterface;
use Drupal\file\FileRepositoryInterface;
use Drupal\localgov_mcp\BannerOperations;
use Drupal\localgov_mcp\Common;
use Drupal\localgov_mcp\LocationOperations;
use Drupal\localgov_mcp\MediaOperations;
use Drupal\localgov_mcp\SchedulingOperations;
use Drupal\localgov_mcp\TaxonomyOperations;
use PHPUnit\Framework\TestCase;
use PHPUnit\Framework\Attributes\AllowMockObjectsWithoutExpectations;

/**
 * Checks create permissions across the supported entity types.
 *
 * @group localgov_mcp
 */
#[AllowMockObjectsWithoutExpectations]
#[Group('localgov_mcp')]
final class FeatureAccessTest extends TestCase {

  /**
   * Media upload cannot create an image without bundle create access.
   */
  public function testMediaCreateDenied(): void {
    [$common, $entities, $account] = $this->deniedCreate('media');
    $result = (new MediaOperations(
      $common, $entities, $account,
      $this->createStub(FileSystemInterface::class),
      $this->createStub(FileRepositoryInterface::class),
    ))->handle(['action' => 'upload', 'bundle' => 'image']);
    $this->assertFalse($result['success']);
  }

  /**
   * Address creation needs geo entity create access.
   */
  public function testLocationCreateDenied(): void {
    [$common, $entities, $account] = $this->deniedCreate('geo_entity');
    $result = (new LocationOperations($common, $entities, $account))->handle([
      'action' => 'add',
      'fields' => ['postal_address' => ['country_code' => 'GB']],
    ]);
    $this->assertFalse($result['success']);
  }

  /**
   * Term creation needs the vocabulary's create access.
   */
  public function testTermCreateDenied(): void {
    [$common, $entities, $account] = $this->deniedCreate('taxonomy_term');
    $result = (new TaxonomyOperations($common, $entities, $account))->handle([
      'action' => 'add',
      'vocabulary' => 'localgov_topic',
      'name' => 'Parks',
    ]);
    $this->assertFalse($result['success']);
  }

  /**
   * Banner creation needs bundle create access.
   */
  public function testBannerCreateDenied(): void {
    [$common, $entities, $account] = $this->deniedCreate('localgov_alert_banner');
    $scheduling = new SchedulingOperations(
      $common, $account,
      $this->createStub(ModerationInformationInterface::class),
      $this->createStub(StateTransitionValidationInterface::class),
      $this->createStub(TimeInterface::class),
    );
    $result = (new BannerOperations(
      $common, $entities, $account,
      $this->createStub(StateTransitionValidationInterface::class),
      $scheduling,
    ))->handle(['action' => 'create', 'title' => 'Service disruption']);
    $this->assertFalse($result['success']);
  }

  /**
   * Scheduling rejects a date without an explicit timezone.
   */
  public function testScheduleRequiresIsoTimezone(): void {
    $entities = $this->createMock(EntityTypeManagerInterface::class);
    $entities->expects($this->never())->method('getStorage');
    $account = $this->createStub(AccountProxyInterface::class);
    $scheduler = new SchedulingOperations(
      new Common($entities, $account), $account,
      $this->createStub(ModerationInformationInterface::class),
      $this->createStub(StateTransitionValidationInterface::class),
      $this->createStub(TimeInterface::class),
    );
    $this->expectException(\InvalidArgumentException::class);
    $scheduler->handle([
      'entity_type' => 'node',
      'id' => 42,
      'state' => 'published',
      'at' => 'tomorrow',
    ]);
  }

  /**
   * Builds entity services whose create access is denied.
   */
  private function deniedCreate(string $type): array {
    $entities = $this->createMock(EntityTypeManagerInterface::class);
    $storage = $this->createMock(EntityStorageInterface::class);
    $access = $this->createStub(EntityAccessControlHandlerInterface::class);
    $account = $this->createStub(AccountProxyInterface::class);
    $entities->method('getStorage')->with($type)->willReturn($storage);
    $entities->method('getAccessControlHandler')->with($type)->willReturn($access);
    $access->method('createAccess')->willReturn(FALSE);
    $storage->expects($this->never())->method('create');
    return [new Common($entities, $account), $entities, $account];
  }

}
