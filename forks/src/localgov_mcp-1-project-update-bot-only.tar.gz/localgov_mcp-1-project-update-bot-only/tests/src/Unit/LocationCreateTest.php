<?php

declare(strict_types=1);

namespace Drupal\Tests\localgov_mcp\Unit;

use PHPUnit\Framework\Attributes\Group;
use Drupal\Core\Entity\EntityAccessControlHandlerInterface;
use Drupal\Core\Entity\EntityStorageInterface;
use Drupal\Core\Entity\EntityTypeManagerInterface;
use Drupal\Core\Field\FieldDefinitionInterface;
use Drupal\Core\Field\FieldItemListInterface;
use Drupal\Core\Field\FieldStorageDefinitionInterface;
use Drupal\Core\Session\AccountProxyInterface;
use Drupal\geo_entity\Entity\GeoEntity;
use Drupal\localgov_mcp\Common;
use Drupal\localgov_mcp\LocationOperations;
use PHPUnit\Framework\TestCase;
use Symfony\Component\Validator\ConstraintViolationList;

/**
 * Tests address location creation.
 *
 * @group localgov_mcp
 */
#[Group('localgov_mcp')]
final class LocationCreateTest extends TestCase {

  /**
   * A permitted address is assigned to the correct field and saved.
   */
  public function testAddAddress(): void {
    $entities = $this->createStub(EntityTypeManagerInterface::class);
    $storage = $this->createStub(EntityStorageInterface::class);
    $access = $this->createStub(EntityAccessControlHandlerInterface::class);
    $account = $this->createStub(AccountProxyInterface::class);
    $definition = $this->createStub(FieldDefinitionInterface::class);
    $field_storage = $this->createStub(FieldStorageDefinitionInterface::class);
    $field = $this->createStub(FieldItemListInterface::class);
    $location = $this->createMock(GeoEntity::class);
    $address = ['country_code' => 'GB', 'locality' => 'Haywards Heath'];

    $entities->method('getStorage')->willReturn($storage);
    $entities->method('getAccessControlHandler')->willReturn($access);
    $access->method('createAccess')->willReturn(TRUE);
    $storage->method('create')->willReturn($location);
    $location->method('hasField')->willReturn(TRUE);
    $location->method('getFieldDefinition')->willReturn($definition);
    $definition->method('getFieldStorageDefinition')->willReturn($field_storage);
    $field_storage->method('isBaseField')->willReturn(FALSE);
    $location->method('get')->willReturn($field);
    $field->method('access')->willReturn(TRUE);
    $field->method('getFieldDefinition')->willReturn($definition);
    $location->expects($this->once())->method('set')->with('postal_address', $address);
    $location->expects($this->once())->method('save');
    $location->method('validate')->willReturn(new ConstraintViolationList());
    $location->method('id')->willReturn(5);
    $location->method('bundle')->willReturn('address');
    $location->method('label')->willReturn('Haywards Heath');
    $location->method('getRevisionId')->willReturn(1);

    $result = (new LocationOperations(new Common($entities, $account), $entities, $account))->handle([
      'action' => 'add',
      'fields' => ['postal_address' => $address],
    ]);
    $this->assertTrue($result['success']);
    $this->assertSame(5, $result['data']['id']);
  }

}
