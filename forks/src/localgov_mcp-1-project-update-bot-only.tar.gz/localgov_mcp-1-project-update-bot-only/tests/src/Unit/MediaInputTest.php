<?php

declare(strict_types=1);

namespace Drupal\Tests\localgov_mcp\Unit;

use PHPUnit\Framework\Attributes\Group;
use Drupal\Core\Entity\EntityTypeManagerInterface;
use Drupal\Core\Entity\EntityStorageInterface;
use Drupal\Core\Entity\EntityAccessControlHandlerInterface;
use Drupal\Core\Field\FieldItemListInterface;
use Drupal\Core\File\FileSystemInterface;
use Drupal\Core\Session\AccountProxyInterface;
use Drupal\file\FileRepositoryInterface;
use Drupal\localgov_mcp\Common;
use Drupal\localgov_mcp\MediaOperations;
use Drupal\media\MediaInterface;
use PHPUnit\Framework\TestCase;
use Symfony\Component\Validator\ConstraintViolationList;

/**
 * Tests media source input restrictions.
 *
 * @group localgov_mcp
 */
#[Group('localgov_mcp')]
final class MediaInputTest extends TestCase {

  /**
   * A caller must use the validated upload arguments for source fields.
   */
  public function testSourceFieldCannotBypassUpload(): void {
    $manager = $this->createStub(EntityTypeManagerInterface::class);
    $account = $this->createStub(AccountProxyInterface::class);
    $operations = new MediaOperations(
      new Common($manager, $account),
      $manager,
      $account,
      $this->createStub(FileSystemInterface::class),
      $this->createStub(FileRepositoryInterface::class),
    );
    $this->expectException(\InvalidArgumentException::class);
    $operations->handle([
      'action' => 'upload',
      'bundle' => 'document',
      'fields' => ['field_media_document' => ['target_id' => 5]],
    ]);
  }

  /**
   * An allowed remote video is validated and saved as media.
   */
  public function testRemoteVideoUpload(): void {
    $manager = $this->createStub(EntityTypeManagerInterface::class);
    $storage = $this->createStub(EntityStorageInterface::class);
    $access = $this->createStub(EntityAccessControlHandlerInterface::class);
    $account = $this->createStub(AccountProxyInterface::class);
    $field = $this->createStub(FieldItemListInterface::class);
    $media = $this->createMock(MediaInterface::class);
    $manager->method('getStorage')->willReturn($storage);
    $manager->method('getAccessControlHandler')->willReturn($access);
    $access->method('createAccess')->willReturn(TRUE);
    $storage->method('create')->willReturn($media);
    $field->method('access')->willReturn(TRUE);
    $media->method('get')->willReturn($field);
    $media->expects($this->once())->method('set')->with(
      'field_media_oembed_video', 'https://www.youtube.com/watch?v=abc',
    );
    $media->expects($this->once())->method('save');
    $media->method('validate')->willReturn(new ConstraintViolationList());
    $media->method('id')->willReturn(9);
    $media->method('bundle')->willReturn('remote_video');
    $media->method('label')->willReturn('Council meeting');
    $media->method('getRevisionId')->willReturn(1);

    $result = (new MediaOperations(
      new Common($manager, $account), $manager, $account,
      $this->createStub(FileSystemInterface::class),
      $this->createStub(FileRepositoryInterface::class),
    ))->handle([
      'action' => 'upload',
      'bundle' => 'remote_video',
      'name' => 'Council meeting',
      'remote_url' => 'https://www.youtube.com/watch?v=abc',
    ]);
    $this->assertTrue($result['success']);
    $this->assertSame(9, $result['data']['id']);
  }

}
