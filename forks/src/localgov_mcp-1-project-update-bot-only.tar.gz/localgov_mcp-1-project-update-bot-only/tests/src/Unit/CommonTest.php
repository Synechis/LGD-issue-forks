<?php

declare(strict_types=1);

namespace Drupal\Tests\localgov_mcp\Unit;

use PHPUnit\Framework\Attributes\Group;
use Drupal\Core\Entity\ContentEntityInterface;
use Drupal\Core\Entity\EntityTypeManagerInterface;
use Drupal\Core\Field\FieldItemListInterface;
use Drupal\Core\Field\FieldDefinitionInterface;
use Drupal\Core\Field\FieldStorageDefinitionInterface;
use Drupal\Core\Session\AccountProxyInterface;
use Drupal\localgov_mcp\Common;
use PHPUnit\Framework\TestCase;
use PHPUnit\Framework\Attributes\AllowMockObjectsWithoutExpectations;

/**
 * Tests the shared input and field safety rules.
 *
 * @coversDefaultClass \Drupal\localgov_mcp\Common
 * @group localgov_mcp
 */
#[AllowMockObjectsWithoutExpectations]
#[Group('localgov_mcp')]
final class CommonTest extends TestCase {

  /**
   * Unsupported bundles and missing values are rejected.
   */
  public function testInputValidation(): void {
    $this->assertSame(50, Common::limit(['limit' => 500]));
    $this->assertSame(1, Common::limit(['limit' => -8]));
    $this->assertSame('draft', Common::required(['state' => ' draft '], 'state'));
    $this->expectException(\InvalidArgumentException::class);
    Common::allowed('basic_page', Common::NODE_BUNDLES, 'content type');
  }

  /**
   * Base fields cannot be changed through the generic field input.
   */
  public function testBaseFieldsAreRejected(): void {
    $manager = $this->createMock(EntityTypeManagerInterface::class);
    $account = $this->createMock(AccountProxyInterface::class);
    $entity = $this->createMock(ContentEntityInterface::class);
    $definition = $this->createMock(FieldDefinitionInterface::class);
    $storage = $this->createMock(FieldStorageDefinitionInterface::class);
    $entity->method('hasField')->with('uid')->willReturn(TRUE);
    $entity->method('getFieldDefinition')->with('uid')->willReturn($definition);
    $definition->method('getFieldStorageDefinition')->willReturn($storage);
    $storage->method('isBaseField')->willReturn(TRUE);

    $this->expectException(\InvalidArgumentException::class);
    (new Common($manager, $account))->fields($entity, ['uid' => 1]);
  }

  /**
   * Field access is checked before assigning a configurable value.
   */
  public function testInaccessibleFieldIsRejected(): void {
    $manager = $this->createStub(EntityTypeManagerInterface::class);
    $account = $this->createStub(AccountProxyInterface::class);
    $entity = $this->createMock(ContentEntityInterface::class);
    $definition = $this->createStub(FieldDefinitionInterface::class);
    $storage = $this->createStub(FieldStorageDefinitionInterface::class);
    $field = $this->createStub(FieldItemListInterface::class);
    $entity->method('hasField')->willReturn(TRUE);
    $entity->method('getFieldDefinition')->willReturn($definition);
    $entity->method('get')->willReturn($field);
    $definition->method('getFieldStorageDefinition')->willReturn($storage);
    $storage->method('isBaseField')->willReturn(FALSE);
    $field->method('access')->willReturn(FALSE);
    $entity->expects($this->never())->method('set');

    $this->expectException(\InvalidArgumentException::class);
    (new Common($manager, $account))->fields($entity, ['field_secret' => 'value']);
  }

}
