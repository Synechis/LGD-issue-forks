<?php

declare(strict_types=1);

namespace Drupal\Tests\localgov_mcp\Unit;

use PHPUnit\Framework\Attributes\Group;
use Drupal\content_lock\ContentLock\ContentLockInterface;
use Drupal\content_moderation\StateTransitionValidationInterface;
use Drupal\Core\Entity\EntityStorageInterface;
use Drupal\Core\Entity\EntityTypeManagerInterface;
use Drupal\Core\Field\FieldItemListInterface;
use Drupal\Core\Session\AccountProxyInterface;
use Drupal\localgov_mcp\Common;
use Drupal\localgov_mcp\MetatagOperations;
use Drupal\metatag\MetatagManager;
use Drupal\node\NodeInterface;
use PHPUnit\Framework\TestCase;

/**
 * Tests page title and description retrieval.
 *
 * @group localgov_mcp
 */
#[Group('localgov_mcp')]
final class MetatagReadTest extends TestCase {

  /**
   * Page metadata includes both configured templates and rendered values.
   */
  public function testGetMetadata(): void {
    $entities = $this->createStub(EntityTypeManagerInterface::class);
    $storage = $this->createStub(EntityStorageInterface::class);
    $account = $this->createStub(AccountProxyInterface::class);
    $node = $this->createStub(NodeInterface::class);
    $entities->method('getStorage')->willReturn($storage);
    $storage->method('load')->willReturn($node);
    $node->method('bundle')->willReturn('localgov_services_page');
    $node->method('hasField')->willReturn(TRUE);
    $node->method('access')->willReturn(TRUE);
    $node->method('get')->willReturn($this->createStub(FieldItemListInterface::class));
    $node->method('getRevisionId')->willReturn(9);
    $node->method('label')->willReturn('Service page');
    $metatags = $this->createStub(MetatagManager::class);
    $metatags->method('tagsFromEntityWithDefaults')->willReturn([
      'title' => '[current-page:title] | [site:name]',
      'description' => 'Useful services',
    ]);
    $metatags->method('generateTokenValues')->willReturnCallback(function (array $tags) {
      $this->assertSame('Service page | [site:name]', $tags['title']);
      return [
        'title' => 'Service page | Council',
        'description' => 'Useful services',
      ];
    });
    $result = (new MetatagOperations(
      new Common($entities, $account),
      $account,
      $metatags,
      $this->createStub(StateTransitionValidationInterface::class),
      $this->createStub(ContentLockInterface::class),
    ))->handle(['action' => 'get', 'id' => 42]);

    $this->assertTrue($result['success']);
    $this->assertSame('Service page | Council', $result['data']['title']['rendered']);
    $this->assertSame('Useful services', $result['data']['description']['rendered']);
    $this->assertSame(9, $result['data']['revision_id']);
  }

}
