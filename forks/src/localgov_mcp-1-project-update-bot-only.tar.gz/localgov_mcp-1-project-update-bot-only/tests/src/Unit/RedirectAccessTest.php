<?php

declare(strict_types=1);

namespace Drupal\Tests\localgov_mcp\Unit;

use PHPUnit\Framework\Attributes\Group;
use Drupal\Core\Database\Connection;
use Drupal\Core\Entity\EntityTypeManagerInterface;
use Drupal\Core\Entity\EntityStorageInterface;
use Drupal\Core\Entity\EntityAccessControlHandlerInterface;
use Drupal\Core\Session\AccountProxyInterface;
use Drupal\Core\Url;
use Drupal\localgov_mcp\RedirectOperations;
use Drupal\redirect\Entity\Redirect;
use Drupal\redirect_404\RedirectNotFoundStorageInterface;
use PHPUnit\Framework\TestCase;
use Symfony\Component\Validator\ConstraintViolationList;

/**
 * Tests redirect administration access.
 *
 * @coversDefaultClass \Drupal\localgov_mcp\RedirectOperations
 * @group localgov_mcp
 */
#[Group('localgov_mcp')]
final class RedirectAccessTest extends TestCase {

  /**
   * Redirect listing is restricted to redirect administrators.
   */
  public function testListDenied(): void {
    $manager = $this->createMock(EntityTypeManagerInterface::class);
    $manager->expects($this->never())->method('getStorage');
    $account = $this->createStub(AccountProxyInterface::class);
    $account->method('hasPermission')->willReturn(FALSE);
    $result = (new RedirectOperations(
      $manager,
      $this->createStub(Connection::class),
      $account,
      $this->createStub(RedirectNotFoundStorageInterface::class),
    ))->handle(['action' => 'list']);
    $this->assertFalse($result['success']);
  }

  /**
   * A source URL cannot point to an external origin.
   */
  public function testExternalSourceRejected(): void {
    $manager = $this->createMock(EntityTypeManagerInterface::class);
    $storage = $this->createStub(EntityStorageInterface::class);
    $access = $this->createStub(EntityAccessControlHandlerInterface::class);
    $account = $this->createStub(AccountProxyInterface::class);
    $redirect = $this->createMock(Redirect::class);
    $manager->method('getStorage')->with('redirect')->willReturn($storage);
    $manager->method('getAccessControlHandler')->with('redirect')->willReturn($access);
    $storage->method('create')->willReturn($redirect);
    $access->method('createAccess')->willReturn(TRUE);
    $account->method('hasPermission')->willReturn(TRUE);
    $redirect->expects($this->never())->method('save');

    $operations = new RedirectOperations(
      $manager,
      $this->createStub(Connection::class),
      $account,
      $this->createStub(RedirectNotFoundStorageInterface::class),
    );
    $this->expectException(\InvalidArgumentException::class);
    $operations->handle([
      'action' => 'add',
      'source' => 'https://other.example/old',
      'destination' => '/new',
    ]);
  }

  /**
   * A local redirect preserves source query arguments and defaults to 301.
   */
  public function testAddRedirectWithSourceQuery(): void {
    $manager = $this->createStub(EntityTypeManagerInterface::class);
    $storage = $this->createMock(EntityStorageInterface::class);
    $access = $this->createStub(EntityAccessControlHandlerInterface::class);
    $account = $this->createStub(AccountProxyInterface::class);
    $redirect = $this->createMock(Redirect::class);
    $url = $this->createStub(Url::class);
    $manager->method('getStorage')->willReturn($storage);
    $manager->method('getAccessControlHandler')->willReturn($access);
    $access->method('createAccess')->willReturn(TRUE);
    $account->method('hasPermission')->willReturn(TRUE);
    $storage->expects($this->once())->method('create')->with([
      'type' => 'redirect',
      'language' => 'und',
      'status_code' => 301,
    ])->willReturn($redirect);
    $redirect->expects($this->once())->method('setSource')->with('old', ['campaign' => 'autumn']);
    $redirect->expects($this->once())->method('setRedirect')->with('/new');
    $redirect->expects($this->once())->method('save');
    $redirect->method('validate')->willReturn(new ConstraintViolationList());
    $redirect->method('id')->willReturn(15);
    $redirect->method('getSourcePathWithQuery')->willReturn('/old?campaign=autumn');
    $redirect->method('getRedirectUrl')->willReturn($url);
    $redirect->method('getStatusCode')->willReturn(301);
    $redirect->method('isPublished')->willReturn(TRUE);
    $url->method('toString')->willReturn('/new');

    $result = (new RedirectOperations(
      $manager,
      $this->createStub(Connection::class),
      $account,
      $this->createStub(RedirectNotFoundStorageInterface::class),
    ))->handle([
      'action' => 'add',
      'source' => '/old?campaign=autumn',
      'destination' => '/new',
    ]);
    $this->assertTrue($result['success']);
    $this->assertSame(15, $result['data']['id']);
    $this->assertSame(301, $result['data']['status_code']);
  }

}
