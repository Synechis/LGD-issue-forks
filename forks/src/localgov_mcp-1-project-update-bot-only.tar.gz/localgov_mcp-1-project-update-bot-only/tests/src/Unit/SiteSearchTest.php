<?php

declare(strict_types=1);

namespace Drupal\Tests\localgov_mcp\Unit;

use PHPUnit\Framework\Attributes\Group;
use Drupal\Core\Entity\EntityStorageInterface;
use Drupal\Core\Entity\EntityTypeManagerInterface;
use Drupal\Core\Session\AccountProxyInterface;
use Drupal\Core\TypedData\ComplexDataInterface;
use Drupal\Core\Url;
use Drupal\localgov_mcp\FallbackSearch;
use Drupal\localgov_mcp\SearchOperations;
use Drupal\node\NodeInterface;
use Drupal\search_api\IndexInterface;
use Drupal\search_api\Item\ItemInterface;
use Drupal\search_api\Query\QueryInterface;
use Drupal\search_api\Query\ResultSetInterface;
use PHPUnit\Framework\TestCase;
use Psr\Log\LoggerInterface;

/**
 * Tests indexed site search result filtering.
 *
 * @group localgov_mcp
 */
#[Group('localgov_mcp')]
final class SiteSearchTest extends TestCase {

  /**
   * Only viewable indexed entities are returned.
   */
  public function testSearchFiltersInaccessibleResults(): void {
    $entities = $this->createStub(EntityTypeManagerInterface::class);
    $storage = $this->createStub(EntityStorageInterface::class);
    $index = $this->createStub(IndexInterface::class);
    $query = $this->createStub(QueryInterface::class);
    $result = $this->createStub(ResultSetInterface::class);
    $account = $this->createStub(AccountProxyInterface::class);
    $item = $this->createStub(ItemInterface::class);
    $object = $this->createStub(ComplexDataInterface::class);
    $node = $this->createStub(NodeInterface::class);
    $url = $this->createStub(Url::class);

    $account->method('hasPermission')->willReturn(TRUE);
    $entities->method('getStorage')->willReturn($storage);
    $storage->method('load')->willReturn($index);
    $index->method('status')->willReturn(TRUE);
    $index->method('query')->willReturn($query);
    $query->method('keys')->willReturnSelf();
    $query->method('range')->willReturnSelf();
    $query->method('execute')->willReturn($result);
    $result->method('getResultItems')->willReturn([$item]);
    $item->method('getOriginalObject')->willReturn($object);
    $object->method('getValue')->willReturn($node);
    $node->method('access')->willReturn(TRUE);
    $node->method('getEntityTypeId')->willReturn('node');
    $node->method('id')->willReturn(42);
    $node->method('label')->willReturn('Service page');
    $node->method('toUrl')->willReturn($url);
    $url->method('toString')->willReturn('https://example.test/services/page');

    $search = new SearchOperations(
      $entities, $account, new FallbackSearch($entities, $account),
      $this->createStub(LoggerInterface::class),
    );
    $found = $search->handle(['query' => 'service']);
    $this->assertTrue($found['success']);
    $this->assertSame('search_api', $found['source']);
    $this->assertSame(42, $found['data'][0]['id']);
    $this->assertSame('Service page', $found['data'][0]['title']);
  }

}
