<?php

/**
 * @file
 * Loads Drupal classes needed by the module's isolated unit suite.
 */

declare(strict_types=1);

$loader = require dirname(__DIR__, 5) . '/vendor/autoload.php';
$loader->addPsr4('Drupal\\localgov_mcp\\', dirname(__DIR__) . '/src');
$loader->addPsr4('Drupal\\Tests\\localgov_mcp\\', __DIR__ . '/src');
$loader->addPsr4('Drupal\\content_moderation\\', dirname(__DIR__, 4) . '/core/modules/content_moderation/src');
$loader->addPsr4('Drupal\\node\\', dirname(__DIR__, 4) . '/core/modules/node/src');
$loader->addPsr4('Drupal\\user\\', dirname(__DIR__, 4) . '/core/modules/user/src');
$loader->addPsr4('Drupal\\file\\', dirname(__DIR__, 4) . '/core/modules/file/src');
$loader->addPsr4('Drupal\\content_lock\\', dirname(__DIR__, 3) . '/contrib/content_lock/src');
$loader->addPsr4('Drupal\\redirect_404\\', dirname(__DIR__, 3) . '/contrib/redirect/modules/redirect_404/src');
$loader->addPsr4('Drupal\\redirect\\', dirname(__DIR__, 3) . '/contrib/redirect/src');
$loader->addPsr4('Drupal\\mcp_server\\', dirname(__DIR__, 3) . '/contrib/mcp_server/src');
$loader->addPsr4('Drupal\\metatag\\', dirname(__DIR__, 3) . '/contrib/metatag/src');
$loader->addPsr4('Drupal\\search_api\\', dirname(__DIR__, 3) . '/contrib/search_api/src');
$loader->addPsr4('Drupal\\taxonomy\\', dirname(__DIR__, 4) . '/core/modules/taxonomy/src');
$loader->addPsr4('Drupal\\media\\', dirname(__DIR__, 4) . '/core/modules/media/src');
$loader->addPsr4('Drupal\\geo_entity\\', dirname(__DIR__, 3) . '/contrib/geo_entity/src');
$loader->addPsr4('Drupal\\localgov_alert_banner\\', dirname(__DIR__, 3) . '/contrib/localgov_alert_banner/src');
