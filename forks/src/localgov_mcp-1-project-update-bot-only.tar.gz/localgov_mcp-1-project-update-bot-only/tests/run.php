<?php

/**
 * @file
 * Runs the module tests without the project's incompatible PHPUnit preload.
 */

declare(strict_types=1);

use PHPUnit\TextUI\Application;

require dirname(__DIR__, 5) . '/vendor/autoload.php';

exit((new Application())->run($_SERVER['argv']));
