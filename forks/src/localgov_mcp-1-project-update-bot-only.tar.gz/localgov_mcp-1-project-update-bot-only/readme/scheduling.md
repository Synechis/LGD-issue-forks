# Scheduling

Tool: `localgov_schedule`. It schedules a moderation state change for an existing node or alert banner. The banner tool's `schedule` action uses the same logic.

```json
{
  "entity_type": "node",
  "id": 42,
  "state": "published",
  "at": "2026-11-02T09:00:00+00:00"
}
```

`entity_type` is `node` or `localgov_alert_banner`. Nodes must be one of the 16 supported content bundles. Banners must use the standard or full-page alert bundle. `at` must be in the future and include `Z` or an explicit numeric timezone offset. The returned `scheduled_transition_id`, target ID, revision ID, state, and timestamp identify the queued change.

The tool loads the target's latest revision and records its revision ID. This matters when a published node also has a pending draft. If another revision is created before the scheduled time, review the scheduled transition in Drupal's scheduled transitions administration UI to confirm the intended revision is still targeted.

Scheduling requires update access, the `add scheduled transitions ENTITY_TYPE BUNDLE` permission, and permission to make the target workflow transition from the selected revision. Drupal's Scheduled Transitions module processes due records through cron. Use the site's normal cron setup; the administration tool can trigger a run when the account has site configuration administration permission.
