# Content

Tool: `localgov_content`. It supports the 16 node bundles listed in the [module README](../README.md#supported-content-types). Other node bundles are rejected. Results include the node ID, bundle, title, revision ID, moderation state, published flag, and canonical URL. The `get` action also returns every field the account may view.

| Action | Required arguments | Effect |
| --- | --- | --- |
| `get` | `id` | Read a node and all of its viewable fields. |
| `list` | `bundle` | List nodes of one content type. Optional `limit` (1–50) and `offset` (0 or greater). |
| `search` | `query` | Search node titles. Optional `bundle`, `limit` (1–50), and `offset`. |
| `create_draft` | `bundle`, `title` | Create a draft. Optional `fields` supplies required bundle fields. |
| `create_revision` | `id` | Save a new revision. Optional `fields`, `title`, `state`, `revision_log`; defaults to draft. |
| `publish` | `id` | Transition to `published`. |
| `unpublish` | `id` | Transition to `unpublished`. |
| `change_state` | `id`, `state` | Use an allowed state in the node's active workflow. |
| `set_alias` | `id`, `alias` | Save a site-relative alias in a draft revision. |
| `promote` | `id` | Set the promote flag in a draft revision. Optional `promoted` defaults to true. |
| `break_lock` | `id` | Release the content lock; returns `lock_released`. |

When asked for a list of a content type, call `list` with its bundle machine name. For example, to list service pages:

```json
{"action":"list","bundle":"localgov_services_page","limit":20,"offset":0}
```

Repeat with `offset: 20`, `40`, and so on to read later pages. Listing uses Drupal's entity manager and sorts by most recently changed, then node ID. `search` uses a case-insensitive `CONTAINS` title query through the same entity manager. Both actions apply entity-query access checks and then check each node's `view` access. Use `localgov_site_search` only as a last resort when indexed full-text search is needed and these entity queries cannot answer the request.

Use `{"action":"get","id":42}` for a full node response. The `fields` object is keyed by Drupal field machine name and contains arrays of raw field items, including empty arrays for empty fields. For example, service pages can return `body`, `localgov_download_links`, `localgov_hide_related_topics`, `localgov_page_components`, `localgov_services_parent`, `localgov_related_links`, `localgov_topic_classified`, and `localgov_common_tasks`. The same field discovery works for every supported content type, including site-specific fields. Reference fields contain IDs and, where applicable, revision IDs. Fields the account cannot view are omitted. Add `"include_fields":true` to `list`, `search`, or an action that saves a node when the full field data is needed in those responses.

Example: add a draft revision with an updated body:

```json
{
  "action": "create_revision",
  "id": 42,
  "fields": {
    "body": {"value": "<p>Updated guidance.</p>", "format": "basic_html"}
  },
  "revision_log": "Updated guidance through MCP"
}
```

Example: publish after review:

```json
{"action": "publish", "id": 42}
```

The publish action succeeds only when the current node state and the account's workflow permissions permit a transition to `published`. On the site's editorial workflow, a draft may first need review and approval. To set another permitted state, call `change_state` with that state's machine ID. A failed transition returns `success: false` and a message.

Use `{"action":"set_alias","id":42,"alias":"/services/permits"}` to set a manual alias. The path must not be just `/` and cannot contain a query or fragment. The result is a draft revision; publish it through the normal workflow when ready. The same draft rule applies to `promote`, which also accepts `"promoted": false` to remove front-page promotion.

`break_lock` requires both update access to the node and Drupal's `break content lock` permission. When no lock exists, it succeeds with `lock_released: false`. It does not modify the node or create a revision.
