# Taxonomy

Tool: `localgov_taxonomy`. It accepts only these vocabulary machine names:

| Label | Vocabulary ID |
| --- | --- |
| Event category | `localgov_event_category` |
| Event neighbourhood | `localgov_event_locality` |
| Event price | `localgov_event_price` |
| Media directories | `media_directories` |
| Topic | `localgov_topic` |

`list` returns terms in name order. `search` requires `query` and matches term names. Both require `vocabulary` and accept `limit` from 1 to 100. Terms that fail the account's view access are omitted.

`add` requires `vocabulary` and `name`. `update` requires `vocabulary` and `id`; the term must belong to that vocabulary. Both can accept `description`, `parent_id`, and editable configurable `fields`. A `parent_id` of 0 clears the parent. A nonzero parent must exist in the same vocabulary and be viewable by the caller. A term cannot be its own parent.

Example:

```json
{
  "action": "add",
  "vocabulary": "localgov_event_category",
  "name": "Community workshop",
  "description": "Events where residents can learn a practical skill"
}
```

The response includes the term ID, vocabulary, name, and description. Creation and update use Drupal term access and validation. A caller with a read-only role can list or search if term view access permits it, but cannot add or update terms.
