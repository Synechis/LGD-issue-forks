# Locations

Tool: `localgov_location`. This site stores directory locations as `geo_entity` entities in the `address` bundle. Directory organisation and venue nodes can reference them through the `localgov_location` field.

`add` requires a `fields` object containing `postal_address`. `update` requires an existing location `id` and the `fields` to change. The tool accepts configurable location fields, including `postal_address`, `location`, `external_id`, and `accessibility`. Values use Drupal field item structures.

Example address:

```json
{
  "action": "add",
  "fields": {
    "postal_address": {
      "country_code": "GB",
      "address_line1": "Oaklands Road",
      "locality": "Haywards Heath",
      "postal_code": "RH16 1SS"
    }
  }
}
```

The address bundle generates its label from `postal_address`. Drupal validates the address and any other supplied fields before save. To add geographic geometry, supply the `location` field in the format configured by the site's geofield widget and storage. The response includes the new ID and revision ID, which can then be referenced from a directory node using `{"localgov_location":{"target_id":ID}}` in the content tool's `fields` argument.

An account needs `create geo` or appropriate administrator permission to add a location, and `edit own geo` or `edit any geo` for updates. The generic field editor also checks field-level access.
