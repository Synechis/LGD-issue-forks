# Site search

Tool: `localgov_site_search`. It queries the configured Search API index with machine name `site_search`, which is the index this project uses for public site search. The action takes `query` and optional `limit` from 1 to 50.

Use this tool as a last resort for indexed full-text searches that cannot be answered with entity queries. To list a content type, use `localgov_content` with `action: "list"` and a bundle; to look up content by title, use its `search` action. Those actions use Drupal's entity manager and do not depend on the Search API backend.

```json
{"query":"recycling collection","limit":10}
```

The tool returns each entity's type, ID, title, and canonical URL. It loads the original entity behind every Search API result and checks the current account's `view` access before returning it. The account also needs `access content`.

When the index is missing or disabled, or Search API throws an error, the tool queries Drupal's node and media entity storages instead. The fallback matches node titles and document media names, checks entity-query and per-entity view access, and returns the newest matches up to `limit`. It does not search body text, document contents, or other indexed fields. A normal response has `source: "search_api"`; a fallback response has `source: "entity_query"` and a `message` explaining the reduced search scope. An empty but successful Search API result does not trigger the fallback. If the fallback also fails, the tool returns `success: false` and logs the failures for administrators.

Search API controls ranking, tokenization, and which fields are indexed. The result set depends on the site's current index configuration and backend health. This is distinct from `localgov_content` search, which searches supported node titles through an entity query for editorial lookup.
