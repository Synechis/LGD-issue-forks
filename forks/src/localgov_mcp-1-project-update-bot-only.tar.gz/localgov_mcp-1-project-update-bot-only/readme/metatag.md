# Metatags

Tool: `localgov_metatag`. It reads or writes the page title and meta description on a supported node with the site's `field_metatag` field. Use the node ID from content or site search.

`get` needs `action` and `id`:

```json
{"action":"get","id":42}
```

It returns `title` and `description`, each with a `template` and a `rendered` value. The template can contain Drupal tokens. The rendered value is computed by the Metatag manager using the node and configured defaults. A missing explicit override can still yield a value from sitewide or bundle defaults.

`set` also needs `tag` (`title` or `description`) and a string `value`:

```json
{
  "action": "set",
  "id": 42,
  "tag": "description",
  "value": "Find out when and how to apply for a permit."
}
```

Setting a tag keeps any other per-node metatag overrides, creates a new draft revision, and returns the resulting title, description, and revision ID. The caller needs node update access, field edit access, and permission for a transition to draft. Publish the revision through the normal editorial workflow when ready. If a node bundle has no `field_metatag`, the tool returns a failed result.
