# Administration

Tool: `localgov_administration`. The action controls which site administration operation runs.

| Action | Arguments | Required permission |
| --- | --- | --- |
| `watchdog` | Optional `limit` (1–100) | `access site reports` |
| `maintenance` | `enabled`: true or false | `administer site configuration` |
| `flush_cache` | None | `administer site configuration` |
| `cron` | None | `administer site configuration` |

`watchdog` returns the newest Drupal database log rows, ordered by watchdog ID. Each row includes its ID, user ID, type, raw message template, severity, and timestamp. The stored message is returned as a template; it is not rendered through Drupal's UI placeholder formatter.

Examples:

```json
{"action":"watchdog","limit":20}
```

```json
{"action":"maintenance","enabled":true}
```

`flush_cache` calls Drupal's full cache flush routine. `cron` invokes the core cron runner and returns whether it completed. A cron run may also process due scheduled transitions. Maintenance mode changes are written to the site's `system.maintenance` configuration.

These actions can affect availability or performance. Grant `administer site configuration` only to MCP accounts meant to operate the site. The MCP tool checks this permission immediately before running the action.

An HTTP MCP account used to take the site out of maintenance mode also needs Drupal's `access site in maintenance mode` permission, so it can reach the MCP endpoint while maintenance mode is enabled. A Drush STDIO connection can also be used by an authorised operator.
