# Media

Tool: `localgov_media`. Supported bundles are `document`, `image`, and `remote_video`. `search` matches media names and accepts an optional bundle filter. Results include ID, bundle, name, and revision ID.

| Action | Required arguments | Optional arguments |
| --- | --- | --- |
| `search` | `query` | `bundle`, `limit` (1–50) |
| `upload` for document | `bundle`, `name`, `filename`, `file_base64` | `fields` |
| `upload` for image | `bundle`, `name`, `filename`, `file_base64`, `alt` | `fields` |
| `upload` for remote video | `bundle`, `name`, `remote_url` | `fields` |
| `update` | `id` | `name`, replacement file or remote URL, `fields` |

`file_base64` is the raw base64 representation of file bytes, without a data URL prefix. A decoded upload may be at most 15 MB. Filenames are limited to letters, digits, dot, hyphen, and underscore and must start with a letter or digit. The file extension must be allowed by the media source field configuration. Documents and images are written under `public://localgov_mcp/YYYY-MM/`. File names are renamed if already present.

Example image upload:

```json
{
  "action": "upload",
  "bundle": "image",
  "name": "Town hall entrance",
  "filename": "town-hall.jpg",
  "file_base64": "...base64 bytes...",
  "alt": "The accessible entrance to the town hall"
}
```

For a remote video, pass an HTTPS YouTube or Vimeo URL in `remote_url`. The configured Drupal oEmbed field and media validation handle the provider value. Example: `{"action":"upload","bundle":"remote_video","name":"Council meeting","remote_url":"https://www.youtube.com/watch?v=..."}`.

For an update, `id` selects an existing supported media item. A new file replaces the media source field reference; the old file is managed by the site's normal file usage and cleanup rules. Image replacement requires `alt` again. The current account needs media create or update access, field edit access, and any Drupal permissions required by the supplied field values. `fields` can edit other configurable media fields with Drupal field item values.
