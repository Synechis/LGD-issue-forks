# Redirects and Fix 404

Tool: `localgov_redirect`. All actions require Drupal's `administer redirects` permission. Redirect records use the Redirect module. Fix 404 requests come from the enabled `redirect_404` module.

| Action | Required arguments | Notes |
| --- | --- | --- |
| `list` | None | Newest redirects first; optional `limit` (1–100). |
| `search` | `query` | Search redirect source paths; optional `limit`. |
| `add` | `source`, `destination` | Optional `status_code` and `enabled`. |
| `update` | `id` | Change any supplied source, destination, status code, or enabled flag. |
| `delete` | `id` | Permanently deletes that redirect. |
| `fix_404` | None | Lists unresolved 404 paths by hit count; optional `query`, `limit`. |
| `add_for_404` | `source`, `destination` | Requires an unresolved Fix 404 record and marks it resolved. |

Sources are site-relative paths such as `/old-service`. A source may include a query string, as some recorded 404 requests do, but cannot contain a fragment or parent-directory segment. Destinations must begin with one `/` and point within the same site, for example `/services/new-service`. Status codes can be 301, 302, 307, or 308. Redirect module validation catches duplicate sources and other entity constraints before save.

Add a permanent redirect:

```json
{
  "action": "add",
  "source": "/old-service",
  "destination": "/services/new-service",
  "status_code": 301
}
```

Fix a recorded 404:

1. Call `{"action":"fix_404","limit":20}` and choose a path from the result.
2. Call `{"action":"add_for_404","source":"/missing-page","destination":"/services/new-service"}`.
3. The result contains the new redirect ID and URL. The Fix 404 log entry is marked resolved after the redirect saves.

`delete` is irreversible. The result returns `deleted_id` so an automation can record what it removed. `update` and `delete` also check entity-level access, in addition to the redirect administration permission.
