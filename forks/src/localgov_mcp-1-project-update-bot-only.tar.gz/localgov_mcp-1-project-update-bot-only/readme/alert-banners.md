# Alert banners

Tool: `localgov_banner`. Supported bundles are `localgov_alert_banner` and `localgov_full_page`. The standard banner bundle is the default when `bundle` is omitted.

| Action | Arguments | Result |
| --- | --- | --- |
| `create` | `title`, optional `bundle`, `fields` | Creates an unpublished banner. |
| `update` | `id`, optional `title`, `fields`, `state` | Saves a new revision, draft by default. |
| `publish` | `id` | Makes the banner live through its workflow. |
| `unpublish` | `id` | Removes it from the live site through its workflow. |
| `schedule` | `id`, `state`, `at` | Creates a future Scheduled Transitions record. |

The banner workflow has `draft`, `published`, and `unpublished`. A workflow permission and banner update access are required for transitions. `create` always starts unpublished; use `publish` or `schedule` after creation. On `update`, omit `state` to produce a draft; provide a state only when a direct transition is intended and permitted.

Example: create a standard alert with configurable field values:

```json
{
  "action": "create",
  "title": "Service disruption",
  "fields": {
    "short_description": {"value": "The service is temporarily unavailable.", "format": "basic_html"}
  }
}
```

Other fields such as `link`, `type_of_alert`, and `visibility` follow their Drupal field definitions. Drupal validation may require additional values for a particular bundle or site configuration. The result includes the banner ID, bundle, title, revision ID, and moderation state.

To schedule a banner to go live, call `{"action":"schedule","id":12,"state":"published","at":"2026-11-02T09:00:00+00:00"}`. The account needs the bundle's scheduled transitions permission. See [Scheduling](scheduling.md) for revision and cron behavior.
