<?php

declare(strict_types=1);

namespace Drupal\localgov_mcp\Form;

use Drupal\Core\Config\ConfigFactoryInterface;
use Drupal\Core\Config\TypedConfigManagerInterface;
use Drupal\Core\Form\ConfigFormBase;
use Drupal\Core\Form\FormStateInterface;
use Drupal\mcp_server\Plugin\ToolPluginManager;
use Symfony\Component\DependencyInjection\ContainerInterface;

/**
 * Configures which LocalGov MCP tools are available.
 */
final class ToolSettingsForm extends ConfigFormBase {

  /**
   * The MCP tool plugin manager.
   */
  protected ToolPluginManager $toolManager;

  public function __construct(
    ConfigFactoryInterface $config_factory,
    TypedConfigManagerInterface $typed_config_manager,
    ToolPluginManager $tool_manager,
  ) {
    parent::__construct($config_factory, $typed_config_manager);
    $this->toolManager = $tool_manager;
  }

  /**
   * {@inheritdoc}
   */
  public static function create(ContainerInterface $container): static {
    return new static(
      $container->get('config.factory'),
      $container->get('config.typed'),
      $container->get('plugin.manager.mcp_server.tool'),
    );
  }

  /**
   * {@inheritdoc}
   */
  public function getFormId(): string {
    return 'localgov_mcp_tool_settings';
  }

  /**
   * {@inheritdoc}
   */
  protected function getEditableConfigNames(): array {
    return ['localgov_mcp.settings'];
  }

  /**
   * {@inheritdoc}
   */
  public function buildForm(array $form, FormStateInterface $form_state): array {
    $options = $this->toolOptions();
    $disabled = $this->config('localgov_mcp.settings')->get('disabled_tools') ?? [];
    $form['enabled_tools'] = [
      '#type' => 'checkboxes',
      '#title' => $this->t('Enabled tools'),
      '#description' => $this->t('Disabled tools are hidden from MCP tool discovery and cannot be called. Drupal permissions still control access to enabled tools.'),
      '#options' => $options,
      '#default_value' => array_values(array_diff(array_keys($options), $disabled)),
    ];
    return parent::buildForm($form, $form_state);
  }

  /**
   * {@inheritdoc}
   */
  public function submitForm(array &$form, FormStateInterface $form_state): void {
    $enabled = array_filter((array) $form_state->getValue('enabled_tools'));
    $disabled = array_keys(array_diff_key($this->toolOptions(), $enabled));
    $this->config('localgov_mcp.settings')
      ->set('disabled_tools', $disabled)
      ->save();
    parent::submitForm($form, $form_state);
  }

  /**
   * Returns the tools supplied by this module.
   */
  private function toolOptions(): array {
    $options = [];
    foreach ($this->toolManager->getAvailableDefinitions() as $id => $definition) {
      if ($definition->getProvider() === 'localgov_mcp') {
        $options[$id] = $definition->label . ' (' . $id . ')';
      }
    }
    asort($options);
    return $options;
  }

}
