<?php

declare(strict_types=1);

namespace Drupal\localgov_mcp;

use Drupal\Core\Entity\EntityTypeManagerInterface;
use Drupal\Core\Session\AccountProxyInterface;
use Psr\Log\LoggerInterface;

/**
 * Queries Search API with an entity-query fallback. */
final class SearchOperations {

  public function __construct(
    private readonly EntityTypeManagerInterface $entities,
    private readonly AccountProxyInterface $account,
    private readonly FallbackSearch $entitySearch,
    private readonly LoggerInterface $logger,
  ) {}

  /**
   * Runs the requested operation.
   */
  public function handle(array $input): array {
    if (!$this->account->hasPermission('access content')) {
      return Common::failure('Access content permission is required.');
    }
    $term = Common::required($input, 'query');
    $limit = Common::limit($input);
    $reason = 'unavailable';
    try {
      $index = $this->entities->getStorage('search_api_index')->load('site_search');
      if ($index && $index->status()) {
        $query = $index->query()->keys($term)->range(0, $limit);
        $results = [];
        foreach ($query->execute()->getResultItems() as $item) {
          $object = $item->getOriginalObject();
          $entity = $object ? $object->getValue() : NULL;
          if (!$entity || !$entity->access('view', $this->account)) {
            continue;
          }
          $results[] = [
            'entity_type' => $entity->getEntityTypeId(),
            'id' => (int) $entity->id(),
            'title' => $entity->label(),
            'url' => $entity->toUrl('canonical', ['absolute' => TRUE])->toString(),
          ];
        }
        return Common::success($results) + ['source' => 'search_api'];
      }
    }
    catch (\Throwable $exception) {
      $reason = 'failed';
      $this->logger->warning('The site_search Search API query failed: @message', [
        '@message' => $exception->getMessage(),
      ]);
    }
    return $this->fallback($term, $limit, $reason);
  }

  /**
   * Returns title-only matches if the indexed search cannot run.
   */
  private function fallback(string $term, int $limit, string $reason): array {
    try {
      return Common::success($this->entitySearch->search($term, $limit)) + [
        'source' => 'entity_query',
        'message' => "Search API $reason; showing node title and document media name matches only.",
      ];
    }
    catch (\Throwable $exception) {
      $this->logger->error('The site_search entity-query fallback failed: @message', [
        '@message' => $exception->getMessage(),
      ]);
      return Common::failure('Search API and the entity-query fallback are unavailable.');
    }
  }

}
