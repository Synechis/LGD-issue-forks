<?php

declare(strict_types=1);

namespace Drupal\localgov_mcp;

use Drupal\Core\Entity\ContentEntityInterface;
use Drupal\Core\Entity\EntityTypeManagerInterface;
use Drupal\Core\Entity\RevisionableStorageInterface;
use Drupal\Core\Session\AccountProxyInterface;
use Drupal\filter\FilterFormatInterface;

/**
 * Validation and response helpers shared by the MCP operations.
 */
final class Common {

  public const NODE_BUNDLES = [
    'localgov_directory', 'localgov_directories_org', 'localgov_directories_page',
    'localgov_directories_venue', 'localgov_event', 'external_page',
    'localgov_guides_overview', 'localgov_guides_page', 'homepage',
    'localgov_news_article', 'localgov_newsroom', 'localgov_services_landing',
    'localgov_services_page', 'localgov_services_sublanding',
    'localgov_step_by_step_overview', 'localgov_step_by_step_page',
  ];

  public const VOCABULARIES = [
    'localgov_event_category', 'localgov_event_locality',
    'localgov_event_price', 'media_directories', 'localgov_topic',
  ];

  public function __construct(
    private readonly EntityTypeManagerInterface $entities,
    private readonly AccountProxyInterface $account,
  ) {}

  /**
   * Builds a successful tool result.
   */
  public static function success(array $data = []): array {
    return ['success' => TRUE, 'data' => $data];
  }

  /**
   * Builds a failed tool result.
   */
  public static function failure(string $message): array {
    return ['success' => FALSE, 'message' => $message, 'data' => []];
  }

  /**
   * Clamps a requested result limit.
   */
  public static function limit(array $input, int $max = 50): int {
    return max(1, min($max, (int) ($input['limit'] ?? 20)));
  }

  /**
   * Reads and validates a required string.
   */
  public static function required(array $input, string $key): string {
    $value = trim((string) ($input[$key] ?? ''));
    if ($value === '') {
      throw new \InvalidArgumentException("$key is required.");
    }
    return $value;
  }

  /**
   * Checks a value against an allowlist.
   */
  public static function allowed(string $value, array $allowed, string $label): string {
    if (!in_array($value, $allowed, TRUE)) {
      throw new \InvalidArgumentException("Unsupported $label: $value.");
    }
    return $value;
  }

  /**
   * Loads a supported content entity.
   */
  public function entity(string $type, int $id, ?array $bundles = NULL, bool $latest = FALSE): ContentEntityInterface {
    if ($id < 1) {
      throw new \InvalidArgumentException('A positive entity ID is required.');
    }
    $storage = $this->entities->getStorage($type);
    $entity = $storage->load($id);
    if (!$entity instanceof ContentEntityInterface || ($bundles !== NULL && !in_array($entity->bundle(), $bundles, TRUE))) {
      throw new \InvalidArgumentException('Entity not found or its bundle is not supported.');
    }
    if ($latest && $storage instanceof RevisionableStorageInterface) {
      $revision_id = $storage->getLatestRevisionId($id);
      $revision = $revision_id ? $storage->loadRevision($revision_id) : NULL;
      if ($revision instanceof ContentEntityInterface) {
        $entity = $revision;
      }
    }
    return $entity;
  }

  /**
   * Checks entity operation access.
   */
  public function access(ContentEntityInterface $entity, string $operation): void {
    if (!$entity->access($operation, $this->account)) {
      throw new \InvalidArgumentException('Access denied for this entity.');
    }
  }

  /**
   * Applies only editable configurable fields supplied by the caller.
   */
  public function fields(ContentEntityInterface $entity, array $values): void {
    foreach ($values as $name => $value) {
      if (!is_string($name) || !$entity->hasField($name) || $entity->getFieldDefinition($name)->getFieldStorageDefinition()->isBaseField()) {
        throw new \InvalidArgumentException("Field $name is not an editable configurable field.");
      }
      $field = $entity->get($name);
      if (!$field->access('edit', $this->account)) {
        throw new \InvalidArgumentException("Access denied for field $name.");
      }
      $items = isset($value[0]) && is_array($value[0]) ? $value : [$value];
      foreach ($items as $item) {
        if (in_array($field->getFieldDefinition()->getType(), ['text', 'text_long', 'text_with_summary'], TRUE)
          && (!is_array($item) || empty($item['format']))) {
          throw new \InvalidArgumentException("Field $name requires an explicit text format.");
        }
        if (!is_array($item)) {
          continue;
        }
        $format_id = $item['format'] ?? NULL;
        if ($format_id !== NULL) {
          $format = $this->entities->getStorage('filter_format')->load($format_id);
          if (!$format instanceof FilterFormatInterface || !$format->access('use', $this->account)) {
            throw new \InvalidArgumentException("Text format $format_id is not allowed.");
          }
        }
      }
      $entity->set($name, $value);
    }
  }

  /**
   * Rejects entity validation violations.
   */
  public function validate(ContentEntityInterface $entity): void {
    $errors = [];
    foreach ($entity->validate() as $violation) {
      $errors[] = $violation->getPropertyPath() . ': ' . $violation->getMessage();
    }
    if ($errors) {
      throw new \InvalidArgumentException(implode('; ', $errors));
    }
  }

}
