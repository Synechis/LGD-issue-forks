<?php

declare(strict_types=1);

namespace Drupal\localgov_mcp;

use Drupal\Component\Serialization\Json;
use Drupal\content_lock\ContentLock\ContentLockInterface;
use Drupal\content_moderation\StateTransitionValidationInterface;
use Drupal\Core\Session\AccountProxyInterface;
use Drupal\metatag\MetatagManager;
use Drupal\node\NodeInterface;

/**
 * Reads and writes page title and meta description overrides. */
final class MetatagOperations {

  public function __construct(
    private readonly Common $common,
    private readonly AccountProxyInterface $account,
    private readonly MetatagManager $metatags,
    private readonly StateTransitionValidationInterface $transitions,
    private readonly ContentLockInterface $locks,
  ) {}

  /**
   * Runs the requested operation.
   */
  public function handle(array $input): array {
    $action = Common::allowed(Common::required($input, 'action'), ['get', 'set'], 'metatag action');
    $node = $this->common->entity('node', (int) ($input['id'] ?? 0), Common::NODE_BUNDLES, TRUE);
    if (!$node instanceof NodeInterface) {
      throw new \InvalidArgumentException('Node not found.');
    }
    if (!$node->hasField('field_metatag')) {
      return Common::failure('This page has no editable metatag field.');
    }
    $this->common->access($node, $action === 'get' ? 'view' : 'update');
    $field = $node->get('field_metatag');
    if ($action === 'set') {
      $lock = $this->locks->fetchLock($node);
      if ($lock && (int) $lock->uid !== (int) $this->account->id()) {
        return Common::failure('This node is locked by another editor.');
      }
      if (!$field->access('edit', $this->account)) {
        return Common::failure('Access denied to edit metatags.');
      }
      $tag = Common::allowed(Common::required($input, 'tag'), ['title', 'description'], 'metatag');
      if (!array_key_exists('value', $input) || !is_string($input['value'])) {
        throw new \InvalidArgumentException('value must be a string.');
      }
      $existing = $this->metatags->tagsFromEntity($node);
      $existing[$tag] = $input['value'];
      $can_draft = FALSE;
      foreach ($this->transitions->getValidTransitions($node, $this->account) as $transition) {
        $can_draft = $can_draft || $transition->to()->id() === 'draft';
      }
      if (!$can_draft) {
        return Common::failure('The current account cannot create a draft revision.');
      }
      $node->set('field_metatag', ['value' => Json::encode($existing)]);
      $node->set('moderation_state', 'draft');
      $node->setNewRevision(TRUE);
      $node->setRevisionUserId((int) $this->account->id());
      $this->common->validate($node);
      $node->save();
    }
    $tags = $this->metatags->tagsFromEntityWithDefaults($node);
    $render_tags = $tags;
    foreach (['title', 'description'] as $tag) {
      if (isset($render_tags[$tag]) && is_string($render_tags[$tag])) {
        $render_tags[$tag] = str_replace(
          '[current-page:title]',
          (string) $node->label(),
          $render_tags[$tag],
        );
      }
    }
    $resolved = $this->metatags->generateTokenValues($render_tags, $node);
    return Common::success([
      'id' => (int) $node->id(),
      'title' => ['template' => $tags['title'] ?? NULL, 'rendered' => $resolved['title'] ?? NULL],
      'description' => ['template' => $tags['description'] ?? NULL, 'rendered' => $resolved['description'] ?? NULL],
      'revision_id' => (int) $node->getRevisionId(),
    ]);
  }

}
