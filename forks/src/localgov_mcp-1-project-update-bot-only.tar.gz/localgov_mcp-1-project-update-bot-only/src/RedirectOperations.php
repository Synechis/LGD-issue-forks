<?php

declare(strict_types=1);

namespace Drupal\localgov_mcp;

use Drupal\Core\Database\Connection;
use Drupal\Core\Database\Statement\FetchAs;
use Drupal\Core\Entity\EntityTypeManagerInterface;
use Drupal\Core\Session\AccountProxyInterface;
use Drupal\redirect\Entity\Redirect;
use Drupal\redirect_404\RedirectNotFoundStorageInterface;

/**
 * Redirect CRUD and Fix 404 reporting.
 */
final class RedirectOperations {

  public function __construct(
    private readonly EntityTypeManagerInterface $entities,
    private readonly Connection $database,
    private readonly AccountProxyInterface $account,
    private readonly RedirectNotFoundStorageInterface $notFound,
  ) {}

  /**
   * Runs the requested operation.
   */
  public function handle(array $input): array {
    $action = Common::allowed(Common::required($input, 'action'), [
      'list', 'search', 'add', 'update', 'delete', 'fix_404', 'add_for_404',
    ], 'redirect action');
    if (!$this->account->hasPermission('administer redirects')) {
      return Common::failure('Administer redirects permission is required.');
    }
    return match ($action) {
      'list', 'search' => $this->find($input, $action === 'search'),
      'fix_404' => $this->fix404($input),
      'add', 'update', 'add_for_404' => $this->write($action, $input),
      'delete' => $this->delete($input),
      default => throw new \InvalidArgumentException('Unsupported redirect action.'),
    };
  }

  /**
   * Lists accessible matching entities.
   */
  private function find(array $input, bool $search): array {
    $storage = $this->entities->getStorage('redirect');
    $query = $storage->getQuery()->accessCheck(TRUE)->sort('created', 'DESC')->range(0, Common::limit($input, 100));
    if ($search) {
      $query->condition('redirect_source.path', ltrim(Common::required($input, 'query'), '/'), 'CONTAINS');
    }
    $results = [];
    foreach ($storage->loadMultiple($query->execute()) as $redirect) {
      if ($redirect instanceof Redirect && $redirect->access('view', $this->account)) {
        $results[] = $this->describe($redirect);
      }
    }
    return Common::success($results);
  }

  /**
   * Lists unresolved 404 requests.
   */
  private function fix404(array $input): array {
    $query = $this->database->select('redirect_404', 'r')
      ->fields('r', ['path', 'count', 'timestamp', 'langcode'])
      ->condition('resolved', 0)
      ->orderBy('count', 'DESC')
      ->range(0, Common::limit($input, 100));
    if (!empty($input['query'])) {
      $query->condition('path', '%' . $this->database->escapeLike((string) $input['query']) . '%', 'LIKE');
    }
    return Common::success($query->execute()->fetchAll(FetchAs::Associative));
  }

  /**
   * Creates or updates an entity.
   */
  private function write(string $action, array $input): array {
    $storage = $this->entities->getStorage('redirect');
    if ($action === 'update') {
      $redirect = $storage->load((int) ($input['id'] ?? 0));
      if (!$redirect || !$redirect->access('update', $this->account)) {
        return Common::failure('Redirect not found or access denied.');
      }
    }
    else {
      if (!$this->entities->getAccessControlHandler('redirect')->createAccess('redirect', $this->account)) {
        return Common::failure('Access denied to create redirects.');
      }
      $redirect = $storage->create([
        'type' => 'redirect',
        'language' => 'und',
        'status_code' => 301,
      ]);
    }
    if (!$redirect instanceof Redirect) {
      throw new \InvalidArgumentException('Redirect not found.');
    }
    $source = isset($input['source']) ? $this->source((string) $input['source']) : NULL;
    if ($action !== 'update' && $source === NULL) {
      throw new \InvalidArgumentException('source is required.');
    }
    if ($action === 'add_for_404') {
      $exists = $this->database->select('redirect_404', 'r')->fields('r', ['path'])->condition('path', $source['log_path'])->condition('resolved', 0)->range(0, 1)->execute()->fetchField();
      if ($exists === FALSE) {
        throw new \InvalidArgumentException('This source is not an unresolved Fix 404 path.');
      }
    }
    if ($source !== NULL) {
      $redirect->setSource($source['path'], $source['query']);
    }
    if (isset($input['destination'])) {
      $destination = Common::required($input, 'destination');
      if (!str_starts_with($destination, '/') || str_starts_with($destination, '//') || str_contains($destination, '#')) {
        throw new \InvalidArgumentException('destination must be a local site-relative path.');
      }
      $redirect->setRedirect($destination);
    }
    elseif ($action !== 'update') {
      throw new \InvalidArgumentException('destination is required.');
    }
    if (isset($input['status_code'])) {
      $redirect->setStatusCode((int) Common::allowed((string) $input['status_code'], ['301', '302', '307', '308'], 'redirect status code'));
    }
    if (isset($input['enabled'])) {
      $redirect->set('enabled', (bool) $input['enabled']);
    }
    $errors = [];
    foreach ($redirect->validate() as $violation) {
      $errors[] = $violation->getPropertyPath() . ': ' . $violation->getMessage();
    }
    if ($errors) {
      throw new \InvalidArgumentException(implode('; ', $errors));
    }
    $redirect->save();
    if ($action === 'add_for_404') {
      $this->notFound->resolveLogRequest($source['log_path']);
    }
    return Common::success($this->describe($redirect));
  }

  /**
   * Deletes an accessible redirect.
   */
  private function delete(array $input): array {
    $redirect = $this->entities->getStorage('redirect')->load((int) ($input['id'] ?? 0));
    if (!$redirect || !$redirect->access('delete', $this->account)) {
      return Common::failure('Redirect not found or access denied.');
    }
    $id = (int) $redirect->id();
    $redirect->delete();
    return Common::success(['deleted_id' => $id]);
  }

  /**
   * Validates a redirect source path.
   */
  private function source(string $source): array {
    $source = trim($source);
    $parts = parse_url($source);
    if ($parts === FALSE || isset($parts['scheme']) || isset($parts['host']) || isset($parts['fragment'])) {
      throw new \InvalidArgumentException('source must be a local site-relative path without a fragment.');
    }
    $path = ltrim((string) ($parts['path'] ?? ''), '/');
    if ($path === '' || str_contains($path, '\\') || preg_match('~(^|/)\.\.?(/|$)~', $path)) {
      throw new \InvalidArgumentException('source must be a valid site-relative path.');
    }
    $query = [];
    if (isset($parts['query'])) {
      parse_str($parts['query'], $query);
    }
    return [
      'path' => $path,
      'query' => $query,
      'log_path' => '/' . $path . (isset($parts['query']) ? '?' . $parts['query'] : ''),
    ];
  }

  /**
   * Builds a concise response for an entity.
   */
  private function describe(Redirect $redirect): array {
    return [
      'id' => (int) $redirect->id(),
      'source' => $redirect->getSourcePathWithQuery(),
      'destination' => $redirect->getRedirectUrl()?->toString(),
      'status_code' => (int) $redirect->getStatusCode(),
      'enabled' => $redirect->isPublished(),
    ];
  }

}
