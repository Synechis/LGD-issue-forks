<?php

declare(strict_types=1);

namespace Drupal\localgov_mcp;

use Drupal\Core\Entity\EntityTypeManagerInterface;
use Drupal\Core\File\FileExists;
use Drupal\Core\File\FileSystemInterface;
use Drupal\Core\Session\AccountProxyInterface;
use Drupal\file\FileRepositoryInterface;
use Drupal\file\FileInterface;
use Drupal\media\MediaInterface;

/**
 * Media lookup, upload and update operations.
 */
final class MediaOperations {

  private const BUNDLES = ['document', 'image', 'remote_video'];

  public function __construct(
    private readonly Common $common,
    private readonly EntityTypeManagerInterface $entities,
    private readonly AccountProxyInterface $account,
    private readonly FileSystemInterface $files,
    private readonly FileRepositoryInterface $repository,
  ) {}

  /**
   * Runs the requested operation.
   */
  public function handle(array $input): array {
    $action = Common::allowed(Common::required($input, 'action'), ['search', 'upload', 'update'], 'media action');
    if ($action !== 'search') {
      foreach (array_keys((array) ($input['fields'] ?? [])) as $name) {
        if (in_array($name, ['field_media_document', 'field_media_image', 'field_media_oembed_video'], TRUE)) {
          throw new \InvalidArgumentException('Use the dedicated file or remote_url arguments for media sources.');
        }
      }
    }
    return match ($action) {
      'search' => $this->search($input),
      'upload' => $this->upload($input),
      'update' => $this->update($input),
      default => throw new \InvalidArgumentException('Unsupported media action.'),
    };
  }

  /**
   * Searches accessible entities.
   */
  private function search(array $input): array {
    $query = Common::required($input, 'query');
    $storage = $this->entities->getStorage('media');
    $search = $storage->getQuery()->accessCheck(TRUE)
      ->condition('bundle', self::BUNDLES, 'IN')
      ->condition('name', $query, 'CONTAINS')
      ->sort('changed', 'DESC')->range(0, Common::limit($input));
    if (!empty($input['bundle'])) {
      $search->condition('bundle', Common::allowed((string) $input['bundle'], self::BUNDLES, 'media type'));
    }
    $results = [];
    foreach ($storage->loadMultiple($search->execute()) as $media) {
      if ($media->access('view', $this->account)) {
        $results[] = $this->describe($media);
      }
    }
    return Common::success($results);
  }

  /**
   * Creates a media item from a file or remote URL.
   */
  private function upload(array $input): array {
    $bundle = Common::allowed(Common::required($input, 'bundle'), self::BUNDLES, 'media type');
    $storage = $this->entities->getStorage('media');
    if (!$this->entities->getAccessControlHandler('media')->createAccess($bundle, $this->account)) {
      return Common::failure('Access denied to create this media type.');
    }
    $media = $storage->create([
      'bundle' => $bundle,
      'name' => Common::required($input, 'name'),
      'uid' => $this->account->id(),
    ]);
    $file = NULL;
    if ($bundle === 'remote_video') {
      if (isset($input['file_base64'])) {
        throw new \InvalidArgumentException('Remote videos do not accept file data.');
      }
      if (!$media->get('field_media_oembed_video')->access('edit', $this->account)) {
        return Common::failure('Access denied to edit the remote video field.');
      }
      $url = Common::required($input, 'remote_url');
      if (!preg_match('~^https://(?:www\.)?(?:youtube\.com|youtu\.be|vimeo\.com)/~i', $url)) {
        throw new \InvalidArgumentException('Remote video must be an HTTPS YouTube or Vimeo URL.');
      }
      $media->set('field_media_oembed_video', $url);
    }
    else {
      $file = $this->attachFile($media, $input);
    }
    $this->common->fields($media, (array) ($input['fields'] ?? []));
    $this->common->validate($media);
    $media->save();
    if ($file) {
      $file->setPermanent();
      $file->save();
    }
    return Common::success($this->describe($media));
  }

  /**
   * Updates an existing media item.
   */
  private function update(array $input): array {
    $media = $this->common->entity('media', (int) ($input['id'] ?? 0), self::BUNDLES);
    if (!$media instanceof MediaInterface) {
      throw new \InvalidArgumentException('Media item not found.');
    }
    $this->common->access($media, 'update');
    $file = NULL;
    if (isset($input['name'])) {
      $media->setName(Common::required($input, 'name'));
    }
    if (isset($input['remote_url'])) {
      if ($media->bundle() !== 'remote_video') {
        throw new \InvalidArgumentException('Only remote videos accept remote_url.');
      }
      if (!$media->get('field_media_oembed_video')->access('edit', $this->account)) {
        return Common::failure('Access denied to edit the remote video field.');
      }
      $url = Common::required($input, 'remote_url');
      if (!preg_match('~^https://(?:www\.)?(?:youtube\.com|youtu\.be|vimeo\.com)/~i', $url)) {
        throw new \InvalidArgumentException('Remote video must be an HTTPS YouTube or Vimeo URL.');
      }
      $media->set('field_media_oembed_video', $url);
    }
    if (isset($input['file_base64'])) {
      if ($media->bundle() === 'remote_video') {
        throw new \InvalidArgumentException('Remote videos do not accept file data.');
      }
      $file = $this->attachFile($media, $input);
    }
    $this->common->fields($media, (array) ($input['fields'] ?? []));
    if ($media->getEntityType()->isRevisionable()) {
      $media->setNewRevision(TRUE);
    }
    $this->common->validate($media);
    $media->save();
    if ($file) {
      $file->setPermanent();
      $file->save();
    }
    return Common::success($this->describe($media));
  }

  /**
   * Validates and attaches an uploaded file.
   */
  private function attachFile(MediaInterface $media, array $input): FileInterface {
    $field_name = $media->bundle() === 'image' ? 'field_media_image' : 'field_media_document';
    $field = $media->get($field_name);
    if (!$field->access('edit', $this->account)) {
      throw new \InvalidArgumentException('Access denied to edit the media file.');
    }
    $filename = basename(Common::required($input, 'filename'));
    if ($filename !== ($input['filename'] ?? '') || !preg_match('/^[A-Za-z0-9][A-Za-z0-9._-]*$/', $filename)) {
      throw new \InvalidArgumentException('Filename contains unsupported characters.');
    }
    $extension = strtolower(pathinfo($filename, PATHINFO_EXTENSION));
    $allowed = preg_split('/\s+/', (string) $field->getFieldDefinition()->getSetting('file_extensions'));
    if (!$extension || !in_array($extension, $allowed, TRUE)) {
      throw new \InvalidArgumentException('This file extension is not allowed for the media type.');
    }
    $encoded = Common::required($input, 'file_base64');
    if (strlen($encoded) > 21_000_000) {
      throw new \InvalidArgumentException('File exceeds the 15 MB upload limit.');
    }
    $bytes = base64_decode($encoded, TRUE);
    if ($bytes === FALSE || strlen($bytes) > 15_000_000) {
      throw new \InvalidArgumentException('Invalid base64 data or file exceeds 15 MB.');
    }
    $directory = 'public://localgov_mcp/' . date('Y-m');
    if (!$this->files->prepareDirectory($directory, FileSystemInterface::CREATE_DIRECTORY | FileSystemInterface::MODIFY_PERMISSIONS)) {
      throw new \InvalidArgumentException('Could not prepare the media upload directory.');
    }
    $file = $this->repository->writeData($bytes, $directory . '/' . $filename, FileExists::Rename);
    $value = ['target_id' => $file->id()];
    if ($media->bundle() === 'image') {
      $value['alt'] = Common::required($input, 'alt');
    }
    $media->set($field_name, $value);
    return $file;
  }

  /**
   * Builds a concise response for an entity.
   */
  private function describe(MediaInterface $media): array {
    return [
      'id' => (int) $media->id(),
      'type' => $media->bundle(),
      'name' => $media->label(),
      'revision_id' => (int) $media->getRevisionId(),
    ];
  }

}
