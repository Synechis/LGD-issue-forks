<?php

declare(strict_types=1);

namespace Drupal\localgov_mcp;

use Drupal\Core\Entity\EntityTypeManagerInterface;
use Drupal\Core\Session\AccountProxyInterface;
use Drupal\geo_entity\Entity\GeoEntity;

/**
 * Adds and updates address locations. */
final class LocationOperations {

  public function __construct(
    private readonly Common $common,
    private readonly EntityTypeManagerInterface $entities,
    private readonly AccountProxyInterface $account,
  ) {}

  /**
   * Runs the requested operation.
   */
  public function handle(array $input): array {
    $action = Common::allowed(Common::required($input, 'action'), ['add', 'update'], 'location action');
    $storage = $this->entities->getStorage('geo_entity');
    if ($action === 'add') {
      if (!$this->entities->getAccessControlHandler('geo_entity')->createAccess('address', $this->account)) {
        return Common::failure('Access denied to create locations.');
      }
      $location = $storage->create(['bundle' => 'address', 'uid' => $this->account->id()]);
    }
    else {
      $location = $this->common->entity('geo_entity', (int) ($input['id'] ?? 0), ['address']);
      $this->common->access($location, 'update');
      $location->setNewRevision(TRUE);
    }
    if (!$location instanceof GeoEntity) {
      throw new \InvalidArgumentException('Location not found.');
    }
    $fields = (array) ($input['fields'] ?? []);
    if (!$fields || ($action === 'add' && !isset($fields['postal_address']))) {
      throw new \InvalidArgumentException('fields must include postal_address when adding a location.');
    }
    $this->common->fields($location, $fields);
    $this->common->validate($location);
    $location->save();
    return Common::success([
      'id' => (int) $location->id(),
      'type' => $location->bundle(),
      'label' => $location->label(),
      'revision_id' => (int) $location->getRevisionId(),
    ]);
  }

}
