<?php

declare(strict_types=1);

namespace Drupal\localgov_mcp\Plugin\mcp_server\Tool;

use Drupal\Core\StringTranslation\TranslatableMarkup;
use Drupal\localgov_mcp\ToolBase;
use Drupal\mcp_server\Attribute\Tool;

/**
 * Provides site administration actions. */
#[Tool(
  id: 'localgov_administration',
  label: new TranslatableMarkup('Administer the site'),
  description: new TranslatableMarkup('Read recent watchdog records, change maintenance mode, flush all caches or run cron.'),
  inputSchema: [
    'type' => 'object',
    'properties' => [
      'action' => ['type' => 'string', 'enum' => ['watchdog', 'maintenance', 'flush_cache', 'cron']],
      'enabled' => ['type' => 'boolean'],
      'limit' => ['type' => 'integer', 'minimum' => 1, 'maximum' => 100],
    ],
    'required' => ['action'],
  ],
  readOnly: FALSE,
  destructive: TRUE,
  idempotent: FALSE,
  openWorld: FALSE,
)]
final class Administration extends ToolBase {
  protected const HANDLER = 'localgov_mcp.admin';

}
