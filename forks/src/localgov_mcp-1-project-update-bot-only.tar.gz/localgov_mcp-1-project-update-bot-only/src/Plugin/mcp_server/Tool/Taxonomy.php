<?php

declare(strict_types=1);

namespace Drupal\localgov_mcp\Plugin\mcp_server\Tool;

use Drupal\Core\StringTranslation\TranslatableMarkup;
use Drupal\localgov_mcp\ToolBase;
use Drupal\mcp_server\Attribute\Tool;

/**
 * Provides term operations. */
#[Tool(
  id: 'localgov_taxonomy',
  label: new TranslatableMarkup('Manage taxonomy terms'),
  description: new TranslatableMarkup('List, search, add or update terms in event category, event neighbourhood, event price, media directories and topic.'),
  inputSchema: [
    'type' => 'object',
    'properties' => [
      'action' => ['type' => 'string', 'enum' => ['list', 'search', 'add', 'update']],
      'vocabulary' => [
        'type' => 'string',
        'enum' => [
          'localgov_event_category', 'localgov_event_locality',
          'localgov_event_price', 'media_directories', 'localgov_topic',
        ],
      ],
      'id' => ['type' => 'integer', 'minimum' => 1],
      'query' => ['type' => 'string'],
      'name' => ['type' => 'string'],
      'description' => ['type' => 'string'],
      'parent_id' => ['type' => 'integer', 'minimum' => 0],
      'fields' => ['type' => 'object'],
      'limit' => ['type' => 'integer', 'minimum' => 1, 'maximum' => 100],
    ],
    'required' => ['action', 'vocabulary'],
  ],
  readOnly: FALSE,
  destructive: TRUE,
  idempotent: FALSE,
  openWorld: FALSE,
)]
final class Taxonomy extends ToolBase {
  protected const HANDLER = 'localgov_mcp.taxonomy';

}
