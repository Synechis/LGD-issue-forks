<?php

declare(strict_types=1);

namespace Drupal\localgov_mcp\Plugin\mcp_server\Tool;

use Drupal\Core\StringTranslation\TranslatableMarkup;
use Drupal\localgov_mcp\ToolBase;
use Drupal\mcp_server\Attribute\Tool;

/**
 * Provides page metadata operations. */
#[Tool(
  id: 'localgov_metatag',
  label: new TranslatableMarkup('Manage page metadata'),
  description: new TranslatableMarkup('Get or set the rendered page title and meta description of a supported node. Set writes a new revision.'),
  inputSchema: [
    'type' => 'object',
    'properties' => [
      'action' => ['type' => 'string', 'enum' => ['get', 'set']],
      'id' => ['type' => 'integer', 'minimum' => 1],
      'tag' => ['type' => 'string', 'enum' => ['title', 'description']],
      'value' => ['type' => 'string'],
    ],
    'required' => ['action', 'id'],
  ],
  readOnly: FALSE,
  destructive: TRUE,
  idempotent: FALSE,
  openWorld: FALSE,
)]
final class Metatag extends ToolBase {
  protected const HANDLER = 'localgov_mcp.metatag';

}
