<?php

declare(strict_types=1);

namespace Drupal\localgov_mcp\Plugin\mcp_server\Tool;

use Drupal\Core\StringTranslation\TranslatableMarkup;
use Drupal\localgov_mcp\ToolBase;
use Drupal\mcp_server\Attribute\Tool;

/**
 * Provides address location operations. */
#[Tool(
  id: 'localgov_location',
  label: new TranslatableMarkup('Manage locations'),
  description: new TranslatableMarkup('Add or update address locations (geo_entity address bundle). Provide editable field items, including postal_address on add.'),
  inputSchema: [
    'type' => 'object',
    'properties' => [
      'action' => ['type' => 'string', 'enum' => ['add', 'update']],
      'id' => ['type' => 'integer', 'minimum' => 1],
      'fields' => ['type' => 'object'],
    ],
    'required' => ['action', 'fields'],
  ],
  readOnly: FALSE,
  destructive: TRUE,
  idempotent: FALSE,
  openWorld: FALSE,
)]
final class Location extends ToolBase {
  protected const HANDLER = 'localgov_mcp.location';

}
