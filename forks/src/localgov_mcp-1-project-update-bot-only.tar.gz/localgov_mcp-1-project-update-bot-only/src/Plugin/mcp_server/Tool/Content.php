<?php

declare(strict_types=1);

namespace Drupal\localgov_mcp\Plugin\mcp_server\Tool;

use Drupal\Core\StringTranslation\TranslatableMarkup;
use Drupal\localgov_mcp\Common;
use Drupal\localgov_mcp\ToolBase;
use Drupal\mcp_server\Attribute\Tool;

/**
 * Provides LocalGov content operations. */
#[Tool(
  id: 'localgov_content',
  label: new TranslatableMarkup('Manage LocalGov content'),
  description: new TranslatableMarkup('Use get with an ID to return a node and all viewable fields. Use list with a bundle to list a content type through Drupal entity queries; use search for title lookups. Set include_fields to true to include viewable fields in list, search, or saved-node responses. Other actions: create_draft, create_revision, publish, unpublish, change_state, set_alias, promote, break_lock. Field values use Drupal field item structures.'),
  inputSchema: [
    'type' => 'object',
    'properties' => [
      'action' => [
        'type' => 'string',
        'enum' => [
          'get', 'list', 'search', 'create_draft', 'create_revision', 'publish', 'unpublish',
          'change_state', 'set_alias', 'promote', 'break_lock',
        ],
      ],
      'id' => ['type' => 'integer', 'minimum' => 1],
      'bundle' => [
        'type' => 'string',
        'enum' => Common::NODE_BUNDLES,
        'description' => 'Content type machine name. Required for list; optional for search.',
      ],
      'query' => ['type' => 'string'],
      'title' => ['type' => 'string'],
      'fields' => ['type' => 'object', 'description' => 'Editable Drupal field names mapped to field item values.'],
      'include_fields' => [
        'type' => 'boolean',
        'description' => 'Include all viewable Drupal fields in list, search, and saved-node responses. The get action always includes them.',
      ],
      'state' => ['type' => 'string'],
      'alias' => ['type' => 'string'],
      'promoted' => ['type' => 'boolean'],
      'revision_log' => ['type' => 'string'],
      'limit' => ['type' => 'integer', 'minimum' => 1, 'maximum' => 50],
      'offset' => [
        'type' => 'integer',
        'minimum' => 0,
        'description' => 'Result offset for list and search pagination.',
      ],
    ],
    'required' => ['action'],
  ],
  readOnly: FALSE,
  destructive: TRUE,
  idempotent: FALSE,
  openWorld: FALSE,
)]
final class Content extends ToolBase {
  protected const HANDLER = 'localgov_mcp.content';

}
