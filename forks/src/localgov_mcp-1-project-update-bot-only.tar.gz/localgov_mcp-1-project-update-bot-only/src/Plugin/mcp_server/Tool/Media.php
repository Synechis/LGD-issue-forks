<?php

declare(strict_types=1);

namespace Drupal\localgov_mcp\Plugin\mcp_server\Tool;

use Drupal\Core\StringTranslation\TranslatableMarkup;
use Drupal\localgov_mcp\ToolBase;
use Drupal\mcp_server\Attribute\Tool;

/**
 * Provides media operations. */
#[Tool(
  id: 'localgov_media',
  label: new TranslatableMarkup('Manage LocalGov media'),
  description: new TranslatableMarkup('Search, upload or update document, image and remote video media. File uploads use base64 data and a 15 MB limit.'),
  inputSchema: [
    'type' => 'object',
    'properties' => [
      'action' => ['type' => 'string', 'enum' => ['search', 'upload', 'update']],
      'id' => ['type' => 'integer', 'minimum' => 1],
      'bundle' => ['type' => 'string', 'enum' => ['document', 'image', 'remote_video']],
      'query' => ['type' => 'string'],
      'name' => ['type' => 'string'],
      'filename' => ['type' => 'string'],
      'file_base64' => ['type' => 'string'],
      'alt' => ['type' => 'string'],
      'remote_url' => ['type' => 'string'],
      'fields' => ['type' => 'object'],
      'limit' => ['type' => 'integer', 'minimum' => 1, 'maximum' => 50],
    ],
    'required' => ['action'],
  ],
  readOnly: FALSE,
  destructive: TRUE,
  idempotent: FALSE,
  openWorld: FALSE,
)]
final class Media extends ToolBase {
  protected const HANDLER = 'localgov_mcp.media';

}
