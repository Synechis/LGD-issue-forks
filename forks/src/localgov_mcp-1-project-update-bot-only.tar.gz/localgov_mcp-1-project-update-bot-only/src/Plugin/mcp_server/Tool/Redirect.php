<?php

declare(strict_types=1);

namespace Drupal\localgov_mcp\Plugin\mcp_server\Tool;

use Drupal\Core\StringTranslation\TranslatableMarkup;
use Drupal\localgov_mcp\ToolBase;
use Drupal\mcp_server\Attribute\Tool;

/**
 * Provides redirect and Fix 404 operations. */
#[Tool(
  id: 'localgov_redirect',
  label: new TranslatableMarkup('Manage URL redirects'),
  description: new TranslatableMarkup('List, search, add, update and delete redirects; list unresolved Fix 404 paths and add a redirect for one.'),
  inputSchema: [
    'type' => 'object',
    'properties' => [
      'action' => [
        'type' => 'string',
        'enum' => ['list', 'search', 'add', 'update', 'delete', 'fix_404', 'add_for_404'],
      ],
      'id' => ['type' => 'integer', 'minimum' => 1],
      'query' => ['type' => 'string'],
      'source' => ['type' => 'string'],
      'destination' => ['type' => 'string'],
      'status_code' => ['type' => 'integer', 'enum' => [301, 302, 307, 308]],
      'enabled' => ['type' => 'boolean'],
      'limit' => ['type' => 'integer', 'minimum' => 1, 'maximum' => 100],
    ],
    'required' => ['action'],
  ],
  readOnly: FALSE,
  destructive: TRUE,
  idempotent: FALSE,
  openWorld: FALSE,
)]
final class Redirect extends ToolBase {
  protected const HANDLER = 'localgov_mcp.redirect';

}
