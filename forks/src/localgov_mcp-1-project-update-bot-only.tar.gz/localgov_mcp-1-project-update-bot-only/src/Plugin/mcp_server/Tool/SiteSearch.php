<?php

declare(strict_types=1);

namespace Drupal\localgov_mcp\Plugin\mcp_server\Tool;

use Drupal\Core\StringTranslation\TranslatableMarkup;
use Drupal\localgov_mcp\ToolBase;
use Drupal\mcp_server\Attribute\Tool;

/**
 * Provides the site's indexed search. */
#[Tool(
  id: 'localgov_site_search',
  label: new TranslatableMarkup('Search the site'),
  description: new TranslatableMarkup('Last-resort full-text search through the site_search Search API index, with an access-checked node title and document media name fallback if the index fails. For lists of a content type, use localgov_content with action list; for title lookups, use its search action.'),
  inputSchema: [
    'type' => 'object',
    'properties' => [
      'query' => ['type' => 'string'],
      'limit' => ['type' => 'integer', 'minimum' => 1, 'maximum' => 50],
    ],
    'required' => ['query'],
  ],
  readOnly: TRUE,
  destructive: FALSE,
  idempotent: TRUE,
  openWorld: FALSE,
)]
final class SiteSearch extends ToolBase {
  protected const HANDLER = 'localgov_mcp.search';

}
