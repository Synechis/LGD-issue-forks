<?php

declare(strict_types=1);

namespace Drupal\localgov_mcp\Plugin\mcp_server\Tool;

use Drupal\Core\StringTranslation\TranslatableMarkup;
use Drupal\localgov_mcp\ToolBase;
use Drupal\mcp_server\Attribute\Tool;

/**
 * Provides banner operations. */
#[Tool(
  id: 'localgov_banner',
  label: new TranslatableMarkup('Manage alert banners'),
  description: new TranslatableMarkup('List alert banners or search their titles. Other actions: create, update, publish, unpublish, schedule.'),
  inputSchema: [
    'type' => 'object',
    'properties' => [
      'action' => ['type' => 'string', 'enum' => ['list', 'search', 'create', 'update', 'publish', 'unpublish', 'schedule']],
      'id' => ['type' => 'integer', 'minimum' => 1],
      'bundle' => [
        'type' => 'string',
        'enum' => ['localgov_alert_banner', 'localgov_full_page'],
        'description' => 'Optional banner type filter for list and search.',
      ],
      'query' => ['type' => 'string', 'description' => 'Title text to find. Required for search.'],
      'title' => ['type' => 'string'],
      'fields' => ['type' => 'object'],
      'state' => ['type' => 'string'],
      'at' => ['type' => 'string', 'description' => 'Future ISO 8601 date and time with timezone.'],
      'limit' => ['type' => 'integer', 'minimum' => 1, 'maximum' => 50],
      'offset' => ['type' => 'integer', 'minimum' => 0],
    ],
    'required' => ['action'],
  ],
  readOnly: FALSE,
  destructive: TRUE,
  idempotent: FALSE,
  openWorld: FALSE,
)]
final class Banner extends ToolBase {
  protected const HANDLER = 'localgov_mcp.banner';

}
