<?php

declare(strict_types=1);

namespace Drupal\localgov_mcp\Plugin\mcp_server\Tool;

use Drupal\Core\StringTranslation\TranslatableMarkup;
use Drupal\localgov_mcp\ToolBase;
use Drupal\mcp_server\Attribute\Tool;

/**
 * Schedules state changes. */
#[Tool(
  id: 'localgov_schedule',
  label: new TranslatableMarkup('Schedule a state change'),
  description: new TranslatableMarkup('Schedule a permitted workflow state transition for a node or alert banner revision.'),
  inputSchema: [
    'type' => 'object',
    'properties' => [
      'entity_type' => ['type' => 'string', 'enum' => ['node', 'localgov_alert_banner']],
      'id' => ['type' => 'integer', 'minimum' => 1],
      'state' => ['type' => 'string'],
      'at' => ['type' => 'string', 'description' => 'Future ISO 8601 date and time with timezone.'],
    ],
    'required' => ['entity_type', 'id', 'state', 'at'],
  ],
  readOnly: FALSE,
  destructive: TRUE,
  idempotent: FALSE,
  openWorld: FALSE,
)]
final class Scheduling extends ToolBase {
  protected const HANDLER = 'localgov_mcp.scheduling';

}
