<?php

declare(strict_types=1);

namespace Drupal\localgov_mcp;

use Drupal\Core\Entity\EntityTypeManagerInterface;
use Drupal\Core\Session\AccountProxyInterface;
use Drupal\taxonomy\TermInterface;

/**
 * Lists, finds and edits approved taxonomy vocabularies. */
final class TaxonomyOperations {

  public function __construct(
    private readonly Common $common,
    private readonly EntityTypeManagerInterface $entities,
    private readonly AccountProxyInterface $account,
  ) {}

  /**
   * Runs the requested operation.
   */
  public function handle(array $input): array {
    $action = Common::allowed(Common::required($input, 'action'), ['list', 'search', 'add', 'update'], 'taxonomy action');
    $vocabulary = Common::allowed(Common::required($input, 'vocabulary'), Common::VOCABULARIES, 'vocabulary');
    return in_array($action, ['list', 'search'], TRUE)
      ? $this->find($vocabulary, $action, $input)
      : $this->write($vocabulary, $action, $input);
  }

  /**
   * Lists accessible matching entities.
   */
  private function find(string $vocabulary, string $action, array $input): array {
    $storage = $this->entities->getStorage('taxonomy_term');
    $query = $storage->getQuery()->accessCheck(TRUE)->condition('vid', $vocabulary)->sort('name')->range(0, Common::limit($input, 100));
    if ($action === 'search') {
      $query->condition('name', Common::required($input, 'query'), 'CONTAINS');
    }
    $terms = [];
    foreach ($storage->loadMultiple($query->execute()) as $term) {
      if ($term->access('view', $this->account)) {
        $terms[] = $this->describe($term);
      }
    }
    return Common::success($terms);
  }

  /**
   * Creates or updates an entity.
   */
  private function write(string $vocabulary, string $action, array $input): array {
    $storage = $this->entities->getStorage('taxonomy_term');
    if ($action === 'add') {
      if (!$this->entities->getAccessControlHandler('taxonomy_term')->createAccess($vocabulary, $this->account)) {
        return Common::failure('Access denied to add terms.');
      }
      $term = $storage->create(['vid' => $vocabulary, 'name' => Common::required($input, 'name')]);
    }
    else {
      $term = $this->common->entity('taxonomy_term', (int) ($input['id'] ?? 0), [$vocabulary]);
      $this->common->access($term, 'update');
    }
    if (!$term instanceof TermInterface) {
      throw new \InvalidArgumentException('Term not found.');
    }
    if ($action === 'update') {
      if (isset($input['name'])) {
        $term->setName(Common::required($input, 'name'));
      }
    }
    if (isset($input['description'])) {
      $term->setDescription((string) $input['description']);
    }
    if (isset($input['parent_id'])) {
      $parent_id = (int) $input['parent_id'];
      if ($parent_id > 0) {
        $parent = $this->common->entity('taxonomy_term', $parent_id, [$vocabulary]);
        $this->common->access($parent, 'view');
        if ($action === 'update' && $parent_id === (int) $term->id()) {
          throw new \InvalidArgumentException('A term cannot be its own parent.');
        }
      }
      $term->set('parent', $parent_id > 0 ? ['target_id' => $parent_id] : []);
    }
    $this->common->fields($term, (array) ($input['fields'] ?? []));
    $this->common->validate($term);
    $term->save();
    return Common::success($this->describe($term));
  }

  /**
   * Builds a concise response for an entity.
   */
  private function describe(TermInterface $term): array {
    return [
      'id' => (int) $term->id(),
      'vocabulary' => $term->bundle(),
      'name' => $term->label(),
      'description' => $term->getDescription(),
    ];
  }

}
