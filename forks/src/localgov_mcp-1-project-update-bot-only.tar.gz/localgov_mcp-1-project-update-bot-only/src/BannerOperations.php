<?php

declare(strict_types=1);

namespace Drupal\localgov_mcp;

use Drupal\content_moderation\StateTransitionValidationInterface;
use Drupal\Core\Entity\EntityTypeManagerInterface;
use Drupal\Core\Session\AccountProxyInterface;
use Drupal\localgov_alert_banner\Entity\AlertBannerEntityInterface;

/**
 * Manages alert banners and their moderation states.
 */
final class BannerOperations {

  public function __construct(
    private readonly Common $common,
    private readonly EntityTypeManagerInterface $entities,
    private readonly AccountProxyInterface $account,
    private readonly StateTransitionValidationInterface $transitions,
    private readonly SchedulingOperations $scheduling,
  ) {}

  /**
   * Runs the requested operation.
   */
  public function handle(array $input): array {
    $action = Common::allowed(Common::required($input, 'action'), [
      'list', 'search', 'create', 'update', 'publish', 'unpublish', 'schedule',
    ], 'banner action');
    if (in_array($action, ['list', 'search'], TRUE)) {
      return $this->find($input, $action);
    }
    if ($action === 'schedule') {
      return $this->scheduling->schedule('localgov_alert_banner', (int) ($input['id'] ?? 0), Common::required($input, 'state'), Common::required($input, 'at'));
    }
    if ($action === 'create') {
      $bundle = Common::allowed((string) ($input['bundle'] ?? 'localgov_alert_banner'), [
        'localgov_alert_banner', 'localgov_full_page',
      ], 'banner type');
      $storage = $this->entities->getStorage('localgov_alert_banner');
      if (!$this->entities->getAccessControlHandler('localgov_alert_banner')->createAccess($bundle, $this->account)) {
        return Common::failure('Access denied to create this alert banner.');
      }
      $banner = $storage->create([
        'type' => $bundle,
        'title' => Common::required($input, 'title'),
        'uid' => $this->account->id(),
      ]);
    }
    else {
      $banner = $this->common->entity('localgov_alert_banner', (int) ($input['id'] ?? 0), [
        'localgov_alert_banner', 'localgov_full_page',
      ], TRUE);
      $this->common->access($banner, 'update');
      if (isset($input['title'])) {
        $banner->set('title', Common::required($input, 'title'));
      }
    }
    if (!$banner instanceof AlertBannerEntityInterface) {
      throw new \InvalidArgumentException('Alert banner not found.');
    }
    if ($action === 'create') {
      $banner->set('moderation_state', 'unpublished');
    }
    if (in_array($action, ['create', 'update'], TRUE)) {
      $this->common->fields($banner, (array) ($input['fields'] ?? []));
    }
    $state = match ($action) {
      'publish' => 'published',
      'unpublish' => 'unpublished',
      'update' => $input['state'] ?? 'draft',
      default => NULL,
    };
    if ($action === 'create' && isset($input['state']) && $input['state'] !== 'unpublished') {
      throw new \InvalidArgumentException('Create the banner first, then use publish or schedule.');
    }
    if ($state) {
      $allowed = FALSE;
      foreach ($this->transitions->getValidTransitions($banner, $this->account) as $transition) {
        $allowed = $allowed || $transition->to()->id() === $state;
      }
      if (!$allowed) {
        return Common::failure('The current account cannot make that banner transition.');
      }
      $banner->set('moderation_state', $state);
    }
    if (!$banner->isNew()) {
      $banner->setNewRevision(TRUE);
      $banner->setRevisionUserId((int) $this->account->id());
    }
    $this->common->validate($banner);
    $banner->save();
    return Common::success([
      'id' => (int) $banner->id(),
      'type' => $banner->bundle(),
      'title' => $banner->label(),
      'revision_id' => (int) $banner->getRevisionId(),
      'state' => $banner->get('moderation_state')->value,
    ]);
  }

  /**
   * Lists accessible banners or searches their titles.
   */
  private function find(array $input, string $action): array {
    $bundle = !empty($input['bundle'])
      ? Common::allowed((string) $input['bundle'], ['localgov_alert_banner', 'localgov_full_page'], 'banner type')
      : NULL;
    $title = $action === 'search' ? Common::required($input, 'query') : NULL;
    $storage = $this->entities->getStorage('localgov_alert_banner');
    $query = $storage->getQuery()->accessCheck(TRUE);
    if ($bundle !== NULL) {
      $query->condition('type', $bundle);
    }
    if ($title !== NULL) {
      $query->condition('title', $title, 'CONTAINS');
    }
    $query->sort('changed', 'DESC')->sort('id', 'DESC')
      ->range(max(0, (int) ($input['offset'] ?? 0)), Common::limit($input));
    $results = [];
    foreach ($storage->loadMultiple($query->execute()) as $banner) {
      if ($banner instanceof AlertBannerEntityInterface && $banner->access('view', $this->account)) {
        $results[] = [
          'id' => (int) $banner->id(),
          'type' => $banner->bundle(),
          'title' => $banner->label(),
          'revision_id' => (int) $banner->getRevisionId(),
          'state' => $banner->get('moderation_state')->value,
        ];
      }
    }
    return Common::success($results);
  }

}
