<?php

declare(strict_types=1);

namespace Drupal\localgov_mcp;

use Drupal\Core\Config\ConfigFactoryInterface;
use Drupal\Core\CronInterface;
use Drupal\Core\Database\Connection;
use Drupal\Core\Database\Statement\FetchAs;
use Drupal\Core\Session\AccountProxyInterface;

/**
 * Administrative site operations with per-action permissions. */
final class AdminOperations {

  public function __construct(
    private readonly Connection $database,
    private readonly ConfigFactoryInterface $config,
    private readonly AccountProxyInterface $account,
    private readonly CronInterface $cron,
  ) {}

  /**
   * Runs the requested operation.
   */
  public function handle(array $input): array {
    $action = Common::allowed(Common::required($input, 'action'), ['watchdog', 'maintenance', 'flush_cache', 'cron'], 'administration action');
    if ($action === 'watchdog') {
      if (!$this->account->hasPermission('access site reports')) {
        return Common::failure('Access site reports permission is required.');
      }
      $items = $this->database->select('watchdog', 'w')
        ->fields('w', ['wid', 'uid', 'type', 'message', 'severity', 'timestamp'])
        ->orderBy('wid', 'DESC')->range(0, Common::limit($input, 100))
        ->execute()->fetchAll(FetchAs::Associative);
      return Common::success($items);
    }
    if (!$this->account->hasPermission('administer site configuration')) {
      return Common::failure('Administer site configuration permission is required.');
    }
    if ($action === 'maintenance') {
      if (!isset($input['enabled']) || !is_bool($input['enabled'])) {
        throw new \InvalidArgumentException('enabled must be true or false.');
      }
      $this->config->getEditable('system.maintenance')->set('enabled', $input['enabled'])->save();
      return Common::success(['maintenance_enabled' => $input['enabled']]);
    }
    if ($action === 'flush_cache') {
      drupal_flush_all_caches();
      return Common::success(['caches_flushed' => TRUE]);
    }
    return Common::success(['cron_completed' => $this->cron->run()]);
  }

}
