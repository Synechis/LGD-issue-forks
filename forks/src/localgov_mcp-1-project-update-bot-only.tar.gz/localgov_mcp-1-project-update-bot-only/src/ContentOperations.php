<?php

declare(strict_types=1);

namespace Drupal\localgov_mcp;

use Drupal\Component\Datetime\TimeInterface;
use Drupal\content_lock\ContentLock\ContentLockInterface;
use Drupal\content_moderation\ModerationInformationInterface;
use Drupal\content_moderation\StateTransitionValidationInterface;
use Drupal\Core\Entity\EntityTypeManagerInterface;
use Drupal\Core\Session\AccountProxyInterface;
use Drupal\node\NodeInterface;

/**
 * Node listing, search, drafting, revisions and editorial actions.
 */
final class ContentOperations {

  public function __construct(
    private readonly Common $common,
    private readonly EntityTypeManagerInterface $entities,
    private readonly AccountProxyInterface $account,
    private readonly StateTransitionValidationInterface $transitions,
    private readonly ModerationInformationInterface $moderation,
    private readonly TimeInterface $time,
    private readonly ContentLockInterface $locks,
  ) {}

  /**
   * Runs the requested operation.
   */
  public function handle(array $input): array {
    $action = Common::allowed(Common::required($input, 'action'), [
      'get', 'list', 'search', 'create_draft', 'create_revision', 'publish', 'unpublish',
      'change_state', 'set_alias', 'promote', 'break_lock',
    ], 'content action');
    return match ($action) {
      'get' => $this->get($input),
      'list', 'search' => $this->find($input, $action),
      'create_draft' => $this->createDraft($input),
      default => $this->change($action, $input),
    };
  }

  /**
   * Returns a node and every field the account may view.
   */
  private function get(array $input): array {
    $node = $this->common->entity('node', (int) ($input['id'] ?? 0), Common::NODE_BUNDLES);
    if (!$node instanceof NodeInterface) {
      throw new \InvalidArgumentException('Node not found.');
    }
    $this->common->access($node, 'view');
    return Common::success($this->describe($node, TRUE));
  }

  /**
   * Lists or searches accessible nodes through the entity manager.
   */
  private function find(array $input, string $action): array {
    $bundle = NULL;
    $query = NULL;
    if ($action === 'list') {
      $bundle = Common::allowed(Common::required($input, 'bundle'), Common::NODE_BUNDLES, 'content type');
    }
    else {
      $query = Common::required($input, 'query');
      if (!empty($input['bundle'])) {
        $bundle = Common::allowed((string) $input['bundle'], Common::NODE_BUNDLES, 'content type');
      }
    }
    $storage = $this->entities->getStorage('node');
    $search = $storage->getQuery()->accessCheck(TRUE)
      ->condition('type', Common::NODE_BUNDLES, 'IN');
    if ($bundle !== NULL) {
      $search->condition('type', $bundle);
    }
    if ($query !== NULL) {
      $search->condition('title', $query, 'CONTAINS');
    }
    $search->sort('changed', 'DESC')->sort('nid', 'DESC')
      ->range(max(0, (int) ($input['offset'] ?? 0)), Common::limit($input));
    $results = [];
    foreach ($storage->loadMultiple($search->execute()) as $node) {
      if ($node->access('view', $this->account)) {
        $results[] = $this->describe($node, (bool) ($input['include_fields'] ?? FALSE));
      }
    }
    return Common::success($results);
  }

  /**
   * Creates a draft node.
   */
  private function createDraft(array $input): array {
    $bundle = Common::allowed(Common::required($input, 'bundle'), Common::NODE_BUNDLES, 'content type');
    $title = Common::required($input, 'title');
    $storage = $this->entities->getStorage('node');
    if (!$this->entities->getAccessControlHandler('node')->createAccess($bundle, $this->account)) {
      return Common::failure('Access denied to create this content type.');
    }
    $node = $storage->create(['type' => $bundle, 'title' => $title, 'uid' => $this->account->id()]);
    $node->set('moderation_state', 'draft');
    $this->common->fields($node, (array) ($input['fields'] ?? []));
    $this->common->validate($node);
    $node->save();
    return Common::success($this->describe($node, (bool) ($input['include_fields'] ?? FALSE)));
  }

  /**
   * Applies a node action and saves a revision.
   */
  private function change(string $action, array $input): array {
    $node = $this->common->entity('node', (int) ($input['id'] ?? 0), Common::NODE_BUNDLES, TRUE);
    if (!$node instanceof NodeInterface) {
      throw new \InvalidArgumentException('Node not found.');
    }
    if ($action === 'break_lock') {
      if (!$this->account->hasPermission('break content lock')) {
        return Common::failure('Break content lock permission is required.');
      }
      $this->common->access($node, 'update');
      $had_lock = (bool) $this->locks->fetchLock($node);
      if ($had_lock) {
        $this->locks->release($node);
      }
      return Common::success(['id' => (int) $node->id(), 'lock_released' => $had_lock]);
    }
    $this->common->access($node, 'update');
    $lock = $this->locks->fetchLock($node);
    if ($lock && (int) $lock->uid !== (int) $this->account->id()) {
      return Common::failure('This node is locked by another editor. Use break_lock if permitted.');
    }
    if ($action === 'create_revision') {
      $this->common->fields($node, (array) ($input['fields'] ?? []));
      if (isset($input['title'])) {
        $node->setTitle(Common::required($input, 'title'));
      }
      if (!empty($input['state'])) {
        $this->setState($node, (string) $input['state']);
      }
      else {
        // Explicit draft avoids accidentally publishing edits to a live node.
        $this->setState($node, 'draft');
      }
    }
    elseif (in_array($action, ['publish', 'unpublish', 'change_state'], TRUE)) {
      $state = match ($action) {
        'publish' => 'published',
        'unpublish' => 'unpublished',
        default => Common::required($input, 'state'),
      };
      $this->setState($node, $state);
    }
    elseif ($action === 'set_alias') {
      $this->setState($node, 'draft');
      $alias = '/' . ltrim(Common::required($input, 'alias'), '/');
      if ($alias === '/' || str_contains($alias, '?') || str_contains($alias, '#')) {
        throw new \InvalidArgumentException('Provide a valid site-relative URL alias.');
      }
      $node->set('path', ['alias' => $alias, 'pathauto' => 0]);
    }
    elseif ($action === 'promote') {
      $this->setState($node, 'draft');
      $node->setPromoted((bool) ($input['promoted'] ?? TRUE));
    }
    $node->setNewRevision(TRUE);
    $node->setRevisionUserId((int) $this->account->id());
    $node->setRevisionCreationTime($this->time->getRequestTime());
    $node->setRevisionLogMessage(trim((string) ($input['revision_log'] ?? '')) ?: 'Updated through LocalGov MCP.');
    $this->common->validate($node);
    $node->save();
    return Common::success($this->describe($node, (bool) ($input['include_fields'] ?? FALSE)));
  }

  /**
   * Checks and applies a moderation transition.
   */
  private function setState(NodeInterface $node, string $state): void {
    $workflow = $this->moderation->getWorkflowForEntity($node);
    if (!$workflow || !$workflow->getTypePlugin()->hasState($state)) {
      throw new \InvalidArgumentException('That moderation state is not available for this content type.');
    }
    foreach ($this->transitions->getValidTransitions($node, $this->account) as $transition) {
      if ($transition->to()->id() === $state) {
        $node->set('moderation_state', $state);
        return;
      }
    }
    throw new \InvalidArgumentException('The current account cannot make that moderation transition.');
  }

  /**
   * Builds a concise response for an entity.
   */
  private function describe(NodeInterface $node, bool $include_fields = FALSE): array {
    $data = [
      'id' => (int) $node->id(),
      'type' => $node->bundle(),
      'title' => $node->label(),
      'revision_id' => (int) $node->getRevisionId(),
      'state' => $node->get('moderation_state')->value,
      'published' => $node->isPublished(),
      'url' => $node->toUrl('canonical', ['absolute' => TRUE])->toString(),
    ];
    if ($include_fields) {
      $data['fields'] = [];
      foreach (array_keys($node->getFieldDefinitions()) as $name) {
        $field = $node->get($name);
        if ($field->access('view', $this->account)) {
          $data['fields'][$name] = $field->getValue();
        }
      }
    }
    return $data;
  }

}
