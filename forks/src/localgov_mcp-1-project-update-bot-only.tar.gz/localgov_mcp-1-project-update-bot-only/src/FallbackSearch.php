<?php

declare(strict_types=1);

namespace Drupal\localgov_mcp;

use Drupal\Core\Entity\EntityTypeManagerInterface;
use Drupal\Core\Session\AccountProxyInterface;

/**
 * Searches entity titles when the indexed site search cannot run.
 */
final class FallbackSearch {

  public function __construct(
    private readonly EntityTypeManagerInterface $entities,
    private readonly AccountProxyInterface $account,
  ) {}

  /**
   * Finds accessible nodes and document media without a Search API backend.
   */
  public function search(string $term, int $limit): array {
    $candidates = [];
    foreach ([['node', 'title'], ['media', 'name']] as [$type, $field]) {
      $storage = $this->entities->getStorage($type);
      $query = $storage->getQuery()->accessCheck(TRUE)
        ->condition($field, $term, 'CONTAINS');
      if ($type === 'media') {
        $query->condition('bundle', 'document');
      }
      $query->sort('changed', 'DESC')->range(0, $limit);
      foreach ($storage->loadMultiple($query->execute()) as $entity) {
        if (!$entity->access('view', $this->account)) {
          continue;
        }
        $candidates[] = [
          'changed' => $entity->getChangedTime(),
          'result' => [
            'entity_type' => $entity->getEntityTypeId(),
            'id' => (int) $entity->id(),
            'title' => $entity->label(),
            'url' => $entity->toUrl('canonical', ['absolute' => TRUE])->toString(),
          ],
        ];
      }
    }
    usort($candidates, static fn(array $a, array $b): int => $b['changed'] <=> $a['changed']);
    return array_map(static fn(array $candidate): array => $candidate['result'], array_slice($candidates, 0, $limit));
  }

}
