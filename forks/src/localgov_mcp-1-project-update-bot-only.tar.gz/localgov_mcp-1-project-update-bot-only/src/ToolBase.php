<?php

declare(strict_types=1);

namespace Drupal\localgov_mcp;

use Drupal\Core\Entity\EntityStorageException;
use Drupal\Core\Access\AccessResult;
use Drupal\Core\Access\AccessResultInterface;
use Drupal\Core\Config\ConfigFactoryInterface;
use Drupal\Core\Session\AccountInterface;
use Drupal\Core\Session\AccountProxyInterface;
use Drupal\mcp_server\Plugin\ToolPluginBase;
use Mcp\Server\ClientGateway;
use Symfony\Component\DependencyInjection\ContainerInterface;

/**
 * Shared adapter between MCP tool plugins and small operation services.
 */
abstract class ToolBase extends ToolPluginBase {

  /**
   * The service implementing handle(array): array. */
  protected const HANDLER = '';

  final public function __construct(array $configuration, string $plugin_id, mixed $plugin_definition, AccountProxyInterface $current_user, private readonly object $handler, private readonly ConfigFactoryInterface $configFactory) {
    parent::__construct($configuration, $plugin_id, $plugin_definition, $current_user);
  }

  /**
   * Creates the plugin with its operation service.
   */
  public static function create(ContainerInterface $container, array $configuration, $plugin_id, $plugin_definition): static {
    return new static($configuration, $plugin_id, $plugin_definition, $container->get('current_user'), $container->get(static::HANDLER), $container->get('config.factory'));
  }

  /**
   * Enables the tool by default.
   */
  protected function defaultConfiguration(): array {
    return ['enabled' => TRUE];
  }

  /**
   * Hides tools disabled in the module's configuration.
   */
  public function isEnabled(): bool {
    $disabled = $this->configFactory->get('localgov_mcp.settings')->get('disabled_tools') ?? [];
    return parent::isEnabled() && !in_array($this->getPluginId(), $disabled, TRUE);
  }

  /**
   * Restricts the tool to authenticated accounts.
   */
  public function checkAccess(AccountInterface $account): AccessResultInterface {
    return AccessResult::allowedIf($account->isAuthenticated());
  }

  /**
   * Runs the requested MCP operation.
   */
  public function execute(array $arguments, ClientGateway $gateway): mixed {
    try {
      return $this->handler->handle($arguments);
    }
    catch (\InvalidArgumentException $exception) {
      return Common::failure($exception->getMessage());
    }
    catch (EntityStorageException $exception) {
      return Common::failure('Drupal could not save the entity: ' . $exception->getMessage());
    }
  }

}
