<?php

declare(strict_types=1);

namespace Drupal\localgov_mcp;

use Drupal\Component\Datetime\TimeInterface;
use Drupal\content_moderation\ModerationInformationInterface;
use Drupal\content_moderation\StateTransitionValidationInterface;
use Drupal\Core\Session\AccountProxyInterface;
use Drupal\scheduled_transitions\Entity\ScheduledTransition;

/**
 * Schedules workflow transitions for supported editorial entities.
 */
final class SchedulingOperations {

  public function __construct(
    private readonly Common $common,
    private readonly AccountProxyInterface $account,
    private readonly ModerationInformationInterface $moderation,
    private readonly StateTransitionValidationInterface $transitions,
    private readonly TimeInterface $time,
  ) {}

  /**
   * Runs the requested operation.
   */
  public function handle(array $input): array {
    $type = Common::allowed(Common::required($input, 'entity_type'), ['node', 'localgov_alert_banner'], 'entity type');
    return $this->schedule($type, (int) ($input['id'] ?? 0), Common::required($input, 'state'), Common::required($input, 'at'));
  }

  /**
   * Creates a scheduled moderation transition.
   */
  public function schedule(string $type, int $id, string $state, string $at): array {
    if (!preg_match('/^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}(?:\.\d+)?(?:Z|[+-]\d{2}:\d{2})$/', $at)) {
      throw new \InvalidArgumentException('at must be a future ISO 8601 date and time with a timezone.');
    }
    $bundles = $type === 'node' ? Common::NODE_BUNDLES : ['localgov_alert_banner', 'localgov_full_page'];
    $entity = $this->common->entity($type, $id, $bundles, TRUE);
    $this->common->access($entity, 'update');
    if (!$entity->access('add scheduled transition', $this->account)) {
      return Common::failure('Permission to schedule this entity type is required.');
    }
    $workflow = $this->moderation->getWorkflowForEntity($entity);
    if (!$workflow || !$workflow->getTypePlugin()->hasState($state)) {
      throw new \InvalidArgumentException('This state is not available in the entity workflow.');
    }
    $allowed = FALSE;
    foreach ($this->transitions->getValidTransitions($entity, $this->account) as $transition) {
      $allowed = $allowed || $transition->to()->id() === $state;
    }
    if (!$allowed) {
      return Common::failure('The current account cannot schedule that moderation transition.');
    }
    try {
      $date = new \DateTimeImmutable($at);
    }
    catch (\Exception) {
      throw new \InvalidArgumentException('at must be an ISO 8601 date and time with a timezone.');
    }
    $date_errors = \DateTimeImmutable::getLastErrors();
    if ($date_errors && ($date_errors['warning_count'] > 0 || $date_errors['error_count'] > 0)) {
      throw new \InvalidArgumentException('at contains an invalid calendar date or time.');
    }
    if ($date->getTimestamp() <= $this->time->getRequestTime()) {
      throw new \InvalidArgumentException('at must be a future ISO 8601 date and time with a timezone.');
    }
    $scheduled = ScheduledTransition::createFrom($workflow, $state, $entity, $date, $this->account);
    $scheduled->save();
    return Common::success([
      'scheduled_transition_id' => (int) $scheduled->id(),
      'entity_type' => $type,
      'entity_id' => $id,
      'revision_id' => (int) $entity->getRevisionId(),
      'state' => $state,
      'at' => $date->format(\DateTimeInterface::ATOM),
    ]);
  }

}
