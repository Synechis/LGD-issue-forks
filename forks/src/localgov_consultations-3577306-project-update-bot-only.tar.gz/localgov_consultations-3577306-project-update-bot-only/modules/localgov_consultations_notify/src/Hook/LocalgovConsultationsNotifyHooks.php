<?php

namespace Drupal\localgov_consultations_notify\Hook;

use Drupal\Core\Form\FormStateInterface;
use Drupal\localgov_consultations_notify\NotificationReason;
use Drupal\Component\Utility\DeprecationHelper;
use Drupal\node\NodeInterface;
use Drupal\Core\Entity\EntityInterface;
use Drupal\Core\Hook\Attribute\Hook;
use Drupal\Core\StringTranslation\StringTranslationTrait;

/**
 * Hook implementations for localgov_consultations_notify.
 */
class LocalgovConsultationsNotifyHooks {
  use StringTranslationTrait;

  /**
   * Implements hook_ENTITY_TYPE_presave().
   */
  #[Hook('mailing_list_subscription_presave')]
  public function mailingListSubscriptionPresave(EntityInterface $entity) {
    // Set node and title on new subscriptions.
    if ($entity->isNew()) {
      $mailing_list = $entity->get('mailing_list')->getValue()[0]['target_id'];
      switch ($mailing_list) {
        case 'all_consultations':
          $entity->set('title', 'All Consultations');
          break;

        case 'consultations':
          $route_match_node = \Drupal::routeMatch()->getParameter('node');
          if ($route_match_node && $route_match_node->bundle() === 'consultation') {
            // We've just created a mailing list subscription from a consultation.
            // Set the consultation nid on the subscription entity.
            $entity->set('field_node', $route_match_node->id());
            $entity->set('title', $route_match_node->getTitle());
          }
          break;
      }
    }
  }

  /**
   * Implements hook_ENTITY_TYPE_insert().
   *
   * Respond to mailing list subscription created.
   */
  #[Hook('mailing_list_subscription_insert')]
  public function mailingListSubscriptionInsert(EntityInterface $entity) {
    /** @var \Drupal\localgov_consultations_notify\SubscriptionHandler $subscription_handler */
    $subscription_handler = \Drupal::service('localgov_consultations_notify.subscription_handler');
    $subscription_handler->onSubscribe($entity);
  }

  /**
   * Implements hook_ENTITY_TYPE_update().
   */
  #[Hook('node_update')]
  public function nodeUpdate(NodeInterface $entity): void {
    if ($entity->bundle() == 'consultation') {
      /** @var \Drupal\localgov_consultations_notify\Notifier $notifier */
      $notifier = \Drupal::service('localgov_consultations_notify.notifier');
      // Check for status changes.
      $current_status = $entity->get('localgov_consultation_status')->value;
      $original_status = DeprecationHelper::backwardsCompatibleCall(\Drupal::VERSION, '11.2.0', fn() => $entity->getOriginal(), fn() => $entity->original)->get('localgov_consultation_status')->value;
      if ($current_status !== $original_status) {
        // Consultation has been opened.
        if ($original_status === 'upcoming' && $current_status === 'open') {
          $notifier->notifySubscribers($entity, NotificationReason::ConsultationOpened);
          \Drupal::messenger()->addMessage('An email has been scheduled to inform subscribers that the consultation has opened');
        }
        // Consultation has been closed.
        if ($original_status === 'open' && $current_status === 'closed') {
          $notifier->notifySubscribers($entity, NotificationReason::ConsultationClosed);
          $notifier->notifyConsultationContact($entity, NotificationReason::ConsultationClosed);
          \Drupal::messenger()->addMessage('An email has been scheduled to inform subscribers that the consultation has closed');
        }
      }
      // Check if dates have changed.
      $current_field = $entity->get('localgov_consultation_date');
      $original_field = DeprecationHelper::backwardsCompatibleCall(\Drupal::VERSION, '11.2.0', fn() => $entity->getOriginal(), fn() => $entity->original)->get('localgov_consultation_date');
      if (!$current_field->isEmpty() && !$original_field->isEmpty()) {
        $current_values = $current_field->getValue();
        $original_values = $original_field->getValue();
        $current_start = $current_values[0]['value'] ?? NULL;
        $current_end = $current_values[0]['end_value'] ?? NULL;
        $original_start = $original_values[0]['value'] ?? NULL;
        $original_end = $original_values[0]['end_value'] ?? NULL;
        if ($current_start !== $original_start || $current_end !== $original_end) {
          $notifier->notifySubscribers($entity, NotificationReason::ConsultationDatesChanged);
          \Drupal::messenger()->addMessage('An email has been scheduled to inform subscribers about the date change');
        }
      }
    }
  }

  /**
   * Implements hook_mail().
   */
  #[Hook('mail')]
  public function mail($key, &$message, $params) {
    $options = [
      'langcode' => $message['langcode'],
    ];
    switch ($key) {
      case 'localgov_consultations_email_queue':
        $message['from'] = \Drupal::config('system.site')->get('mail');
        $message['subject'] = $this->t($params['title'], $options);
        $message['body'][] = $params['message'];
        break;
    }
  }

  /**
   * Implements hook_form_alter().
   */
  #[Hook('form_alter')]
  public function formAlter(&$form, FormStateInterface &$form_state) {
    if (isset($form['#entity_type']) && $form['#entity_type'] == 'mailing_list_subscription') {
      $form['actions']['submit']['#submit'][] = 'localgov_consultations_form_submit';
      $form['#validate'][] = 'localgov_consultations_notify_subscription_form_validate';
    }
    if ($form['#form_id'] == 'mailing_list_anonymous_subscription_access_form') {
      $form['#submit'][] = 'localgov_consultations_notify_login_request_form_submit';
    }
  }

}
