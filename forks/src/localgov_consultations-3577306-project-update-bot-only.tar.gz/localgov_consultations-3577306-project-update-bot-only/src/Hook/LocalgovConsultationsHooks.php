<?php

namespace Drupal\localgov_consultations\Hook;

use Drupal\Core\Hook\Attribute\Hook;

/**
 * Hook implementations for localgov_consultations.
 */
class LocalgovConsultationsHooks {

  /**
   * Implements hook_theme().
   */
  #[Hook('theme')]
  public function theme($existing, $type, $theme, $path) {
    return [
      'node__consultation' => [
        'template' => 'node--consultation',
        'base hook' => 'node',
      ],
      'node__consultation__teaser' => [
        'template' => 'node--consultation--teaser',
        'base hook' => 'node',
      ],
      'views_view__consultations' => [
        'template' => 'views-view--consultations',
        'base hook' => 'views_view',
        'path' => $path . '/templates',
      ],
      'field__node__localgov_consultation_date__consultation' => [
        'base hook' => 'field',
        'template' => 'field--node--localgov-consultation-date--consultation',
        'path' => $path . '/templates/field',
      ],
      'field__node__localgov_consultation_timeline__consultation' => [
        'base hook' => 'field',
        'template' => 'field--node--localgov-consultation-timeline--consultation',
        'path' => $path . '/templates/field',
      ],
      'paragraph__localgov_consultation_tl_steps' => [
        'template' => 'paragraph--localgov-consultation-tl-steps',
        'base hook' => 'paragraph',
        'path' => $path . '/templates/paragraphs',
      ],
      'paragraph__localgov_consultation_timeline' => [
        'template' => 'paragraph--localgov-consultation-timeline',
        'base hook' => 'paragraph',
        'path' => $path . '/templates/paragraphs',
      ],
    ];
  }

  /**
   * Implements hook_preprocess_views_view().
   *
   * @param array $vars
   *   Variables array for the views view template.
   */
  #[Hook('preprocess_views_view')]
  public function preprocessViewsView(array &$vars): void {
    if ($vars['view']->id() == "consultations") {
      $vars['#attached']['library'][] = 'localgov_consultations/localgov_consultations';
      // Utilise localgov_base styling if available.
      $vars['#attached']['library'][] = 'localgov_base/teaser';
    }
  }

  /**
   * Implements hook_preprocess_node().
   *
   * @param array $variables
   *   Variables array for the node template.
   */
  #[Hook('preprocess_node')]
  public function preprocessNode(array &$variables): void {
    $node = $variables['node'];
    if ($node->bundle() === 'consultation') {
      $variables['#attached']['library'][] = 'localgov_consultations/localgov_consultations';
      if ($node->hasField('localgov_consultation_date') && !$node->get('localgov_consultation_date')->isEmpty()) {
        $date_item = $node->get('localgov_consultation_date')->first();
        // Convert ISO string from DB to timestamps.
        $start_ts = strtotime($date_item->value);
        $end_ts = strtotime($date_item->end_value);
        $now = time();
        $date_formatter = \Drupal::service('date.formatter');
        $format = 'd M Y';
        if ($now < $start_ts) {
          $text = "Opens on " . $date_formatter->format($start_ts, 'custom', $format);
          $status_class = 'upcoming';
        }
        elseif ($now >= $start_ts && $now <= $end_ts) {
          $text = "Closes on " . $date_formatter->format($end_ts, 'custom', $format);
          $status_class = 'open';
        }
        else {
          $text = "Closed on " . $date_formatter->format($end_ts, 'custom', $format);
          $status_class = 'closed';
        }
        $variables['consultation_display_date'] = [
          '#markup' => $text,
          '#prefix' => '<span class="consultation-status-label ' . $status_class . '">',
          '#suffix' => '</span>',
        ];
      }
      if ($node->hasField('localgov_consultation_contact') && !$node->get('localgov_consultation_contact')->isEmpty()) {
        $contacts = $node->get('localgov_consultation_contact');
        $service_contacts = [];
        foreach ($contacts as $contact) {
          if ($entity = $contact->entity) {
            $service_contacts[] = [
              'name' => $entity->get('name')->value,
              'email' => $entity->get('email')->value,
            ];
          }
        }
        $variables['consultation_contacts'] = $service_contacts;
      }
      if ($variables['view_mode'] == "teaser") {
        $teaser_media_field = !$node->get('localgov_consultation_teaser_img')->isEmpty() ? $node->get("localgov_consultation_teaser_img") : $node->get("localgov_consultation_banner");
        if ($teaser_media_field->isEmpty()) {
          // Neither field is populated...
          return;
        }
        $teaser_media = $teaser_media_field->entity;
        if ($teaser_media && $teaser_media->hasField('field_media_image')) {
          $variables['localgov_consultation_teaser_img'] = $teaser_media->field_media_image->view([
            'type' => 'image',
            'label' => 'hidden',
            'settings' => [
                    // 'image_link' => 'content',
              'image_style' => 'large_3_2_768x512',
            ],
          ]);
        }
      }
    }
  }

  /**
   * Implements hook_cron().
   *
   * Automatically update consultation statuses based on their dates.
   */
  #[Hook('cron')]
  public function cron() {
    \Drupal::service('localgov_consultations.status_manager')->updateConsultationStatuses();
  }

}
