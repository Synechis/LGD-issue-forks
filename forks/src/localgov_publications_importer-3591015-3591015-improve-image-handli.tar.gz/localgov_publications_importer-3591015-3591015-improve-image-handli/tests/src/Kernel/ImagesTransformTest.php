<?php

declare(strict_types=1);

namespace Drupal\Tests\localgov_publications_importer\Kernel;

use Drupal\Core\File\FileSystemInterface;
use Drupal\field\Entity\FieldConfig;
use Drupal\field\Entity\FieldStorageConfig;
use Drupal\KernelTests\KernelTestBase;
use Drupal\localgov_publications_importer\Entity\Import;
use Drupal\localgov_publications_importer\Image;
use Drupal\localgov_publications_importer\ImageInterface;
use Drupal\localgov_publications_importer\Page;
use Drupal\localgov_publications_importer\Plugin\LocalGovImporter\Transform\Images;
use Drupal\media\Entity\Media;
use Drupal\media\Entity\MediaType;

/**
 * Kernel tests for the Images transform plugin.
 *
 * @group localgov_publications_importer
 */
class ImagesTransformTest extends KernelTestBase {

  /**
   * {@inheritdoc}
   */
  protected static $modules = [
    'system',
    'user',
    'field',
    'filter',
    'text',
    'node',
    'file',
    'image',
    'media',
  ];

  /**
   * {@inheritdoc}
   */
  protected function setUp(): void {
    parent::setUp();

    $this->enableModules(['localgov_publications_importer']);

    $this->installEntitySchema('user');
    $this->installEntitySchema('file');
    $this->installEntitySchema('media');
    $this->installEntitySchema('localgov_import');
    $this->installSchema('file', ['file_usage']);
    $this->installConfig(['system', 'field', 'file', 'image', 'media']);

    // Create the field storage for field_media_image.
    FieldStorageConfig::create([
      'field_name' => 'field_media_image',
      'entity_type' => 'media',
      'type' => 'image',
      'cardinality' => 1,
    ])->save();

    // Create the image media type.
    MediaType::create([
      'id' => 'image',
      'label' => 'Image',
      'source' => 'image',
      'source_configuration' => [
        'source_field' => 'field_media_image',
      ],
    ])->save();

    // Create the field instance on the image bundle.
    FieldConfig::create([
      'field_name' => 'field_media_image',
      'entity_type' => 'media',
      'bundle' => 'image',
      'label' => 'Image',
      'required' => TRUE,
      'settings' => [
        'alt_field' => TRUE,
        'alt_field_required' => FALSE,
        'title_field' => TRUE,
        'title_field_required' => FALSE,
      ],
    ])->save();

    $publicDir = 'public://';
    $this->container->get('file_system')
      ->prepareDirectory($publicDir, FileSystemInterface::CREATE_DIRECTORY | FileSystemInterface::MODIFY_PERMISSIONS);
  }

  /**
   * Data provider for testImageCreation().
   */
  public static function imageProvider(): array {
    $pngIm = imagecreatetruecolor(1, 1);
    ob_start();
    imagepng($pngIm);
    $pngBytes = ob_get_clean();
    imagedestroy($pngIm);

    $pngImage = new Image();
    $pngImage->setFilter(ImageInterface::FILTER_NONE);
    $pngImage->setWidth(1);
    $pngImage->setHeight(1);
    $pngImage->setBitsPerComponent(8);
    $pngImage->setColorSpace('DeviceRGB');

    $jpegIm = imagecreatetruecolor(1, 1);
    ob_start();
    imagejpeg($jpegIm);
    $jpegBytes = ob_get_clean();
    imagedestroy($jpegIm);

    $jpegImage = new Image();
    $jpegImage->setFilter('DCTDecode');
    $jpegImage->setWidth(1);
    $jpegImage->setHeight(1);
    $jpegImage->setBitsPerComponent(8);
    $jpegImage->setColorSpace('DeviceRGB');

    return [
      'FILTER_NONE' => [$pngImage, $pngBytes],
      'DCTDecode' => [$jpegImage, $jpegBytes],
    ];
  }

  /**
   * Tests that an image gets a file and media entity after transform.
   *
   * @dataProvider imageProvider
   */
  public function testImageCreation(Image $image, string $imageBytes): void {

    // This can't happen in the data provider as it needs the container set up
    // to work.
    $image->setRawDataFile($this->writeTempFile($imageBytes));

    $page = new Page();
    $page->addImage($image);

    $import = Import::create(['title' => 'Test import']);
    $import->addPage($page);
    $import->save();

    $plugin = Images::create($this->container, [], 'transform_images', []);
    $plugin->transform($import);

    // transform() serialises the mutated pages back into the entity, so reload
    // the images from the import rather than from the original DTO.
    $importedImage = $import->getPages()[0]->getImages()[0];

    $this->assertNotNull($importedImage->getFileId(), 'Image has a file entity ID after transform.');
    $this->assertNotNull($importedImage->getMediaId(), 'Image has a media entity ID after transform.');

    $media = Media::load($importedImage->getMediaId());
    $this->assertInstanceOf(Media::class, $media);
    $this->assertEquals('image', $media->bundle());
    $this->assertEquals($importedImage->getFileId(), $media->get('field_media_image')->target_id);
  }

  /**
   * Writes binary data to a temporary stream-wrapper file and returns its URI.
   */
  private function writeTempFile(string $content): string {
    $uuid = $this->container->get('uuid')->generate();
    $dir = 'temporary://localgov_publications_importer';
    $this->container->get('file_system')
      ->prepareDirectory($dir, FileSystemInterface::CREATE_DIRECTORY);
    $path = $dir . '/' . $uuid;
    file_put_contents((string) $path, $content);
    return $path;
  }

}
