<?php

namespace Drupal\Tests\localgov_publications_importer\Functional;

use Drupal\localgov_publications_importer\Entity\ImportPipeline;

/**
 * Tests the ImportPipelineForm.
 *
 * @group localgov_publications_importer
 */
class ImportPipelineFormTest extends FunctionalTestBase {

  /**
   * Test the pipeline add form has the expected fields.
   */
  public function testAddFormRendersFields(): void {
    $user = $this->drupalCreateUser(['create import pipelines']);
    $this->drupalLogin($user);
    $this->drupalGet('admin/config/system/localgov-import-pipeline/add');
    $this->assertSession()->statusCodeEquals(200);

    // Basic fields.
    $this->assertSession()->fieldExists('Pipeline name');
    $this->assertSession()->fieldExists('id');
    $this->assertSession()->fieldExists('Extract Plugin');
    $this->assertSession()->fieldExists('Save Plugin');

    // Transform plugin checkboxes should be present.
    $this->assertSession()->fieldExists('selected_transform_plugin[transform_line_breaks]');
    $this->assertSession()->fieldExists('selected_transform_plugin[transform_page_limit]');
  }

  /**
   * Test submitting the add form creates a new pipeline entity.
   */
  public function testAddFormCreatesPipeline(): void {
    $user = $this->drupalCreateUser(['create import pipelines']);
    $this->drupalLogin($user);
    $this->drupalGet('admin/config/system/localgov-import-pipeline/add');

    $this->submitForm([
      'Pipeline name' => 'My Test Pipeline',
      'id' => 'my_test_pipeline',
      'extract_plugin' => 'smalot_pdfparser',
      'save_plugin' => 'save_publication',
    ], 'Save');

    // Should redirect to the collection page.
    $this->assertSession()->addressEquals('admin/config/system/localgov-import-pipeline');

    // The entity should exist.
    $pipeline = ImportPipeline::load('my_test_pipeline');
    $this->assertInstanceOf(ImportPipeline::class, $pipeline);
    $this->assertEquals('My Test Pipeline', $pipeline->label());
    $this->assertEquals('smalot_pdfparser', $pipeline->extract_plugin);
    $this->assertEquals('save_publication', $pipeline->save_plugin);
    $this->assertEquals([], $pipeline->transform_plugins);
  }

  /**
   * Test that the edit form shows the entity's current values.
   */
  public function testEditFormShowsEntityValues(): void {
    /** @var \Drupal\Core\Entity\EntityTypeManagerInterface $entityTypeManager */
    $entityTypeManager = $this->container->get('entity_type.manager');
    $entityTypeManager->getStorage('localgov_import_pipeline')->create([
      'id' => 'existing_pipeline',
      'label' => 'Existing Pipeline',
      'extract_plugin' => 'smalot_pdfparser',
      'save_plugin' => 'save_publication',
    ])->save();

    $user = $this->drupalCreateUser(['update import pipelines']);
    $this->drupalLogin($user);
    $this->drupalGet('admin/config/system/localgov-import-pipeline/existing_pipeline');

    $this->assertSession()->statusCodeEquals(200);
    $this->assertSession()->fieldValueEquals('Pipeline name', 'Existing Pipeline');
    $this->assertSession()->fieldValueEquals('extract_plugin', 'smalot_pdfparser');
    $this->assertSession()->fieldValueEquals('save_plugin', 'save_publication');
  }

  /**
   * Test saving the edit form updates the entity.
   */
  public function testEditFormUpdatesPipeline(): void {
    /** @var \Drupal\Core\Entity\EntityTypeManagerInterface $entityTypeManager */
    $entityTypeManager = $this->container->get('entity_type.manager');
    $entityTypeManager->getStorage('localgov_import_pipeline')->create([
      'id' => 'pipeline_to_edit',
      'label' => 'Original Label',
      'extract_plugin' => 'smalot_pdfparser',
      'save_plugin' => 'save_publication',
    ])->save();

    $user = $this->drupalCreateUser(['update import pipelines']);
    $this->drupalLogin($user);
    $this->drupalGet('admin/config/system/localgov-import-pipeline/pipeline_to_edit');

    $this->submitForm([
      'Pipeline name' => 'Updated Label',
    ], 'Save');

    $this->assertSession()->addressEquals('admin/config/system/localgov-import-pipeline');

    // Reload the entity and check it was updated.
    $pipeline = $this->reloadEntity(ImportPipeline::load('pipeline_to_edit'));
    $this->assertEquals('Updated Label', $pipeline->label());
  }

  /**
   * Test the table of transform plugins appears when a pipeline has them.
   */
  public function testTransformPluginTableAppearsForEntityWithTransforms(): void {
    /** @var \Drupal\Core\Entity\EntityTypeManagerInterface $entityTypeManager */
    $entityTypeManager = $this->container->get('entity_type.manager');
    $entityTypeManager->getStorage('localgov_import_pipeline')->create([
      'id' => 'pipeline_with_transforms',
      'label' => 'Pipeline With Transforms',
      'extract_plugin' => 'smalot_pdfparser',
      'save_plugin' => 'save_publication',
      'transform_plugins' => [0 => 'transform_line_breaks'],
    ])->save();

    $user = $this->drupalCreateUser(['update import pipelines']);
    $this->drupalLogin($user);
    $this->drupalGet('admin/config/system/localgov-import-pipeline/pipeline_with_transforms');

    $this->assertSession()->statusCodeEquals(200);

    // The checkbox for the selected plugin should be checked.
    $this->assertSession()->checkboxChecked('selected_transform_plugin[transform_line_breaks]');

    // The transform plugins table should be rendered.
    $this->assertSession()->elementExists('css', 'table');
    $this->assertSession()->pageTextContains('Transform Plugins');
  }

  /**
   * Test the configurable transform plugin shows its configuration fields.
   */
  public function testConfigurableTransformPluginShowsConfigFields(): void {
    /** @var \Drupal\Core\Entity\EntityTypeManagerInterface $entityTypeManager */
    $entityTypeManager = $this->container->get('entity_type.manager');
    $entityTypeManager->getStorage('localgov_import_pipeline')->create([
      'id' => 'pipeline_with_page_limit',
      'label' => 'Pipeline With Page Limit',
      'extract_plugin' => 'smalot_pdfparser',
      'save_plugin' => 'save_publication',
      'transform_plugins' => [0 => 'transform_page_limit'],
      'transform_plugin_configurations' => [0 => ['limit' => 5, 'offset' => 2]],
    ])->save();

    $user = $this->drupalCreateUser(['update import pipelines']);
    $this->drupalLogin($user);
    $this->drupalGet('admin/config/system/localgov-import-pipeline/pipeline_with_page_limit');

    $this->assertSession()->statusCodeEquals(200);
    $this->assertSession()->checkboxChecked('selected_transform_plugin[transform_page_limit]');

    // Configuration fields for the PageLimit plugin should be rendered.
    $this->assertSession()->fieldValueEquals('transform_plugins[0][configuration][limit]', '5');
    $this->assertSession()->fieldValueEquals('transform_plugins[0][configuration][offset]', '2');
  }

  /**
   * Test that saving the edit form preserves existing transform plugins.
   *
   * Adding transform plugins via the form requires AJAX interaction. This test
   * verifies that when editing an entity whose transform plugins are already
   * set, they are preserved through a form submission.
   */
  public function testEditFormPreservesTransformPlugins(): void {

    $expectedTransformPlugins = [
      'transform_line_breaks',
    ];

    /** @var \Drupal\Core\Entity\EntityTypeManagerInterface $entityTypeManager */
    $entityTypeManager = $this->container->get('entity_type.manager');
    $entityTypeManager->getStorage('localgov_import_pipeline')->create([
      'id' => 'pipeline_preserve_transforms',
      'label' => 'Pipeline Preserve Transforms',
      'extract_plugin' => 'smalot_pdfparser',
      'save_plugin' => 'save_publication',
      'transform_plugins' => $expectedTransformPlugins,
    ])->save();

    $user = $this->drupalCreateUser(['update import pipelines']);
    $this->drupalLogin($user);
    $this->drupalGet('admin/config/system/localgov-import-pipeline/pipeline_preserve_transforms');

    // Submit the form changing only the label.
    $this->submitForm([
      'Pipeline name' => 'Updated Label',
    ], 'Save');

    $this->assertSession()->addressEquals('admin/config/system/localgov-import-pipeline');

    $pipeline = $this->reloadEntity(ImportPipeline::load('pipeline_preserve_transforms'));
    $this->assertEquals('Updated Label', $pipeline->label());
    $this->assertEquals($expectedTransformPlugins, $pipeline->transform_plugins);
  }

  /**
   * Reload an entity to get fresh data from storage.
   */
  protected function reloadEntity(ImportPipeline $entity): ImportPipeline {
    $storage = $this->container->get('entity_type.manager')
      ->getStorage('localgov_import_pipeline');
    $storage->resetCache([$entity->id()]);
    return $storage->load($entity->id());
  }

}
