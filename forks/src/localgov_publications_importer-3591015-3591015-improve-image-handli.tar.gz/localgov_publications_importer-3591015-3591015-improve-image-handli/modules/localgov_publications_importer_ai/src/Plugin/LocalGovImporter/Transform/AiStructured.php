<?php

namespace Drupal\localgov_publications_importer_ai\Plugin\LocalGovImporter\Transform;

use Drupal\Core\Entity\EntityTypeManagerInterface;
use Drupal\Core\StringTranslation\TranslatableMarkup;
use Drupal\ai\AiProviderPluginManager;
use Drupal\ai\Exception\AiRequestErrorException;
use Drupal\ai\OperationType\Chat\ChatInput;
use Drupal\ai\OperationType\Chat\ChatMessage;
use Drupal\ai\OperationType\Chat\Tools\ToolsInput;
use Drupal\localgov_publications_importer\Attribute\Transform;
use Drupal\localgov_publications_importer\Entity\ImportPipeline;
use Drupal\localgov_publications_importer\Exception\RetryableTransformFailure;
use Drupal\localgov_publications_importer\ImportInterface;
use Drupal\localgov_publications_importer\Page;
use Drupal\localgov_publications_importer\Plugin\ParagraphTypesProviderInterface;
use Drupal\localgov_publications_importer\SaveOperationManager;
use Drupal\localgov_publications_importer\Service\ParagraphSchemaDiscovery;
use Drupal\localgov_publications_importer_ai\Tool\FormatStructuredPagesTool;
use Symfony\Component\DependencyInjection\ContainerInterface;

/**
 * Transform operation that uses AI to produce structured paragraph content.
 */
#[Transform(
  id: 'transform_ai_structured',
  label: new TranslatableMarkup('AI structured paragraphs'),
  description: new TranslatableMarkup("Uses AI to split a document into pages and convert content into typed paragraph data matching the site's paragraph types.")
)]
class AiStructured extends AiAllInOne {

  /**
   * {@inheritDoc}
   */
  protected string $prompt = <<<PROMPT
You are a website content editor. Convert the provided document text into structured publication pages.

Available paragraph types:
[paragraph-types]

Requirements:
- Return ONLY a JSON array of page objects, no other text
- Each page object has: "title" (string), "paragraphs" (array of paragraph objects)
- Split the content into MULTIPLE pages (200-500 words each when possible)
- Break pages at natural stopping points: section boundaries, topic changes, or major headings
- Generate descriptive titles that reflect each page's main topic
- Each paragraph object must include a "type" field matching one of the available paragraph types above
- Populate paragraph fields using the types described — use the most appropriate paragraph type for each piece of content
- For text_long fields, use only these HTML tags: h2, h3, h4, p, ul, ol, li
- For link fields, provide {"uri": "...", "title": "..."} objects
- Ensure any JSON you create is valid — this is critical
- Properly escape all double quotes in JSON strings

Example format:
[
  {
    "title": "Introduction",
    "paragraphs": [
      {"type": "localgov_text", "localgov_text": "<p>Intro content...</p>"},
      {"type": "localgov_link", "localgov_title": "Apply now", "localgov_url": "https://example.com/apply"}
    ]
  }
]

PROMPT;

  /**
   * {@inheritdoc}
   */
  public static function create(ContainerInterface $container, array $configuration, $plugin_id, $plugin_definition) {
    return new static(
      $configuration,
      $plugin_id,
      $plugin_definition,
      $container->get('ai.provider'),
      $container->get(ParagraphSchemaDiscovery::class),
      $container->get(SaveOperationManager::class),
      $container->get('entity_type.manager'),
    );
  }

  /**
   * Constructor.
   */
  public function __construct(
    array $configuration,
    $plugin_id,
    $plugin_definition,
    AiProviderPluginManager $aiProviderPluginManager,
    protected ParagraphSchemaDiscovery $paragraphSchemaDiscovery,
    protected SaveOperationManager $saveOperationManager,
    protected EntityTypeManagerInterface $entityTypeManager,
  ) {
    parent::__construct($configuration, $plugin_id, $plugin_definition, $aiProviderPluginManager);
  }

  /**
   * {@inheritDoc}
   */
  public function transform(ImportInterface $import, ?int $page = NULL): void {

    // Only run once for the whole document.
    if ($page > 0) {
      return;
    }

    $paragraphSchema = $this->paragraphSchemaDiscovery->getSchema();

    $paragraphSchema = $this->filterSchemaForSavePlugin($import, $paragraphSchema);

    if ($paragraphSchema === []) {
      throw new \Exception('No AI-fillable paragraph types found in AiStructured transform.');
    }

    $content = [];
    foreach ($import->getPages() as $pageObj) {
      $pageContent = $pageObj->getContent();
      assert(is_string($pageContent));
      $content[] = $pageContent;
      foreach ($pageObj->getImages() as $image) {
        $content[] = $image->toPlaceHolder();
      }
    }
    $allContent = implode(' ', $content);

    $provider = $this->aiProvider();
    if ($provider === NULL) {
      return;
    }

    $prompt = $this->buildPrompt($paragraphSchema);

    $messages = new ChatInput([
      new ChatMessage('user', $allContent),
    ]);
    $messages->setSystemPrompt($prompt);
    $messages->setChatTools(new ToolsInput([FormatStructuredPagesTool::createWithSchema($paragraphSchema)]));

    try {
      /** @var \Drupal\ai\OperationType\Chat\ChatInterface&\Drupal\ai\AiProviderInterface $provider */
      $chatOutput = $provider->chat($messages, $this->aiModelId);
      $message = $chatOutput->getNormalized();
      $rawOutput = $chatOutput->getRawOutput();
    }
    catch (AiRequestErrorException $e) {
      throw new RetryableTransformFailure("Request to AI failed.", 0, $e);
    }

    $aiResponse = NULL;

    if ($provider->getPluginId() === 'bedrock' && $rawOutput instanceof \JsonSerializable) {
      $rawJson = $rawOutput->jsonSerialize();

      if (($rawJson['stopReason'] ?? NULL) === 'max_tokens') {
        $this->getLogger('localgov_publications_importer')->error("Hit maximum output token limit when generating structured content.");
      }

      foreach ($rawJson['output']['message']['content'] ?? [] as $block) {
        if (isset($block['toolUse']['name']) && $block['toolUse']['name'] === 'format_structured_pages') {
          $aiResponse = $block['toolUse']['input']['pages'] ?? NULL;
          break;
        }
      }
    }

    if ($aiResponse === NULL) {
      $aiResponse = $this->extractAndDecodeJson($message->getText());
    }

    if ($aiResponse === NULL) {
      $this->getLogger('localgov_publications_importer')->error("Couldn't decode structured JSON response: " . json_last_error_msg());
      return;
    }

    $pages = [];

    foreach ($aiResponse as $aiSuggestedPage) {
      $newPage = new Page();
      $newPage->setTitle($aiSuggestedPage['title'] ?? '');
      $newPage->setContent($aiSuggestedPage['paragraphs'] ?? []);
      $pages[] = $newPage;
    }

    $import->setPages($pages);
  }

  /**
   * Filter a paragraph schema to only the types the save plugin accepts.
   *
   * If the pipeline's save plugin implements ParagraphTypesProviderInterface,
   * the schema is filtered to the intersection. Otherwise the full schema is
   * returned unchanged so the plugin degrades gracefully.
   *
   * @param \Drupal\localgov_publications_importer\ImportInterface $import
   *   The current import, used to identify the pipeline's save plugin.
   * @param array $paragraphSchema
   *   Full schema as returned by ParagraphSchemaDiscovery::getSchema().
   *
   * @return array
   *   Filtered schema array.
   */
  protected function filterSchemaForSavePlugin(ImportInterface $import, array $paragraphSchema): array {
    $pipeline = $this->entityTypeManager
      ->getStorage('localgov_import_pipeline')
      ->load($import->getPipeline());

    if (!$pipeline instanceof ImportPipeline || !$pipeline->save_plugin) {
      return $paragraphSchema;
    }

    $savePlugin = $this->saveOperationManager->createInstance(
      $pipeline->save_plugin,
      $pipeline->save_plugin_configuration,
    );

    if (!$savePlugin instanceof ParagraphTypesProviderInterface) {
      return $paragraphSchema;
    }

    $allowed = array_flip($savePlugin->getAllowedParagraphTypes());
    // Empty array indicates that all paragraphs are allowed.
    if ($allowed === []) {
      return $paragraphSchema;
    }
    return array_intersect_key($paragraphSchema, $allowed);
  }

  /**
   * Build the system prompt, inserting the discovered paragraph schema.
   *
   * @param array $paragraphSchema
   *   Schema as returned by ParagraphSchemaDiscovery::getSchema().
   */
  protected function buildPrompt(array $paragraphSchema): string {
    $schemaDescription = $this->buildSchemaForPrompt($paragraphSchema);
    return str_replace('[paragraph-types]', $schemaDescription, $this->prompt);
  }

  /**
   * Render the schema as a prompt-ready string for the AI system message.
   */
  protected function buildSchemaForPrompt($paragraphSchema): string {
    $lines = [];

    foreach ($paragraphSchema as $typeId => $info) {
      $fieldParts = [];
      foreach ($info['fields'] as $fieldName => $fieldInfo) {
        $fieldParts[] = "{$fieldName} ({$fieldInfo['description']})";
      }
      $lines[] = "- {$typeId}: fields: " . implode(', ', $fieldParts);
    }

    return implode("\n", $lines);
  }

}
