<?php

namespace Drupal\localgov_publications_importer_ai\Plugin\LocalGovImporter\Transform;

use Drupal\Core\Logger\LoggerChannelTrait;
use Drupal\Core\Plugin\ContainerFactoryPluginInterface;
use Drupal\Core\StringTranslation\TranslatableMarkup;
use Drupal\ai\AiProviderPluginManager;
use Drupal\ai\Exception\AiRequestErrorException;
use Drupal\ai\OperationType\Chat\ChatInput;
use Drupal\ai\OperationType\Chat\ChatMessage;
use Drupal\ai\Plugin\ProviderProxy;
use Drupal\localgov_publications_importer\Attribute\Transform;
use Drupal\localgov_publications_importer\Exception\RetryableTransformFailure;
use Drupal\localgov_publications_importer\ImportInterface;
use Drupal\localgov_publications_importer\Plugin\LocalGovImporter\Transform\TransformPluginBase;
use Symfony\Component\DependencyInjection\ContainerInterface;

/**
 * Transform operation that uses AI to generate a summary for the import.
 */
#[Transform(
  id: 'transform_ai_summary',
  label: new TranslatableMarkup('AI summary'),
  description: new TranslatableMarkup('Uses AI to generate a summary of the entire document.')
)]
class AiSummary extends TransformPluginBase implements ContainerFactoryPluginInterface {

  use LoggerChannelTrait;

  /**
   * The default AI prompt to use for generating a summary.
   *
   * This can be overridden by the plugin's configuration.
   */
  protected string $prompt = 'You are a website content editor. The user will provide you with the full text of a document. Write a concise summary of the document in 2-4 sentences, suitable for display on the cover page of a publication. Return only the summary text, with no additional commentary or formatting.';

  /**
   * AI Provider ID.
   *
   * If this is empty the default provider for chat will be used.
   */
  protected string $aiProviderId = '';

  /**
   * AI Model ID.
   *
   * If this is empty the default model for chat will be used.
   */
  protected string $aiModelId = '';

  /**
   * {@inheritdoc}
   */
  public static function create(ContainerInterface $container, array $configuration, $plugin_id, $plugin_definition) {
    return new static(
      $configuration,
      $plugin_id,
      $plugin_definition,
      $container->get('ai.provider'),
    );
  }

  /**
   * Constructor.
   */
  public function __construct(
    array $configuration,
    $plugin_id,
    $plugin_definition,
    protected AiProviderPluginManager $aiProviderPluginManager,
  ) {
    parent::__construct($configuration, $plugin_id, $plugin_definition);

    if (isset($this->configuration['prompt'])) {
      $this->prompt = $this->configuration['prompt'];
    }
  }

  /**
   * {@inheritDoc}
   */
  public function transform(ImportInterface $import, ?int $page = NULL): void {

    // We only want to do this once.
    if ($page > 0) {
      return;
    }

    $content = [];

    foreach ($import->getPages() as $pageObj) {
      $content[] = $pageObj->getContent();
    }

    $allContent = implode(" ", $content);

    $this->configureAi();

    $provider = $this->aiProvider();
    if ($provider === NULL) {
      return;
    }

    $messages = new ChatInput([
      new ChatMessage('user', $allContent),
    ]);
    $messages->setSystemPrompt($this->prompt);

    try {
      /** @var \Drupal\ai\OperationType\Chat\ChatInterface&\Drupal\ai\AiProviderInterface $provider */
      $message = $provider->chat($messages, $this->aiModelId)->getNormalized();
    }
    catch (AiRequestErrorException $e) {
      // AiRequestErrorException is thrown for timeouts.
      // We could retry this request.
      throw new RetryableTransformFailure("Request to AI failed.", 0, $e);
    }

    $import->setSummary(trim($message->getText()));
  }

  /**
   * Get the configured AI provider.
   */
  protected function aiProvider(): ?ProviderProxy {

    if ($this->aiProviderId === '' || $this->aiModelId === '') {
      return NULL;
    }

    return $this->aiProviderPluginManager->createInstance($this->aiProviderId);
  }

  /**
   * Configure the AI provider and model.
   */
  protected function configureAi(): void {

    if (isset($this->configuration['aiProviderId'])) {
      $this->aiProviderId = $this->configuration['aiProviderId'];
    }

    if (isset($this->configuration['aiModelId'])) {
      $this->aiModelId = $this->configuration['aiModelId'];
    }

    // Keys are provider_id, model_id if we get an array back.
    $defaults = $this->aiProviderPluginManager->getDefaultProviderForOperationType('chat');
    if (is_array($defaults)) {
      if ($this->aiProviderId === '') {
        $this->aiProviderId = $defaults['provider_id'];
      }
      if ($this->aiModelId === '') {
        $this->aiModelId = $defaults['model_id'];
      }
    }
  }

  /**
   * {@inheritDoc}
   */
  public function isConfigurable(): bool {
    return TRUE;
  }

  /**
   * {@inheritDoc}
   */
  public function getConfigurationForm(): array {
    return [
      'prompt' => [
        '#type' => 'textarea',
        '#description' => new TranslatableMarkup("The prompt that will be sent to the AI to describe the summary you'd like generated"),
        '#default_value' => $this->prompt,
      ],
    ];
  }

}
