<?php

namespace Drupal\localgov_publications_importer_ai\Tool;

use Drupal\ai\OperationType\Chat\Tools\ToolsFunctionInput;

/**
 * Dynamic tool definition for structured paragraph-based page output.
 *
 * The JSON schema for the paragraphs array is built at runtime from the
 * paragraph types discovered by ParagraphSchemaDiscovery.
 */
class FormatStructuredPagesTool extends ToolsFunctionInput {

  /**
   * The paragraph type schema, keyed by type ID.
   *
   * @var array<string, array{label: string, fields: array<string, array{type: string, description: string}>}>
   */
  protected array $paragraphSchema;

  /**
   * Create an instance with the given paragraph schema.
   *
   * @param array $paragraphSchema
   *   Schema as returned by ParagraphSchemaDiscovery::getSchema().
   *
   * @return static
   */
  public static function createWithSchema(array $paragraphSchema): static {
    $instance = new static();
    $instance->paragraphSchema = $paragraphSchema;
    return $instance;
  }

  /**
   * {@inheritdoc}
   */
  public function getName(): string {
    return 'format_structured_pages';
  }

  /**
   * {@inheritdoc}
   */
  public function renderFunctionArray(): array {
    return [
      'name' => 'format_structured_pages',
      'description' => 'Format the document content into structured pages with typed paragraphs.',
      'parameters' => [
        'type' => 'object',
        'properties' => [
          'pages' => [
            'type' => 'array',
            'items' => [
              'type' => 'object',
              'properties' => [
                'title' => [
                  'type' => 'string',
                  'description' => 'Descriptive title reflecting the page\'s main topic.',
                ],
                'paragraphs' => [
                  'type' => 'array',
                  'items' => $this->buildParagraphSchema(),
                ],
              ],
              'required' => ['title', 'paragraphs'],
            ],
          ],
        ],
        'required' => ['pages'],
      ],
    ];
  }

  /**
   * Build the JSON schema for a single paragraph object.
   */
  protected function buildParagraphSchema(): array {
    $typeIds = array_keys($this->paragraphSchema);

    // Build a properties object covering every field across all types, so
    // Bedrock's strict schema validation accepts any valid combination.
    $properties = [
      'type' => [
        'type' => 'string',
        'enum' => $typeIds,
        'description' => 'The paragraph type ID.',
      ],
    ];

    foreach ($this->paragraphSchema as $typeInfo) {
      foreach ($typeInfo['fields'] as $fieldName => $fieldInfo) {
        if (isset($properties[$fieldName])) {
          continue;
        }
        $properties[$fieldName] = $this->fieldToJsonSchema($fieldInfo['type'], $fieldInfo['description']);
      }
    }

    return [
      'type' => 'object',
      'properties' => $properties,
      'required' => ['type'],
    ];
  }

  /**
   * Convert a Drupal field type to a JSON Schema definition.
   */
  protected function fieldToJsonSchema(string $fieldType, string $description): array {
    if ($fieldType === 'link') {
      return [
        'type' => 'object',
        'description' => $description,
        'properties' => [
          'uri' => ['type' => 'string'],
          'title' => ['type' => 'string'],
        ],
      ];
    }

    return [
      'type' => 'string',
      'description' => $description,
    ];
  }

}
