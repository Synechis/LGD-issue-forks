<?php

namespace Drupal\localgov_publications_importer\Attribute;

use Drupal\Component\Plugin\Attribute\Plugin;
use Drupal\Core\StringTranslation\TranslatableMarkup;

/**
 * Defines an Extract attribute object.
 */
#[\Attribute(
  \Attribute::TARGET_CLASS,
)]
class Extract extends Plugin {

  /**
   * Constructor.
   *
   * @param string $id
   *   The plugin ID.
   * @param \Drupal\Core\StringTranslation\TranslatableMarkup $label
   *   The human-readable plugin label.
   * @param \Drupal\Core\StringTranslation\TranslatableMarkup $description
   *   A short description of the plugin.
   * @param string[] $supportedExtensions
   *   File extensions this extract plugin accepts, without leading dots
   *   (e.g. ['pdf'] or ['docx', 'doc']). Used by the import form to build
   *   the upload validator. Default is an empty array, indicating no
   *   restriction.
   */
  public function __construct(
    public readonly string $id,
    public readonly TranslatableMarkup $label,
    public readonly TranslatableMarkup $description,
    public readonly array $supportedExtensions = [],
  ) {
  }

}
