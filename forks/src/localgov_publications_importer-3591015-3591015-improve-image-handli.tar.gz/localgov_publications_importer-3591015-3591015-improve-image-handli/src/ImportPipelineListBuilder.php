<?php

namespace Drupal\localgov_publications_importer;

use Drupal\Core\Config\Entity\ConfigEntityListBuilder;
use Drupal\Core\Entity\EntityInterface;
use Drupal\Core\Entity\EntityStorageInterface;
use Drupal\Core\Entity\EntityTypeInterface;
use Drupal\Core\Session\AccountProxyInterface;
use Drupal\localgov_publications_importer\Entity\ImportPipeline;
use Symfony\Component\DependencyInjection\ContainerInterface;

/**
 * Provides a listing of Import Pipeline entities.
 */
class ImportPipelineListBuilder extends ConfigEntityListBuilder {

  /**
   * {@inheritdoc}
   */
  public static function createInstance(ContainerInterface $container, EntityTypeInterface $entity_type) {
    return new static(
      $entity_type,
      $container->get('entity_type.manager')->getStorage($entity_type->id()),
      $container->get('current_user'),
    );
  }

  /**
   * {@inheritdoc}
   */
  public function __construct(EntityTypeInterface $entity_type, EntityStorageInterface $storage, protected AccountProxyInterface $account) {
    parent::__construct($entity_type, $storage);
  }

  /**
   * {@inheritdoc}
   */
  public function getDefaultOperations(EntityInterface $entity) {
    $operations = parent::getDefaultOperations($entity);
    if ($entity->hasLinkTemplate('export-form') && $this->currentUserCanImportExport()) {
      $operations['export'] = [
        'title' => $this->t('Export'),
        'weight' => 50,
        'url' => $entity->toUrl('export-form'),
      ];
    }
    return $operations;
  }

  /**
   * Check if the current user can import or export pipelines.
   */
  protected function currentUserCanImportExport(): bool {
    return $this->account->hasPermission('import export import pipelines') || $this->account->hasPermission('administer import pipelines');
  }

  /**
   * {@inheritdoc}
   */
  public function buildHeader() {
    $header = [
      'label' => $this->t('Label'),
      'id' => $this->t('Machine name'),
      'extract_plugin' => $this->t('Extract Plugin'),
      'save_plugin' => $this->t('Save Plugin'),
    ];
    return $header + parent::buildHeader();
  }

  /**
   * {@inheritdoc}
   */
  public function buildRow(EntityInterface $entity) {
    assert($entity instanceof ImportPipeline);
    $row = [
      'label' => $entity->label(),
      'id' => $entity->id(),
      'extract_plugin' => $entity->extract_plugin,
      'save_plugin' => $entity->save_plugin,
    ];
    return $row + parent::buildRow($entity);
  }

  /**
   * Get the title for the list page.
   *
   * @return string
   *   The page title.
   */
  public function getTitle() {
    return 'Import Pipelines';
  }

  /**
   * {@inheritdoc}
   */
  public function render() {
    $build = parent::render();
    $build['intro'] = [
      '#prefix' => '<p>',
      '#markup' => 'Import pipelines are used by the content importer. You can add multiple pipelines to import content in different ways. For example: To different content types, Using different AI prompts, or using your own custom plugins.',
      '#suffix' => '</p>',
      '#weight' => -1,
    ];
    return $build;
  }

}
