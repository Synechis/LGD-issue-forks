<?php

namespace Drupal\localgov_publications_importer\Form;

use Drupal\Core\Entity\EntityTypeManagerInterface;
use Drupal\Core\Form\FormBase;
use Drupal\Core\Form\FormStateInterface;
use Drupal\Core\Link;
use Drupal\Core\Url;
use Drupal\localgov_publications_importer\Entity\Import;
use Drupal\localgov_publications_importer\Entity\ImportPipeline;
use Drupal\localgov_publications_importer\ExtractOperationManager;
use Drupal\localgov_publications_importer\Plugin\ExtractInterface;
use Drupal\localgov_publications_importer\Plugin\ImportFormInterface;
use Drupal\localgov_publications_importer\Plugin\SaveInterface;
use Drupal\localgov_publications_importer\SaveOperationManager;
use Drupal\localgov_publications_importer\TransformOperationManager;

use Symfony\Component\DependencyInjection\ContainerInterface;

/**
 * Publication import form.
 */
class PublicationImportForm extends FormBase {

  /**
   * Constructor.
   */
  public function __construct(
    protected EntityTypeManagerInterface $entityTypeManager,
    protected ExtractOperationManager $extractOperationManager,
    protected TransformOperationManager $transformOperationManager,
    protected SaveOperationManager $saveOperationManager,
  ) {
  }

  /**
   * {@inheritdoc}
   */
  public static function create(ContainerInterface $container): static {
    return new static(
      $container->get('entity_type.manager'),
      $container->get(ExtractOperationManager::class),
      $container->get(TransformOperationManager::class),
      $container->get(SaveOperationManager::class),
    );
  }

  /**
   * {@inheritdoc}
   */
  public function getFormId() {
    return 'publication_import_form';
  }

  /**
   * {@inheritdoc}
   */
  public function buildForm(array $form, FormStateInterface $form_state) {

    $form['#attributes'] = ['enctype' => 'multipart/form-data'];

    /** @var \Drupal\localgov_publications_importer\Entity\ImportPipeline[] $importPipelines */
    $importPipelines = $this->entityTypeManager
      ->getStorage('localgov_import_pipeline')
      ->loadMultiple();

    if (count($importPipelines) === 0) {
      $link = Link::fromTextAndUrl($this->t('Import Pipeline admin page'), Url::fromRoute('entity.localgov_import_pipeline.collection'));
      $this->messenger()->addError($this->t('There are no configured import pipelines. Please add one from the @link.', ['@link' => $link->toString()]));
    }

    $importPipelineOptions = [];
    foreach ($importPipelines as $importPipeline) {
      $importPipelineOptions[$importPipeline->id()] = $importPipeline->label();
    }

    // Use the pipeline the user has selected, falling back to the first option.
    $selectedPipelineId = $form_state->getValue('import_pipeline', array_key_first($importPipelineOptions));

    $form['import_pipeline'] = [
      '#type' => 'radios',
      '#title' => $this->t('Import Pipeline'),
      '#options' => $importPipelineOptions,
      '#default_value' => $selectedPipelineId,
      '#required' => TRUE,
      '#description' => $this->t('Select the import pipeline to use for processing the uploaded file.'),
      '#ajax' => [
        'callback' => '::pipelineSelected',
        'wrapper' => 'plugin-import-fields',
        'event' => 'change',
      ],
    ];

    // This is, apparently, how you can add descriptions to individual radio
    // buttons, instead of the whole set.
    foreach ($importPipelines as $importPipeline) {
      $form['import_pipeline'][$importPipeline->id()]['#description'] = $importPipeline->description();
    }

    // Build the file field with validators scoped to the selected pipeline.
    $selectedPipeline = $importPipelines[$selectedPipelineId];
    $extensionsString = implode(' ', $selectedPipeline->acceptableFileExtensions());

    $form['plugin_import_fields'] = [
      '#type' => 'container',
      '#prefix' => '<div id="plugin-import-fields">',
      '#suffix' => '</div>',
      '#tree' => TRUE,
    ];

    $form['plugin_import_fields']['my_file'] = [
      '#type' => 'managed_file',
      '#name' => 'my_file',
      '#title' => $this->t('File *'),
      '#size' => 20,
      '#description' => $this->t('Allowed formats: %extensions', ['%extensions' => $extensionsString]),
      '#upload_validators' => [
        'file_validate_extensions' => [$extensionsString],
      ],
      '#upload_location' => 'private://localgov_publications_importer/',
    ];

    if ($selectedPipelineId) {
      $form['plugin_import_fields'] += $this->buildPluginFields($selectedPipelineId, $form_state);
    }

    $form['actions']['#type'] = 'actions';
    $form['actions']['submit'] = [
      '#type' => 'submit',
      '#value' => $this->t('Import'),
      '#button_type' => 'primary',
    ];

    return $form;
  }

  /**
   * AJAX callback for pipeline selection.
   *
   * Replaces the plugin import fields when the pipeline changes.
   */
  public function pipelineSelected(array &$form, FormStateInterface $form_state): array {
    return $form['plugin_import_fields'];
  }

  /**
   * Build plugin import form fields for the selected pipeline.
   *
   * Iterates the pipeline's extract, transform, and save plugins. Any plugin
   * that implements ImportFormInterface contributes fields to the form inside
   * its own container, keyed by plugin slot.
   *
   * @param string $pipelineId
   *   The pipeline ID.
   * @param \Drupal\Core\Form\FormStateInterface $form_state
   *   The form state.
   *
   * @return array
   *   Form API elements keyed by plugin slot.
   */
  protected function buildPluginFields(string $pipelineId, FormStateInterface $form_state): array {
    $elements = [];

    /** @var \Drupal\localgov_publications_importer\Entity\ImportPipeline|null $pipeline */
    $pipeline = $this->entityTypeManager
      ->getStorage('localgov_import_pipeline')
      ->load($pipelineId);

    if (!$pipeline instanceof ImportPipeline) {
      return $elements;
    }

    // Extract plugin.
    $extractPlugin = $this->getExtractPlugin($pipeline);
    if ($extractPlugin instanceof ImportFormInterface) {
      $elements['extract'] = [
        '#type' => 'details',
        '#title' => $this->t('Extract: @label', ['@label' => $extractPlugin->getPluginDefinition()['label']]),
        '#open' => TRUE,
      ];
      $elements['extract'] += $extractPlugin->buildImportForm($form_state);
    }

    // Transform plugins.
    $transformPlugins = $this->getTransformPlugins($pipeline);
    foreach ($transformPlugins as $index => $transformPlugin) {
      if ($transformPlugin instanceof ImportFormInterface) {
        $key = 'transform_' . $index;
        $elements[$key] = [
          '#type' => 'details',
          '#title' => $this->t('Transform: @label', ['@label' => $transformPlugin->getPluginDefinition()['label']]),
          '#open' => TRUE,
        ];
        $elements[$key] += $transformPlugin->buildImportForm($form_state);
      }
    }

    // Save plugin.
    $savePlugin = $this->getSavePlugin($pipeline);
    if ($savePlugin instanceof ImportFormInterface) {
      $elements['save'] = [
        '#type' => 'details',
        '#title' => $this->t('Save: @label', ['@label' => $savePlugin->getPluginDefinition()['label']]),
        '#open' => TRUE,
      ];
      $elements['save'] += $savePlugin->buildImportForm($form_state);
    }

    return $elements;
  }

  /**
   * {@inheritdoc}
   */
  public function validateForm(array &$form, FormStateInterface $form_state): void {
    parent::validateForm($form, $form_state);

    $pipelineId = $form_state->getValue('import_pipeline');
    if (!$pipelineId) {
      return;
    }

    /** @var \Drupal\localgov_publications_importer\Entity\ImportPipeline|null $pipeline */
    $pipeline = $this->entityTypeManager
      ->getStorage('localgov_import_pipeline')
      ->load($pipelineId);

    if (!$pipeline instanceof ImportPipeline) {
      return;
    }

    $pluginImportValues = $form_state->getValue('plugin_import_fields', []);

    // Extract plugin.
    $extractPlugin = $this->getExtractPlugin($pipeline);
    if ($extractPlugin instanceof ImportFormInterface) {
      $extractPlugin->validateImportForm($pluginImportValues['extract'] ?? [], $form_state);
    }

    // Transform plugins.
    $transformPlugins = $this->getTransformPlugins($pipeline);
    foreach ($transformPlugins as $index => $transformPlugin) {
      if ($transformPlugin instanceof ImportFormInterface) {
        $transformPlugin->validateImportForm($pluginImportValues['transform_' . $index] ?? [], $form_state);
      }
    }

    // Save plugin.
    $savePlugin = $this->getSavePlugin($pipeline);
    if ($savePlugin instanceof ImportFormInterface) {
      $savePlugin->validateImportForm($pluginImportValues['save'] ?? [], $form_state);
    }
  }

  /**
   * {@inheritdoc}
   */
  public function submitForm(array &$form, FormStateInterface $form_state): void {

    [$fid] = $form_state->getValue(['plugin_import_fields', 'my_file']);
    /** @var \Drupal\file\FileInterface $file */
    $file = $this->entityTypeManager->getStorage('file')->load($fid);

    // @todo Move a lot of this to the new ImportManager.
    $importPipelineId = $form_state->getValue('import_pipeline');

    $user = $this->entityTypeManager
      ->getStorage('user')
      ->load($this->currentUser()->id());

    $import = Import::create([
      'file' => $file,
      'title' => $file->getFilename(),
      'creator' => $user,
      'pipeline' => $importPipelineId,
    ]);

    $runtimeConfiguration = $this->collectRuntimeConfiguration($importPipelineId, $form_state);
    if (!empty($runtimeConfiguration)) {
      $import->setRuntimeConfiguration($runtimeConfiguration);
    }

    $import->save();

    // Mark the file as permanent, so it doesn't get cleaned up prematurely.
    $file->setPermanent();
    $file->save();

    $form_state->setRedirect('view.imports.page_1');
  }

  /**
   * Collect runtime configuration overrides from the plugin import form fields.
   *
   * Calls getImportFormConfiguration() on each plugin that implements
   * ImportFormInterface and assembles the results into a structure that can be
   * stored on the Import entity and used by the Importer service.
   *
   * @param string $pipelineId
   *   The selected pipeline ID.
   * @param \Drupal\Core\Form\FormStateInterface $form_state
   *   The form state.
   *
   * @return array
   *   Runtime configuration array, keyed by plugin slot.
   */
  protected function collectRuntimeConfiguration(string $pipelineId, FormStateInterface $form_state): array {
    /** @var \Drupal\localgov_publications_importer\Entity\ImportPipeline|null $pipeline */
    $pipeline = $this->entityTypeManager
      ->getStorage('localgov_import_pipeline')
      ->load($pipelineId);

    if (!$pipeline instanceof ImportPipeline) {
      return [];
    }

    $runtimeConfig = [];
    $pluginImportValues = $form_state->getValue('plugin_import_fields', []);

    // Extract plugin.
    $extractPlugin = $this->getExtractPlugin($pipeline);
    if ($extractPlugin instanceof ImportFormInterface) {
      $runtimeConfig['extract'] = $extractPlugin->getImportFormConfiguration($pluginImportValues['extract'] ?? []);
    }

    // Transform plugins.
    $transformPlugins = $this->getTransformPlugins($pipeline);
    foreach ($transformPlugins as $index => $transformPlugin) {
      if ($transformPlugin instanceof ImportFormInterface) {
        $runtimeConfig['transform'][$index] = $transformPlugin->getImportFormConfiguration($pluginImportValues['transform_' . $index] ?? []);
      }
    }

    // Save plugin.
    $savePlugin = $this->getSavePlugin($pipeline);
    if ($savePlugin instanceof ImportFormInterface) {
      $runtimeConfig['save'] = $savePlugin->getImportFormConfiguration($pluginImportValues['save'] ?? []);
    }

    return $runtimeConfig;
  }

  /**
   * Returns the extract plugin for a pipeline.
   *
   * @return ?\Drupal\localgov_publications_importer\Plugin\ExtractInterface
   *   Extract plugin.
   */
  protected function getExtractPlugin(ImportPipeline $pipeline): ?ExtractInterface {
    if ($pipeline->extract_plugin) {
      return $this->extractOperationManager->createInstance(
        $pipeline->extract_plugin,
        $pipeline->extract_plugin_configuration,
      );
    }
    return NULL;
  }

  /**
   * Returns the transform plugins for a pipeline.
   *
   * @return \Drupal\localgov_publications_importer\Plugin\TransformInterface[]
   *   Array of transform plugins.
   */
  protected function getTransformPlugins(ImportPipeline $pipeline): array {
    $transformPlugins = [];
    foreach ($pipeline->transform_plugins as $index => $pluginId) {
      $config = $pipeline->transform_plugin_configurations[$index] ?? [];
      $transformPlugins[$index] = $this->transformOperationManager->createInstance($pluginId, $config);
    }
    return $transformPlugins;
  }

  /**
   * Returns the save plugin for a pipeline.
   *
   * @return ?\Drupal\localgov_publications_importer\Plugin\SaveInterface
   *   Save plugin.
   */
  protected function getSavePlugin(ImportPipeline $pipeline): ?SaveInterface {
    if ($pipeline->save_plugin) {
      return $this->saveOperationManager->createInstance(
        $pipeline->save_plugin,
        $pipeline->save_plugin_configuration,
      );
    }
    return NULL;
  }

}
