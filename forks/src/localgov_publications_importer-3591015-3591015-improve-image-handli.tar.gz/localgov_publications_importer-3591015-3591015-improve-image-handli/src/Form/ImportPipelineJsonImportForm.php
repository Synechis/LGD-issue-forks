<?php

namespace Drupal\localgov_publications_importer\Form;

use Drupal\Core\Entity\EntityTypeManagerInterface;
use Drupal\Core\Form\FormBase;
use Drupal\Core\Form\FormStateInterface;
use Symfony\Component\DependencyInjection\ContainerInterface;

/**
 * Form to import an Import Pipeline entity from JSON.
 */
class ImportPipelineJsonImportForm extends FormBase {

  /**
   * Constructor.
   */
  public function __construct(
    protected EntityTypeManagerInterface $entityTypeManager,
  ) {}

  /**
   * {@inheritdoc}
   */
  public static function create(ContainerInterface $container): static {
    return new static(
      $container->get('entity_type.manager'),
    );
  }

  /**
   * {@inheritdoc}
   */
  public function getFormId(): string {
    return 'localgov_publications_importer_pipeline_json_import';
  }

  /**
   * {@inheritdoc}
   */
  public function buildForm(array $form, FormStateInterface $form_state): array {
    $form['json'] = [
      '#type' => 'textarea',
      '#title' => $this->t('Pipeline JSON'),
      '#description' => $this->t('Paste the JSON from an exported import pipeline.'),
      '#required' => TRUE,
      '#rows' => 20,
    ];

    $form['actions'] = ['#type' => 'actions'];
    $form['actions']['submit'] = [
      '#type' => 'submit',
      '#value' => $this->t('Import'),
    ];

    return $form;
  }

  /**
   * {@inheritdoc}
   */
  public function validateForm(array &$form, FormStateInterface $form_state): void {
    $data = json_decode($form_state->getValue('json'), TRUE);

    if ($data === NULL) {
      $form_state->setErrorByName('json', $this->t('Invalid JSON.'));
      return;
    }

    if (empty($data['id'])) {
      $form_state->setErrorByName('json', $this->t('The JSON must contain an "id" key.'));
    }

    if (empty($data['label'])) {
      $form_state->setErrorByName('json', $this->t('The JSON must contain a "label" key.'));
    }

    $form_state->set('pipeline_data', $data);
  }

  /**
   * {@inheritdoc}
   */
  public function submitForm(array &$form, FormStateInterface $form_state): void {
    $data = $form_state->get('pipeline_data');
    $storage = $this->entityTypeManager->getStorage('localgov_import_pipeline');

    $existing = $storage->load($data['id']);
    if ($existing !== NULL) {
      foreach ($data as $key => $value) {
        $existing->set($key, $value);
      }
      $existing->save();
      $this->messenger()->addStatus($this->t('Pipeline %label has been updated.', ['%label' => $data['label']]));
    }
    else {
      $storage->create($data)->save();
      $this->messenger()->addStatus($this->t('Pipeline %label has been imported.', ['%label' => $data['label']]));
    }

    $form_state->setRedirect('entity.localgov_import_pipeline.collection');
  }

}
