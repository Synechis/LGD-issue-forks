<?php

namespace Drupal\localgov_publications_importer\Plugin;

use Drupal\Core\Form\FormStateInterface;

/**
 * Interface for plugins that add fields to the publication import form.
 *
 * Any Extract, Transform, or Save plugin may implement this interface to allow
 * users to override its configuration at import time, rather than only at
 * pipeline-configuration time.
 *
 * The form will nest the returned elements inside a container specific to each
 * plugin. The same values array is passed back to validateImportForm() and
 * getImportFormConfiguration() so plugins only need to deal with their own
 * relative keys.
 */
interface ImportFormInterface {

  /**
   * Build form elements to add to the import form.
   *
   * Use $this->configuration for default values; these are populated from the
   * pipeline configuration when the plugin is instantiated.
   *
   * @param \Drupal\Core\Form\FormStateInterface $form_state
   *   The form state.
   *
   * @return array
   *   Form API elements.
   */
  public function buildImportForm(FormStateInterface $form_state): array;

  /**
   * Validate the plugin's import form values.
   *
   * @param array $values
   *   The submitted values for this plugin's fields only.
   * @param \Drupal\Core\Form\FormStateInterface $form_state
   *   The complete form state, for setting errors.
   */
  public function validateImportForm(array $values, FormStateInterface $form_state): void;

  /**
   * Convert submitted import form values to a plugin configuration array.
   *
   * The returned array is stored as a runtime configuration override on the
   * Import entity and replaces the pipeline-level configuration when the
   * import executes.
   *
   * @param array $values
   *   The submitted values for this plugin's fields only.
   *
   * @return array
   *   Plugin configuration array.
   */
  public function getImportFormConfiguration(array $values): array;

}
