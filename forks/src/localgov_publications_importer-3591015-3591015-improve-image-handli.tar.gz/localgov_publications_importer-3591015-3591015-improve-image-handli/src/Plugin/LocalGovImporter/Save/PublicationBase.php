<?php

namespace Drupal\localgov_publications_importer\Plugin\LocalGovImporter\Save;

use Drupal\Core\Form\FormStateInterface;
use Drupal\Core\StringTranslation\TranslatableMarkup;
use Drupal\file\FileInterface;
use Drupal\media\Entity\Media;
use Drupal\localgov_publications_importer\ImportInterface;
use Drupal\localgov_publications_importer\Plugin\ImportFormInterface;
use Drupal\node\NodeInterface;
use Drupal\paragraphs\Entity\Paragraph;
use Drupal\paragraphs\ParagraphInterface;

/**
 * Base class for publication save plugins.
 */
abstract class PublicationBase extends SavePluginBase implements ImportFormInterface {

  /**
   * Creates / Links a cover page if the plugin is configured to do so.
   */
  protected function createCoverPage(NodeInterface $rootPage, ImportInterface $import): ?NodeInterface {
    $coverPageMode = $this->configuration['cover_page'] ?? 'no';

    if ($coverPageMode === 'no') {
      return NULL;
    }

    $nodeStorage = $this->entityTypeManager->getStorage('node');

    // Create a cover page if one has been requested.
    if ($coverPageMode === 'create_new') {
      /** @var \Drupal\node\NodeInterface $publicationPage */
      $coverPage = $nodeStorage->create([
        'type' => 'localgov_publication_cover_page',
        'title' => $rootPage->getTitle(),
        'uid' => $import->getCreator()->id(),
      ]);

      $coverPage->get('localgov_publication')->set(0, ['target_id' => $rootPage->id()]);

      $documentMedia = $this->createMediaForOriginalFile($import);
      if ($documentMedia !== NULL) {
        $coverPage->get('localgov_documents')->appendItem(['target_id' => $documentMedia->id()]);
      }

      $summary = $import->getSummary();
      if ($summary !== '') {
        $summaryParagraph = $this->createSummaryParagraph($summary);
        $coverPage->get('localgov_publication_content')->appendItem([
          'target_id' => $summaryParagraph->id(),
          'target_revision_id' => $summaryParagraph->getRevisionId(),
        ]);
      }

      $coverPage->save();
    }
    elseif ($coverPageMode === 'use_existing') {
      if (isset($this->configuration['existing_cover_page'])) {
        // Link the new publication to the existing cover page.
        $coverPage = $nodeStorage->load($this->configuration['existing_cover_page']);
        $coverPage->get('localgov_publication')->appendItem(['target_id' => $rootPage->id()]);

        $documentMedia = $this->createMediaForOriginalFile($import);
        if ($documentMedia !== NULL) {
          $coverPage->get('localgov_documents')->appendItem(['target_id' => $documentMedia->id()]);
        }

        $summary = $import->getSummary();
        if ($summary !== '') {
          $summaryParagraph = $this->createSummaryParagraph($summary);
          $coverPage->get('localgov_publication_content')->appendItem([
            'target_id' => $summaryParagraph->id(),
            'target_revision_id' => $summaryParagraph->getRevisionId(),
          ]);
        }

        $coverPage->save();
      }
    }
    return $coverPage;
  }

  /**
   * Create a document media entity for the file attached to the import.
   */
  protected function createMediaForOriginalFile(ImportInterface $import): ?Media {
    $file = $import->getFile();
    if ($file === NULL) {
      return NULL;
    }

    $media = Media::create([
      'bundle' => 'document',
      'name' => $file->getFilename(),
      'field_media_document' => ['target_id' => $file->id()],
      'uid' => $import->getCreator()->id(),
    ]);
    $media->save();
    return $media;
  }

  /**
   * Create a text paragraph containing the given summary.
   */
  protected function createSummaryParagraph(string $summary): ParagraphInterface {
    $paragraph = Paragraph::create([
      'type' => 'localgov_text',
      'localgov_text' => [
        'value' => $summary,
        'format' => 'wysiwyg',
      ],
    ]);
    $paragraph->save();
    return $paragraph;
  }

  /**
   * Create an image paragraph to store the given image.
   */
  protected function createImageParagraph(FileInterface $image, ParagraphInterface $parentParagraph) {
    $mediaEntities = $this->entityTypeManager->getStorage('media')->loadByProperties(['field_media_image' => $image->id()]);

    if ($mediaEntities === []) {
      return NULL;
    }

    $media = reset($mediaEntities);

    $paragraph = Paragraph::create([
      'type' => 'localgov_image',
      'localgov_image' => [
        'target_id' => $media->id(),
      ],
      'localgov_caption' => [
        // @todo Something meaningful.
        'value' => '',
      ],
    ]);
    $paragraph->setBehaviorSettings('layout_paragraphs', [
      'region' => 'content',
      'parent_uuid' => $parentParagraph->uuid(),
      'layout' => '',
      'config' => [],
    ]);
    $paragraph->save();

    return $paragraph;
  }

  /**
   * {@inheritdoc}
   */
  public function buildImportForm(FormStateInterface $form_state): array {

    $coverPageOptions = $this->getCoverPageOptions();

    $form['cover_page'] = [
      '#title' => 'Add a cover page',
      '#type' => 'radios',
      '#options' => [
        'no' => 'No',
        'create_new' => 'Yes: Create new',
      ],
      '#default_value' => 'no',
    ];

    if ($coverPageOptions === []) {
      $form['cover_page']['#description'] = new TranslatableMarkup('The option to use an existing cover page will be shown when one is created.');
    }
    else {
      $form['cover_page']['#options']['use_existing'] = 'Yes: Use existing';

      $form['existing_cover_page'] = [
        '#title' => 'Choose an existing cover page to add to',
        '#type' => 'select',
        '#options' => $coverPageOptions,
        '#states' => [
          // Show this select only if use_existing is chosen in the field above.
          'visible' => [
            ':input[name="plugin_import_fields[save][cover_page]"]' => ['value' => 'use_existing'],
          ],
        ],
      ];
    }

    return $form;
  }

  /**
   * {@inheritdoc}
   */
  public function validateImportForm(array $values, FormStateInterface $form_state): void {
    // Nothing needs validating.
  }

  /**
   * {@inheritdoc}
   */
  public function getImportFormConfiguration(array $values): array {
    return $values;
  }

  /**
   * Returns a list of cover pages suitable for use as options in a form.
   *
   * @return array
   *   Cover page options. Key is node ID. Value is title.
   */
  protected function getCoverPageOptions(): array {
    $coverPages = $this->entityTypeManager->getStorage('node')->loadByProperties([
      'type' => 'localgov_publication_cover_page',
    ]);

    $options = [];
    foreach ($coverPages as $coverPage) {
      $options[$coverPage->id()] = $coverPage->label();
    }
    return $options;
  }

}
