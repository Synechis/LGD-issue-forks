<?php

namespace Drupal\localgov_publications_importer\Plugin\LocalGovImporter\Extract;

use Drupal\Component\Plugin\PluginBase;
use Drupal\localgov_publications_importer\Plugin\ExtractInterface;

/**
 * Base class for extract operations.
 */
abstract class ExtractPluginBase extends PluginBase implements ExtractInterface {

  /**
   * An array of MD5 hashes that we'll use to not import duplicated images.
   *
   * @var string[]
   */
  protected array $importedImages = [];

  /**
   * The directory where we'll save temporary files.
   *
   * @var string
   */
  protected string $tempDir = 'temporary://localgov_publications_importer';

  /**
   * {@inheritDoc}
   */
  public function isConfigurable(): bool {
    return FALSE;
  }

  /**
   * {@inheritDoc}
   */
  public function getConfigurationForm(): array {
    return [];
  }

}
