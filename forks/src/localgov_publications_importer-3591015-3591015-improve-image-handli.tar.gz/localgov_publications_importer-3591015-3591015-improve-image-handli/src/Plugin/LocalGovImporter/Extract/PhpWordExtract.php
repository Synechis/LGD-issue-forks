<?php

namespace Drupal\localgov_publications_importer\Plugin\LocalGovImporter\Extract;

use Drupal\Component\Uuid\UuidInterface;
use Drupal\Core\File\FileExists;
use Drupal\Core\File\FileSystemInterface;
use Drupal\Core\Logger\LoggerChannelTrait;
use Drupal\Core\Plugin\ContainerFactoryPluginInterface;
use Drupal\Core\StringTranslation\TranslatableMarkup;
use Drupal\localgov_publications_importer\Attribute\Extract;
use Drupal\localgov_publications_importer\Image;
use Drupal\localgov_publications_importer\ImageInterface;
use Drupal\localgov_publications_importer\ImportInterface;
use Drupal\localgov_publications_importer\Page;
use PhpOffice\PhpWord\IOFactory;
use PhpOffice\PhpWord\PhpWord;
use Symfony\Component\DependencyInjection\ContainerInterface;

/**
 * Extract operation that uses PhpOffice/PhpWord for Microsoft Word documents.
 *
 * Loads a .docx file, converts it to HTML (preserving bold, italic, links,
 * lists, tables, and inline images), then splits the HTML into publication
 * pages at every H2 heading. The H2 text becomes the page title and is not
 * repeated in the page body. Content before the first H2 (including any H1)
 * becomes the first page.
 *
 * Embedded images are extracted from their base64 data-URI src attributes,
 * normalised to JPEG, saved to temporary files, and replaced with placeholder
 * src values that the transform_images plugin understands.
 *
 * @see \Drupal\localgov_publications_importer\Plugin\LocalGovImporter\Transform\Images
 */
#[Extract(
  id: 'phpword',
  label: new TranslatableMarkup('PhpWord extract'),
  description: new TranslatableMarkup('Extract operation that uses PhpOffice/PhpWord to import Microsoft Word documents (.docx)'),
  supportedExtensions: ['docx', 'doc'],
)]
class PhpWordExtract extends ExtractPluginBase implements ContainerFactoryPluginInterface {

  use LoggerChannelTrait;

  /**
   * {@inheritdoc}
   */
  public static function create(ContainerInterface $container, array $configuration, $plugin_id, $plugin_definition) {
    return new static(
      $configuration,
      $plugin_id,
      $plugin_definition,
      $container->get('file_system'),
      $container->get('uuid'),
    );
  }

  /**
   * Constructor.
   */
  public function __construct(
    array $configuration,
    string $plugin_id,
    mixed $plugin_definition,
    protected FileSystemInterface $fileSystem,
    protected UuidInterface $uuid,
  ) {
    parent::__construct($configuration, $plugin_id, $plugin_definition);
  }

  /**
   * {@inheritDoc}
   */
  public function extract(ImportInterface $import): void {
    $fileUri = $import->getFile()->getFileUri();
    $filePath = $this->fileSystem->realpath($fileUri);

    if ($filePath === FALSE) {
      $this->getLogger('localgov_publications_importer')->error(
        'Could not resolve real path for @uri',
        ['@uri' => $fileUri]
      );
      return;
    }

    $phpWord = $this->loadDocument($filePath);
    if ($phpWord === NULL) {
      return;
    }

    $this->setTitle($import, $phpWord);

    $this->fileSystem->prepareDirectory(
      $this->tempDir,
      FileSystemInterface::CREATE_DIRECTORY | FileSystemInterface::MODIFY_PERMISSIONS
    );

    $html = $this->convertToHtml($phpWord);
    if ($html === '') {
      $this->getLogger('localgov_publications_importer')->error(
        'Could not convert Word document to HTML for @uri',
        ['@uri' => $fileUri]
      );
      return;
    }

    $dom = new \DOMDocument('1.0', 'UTF-8');
    $dom->loadHTML($html);

    // Replace embedded base64 images with placeholder src values that the
    // transform_images plugin will later resolve to Drupal file entities.
    $imageMap = $this->extractImages($dom);

    $body = $dom->getElementsByTagName('body')->item(0);
    if (!($body instanceof \DOMElement)) {
      return;
    }

    $content = $dom->saveHTML($body);
    if (!is_string($content)) {
      return;
    }

    $page = new Page();
    $page->setTitle('Page 1');
    $page->setContent($content);

    // Attach any images that appear in this section.
    foreach ($imageMap as $image) {
      $page->addImage($image);
    }
    $page->setPageNumber(1);
    $import->addPage($page);
  }

  /**
   * Load the Word document via PhpWord.
   *
   * @param string $filePath
   *   Real filesystem path to the .docx file.
   *
   * @return \PhpOffice\PhpWord\PhpWord|null
   *   The loaded document, or NULL on failure.
   */
  protected function loadDocument(string $filePath): ?PhpWord {
    try {
      return IOFactory::load($filePath);
    }
    catch (\Exception $e) {
      $this->getLogger('localgov_publications_importer')->error(
        'Could not load Word document: @message',
        ['@message' => $e->getMessage()]
      );
      return NULL;
    }
  }

  /**
   * Set the import title from the PhpWord document.
   *
   * @param \Drupal\localgov_publications_importer\ImportInterface $import
   *   The import entity.
   * @param \PhpOffice\PhpWord\PhpWord $phpWord
   *   The PhpWord document.
   */
  protected function setTitle(ImportInterface $import, PhpWord $phpWord): void {
    $title = $phpWord->getDocInfo()->getTitle();
    // PhpWord returns '-' as a default when no title is set.
    if ($title === '-') {
      $this->getLogger('localgov_publications_importer')->debug(
        'No title found in Word document properties; falling back to filename.'
      );
      $import->setTitle(basename($import->getFile()->getFileUri()));
      return;
    }
    $import->setTitle($title);
  }

  /**
   * Convert the PhpWord document to an HTML string.
   *
   * PhpWord's HTML writer produces a complete HTML document with inline styles
   * and base64-encoded images. This method returns the full document so the
   * caller can parse it with DOMDocument.
   *
   * @param \PhpOffice\PhpWord\PhpWord $phpWord
   *   The PhpWord document.
   *
   * @return string
   *   The HTML string, or empty string on failure.
   */
  protected function convertToHtml(PhpWord $phpWord): string {
    try {
      $writer = IOFactory::createWriter($phpWord, 'HTML');

      // The writer requires a file path, so write to a system temp file.
      $tempFile = tempnam($this->tempDir, 'phpword_extract_');
      if ($tempFile === FALSE) {
        return '';
      }

      $writer->save($tempFile);
      $html = file_get_contents($tempFile);
      unlink($tempFile);

      return is_string($html) ? $html : '';
    }
    catch (\Exception $e) {
      $this->getLogger('localgov_publications_importer')->error(
        'Could not convert Word document to HTML: @message',
        ['@message' => $e->getMessage()]
      );
      return '';
    }
  }

  /**
   * Replace base64 data-URI images in the DOM with placeholder src values.
   *
   * PhpWord's HTML writer embeds images as base64 data URIs. This method:
   *   1. Finds every <img src="data:image/...;base64,..."> element.
   *   2. Decodes the image data and normalises it to JPEG.
   *   3. Saves the JPEG bytes to a temporary file under $this->tempDir.
   *   4. Creates an Image value object pointing to that temp file.
   *   5. Replaces the data-URI src with the placeholder src that
   *      Image::toPlaceHolder() would generate, so subsequent pipeline
   *      stages (transform_images, save_publication) can handle it.
   *
   * Duplicate images are deduplicated by MD5 hash.
   *
   * @param \DOMDocument $dom
   *   Parsed HTML.
   *
   * @return \Drupal\localgov_publications_importer\Image[]
   *   Map of placeholder src string to Image object.
   */
  protected function extractImages(\DOMDocument $dom): array {
    $imageMap = [];

    // Snapshot the node list before modifying the DOM.
    $imgNodeList = $dom->getElementsByTagName('img');
    $imgs = [];
    for ($i = 0; $i < $imgNodeList->length; $i++) {
      $imgs[] = $imgNodeList->item($i);
    }

    foreach ($imgs as $imgNode) {
      if (!($imgNode instanceof \DOMElement)) {
        continue;
      }

      $src = $imgNode->getAttribute('src');

      // Only process base64 data URIs.
      if (!preg_match('/^data:(image\/[\w+\-]+);base64,(.+)$/s', $src, $matches)) {
        continue;
      }

      $mimeType = $matches[1];
      $imageData = base64_decode($matches[2], TRUE);

      if ($imageData === FALSE || $imageData === '') {
        continue;
      }

      // Deduplicate: if we've seen this image before, reuse its placeholder.
      $hash = md5($imageData);
      if (isset($this->importedImages[$hash])) {
        $imgNode->setAttribute('src', $this->importedImages[$hash]);
        continue;
      }

      // Read image dimensions before any conversion.
      $imageInfo = getimagesizefromstring($imageData);
      if ($imageInfo === FALSE) {
        $this->getLogger('localgov_publications_importer')->debug('Could not read image info from embedded Word image; skipping.');
        continue;
      }

      [$width, $height] = $imageInfo;

      if ($mimeType === 'image/jpeg') {
        $extension = '.jpg';
      }
      elseif ($mimeType === 'image/png') {
        $extension = '.png';
      }
      else {
        continue;
      }

      // Save to the shared importer temp directory.
      $uuid = $this->uuid->generate();
      $dataFile = $this->tempDir . '/' . $uuid . $extension;
      $this->fileSystem->saveData($imageData, $dataFile, FileExists::Replace);

      $image = new Image();
      $image->setWidth($width);
      $image->setHeight($height);
      $image->setFilter(ImageInterface::FILTER_NONE);
      $image->setRawDataFile($dataFile);

      $placeholder = $image->toPlaceHolder();
      $imgNode->setAttribute('src', $placeholder);

      $this->importedImages[$hash] = $placeholder;
      $imageMap[$placeholder] = $image;
    }

    return $imageMap;
  }

}
