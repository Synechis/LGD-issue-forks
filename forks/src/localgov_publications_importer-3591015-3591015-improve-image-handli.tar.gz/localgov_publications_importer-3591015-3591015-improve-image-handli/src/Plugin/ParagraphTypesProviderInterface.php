<?php

namespace Drupal\localgov_publications_importer\Plugin;

/**
 * Interface for save plugins that restrict which paragraph types they accept.
 *
 * When a transform plugin (such as AiStructured) needs to know which paragraph
 * types are valid for a given save destination, it can instantiate the save
 * plugin and check for this interface. The transform plugin can then limit the
 * paragraph types it asks the AI to produce to only those the save plugin can
 * actually handle.
 */
interface ParagraphTypesProviderInterface {

  /**
   * Return the paragraph type IDs that this save plugin can accept.
   *
   * @return string[]
   *   Paragraph type IDs, e.g. ['localgov_text', 'localgov_contact'].
   */
  public function getAllowedParagraphTypes(): array;

}
