<?php

namespace Drupal\localgov_publications_importer;

use Drupal\Core\Entity\EntityInterface;
use Drupal\file\FileInterface;
use Drupal\node\NodeInterface;
use Drupal\user\UserInterface;

/**
 * Interface for content being imported.
 */
interface ImportInterface extends EntityInterface {

  /**
   * Set the title of the import.
   */
  public function setTitle(string $title): void;

  /**
   * Get the title of the import.
   */
  public function getTitle(): string;

  /**
   * Set the summary of the import.
   */
  public function setSummary(string $summary): void;

  /**
   * Get the summary of the import.
   */
  public function getSummary(): string;

  /**
   * Set the pages of the import.
   *
   * @param \Drupal\localgov_publications_importer\PageInterface[] $pages
   *   Array of pages.
   */
  public function setPages(array $pages): void;

  /**
   * Get the pages of the import.
   *
   * @return \Drupal\localgov_publications_importer\PageInterface[]
   *   Array of pages.
   */
  public function getPages(): array;

  /**
   * Add a new page to this import.
   */
  public function addPage(PageInterface $page): void;

  /**
   * Remove a page from this import.
   */
  public function removePage(int $pageNumber): void;

  /**
   * Get the status of the import.
   */
  public function getStatus(): int;

  /**
   * Set the status of the import.
   */
  public function setStatus(int $status): void;

  /**
   * Get the created timestamp.
   */
  public function getCreated(): int;

  /**
   * Set the created timestamp.
   */
  public function setCreated(int $timestamp): void;

  /**
   * Get the import pipeline ID to use.
   */
  public function getPipeline(): string;

  /**
   * Set the import pipeline ID to use.
   */
  public function setPipeline(string $pipeline): void;

  /**
   * Get the file.
   */
  public function getFile(): ?FileInterface;

  /**
   * Set the file.
   */
  public function setFile(FileInterface $file): void;

  /**
   * Set the result of the import.
   */
  public function setResult(NodeInterface $node): void;

  /**
   * Get the creator user.
   */
  public function getCreator(): ?UserInterface;

  /**
   * Set the creator user.
   */
  public function setCreator(UserInterface $user): void;

  /**
   * Add an image.
   */
  public function addImage(FileInterface $file): void;

  /**
   * Get the images.
   *
   * @return \Drupal\file\FileInterface[]
   *   Array of image files.
   */
  public function getImages(): array;

  /**
   * Set the images.
   *
   * @param \Drupal\file\FileInterface[] $files
   *   Array of image files.
   */
  public function setImages(array $files): void;

  /**
   * Get runtime plugin configuration overrides for this import.
   *
   * Keyed by plugin slot: 'extract', 'transform' (indexed by pipeline
   * position), and 'save'. Each entry is a complete plugin configuration array
   * that replaces the pipeline-level configuration at run time.
   *
   * @param ?string $pluginSlot
   *   Which plugin slot to get the config for. If nothing is passed, all the
   *   config for all slots is returned.
   *
   * @return array
   *   Runtime configuration array.
   */
  public function getRuntimeConfiguration(?string $pluginSlot = NULL): array;

  /**
   * Set runtime plugin configuration overrides for this import.
   *
   * @param array $configuration
   *   Keyed by 'extract', 'transform', and 'save' as described in
   *   getRuntimeConfiguration().
   */
  public function setRuntimeConfiguration(array $configuration): void;

}
