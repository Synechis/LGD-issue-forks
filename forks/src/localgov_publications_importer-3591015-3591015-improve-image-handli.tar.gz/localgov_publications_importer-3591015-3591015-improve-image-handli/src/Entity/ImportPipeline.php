<?php

namespace Drupal\localgov_publications_importer\Entity;

use Drupal\Core\Config\Entity\ConfigEntityBase;
use Drupal\Core\StringTranslation\StringTranslationTrait;
use Drupal\Core\StringTranslation\TranslatableMarkup;
use Drupal\localgov_publications_importer\ExtractOperationManager;

/**
 * Defines the Import Pipeline configuration entity.
 *
 * @ConfigEntityType(
 *   id = "localgov_import_pipeline",
 *   label = @Translation("Import Pipeline"),
 *   handlers = {
 *     "form" = {
 *       "default" = "Drupal\localgov_publications_importer\Form\ImportPipelineForm",
 *       "delete" = "Drupal\Core\Entity\EntityDeleteForm"
 *     },
 *     "list_builder" = "Drupal\localgov_publications_importer\ImportPipelineListBuilder",
 *     "route_provider" = {
 *       "html" = "Drupal\Core\Entity\Routing\AdminHtmlRouteProvider",
 *     },
 *     "access" = "Drupal\localgov_publications_importer\ImportPipelineAccessControlHandler",
 *   },
 *   config_prefix = "localgov_import_pipeline",
 *   admin_permission = "administer import pipelines",
 *   collection_permission = "view import pipelines",
 *   entity_keys = {
 *     "id" = "id",
 *     "label" = "label"
 *   },
 *   config_export = {
 *     "id",
 *     "label",
 *     "extract_plugin",
 *     "extract_plugin_configuration",
 *     "transform_plugins",
 *     "transform_plugin_configurations",
 *     "save_plugin",
 *     "save_plugin_configuration"
 *   },
 *   links = {
 *     "add-form" = "/admin/config/system/localgov-import-pipeline/add",
 *     "collection" = "/admin/config/system/localgov-import-pipeline",
 *     "edit-form" = "/admin/config/system/localgov-import-pipeline/{localgov_import_pipeline}",
 *     "delete-form" = "/admin/config/system/localgov-import-pipeline/{localgov_import_pipeline}/delete",
 *     "export-form" = "/admin/config/system/localgov-import-pipeline/{localgov_import_pipeline}/export"
 *   }
 * )
 */
class ImportPipeline extends ConfigEntityBase {

  use StringTranslationTrait;

  /**
   * The pipeline ID.
   *
   * @var string
   */
  public $id;

  /**
   * The pipeline label.
   *
   * @var string
   */
  public $label;

  /**
   * The extract plugin ID.
   *
   * @var string
   */
  public $extract_plugin;

  /**
   * The extract plugin configuration.
   *
   * @var array
   */
  public $extract_plugin_configuration = [];

  /**
   * The transform plugin IDs.
   *
   * @var array
   */
  public $transform_plugins = [];

  /**
   * The transform plugin configurations.
   *
   * @var array
   */
  public $transform_plugin_configurations = [];

  /**
   * The save plugin ID.
   *
   * @var string
   */
  public $save_plugin;

  /**
   * The save plugin configuration.
   *
   * @var array
   */
  public $save_plugin_configuration = [];

  /**
   * Get a description for the pipeline.
   *
   * Returns a human-readable list of the file extensions accepted by the
   * pipeline's extract plugin (e.g. "Accepts: docx, doc"), or an empty
   * string if the plugin imposes no restriction or cannot be found.
   *
   * @return \Drupal\Core\StringTranslation\TranslatableMarkup
   *   Description, or null.
   */
  public function description(): ?TranslatableMarkup {

    $extensions = $this->acceptableFileExtensions();
    if ($extensions === []) {
      return $this->t('Accepts any file');
    }

    return $this->t('Accepts: @extensions', [
      '@extensions' => implode(', ', $extensions),
    ]);
  }

  /**
   * Get the file extensions this import pipeline will accept.
   *
   * @return string[]
   *   Array of file extensions.
   */
  public function acceptableFileExtensions(): array {

    if (empty($this->extract_plugin)) {
      return [];
    }

    /** @var \Drupal\localgov_publications_importer\ExtractOperationManager $manager */
    $manager = \Drupal::service(ExtractOperationManager::class);
    $definition = $manager->getDefinition($this->extract_plugin);

    return $definition['supportedExtensions'] ?? [];
  }

}
