<?php

namespace Drupal\localgov_publications_importer\Controller;

use Drupal\Core\Controller\ControllerBase;
use Drupal\localgov_publications_importer\Entity\ImportPipeline;

/**
 * Controller for the Import Pipeline export page.
 */
class ImportPipelineExportController extends ControllerBase {

  /**
   * Renders the export page for an import pipeline.
   *
   * @param \Drupal\localgov_publications_importer\Entity\ImportPipeline $localgov_import_pipeline
   *   The import pipeline entity.
   *
   * @return array
   *   A render array.
   */
  public function export(ImportPipeline $localgov_import_pipeline): array {
    $data = array_diff_key($localgov_import_pipeline->toArray(), array_flip([
      'uuid',
      'langcode',
      'status',
      'dependencies',
      '_core',
    ]));
    $json = json_encode($data, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES);

    return [
      'export' => [
        '#type' => 'textarea',
        '#title' => $this->t('Pipeline configuration (JSON)'),
        '#value' => $json,
        '#rows' => 20,
        '#attributes' => ['readonly' => 'readonly'],
      ],
    ];
  }

  /**
   * Returns the page title for the export page.
   *
   * @param \Drupal\localgov_publications_importer\Entity\ImportPipeline $localgov_import_pipeline
   *   The import pipeline entity.
   *
   * @return string
   *   The page title.
   */
  public function title(ImportPipeline $localgov_import_pipeline): string {
    return (string) $this->t('Export: @label', ['@label' => $localgov_import_pipeline->label()]);
  }

}
