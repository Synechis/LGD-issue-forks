<?php

namespace Drupal\localgov_publications_importer;

/**
 * Interface for images being imported.
 */
interface ImageInterface {

  /**
   * No filter.
   *
   * Use of this constant for the image filter indicates that the image doesn't
   * require processing, and can be used as-is.
   */
  const FILTER_NONE = 'none';

  /**
   * Get the file ID, if this image has been imported.
   */
  public function getFileId(): ?int;

  /**
   * Set the file ID of this image.
   */
  public function setFileId(int $fileId): void;

  /**
   * Get the filter used to encode the image.
   */
  public function getFilter(): string;

  /**
   * Set the filter used to encode the image.
   */
  public function setFilter(string $filter): void;

  /**
   * Get the image width in pixels.
   */
  public function getWidth(): int;

  /**
   * Set the image width in pixels.
   */
  public function setWidth(int $width): void;

  /**
   * Get the image height in pixels.
   */
  public function getHeight(): int;

  /**
   * Set the image height in pixels.
   */
  public function setHeight(int $height): void;

  /**
   * Get the number of bits per color component.
   */
  public function getBitsPerComponent(): int;

  /**
   * Set the number of bits per color component.
   */
  public function setBitsPerComponent(int $bitsPerComponent): void;

  /**
   * Get the color space of the image.
   */
  public function getColorSpace(): string;

  /**
   * Set the color space of the image.
   */
  public function setColorSpace(string $colorSpace): void;

  /**
   * Get the path to the file containing the xObject data.
   *
   * @deprecated in localgov_publications_importer:1.2.0 and is removed from localgov_publications_importer:2.0.0. Use getRawDataFile().
   * @see https://www.drupal.org/project/localgov_publications_importer/issues/3583836
   *
   * @return string
   *   The file path.
   */
  public function getxObjectDataFile(): string;

  /**
   * Set the path to the file containing the xObject data.
   *
   * @deprecated in localgov_publications_importer:1.2.0 and is removed from localgov_publications_importer:2.0.0. Use setRawDataFile().
   * @see https://www.drupal.org/project/localgov_publications_importer/issues/3583836
   */
  public function setxObjectDataFile(string $xObjectDataFile): void;

  /**
   * Get the path to the file containing the raw data.
   */
  public function getRawDataFile(): string;

  /**
   * Set the path to the file containing the raw data.
   */
  public function setRawDataFile(string $rawDataFile): void;

  /**
   * Set the ID of media using this image.
   */
  public function setMediaId(int $mediaId): void;

  /**
   * Get the ID of media using this image.
   */
  public function getMediaId(): ?int;

  /**
   * Gets a placeholder for the image that we can insert into content.
   */
  public function toPlaceHolder(): string;

  /**
   * Figure out the file extension this image should have from its filter.
   */
  public function fileExtension(): string;

}
