<?php

namespace Drupal\localgov_publications_importer\Commands;

use Drupal\Core\Entity\EntityTypeManagerInterface;
use Drupal\localgov_publications_importer\ExtractOperationManager;
use Drupal\localgov_publications_importer\Service\ParagraphSchemaDiscovery;
use Drush\Commands\DrushCommands;

/**
 * Drush commands for debugging the PDF import pipeline.
 */
class DebugCommand extends DrushCommands {

  /**
   * Constructor.
   */
  public function __construct(
    protected ParagraphSchemaDiscovery $paragraphSchemaDiscovery,
    protected ExtractOperationManager $extractOperationManager,
    protected EntityTypeManagerInterface $entityTypeManager,
  ) {
    parent::__construct();
  }

  /**
   * Print the paragraph schema as JSON.
   *
   * @command localgov_publications_importer:paragraph-schema
   * @aliases lpips
   */
  public function paragraphSchema(): void {
    $this->output()->writeln(json_encode($this->paragraphSchemaDiscovery->getSchema(), JSON_PRETTY_PRINT));
  }

  /**
   * Run an extract plugin against a file and print the extracted content.
   *
   * @param string $path
   *   Absolute path to the file to extract from.
   * @param string $plugin_id
   *   The extract plugin ID to use (e.g. smalot_pdfparser, phpword).
   *
   * @command localgov_publications_importer:debug-extract
   * @aliases lpide
   * @usage localgov_publications_importer:debug-extract /path/to/file.pdf smalot_pdfparser
   *   Extract the given PDF using the Smalot parser and print the result.
   */
  public function debugExtract(string $path, string $plugin_id): void {
    $realPath = realpath($path);
    if ($realPath === FALSE) {
      $this->logger()->error("File not found: {$path}");
      return;
    }

    $file = $this->entityTypeManager->getStorage('file')->create([
      'uri' => $realPath,
      'filename' => basename($realPath),
      'status' => 1,
    ]);

    $import = $this->entityTypeManager->getStorage('localgov_import')->create([]);
    $import->setFile($file);

    try {
      $plugin = $this->extractOperationManager->createInstance($plugin_id);
    }
    catch (\Exception $e) {
      $this->logger()->error("Could not instantiate extract plugin '{$plugin_id}': {$e->getMessage()}");
      return;
    }

    try {
      $plugin->extract($import);
    }
    catch (\Exception $e) {
      $this->logger()->error("Extract failed: {$e->getMessage()}");
      return;
    }

    $pages = $import->getPages();
    if (empty($pages)) {
      $this->logger()->notice('No pages extracted.');
      return;
    }

    $this->output()->writeln('Title:  ' . $import->getTitle());
    $this->output()->writeln('Pages:  ' . count($pages));

    foreach ($pages as $page) {
      $this->output()->writeln('');
      $this->output()->writeln('--- Page ' . $page->getPageNumber() . ': ' . $page->getTitle() . ' ---');

      $content = $page->getContent();
      if (is_array($content)) {
        $this->output()->writeln(json_encode($content, JSON_PRETTY_PRINT));
      }
      else {
        $this->output()->writeln($content);
      }

      $imageCount = count($page->getImages());
      if ($imageCount > 0) {
        $this->output()->writeln("[{$imageCount} image(s) on this page]");
      }
    }
  }

}
