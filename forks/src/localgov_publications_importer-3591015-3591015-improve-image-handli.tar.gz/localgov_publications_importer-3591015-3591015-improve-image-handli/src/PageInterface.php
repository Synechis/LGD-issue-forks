<?php

namespace Drupal\localgov_publications_importer;

/**
 * Interface for a single page of content being imported.
 */
interface PageInterface {

  /**
   * Set the title of the page.
   */
  public function setTitle(string $title): void;

  /**
   * Get the title of the page.
   */
  public function getTitle(): string;

  /**
   * Set the content of the page.
   *
   * @param string|array $content
   *   Either an HTML string, or an array of paragraph data arrays, each with a
   *   'type' key and field values (e.g. ['type' => 'localgov_text',
   *   'localgov_text' => '<p>HTML</p>']).
   */
  public function setContent(string|array $content): void;

  /**
   * Get the content of the page.
   *
   * @return string|array
   *   Either an HTML string or an array of paragraph data arrays.
   */
  public function getContent(): string|array;

  /**
   * Set the poge number.
   */
  public function setPageNumber(int $pageNumber): void;

  /**
   * Get the poge number.
   */
  public function getPageNumber(): ?int;

  /**
   * Add an image to the page.
   */
  public function addImage(ImageInterface $image): void;

  /**
   * Get the images that have been added to the page.
   *
   * @return ImageInterface[]
   *   The images that have been added to this page.
   */
  public function getImages(): array;

}
