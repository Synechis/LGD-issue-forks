<?php

namespace Drupal\localgov_publications_importer\Service;

use Drupal\Core\Entity\EntityFieldManagerInterface;
use Drupal\Core\Entity\EntityTypeManagerInterface;
use Drupal\Core\Field\FieldDefinitionInterface;
use Drupal\paragraphs\Entity\Paragraph;
use Drupal\paragraphs\ParagraphInterface;

/**
 * Discovers paragraph types and their AI-fillable fields at runtime.
 */
class ParagraphSchemaDiscovery {

  /**
   * Field types that can be populated by an AI from plain text / HTML / links.
   */
  protected const AI_FILLABLE_TYPES = [
    'string',
    'string_long',
    'text_long',
    'link',
    'email',
    'telephone',
    'integer',
    'float',
    'decimal',
    'list_string',
    'list_integer',
    'list_float',
    'entity_reference',
  ];

  /**
   * Base fields that every paragraph entity has — always skip these.
   */
  protected const BASE_FIELDS = [
    'id',
    'uuid',
    'revision_id',
    'langcode',
    'type',
    'status',
    'created',
    'parent_id',
    'parent_type',
    'parent_field_name',
    'behavior_settings',
    'default_langcode',
    'revision_default',
    'revision_translation_affected',
  ];

  public function __construct(
    protected EntityTypeManagerInterface $entityTypeManager,
    protected EntityFieldManagerInterface $entityFieldManager,
  ) {}

  /**
   * Return a schema array describing AI-fillable paragraph types.
   *
   * Each entry is keyed by paragraph type ID and contains:
   *   - 'label': human-readable label
   *   - 'fields': array keyed by field name with 'type' and 'description'
   *
   * @return array<string, array{label: string, fields: array<string, array{type: string, description: string}>}>
   *   Paragraph schema array.
   */
  public function getSchema(): array {
    $schema = [];

    /** @var \Drupal\paragraphs\ParagraphsTypeInterface[] $paragraphTypes */
    $paragraphTypes = $this->entityTypeManager
      ->getStorage('paragraphs_type')
      ->loadMultiple();

    foreach ($paragraphTypes as $typeId => $paragraphType) {
      $fieldDefinitions = $this->entityFieldManager
        ->getFieldDefinitions('paragraph', $typeId);

      $fillableFields = [];

      foreach ($fieldDefinitions as $fieldName => $definition) {
        if (in_array($fieldName, self::BASE_FIELDS, TRUE)) {
          continue;
        }

        $fieldType = $definition->getType();

        if (!in_array($fieldType, self::AI_FILLABLE_TYPES, TRUE)) {
          continue;
        }

        if ($fieldType === 'entity_reference' && $definition->getSetting('target_type') !== 'media') {
          continue;
        }

        $fillableFields[$fieldName] = $this->describeFieldType($fieldType, $definition);
      }

      if ($fillableFields === []) {
        continue;
      }

      $schema[$typeId] = [
        'label' => (string) $paragraphType->label(),
        'description' => $paragraphType->getDescription(),
        'fields' => $fillableFields,
      ];
    }

    return $schema;
  }

  /**
   * Create a paragraph entity from an AI-generated data array.
   *
   * @param array $data
   *   Must contain a 'type' key matching a paragraph type ID, plus field
   *   values keyed by field name.
   */
  public function createParagraphFromData(array $data): ParagraphInterface {
    $typeId = $data['type'];
    $schema = $this->getSchema();

    $values = ['type' => $typeId];

    if (isset($schema[$typeId])) {
      foreach ($schema[$typeId]['fields'] as $fieldName => $fieldInfo) {
        if (!isset($data[$fieldName])) {
          continue;
        }

        $rawValue = $data[$fieldName];

        $values[$fieldName] = match ($fieldInfo['type']) {
          'text_long' => ['value' => $rawValue, 'format' => 'wysiwyg'],
          'link' => is_array($rawValue)
            ? ['uri' => $rawValue['uri'] ?? '', 'title' => $rawValue['title'] ?? '']
            : ['uri' => $rawValue, 'title' => ''],
          'integer', 'list_integer' => (int) $rawValue,
          'float', 'list_float' => (float) $rawValue,
          'decimal' => (string) $rawValue,
          default => $rawValue,
        };
      }
    }

    return Paragraph::create($values);
  }

  /**
   * Return a human-readable description of a field type for the AI prompt.
   *
   * @param string $fieldType
   *   The field type ID.
   * @param \Drupal\Core\Field\FieldDefinitionInterface $definition
   *   The field definition, used to extract allowed values for list fields.
   *
   * @return string
   *   A prompt-ready description of the expected value format.
   */
  protected function describeFieldType(string $fieldType, FieldDefinitionInterface $definition): array {
    if (in_array($fieldType, ['list_string', 'list_integer', 'list_float'], TRUE)) {
      $allowed = array_keys($definition->getSetting('allowed_values') ?? []);
      if ($allowed !== []) {
        return [
          'type' => $fieldType,
          'description' => 'one of: ' . implode(', ', $allowed),
        ];
      }
    }

    // Override entity_reference fields that reference media into a pseudotype
    // that describes it better to the LLM.
    // @todo Ideally only do this for image media.
    if ($definition->getSetting('target_type') === 'media') {
      $fieldType = 'image';
    }

    $description = match ($fieldType) {
      'string', 'string_long' => 'plain text string',
      'text_long' => 'HTML string using tags: h2, h3, h4, p, ul, ol, li',
      'link' => '{"uri": "...", "title": "..."} object',
      'email' => 'email address string',
      'telephone' => 'telephone number string',
      'integer', 'list_integer' => 'integer',
      'float', 'list_float' => 'float',
      'decimal' => 'decimal number as string',
      'entity_reference' => 'entity ID (integer)',
      'image' => 'img tag from the source markup, e.g. <img src="..." alt="...">',
      default => 'string',
    };

    return [
      'type' => $fieldType,
      'description' => $description,
    ];
  }

}
