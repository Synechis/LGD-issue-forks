<?php

declare(strict_types=1);

namespace Drupal\Tests\localgov_topics\Kernel;

use Drupal\KernelTests\KernelTestBase;
use Drupal\taxonomy\Entity\Vocabulary;
use Drupal\field\Entity\FieldStorageConfig;
use Drupal\user\Entity\Role;
use Drupal\localgov_roles\RolesHelper;

/**
 * Tests localgov_topics module behavior.
 *
 * @group localgov_topics
 */
class LocalgovTopicsTest extends KernelTestBase {

  /**
   * Modules to enable.
   *
   * @var array
   */
  protected static $modules = [
    'system',
    'user',
    'node',
    'taxonomy',
    'field',
    'text',
    'localgov_roles',
    'localgov_topics',
  ];

  /**
   * {@inheritdoc}
   */
  protected function setUp(): void {
    parent::setUp();

    // Install required entity schemas and config.
    $this->installEntitySchema('taxonomy_term');
    $this->installEntitySchema('node');
    $this->installEntitySchema('user');
    $this->installConfig(['user', 'localgov_roles', 'localgov_topics']);
  }

  /**
   * Load the editor role and verify it has the permissions.
   */
  public function testEditorRoleHasPermissions(): void {
    RolesHelper::assignModuleRoles('localgov_topics');

    $role_id = RolesHelper::EDITOR_ROLE;

    $role = Role::load($role_id);
    $this->assertNotNull($role, "Role '$role_id' should exist (provided by localgov_roles).");

    $this->assertTrue($role->hasPermission('create terms in localgov_topic'));
    $this->assertTrue($role->hasPermission('edit terms in localgov_topic'));
    $this->assertTrue($role->hasPermission('delete terms in localgov_topic'));
  }

  /**
   * Verify config/install created the vocabulary and the field storage.
   */
  public function testConfigInstallCreatesVocabularyAndFieldStorage(): void {
    $vocab = Vocabulary::load('localgov_topic');
    $this->assertNotNull($vocab, 'localgov_topic vocabulary was installed.');
    $this->assertEquals('localgov_topic', $vocab->id());

    $storage = FieldStorageConfig::loadByName('node', 'localgov_topic_classified');
    $this->assertNotNull($storage, 'Field storage node.localgov_topic_classified exists.');
    $this->assertEquals('entity_reference', $storage->getType());
  }

}
