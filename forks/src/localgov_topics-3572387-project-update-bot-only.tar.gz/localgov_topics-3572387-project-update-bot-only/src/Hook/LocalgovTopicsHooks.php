<?php

namespace Drupal\localgov_topics\Hook;

use Drupal\localgov_roles\RolesHelper;
use Drupal\Core\Hook\Attribute\Hook;

/**
 * Hook implementations for localgov_topics.
 */
class LocalgovTopicsHooks {

  /**
   * Implements hook_localgov_roles_default().
   */
  #[Hook('localgov_roles_default')]
  public function localgovRolesDefault(): array {
    // Grant edit topic permissions to localgov roles.
    $topic_permissions = [
      'create terms in localgov_topic',
      'delete terms in localgov_topic',
      'edit terms in localgov_topic',
    ];
    $perms = [
      RolesHelper::EDITOR_ROLE => $topic_permissions,
    ];
    return $perms;
  }

}
