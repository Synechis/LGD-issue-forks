# LocalGov Waste collection CSV data provider

This module provides a CSV data provider for authorities which may not have access to a third-party waste collection system or address gazetteer.

## How to use

- Enable the module and set it as the active data provider in the [parent module settings](../../README.md#configuration).
- Prepare the 2 required CSV files, and optionally a PDF file for each collection route (see file formats / naming below for details).
- Visit the CSV data provider settings form, select the mode for import, select the property & route CSV file and the collection dates CSV file, and submit the form.
- The import can take some time to process depending on the number of properties in the import file. After initial import use the 'Append and update' option and only include new or changed records in the import files.

## File formats
### Property file
4 columns:
- UPRN
- Postcode
- Round code
- Formatted address

### Collections file
3 columns:
- Round code
- Waste type
- Collection date

### PDF files
Named to match the round code, with a .pdf extension. This is case sensitive.

## Example files

Example CSV files are provided in the ``examples`` folder in the root of this sub-module:
- ```TestProperties.csv``` includes 2 properties with missing UPRNs.
- ```TestPropertiesUpdate.csv``` contains corrected data for those 2 properties and one additional property, to test the append and update import option.
- ```TestCollections.csv``` contains collection data for the three collection rounds referenced in the properties data.
- ```MONA.pdf``` is a sample PDF for the ```MONA``` round.

