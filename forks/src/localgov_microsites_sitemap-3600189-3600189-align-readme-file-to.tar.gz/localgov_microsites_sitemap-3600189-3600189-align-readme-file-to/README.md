# LocalGov Microsites Sitemap

Gives every microsite in a LocalGov Microsites installation its own XML sitemap,
served at `/sitemap.xml` on that microsite's own domain and containing only that
microsite's content.

Out of the box, [Simple XML Sitemap](https://www.drupal.org/project/simple_sitemap)
has no concept of microsites: it serves one default sitemap at `/sitemap.xml`
regardless of which domain the request arrived on. On a microsites install that
means every microsite domain advertises the control site's content. This module
replaces that behaviour with a per-microsite sitemap variant, and blocks the
fallback so a microsite can never serve the control site's sitemap.

## Requirements

- [Simple XML Sitemap](https://www.drupal.org/project/simple_sitemap) 4.2 or newer
- [LocalGov Microsites Group](https://www.drupal.org/project/localgov_microsites_group)

`domain`, `domain_path`, `group`, `gnode` and `group_context_domain` are all
required at runtime, but they arrive with `localgov_microsites_group` and do not
need to be requested separately.

## Installation

Install with Composer and enable as usual:

```
composer require drupal/localgov_microsites_sitemap
drush en localgov_microsites_sitemap
```

On enable, the module creates sitemap variants for every microsite that already
exists. Nothing needs to be configured by hand.

---

# For site administrators

## What the module creates

Each microsite gets **two** sitemap variants, both listed at
_Configuration → Search and metadata → Simple XML Sitemap_:

| Variant                          | ID                        | Purpose                                                                |
| -------------------------------- | ------------------------- | ---------------------------------------------------------------------- |
| `<Microsite name> Sitemap`       | `lgd_ms_<group id>`       | The actual sitemap: the microsite's content, with hreflang alternates. |
| `<Microsite name> Sitemap Index` | `lgd_ms_index_<group id>` | A sitemap index listing the microsite's other variants.                |

These are created and deleted automatically:

- Creating a microsite group creates both variants.
- Deleting a microsite group deletes both variants and their bundle settings.
- Enabling the module creates variants for all pre-existing microsites.
- Uninstalling the module removes every microsite variant it manages.

## Which content is included

When a variant is created, indexing is switched on for every **content type**
that is **available to that microsite**. Content types disabled from
microsite's site setting are excluded.

Other entity types, such as media or taxonomy terms, are not indexed by
default. They can be enabled on the variant from the Simple XML Sitemap UI.

Indexing is always switched on for these content types, even if the **default**
sitemap variant does not index them. Priority, change frequency and image
settings are inherited from the default variant, so site-wide choices carry
over to microsites; where the default variant has no settings for a content
type, priority 0.5 and a weekly change frequency are used and images are not
included.

**Only nodes and media are filtered by microsite.** If another entity type,
such as taxonomy terms, is indexed on a microsite variant, the sitemap lists
every entity of that type from **all** microsites, not only this one's.

Note that this reflects the microsite's configuration **at the moment the
variant is created**. Enabling or disabling a module on an existing microsite
later does not retroactively update its sitemap's bundle settings — adjust those
on the variant directly if needed.

## Generating the sitemaps

Generation is handled entirely by Simple XML Sitemap. Sitemaps are built on
cron, or on demand:

```
drush simple-sitemap:generate
```

Until a variant has been generated at least once, requesting it returns a 404.

## What visitors see

- `https://<microsite-domain>/sitemap.xml` — that microsite's sitemap.
- `https://<control-site-domain>/sitemap.xml` — the default, site-wide sitemap,
  unchanged.

A microsite needs a **domain** for this to work. Without one, its sitemap is
only reachable at `/lgd_ms_<group id>/sitemap.xml` on the control site, and
its URLs go through Simple XML Sitemap's usual anonymous access check, which
microsite content normally fails on the control site, so the sitemap usually
ends up empty.

Every variant also remains reachable at its own `/<variant id>/sitemap.xml`
path, on any domain. That path always serves the named variant, whichever
domain the request arrives on.

**A microsite domain never falls back to the default sitemap.** If a microsite
has no usable sitemap, for example the variant is missing, disabled, or has not been
generated yet; `/sitemap.xml` on that domain returns **404**. This is
deliberate: silently serving the control site's sitemap on a microsite domain
would publish the wrong URLs to search engines.

If a microsite unexpectedly 404s at `/sitemap.xml`, check in this order:

1. The variant exists and is **enabled** on the Simple XML Sitemap variants page.
2. Its **Microsite group** field points at the right microsite (see below).
3. The sitemap has been generated (`drush simple-sitemap:generate`).
4. The microsite's domain has a group assigned in its Domain settings.

If `/sitemap.xml` works but the sitemap is empty, check that the microsite has
a domain (see above) and regenerate.

## Reassigning a variant

The add and edit forms of a sitemap variant have an extra **Microsite group**
select, which controls which microsite the variant is scoped to. It is shown,
and required, only when the variant's type is one of the two microsite types
(see [Sitemap types](#sitemap-types)); for any other type it is hidden.

Choosing another microsite moves the variant to that microsite. A variant of a
microsite type cannot be saved without a microsite group. A sitemap that should
not belong to any microsite has to use one of Simple XML Sitemap's own types
instead, and is then outside the scope of this module.

---

# For developers

## Architecture

| Class                                     | Role                                                                                  |
| ----------------------------------------- | ------------------------------------------------------------------------------------- |
| `MicrositeSitemapManager`                 | Creates, loads and deletes variants for a group. The entry point for everything else. |
| `Hook\GroupSitemapHooks`                  | `entity_insert` / `entity_delete` on `microsite` groups, driving the manager.         |
| `Hook\SimpleSitemapFormHooks`             | Adds the _Microsite group_ select to the variant add/edit forms, for microsite types. |
| `EventSubscriber\SitemapDomainSubscriber` | Maps a request on a microsite domain to that microsite's variant, or 404s.            |
| `Plugin\...\MicrositeEntityUrlGenerator`  | Emits entity URLs filtered to the group, on the microsite's domain.                   |
| `Plugin\...\MicrositeIndexUrlGenerator`   | Emits the sitemap index, listing only sibling variants of the same group.             |

## How a variant knows its microsite

The group ID is stored on the variant as a third party setting:

```yaml
simple_sitemap.sitemap.lgd_ms_7:
  third_party_settings:
    localgov_microsites_sitemap:
      localgov_microsites_group_id: 7
```

Addressed in code via constants on `MicrositeSitemapManager`:

```php
$group_id = $sitemap->getThirdPartySetting(
  MicrositeSitemapManager::MODULE_NAME,
  MicrositeSitemapManager::THIRD_PARTY_SETTING_GROUP_ID_KEY
);
```

**This setting is the source of truth.** IDs follow the
`lgd_ms_<gid>` / `lgd_ms_index_<gid>` convention, but may carry a uniqueness
suffix on collision, and the group can be reassigned from the admin UI. Always
resolve variants with `MicrositeSitemapManager::loadForGroup()` rather than
rebuilding an ID from a group:

```php
/** @var \Drupal\simple_sitemap\Entity\SimpleSitemapInterface[] $variants */
$variants = $sitemapManager->loadForGroup($group);
```

## Sitemap types

Two `simple_sitemap_type` config entities ship in `config/install`:

- **`localgov_microsites_sitemap_hreflang`** — generator `default`, URL
  generators `custom`, `localgov_microsites_sitemap_entity`,
  `entity_menu_link_content`, `arbitrary`.
- **`localgov_microsites_sitemap_index`** — generator `index`, URL generator
  `localgov_microsites_sitemap_index`.

Both are marked as enforced dependencies of this module, so they are removed on
uninstall.

## URL generation

`MicrositeEntityUrlGenerator` extends Simple XML Sitemap's `EntityUrlGenerator`
and does two things on top of it:

1. **Filters datasets to the group.** `getDataSets()` intersects the parent's
   IDs with those in `group_relationship_field_data` for the variant's group.
   This covers `node` (`group_node:*`) and `media` (`group_media:*`); any other
   entity type passes through **unfiltered**.
2. **Rewrites URLs onto the microsite domain.** A `domain_path` alias for the
   microsite's domain is preferred; failing that, the generation base URL is
   substituted for the microsite's. The microsite's own front, 403 and 404 page
   settings are honoured.

`MicrositeIndexUrlGenerator` throws `SkipElementException` for any variant that
is disabled, is itself an index, or belongs to a different group, so a
microsite's index lists only its own siblings. Each entry points at
`https://<microsite-domain>/sitemap.xml`, not the internal
`/{variant}/sitemap.xml` path.

## Request routing

`SitemapDomainSubscriber` listens on `KernelEvents::REQUEST` at priority 20 —
after routing, so the resolved `variant` attribute is read by the controller's
argument resolver as though `/{variant}/sitemap.xml` had been matched.

For a request to `/sitemap.xml`:

| Condition                                       | Result                                      |
| ----------------------------------------------- | ------------------------------------------- |
| Domain has no `group_context_domain` group UUID | Pass through: control site, default sitemap |
| Group UUID set, group won't load                | `NotFoundHttpException`                     |
| Group loads, no enabled variant                 | `NotFoundHttpException`                     |
| Group loads, variant found                      | Sets the `variant` request attribute        |

The hreflang variant is preferred; any other enabled variant for the group is
used as a fallback.

The 404s are load-bearing. `SimpleSitemapController::getSitemap()` falls back to
`getDefaultSitemap()` when no variant is supplied, so returning early on a
microsite domain would serve the control site's sitemap.

## Known limitations

- `ContentTypeHelper::enabledContentTypes()` is not declared on
  `ContentTypeHelperInterface`, so `MicrositeSitemapManager` type-hints the
  concrete class. It could change without a BC break upstream.
- Bundle settings are only written at variant creation; later changes to a
  microsite's enabled modules are not reflected.
- Only node bundle settings are written; other entity types have to be enabled
  on each variant by hand.
- Entity types other than `node` and `media` are not group-filtered by
  `MicrositeEntityUrlGenerator`: if indexed on a microsite variant, entities
  of that type from every microsite end up in its sitemap.
- On a microsite domain, URLs are not checked for anonymous access; only
  unpublished content and the microsite's 403/404 pages are left out.
- Every entry in a microsite's sitemap index points at
  `https://<microsite-domain>/sitemap.xml`. With more than one non-index
  variant in the same group, the entries all share that URL.
- `initializeAllMicrosites()` loads every microsite group in one pass, which may
  be heavy on installations with a large number of microsites.

## Supporting this module

### Big Blue Door

This module is developed by
[Big Blue Door](https://www.drupal.org/big-blue-door), who actively support
its ongoing maintenance and development through sponsored developer time.

**Supporting organizations:**

- [Big Blue Door](https://www.drupal.org/big-blue-door) — development and
  maintenance

## Maintainers

Part of the [LocalGov Drupal](https://localgovdrupal.org/) project.

- Marco Pagliarulo - [marcopagliarulo](https://www.drupal.org/u/marcopagliarulo)
- Tsegaselassie Tadesse - [tsega](https://www.drupal.org/u/tsega)
- Colin McTaggart - [youngwolf0](https://www.drupal.org/u/youngwolf0)
- Finn Lewis - [finn-lewis](https://www.drupal.org/u/finn-lewis)
- ekes - [ekes](https://www.drupal.org/u/ekes)
- Mark Conroy - [markconroy](https://www.drupal.org/u/markconroy)
- Tony Barker - [tonypaulbarker](https://www.drupal.org/u/tonypaulbarker)
