<?php

namespace Drupal\localgov_moderngov\Hook;

use Drupal\localgov_moderngov\Constants;
use Drupal\Core\Hook\Attribute\Hook;

/**
 * Hook implementations for localgov_moderngov.
 */
class LocalgovModerngovHooks {

  /**
   * Implements hook_theme().
   *
   * Themes:
   * - ModernGov template page.
   */
  #[Hook('theme')]
  public function theme() {
    return [
      Constants::PAGE_TPL_NAME => [
        'base hook' => 'page',
      ],
    ];
  }

}
