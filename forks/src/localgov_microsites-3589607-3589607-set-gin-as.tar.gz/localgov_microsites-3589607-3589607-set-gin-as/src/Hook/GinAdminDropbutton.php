<?php

namespace Drupal\localgov_microsites\Hook;

use Drupal\Core\Hook\Attribute\Hook;
use Drupal\Core\Security\TrustedCallbackInterface;
use Drupal\Core\Theme\ThemeManagerInterface;

/**
 * Alter the dropdown to show as extrasmall on backend (Gin default).
 *
 * Gin set the dropdown style to extrasmall by default.
 * Group admin views did not use operation field but global operation field
 * Which is not preprocessed by gin.
 *
 * @package Drupal\localgov_microsites\Hook
 */
class GinAdminDropbutton implements TrustedCallbackInterface {

  /**
   * Constructs a new GinAdminDropbutton instance.
   *
   * @param \Drupal\Core\Theme\ThemeManagerInterface $themeManager
   *   The theme manager service.
   */
  public function __construct(
    protected ThemeManagerInterface $themeManager,
  ) {}

  /**
   * {@inheritdoc}
   */
  public static function trustedCallbacks(): array {
    return ['setDropbuttonType'];
  }

  /**
   * Implements hook_element_info_alter().
   */
  #[Hook('element_info_alter')]
  public function elementInfoAlter(array &$info): void {
    if (isset($info['dropbutton'])) {
      $dropbutton_pre_renders = !empty($info['dropbutton']['#pre_render']) ? $info['dropbutton']['#pre_render'] : [];
      array_unshift($dropbutton_pre_renders, __CLASS__ . '::setDropbuttonType');
      $info['dropbutton']['#pre_render'] = $dropbutton_pre_renders;
    }
  }

  /**
   * Set dropbutton type to extrasmall for Gin theme.
   *
   * @param array $element
   *   The element definition.
   *
   * @return array
   *   The altered element definition.
   */
  public function setDropbuttonType(array $element): array {
    if (!empty($element['#dropbutton_type'])) {
      return $element;
    }

    if ($this->themeManager->getActiveTheme()->getName() !== 'gin') {
      return $element;
    }

    $element['#dropbutton_type'] = 'extrasmall';
    return $element;
  }

}
