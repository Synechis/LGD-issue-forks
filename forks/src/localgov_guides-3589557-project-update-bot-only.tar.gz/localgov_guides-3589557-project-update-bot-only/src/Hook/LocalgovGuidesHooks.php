<?php

namespace Drupal\localgov_guides\Hook;

use Drupal\Core\Form\FormStateInterface;
use Drupal\localgov_guides\ChildParentRelationship;
use Drupal\node\NodeInterface;
use Drupal\Core\Hook\Attribute\Hook;

/**
 * Hook implementations for localgov_guides.
 */
class LocalgovGuidesHooks {

  /**
   * Implements hook_theme().
   */
  #[Hook('theme')]
  public function theme($existing, $type, $theme, $path) {
    return [
      'guides_contents_block' => [
        'variables' => [
          'links' => [],
          'format' => [],
        ],
      ],
      'guides_prev_next_block' => [
        'variables' => [
          'previous_url' => NULL,
          'previous_title' => NULL,
          'next_url' => NULL,
          'next_title' => NULL,
          'show_title' => NULL,
        ],
      ],
      'node__localgov_guides_overview__full' => [
        'template' => 'node--localgov-guides-overview--full',
        'base hook' => 'node',
      ],
      'node__localgov_guides_page__full' => [
        'template' => 'node--localgov-guides-page--full',
        'base hook' => 'node',
      ],
    ];
  }

  /**
   * Implements hook_ENTITY_TYPE_insert().
   */
  #[Hook('node_insert')]
  public function nodeInsert(NodeInterface $node) {
    if ($node->bundle() == 'localgov_guides_page') {
      return \Drupal::service('class_resolver')->getInstanceFromDefinition(ChildParentRelationship::class)->pageUpdateOverview($node);
    }
  }

  /**
   * Implements hook_ENTITY_TYPE_update().
   *
   * Implements reference back on overview to page when pages are created.
   */
  #[Hook('node_update')]
  public function nodeUpdate(NodeInterface $node) {
    if ($node->bundle() == 'localgov_guides_page') {
      return \Drupal::service('class_resolver')->getInstanceFromDefinition(ChildParentRelationship::class)->pageUpdateOverview($node);
    }
  }

  /**
   * Implements hook_ENTITY_TYPE_prepare_form().
   *
   * Check back-reference fields before editing overview.
   */
  #[Hook('node_prepare_form')]
  public function nodePrepareForm(NodeInterface $node, $operation, FormStateInterface $form) {
    if ($node->bundle() == 'localgov_guides_overview') {
      return \Drupal::service('class_resolver')->getInstanceFromDefinition(ChildParentRelationship::class)->overviewPagesCheck($node);
    }
  }

  /**
   * Implements hook_ENTITY_TYPE_presave().
   *
   * Check back-reference fields before saving.
   * Especially if someone has changed a page since form load!
   */
  #[Hook('node_presave')]
  public function nodePresave(NodeInterface $node) {
    if ($node->bundle() == 'localgov_guides_overview') {
      return \Drupal::service('class_resolver')->getInstanceFromDefinition(ChildParentRelationship::class)->overviewPagesCheck($node);
    }
  }

  /**
   * Implements hook_modules_installed().
   */
  #[Hook('modules_installed')]
  public function modulesInstalled($modules) {
    $services = in_array('localgov_services_navigation', $modules, TRUE);
    $topics = in_array('localgov_topics', $modules, TRUE);
    if ($services) {
      \Drupal::service('config.installer')->installOptionalConfig(NULL, [
        'config' => 'field.storage.node.localgov_services_parent',
      ]);
    }
    if ($topics) {
      \Drupal::service('config.installer')->installOptionalConfig(NULL, [
        'config' => 'field.storage.node.localgov_topic_classified',
      ]);
    }
    if ($services || $topics) {
      localgov_guides_optional_fields_settings($services, $topics);
    }
  }

  /**
   * Implements hook_preprocess_HOOK().
   */
  #[Hook('preprocess_html')]
  public function preprocessHtml(&$variables) {
    // Add the guide overview as a subtitle to guide pages.
    $node = \Drupal::routeMatch()->getParameter('node');
    if ($node instanceof NodeInterface && $node->bundle() == 'localgov_guides_page') {
      if ($parent = $node->get('localgov_guides_parent')->entity) {
        $variables['head_title']['title'] .= ' | ' . trim(strip_tags($parent->label()));
      }
    }
  }

}
