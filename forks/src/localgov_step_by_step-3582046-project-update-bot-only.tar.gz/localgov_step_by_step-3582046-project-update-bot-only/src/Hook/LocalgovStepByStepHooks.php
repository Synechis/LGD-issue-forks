<?php

namespace Drupal\localgov_step_by_step\Hook;

use Drupal\Core\Entity\EntityInterface;
use Drupal\Core\Hook\Attribute\Hook;

/**
 * Hook implementations for localgov_step_by_step.
 */
class LocalgovStepByStepHooks {

  /**
   * Implements hook_theme().
   *
   * Provides the following themes:
   * - Step by step navigation view's Prev/Next block.
   */
  #[Hook('theme')]
  public function theme() {
    return [
      'step_by_step_part_of_block' => [
        'variables' => [
          'label' => NULL,
          'url' => NULL,
        ],
        'render element' => 'children',
      ],
      'views_view_list__localgov_step_by_step_navigation__prev_next' => [
        'base hook' => 'views_view_list',
      ],
    ];
  }

  /**
   * Implements hook_ENTITY_TYPE_insert().
   */
  #[Hook('node_insert')]
  public function nodeInsert(EntityInterface $entity) {
    localgov_step_by_step_node_update($entity);
  }

  /**
   * Implements hook_ENTITY_TYPE_update().
   *
   * The step_by_step_overview and step_by_step_page content types reference each
   * other.  When a step_by_step_page type node is updated, find its
   * step_by_step_overview node.  Then make sure this step_by_step_overview node
   * refers back to the step_by_step_page node.
   */
  #[Hook('node_update')]
  public function nodeUpdate(EntityInterface $entity) {
    $is_not_step_by_step_page_node = $entity->bundle() !== 'localgov_step_by_step_page';
    if ($is_not_step_by_step_page_node) {
      return;
    }
    $step_by_step_page_node = $entity;
    $step_by_step_page_nid = $step_by_step_page_node->id();
    $step_by_step_overview_node = $step_by_step_page_node->localgov_step_parent->entity ?? FALSE;
    if (empty($step_by_step_overview_node)) {
      return;
    }
    try {
      $has_ref_to_this_step_by_step_page = array_filter($step_by_step_overview_node->localgov_step_by_step_pages->referencedEntities(), function (EntityInterface $page_node) use ($step_by_step_page_nid): bool {
          return $page_node->id() === $step_by_step_page_nid;
      });
      if ($has_ref_to_this_step_by_step_page) {
        return;
      }
      $step_by_step_overview_node->localgov_step_by_step_pages->appendItem($step_by_step_page_nid);
      $step_by_step_overview_node->save();
    }
    catch (\Exception $e) {
      \Drupal::service('logger.factory')->get('localgov-step-by-step')->error($e->getMessage());
    }
  }

  /**
   * Implements hook_preprocess_views_view_list().
   *
   * Marks the rows corresponding to the current, previous, and next nodes.
   */
  #[Hook('preprocess_views_view_list')]
  public function preprocessViewsViewList(array &$variables) {
    $view = $variables['view'];
    $view_id = $view->id();
    $view_display_id = $view->current_display;
    $is_step_by_step_nav = $view_id === 'localgov_step_by_step_navigation';
    $is_step_by_step_nav_block = $view_display_id === 'steps';
    $is_step_by_step_prev_next_block = $view_display_id === 'prev_next';
    $current_nid = $is_step_by_step_nav ? $view->args[0] : '';
    if ($is_step_by_step_nav && $is_step_by_step_prev_next_block) {
      _localgov_step_by_step_find_prev_next_steps($current_nid, $variables);
    }
    elseif ($is_step_by_step_nav && $is_step_by_step_nav_block) {
      _localgov_step_by_step_mark_current_step($current_nid, $variables);
    }
    if ($is_step_by_step_nav) {
      $variables['view']->element['#attached']['library'][] = 'localgov_step_by_step/step-by-step-nav';
    }
  }

  /**
   * Implements hook_modules_installed().
   */
  #[Hook('modules_installed')]
  public function modulesInstalled($modules) {
    $services = in_array('localgov_services_navigation', $modules, TRUE);
    $topics = in_array('localgov_topics', $modules, TRUE);
    if ($services) {
      \Drupal::service('config.installer')->installOptionalConfig(NULL, [
        'config' => 'field.storage.node.localgov_services_parent',
      ]);
    }
    if ($topics) {
      \Drupal::service('config.installer')->installOptionalConfig(NULL, [
        'config' => 'field.storage.node.localgov_topic_classified',
      ]);
    }
    if ($services || $topics) {
      localgov_step_by_step_optional_fields_settings($services, $topics);
    }
  }

}
