# LocalGov Directories Facets Guard

Protects Directory channel pages against bots that crawl every combination of
directory facets.

## The problem

Every facet combination on a Directory channel is its own URL. None of them
is in the page cache, so each request runs a search and renders the page.
A channel with a few dozen facets has more combinations than any cache can
hold, and a bot that ignores `robots.txt` and `rel="nofollow"` can take the
site down by walking through them. Facets also accepts any value in the
query string and silently ignores what it does not recognise, so a bot can
invent an unlimited number of uncached URLs.

## What the module fixes

- **Rejects too many facet filters.** Requests with more active facet
  filters than the configured limit get `HTTP 400`.
- **Rejects invented facet filters.** Filters the facets module could not
  have built (malformed values, unknown facet URL alias, non-numeric
  directory facet ID) get `HTTP 400`.
- **Rejects overlong search texts.** Values for `search` and
  `search_api_fulltext` longer than the configured limit get `HTTP 400`.
- **Gives every facet combination one URL.** The same filters in another
  order or spelling (`f[]`, gaps in the numbering, duplicates, unencoded
  brackets) get `HTTP 301` to the spelling the facets module itself
  generates.
- **Does all of this before Drupal starts.** The checks run in an HTTP
  middleware (priority 260, before `page_cache` at 200) that reads only the
  query string. Rejected requests get a small self-contained HTML page with
  links back, rendered without bootstrapping Drupal, so it is English only.
- **Keeps visitors within the same limits.** On the Directory channel page,
  ticking one facet too many is cancelled and a message is shown next to the
  filters, and the search field gets a `maxlength`. Visitors never see the
  error page.
- **Keeps filtered listings out of the page cache.** Pages with more than
  one active facet or a search text are rarely requested twice, so they are
  not stored.

The filter keys (`f` by default) and facet URL aliases are read from the
site's facet and facet source configuration. Only facets whose source uses
the query string URL processor are guarded.

## Settings

Configuration > Search and metadata > Directories facets guard
(`/admin/config/search/directories-facets-guard`):

- Maximum number of active facet filters (default 5).
- Maximum length of the search text (default 50 characters).

The limits apply to the whole site and take effect immediately. They can be
overridden per environment in `settings.php`:

```php
$config['localgov_directories_facets_guard.settings']['max_active'] = 3;
$config['localgov_directories_facets_guard.settings']['max_search_length'] = 40;
```

## Recommended: no crawlable facet links

The facets checkbox widget renders a hidden link for every option, which is
how crawlers find every combination. The facets merge request
[!411](https://git.drupalcode.org/project/facets/-/merge_requests/411)
([#3504573](https://www.drupal.org/project/facets/issues/3504573)) adds a
"Use span elements instead of links" option to the checkbox widget. Enable it
on the directory facets. This module does not require it, but the two work
best together.

## Not covered

Bots that generate valid combinations within the limit, or random short
search phrases, are a rate-limiting problem. Handle them at the web server,
ingress or WAF.
