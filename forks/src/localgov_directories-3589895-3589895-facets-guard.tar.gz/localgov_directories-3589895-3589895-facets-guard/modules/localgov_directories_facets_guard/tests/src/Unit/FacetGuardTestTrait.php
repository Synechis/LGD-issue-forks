<?php

declare(strict_types=1);

namespace Drupal\Tests\localgov_directories_facets_guard\Unit;

use Drupal\Core\Config\MemoryStorage;
use Drupal\Core\Config\StorageInterface;
use Symfony\Component\HttpFoundation\Request;

/**
 * Shared fixtures for the facets guard unit tests.
 */
trait FacetGuardTestTrait {

  /**
   * Builds a config storage with a directory facet and a news date facet.
   *
   * @param string|null $directory_filter_key
   *   The filter key of the directory facet source, or NULL for the default.
   */
  protected function configStorage(?string $directory_filter_key = NULL): StorageInterface {
    $storage = new MemoryStorage();
    $storage->write('localgov_directories_facets_guard.settings', [
      'max_active'        => 5,
      'max_search_length' => 50,
    ]);
    $storage->write('facets.facet.localgov_directories_facets', [
      'url_alias'        => 'localgov_directories_facets',
      'field_identifier' => 'localgov_directory_facets_filter',
      'facet_source_id'  => 'search_api:views_embed__localgov_directory_channel__node_embed',
    ]);
    $storage->write('facets.facet_source.search_api__views_embed__localgov_directory_channel__node_embed', [
      'filter_key'    => $directory_filter_key,
      'url_processor' => 'query_string',
    ]);
    // A facet source without its own config falls back on the "f" key.
    $storage->write('facets.facet.localgov_news_date', [
      'url_alias'        => 'date',
      'field_identifier' => 'localgov_news_date',
      'facet_source_id'  => 'search_api:views_page__localgov_news_search__page_search_news',
    ]);
    return $storage;
  }

  /**
   * Builds a request with the query string spelled exactly as given.
   */
  protected function request(string $query_string, string $path = '/channel'): Request {
    $request = Request::create($path . ($query_string === '' ? '' : '?' . $query_string));
    $request->server->set('QUERY_STRING', $query_string);
    return $request;
  }

}
