<?php

declare(strict_types=1);

namespace Drupal\Tests\localgov_directories_facets_guard\Unit;

use Drupal\Core\Config\StorageInterface;
use Drupal\localgov_directories_facets_guard\FacetDefinitions;
use Drupal\localgov_directories_facets_guard\StackMiddleware\FacetQueryGuard;
use Drupal\Tests\UnitTestCase;
use PHPUnit\Framework\Attributes\CoversClass;
use PHPUnit\Framework\Attributes\DataProvider;
use PHPUnit\Framework\Attributes\Group;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\HttpKernel\HttpKernelInterface;

/**
 * Tests the facet and search query string guard.
 */
#[CoversClass(FacetQueryGuard::class)]
#[Group('localgov_directories_facets_guard')]
final class FacetQueryGuardTest extends UnitTestCase {

  use FacetGuardTestTrait;

  /**
   * Directory facet filter prefix, encoded as the facets module encodes it.
   */
  private const F = 'localgov_directories_facets%3A';

  /**
   * Requests that are passed on to Drupal unchanged.
   */
  public static function passedProvider(): array {
    $f = self::F;
    return [
      'no query string'       => [''],
      'unrelated parameter'   => ['utm_source=x'],
      'one facet'             => ["f%5B0%5D={$f}99"],
      'five facets'           => ["f%5B0%5D={$f}1&f%5B1%5D={$f}2&f%5B2%5D={$f}3&f%5B3%5D={$f}4&f%5B4%5D={$f}5"],
      'facets sort naturally' => ["f%5B0%5D={$f}3&f%5B1%5D={$f}20"],
      'facet and search'      => ["f%5B0%5D={$f}99&search=hello+world"],
      'search before facets'  => ["search=hello&f%5B0%5D={$f}99"],
      'non-directory facet'   => ['f%5B0%5D=date%3A2024-05'],
      'search at the limit'   => ['search=' . str_repeat('a', 50)],
    ];
  }

  /**
   * Tests requests that are passed on to Drupal.
   */
  #[DataProvider('passedProvider')]
  public function testPassed(string $query_string): void {
    $response = $this->guard()->handle($this->request($query_string));
    $this->assertSame(Response::HTTP_OK, $response->getStatusCode());
    $this->assertSame('passed', $response->getContent());
  }

  /**
   * Requests that are rejected, with the heading of the error page.
   */
  public static function rejectedProvider(): array {
    $f = self::F;
    return [
      'six facets'                  => [
        "f%5B0%5D={$f}1&f%5B1%5D={$f}2&f%5B2%5D={$f}3&f%5B3%5D={$f}4&f%5B4%5D={$f}5&f%5B5%5D={$f}6",
        'Too many filters selected',
      ],
      'f as a string'               => ["f={$f}1", 'This link is not valid'],
      'nested array'                => ["f%5B0%5D%5B%5D={$f}1", 'This link is not valid'],
      'empty value'                 => ['f%5B0%5D=', 'This link is not valid'],
      'value without alias'         => ['f%5B0%5D=random', 'This link is not valid'],
      'unknown alias'               => ['f%5B0%5D=unknown%3A1', 'This link is not valid'],
      'non-numeric directory facet' => ["f%5B0%5D={$f}abc", 'This link is not valid'],
      'disallowed characters'       => ['f%5B0%5D=date%3A2024%2F05', 'This link is not valid'],
      'search too long'             => ['search=' . str_repeat('a', 51), 'Search text is too long'],
      'fulltext search too long'    => ['search_api_fulltext=' . str_repeat('a', 51), 'Search text is too long'],
      'search as an array'          => ['search%5B%5D=x', 'This link is not valid'],
    ];
  }

  /**
   * Tests requests that are rejected before Drupal renders.
   */
  #[DataProvider('rejectedProvider')]
  public function testRejected(string $query_string, string $heading): void {
    $response = $this->guard()->handle($this->request($query_string));
    $this->assertSame(Response::HTTP_BAD_REQUEST, $response->getStatusCode());
    $this->assertStringContainsString('<h1>' . $heading . '</h1>', (string) $response->getContent());
    $this->assertSame('noindex', $response->headers->get('X-Robots-Tag'));
  }

  /**
   * Requests redirected to the facets module's spelling of the same filters.
   */
  public static function redirectedProvider(): array {
    $f = self::F;
    $canonical = "f%5B0%5D={$f}99&f%5B1%5D={$f}148";
    return [
      'reversed order'    => ["f%5B0%5D={$f}148&f%5B1%5D={$f}99", $canonical],
      'gaps in numbering' => ["f%5B3%5D={$f}99&f%5B7%5D={$f}148", $canonical],
      'unnumbered'        => ["f%5B%5D={$f}99&f%5B%5D={$f}148", $canonical],
      'unencoded'         => ['f[0]=localgov_directories_facets:99&f[1]=localgov_directories_facets:148', $canonical],
      'duplicates'        => ["f%5B0%5D={$f}99&f%5B1%5D={$f}99", "f%5B0%5D={$f}99"],
      'other params kept' => ["search=a+b&f%5B0%5D={$f}148&f%5B1%5D={$f}99&page=1", "{$canonical}&search=a+b&page=1"],
    ];
  }

  /**
   * Tests that other spellings redirect to one URL per combination.
   */
  #[DataProvider('redirectedProvider')]
  public function testRedirected(string $query_string, string $expected): void {
    $response = $this->guard()->handle($this->request($query_string));
    $this->assertSame(Response::HTTP_MOVED_PERMANENTLY, $response->getStatusCode());
    $this->assertSame('/channel?' . $expected, $response->headers->get('Location'));
  }

  /**
   * Tests that a facet source's own filter key is guarded too.
   */
  public function testConfiguredFilterKey(): void {
    $guard = $this->guard($this->configStorage('filter'));
    $f = self::F;

    $this->assertSame(Response::HTTP_OK, $guard->handle($this->request("filter%5B0%5D={$f}99"))->getStatusCode());
    $this->assertSame(Response::HTTP_BAD_REQUEST, $guard->handle($this->request('filter%5B0%5D=random'))->getStatusCode());

    $response = $guard->handle($this->request("filter%5B0%5D={$f}148&filter%5B1%5D={$f}99"));
    $this->assertSame("/channel?filter%5B0%5D={$f}99&filter%5B1%5D={$f}148", $response->headers->get('Location'));

    // The limit counts the filters of all keys together.
    $too_many = "f%5B0%5D=date%3Aa&f%5B1%5D=date%3Ab&f%5B2%5D=date%3Ac&filter%5B0%5D={$f}1&filter%5B1%5D={$f}2&filter%5B2%5D={$f}3";
    $this->assertSame(Response::HTTP_BAD_REQUEST, $guard->handle($this->request($too_many))->getStatusCode());
  }

  /**
   * Tests that settings.php overrides take precedence over stored config.
   */
  public function testSettingsOverride(): void {
    $f = self::F;
    $GLOBALS['config']['localgov_directories_facets_guard.settings']['max_active'] = 1;
    try {
      $response = $this->guard()->handle($this->request("f%5B0%5D={$f}1&f%5B1%5D={$f}2"));
    }
    finally {
      unset($GLOBALS['config']['localgov_directories_facets_guard.settings']);
    }
    $this->assertSame(Response::HTTP_BAD_REQUEST, $response->getStatusCode());
  }

  /**
   * Tests that missing or zero limits fall back on 5 facets and 50 characters.
   */
  public function testDefaultLimits(): void {
    $f = self::F;
    $five = "f%5B0%5D={$f}1&f%5B1%5D={$f}2&f%5B2%5D={$f}3&f%5B3%5D={$f}4&f%5B4%5D={$f}5";
    foreach ([NULL, ['max_active' => 0, 'max_search_length' => 0]] as $settings) {
      $storage = $this->configStorage();
      $settings === NULL
        ? $storage->delete('localgov_directories_facets_guard.settings')
        : $storage->write('localgov_directories_facets_guard.settings', $settings);
      $guard = $this->guard($storage);

      $this->assertSame(Response::HTTP_OK, $guard->handle($this->request($five))->getStatusCode());
      $this->assertSame(Response::HTTP_BAD_REQUEST, $guard->handle($this->request($five . "&f%5B5%5D={$f}6"))->getStatusCode());
      $this->assertSame(Response::HTTP_OK, $guard->handle($this->request('search=' . str_repeat('a', 50)))->getStatusCode());
      $this->assertSame(Response::HTTP_BAD_REQUEST, $guard->handle($this->request('search=' . str_repeat('a', 51)))->getStatusCode());
    }
  }

  /**
   * Tests that the redirect cannot leave the site.
   */
  public function testRedirectStaysOnSite(): void {
    $query_string = 'f%5B0%5D=' . self::F . '148&f%5B1%5D=' . self::F . '99';
    $request      = $this->request($query_string);
    // A web server passes "//host/path" through as the path.
    $request->server->set('REQUEST_URI', '//evil.example/x?' . $query_string);
    $response = $this->guard()->handle($request);
    $this->assertStringStartsWith('/evil.example/x?', (string) $response->headers->get('Location'));
  }

  /**
   * Tests that "Go back" only links to http(s) pages on the same site.
   */
  public function testGoBackLink(): void {
    $query_string = 'f%5B0%5D=random';
    foreach ([
      'http://localhost/channel?a=1' => 'http://localhost/channel?a=1',
      'https://evil.example/x'       => '/channel',
      'javascript://localhost/%0a1'  => '/channel',
      ''                             => '/channel',
    ] as $referer => $expected) {
      $request = $this->request($query_string);
      $request->headers->set('referer', $referer);
      $content = (string) $this->guard()->handle($request)->getContent();
      $this->assertStringContainsString('<a class="primary" href="' . htmlspecialchars($expected, ENT_QUOTES) . '">', $content, $referer);
    }
  }

  /**
   * Tests that sub-requests are passed on untouched.
   */
  public function testSubRequest(): void {
    $response = $this->guard()->handle($this->request('f%5B0%5D=random'), HttpKernelInterface::SUB_REQUEST);
    $this->assertSame('passed', $response->getContent());
  }

  /**
   * Builds the guard around a kernel that answers "passed".
   */
  private function guard(?StorageInterface $storage = NULL): FacetQueryGuard {
    $storage ??= $this->configStorage();
    $kernel = new class() implements HttpKernelInterface {

      /**
       * {@inheritdoc}
       */
      public function handle(Request $request, int $type = self::MAIN_REQUEST, bool $catch = TRUE): Response {
        return new Response('passed');
      }

    };
    return new FacetQueryGuard($kernel, $storage, new FacetDefinitions($storage));
  }

}
