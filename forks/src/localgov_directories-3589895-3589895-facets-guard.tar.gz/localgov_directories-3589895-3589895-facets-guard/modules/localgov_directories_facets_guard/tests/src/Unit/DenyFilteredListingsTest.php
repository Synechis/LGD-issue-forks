<?php

declare(strict_types=1);

namespace Drupal\Tests\localgov_directories_facets_guard\Unit;

use Drupal\Core\PageCache\RequestPolicyInterface;
use Drupal\localgov_directories_facets_guard\FacetDefinitions;
use Drupal\localgov_directories_facets_guard\PageCache\DenyFilteredListings;
use Drupal\Tests\UnitTestCase;
use PHPUnit\Framework\Attributes\CoversClass;
use PHPUnit\Framework\Attributes\DataProvider;
use PHPUnit\Framework\Attributes\Group;

/**
 * Tests which listings are kept out of the page cache.
 */
#[CoversClass(DenyFilteredListings::class)]
#[Group('localgov_directories_facets_guard')]
final class DenyFilteredListingsTest extends UnitTestCase {

  use FacetGuardTestTrait;

  /**
   * Query strings and whether the page cache is denied for them.
   */
  public static function provider(): array {
    $f = 'localgov_directories_facets%3A';
    return [
      'no query string'  => ['', FALSE],
      'one facet'        => ["f%5B0%5D={$f}1", FALSE],
      'two facets'       => ["f%5B0%5D={$f}1&f%5B1%5D={$f}2", TRUE],
      'empty search'     => ['search=', FALSE],
      'search'           => ['search=a', TRUE],
      'fulltext search'  => ['search_api_fulltext=a', TRUE],
      'unrelated param'  => ['utm_source=x', FALSE],
      'facet keys added' => ["f%5B0%5D=date%3Aa&filter%5B0%5D={$f}1", TRUE],
    ];
  }

  /**
   * Tests the page cache policy.
   */
  #[DataProvider('provider')]
  public function testCheck(string $query_string, bool $denied): void {
    $policy = new DenyFilteredListings(new FacetDefinitions($this->configStorage('filter')));
    $this->assertSame($denied ? RequestPolicyInterface::DENY : NULL, $policy->check($this->request($query_string)));
  }

}
