<?php

declare(strict_types=1);

namespace Drupal\Tests\localgov_directories_facets_guard\Unit;

use Drupal\localgov_directories_facets_guard\FacetDefinitions;
use Drupal\Tests\UnitTestCase;
use PHPUnit\Framework\Attributes\CoversClass;
use PHPUnit\Framework\Attributes\Group;

/**
 * Tests reading filter keys and URL aliases from facet configuration.
 */
#[CoversClass(FacetDefinitions::class)]
#[Group('localgov_directories_facets_guard')]
final class FacetDefinitionsTest extends UnitTestCase {

  use FacetGuardTestTrait;

  /**
   * Tests that facet sources without a filter key use "f".
   */
  public function testDefaultFilterKey(): void {
    $definitions = new FacetDefinitions($this->configStorage());
    $this->assertSame(['f'], $definitions->filterKeys());
    $this->assertSame([
      'localgov_directories_facets' => ['localgov_directory_facets_filter'],
      'date'                        => ['localgov_news_date'],
    ], $definitions->fieldsByAlias('f'));
  }

  /**
   * Tests that a facet source's own filter key is used for its facets.
   */
  public function testConfiguredFilterKey(): void {
    $definitions = new FacetDefinitions($this->configStorage('filter'));
    $this->assertEqualsCanonicalizing(['f', 'filter'], $definitions->filterKeys());
    $this->assertSame(['localgov_directories_facets' => ['localgov_directory_facets_filter']], $definitions->fieldsByAlias('filter'));
    $this->assertSame(['date' => ['localgov_news_date']], $definitions->fieldsByAlias('f'));
  }

  /**
   * Tests that facets whose source does not use the query string are ignored.
   */
  public function testOtherUrlProcessorsIgnored(): void {
    $storage = $this->configStorage();
    $storage->write('facets.facet_source.search_api__views_embed__localgov_directory_channel__node_embed', [
      'filter_key'    => NULL,
      'url_processor' => 'facets_pretty_paths',
    ]);
    $definitions = new FacetDefinitions($storage);
    $this->assertSame(['date' => ['localgov_news_date']], $definitions->fieldsByAlias('f'));
  }

}
