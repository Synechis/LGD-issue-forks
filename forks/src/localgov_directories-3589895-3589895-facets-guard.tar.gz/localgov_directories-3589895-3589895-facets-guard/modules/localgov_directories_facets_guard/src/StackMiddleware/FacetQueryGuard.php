<?php

declare(strict_types=1);

namespace Drupal\localgov_directories_facets_guard\StackMiddleware;

use Drupal\Component\Utility\Html;
use Drupal\Core\Config\StorageInterface;
use Drupal\localgov_directories_facets_guard\FacetDefinitions;
use Symfony\Component\HttpFoundation\RedirectResponse;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\HttpKernel\HttpKernelInterface;

/**
 * Guards facet and search query strings before the page cache.
 *
 * Bots crawl every combination of facets, and each one is a cache miss that
 * runs a search and renders the page. Malformed or too many facet filters and
 * overlong search texts are rejected, and permutations of the same filters
 * are redirected to one URL.
 */
final class FacetQueryGuard implements HttpKernelInterface {

  /**
   * Field of the directory facets, whose values are always facet entity IDs.
   */
  private const DIRECTORY_FACETS_FIELD = 'localgov_directory_facets_filter';

  /**
   * Full text search keys of the directory channel view displays.
   */
  public const SEARCH_KEYS = ['search', 'search_api_fulltext'];

  /**
   * The configuration object holding the limits.
   */
  public const CONFIG_NAME = 'localgov_directories_facets_guard.settings';

  /**
   * Limits used when the configuration is missing or not a positive number.
   */
  public const DEFAULT_LIMITS = [
    'max_active'        => 5,
    'max_search_length' => 50,
  ];

  public function __construct(
    private readonly HttpKernelInterface $httpKernel,
    private readonly StorageInterface $configStorage,
    private readonly FacetDefinitions $facetDefinitions,
  ) {}

  /**
   * {@inheritdoc}
   */
  public function handle(Request $request, int $type = self::MAIN_REQUEST, bool $catch = TRUE): Response {
    $query = $request->query->all();
    if ($type !== self::MAIN_REQUEST || $query === []) {
      return $this->httpKernel->handle($request, $type, $catch);
    }
    $filter_keys = array_values(array_intersect($this->facetDefinitions->filterKeys(), array_keys($query)));
    $search_keys = array_intersect(self::SEARCH_KEYS, array_keys($query));
    if ($filter_keys === [] && $search_keys === []) {
      return $this->httpKernel->handle($request, $type, $catch);
    }

    // Collapse leading slashes so "//host" can't become an external URL.
    $path   = '/' . ltrim($request->getBaseUrl() . $request->getPathInfo(), '/\\');
    $limits = $this->limits();

    $max_length = $limits['max_search_length'];
    foreach ($search_keys as $key) {
      if (!is_string($query[$key])) {
        return $this->reject($request, $path, 'This link is not valid', 'The search in this link could not be read.');
      }
      if (mb_strlen($query[$key]) > $max_length) {
        return $this->reject($request, $path, 'Search text is too long', sprintf('Search text can be at most %d characters. Please shorten it and try again.', $max_length));
      }
    }

    if ($filter_keys === []) {
      return $this->httpKernel->handle($request, $type, $catch);
    }

    $canonical = [];
    foreach ($filter_keys as $key) {
      if (!$this->isValid($key, $query[$key])) {
        return $this->reject($request, $path, 'This link is not valid', 'The filters in this link could not be read.');
      }
      // Same order as the facets query string URL processor builds its links.
      $canonical[$key] = array_values(array_unique($query[$key]));
      sort($canonical[$key], SORT_NATURAL);
    }

    $max_active = $limits['max_active'];
    if (count($canonical, COUNT_RECURSIVE) - count($canonical) > $max_active) {
      return $this->reject($request, $path, 'Too many filters selected', sprintf('You can combine up to %d filters at a time. Please remove some filters and try again.', $max_active));
    }

    // Spell the filters exactly as the facets query string URL processor
    // does (sorted, numbered from 0, encoded), so each combination has one
    // URL. The raw query string also catches "f[]" and unencoded brackets,
    // which PHP parses to the same array.
    $query_string = (string) $request->server->get('QUERY_STRING', '');
    [$raw_filters, $raw_other] = $this->splitRawQuery($query_string, $filter_keys);
    $expected = [];
    $redirect = FALSE;
    foreach ($canonical as $key => $filters) {
      $pairs = [];
      foreach ($filters as $delta => $filter) {
        $pairs[] = rawurlencode($key) . '%5B' . $delta . '%5D=' . rawurlencode($filter);
      }
      $redirect = $redirect || $filters !== $query[$key] || ($query_string !== '' && ($raw_filters[$key] ?? []) !== $pairs);
      $expected = array_merge($expected, $pairs);
    }
    if ($redirect) {
      return new RedirectResponse($path . '?' . implode('&', array_merge($expected, $raw_other)), Response::HTTP_MOVED_PERMANENTLY);
    }

    return $this->httpKernel->handle($request, $type, $catch);
  }

  /**
   * Splits a raw query string into facet filter pairs and the other pairs.
   *
   * @param string $query_string
   *   The raw query string.
   * @param string[] $filter_keys
   *   The facet filter keys present in the query.
   *
   * @return array{0: array<string, string[]>, 1: string[]}
   *   The raw "f[...]=..." pairs keyed by filter key, and the remaining pairs,
   *   both in their original order and spelling.
   */
  private function splitRawQuery(string $query_string, array $filter_keys): array {
    $filters = $other = [];
    foreach (explode('&', $query_string) as $pair) {
      if ($pair === '') {
        continue;
      }
      $name = rawurldecode(strtok($pair, '='));
      $key  = strtok($name, '[');
      if (in_array($key, $filter_keys, TRUE)) {
        $filters[$key][] = $pair;
      }
      else {
        $other[] = $pair;
      }
    }
    return [$filters, $other];
  }

  /**
   * Returns the configured limits, with settings.php overrides applied.
   *
   * This runs before the request is on the request stack, so the config
   * factory cannot be used: config overriders that depend on the request,
   * such as the domain module's on LocalGov Microsites or language
   * negotiation, would fatal. The limits are global, so they are read from
   * the (cached) config storage, and $config overrides from settings.php
   * are applied the way the config factory applies them.
   *
   * @return array{max_active: int, max_search_length: int}
   *   The limits.
   */
  private function limits(): array {
    $data = ($GLOBALS['config'][self::CONFIG_NAME] ?? []) + ($this->configStorage->read(self::CONFIG_NAME) ?: []);
    return self::validLimits($data);
  }

  /**
   * Returns the limits, falling back on the defaults for invalid values.
   *
   * A missing or zero limit would otherwise reject every filtered listing.
   *
   * @param array $data
   *   Configuration data with "max_active" and "max_search_length".
   *
   * @return array{max_active: int, max_search_length: int}
   *   The limits.
   */
  public static function validLimits(array $data): array {
    $limits = [];
    foreach (self::DEFAULT_LIMITS as $key => $default) {
      $value        = (int) ($data[$key] ?? 0);
      $limits[$key] = $value > 0 ? $value : $default;
    }
    return $limits;
  }

  /**
   * Checks that the filters are values the facets module could have built.
   *
   * Each filter must be "<url alias>:<value>" for an existing facet. Facets
   * silently ignores anything else and still renders the page, so random
   * values would otherwise give bots unlimited uncached URLs.
   */
  private function isValid(string $filter_key, mixed $filters): bool {
    if (!is_array($filters) || $filters === []) {
      return FALSE;
    }
    $fields = $this->facetDefinitions->fieldsByAlias($filter_key);
    foreach ($filters as $filter) {
      if (!is_string($filter) || !preg_match('/^([A-Za-z0-9_]+):([A-Za-z0-9_.\-]{1,64})$/', $filter, $match)) {
        return FALSE;
      }
      [, $alias, $value] = $match;
      if (!isset($fields[$alias])) {
        return FALSE;
      }
      if (in_array(self::DIRECTORY_FACETS_FIELD, $fields[$alias], TRUE) && !ctype_digit($value)) {
        return FALSE;
      }
    }
    return TRUE;
  }

  /**
   * Builds a cheap, self-contained page for rejected facet requests.
   *
   * Visitors can end up here by ticking one checkbox too many, so the page
   * explains why and links back, without bootstrapping Drupal to render it.
   */
  private function reject(Request $request, string $path, string $title, string $message): Response {
    // Only go back to an http(s) page on the same site.
    $referer = (string) $request->headers->get('referer', '');
    $same    = in_array(parse_url($referer, PHP_URL_SCHEME), ['http', 'https'], TRUE)
      && parse_url($referer, PHP_URL_HOST) === $request->getHost();
    $back    = $same ? $referer : $path;

    $html = <<<'HTML'
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="robots" content="noindex">
<title>%1$s</title>
<style>
body{margin:0;font-family:system-ui,-apple-system,"Segoe UI",Roboto,sans-serif;color:#1f2937;background:#f9fafb}
main{max-width:32rem;margin:15vh auto;padding:2rem;background:#fff;border:1px solid #e5e7eb;border-radius:.75rem}
h1{margin:0 0 .75rem;font-size:1.5rem}
p{margin:0 0 1.5rem;line-height:1.5}
a{display:inline-block;margin:0 .5rem .5rem 0;padding:.6rem 1.2rem;border-radius:9999px;border:1px solid #1d4ed8;text-decoration:none;color:#1d4ed8}
a.primary{background:#1d4ed8;color:#fff}
a:focus-visible{outline:3px solid #f59e0b;outline-offset:2px}
</style>
</head>
<body>
<main>
<h1>%1$s</h1>
<p>%2$s</p>
<a class="primary" href="%3$s">Go back</a><a href="%4$s">Show all results</a>
</main>
</body>
</html>
HTML;

    return new Response(
      sprintf($html, Html::escape($title), Html::escape($message), Html::escape($back), Html::escape($path)),
      Response::HTTP_BAD_REQUEST,
      [
        'Content-Type'  => 'text/html; charset=UTF-8',
        'Cache-Control' => 'no-store',
        'X-Robots-Tag'  => 'noindex',
      ],
    );
  }

}
