<?php

declare(strict_types=1);

namespace Drupal\localgov_directories_facets_guard\Form;

use Drupal\Core\Form\ConfigFormBase;
use Drupal\Core\Form\FormStateInterface;
use Drupal\localgov_directories_facets_guard\StackMiddleware\FacetQueryGuard;

/**
 * Settings for the limits the directories facets guard enforces.
 */
final class SettingsForm extends ConfigFormBase {

  /**
   * {@inheritdoc}
   */
  public function getFormId(): string {
    return 'localgov_directories_facets_guard_settings';
  }

  /**
   * {@inheritdoc}
   */
  protected function getEditableConfigNames(): array {
    return [FacetQueryGuard::CONFIG_NAME];
  }

  /**
   * {@inheritdoc}
   */
  public function buildForm(array $form, FormStateInterface $form_state): array {
    $form['intro'] = [
      '#markup' => '<p>' . $this->t('These limits apply to the whole site. Requests over the limits are rejected before Drupal renders the page, and the facet and search fields keep visitors within them.') . '</p>',
    ];

    $form['max_active'] = [
      '#type'          => 'number',
      '#title'         => $this->t('Maximum number of active facet filters'),
      '#description'   => $this->t('Visitors cannot tick more facets than this, and URLs with more are rejected.'),
      '#min'           => 1,
      '#required'      => TRUE,
      '#config_target' => FacetQueryGuard::CONFIG_NAME . ':max_active',
    ];

    $form['max_search_length'] = [
      '#type'          => 'number',
      '#title'         => $this->t('Maximum length of the search text'),
      '#description'   => $this->t('In characters. The search field accepts no more than this, and longer searches are rejected.'),
      '#min'           => 1,
      '#required'      => TRUE,
      '#config_target' => FacetQueryGuard::CONFIG_NAME . ':max_search_length',
    ];

    return parent::buildForm($form, $form_state);
  }

}
