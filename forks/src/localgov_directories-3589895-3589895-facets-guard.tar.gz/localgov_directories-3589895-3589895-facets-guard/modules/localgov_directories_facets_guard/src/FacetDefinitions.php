<?php

declare(strict_types=1);

namespace Drupal\localgov_directories_facets_guard;

use Drupal\Core\Config\StorageInterface;

/**
 * Knows which query string keys and URL aliases the site's facets use.
 *
 * Read from the (cached) config storage rather than the entity API, because
 * it is used before the request is on the request stack, so the config
 * factory cannot be used: config overriders that depend on the request, such
 * as the domain module's on LocalGov Microsites or language negotiation,
 * would fatal.
 */
final class FacetDefinitions {

  /**
   * The filter key the facets query string URL processor falls back on.
   */
  private const DEFAULT_FILTER_KEY = 'f';

  /**
   * Facet field identifiers by URL alias, keyed by filter key.
   *
   * @var array<string, array<string, string[]>>|null
   */
  private ?array $aliases = NULL;

  public function __construct(
    private readonly StorageInterface $configStorage,
  ) {}

  /**
   * Returns the query string keys facets use for their filters.
   *
   * @return string[]
   *   Filter keys, such as "f".
   */
  public function filterKeys(): array {
    return array_keys($this->aliases());
  }

  /**
   * Returns the field identifiers of the facets using a filter key.
   *
   * @return array<string, string[]>
   *   Field identifiers keyed by facet URL alias.
   */
  public function fieldsByAlias(string $filter_key): array {
    return $this->aliases()[$filter_key] ?? [];
  }

  /**
   * Builds the facet field identifiers by URL alias and filter key.
   *
   * Only facets whose source uses the query string URL processor are
   * included; other URL processors do not put filters in the query string.
   *
   * @return array<string, array<string, string[]>>
   *   Field identifiers keyed by filter key and facet URL alias.
   */
  private function aliases(): array {
    if ($this->aliases !== NULL) {
      return $this->aliases;
    }

    $facets       = $this->configStorage->readMultiple($this->configStorage->listAll('facets.facet.'));
    $source_names = [];
    foreach ($facets as $facet) {
      $source_names[] = $this->sourceConfigName((string) ($facet['facet_source_id'] ?? ''));
    }
    $sources = $this->configStorage->readMultiple(array_unique($source_names));

    $this->aliases = [];
    foreach ($facets as $facet) {
      $source = $sources[$this->sourceConfigName((string) ($facet['facet_source_id'] ?? ''))] ?? [];
      if (($source['url_processor'] ?? 'query_string') !== 'query_string' || empty($facet['url_alias'])) {
        continue;
      }
      $key = ($source['filter_key'] ?? '') ?: self::DEFAULT_FILTER_KEY;
      $this->aliases[$key][$facet['url_alias']][] = (string) ($facet['field_identifier'] ?? '');
    }

    return $this->aliases;
  }

  /**
   * Returns the config name of a facet source, as the facets module names it.
   */
  private function sourceConfigName(string $source_id): string {
    return 'facets.facet_source.' . str_replace(':', '__', $source_id);
  }

}
