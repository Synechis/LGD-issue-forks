<?php

declare(strict_types=1);

namespace Drupal\localgov_directories_facets_guard\PageCache;

use Drupal\Core\PageCache\RequestPolicyInterface;
use Drupal\localgov_directories_facets_guard\FacetDefinitions;
use Drupal\localgov_directories_facets_guard\StackMiddleware\FacetQueryGuard;
use Symfony\Component\HttpFoundation\Request;

/**
 * Keeps searched and multi-facet listings out of the page cache.
 *
 * Search texts and facet combinations are rarely requested twice, so caching
 * them only fills the cache backend with entries that are never read.
 */
final class DenyFilteredListings implements RequestPolicyInterface {

  public function __construct(
    private readonly FacetDefinitions $facetDefinitions,
  ) {}

  /**
   * {@inheritdoc}
   */
  public function check(Request $request): ?string {
    $query = $request->query->all();
    if ($query === []) {
      return NULL;
    }

    foreach (FacetQueryGuard::SEARCH_KEYS as $key) {
      if (($query[$key] ?? '') !== '') {
        return self::DENY;
      }
    }

    $active = 0;
    foreach ($this->facetDefinitions->filterKeys() as $key) {
      $active += is_array($query[$key] ?? NULL) ? count($query[$key]) : 0;
    }

    return $active > 1 ? self::DENY : NULL;
  }

}
