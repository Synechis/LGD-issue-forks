<?php

declare(strict_types=1);

namespace Drupal\localgov_directories_facets_guard\Hook;

use Drupal\Core\Cache\CacheableMetadata;
use Drupal\Core\Config\ConfigFactoryInterface;
use Drupal\Core\Hook\Attribute\Hook;
use Drupal\facets\FacetInterface;
use Drupal\localgov_directories_facets_guard\FacetDefinitions;
use Drupal\localgov_directories_facets_guard\StackMiddleware\FacetQueryGuard;

/**
 * Hook implementations for localgov_directories_facets_guard.
 *
 * Keeps visitors within the limits FacetQueryGuard enforces, so they stay on
 * the page instead of landing on its error page.
 */
class DirectoriesFacetsGuardHooks {

  public function __construct(
    private readonly ConfigFactoryInterface $configFactory,
    private readonly FacetDefinitions $facetDefinitions,
  ) {}

  /**
   * Implements hook_preprocess_facets_item_list().
   */
  #[Hook('preprocess_facets_item_list')]
  public function preprocessFacetsItemList(array &$variables): void {
    $facet = $variables['facet'] ?? NULL;
    if ($facet instanceof FacetInterface && $facet->getWidget()['type'] === 'checkbox') {
      $this->attachLimits($variables);
    }
  }

  /**
   * Implements hook_preprocess_block().
   */
  #[Hook('preprocess_block')]
  public function preprocessBlock(array &$variables): void {
    if (($variables['plugin_id'] ?? '') === 'localgov_directories_channel_search_block') {
      $this->attachLimits($variables);
    }
  }

  /**
   * Attaches the limits and the script that applies them in the browser.
   */
  private function attachLimits(array &$variables): void {
    $config = $this->configFactory->get(FacetQueryGuard::CONFIG_NAME);
    $limits = FacetQueryGuard::validLimits($config->get() ?? []);

    $variables['#attached']['library'][] = 'localgov_directories_facets_guard/facet_limit';
    $variables['#attached']['drupalSettings']['localgovDirectoriesFacetsGuard'] = [
      'maxActive'       => $limits['max_active'],
      'maxSearchLength' => $limits['max_search_length'],
      'searchKeys'      => FacetQueryGuard::SEARCH_KEYS,
      'filterKeys'      => $this->facetDefinitions->filterKeys(),
    ];

    // Re-render cached pages when the limits change.
    CacheableMetadata::createFromRenderArray($variables)
      ->addCacheableDependency($config)
      ->applyTo($variables);
  }

}
