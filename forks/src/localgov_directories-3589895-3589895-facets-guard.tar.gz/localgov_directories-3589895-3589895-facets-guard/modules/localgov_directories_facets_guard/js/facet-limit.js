/**
 * @file
 * Keeps visitors within the facet and search limits the server accepts.
 *
 * The facets checkbox widget navigates as soon as a box changes. Ticking one
 * box too many would land the visitor on the FacetQueryGuard error page, so
 * the click is cancelled and a message is shown next to the filters instead.
 */
((Drupal, once) => {
  /**
   * Counts the facet filters in the current URL, as the server does.
   */
  function activeFilterCount(filterKeys) {
    let count = 0;
    new URLSearchParams(window.location.search).forEach((value, key) => {
      if (filterKeys.some((filterKey) => key.startsWith(`${filterKey}[`))) {
        count += 1;
      }
    });
    return count;
  }

  /**
   * Shows the limit message in front of the facet list that was clicked.
   */
  function showMessage(widget, max) {
    document
      .querySelectorAll('.directories-facets-guard-message')
      .forEach((message) => message.remove());

    const message = document.createElement('p');
    message.className = 'directories-facets-guard-message';
    message.setAttribute('role', 'status');
    widget.parentNode.insertBefore(message, widget);
    message.textContent = Drupal.t(
      'You can combine up to @max filters. Remove a filter to choose another.',
      { '@max': max },
    );
  }

  Drupal.behaviors.localgovDirectoriesFacetsGuard = {
    attach(context, settings) {
      const guard = settings.localgovDirectoriesFacetsGuard;
      if (!guard) {
        return;
      }

      // Longer search texts are rejected by the server.
      const searchInputs = guard.searchKeys
        .map((key) => `input[name="${key}"]`)
        .join(',');
      once('directories-facets-guard-search', searchInputs, context).forEach(
        (input) => {
          input.maxLength = guard.maxSearchLength;
        },
      );

      const max = guard.maxActive;
      once('directories-facets-guard', 'body', context).forEach(() => {
        // Capture phase, so this runs before the facets change handler.
        document.addEventListener(
          'click',
          (event) => {
            const checkbox =
              event.target instanceof HTMLInputElement &&
              event.target.closest('.js-facets-widget input.facets-checkbox');
            // The click has already toggled the box: only a newly ticked,
            // real facet (not "Show all") can push the count over the limit.
            if (
              !checkbox ||
              !checkbox.checked ||
              checkbox.value.endsWith(':reset_all') ||
              activeFilterCount(guard.filterKeys) < max
            ) {
              return;
            }

            // Cancelling the click unticks the box and suppresses its change
            // event, so the page does not navigate.
            event.preventDefault();
            showMessage(checkbox.closest('.js-facets-widget'), max);
          },
          { capture: true },
        );
      });
    },
  };
})(Drupal, once);
