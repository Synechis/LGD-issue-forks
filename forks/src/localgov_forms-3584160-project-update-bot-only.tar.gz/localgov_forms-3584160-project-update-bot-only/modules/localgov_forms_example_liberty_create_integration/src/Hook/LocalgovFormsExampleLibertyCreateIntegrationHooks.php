<?php

namespace Drupal\localgov_forms_example_liberty_create_integration\Hook;

use Drupal\webform\Plugin\WebformHandlerInterface;
use Drupal\Core\Render\BubbleableMetadata;
use Drupal\Core\Hook\Attribute\Hook;
use Drupal\Core\StringTranslation\StringTranslationTrait;

/**
 * Hook implementations for localgov_forms_example_liberty_create_integration.
 */
class LocalgovFormsExampleLibertyCreateIntegrationHooks {
  use StringTranslationTrait;

  /**
   * Implements hook_modules_installed().
   *
   * Whitelists the following environment variables:
   * - DRUPAL_LIBERTY_CREATE_API_AUTH_KEY
   * - DRUPAL_LIBERTY_CREATE_API_USERNAME
   * - DRUPAL_LIBERTY_CREATE_API_USER_KEY.
   */
  #[Hook('modules_installed')]
  public function modulesInstalled($modules, $is_syncing): void {
    if (!$is_syncing && in_array('token_environment', $modules, TRUE)) {
      $token_env_config = \Drupal::service('config.factory')->getEditable('token_environment.settings');
      $allowed_env_vars = $token_env_config->get('allowed_env_variables') ?? [];
      $allowed_env_vars[] = 'DRUPAL_LIBERTY_CREATE_API_AUTH_KEY';
      $token_env_config->set('allowed_env_variables', $allowed_env_vars)->save();
    }
  }

  /**
   * Implements hook_tokens_alter().
   *
   * Extracts the firstname and lastname from a Webform submission token value for
   * a fullname.  When the fullname comprises just one word, that's used for both
   * firstname and lastname.
   *
   * Example:
   * When the `[webform_submission:values:name:clear]` token has a value of
   * "Foo Bar",  `[webform_submission:values:name:extracted_firstname:clear]` will
   * resolve to "Foo" and
   * `[webform_submission:values:name:extracted_lastname:clear]` will resolve to
   * "Bar".
   */
  #[Hook('tokens_alter')]
  public function tokensAlter(array &$replacements, array $context, BubbleableMetadata $bubbleable_metadata): void {
    if ($context['type'] === 'webform_submission' && !empty($context['data']['webform_submission'])) {
      $firstname_extraction_tokens = array_filter($context['tokens'], fn($token) => strpos($token, ':extracted_firstname'));
      $lastname_extraction_tokens = array_filter($context['tokens'], fn($token) => strpos($token, ':extracted_lastname'));
      foreach ($firstname_extraction_tokens as $firstname_token) {
        $name_parts = explode(' ', $replacements[$firstname_token]);
        $replacements[$firstname_token] = current($name_parts);
      }
      foreach ($lastname_extraction_tokens as $lastname_token) {
        $name_parts_again = explode(' ', $replacements[$lastname_token]);
        $replacements[$lastname_token] = end($name_parts_again);
      }
    }
  }

  /**
   * Implements hook_token_info_alter().
   *
   * Declares the
   * `[webform_submission:values:element_key:file_details_for_liberty_create_api]`
   * pseudo-token.
   *
   * @see localgov_forms_example_liberty_create_integration_webform_handler_invoke_post_save_alter()
   * @see localgov_forms_example_liberty_create_integration_webform_handler_invoke_post_load_alter()
   */
  #[Hook('token_info_alter')]
  public function tokenInfoAlter(&$token_info): void {
    $token_info['tokens']['webform_submission']['values:?:file_details_for_liberty_create_api'] = [
      'name' => $this->t('File detail for Liberty Create API'),
      'description' => $this->t('Expands based on the number of uploaded files.  Replace question mark in the token name with machine id of a file element e.g. `[webform_submission:values:foo:file_details_for_liberty_create_api]`.  Available within the "Remote post" and "Async remote post" handlers\' "Completed custom data" settings only.'),
    ];
  }

  /**
   * Implements hook_webform_handler_invoke_METHOD_NAME_alter() for hook_webform_handler_invoke_post_save_alter().
   */
  #[Hook('webform_handler_invoke_post_save_alter')]
  public function webformHandlerInvokePostSaveAlter(WebformHandlerInterface $handler, array &$args): void {
    $handler_id = $handler->getHandlerId();
    if ($handler_id === 'remote_post' || $handler_id === 'async_remote_post') {
      _localgov_forms_example_liberty_create_integration_manage_remote_post_custom_data($handler);
    }
  }

  /**
   * Implements hook_webform_handler_invoke_METHOD_NAME_alter() for hook_webform_handler_invoke_post_load_alter().
   *
   * Relevant during Queue processing.
   */
  #[Hook('webform_handler_invoke_post_load_alter')]
  public function webformHandlerInvokePostLoadAlter(WebformHandlerInterface $handler, array &$args): void {
    localgov_forms_example_liberty_create_integration_webform_handler_invoke_post_save_alter($handler, $args);
  }

}
