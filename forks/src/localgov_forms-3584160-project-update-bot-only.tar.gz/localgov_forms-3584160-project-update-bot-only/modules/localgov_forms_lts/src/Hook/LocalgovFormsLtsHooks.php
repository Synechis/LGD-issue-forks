<?php

namespace Drupal\localgov_forms_lts\Hook;

use Drupal\Core\Hook\Attribute\Hook;

/**
 * Hook implementations for localgov_forms_lts.
 */
class LocalgovFormsLtsHooks {

  /**
   * Implements hook_cron().
   */
  #[Hook('cron')]
  public function cron(): void {
    localgov_forms_lts_copy_recently_added_n_updated_subs();
  }

}
