<?php

namespace Drupal\localgov_forms_feedback_form\Hook;

use Drupal\Core\Hook\Attribute\Hook;

/**
 * Hook implementations for localgov_forms_feedback_form.
 */
class LocalgovFormsFeedbackFormHooks {
  /**
   * @file
   * Module file for the Localgov Forms Feedback Form module.
   */

  /**
   * Implements hook_form_FORM_ID_alter().
   */
  #[Hook('form_webform_submission_localgov_forms_feedback_form_add_form_alter')]
  public function formWebformSubmissionLocalgovFormsFeedbackFormAddFormAlter(&$form, $form_state, $form_id): void {
    $form['#attached']['library'][] = 'localgov_forms_feedback_form/localgov_forms_feedback_form';
  }

}
