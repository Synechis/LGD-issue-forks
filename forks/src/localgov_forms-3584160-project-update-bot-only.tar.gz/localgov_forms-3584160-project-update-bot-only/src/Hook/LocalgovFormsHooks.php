<?php

namespace Drupal\localgov_forms\Hook;

use Drupal\Core\Form\FormStateInterface;
use Drupal\Core\Hook\Attribute\Hook;
use Drupal\Core\StringTranslation\StringTranslationTrait;

/**
 * Hook implementations for localgov_forms.
 */
class LocalgovFormsHooks {
  use StringTranslationTrait;

  /**
   * Implements hook_theme().
   */
  #[Hook('theme')]
  public function theme(): array {
    return [
          // Form element: localgov_webform_uk_address.
      'localgov_forms_uk_address_lookup' => [
        'render element' => 'element',
      ],
          // Form element: webform_uk_address.
      'localgov_forms_uk_address' => [
        'render element' => 'element',
      ],
    ];
  }

  /**
   * Implements hook_webform_element_default_properties_alter().
   */
  #[Hook('webform_element_default_properties_alter')]
  public function webformElementDefaultPropertiesAlter(array &$properties, array &$definition): void {
    if ($definition['id'] !== 'number') {
      return;
    }
    $properties['localgov_forms_two_decimal'] = FALSE;
  }

  /**
   * Implements hook_webform_element_configuration_form_alter().
   */
  #[Hook('webform_element_configuration_form_alter')]
  public function webformElementConfigurationFormAlter(array &$form, FormStateInterface $form_state): void {
    /** @var \Drupal\webform_ui\Form\WebformUiElementEditForm $form_object */
    $form_object = $form_state->getFormObject();
    $element_plugin = $form_object->getWebformElementPlugin();
    if (!$element_plugin->hasProperty('localgov_forms_two_decimal')) {
      return;
    }
    $form['localgov_forms'] = [
      '#type' => 'details',
      '#title' => $this->t('LocalGov Forms'),
      '#open' => TRUE,
          // After all core fieldsets (weight -20).
      '#weight' => -10,
    ];
    $form['localgov_forms']['localgov_forms_two_decimal'] = [
      '#type' => 'checkbox',
      '#title' => $this->t('Two decimal places'),
      '#description' => $this->t('Constrain input to two decimal places and normalise on blur/submit. Forces step to 0.01.'),
    ];
  }

  /**
   * Implements hook_form_FORM_ID_alter() for webform_ui_element_form.
   */
  #[Hook('form_webform_ui_element_form_alter')]
  public function formWebformUiElementFormAlter(array &$form, FormStateInterface $form_state): void {
    /** @var \Drupal\webform_ui\Form\WebformUiElementEditForm $form_object */
    $form_object = $form_state->getFormObject();
    if (!method_exists($form_object, 'getWebformElementPlugin')) {
      return;
    }
    $element_plugin = $form_object->getWebformElementPlugin();
    if (!$element_plugin->hasProperty('localgov_forms_two_decimal')) {
      return;
    }
    // The step field may be directly under number or inside number_container
    // depending on whether min/max/step are all numeric.
    $states = [
      'disabled' => [
        ':input[name="properties[localgov_forms_two_decimal]"]' => [
          'checked' => TRUE,
        ],
      ],
    ];
    if (isset($form['properties']['number']['number_container']['step'])) {
      $form['properties']['number']['number_container']['step']['#states'] = $states;
    }
    elseif (isset($form['properties']['number']['step'])) {
      $form['properties']['number']['step']['#states'] = $states;
    }
  }

  /**
   * Implements hook_webform_element_alter().
   */
  #[Hook('webform_element_alter')]
  public function webformElementAlter(array &$element, FormStateInterface $form_state, array $context): void {
    if (($element['#type'] ?? '') === 'number' && !empty($element['#localgov_forms_two_decimal'])) {
      $element['#attributes']['data-two-decimal'] = 'true';
      // Force #step (server-side validation) and the HTML attribute to match,
      // so a conflicting step set in the element settings doesn't cause cryptic
      // validation failures after the JS has already accepted the input.
      $element['#step'] = 0.01;
      $element['#attributes']['step'] = '0.01';
      $element['#attributes']['inputmode'] = 'decimal';
      $element['#attached']['library'][] = 'localgov_forms/localgov_forms_two_decimal';
      // Core's Number element casts the submitted value to a plain number
      // during validation, discarding any trailing zeros the JS added
      // client-side. Re-apply fixed 2-decimal formatting after that runs so
      // the stored value keeps the format, not just the displayed one.
      $element['#element_validate'][] = 'localgov_forms_two_decimal_validate';
    }
  }

}
