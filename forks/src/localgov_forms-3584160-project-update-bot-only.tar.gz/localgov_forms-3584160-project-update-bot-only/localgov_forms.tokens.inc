<?php

/**
 * @file
 * Token declarations.
 */

declare(strict_types=1);

use Drupal\Core\Hook\Attribute\LegacyHook;
use Drupal\localgov_forms\Hook\LocalgovFormsTokensHooks;
use Drupal\Core\Render\BubbleableMetadata;

/**
 * Implements hook_token_info().
 *
 * Token declarations.
 */
#[LegacyHook]
function localgov_forms_token_info(): array {

  return \Drupal::service(LocalgovFormsTokensHooks::class)->tokenInfo();
}

/**
 * Implements hook_tokens().
 *
 * Provides following token values:
 * - purge_date
 * - purge_date:long
 * - purge_date:custom:d/m/Y.
 * - etc.
 *
 * @see system_tokens()
 */
#[LegacyHook]
function localgov_forms_tokens($type, $tokens, array $data, array $options, BubbleableMetadata $bubbleable_metadata): array {
  return \Drupal::service(LocalgovFormsTokensHooks::class)->tokens($type, $tokens, $data, $options, $bubbleable_metadata);
}
