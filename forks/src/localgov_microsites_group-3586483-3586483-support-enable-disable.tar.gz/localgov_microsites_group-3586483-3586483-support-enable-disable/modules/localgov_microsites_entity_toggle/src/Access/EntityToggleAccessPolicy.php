<?php

declare(strict_types=1);

namespace Drupal\localgov_microsites_entity_toggle\Access;

use Drupal\Core\Session\AccountInterface;
use Drupal\flexible_permissions\CalculatedPermissionsItem;
use Drupal\flexible_permissions\PermissionCalculatorAlterInterfaceV2;
use Drupal\flexible_permissions\PermissionCalculatorInterface;
use Drupal\flexible_permissions\RefinableCalculatedPermissions;
use Drupal\flexible_permissions\RefinableCalculatedPermissionsInterface;
use Drupal\group\Access\GroupPermissionHandlerInterface;
use Drupal\group\PermissionScopeInterface;
use Drupal\group\Plugin\Group\Relation\GroupRelationTypeManagerInterface;
use Drupal\group_sites\GroupSitesAdminModeInterface;
use Drupal\localgov_microsites_entity_toggle\Service\MicrositeBundleAccess;
use Drupal\localgov_microsites_group\ContentTypeHelper;
use Drupal\localgov_microsites_entity_toggle\Service\ToggleHelper;

/**
 * Removes the group permissions of the bundles disabled on a microsite.
 *
 * Runs after group_sites, which has merged the permissions of the active
 * microsite into one item. An admin item gets every permission, so it is
 * replaced by a normal item with all the allowed permissions.
 */
final class EntityToggleAccessPolicy implements PermissionCalculatorInterface, PermissionCalculatorAlterInterfaceV2 {

  /**
   * Constructs an EntityToggleAccessPolicy.
   *
   * @param \Drupal\localgov_microsites_entity_toggle\Service\MicrositeBundleAccess $bundleAccess
   *   The active microsite bundle access service.
   * @param \Drupal\localgov_microsites_entity_toggle\Service\ToggleHelper $toggleHelper
   *   The toggle helper.
   * @param \Drupal\group\Plugin\Group\Relation\GroupRelationTypeManagerInterface $groupRelationTypeManager
   *   The group relation type manager.
   * @param \Drupal\group\Access\GroupPermissionHandlerInterface $groupPermissionHandler
   *   The group permission handler.
   * @param \Drupal\group_sites\GroupSitesAdminModeInterface $adminMode
   *   The group sites admin mode service.
   * @param \Drupal\localgov_microsites_group\ContentTypeHelper $contentTypeHelper
   *   The microsite content type helper.
   */
  public function __construct(
    protected MicrositeBundleAccess $bundleAccess,
    protected ToggleHelper $toggleHelper,
    protected GroupRelationTypeManagerInterface $groupRelationTypeManager,
    protected GroupPermissionHandlerInterface $groupPermissionHandler,
    protected GroupSitesAdminModeInterface $adminMode,
    protected ContentTypeHelper $contentTypeHelper,
  ) {
  }

  /**
   * {@inheritdoc}
   */
  public function calculatePermissions(AccountInterface $account, $scope) {
    return new RefinableCalculatedPermissions();
  }

  /**
   * {@inheritdoc}
   */
  public function alterPermissions(AccountInterface $account, $scope, RefinableCalculatedPermissionsInterface $calculated_permissions): void {
    if ($scope !== PermissionScopeInterface::INDIVIDUAL_ID || $this->adminMode->isActive()) {
      return;
    }

    // The result changes with the domain and the microsite.
    $calculated_permissions->addCacheableDependency($this->bundleAccess->getCacheability());

    $group = $this->bundleAccess->getActiveMicrosite();
    if (!$group) {
      return;
    }

    $item = $calculated_permissions->getItem($scope, $group->id());
    if (!$item) {
      return;
    }

    $plugin_ids = $this->toggleHelper->getRelationPluginIds($group, $this->bundleAccess->getDisabledBundleIds());
    if (!$plugin_ids) {
      return;
    }

    $permissions = $item->getPermissions();
    if ($item->isAdmin()) {
      $permissions = array_merge($permissions, array_keys($this->groupPermissionHandler->getPermissionsByGroupType($group->getGroupType())));

      // Also remove the content types of disabled modules.
      $installed = $this->groupRelationTypeManager->getInstalledIds($group->getGroupType());
      $plugin_ids = array_merge($plugin_ids, array_diff($installed, $this->contentTypeHelper->enabledContentTypes($group)));
    }

    $removed = $this->getPluginPermissions(array_unique($plugin_ids));

    $calculated_permissions->addItem(new CalculatedPermissionsItem(
      $scope,
      $group->id(),
      array_values(array_unique(array_diff($permissions, $removed))),
      FALSE,
    ), TRUE);
  }

  /**
   * {@inheritdoc}
   */
  public function getPersistentCacheContexts($scope) {
    return [];
  }

  /**
   * Returns all the permissions of the given relation plugins.
   *
   * @param string[] $plugin_ids
   *   The group relation plugin IDs.
   *
   * @return string[]
   *   The permission names.
   */
  protected function getPluginPermissions(array $plugin_ids): array {
    $permissions = [];
    foreach ($plugin_ids as $plugin_id) {
      $provider = $this->groupRelationTypeManager->getPermissionProvider($plugin_id);
      $permissions = array_merge($permissions, array_keys($provider->buildPermissions()));
    }

    return $permissions;
  }

}
