<?php

declare(strict_types=1);

namespace Drupal\localgov_microsites_entity_toggle\Hook;

use Drupal\Core\Access\AccessResult;
use Drupal\Core\Access\AccessResultInterface;
use Drupal\Core\Entity\EntityInterface;
use Drupal\Core\Hook\Attribute\Hook;
use Drupal\Core\Session\AccountInterface;
use Drupal\localgov_microsites_entity_toggle\Service\MicrositeBundleAccess;

/**
 * Denies access to the entity bundles a microsite has switched off.
 *
 * @package Drupal\localgov_microsites_entity_toggle\Hook
 */
final class EntityAccess {

  /**
   * Constructs an EntityAccess hook handler.
   *
   * @param \Drupal\localgov_microsites_entity_toggle\Service\MicrositeBundleAccess $bundleAccess
   *   The active microsite bundle access service.
   */
  public function __construct(
    protected MicrositeBundleAccess $bundleAccess,
  ) {
  }

  /**
   * Implements hook_entity_access().
   */
  #[Hook('entity_access')]
  public function entityAccess(EntityInterface $entity, string $operation, AccountInterface $account): AccessResultInterface {
    return $this->bundleAccess->access($entity->getEntityTypeId(), $entity->bundle());
  }

  /**
   * Implements hook_entity_create_access().
   */
  #[Hook('entity_create_access')]
  public function entityCreateAccess(AccountInterface $account, array $context, ?string $entity_bundle): AccessResultInterface {
    if (!$entity_bundle) {
      return AccessResult::neutral();
    }

    return $this->bundleAccess->access($context['entity_type_id'], $entity_bundle);
  }

}
