<?php

declare(strict_types=1);

namespace Drupal\localgov_microsites_entity_toggle\Service;

use Drupal\Core\Extension\ModuleHandlerInterface;
use Drupal\localgov_microsites_group\RolesHelper;

/**
 * The entity bundles controlled by the Content types tab.
 *
 * @see \Drupal\localgov_microsites_group\ContentTypeHelper::enabledContentTypes()
 * @see \Drupal\localgov_microsites_group\Access\MicrositeContentTypesAccessPolicy
 */
final class ModuleControlledBundles {

  /**
   * Constructs a ModuleControlledBundles.
   *
   * @param \Drupal\Core\Extension\ModuleHandlerInterface $moduleHandler
   *   The module handler.
   * @param \Drupal\localgov_microsites_entity_toggle\Service\ToggleHelper $toggleHelper
   *   The toggle helper.
   */
  public function __construct(
    protected ModuleHandlerInterface $moduleHandler,
    protected ToggleHelper $toggleHelper,
  ) {
  }

  /**
   * Returns the bundles controlled by the Content types tab.
   *
   * @param string|null $module
   *   A module on the Content types tab, or NULL for all of them.
   *
   * @return string[]
   *   A sorted list of "<entity_type>:<bundle>" identifiers.
   */
  public function getBundleIds(?string $module = NULL): array {
    $ids = [];
    foreach ($this->getRelationPluginIds($module) as $plugin_id) {
      if ($bundle_id = $this->toggleHelper->getRelationBundleId($plugin_id)) {
        $ids[] = $bundle_id;
      }
    }

    $ids = array_unique($ids);
    sort($ids);

    return $ids;
  }

  /**
   * Returns the relation plugin IDs of the modules on the Content types tab.
   *
   * @param string|null $only_module
   *   A module on the Content types tab, or NULL for all of them.
   *
   * @return string[]
   *   A list of group relation plugin IDs.
   */
  protected function getRelationPluginIds(?string $only_module = NULL): array {
    $plugin_ids = [];

    $this->moduleHandler->invokeAllWith('localgov_microsites_roles_default', function ($hook, $module) use (&$plugin_ids, $only_module): void {
      // This module cannot be disabled, so it is not on the tab.
      if ($module === 'localgov_microsites_group') {
        return;
      }
      if ($only_module !== NULL && $module !== $only_module) {
        return;
      }

      foreach ($hook()['group'][RolesHelper::GROUP_ADMIN_ROLE] ?? [] as $permission) {
        $matches = [];
        if (preg_match('/^create (.*) entity$/', $permission, $matches)) {
          $plugin_ids[] = $matches[1];
        }
      }
    });

    return array_unique($plugin_ids);
  }

}
