<?php

declare(strict_types=1);

namespace Drupal\localgov_microsites_entity_toggle\Service;

use Drupal\Core\Entity\EntityTypeBundleInfoInterface;
use Drupal\Core\Extension\ModuleHandlerInterface;
use Drupal\group\Entity\GroupInterface;
use Drupal\group\Entity\GroupTypeInterface;
use Drupal\group\Plugin\Group\Relation\GroupRelationTypeManagerInterface;

/**
 * Decides which entity bundles the toggle can switch off.
 *
 * A group related bundle is supported only when its relation plugin has its
 * own permissions, so removing them really blocks the bundle.
 *
 * @see hook_localgov_microsites_entity_toggle_unsupported_bundles_alter()
 */
final class SupportedBundles {

  /**
   * The operations a relation plugin must protect with its own permission.
   */
  protected const OPERATIONS = ['create', 'view', 'update', 'delete'];

  /**
   * The unsupported bundles before the alter hook, keyed by group type ID.
   *
   * @var array<string, array<string, string>>
   */
  private array $built = [];

  /**
   * The unsupported bundles, keyed by group ID.
   *
   * @var array<int|string, array<string, string>>
   */
  private array $unsupported = [];

  /**
   * Constructs a SupportedBundles.
   *
   * @param \Drupal\group\Plugin\Group\Relation\GroupRelationTypeManagerInterface $groupRelationTypeManager
   *   The group relation type manager.
   * @param \Drupal\Core\Entity\EntityTypeBundleInfoInterface $entityTypeBundleInfo
   *   The entity type bundle info.
   * @param \Drupal\Core\Extension\ModuleHandlerInterface $moduleHandler
   *   The module handler.
   */
  public function __construct(
    protected GroupRelationTypeManagerInterface $groupRelationTypeManager,
    protected EntityTypeBundleInfoInterface $entityTypeBundleInfo,
    protected ModuleHandlerInterface $moduleHandler,
  ) {
  }

  /**
   * Returns the bundles the toggle cannot switch off.
   *
   * @param \Drupal\group\Entity\GroupInterface $group
   *   The microsite group.
   *
   * @return array<string, string>
   *   The reasons, keyed by "<entity_type>:<bundle>" identifier.
   */
  public function getUnsupportedBundles(GroupInterface $group): array {
    $group_id = $group->id();

    if (!isset($this->unsupported[$group_id])) {
      $group_type = $group->getGroupType();
      $this->built[$group_type->id()] ??= $this->buildUnsupportedBundles($group_type);

      $unsupported = $this->built[$group_type->id()];
      // Other modules can take over a bundle by removing it.
      $this->moduleHandler->alter('localgov_microsites_entity_toggle_unsupported_bundles', $unsupported, $group_type, $group);
      $this->unsupported[$group_id] = $unsupported;
    }

    return $this->unsupported[$group_id];
  }

  /**
   * Checks whether the toggle can switch off a bundle.
   *
   * @param \Drupal\group\Entity\GroupInterface $group
   *   The microsite group.
   * @param string $bundle_id
   *   An "<entity_type>:<bundle>" identifier.
   *
   * @return bool
   *   TRUE when the bundle is supported.
   */
  public function isSupported(GroupInterface $group, string $bundle_id): bool {
    return !isset($this->getUnsupportedBundles($group)[$bundle_id]);
  }

  /**
   * Removes the unsupported bundles from a list.
   *
   * @param \Drupal\group\Entity\GroupInterface $group
   *   The microsite group.
   * @param string[] $bundle_ids
   *   A list of "<entity_type>:<bundle>" identifiers.
   *
   * @return string[]
   *   The supported identifiers.
   */
  public function filter(GroupInterface $group, array $bundle_ids): array {
    return array_values(array_diff($bundle_ids, array_keys($this->getUnsupportedBundles($group))));
  }

  /**
   * Builds the unsupported bundles from the installed relation plugins.
   *
   * @param \Drupal\group\Entity\GroupTypeInterface $group_type
   *   The microsite group type.
   *
   * @return array<string, string>
   *   The reasons, keyed by "<entity_type>:<bundle>" identifier.
   */
  protected function buildUnsupportedBundles(GroupTypeInterface $group_type): array {
    $plugin_ids = $this->groupRelationTypeManager->getInstalledIds($group_type);

    // Find the plugins that use each permission.
    $permissions = [];
    $owners = [];
    foreach ($plugin_ids as $plugin_id) {
      $provider = $this->groupRelationTypeManager->getPermissionProvider($plugin_id);
      foreach (self::OPERATIONS as $operation) {
        $permission = $provider->getPermission($operation, 'entity');
        $permissions[$plugin_id][$operation] = $permission;
        if ($permission) {
          $owners[$permission][$plugin_id] = TRUE;
        }
      }
    }

    $unsupported = [];
    foreach ($plugin_ids as $plugin_id) {
      $reason = $this->getUnsupportedReason($plugin_id, $permissions[$plugin_id], $owners);
      if ($reason === NULL) {
        continue;
      }

      $definition = $this->groupRelationTypeManager->getDefinition($plugin_id);
      $entity_type_id = $definition->getEntityTypeId();
      if (in_array($entity_type_id, ToggleHelper::EXCLUDED_ENTITY_TYPES, TRUE)) {
        continue;
      }

      // A plugin without a bundle covers every bundle of its entity type.
      $bundles = $definition->getEntityBundle()
        ? [$definition->getEntityBundle()]
        : array_keys($this->entityTypeBundleInfo->getBundleInfo($entity_type_id));

      foreach ($bundles as $bundle) {
        $unsupported[$entity_type_id . ':' . $bundle] = $reason;
      }
    }

    ksort($unsupported);

    return $unsupported;
  }

  /**
   * Returns why a relation plugin cannot be switched off by bundle.
   *
   * @param string $plugin_id
   *   The group relation plugin ID.
   * @param array<string, string|false> $permissions
   *   The permission of each operation, keyed by operation.
   * @param array<string, array<string, true>> $owners
   *   The plugin IDs of each permission, keyed by permission.
   *
   * @return string|null
   *   The reason, or NULL when the plugin is supported.
   */
  protected function getUnsupportedReason(string $plugin_id, array $permissions, array $owners): ?string {
    $definition = $this->groupRelationTypeManager->getDefinition($plugin_id);

    if (!$definition->getEntityBundle()) {
      return "The $plugin_id relation covers every bundle of the entity type.";
    }
    if (!$definition->definesEntityAccess()) {
      return "The $plugin_id relation does not control entity access.";
    }

    foreach ($permissions as $operation => $permission) {
      if (!$permission) {
        return "The $plugin_id relation has no permission for the $operation operation.";
      }
      if (count($owners[$permission]) > 1) {
        return "The $plugin_id relation shares the \"$permission\" permission with other relations.";
      }
    }

    return NULL;
  }

}
