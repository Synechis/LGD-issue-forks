<?php

declare(strict_types=1);

namespace Drupal\localgov_microsites_entity_toggle\Service;

use Drupal\Core\Access\AccessResult;
use Drupal\Core\Access\AccessResultInterface;
use Drupal\Core\Cache\CacheableMetadata;
use Drupal\group\Entity\GroupInterface;
use Drupal\group_sites\GroupSitesNegotiator;

/**
 * Decides which entity bundles are switched off on the active microsite.
 */
final class MicrositeBundleAccess {

  /**
   * The bundles disabled on the active microsite, keyed by identifier.
   *
   * @var array<string, true>|null
   */
  private ?array $disabled = NULL;

  /**
   * The active microsite, or NULL on the controller site.
   */
  private ?GroupInterface $microsite = NULL;

  /**
   * The cache metadata of the active microsite.
   */
  private ?CacheableMetadata $cacheability = NULL;

  /**
   * Constructs a MicrositeBundleAccess.
   *
   * @param \Drupal\localgov_microsites_entity_toggle\Service\ToggleHelper $toggleHelper
   *   The toggle helper.
   * @param \Drupal\localgov_microsites_entity_toggle\Service\ModuleControlledBundles $moduleControlledBundles
   *   The bundles controlled by the Content types tab.
   * @param \Drupal\group_sites\GroupSitesNegotiator $negotiator
   *   The group sites negotiator.
   */
  public function __construct(
    protected ToggleHelper $toggleHelper,
    protected ModuleControlledBundles $moduleControlledBundles,
    protected GroupSitesNegotiator $negotiator,
  ) {
  }

  /**
   * Returns the active microsite.
   *
   * @return \Drupal\group\Entity\GroupInterface|null
   *   The microsite group, or NULL on the controller site.
   */
  public function getActiveMicrosite(): ?GroupInterface {
    $this->resolve();
    return $this->microsite;
  }

  /**
   * Returns the cache metadata of the active microsite.
   *
   * @return \Drupal\Core\Cache\CacheableMetadata
   *   The cache metadata.
   */
  public function getCacheability(): CacheableMetadata {
    $this->resolve();
    return $this->cacheability;
  }

  /**
   * Returns the bundles switched off on the active microsite.
   *
   * @return string[]
   *   A list of "<entity_type>:<bundle>" identifiers. Empty on the
   *   controller site.
   */
  public function getDisabledBundleIds(): array {
    $this->resolve();
    return array_keys($this->disabled);
  }

  /**
   * Checks whether a bundle is switched off on the active microsite.
   *
   * @param string $entity_type_id
   *   The entity type ID to check.
   * @param string $bundle
   *   The bundle to check.
   *
   * @return bool
   *   TRUE when the bundle has to be denied.
   */
  public function isDisabled(string $entity_type_id, string $bundle): bool {
    // These types can never be disabled.
    if (in_array($entity_type_id, ToggleHelper::EXCLUDED_ENTITY_TYPES, TRUE)) {
      return FALSE;
    }

    $this->resolve();
    return isset($this->disabled[$entity_type_id . ':' . $bundle]);
  }

  /**
   * Builds the access result for a bundle on the active microsite.
   *
   * @param string $entity_type_id
   *   The entity type ID to check.
   * @param string $bundle
   *   The bundle to check.
   *
   * @return \Drupal\Core\Access\AccessResultInterface
   *   Forbidden when the bundle is disabled, neutral otherwise.
   */
  public function access(string $entity_type_id, string $bundle): AccessResultInterface {
    if (in_array($entity_type_id, ToggleHelper::EXCLUDED_ENTITY_TYPES, TRUE)) {
      return AccessResult::neutral();
    }

    $result = $this->isDisabled($entity_type_id, $bundle)
      ? AccessResult::forbidden('The entity bundle is disabled for this microsite.')
      : AccessResult::neutral();

    return $result->addCacheableDependency($this->getCacheability());
  }

  /**
   * Loads the active microsite and its disabled bundles once.
   */
  protected function resolve(): void {
    if ($this->disabled !== NULL) {
      return;
    }

    $this->cacheability = new CacheableMetadata();
    $this->microsite = $this->negotiator->getActiveGroup($this->cacheability);
    $this->disabled = [];

    if (!$this->microsite instanceof GroupInterface) {
      return;
    }

    // Saving the microsite clears the cached results.
    $this->cacheability->addCacheableDependency($this->microsite);

    $disabled = array_diff(
      $this->toggleHelper->getDisabledBundles($this->microsite),
      $this->moduleControlledBundles->getBundleIds(),
    );

    $this->disabled = array_fill_keys($disabled, TRUE);
  }

}
