<?php

declare(strict_types=1);

namespace Drupal\localgov_microsites_entity_toggle\Service;

use Drupal\Core\Entity\EntityFieldManagerInterface;
use Drupal\Core\Entity\EntityTypeBundleInfoInterface;
use Drupal\Core\Entity\EntityTypeManagerInterface;
use Drupal\Core\Entity\FieldableEntityInterface;
use Drupal\Core\Field\FieldDefinitionInterface;
use Drupal\Core\Field\Plugin\Field\FieldType\EntityReferenceItem;
use Drupal\field\FieldConfigInterface;
use Drupal\group\Entity\GroupInterface;
use Drupal\group\Plugin\Group\Relation\GroupRelationTypeManagerInterface;

/**
 * Helper for the entity bundles available to a microsite.
 */
final class ToggleHelper {

  /**
   * The field that stores the disabled bundles.
   */
  public const FIELD_NAME = 'lgms_entities_disabled';

  /**
   * The entity type the field is attached to.
   */
  public const ENTITY_TYPE = 'group';

  /**
   * The group bundle the field is attached to.
   */
  public const BUNDLE = 'microsite';

  /**
   * The group permission needed to disable bundles.
   */
  public const PERMISSION = 'disable and enable entities on localgov microsites';


  /**
   * Entity types that can never be disabled.
   */
  public const EXCLUDED_ENTITY_TYPES = [
    'file',
    'group',
    'group_relationship',
    'path_alias',
    'user',
  ];

  /**
   * Constructs a ToggleHelper.
   *
   * @param \Drupal\Core\Entity\EntityTypeManagerInterface $entityTypeManager
   *   The entity type manager.
   * @param \Drupal\Core\Entity\EntityFieldManagerInterface $entityFieldManager
   *   The entity field manager.
   * @param \Drupal\Core\Entity\EntityTypeBundleInfoInterface $entityTypeBundleInfo
   *   The entity type bundle info.
   * @param \Drupal\group\Plugin\Group\Relation\GroupRelationTypeManagerInterface $groupRelationTypeManager
   *   The group relation type manager.
   */
  public function __construct(
    protected EntityTypeManagerInterface $entityTypeManager,
    protected EntityFieldManagerInterface $entityFieldManager,
    protected EntityTypeBundleInfoInterface $entityTypeBundleInfo,
    protected GroupRelationTypeManagerInterface $groupRelationTypeManager,
  ) {
  }

  /**
   * Returns the bundles that can be added to the microsite.
   *
   * @param \Drupal\group\Entity\GroupInterface $group
   *   The microsite group.
   *
   * @return string[]
   *   A sorted list of "<entity_type>:<bundle>" identifiers.
   */
  public function getGroupRelatedBundles(GroupInterface $group): array {
    $group_type = $group->getGroupType();

    $ids = [];
    foreach ($this->groupRelationTypeManager->getInstalledIds($group_type) as $plugin_id) {
      if ($bundle_id = $this->getRelationBundleId($plugin_id)) {
        $ids[] = $bundle_id;
      }
    }

    $ids = array_unique($ids);
    sort($ids);

    return $ids;
  }

  /**
   * Returns the bundle identifier of a group relation plugin.
   *
   * @param string $plugin_id
   *   The group relation plugin ID, for example "group_node:localgov_page".
   *
   * @return string|null
   *   An "<entity_type>:<bundle>" identifier, or NULL if the plugin is gone.
   */
  public function getRelationBundleId(string $plugin_id): ?string {
    $relation_type = $this->groupRelationTypeManager->getDefinition($plugin_id, FALSE);
    if (!$relation_type || !$relation_type->getEntityTypeId() || !$relation_type->getEntityBundle()) {
      return NULL;
    }

    return $relation_type->getEntityTypeId() . ':' . $relation_type->getEntityBundle();
  }

  /**
   * Returns the installed group relation plugin IDs of the given bundles.
   *
   * @param \Drupal\group\Entity\GroupInterface $group
   *   The microsite group.
   * @param string[] $bundle_ids
   *   A list of "<entity_type>:<bundle>" identifiers.
   *
   * @return string[]
   *   A list of group relation plugin IDs.
   */
  public function getRelationPluginIds(GroupInterface $group, array $bundle_ids): array {
    $wanted = array_fill_keys($bundle_ids, TRUE);

    $plugin_ids = [];
    foreach ($this->groupRelationTypeManager->getInstalledIds($group->getGroupType()) as $plugin_id) {
      $bundle_id = $this->getRelationBundleId($plugin_id);
      if ($bundle_id !== NULL && isset($wanted[$bundle_id])) {
        $plugin_ids[] = $plugin_id;
      }
    }

    return $plugin_ids;
  }

  /**
   * Returns the bundles referenced by the given bundles, at any depth.
   *
   * @param \Drupal\group\Entity\GroupInterface $group
   *   The microsite group.
   * @param string[]|null $bundle_ids
   *   A list of "<entity_type>:<bundle>" identifiers, or NULL for the
   *   bundles of the microsite.
   *
   * @return string[]
   *   A sorted list of "<entity_type>:<bundle>" identifiers.
   */
  public function getReferencedBundles(GroupInterface $group, ?array $bundle_ids = NULL): array {
    $bundle_ids ??= $this->getGroupRelatedBundles($group);

    // Remember visited bundles to avoid infinite loops.
    $retrieved = array_fill_keys($bundle_ids, TRUE);
    $found = [];

    foreach ($bundle_ids as $bundle_id) {
      $this->collectReferencedBundles($bundle_id, $retrieved, $found);
    }

    $ids = array_keys($found);
    sort($ids);

    return $ids;
  }

  /**
   * Collects the referenced bundles of one bundle, recursively.
   *
   * @param string $bundle_id
   *   The "<entity_type>:<bundle>" identifier to start from.
   * @param array $retrieved
   *   The bundles already visited.
   * @param array $found
   *   The bundles found, keyed by identifier.
   */
  protected function collectReferencedBundles(string $bundle_id, array &$retrieved, array &$found): void {
    [$entity_type_id, $bundle] = explode(':', $bundle_id, 2);

    if (!$entity_type_id || !$bundle) {
      return;
    }

    foreach ($this->getReferenceTargets($entity_type_id, $bundle) as $target_id) {
      $found[$target_id] = TRUE;

      if (!isset($retrieved[$target_id])) {
        $retrieved[$target_id] = TRUE;
        $this->collectReferencedBundles($target_id, $retrieved, $found);
      }
    }
  }

  /**
   * Returns the bundles referenced by the fields of a bundle.
   *
   * @param string $entity_type_id
   *   The entity type ID to inspect.
   * @param string $bundle
   *   The bundle to inspect.
   *
   * @return string[]
   *   A list of "<entity_type>:<bundle>" identifiers.
   */
  protected function getReferenceTargets(string $entity_type_id, string $bundle): array {
    $entity_type = $this->entityTypeManager->getDefinition($entity_type_id, FALSE);

    // Only fieldable entities have reference fields.
    if (!$entity_type || !$entity_type->entityClassImplements(FieldableEntityInterface::class)) {
      return [];
    }

    $ids = [];
    foreach ($this->entityFieldManager->getFieldDefinitions($entity_type_id, $bundle) as $field_definition) {

      if (!$field_definition instanceof FieldConfigInterface) {
        continue;
      }
      if (!$this->isEntityReference($field_definition)) {
        continue;
      }

      $target_type = $field_definition->getSetting('target_type');
      if (!$target_type || !$this->entityTypeManager->hasDefinition($target_type)) {
        continue;
      }

      $handler_settings = $field_definition->getSetting('handler_settings') ?? [];
      $configured_bundles = array_values($handler_settings['target_bundles'] ?? []);
      $all_bundles = array_keys($this->entityTypeBundleInfo->getBundleInfo($target_type));

      if (!$configured_bundles) {
        // No bundles set: all bundles are allowed.
        $target_bundles = $all_bundles;
      }
      elseif (!empty($handler_settings['negate'])) {
        // The list is inverted.
        $target_bundles = array_diff($all_bundles, $configured_bundles);
      }
      else {
        $target_bundles = $configured_bundles;
      }

      foreach ($target_bundles as $target_bundle) {
        $ids[] = $target_type . ':' . $target_bundle;
      }
    }

    return $ids;
  }

  /**
   * Checks whether a field definition references other entities.
   *
   * @param \Drupal\Core\Field\FieldDefinitionInterface $field_definition
   *   The field definition to check.
   *
   * @return bool
   *   TRUE if the field references entities.
   */
  protected function isEntityReference(FieldDefinitionInterface $field_definition): bool {
    return is_a($field_definition->getItemDefinition()->getClass(), EntityReferenceItem::class, TRUE);
  }

  /**
   * Builds the form options from a list of bundles.
   *
   * @param string[] $bundle_ids
   *   A list of "<entity_type>:<bundle>" identifiers.
   *
   * @return array[]
   *   An array keyed by entity type ID, each value holding:
   *   - label: the entity type label.
   *   - options: bundle labels keyed by "<entity_type>:<bundle>".
   */
  public function getBundleOptions(array $bundle_ids): array {
    $grouped = [];

    foreach ($bundle_ids as $bundle_id) {
      [$entity_type_id, $bundle] = explode(':', (string) $bundle_id, 2);

      // Skip invalid IDs and excluded entity types.
      if (!$entity_type_id || !$bundle || in_array($entity_type_id, self::EXCLUDED_ENTITY_TYPES, TRUE)) {
        continue;
      }

      $entity_type = $this->entityTypeManager->getDefinition($entity_type_id, FALSE);

      // Only content entity types.
      if (!$entity_type || $entity_type->getGroup() !== 'content') {
        continue;
      }

      $bundle_info = $this->entityTypeBundleInfo->getBundleInfo($entity_type_id);
      if (!isset($bundle_info[$bundle])) {
        continue;
      }

      $grouped[$entity_type_id]['label'] = (string) $entity_type->getLabel();
      $grouped[$entity_type_id]['options'][$bundle_id] = (string) "{$bundle_info[$bundle]['label']} ({$bundle})";
    }

    foreach ($grouped as &$group) {
      asort($group['options']);
    }

    return $grouped;
  }

  /**
   * Returns the bundles disabled for a microsite.
   *
   * @param \Drupal\group\Entity\GroupInterface $group
   *   The microsite group.
   *
   * @return string[]
   *   A list of "<entity_type>:<bundle>" identifiers.
   */
  public function getDisabledBundles(GroupInterface $group): array {
    if (!$group->hasField(self::FIELD_NAME)) {
      return [];
    }

    return array_column($group->get(self::FIELD_NAME)->getValue(), 'value');
  }

  /**
   * Stores the bundles disabled for a microsite.
   *
   * @param \Drupal\group\Entity\GroupInterface $group
   *   The microsite group.
   * @param string[] $bundle_ids
   *   A list of "<entity_type>:<bundle>" identifiers to disable.
   */
  public function setDisabledBundles(GroupInterface $group, array $bundle_ids): void {
    if (!$group->hasField(self::FIELD_NAME)) {
      return;
    }

    $bundle_ids = array_values(array_unique($bundle_ids));
    sort($bundle_ids);

    $group->set(self::FIELD_NAME, $bundle_ids);
    $group->save();
  }

}
