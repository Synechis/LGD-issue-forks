<?php

declare(strict_types=1);

namespace Drupal\localgov_microsites_entity_toggle\Plugin\DomainGroupSettings;

use Drupal\Core\Access\AccessResultInterface;
use Drupal\Core\DependencyInjection\AutowiredInstanceTrait;
use Drupal\Core\Form\FormStateInterface;
use Drupal\Core\Plugin\ContainerFactoryPluginInterface;
use Drupal\Core\Session\AccountInterface;
use Drupal\Core\StringTranslation\StringTranslationTrait;
use Drupal\group\Access\GroupAccessResult;
use Drupal\group\Entity\GroupInterface;
use Drupal\localgov_microsites_entity_toggle\Service\ModuleControlledBundles;
use Drupal\localgov_microsites_entity_toggle\Service\ToggleHelper;
use Drupal\localgov_microsites_group\Plugin\DomainGroupSettingsBase;
use Symfony\Component\DependencyInjection\Attribute\Autowire;
use Symfony\Component\DependencyInjection\ContainerInterface;

/**
 * Enables and disables entity bundles for a microsite.
 *
 * @DomainGroupSettings(
 *   id = "localgov_microsites_entity_toggle_manage_entities",
 *   label = @Translation("Entities"),
 * )
 */
class ManageEntities extends DomainGroupSettingsBase implements ContainerFactoryPluginInterface {

  use StringTranslationTrait;
  use AutowiredInstanceTrait;

  /**
   * The form key of the plugin elements.
   */
  protected const FORM_KEY = 'entity_access';

  /**
   * The form sections, keyed by element name.
   */
  protected const SECTIONS = ['site_content', 'components'];

  /**
   * Constructs a new ManageEntities plugin instance.
   *
   * @param array $configuration
   *   A configuration array containing information about the plugin instance.
   * @param string $plugin_id
   *   The plugin_id for the plugin instance.
   * @param mixed $plugin_definition
   *   The plugin implementation definition.
   * @param \Drupal\localgov_microsites_entity_toggle\Service\ToggleHelper $toggleHelper
   *   The toggle helper.
   * @param \Drupal\localgov_microsites_entity_toggle\Service\ModuleControlledBundles $moduleControlledBundles
   *   The bundles controlled by the Content types tab.
   */
  public function __construct(
    array $configuration,
    string $plugin_id,
    mixed $plugin_definition,
    #[Autowire(service: 'localgov_microsites_entity_toggle.toggle_helper')]
    protected ToggleHelper $toggleHelper,
    #[Autowire(service: 'localgov_microsites_entity_toggle.module_controlled_bundles')]
    protected ModuleControlledBundles $moduleControlledBundles,
  ) {
    parent::__construct($configuration, $plugin_id, $plugin_definition);
  }

  /**
   * {@inheritdoc}
   */
  public static function create(ContainerInterface $container, array $configuration, $plugin_id, $plugin_definition) {
    return static::createInstanceAutowired($container, $configuration, $plugin_id, $plugin_definition);
  }

  /**
   * {@inheritdoc}
   *
   * Checks the group permission.
   */
  public function access(GroupInterface $group, AccountInterface $account): AccessResultInterface {
    return GroupAccessResult::allowedIfHasGroupPermission($group, $account, $this->toggleHelper::PERMISSION);
  }

  /**
   * {@inheritdoc}
   *
   * Builds the form with one checkbox for each bundle.
   */
  public function buildConfigurationForm(array $form, FormStateInterface $form_state, GroupInterface $group): array {
    $form['#weight'] = 20;

    // Bundles that can be added to the group.
    $related = $this->toggleHelper->getGroupRelatedBundles($group);

    // Entity referenced by entities having a group relationship.
    $components = array_diff($this->toggleHelper->getReferencedBundles($group, $related), $related);

    // The bundles managed already on "Content types" tab.
    $site_content = array_diff($related, $this->moduleControlledBundles->getBundleIds());

    $sections = [
      'site_content' => [
        'title' => $this->t('Site content'),
        'description' => $this->t('Content types this microsite can hold that are not covered by a module on the Content types tab. Unticking a type hides it from the editorial interface; content already created will not be accessible anymore.'),
        'bundles' => $site_content,
      ],
      'components' => [
        'title' => $this->t('Components'),
        'description' => $this->t('Building blocks used inside the content above, such as paragraphs and media.'),
        'bundles' => $components,
      ],
    ];

    $form[self::FORM_KEY] = [
      '#type' => 'container',
      // Keep the values apart from the other plugins.
      '#tree' => TRUE,
    ];

    $disabled = $this->toggleHelper->getDisabledBundles($group);

    foreach ($sections as $section => $info) {
      $grouped = $this->toggleHelper->getBundleOptions($info['bundles']);
      if (!$grouped) {
        continue;
      }

      $form[self::FORM_KEY][$section] = [
        '#type' => 'details',
        '#title' => $info['title'],
        '#description' => $info['description'],
        '#open' => $section === 'site_content',
      ];

      foreach ($grouped as $entity_type_id => $entity_type) {
        $form[self::FORM_KEY][$section][$entity_type_id] = [
          '#type' => 'checkboxes',
          '#title' => $entity_type['label'],
          '#options' => $entity_type['options'],
          '#default_value' => array_values(array_diff(array_keys($entity_type['options']), $disabled)),
        ];
      }
    }

    if (!array_intersect(self::SECTIONS, array_keys($form[self::FORM_KEY]))) {
      $form[self::FORM_KEY]['empty'] = [
        '#markup' => $this->t('Every entity type available to this microsite is managed on the Content types tab.'),
      ];
    }

    return $form;
  }

  /**
   * {@inheritdoc}
   *
   * Nothing to validate but callback required.
   */
  public function validateConfigurationForm(array &$form, FormStateInterface $form_state): void {
  }

  /**
   * {@inheritdoc}
   *
   * Saves the unticked bundles as disabled.
   */
  public function submitConfigurationForm(array &$form, FormStateInterface $form_state): void {
    $group = $form_state->get('group');
    if (!$group instanceof GroupInterface) {
      return;
    }

    $values = $form_state->getValue(self::FORM_KEY) ?? [];

    $available = [];
    $enabled = [];
    foreach (self::SECTIONS as $section) {
      foreach ($values[$section] ?? [] as $checkboxes) {
        if (!is_array($checkboxes)) {
          continue;
        }

        // Ticked options have the bundle ID, the others have 0.
        $available = array_merge($available, array_keys($checkboxes));
        $enabled = array_merge($enabled, array_filter($checkboxes));
      }
    }

    // Keep the values of bundles not shown in the form.
    $untouched = array_diff($this->toggleHelper->getDisabledBundles($group), $available);

    $this->toggleHelper->setDisabledBundles(
      $group,
      array_merge($untouched, array_diff($available, $enabled))
    );
  }

}
