<?php

/**
 * @file
 * Hooks provided by the Localgov Microsites Entity Toggle module.
 */

/**
 * @addtogroup hooks
 * @{
 */

/**
 * Alters the bundles the toggle cannot switch off.
 *
 * A group related bundle is unsupported when its relation plugin has no
 * bundle, does not control entity access, or shares a permission with other
 * relation plugins.
 *
 * Remove a bundle from the list to show it on the Entities tab. The module
 * then stores its state, and
 * \Drupal\localgov_microsites_entity_toggle\Service\MicrositeBundleAccess
 * reports it as disabled. The module that removes the bundle must deny access
 * to it on every route and form that the bundle uses.
 *
 * @param array<string, string> $unsupported
 *   The reasons, keyed by "<entity_type>:<bundle>" identifier.
 * @param \Drupal\group\Entity\GroupTypeInterface $group_type
 *   The microsite group type.
 * @param \Drupal\group\Entity\GroupInterface $group
 *   The microsite group the list is for.
 */
function hook_localgov_microsites_entity_toggle_unsupported_bundles_alter(array &$unsupported, \Drupal\group\Entity\GroupTypeInterface $group_type, \Drupal\group\Entity\GroupInterface $group): void {
  // This module denies access to disabled group menus itself.
  foreach (array_keys($unsupported) as $bundle_id) {
    if (str_starts_with($bundle_id, 'group_content_menu:')) {
      unset($unsupported[$bundle_id]);
    }
  }
}

/**
 * @} End of "addtogroup hooks".
 */
