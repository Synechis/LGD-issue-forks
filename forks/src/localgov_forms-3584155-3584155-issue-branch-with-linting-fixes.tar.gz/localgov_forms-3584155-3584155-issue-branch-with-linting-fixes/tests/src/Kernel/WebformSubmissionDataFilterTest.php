<?php

declare(strict_types=1);

namespace Drupal\Tests\localgov_forms\Kernel;

use Drupal\Component\Serialization\Yaml;
use Drupal\Tests\views\Kernel\ViewsKernelTestBase;
use Drupal\views\Tests\ViewTestData;
use Drupal\views\Views;
use Drupal\webform\Entity\Webform;
use Drupal\webform\Entity\WebformSubmission;

/**
 * Tests the localgov_forms_submission_data_filter Views filter.
 *
 * The filter adds its own LEFT JOIN to webform_submission_data, pinned to a
 * field key (and optionally a composite sub-field property and a webform ID),
 * then filters on the joined value column. These tests assert that filtering
 * targets the correct value column - not the sid join key - and that composite
 * sub-fields are isolated from same-named top-level fields.
 *
 * @group localgov_forms
 *
 * @coversDefaultClass \Drupal\localgov_forms\Plugin\views\filter\WebformSubmissionDataFilter
 */
class WebformSubmissionDataFilterTest extends ViewsKernelTestBase {

  /**
   * {@inheritdoc}
   */
  protected static $modules = [
    'system',
    'user',
    'path',
    'path_alias',
    'field',
    'webform',
    'views',
    'geocoder',
    'localgov_forms',
    'localgov_forms_test',
  ];

  /**
   * The views used by this test.
   *
   * @var string[]
   */
  public static $testViews = ['localgov_forms_test_submission_data'];

  /**
   * Submission IDs keyed by a friendly label.
   *
   * @var int[]
   */
  protected array $sids = [];

  /**
   * {@inheritdoc}
   */
  protected function setUp($import_test_views = TRUE): void {
    // Skip the default views_test_config import; we provide our own view.
    parent::setUp(FALSE);

    $this->installEntitySchema('user');
    $this->installEntitySchema('path_alias');
    $this->installSchema('webform', ['webform']);
    $this->installConfig('webform');
    $this->installEntitySchema('webform_submission');

    ViewTestData::createTestViews(static::class, ['localgov_forms_test']);

    $this->createFixtures();
  }

  /**
   * Creates the test webforms and submissions.
   *
   * "postcode" is a top-level textfield (stored with property = '').
   * "delivery_address" is a webform_address composite element, whose
   * "postal_code" sub-field is stored as its own row (property = postal_code).
   * The same values are deliberately reused across the two columns so that an
   * assertion on the exact matched sid set proves the filter targets the right
   * column / property rather than accidentally matching either.
   */
  protected function createFixtures(): void {
    $elements = Yaml::encode([
      'postcode' => [
        '#type' => 'textfield',
        '#title' => 'Postcode',
      ],
      'delivery_address' => [
        '#type' => 'webform_address',
        '#title' => 'Delivery address',
      ],
    ]);

    $webform = Webform::create([
      'id' => 'lgf_test_form',
      'title' => 'LGF test form',
      'elements' => $elements,
    ]);
    $webform->save();

    $other_webform = Webform::create([
      'id' => 'lgf_other_form',
      'title' => 'LGF other form',
      'elements' => $elements,
    ]);
    $other_webform->save();

    $rows = [
      's1' => ['postcode' => 'BN1 1JE', 'address' => 'BN2 2AA'],
      's2' => ['postcode' => 'BN2 2AA', 'address' => 'BN1 1JE'],
      's3' => ['postcode' => 'LS1 4DL', 'address' => 'LS1 4DL'],
    ];
    foreach ($rows as $label => $data) {
      $submission = WebformSubmission::create([
        'webform_id' => $webform->id(),
        'data' => [
          'postcode' => $data['postcode'],
          'delivery_address' => ['postal_code' => $data['address']],
        ],
      ]);
      $submission->save();
      $this->sids[$label] = (int) $submission->id();
    }

    // A submission on a second webform, used to prove webform_id scoping.
    $other = WebformSubmission::create([
      'webform_id' => $other_webform->id(),
      'data' => ['postcode' => 'BN1 1JE'],
    ]);
    $other->save();
    $this->sids['other'] = (int) $other->id();
  }

  /**
   * Runs the test view with the given filter configuration.
   *
   * @param array $options
   *   Overrides for the filter handler options (webform_field_key,
   *   webform_property, webform_id).
   * @param string $value
   *   The value to filter on.
   * @param string $operator
   *   The string-filter operator (e.g. contains, starts, word).
   *
   * @return int[]
   *   The matched submission IDs, sorted ascending.
   */
  protected function runFilter(array $options, string $value, string $operator = 'contains'): array {
    $view = Views::getView('localgov_forms_test_submission_data');
    $view->setDisplay();
    $view->initHandlers();

    $handler = $view->filter['data_filter'];
    $handler->options = array_merge($handler->options, $options);
    $handler->operator = $operator;
    $handler->value = $value;

    $view->execute();

    $sids = array_map(static fn($row) => (int) $row->sid, $view->result);
    $view->destroy();
    sort($sids);
    return $sids;
  }

  /**
   * Filtering a top-level field targets its value, not the sid join key.
   *
   * @covers ::query
   */
  public function testTopLevelFieldValueMatch(): void {
    $result = $this->runFilter(
      ['webform_field_key' => 'postcode', 'webform_property' => ''],
      'BN1 1JE'
    );
    $this->assertSame([$this->sids['s1'], $this->sids['other']], $result);
  }

  /**
   * Composite sub-fields are isolated via the property condition.
   *
   * The address postal_code holding "BN1 1JE" lives in submission s2, while the
   * top-level postcode "BN1 1JE" lives in s1. Targeting the composite property
   * must return only s2.
   *
   * @covers ::query
   */
  public function testCompositeSubFieldIsolation(): void {
    $result = $this->runFilter(
      ['webform_field_key' => 'delivery_address', 'webform_property' => 'postal_code'],
      'BN1 1JE'
    );
    $this->assertSame([$this->sids['s2']], $result);
  }

  /**
   * A top-level filter must not leak into composite sub-rows.
   *
   * "BN2 2AA" exists as the top-level postcode of s2 and as the address
   * postal_code of s1. Filtering the top-level postcode (property = '') must
   * return only s2.
   *
   * @covers ::query
   */
  public function testTopLevelDoesNotMatchCompositeRows(): void {
    $result = $this->runFilter(
      ['webform_field_key' => 'postcode', 'webform_property' => ''],
      'BN2 2AA'
    );
    $this->assertSame([$this->sids['s2']], $result);
  }

  /**
   * The operator is still delegated to the parent string filter.
   *
   * @covers ::query
   */
  public function testOperatorPassthrough(): void {
    $result = $this->runFilter(
      ['webform_field_key' => 'postcode', 'webform_property' => ''],
      'LS1',
      'starts'
    );
    $this->assertSame([$this->sids['s3']], $result);
  }

  /**
   * The optional webform_id condition scopes the join to one webform.
   *
   * @covers ::query
   */
  public function testWebformIdScoping(): void {
    // Without scoping, "BN1 1JE" matches s1 and the other-webform submission.
    $unscoped = $this->runFilter(
      ['webform_field_key' => 'postcode', 'webform_property' => '', 'webform_id' => ''],
      'BN1 1JE'
    );
    $this->assertSame([$this->sids['s1'], $this->sids['other']], $unscoped);

    // Scoped to the other webform, only its submission matches.
    $scoped = $this->runFilter(
      ['webform_field_key' => 'postcode', 'webform_property' => '', 'webform_id' => 'lgf_other_form'],
      'BN1 1JE'
    );
    $this->assertSame([$this->sids['other']], $scoped);
  }

}
