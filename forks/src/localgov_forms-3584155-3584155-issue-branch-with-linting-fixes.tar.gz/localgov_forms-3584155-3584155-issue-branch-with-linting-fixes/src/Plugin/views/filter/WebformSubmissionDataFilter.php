<?php

namespace Drupal\localgov_forms\Plugin\views\filter;

use Drupal\Core\Form\FormStateInterface;
use Drupal\views\Plugin\views\filter\StringFilter;
use Drupal\views\Views;

/**
 * Filter on a field value stored in webform_submission_data.
 *
 * The standard "Contains" filter on a webform_submission_data column targets
 * the sid (the integer join key) rather than the value column, because the
 * view's existing relationship does not restrict the join to a specific field
 * key. This plugin adds its own LEFT JOIN to webform_submission_data with the
 * field key, property (for composite element sub-fields), and optionally the
 * webform ID baked into the join's extra conditions, then re-points
 * $this->tableAlias / $this->realField at the joined table's value column
 * before delegating to StringFilter::query().
 *
 * Composite element sub-fields (e.g. the postcode stored inside a
 * localgov_webform_uk_address element) are held as separate rows:
 * name = parent element key, property = sub-field key. Set webform_field_key
 * to the parent element key (e.g. "delivery_address") and webform_property
 * to the sub-field key (e.g. "postcode"). For top-level non-composite fields,
 * leave webform_property empty.
 *
 * Usage: expose this filter on the webform_submission table (via
 * hook_views_data_alter), add it to a view, and configure webform_field_key
 * and webform_property in the filter options. Multiple instances may coexist
 * in the same view as long as each targets a different field key/property pair.
 *
 * @ViewsFilter("localgov_forms_submission_data_filter")
 */
class WebformSubmissionDataFilter extends StringFilter {

  /**
   * {@inheritdoc}
   */
  protected function defineOptions() {
    $options = parent::defineOptions();
    $options['webform_field_key'] = ['default' => ''];
    $options['webform_property'] = ['default' => ''];
    $options['webform_id'] = ['default' => ''];
    return $options;
  }

  /**
   * {@inheritdoc}
   */
  public function buildOptionsForm(&$form, FormStateInterface $form_state) {
    $form['webform_field_key'] = [
      '#type' => 'textfield',
      '#title' => $this->t('Webform field key'),
      '#description' => $this->t('Machine name of the element as stored in the <em>name</em> column of webform_submission_data. For composite elements (e.g. address lookups) this is the parent element key (e.g. <code>delivery_address</code>), not the sub-field key.'),
      '#default_value' => $this->options['webform_field_key'],
      '#required' => TRUE,
      '#weight' => -10,
    ];

    $form['webform_property'] = [
      '#type' => 'textfield',
      '#title' => $this->t('Sub-field property (optional)'),
      '#description' => $this->t('For composite elements, the sub-field key as stored in the <em>property</em> column (e.g. <code>postcode</code>). Leave blank for top-level non-composite fields.'),
      '#default_value' => $this->options['webform_property'],
      '#required' => FALSE,
      '#weight' => -9,
    ];

    $form['webform_id'] = [
      '#type' => 'textfield',
      '#title' => $this->t('Webform ID (optional)'),
      '#description' => $this->t('Restrict the join to a specific webform. Leave blank to match across all webforms.'),
      '#default_value' => $this->options['webform_id'],
      '#required' => FALSE,
      '#weight' => -8,
    ];

    parent::buildOptionsForm($form, $form_state);
  }

  /**
   * {@inheritdoc}
   */
  public function query() {
    $field_key = $this->options['webform_field_key'];
    $property_key = $this->options['webform_property'] ?? '';

    $safe_key = preg_replace('/[^a-z0-9_]/', '_', strtolower($field_key));
    $alias = 'webform_submission_data__' . $safe_key;
    if ($property_key !== '') {
      $safe_prop = preg_replace('/[^a-z0-9_]/', '_', strtolower($property_key));
      $alias .= '__' . $safe_prop;
    }

    // Ensure the handler's own table (webform_submission) is in the query and
    // capture its alias as the left-hand side of the new join.
    $left_alias = $this->ensureMyTable();

    // Always include the property condition. For composite sub-fields this
    // matches the sub-field key; for top-level fields it matches '' (empty
    // string), which prevents accidentally hitting composite sub-rows with the
    // same parent element name.
    $extra = [
      ['field' => 'name', 'value' => $field_key],
      ['field' => 'property', 'value' => $property_key],
    ];
    if (!empty($this->options['webform_id'])) {
      $extra[] = ['field' => 'webform_id', 'value' => $this->options['webform_id']];
    }

    $join = Views::pluginManager('join')->createInstance('standard', [
      'table' => 'webform_submission_data',
      'field' => 'sid',
      'left_table' => $left_alias,
      'left_field' => 'sid',
      'extra' => $extra,
      'type' => 'LEFT',
    ]);

    $this->tableAlias = $this->query->addTable('webform_submission_data', $this->relationship, $join, $alias);
    $this->realField = 'value';

    parent::query();
  }

}
