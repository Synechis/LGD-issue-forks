<?php

namespace Drupal\localgov_microsites_group\Controller;

use Drupal\Component\Datetime\TimeInterface;
use Drupal\Component\Utility\DeprecationHelper;
use Drupal\Core\Access\AccessResult;
use Drupal\Core\Controller\ControllerBase;
use Drupal\Core\Plugin\Context\ContextRepositoryInterface;
use Drupal\Core\Session\AccountInterface;
use Drupal\Core\Url;
use Drupal\group\Entity\GroupInterface;
use Drupal\localgov_microsites_group\DomainFromGroupTrait;
use Drupal\localgov_microsites_group\RolesHelper;
use Drupal\user\UserInterface;
use Symfony\Component\DependencyInjection\ContainerInterface;
use Symfony\Component\HttpFoundation\RedirectResponse;
use Symfony\Component\HttpFoundation\Response;

/**
 * Redirect to current group admin page.
 */
class MicrositeAdminController extends ControllerBase {

  use DomainFromGroupTrait;

  /**
   * {@inheritdoc}
   */
  public static function create(ContainerInterface $container) {
    return new static(
      $container->get('context.repository'),
      $container->get('datetime.time'),
      // OneTimeAuthentication is available only on drupal 11.4.
      $container->has('Drupal\user\OneTimeAuthentication') ? $container->get('Drupal\user\OneTimeAuthentication') : NULL,
    );
  }

  /**
   * Initialise a MicrositeAdminController instance.
   *
   * @param \Drupal\Core\Plugin\Context\ContextRepositoryInterface $contextRepository
   *   The context repository service.
   * @param \Drupal\Component\Datetime\TimeInterface $time
   *   The time service.
   * @param object|null $oneTimeAuthentication
   *   The one time authentication service, available from Drupal 11.4.
   */
  public function __construct(
    protected ContextRepositoryInterface $contextRepository,
    protected TimeInterface $time,
    protected ?object $oneTimeAuthentication = NULL,
  ) {}

  /**
   * Redirect to microsite admin page /group/{group ID}.
   */
  public function redirectToMicrositeAdmin() {

    $group_id = $this->getGroupId();
    $url = Url::fromRoute('entity.group.canonical', ['group' => $group_id]);
    return new RedirectResponse($url->toString());
  }

  /**
   * Redicect to the one time login url on the target microsite.
   *
   * @param \Drupal\group\Entity\GroupInterface $group
   *   The target group.
   *
   * @return \Symfony\Component\HttpFoundation\Response
   *   The routing response.
   */
  public function redirectToMicrositeLogin(GroupInterface $group): Response {
    $domain = $this->getDomainFromGroup($group);
    if (!$domain) {
      $this->messenger()->addWarning($this->t('The microsite %label has no domain.', ['%label' => $group->label()]));
      return new RedirectResponse(Url::fromRoute('view.localgov_microsites_overview.collection')->toString());
    }

    $user = $this->entityTypeManager()->getStorage('user')->load($this->currentUser()->id());
    $one_time_url = $this->generateOneTimeLoginUrl($user);
    $one_time_url->setOption('base_url', rtrim($domain->getPath(), '/'));
    // Land on the microsite homepage after login.
    $one_time_url->setOption('query', [
      'destination' => Url::fromRoute('<front>', [], ['language' => $one_time_url->getOption('language')])->toString(),
    ]);
    return new RedirectResponse($one_time_url->toString());
  }

  /**
   * Generates an immediate one time login url for the given user.
   *
   * @param \Drupal\user\UserInterface $user
   *   The user to generate the login url for.
   *
   * @return \Drupal\Core\Url
   *   The one time login url.
   *
   * @todo Use \Drupal\user\OneTimeAuthentication directly when the minimum
   *   supported Drupal version is 11.4.
   * @see https://www.drupal.org/node/3581062
   */
  protected function generateOneTimeLoginUrl(UserInterface $user): Url {
    return DeprecationHelper::backwardsCompatibleCall(
      \Drupal::VERSION,
      '11.4',
      fn() => $this->oneTimeAuthentication->generateOneTimeLoginUrl($user, [], TRUE),
      function () use ($user) {
        $timestamp = $this->time->getCurrentTime();
        return Url::fromRoute('user.reset.login',
          [
            'uid' => $user->id(),
            'timestamp' => $timestamp,
            'hash' => user_pass_rehash($user, $timestamp),
          ],
          [
            'absolute' => TRUE,
            'language' => $this->languageManager()->getLanguage($user->getPreferredLangcode()),
          ]
        );
      },
    );
  }

  /**
   * Access check to the microsite login redirect.
   *
   * @param \Drupal\group\Entity\GroupInterface $group
   *   The target microsite.
   * @param \Drupal\Core\Session\AccountInterface $account
   *   The account to check access for.
   *
   * @return \Drupal\Core\Access\AccessResultInterface
   *   The access result.
   */
  public function accessMicrositeLogin(GroupInterface $group, AccountInterface $account) {
    // Allowed for members of the target microsite, microsites controllers and
    // user 1, only from the control site (no microsite in context).
    $allowed = $group->getGroupType()->id() === 'microsite' && $account->isAuthenticated() &&
      is_null($this->getGroupId()) && (
        (int) $account->id() === 1 ||
        in_array(RolesHelper::MICROSITES_CONTROLLER_ROLE, $account->getRoles(TRUE), TRUE) ||
        $group->getMember($account)
      );

    return AccessResult::allowedIf($allowed)
      ->cachePerUser()
      ->addCacheContexts(['url.site'])
      ->addCacheableDependency($group)
      ->addCacheTags(['group_relationship_list:plugin:group_membership:group:' . $group->id()]);
  }

  /**
   * Access check to microsite admin page redirect.
   *
   * @return \Drupal\Core\Access\AccessResultInterface
   *   The access result.
   */
  public function access() {

    if (!is_null($this->getGroupId())) {
      return AccessResult::allowed();
    }
    return AccessResult::forbidden();
  }

  /**
   * Tries to retrieve the current group id from the current context.
   *
   * @return int|null
   *   The group id or null.
   */
  protected function getGroupId(): int|null {
    $context_id = $this->config('group_sites.settings')->get('context_provider');
    if ($context_id === NULL) {
      return NULL;
    }

    $contexts = $this->contextRepository->getRuntimeContexts([$context_id]);

    $context = count($contexts) ? reset($contexts) : NULL;

    if ($group = $context?->getContextValue()) {
      if (!$group instanceof GroupInterface) {
        throw new \InvalidArgumentException('Context value is not a Group entity.');
      }
      return $group->id();
    }
    return NULL;
  }

}
