<?php

namespace Drupal\localgov_microsites_group\Hook;

use Drupal\Core\Hook\Attribute\Hook;
use Drupal\Core\StringTranslation\StringTranslationTrait;

/**
 * Provides views hooks related to Localgov microsite group.
 *
 * @package Drupal\localgov_microsites_group\Hook
 */
class Views {

  use StringTranslationTrait;

  /**
   * Implements hook_views_data().
   *
   * @phpstan-ignore-next-line Hook only exists from Drupal 11.1.
   */
  #[Hook('views_data')]
  public function viewsData(): array {
    // Add the Microsite domain link view field.
    $data['groups_field_data']['localgov_microsites_group_domain_link'] = [
      'title' => $this->t('Microsite domain'),
      'help' => $this->t('A link to the domain of the microsite'),
      'field' => [
        'id' => 'localgov_microsites_group_domain_link',
      ],
    ];

    return $data;
  }

}
