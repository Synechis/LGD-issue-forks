<?php

namespace Drupal\localgov_microsites_group\Hook;

use Drupal\Core\Cache\CacheableMetadata;
use Drupal\Core\Entity\EntityInterface;
use Drupal\Core\Hook\Attribute\Hook;
use Drupal\Core\Session\AccountInterface;
use Drupal\Core\StringTranslation\StringTranslationTrait;
use Drupal\Core\Url;

/**
 * Provides entity hooks related to Localgov microsite group.
 *
 * @package Drupal\localgov_microsites_group\Hook
 */
class Entity {

  use StringTranslationTrait;

  public function __construct(
    protected AccountInterface $currentUser,
  ) {}

  /**
   * Implements hook_entity_operation().
   *
   * @phpstan-ignore-next-line Hook only exists from Drupal 11.1.
   */
  #[Hook('entity_operation')]
  public function entityOperation(EntityInterface $entity, ?CacheableMetadata $cacheability = NULL): array {
    $operations = [];

    if ($entity->getEntityTypeId() == 'group') {
      $url = Url::fromRoute('localgov_microsites_group.microsite_login', ['group' => $entity->id()]);
      $access = $url->access($this->currentUser, TRUE);

      $cacheability?->addCacheableDependency($access);

      if ($access->isAllowed()) {
        $operations['microsite_login'] = [
          'title' => $this->t('Login'),
          'weight' => 20,
          'url' => $url,
        ];
      }
    }

    return $operations;
  }

}
