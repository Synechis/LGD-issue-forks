<?php

namespace Drupal\localgov_microsites_group\Plugin\views\field;

use Drupal\Core\Access\AccessResult;
use Drupal\Core\Url;
use Drupal\group\Entity\GroupInterface;
use Drupal\localgov_microsites_group\DomainFromGroupTrait;
use Drupal\views\Attribute\ViewsField;
use Drupal\views\Plugin\views\field\LinkBase;
use Drupal\views\ResultRow;

/**
 * Displays the domain URL associated with a Group entity.
 */
#[ViewsField("localgov_microsites_group_domain_link")]
class LocalgovMicrositesGroupDomainLink extends LinkBase {

  use DomainFromGroupTrait;

  /**
   * {@inheritdoc}
   */
  public function usesGroupBy(): bool {
    return FALSE;
  }

  /**
   * {@inheritdoc}
   */
  public function query(): void {
    // No extra query needed; we resolve the domain from the group entity.
  }

  /**
   * {@inheritdoc}
   */
  protected function getUrlInfo(ResultRow $row) {
    $group = $this->getEntity($row);
    if (!$group instanceof GroupInterface) {
      return NULL;
    }

    if ($group->getGroupType()->id() !== 'microsite') {
      return NULL;
    }

    $domain = $this->getDomainFromGroup($group);
    if (!$domain) {
      return NULL;
    }

    return Url::fromUri($domain->getScheme() . $domain->getHostname(), ['attributes' => ['target' => '_blank']]);
  }

  /**
   * {@inheritdoc}
   */
  protected function getDefaultLabel() {
    return $this->t('Microsite domain');
  }

  /**
   * {@inheritdoc}
   */
  protected function renderLink(ResultRow $row): string {
    $url = $this->getUrlInfo($row);
    if (!$url) {
      return '';
    }
    $this->options['alter']['make_link'] = TRUE;
    $this->options['alter']['url'] = $url;
    return !empty($this->options['text'])
      ? $this->sanitizeValue($this->options['text'])
      : $this->sanitizeValue($url->toString());
  }

  /**
   * {@inheritdoc}
   */
  protected function checkUrlAccess(ResultRow $row) {
    // The Url is always external, so return access allowed.
    return AccessResult::allowed();
  }

}
