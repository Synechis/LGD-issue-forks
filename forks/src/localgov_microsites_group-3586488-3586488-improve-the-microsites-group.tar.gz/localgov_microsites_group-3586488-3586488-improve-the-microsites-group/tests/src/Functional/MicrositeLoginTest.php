<?php

namespace Drupal\Tests\localgov_microsites_group\Functional;

use Drupal\Core\Url;
use Drupal\Tests\BrowserTestBase;
use Drupal\Tests\localgov_microsites_group\Traits\GroupCreationTrait;
use Drupal\Tests\localgov_microsites_group\Traits\InitializeGroupsTrait;
use Drupal\domain\DomainInterface;
use Drupal\localgov_microsites_group\DomainFromGroupTrait;
use Drupal\localgov_microsites_group\RolesHelper;
use Drupal\views\Entity\View;

/**
 * Tests the login from the control site to a microsite.
 *
 * @group localgov_microsites_group
 */
class MicrositeLoginTest extends BrowserTestBase {

  use InitializeGroupsTrait;
  use GroupCreationTrait, DomainFromGroupTrait {
    GroupCreationTrait::getEntityTypeManager insteadof DomainFromGroupTrait;
  }

  /**
   * {@inheritdoc}
   */
  protected bool $useOneTimeLoginLinks = FALSE;

  /**
   * Will be removed when issue #3204455 on Domain Site Settings gets merged.
   *
   * See https://www.drupal.org/project/domain_site_settings/issues/3204455.
   *
   * @var bool
   * @see \Drupal\Core\Config\Development\ConfigSchemaChecker
   * phpcs:disable DrupalPractice.Objects.StrictSchemaDisabled.StrictConfigSchema
   */
  protected $strictConfigSchema = FALSE;

  /**
   * Modules to enable.
   *
   * @var array
   */
  protected static $modules = [
    'group',
    'domain',
    'localgov_core',
    'localgov_media',
  ];

  /**
   * {@inheritdoc}
   */
  protected $defaultTheme = 'stark';

  /**
   * Microsites controller user.
   *
   * @var \Drupal\user\UserInterface
   */
  protected $controllerUser;

  /**
   * Member user of group 1.
   *
   * @var \Drupal\user\UserInterface
   */
  protected $memberUser1;

  /**
   * Authenticated user not member of any group.
   *
   * @var \Drupal\user\UserInterface
   */
  protected $otherUser;

  /**
   * {@inheritdoc}
   */
  protected function setUp(): void {
    parent::setUp();
    $this->container->get('module_installer')->install(['localgov_microsites_group']);
    $this->rebuildContainer();
    // Drupal 10 does not rebuild the router after installing the module when
    // it was already rebuilt during the install, so the routes of the views
    // installed afterwards are missing.
    // @todo Remove when the minimum supported version is Drupal 11.
    $this->container->get('router.builder')->rebuild();

    $owner = $this->createUser();
    $this->controllerUser = $this->createUser();
    $this->controllerUser->addRole(RolesHelper::MICROSITES_CONTROLLER_ROLE);
    $this->controllerUser->save();
    $this->memberUser1 = $this->createUser();
    $this->otherUser = $this->createUser();

    $this->createMicrositeGroups(['uid' => $owner->id()]);
    $this->groups[1]->addMember($this->memberUser1);
    $this->createMicrositeGroupsDomains($this->groups);
  }

  /**
   * Test the microsite login.
   *
   * Run as a single test to avoid the cost of a site install for each case.
   */
  public function testMicrositeLogin() {
    $this->doTestMicrositesOverview();
    $this->resetBrowserSession();
    $this->doTestMicrositeLoginAccess();
    $this->resetBrowserSession();
    $this->doTestMicrositeLoginRedirect();
    $this->resetBrowserSession();
    $this->doTestMicrositeLoginWithoutDomain();
  }

  /**
   * Test the domain and login links in the Microsites overview view.
   */
  protected function doTestMicrositesOverview(): void {
    $this->assertNotNull(View::load('localgov_microsites_overview'), 'The Microsites overview view is installed.');
    $this->assertCount(1, $this->container->get('router.route_provider')->getRoutesByNames(['view.localgov_microsites_overview.collection']), 'The Microsites overview route exists.');

    $this->drupalLogin($this->controllerUser);
    $this->drupalGet('admin/microsites');
    $this->assertSession()->statusCodeEquals(200);

    foreach ([1, 2] as $delta) {
      $domain = $this->getDomainFromGroup($this->groups[$delta]);
      assert($domain instanceof DomainInterface);
      $this->assertSession()->linkByHrefExists($domain->getScheme() . $domain->getHostname());
      $this->assertSession()->linkByHrefExists(Url::fromRoute('localgov_microsites_group.microsite_login', ['group' => $this->groups[$delta]->id()])->toString());
    }
  }

  /**
   * Test access to the microsite login route.
   */
  protected function doTestMicrositeLoginAccess(): void {
    $login_path = fn ($delta) => 'admin/microsite_login/' . $this->groups[$delta]->id();

    // Anonymous.
    $this->drupalGet($login_path(1));
    $this->assertSession()->statusCodeEquals(403);

    // Not a member of any microsite.
    $this->drupalLogin($this->otherUser);
    $this->drupalGet($login_path(1));
    $this->assertSession()->statusCodeEquals(403);
    $this->drupalLogout();

    // Member can only login to their microsite.
    $this->drupalLogin($this->memberUser1);
    $this->drupalGet($login_path(2));
    $this->assertSession()->statusCodeEquals(403);
    $this->drupalLogout();

    // Microsites controller can login to any microsite, but only from the
    // control site.
    $this->drupalLogin($this->controllerUser);
    $this->drupalGetNoRedirect($login_path(2));
    $this->assertSession()->statusCodeEquals(302);
    $domain1 = $this->getDomainFromGroup($this->groups[1]);
    assert($domain1 instanceof DomainInterface);
    $this->drupalGet($domain1->getUrl() . $login_path(2));
    $this->assertSession()->statusCodeEquals(403);
  }

  /**
   * Test the microsite login logs the user in on the microsite domain.
   */
  protected function doTestMicrositeLoginRedirect(): void {
    $domain1 = $this->getDomainFromGroup($this->groups[1]);
    assert($domain1 instanceof DomainInterface);
    $user_page = Url::fromRoute('user.page')->getInternalPath();

    $accounts = [
      'UID 1' => $this->rootUser,
      'microsites controller' => $this->controllerUser,
      'microsite member' => $this->memberUser1,
    ];
    foreach ($accounts as $name => $account) {
      $this->resetBrowserSession();

      // Not logged in on the microsite.
      $this->drupalGet($domain1->getUrl() . $user_page);
      $this->assertSession()->fieldExists('name');

      $this->drupalLogin($account);
      $this->drupalGetNoRedirect('admin/microsite_login/' . $this->groups[1]->id());
      $this->assertSession()->statusCodeEquals(302);
      $one_time_url = $this->getSession()->getResponseHeader('Location');
      $this->assertStringStartsWith($domain1->getPath() . 'user/reset/' . $account->id() . '/', $one_time_url, $name);
      $this->assertStringContainsString('/login?destination=', $one_time_url, $name);

      $this->resetBrowserSession();
      $this->drupalGetNoRedirect($one_time_url);
      $this->assertSession()->statusCodeEquals(302);
      // Redirected to the microsite homepage.
      $location = parse_url($this->getSession()->getResponseHeader('Location'));
      $this->assertSame(parse_url($domain1->getPath(), PHP_URL_HOST), $location['host'], $name);
      $this->assertSame(parse_url($domain1->getPath(), PHP_URL_PATH), $location['path'], $name);

      // Logged in on the microsite as the same user.
      $this->drupalGet($domain1->getUrl() . $user_page);
      $this->assertSession()->addressEquals(Url::fromUri('internal:/user')->toString() . '/' . $account->id());
    }
  }

  /**
   * Test the microsite login without a domain redirects to the overview.
   */
  protected function doTestMicrositeLoginWithoutDomain(): void {
    $group = $this->createGroup(['type' => 'microsite']);

    $this->drupalLogin($this->controllerUser);
    $this->drupalGet('admin/microsite_login/' . $group->id());
    $this->assertSession()->statusCodeEquals(200);
    $this->assertSession()->addressEquals('admin/microsites');
    $this->assertSession()->pageTextContains('has no domain');
  }

  /**
   * Starts a new anonymous browser session.
   */
  protected function resetBrowserSession(): void {
    $this->getSession()->reset();
    $this->loggedInUser = FALSE;
  }

  /**
   * Retrieves a Drupal path without following redirects.
   *
   * @param string $path
   *   The Drupal path to load.
   */
  protected function drupalGetNoRedirect(string $path): void {
    $client = $this->getSession()->getDriver()->getClient();
    $client->followRedirects(FALSE);
    // The redirect response markup also has a meta refresh tag.
    $meta_refresh_count = $this->maximumMetaRefreshCount;
    $this->maximumMetaRefreshCount = 0;
    $this->drupalGet($path);
    $this->maximumMetaRefreshCount = $meta_refresh_count;
    $client->followRedirects(TRUE);
  }

}
