<?php

namespace Drupal\Tests\localgov_microsites_group\Kernel;

use Drupal\Tests\group\Kernel\GroupKernelTestBase;
use Drupal\group\Entity\GroupRole;
use Drupal\localgov_microsites_group\RolesHelper;
use Drupal\node\Entity\NodeType;
use Drupal\taxonomy\Entity\Vocabulary;
use Drupal\user\Entity\Role;

/**
 * Tests roles are assigned the permissions a module declares when enabled.
 *
 * @group localgov_roles
 */
class ModuleRolesTest extends GroupKernelTestBase {

  /**
   * {@inheritdoc}
   */
  protected static $modules = [
    'domain',
    'domain_path',
    'entity_browser',
    'entity_browser_entity_form',
    'entity_reference_revisions',
    'field_formatter_class',
    'field_group',
    'file',
    'image',
    'media',
    'media_library',
    'geo_entity',
    'geofield',
    'gnode',
    'groupmedia',
    'group_content_menu',
    'group_sites',
    'layout_discovery',
    'layout_paragraphs',
    'layout_paragraphs_permissions',
    'node',
    'override_node_options',
    'paragraphs',
    'path_alias',
    'replicate',
    'taxonomy',
    'toolbar',
    'tour',
    'user',
    'views',
    'localgov_geo',
    'localgov_media',
    'localgov_microsites_group',
    'localgov_paragraphs_layout',
    'localgov_microsites_roles_test',
  ];

  /**
   * {@inheritdoc}
   */
  protected function setUp(): void {
    parent::setUp();

    // Set config that group_sites needs to run tests.
    $this->config('group_sites.settings')
      ->set('no_site_access_policy', 'group_sites.no_site_access_policy.do_nothing')
      ->set('site_access_policy', 'group_sites.site_access_policy.single')
      ->save();

    // The module's relationship type and group roles reference this bundle.
    NodeType::create([
      'type' => 'localgov_page',
      'name' => 'Page',
    ])->save();
    Vocabulary::create([
      'name' => 'Topics',
      'vid' => 'localgov_topic',
    ])->save();
    $this->enableModules(['group_term']);

    $this->installEntitySchema('file');
    $this->installEntitySchema('group_content_menu');
    $this->installEntitySchema('user');
    $this->installSchema('node', 'node_access');
    $this->installSchema('file', 'file_usage');

    $this->installConfig([
      'geo_entity',
      'gnode',
      'override_node_options',
      'user',
      'localgov_media',
      'localgov_paragraphs_layout',
      'localgov_microsites_group',
    ]);
  }

  /**
   * Test permissions are assigned as expected.
   */
  public function testPermissionsAssignedWhenEnablingModules() {
    // KernelTestBase enables $modules without hook_modules_installed().
    localgov_microsites_group_modules_installed(['localgov_microsites_roles_test'], FALSE);

    // Test global permissions.
    $microsites_controller = Role::load(RolesHelper::MICROSITES_CONTROLLER_ROLE);
    $this->assertFalse($microsites_controller->hasPermission('administer microsites roles test'));
    $this->assertTrue($microsites_controller->hasPermission('create microsites roles test'));
    $this->assertTrue($microsites_controller->hasPermission('delete microsites roles test'));
    $this->assertTrue($microsites_controller->hasPermission('edit microsites roles test'));
    $this->assertTrue($microsites_controller->hasPermission('view microsites roles test'));

    $microsites_trusted_editor = Role::load(RolesHelper::MICROSITES_EDITOR_ROLE);
    $this->assertFalse($microsites_trusted_editor->hasPermission('administer microsites roles test'));
    $this->assertTrue($microsites_trusted_editor->hasPermission('create microsites roles test'));
    $this->assertFalse($microsites_trusted_editor->hasPermission('delete microsites roles test'));
    $this->assertTrue($microsites_trusted_editor->hasPermission('edit microsites roles test'));
    $this->assertTrue($microsites_trusted_editor->hasPermission('view microsites roles test'));

    // Test microsite group permissions.
    $microsite_admin = GroupRole::load('microsite-' . RolesHelper::GROUP_ADMIN_ROLE);
    $this->assertTrue($microsite_admin->hasPermission('administer microsite roles test'));
    $this->assertTrue($microsite_admin->hasPermission('create microsite roles test'));
    $this->assertTrue($microsite_admin->hasPermission('delete microsite roles test'));
    $this->assertTrue($microsite_admin->hasPermission('edit microsite roles test'));
    $this->assertTrue($microsite_admin->hasPermission('view microsite roles test'));

    $microsite_anon = GroupRole::load('microsite-' . RolesHelper::GROUP_ANONYMOUS_ROLE);
    $this->assertFalse($microsite_anon->hasPermission('administer microsite roles test'));
    $this->assertFalse($microsite_anon->hasPermission('create microsite roles test'));
    $this->assertFalse($microsite_anon->hasPermission('delete microsite roles test'));
    $this->assertFalse($microsite_anon->hasPermission('edit microsite roles test'));
    $this->assertTrue($microsite_anon->hasPermission('view microsite roles test'));

    $microsite_member = GroupRole::load('microsite-' . RolesHelper::GROUP_MEMBER_ROLE);
    $this->assertFalse($microsite_member->hasPermission('administer microsite roles test'));
    $this->assertTrue($microsite_member->hasPermission('create microsite roles test'));
    $this->assertTrue($microsite_member->hasPermission('delete microsite roles test'));
    $this->assertTrue($microsite_member->hasPermission('edit microsite roles test'));
    $this->assertTrue($microsite_member->hasPermission('view microsite roles test'));

    $microsite_outsider = GroupRole::load('microsite-' . RolesHelper::GROUP_OUTSIDER_ROLE);
    $this->assertFalse($microsite_outsider->hasPermission('administer microsite roles test'));
    $this->assertFalse($microsite_outsider->hasPermission('create microsite roles test'));
    $this->assertFalse($microsite_outsider->hasPermission('delete microsite roles test'));
    $this->assertFalse($microsite_outsider->hasPermission('edit microsite roles test'));
    $this->assertTrue($microsite_outsider->hasPermission('view microsite roles test'));
  }

}
