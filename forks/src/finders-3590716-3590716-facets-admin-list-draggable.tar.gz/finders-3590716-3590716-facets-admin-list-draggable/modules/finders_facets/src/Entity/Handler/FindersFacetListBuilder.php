<?php

namespace Drupal\finders_facets\Entity\Handler;

use Drupal\Core\Entity\DraggableListBuilderTrait;
use Drupal\Core\Entity\EntityInterface;
use Drupal\Core\Entity\EntityListBuilder;
use Drupal\Core\Entity\EntityStorageInterface;
use Drupal\Core\Entity\EntityTypeInterface;
use Drupal\Core\Form\FormInterface;
use Drupal\Core\Form\FormStateInterface;

/**
 * Provides the list builder handler for the Finders Facet entity.
 */
class FindersFacetListBuilder extends EntityListBuilder implements FormInterface {

  use DraggableListBuilderTrait {
    buildHeader as traitBuildHeader;
    buildRow as traitBuildRow;
    buildForm as traitBuildForm;
    submitForm as traitSubmitForm;
  }

  /**
   * {@inheritdoc}
   */
  protected const SORT_KEY = 'weight';

  /**
   * {@inheritdoc}
   */
  public function __construct(EntityTypeInterface $entity_type, EntityStorageInterface $storage) {
    parent::__construct($entity_type, $storage);

    $this->formBuilder = \Drupal::formBuilder();

    $this->weightKey = 'weight';

    // Disable limit to load all entities for full drag-and-drop support.
    $this->limit = FALSE;
  }

  /**
   * {@inheritdoc}
   */
  public function getFormId() {
    return 'finders_facets_list';
  }

  /**
   * {@inheritdoc}
   */
  public function buildForm(array $form, FormStateInterface $form_state) {
    $form = $this->traitBuildForm($form, $form_state);

    $total = $this->getStorage()
      ->getQuery()
      ->count()
      ->accessCheck(TRUE)
      ->execute();

    $form['summary']['#markup'] = $this->t('Total finder facets: @total', ['@total' => $total]);

    return $form;
  }

  /**
   * {@inheritdoc}
   */
  public function buildHeader() {
    $header['id'] = $this->t('ID');
    $header['bundle'] = $this->t('Facet Type');
    $header['title'] = $this->t('Title');
    $header['author'] = $this->t('Author');
    return $header + $this->traitBuildHeader();
  }

  /**
   * {@inheritdoc}
   */
  public function buildRow(EntityInterface $entity) {
    $row['id'] = [
      '#markup' => $entity->id(),
    ];
    $row['bundle'] = [
      // @todo Change to using getBundleEntity() when 11.3 is our minimum core
      // version. See https://www.drupal.org/node/2699835.
      '#markup' => $entity->type->entity->label(),
    ];
    $row['title'] = [
      '#type' => 'link',
      '#title' => $entity->label(),
      '#url' => $entity->toUrl('edit-form'),
    ];
    $row['uid']['data'] = [
      '#theme' => 'username',
      '#account' => $entity->getOwner(),
    ];
    return $row + $this->traitBuildRow($entity);
  }

  /**
   * {@inheritdoc}
   */
  protected function getWeight(EntityInterface $entity): int|float {
    return $entity->weight->value;
  }

  /**
   * {@inheritdoc}
   */
  protected function setWeight(EntityInterface $entity, int|float $weight): EntityInterface {
    $entity->weight = $weight;
    return $entity;
  }

  /**
   * {@inheritdoc}
   */
  public function submitForm(array &$form, FormStateInterface $form_state) {
    $this->traitSubmitForm($form, $form_state);

    $this->messenger()->addStatus($this->t('The facet weights have been saved.'));
  }

}
