# LocalGov Restricted Content

Restricts content access to signed-in users.

When a content type is configured for restriction, editors can mark individual pages as restricted. Anonymous users will see a sign-in prompt instead of the page content, and the page lede (subtitle/description) will be hidden.

Restriction is inherited for supported content relationships: if a parent page is restricted, child pages that reference it are automatically restricted.

## Features

- Configurable per content type — choose which content types support restriction
- Inherited restriction — child content inherits restriction from parent pages
- Anonymous view modes — optionally define separate view modes for anonymous users
- Sign-in prompts — displays a sign-in link and message to anonymous users on restricted content
- Page lede hidden — hides the page description for anonymous users on restricted pages
- Condition plugin — a `Restricted Content` condition is available for use in block visibility and layout builder rules

## Installation

```bash
composer require drupal/localgov_restricted_content
```

Enable the module:

```bash
drush en localgov_restricted_content
```

## Configuration

Visit `/admin/config/content/restricted-content` to select which content types support restriction. The `localgov_news_article` and `localgov_newsroom` content types are enabled by default.

### Anonymous view modes

For each restricted content type, you can optionally create a view mode named `{view_mode}_anonymous` (e.g. `full_anonymous`, `teaser_anonymous`). When an anonymous user views restricted content, the module will automatically switch to the anonymous view mode if one exists for the current view mode.

### Sign-in prompts

Two extra display fields are available for each configured content type in **Manage display**:

- **Sign in link for listings** — use on teasers and cards; renders a sign-in link
- **Sign in link for pages** — use on full page views; renders a sign-in link with the message "This page is restricted, please sign in to see the full page."

Enable these fields in the relevant view mode's display settings. They are hidden by default.

### Block visibility

The **Restricted Content** condition plugin is available for use in block visibility rules and Layout Builder section conditions. It returns false when an anonymous user is viewing restricted content, and can be negated.

## Restricting content

When a content type is configured, editors will see a **Restricted content** checkbox on the node edit form. Checking this restricts the page to signed-in users only.

If the page's parent is already restricted, the checkbox is disabled and a note explains that restriction is inherited from the parent.

### Inherited restriction

Restriction inheritance is checked by looking for a known parent reference field on the node. The following parent relationships are supported:

| Parent field | Example relationship |
|---|---|
| `localgov_newsroom` | News article → Newsroom |
| `localgov_guides_parent` | Guide page → Guides |
| `localgov_services_parent` | Service page → Services |
| `localgov_step_parent` | Step → Guide or Service |
| `localgov_subsites_parent` | Subsite page → Subsite |

Content types that do not use one of these fields to reference a parent will not inherit restriction.

## Maintainers

- [Adrian Bateman](https://www.drupal.org/u/polynya)
- [Duncan Davidson](https://www.drupal.org/u/duncandavidson)

## Support

- [Issue queue](https://www.drupal.org/project/issues/localgov_restricted_content)
- [LocalGov Drupal Slack](https://localgovdrupal.org/community/slack)
