<?php

declare(strict_types=1);

namespace Drupal\localgov_waste_collection\Controller;

use Drupal\Component\Utility\Unicode;
use Drupal\Core\Config\Config;
use Drupal\Core\Config\ConfigFactoryInterface;
use Drupal\Core\Controller\ControllerBase;
use Drupal\Core\Form\FormBuilderInterface;
use Drupal\Core\TempStore\PrivateTempStore;
use Drupal\Core\TempStore\PrivateTempStoreFactory;
use Drupal\Core\Url;
use Drupal\localgov_waste_collection\DataProviderManager;
use Drupal\localgov_waste_collection\Exception\PostcodeSearchException;
use Drupal\localgov_waste_collection\Service\CollectionDateParser;
use Drupal\localgov_waste_collection\Service\PublicHolidays;
use Spatie\IcalendarGenerator\Components\Calendar;
use Spatie\IcalendarGenerator\Components\Event;
use Spatie\IcalendarGenerator\Enums\RecurrenceFrequency;
use Spatie\IcalendarGenerator\ValueObjects\RRule;
use Symfony\Component\DependencyInjection\ContainerInterface;
use Symfony\Component\HttpFoundation\RedirectResponse;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\ResponseHeaderBag;
use Symfony\Component\HttpFoundation\StreamedResponse;

/**
 * Waste collection schedule controller.
 *
 * @package Drupal\localgov_waste_collection\Controller
 */
class WasteCollectionController extends ControllerBase {

  /**
   * The data provider plugin manager.
   *
   * @var \Drupal\localgov_waste_collection\DataProviderManager
   */
  protected $dataProviderManager;

  /**
   * The configuration factory.
   *
   * @var \Drupal\Core\Config\ConfigFactoryInterface
   */
  protected $configFactory;

  /**
   * The data provider plugin.
   *
   * @var \Drupal\localgov_waste_collection\DataProviderBase
   */
  protected $dataProvider;

  /**
   * The form builder interface.
   *
   * @var \Drupal\Core\Form\FormBuilderInterface
   */
  protected $formBuilder;

  /**
   * The public holiday provider.
   *
   * @var \Drupal\localgov_waste_collection\Service\PublicHolidays
   */
  protected $publicHolidays;

  /**
   * The collection date parser.
   *
   * @var \Drupal\localgov_waste_collection\Service\CollectionDateParser
   */
  protected CollectionDateParser $collectionDateParser;

  /**
   * Private temp storage.
   */
  private PrivateTempStore $tempStore;

  /**
   * The configuration object.
   *
   * @var \Drupal\Core\Config\Config
   */
  private Config $config;

  /**
   * Constructor.
   */
  public function __construct(PrivateTempStoreFactory $temp_store_factory, DataProviderManager $dataProviderManager, ConfigFactoryInterface $configFactory, FormBuilderInterface $formBuilder, PublicHolidays $publicHolidays, CollectionDateParser $collectionDateParser) {
    $this->tempStore = $temp_store_factory->get('localgov_waste_collection_schedule');
    $this->dataProviderManager = $dataProviderManager;
    $this->configFactory = $configFactory;
    $this->formBuilder = $formBuilder;
    $this->publicHolidays = $publicHolidays;
    $this->collectionDateParser = $collectionDateParser;

    $this->config = $this->configFactory->get('localgov_waste_collection.settings');
    $plugin_id = $this->config->get('active_data_provider');
    $this->dataProvider = $this->dataProviderManager->createInstance($plugin_id);
  }

  /**
   * {@inheritdoc}
   */
  public static function create(ContainerInterface $container) {
    return new static(
      $container->get('tempstore.private'),
      $container->get('plugin.manager.localgov_waste_collection.data_provider'),
      $container->get('config.factory'),
      $container->get('form_builder'),
      $container->get('localgov_waste_collection.public_holidays_provider'),
      $container->get('localgov_waste_collection.collection_date_parser'),
    );
  }

  /**
   * Get the formatted display time from config.
   *
   * @return string
   *   The formatted time (e.g., "6:00 AM").
   */
  private function getFormattedCollectionTime($unformattedTime): string {
    return \DateTime::createFromFormat('H:i:s', $unformattedTime)->format('g:i A');
  }

  /**
   * Display the postcode form.
   *
   * @return array
   *   Drupal render array
   */
  public function showForm(?Request $request): array {
    $form = $this->formBuilder->getForm('Drupal\localgov_waste_collection\Form\PostcodeForm');
    $build['#form'] = $form;

    $build['#theme'] = 'localgov_waste_collection_form';

    // Ensure that anonymous users can view any error messages that may be set
    // in the tempstore.
    $build['#cache']['contexts'][] = 'session';

    if ($this->tempStore->get('noresults_postcode')) {
      $build['#noresults'] = $this->tempStore->get('noresults_postcode');
      $this->tempStore->delete('noresults_postcode');
    }
    return $build;
  }

  /**
   * Display the results of a postcode search.
   *
   * @return array|RedirectResponse
   *   Drupal render array or redirect back to form.
   */
  public function getAddresses(Request $request): array|RedirectResponse {
    $query_parameters = $request->query->all();
    $postcode = urldecode($query_parameters["postcode"]);

    $properties = [];
    try {
      $properties = $this->dataProvider->findAddressesByPostcode($postcode);
    }
    catch (PostcodeSearchException $e) {
      // @todo This contradicts the 'No properties found for postcode...'
      // message which is output when there are not properties found!
      $this->messenger()
        ->addError($this->t('There was a problem with the postcode search. Please try again later.'));
    }

    if (empty($properties)) {
      $this->tempStore->set('noresults_postcode', $postcode);
      return $this->redirect('localgov_waste_collection.form');
    }

    $form = $this->formBuilder->getForm('Drupal\localgov_waste_collection\Form\AddressSelectForm', $properties);

    $build[] = [
      '#form' => $form,
      '#theme' => 'localgov_waste_collection_property_list',
      '#postcode' => $postcode,
      '#properties' => $properties,
    ];

    return $build;
  }

  /**
   * View the collection schedule for a UPRN.
   *
   * @param string $uprn
   *   UPRN to lookup.
   *
   * @return array
   *   Drupal render array
   */
  public function viewSchedule(string $uprn): array {
    $build = [];
    $collections = $this->dataProvider->getCollections($uprn);

    if ($this->config->get('public_holidays')) {
      $publicHolidays = $this->publicHolidays->getPublicHolidays();
      foreach ($collections["dates"] as $key => $values) {
        $formattedDate = date('d-m-Y', strtotime($values["date"]));
        $holiday = $publicHolidays[$formattedDate] ?? NULL;
        $collections["dates"][$key]["holiday"] = $holiday;
      }
    }

    // Assemble the collection type labels of next collection day.
    $first_collection_date = NULL;
    $next_collection_labels = [];
    foreach ($collections['dates'] as $collection) {
      // Store the first date that's in the future.
      if (is_null($first_collection_date) && strtotime($collection['date']) > strtotime('today')) {
        $first_collection_date = $collection['date'];
      }

      if ($collection['date'] == $first_collection_date) {
        $next_collection_labels[] = $collection['type']['label'] ?? $collection['type']['name'];
      }
    }
    if ($first_collection_date) {
      $build['#next_collection_date'] = strtotime($first_collection_date);
      $build['#next_collection_labels'] = $next_collection_labels;
    }

    // Assemble the calendar range label.
    if (!empty($collections['dates'])) {
      $first_collection_timestamp = strtotime(reset($collections['dates'])['date']);
      $last_collection_timestamp = strtotime(end($collections['dates'])['date']);
      $build['#calendar_range_label'] = $this->t('@start-month to @end-month', [
        '@start-month' => date(
            date('Y', $first_collection_timestamp) == date('Y', $last_collection_timestamp) ? 'F' : 'F Y',
            $first_collection_timestamp,
        ),
        '@end-month' => date('F Y', $last_collection_timestamp),
      ]);
    }

    $dates = [];
    $colour_theme_keys = [];
    foreach ($collections['dates'] as $index => $collection) {
      if (!isset($colour_theme_keys[$collection['type']['colour']])) {
        $colour_theme_keys[$collection['type']['colour']] = preg_replace('/[^[:alnum:]]/', '_', strtolower($collection['type']['colour']));
      }
      $dates[$index] = [
        '#theme' => [
          'localgov_waste_collection_collection_item__' . $colour_theme_keys[$collection['type']['colour']],
          'localgov_waste_collection_collection_item',
        ],
        '#date' => $collection['date'],
        '#label' => $collection['type']['label'] ?? $collection['type']['name'],
        '#holiday' => $collection['holiday'] ?? FALSE,
        '#colour' => $collection['type']['colour'],
        '#colour_name' => $colour_theme_keys[$collection['type']['colour']],
        '#service_updates_path' => $this->config->get('service_updates_path') ?? '/',
      ];
    }

    $build['#dates'] = $dates;

    if (!empty($collections) && $address = $this->dataProvider->getAddressFromUprn($uprn)) {
      $collectionTime = $collections['collection_time'] ?? $this->config->get('collection_time') ?: '06:00:00';

      $build['#address'] = $address;
      $build['#uprn'] = $uprn;
      $build['#service_updates_path'] = $this->config->get('service_updates_path') ?? '/';
      $build['#collection_time'] = $this->getFormattedCollectionTime($collectionTime);
      $build['#collections'] = $collections;
      $build['#show_ics_download'] = (bool) ($this->config->get('show_ics_download') ?? FALSE);
      $build['#show_webcal_subscribe'] = (bool) ($this->config->get('show_webcal_subscribe') ?? TRUE);
      $subscribeUrl = Url::fromRoute('localgov_waste_collection.subscribe', ['uprn' => $uprn], ['absolute' => TRUE])->toString();
      $build['#webcal_url'] = preg_replace('/^https?:\/\//', 'webcal://', $subscribeUrl);
      if (isset($collections["pdf"])) {
        $build['#pdf'] = $collections["pdf"];
      }
    }
    else {
      $build['#retrievalError'] = $this->t('Collection schedule could not be retrieved.');
    }

    $build['#theme'] = 'localgov_waste_collection_view_schedule';
    return $build;
  }

  /**
   * Download the collection schedule for a UPRN as a .ics file.
   *
   * @param string $uprn
   *   UPRN to lookup.
   *
   * @return \Symfony\Component\HttpFoundation\StreamedResponse
   *   Streamed response
   */
  public function downloadSchedule(string $uprn): StreamedResponse {
    $response = new StreamedResponse();
    $collections = $this->dataProvider->getCollections($uprn);
    if (!empty($collections)) {
      $contentDisposition = $response->headers->makeDisposition(ResponseHeaderBag::DISPOSITION_ATTACHMENT, $uprn . '.ics');
      $response->headers->set('Content-Type', 'text/calendar; charset=utf-8');
      $response->headers->set('Content-Disposition', $contentDisposition);
      $response->setCallback(function () use ($uprn, $collections): void {
        $calendar = $this->buildCalendar($uprn, $collections, TRUE);
        echo $calendar->get();
      });
    }
    return $response;
  }

  /**
   * Subscribe to the collection schedule for a UPRN via an ICS feed.
   *
   * @param string $uprn
   *   UPRN to lookup.
   *
   * @return \Symfony\Component\HttpFoundation\StreamedResponse
   *   Streamed response
   */
  public function subscribeToSchedule(string $uprn): StreamedResponse {
    $response = new StreamedResponse();
    $collections = $this->dataProvider->getCollections($uprn);
    if (!empty($collections)) {
      $response->headers->set('Content-Type', 'text/calendar; charset=utf-8');
      $response->setCallback(function () use ($uprn, $collections): void {
        $calendar = $this->buildCalendar($uprn, $collections, FALSE);
        echo $calendar->get();
      });
    }
    return $response;
  }

  /**
   * Build a Calendar object with collection events.
   *
   * @param string $uprn
   *   The UPRN for the property.
   * @param array $collections
   *   The collection data from the data provider.
   * @param bool $includeReminder
   *   Whether to include the re-download reminder event.
   *
   * @return \Spatie\IcalendarGenerator\Components\Calendar
   *   The built calendar.
   */
  private function buildCalendar(string $uprn, array $collections, bool $includeReminder): Calendar {
    date_default_timezone_set('Europe/London');
    $calendar = Calendar::create((string) $this->t('Bin collection dates'));

    $titleFormat = $this->config->get('ics_event_title_format') ?: '@colour lidded bins for @label';
    $descriptionFormat = $this->config->get('ics_event_description_format') ?: 'Please make sure you have your bin or sacks out by @time ready for collection.';
    $alertFormat = $this->config->get('ics_event_alert_format') ?: '@colour lidded bins for @label';
    $collectionTime = $collections['collection_time'] ?? $this->config->get('collection_time') ?: '06:00:00';
    $displayTime = $this->getFormattedCollectionTime($collectionTime);
    $plannedCollections = $this->splitRecurringAndOneOffCollections($collections['dates'] ?? []);

    // Using UPRN for the event uid means users can add multiple properties,
    // and refresh an existing calendar without adding dupes.
    foreach ($plannedCollections['series'] as $series) {
      $collection = $series['first'];
      $collectionDate = $this->collectionDateParser->parseCollectionDate($collection);
      if ($collectionDate === NULL) {
        continue;
      }
      $collectionLabel = $collection['type']['label'] ?? $collection['type']['name'];
      $replacements = [
        '@time' => $displayTime,
        '@colour' => $collection["type"]["colour"],
        '@label' => $collectionLabel,
      ];

      $rrule = RRule::frequency(RecurrenceFrequency::weekly())
        ->interval($series['interval_weeks'])
        ->times($series['count']);

      $uidSeed = strtolower($collection['type']['colour'] . '-' . $collectionLabel . '-weekly-' . $series['interval_weeks']);
      $uidSuffix = preg_replace('/[^[:alnum:]]+/', '-', $uidSeed);

      $event = Event::create(Unicode::ucfirst((string) $this->replaceEventPlaceholders($titleFormat, $replacements)))
        ->startsAt(new \DateTime($collectionDate->format('Y-m-d') . ' ' . $collectionTime))
        ->uniqueIdentifier($uprn . '-series-' . trim((string) $uidSuffix, '-'))
        ->description($this->replaceEventPlaceholders($descriptionFormat, $replacements))
        ->rrule($rrule)
        ->alertMinutesBefore(720, $this->replaceEventPlaceholders($alertFormat, $replacements));
      $calendar->event($event);
    }

    foreach ($plannedCollections['one_off'] as $collection) {
      $collectionDate = $this->collectionDateParser->parseCollectionDate($collection);
      if ($collectionDate === NULL) {
        continue;
      }
      $collectionLabel = $collection['type']['label'] ?? $collection['type']['name'];
      $replacements = [
        '@time' => $displayTime,
        '@colour' => $collection["type"]["colour"],
        '@label' => $collectionLabel,
      ];

      $event = Event::create(Unicode::ucfirst((string) $this->replaceEventPlaceholders($titleFormat, $replacements)))
        ->startsAt(new \DateTime($collectionDate->format('Y-m-d') . ' ' . $collectionTime))
        ->uniqueIdentifier($uprn . '-' . $collection["date"] . '-' . $collection["type"]["colour"])
        ->description($this->replaceEventPlaceholders($descriptionFormat, $replacements))
        ->alertMinutesBefore(720, $this->replaceEventPlaceholders($alertFormat, $replacements));
      $calendar->event($event);
    }

    if ($includeReminder) {
      $lastCollection = end($collections["dates"]);
      $lastCollectionDate = $this->collectionDateParser->parse($lastCollection["date"] ?? NULL);
      if ($lastCollectionDate === NULL) {
        return $calendar;
      }
      $reminderDate = new \DateTime($lastCollectionDate->format('Y-m-d') . ' 18:00:00');
      $reminderDate->modify('-2 weeks');
      $calendarLink = Url::fromRoute('localgov_waste_collection.download', ['uprn' => $uprn], ['absolute' => 'true'])
        ->toString();
      $event = Event::create((string) $this->t('Download your bin collection calendar'))
        ->startsAt($reminderDate)
        ->uniqueIdentifier($uprn . '-reminder-' . $lastCollection["date"])
        ->description((string) $this->t('Your bin collection calendar information expires in 14 days. Go to @calendarlink to update your calendar.', ['@calendarlink' => $calendarLink]))
        ->alertAt(
          $reminderDate,
          (string) $this->t('Update your bin collection calendar')
        );
      $calendar->event($event);
    }

    return $calendar;
  }

  /**
   * Split collection rows into recurring series and one-off dates.
   *
   * @param array $dates
   *   Flat collection dates array from the provider.
   *
   * @return array
   *   Array with `series` and `one_off` keys.
   */
  private function splitRecurringAndOneOffCollections(array $dates): array {
    $grouped = [];
    $oneOff = [];

    foreach ($dates as $collection) {
      $type = $collection['type'] ?? [];
      $colour = $type['colour'] ?? '';
      $label = $type['label'] ?? ($type['name'] ?? '');
      $collectionDate = $this->collectionDateParser->parseCollectionDate($collection);

      if ($collectionDate === NULL || $colour === '' || $label === '') {
        $oneOff[] = $collection;
        continue;
      }

      $key = strtolower($colour . '|' . $label . '|' . $collectionDate->format('N'));
      $grouped[$key][] = $collection;
    }

    $series = [];
    foreach ($grouped as $collectionsByType) {
      usort($collectionsByType, function ($a, $b) {
        $dateA = $this->collectionDateParser->parseCollectionDate($a);
        $dateB = $this->collectionDateParser->parseCollectionDate($b);

        if ($dateA === NULL && $dateB === NULL) {
          return 0;
        }
        if ($dateA === NULL) {
          return 1;
        }
        if ($dateB === NULL) {
          return -1;
        }

        return $dateA->getTimestamp() <=> $dateB->getTimestamp();
      });

      $intervalWeeks = $this->detectWeeklyInterval($collectionsByType);
      if ($intervalWeeks === NULL) {
        $oneOff = array_merge($oneOff, $collectionsByType);
        continue;
      }

      $series[] = [
        'first' => $collectionsByType[0],
        'count' => count($collectionsByType),
        'interval_weeks' => $intervalWeeks,
      ];
    }

    return [
      'series' => $series,
      'one_off' => $oneOff,
    ];
  }

  /**
   * Detect a consistent weekly interval for a list of collection rows.
   *
   * Returns NULL when the sequence is too short or irregular.
   *
   * @param array $collectionsByType
   *   Ordered list of collection rows for one type.
   *
   * @return int|null
   *   Weekly interval for RRULE, or NULL.
   */
  private function detectWeeklyInterval(array $collectionsByType): ?int {
    if (count($collectionsByType) < 3) {
      return NULL;
    }

    $expectedDays = NULL;
    $previousDate = NULL;

    foreach ($collectionsByType as $collection) {
      $currentDate = $this->collectionDateParser->parseCollectionDate($collection);
      if ($currentDate === NULL) {
        return NULL;
      }

      if ($previousDate !== NULL) {
        $differenceDays = (int) $previousDate->diff($currentDate)->format('%a');
        if ($differenceDays <= 0) {
          return NULL;
        }

        if ($expectedDays === NULL) {
          $expectedDays = $differenceDays;
        }
        elseif ($expectedDays !== $differenceDays) {
          return NULL;
        }
      }

      $previousDate = $currentDate;
    }

    if ($expectedDays === NULL || $expectedDays < 7 || $expectedDays % 7 !== 0) {
      return NULL;
    }

    return (int) ($expectedDays / 7);
  }

  /**
   * Replace placeholders in event format strings.
   *
   * @param string $format
   *   The format string with placeholders.
   * @param array $replacements
   *   Array of placeholder => value pairs.
   *
   * @return string
   *   The formatted string with placeholders replaced.
   */
  private function replaceEventPlaceholders(string $format, array $replacements): string {
    return str_replace(array_keys($replacements), array_values($replacements), $format);
  }

}
