<?php

declare(strict_types=1);

namespace Drupal\localgov_waste_collection\Service;

/**
 * Parses collection dates from provider payloads.
 */
class CollectionDateParser {

  /**
   * Parse a provider collection row into a DateTimeImmutable instance.
   *
   * @param array $collection
   *   Collection row from a provider.
   *
   * @return \DateTimeImmutable|null
   *   Parsed date, or NULL if the value cannot be interpreted safely.
   */
  public function parseCollectionDate(array $collection): ?\DateTimeImmutable {
    return $this->parse($collection['date'] ?? NULL);
  }

  /**
   * Parse a provider date value into a DateTimeImmutable instance.
   *
   * Supports common provider formats and falls back to strtotime for more
   * permissive handling.
   *
   * @param mixed $date
   *   Raw provider date value.
   *
   * @return \DateTimeImmutable|null
   *   Parsed date, or NULL if the value cannot be interpreted safely.
   */
  public function parse(mixed $date): ?\DateTimeImmutable {
    if ($date instanceof \DateTimeImmutable) {
      return $date;
    }

    if ($date instanceof \DateTimeInterface) {
      return \DateTimeImmutable::createFromInterface($date);
    }

    if (is_int($date)) {
      return (new \DateTimeImmutable())->setTimestamp($date);
    }

    if (!is_string($date)) {
      return NULL;
    }

    $date = trim($date);
    if ($date === '') {
      return NULL;
    }

    foreach (['d-m-Y', 'Y-m-d', 'd/m/Y', 'Y/m/d', 'd.m.Y', 'Y.m.d', 'm/d/Y', 'm-d-Y'] as $format) {
      $parsedDate = \DateTimeImmutable::createFromFormat($format, $date);
      $errors = \DateTimeImmutable::getLastErrors() ?: ['warning_count' => 0, 'error_count' => 0];
      if ($parsedDate !== FALSE && $errors['warning_count'] === 0 && $errors['error_count'] === 0) {
        return $parsedDate;
      }
    }

    $timestamp = strtotime($date);
    if ($timestamp === FALSE) {
      return NULL;
    }

    return (new \DateTimeImmutable())->setTimestamp($timestamp);
  }

}
