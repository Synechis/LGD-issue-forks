<?php

namespace Drupal\Tests\localgov_waste_collection\Functional;

use Drupal\Core\Url;
use Drupal\Tests\BrowserTestBase;
use Symfony\Component\HttpFoundation\Response;

/**
 * Tests the ICS file download for a given UPRN.
 *
 * Note: the example provider uses a fixed fixture UPRN for its test data.
 * This is intentionally example-only and should not be treated as a real-world
 * UPRN that exists in production or other provider datasets.
 *
 * @group localgov_waste_collection
 */
class DownloadCalendarTest extends BrowserTestBase {

  /**
   * The example provider uses a fixed fixture UPRN for its test data.
   *
   * This is intentionally tied to the example dataset and is not a real-world
   * UPRN that will exist for other councils or providers.
   */
  private const EXAMPLE_PROVIDER_UPRN = '12345674';

  /**
   * {@inheritdoc}
   */
  protected $defaultTheme = 'stark';

  /**
   * Modules to enable.
   *
   * @var array
   */
  protected static $modules = [
    'localgov_waste_collection',
    'localgov_waste_collection_example_provider',
  ];

  /**
   * {@inheritdoc}
   */
  protected function setUp(): void {
    parent::setUp();

    $config = $this->config('localgov_waste_collection.settings');
    $config->set('active_data_provider', 'example_data_provider');
    $config->save();
  }

  /**
   * Tests the ICS download route returns a valid calendar file.
   */
  public function testCalendarDownload(): void {
    $user = $this->drupalCreateUser([
      'access content',
    ]);
    $this->drupalLogin($user);

    $uprn = self::EXAMPLE_PROVIDER_UPRN;
    $url = Url::fromRoute('localgov_waste_collection.download', ['uprn' => $uprn])->toString();
    $this->drupalGet($url);

    // Assert headers.
    $this->assertSession()->statusCodeEquals(Response::HTTP_OK);
    $this->assertSession()->responseHeaderEquals('Content-Type', 'text/calendar; charset=utf-8');

    $disposition = $this->getSession()->getResponseHeader('Content-Disposition');
    $this->assertStringContainsString('attachment', $disposition);
    $this->assertStringContainsString($uprn . '.ics', $disposition);

    // Assert content.
    $content = $this->getSession()->getPage()->getContent();
    $this->assertStringContainsString('BEGIN:VCALENDAR', $content);
    $this->assertStringContainsString('END:VCALENDAR', $content);
    $this->assertStringContainsString('SUMMARY:Green lidded bins for Garden Waste', $content);

    // Collection events should use recurring series where a stable pattern is
    // available in the source data.
    $this->assertStringContainsString('RRULE:FREQ=WEEKLY', $content);

    // Download should include the re-download reminder event.
    $this->assertStringContainsString('Download your bin collection calendar', $content);
  }

  /**
   * Tests the ICS subscribe route returns a valid calendar feed.
   */
  public function testCalendarSubscribe(): void {
    $user = $this->drupalCreateUser([
      'access content',
    ]);
    $this->drupalLogin($user);

    $uprn = self::EXAMPLE_PROVIDER_UPRN;
    $url = Url::fromRoute('localgov_waste_collection.subscribe', ['uprn' => $uprn])->toString();
    $this->drupalGet($url);

    // Assert headers.
    $this->assertSession()->statusCodeEquals(Response::HTTP_OK);
    $this->assertSession()->responseHeaderEquals('Content-Type', 'text/calendar; charset=utf-8');

    // Subscribe should not serve as an attachment.
    $disposition = $this->getSession()->getResponseHeader('Content-Disposition');
    $this->assertEmpty($disposition);

    // Assert valid ICS content with collection events.
    $content = $this->getSession()->getPage()->getContent();
    $this->assertStringContainsString('BEGIN:VCALENDAR', $content);
    $this->assertStringContainsString('END:VCALENDAR', $content);
    $this->assertStringContainsString('SUMMARY:Green lidded bins for Garden Waste', $content);

    // Subscribe should NOT include the re-download reminder event.
    $this->assertStringNotContainsString('Download your bin collection calendar', $content);
  }

  /**
   * Tests same-day collections are represented as recurring event series.
   *
   * This fixture is intentionally tied to the example_data_provider dataset and
   * the fixed UPRN above. Other providers will return different UPRNs and may
   * not match the same collection pattern.
   */
  public function testCalendarUsesRecurringSeriesForSameDayCollections(): void {
    $user = $this->drupalCreateUser([
      'access content',
    ]);
    $this->drupalLogin($user);

    $uprn = self::EXAMPLE_PROVIDER_UPRN;
    $url = Url::fromRoute('localgov_waste_collection.download', ['uprn' => $uprn])->toString();
    $this->drupalGet($url);

    $this->assertSession()->statusCodeEquals(Response::HTTP_OK);

    $content = $this->getSession()->getPage()->getContent();

    // The example provider returns multiple collections on the same date, and
    // we expect recurring series rather than single-day instant events.
    $this->assertGreaterThanOrEqual(
      2,
      substr_count($content, 'RRULE:'),
      'Expected at least two recurring event series for same-day collections.'
    );

    // If a collection is created as a same-day instant event, a single VEVENT
    // will have DTSTART and DTEND set to the exact same date and time. That
    // should fail the test because it is not a proper recurring series.
    preg_match_all('/BEGIN:VEVENT\r?\n(.*?)\r?\nEND:VEVENT/s', $content, $eventBlocks);
    foreach ($eventBlocks[1] as $eventBlock) {
      preg_match('/DTSTART[^\r\n]*:(\d{8}T\d{6})/m', $eventBlock, $startMatch);
      preg_match('/DTEND[^\r\n]*:(\d{8}T\d{6})/m', $eventBlock, $endMatch);

      if ($startMatch && $endMatch && $startMatch[1] === $endMatch[1]) {
        $this->fail('Found same-day instant event definitions that should be recurring series.');
      }
    }
  }

}
