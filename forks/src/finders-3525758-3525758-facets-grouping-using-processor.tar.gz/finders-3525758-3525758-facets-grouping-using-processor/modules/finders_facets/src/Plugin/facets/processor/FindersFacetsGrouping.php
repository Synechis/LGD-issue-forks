<?php

declare(strict_types=1);

namespace Drupal\finders_facets\Plugin\facets\processor;

use Drupal\Core\Entity\EntityTypeManagerInterface;
use Drupal\Core\Plugin\ContainerFactoryPluginInterface;
use Drupal\Core\Url;
use Drupal\facets\FacetInterface;
use Drupal\facets\Processor\BuildProcessorInterface;
use Drupal\facets\Processor\ProcessorPluginBase;
use Drupal\facets\Result\Result;
use Drupal\facets\Result\ResultInterface;
use Drupal\finders_facets\Hook\FindersHooks;
use Symfony\Component\DependencyInjection\ContainerInterface;

/**
 * Groups the results for Finders facets by the facet type.
 *
 * We can't use a Facets hierarchy plugin for this, as that only returns
 * children for a given result value, and won't let us add dummy parents.
 *
 * @see \Drupal\finders_facets\Hook\FacetsHooks::preprocessFacetsItemList()
 *
 * @FacetsProcessor(
 *   id = "finders_facets_grouping",
 *   label = @Translation("Finders facets grouping"),
 *   description = @Translation("Group Finder facets by their facet type."),
 *   stages = {
 *     "build" = 50
 *   }
 * )
 */
class FindersFacetsGrouping extends ProcessorPluginBase implements ContainerFactoryPluginInterface, BuildProcessorInterface {

  /**
   * The entity type manager.
   *
   * @var \Drupal\Core\Entity\EntityTypeManagerInterface
   */
  protected $entityTypeManager;

  /**
   * {@inheritdoc}
   */
  public static function create(ContainerInterface $container, array $configuration, $plugin_id, $plugin_definition) {
    return new static(
      $configuration,
      $plugin_id,
      $plugin_definition,
      $container->get('entity_type.manager'),
    );
  }

  /**
   * Creates a FindersFacetsGrouping instance.
   *
   * @param array $configuration
   *   A configuration array containing information about the plugin instance.
   * @param string $plugin_id
   *   The plugin_id for the plugin instance.
   * @param mixed $plugin_definition
   *   The plugin implementation definition.
   * @param \Drupal\Core\Entity\EntityTypeManagerInterface $entity_type_manager
   *   The entity type manager.
   */
  public function __construct(
    array $configuration,
    $plugin_id,
    $plugin_definition,
    EntityTypeManagerInterface $entity_type_manager,
  ) {
    parent::__construct($configuration, $plugin_id, $plugin_definition);
    $this->entityTypeManager = $entity_type_manager;
  }

  /**
   * {@inheritdoc}
   */
  public function supportsFacet(FacetInterface $facet) {
    return ($facet->getFieldIdentifier() == FindersHooks::FACET_INDEXING_FIELD);
  }

  /**
   * {@inheritdoc}
   */
  public function build(FacetInterface $facet, array $results) {
    $facet_storage = $this->entityTypeManager->getStorage('finders_facet');
    $facet_type_storage = $this->entityTypeManager->getStorage('finders_facet_type');

    // Forcibly set the facet to use hierachy. Various things check for this,
    // such as the LinksWidget.
    $facet->setUseHierarchy(TRUE);

    // Load the finders facet entities.
    $finders_facet_ids = array_map(fn (ResultInterface $result) => $result->getRawValue(), $results);
    $finders_facets = $facet_storage->loadMultiple($finders_facet_ids);

    // Get the list of finders facet types that are involved, and group the
    // results by bundle.
    $results_by_finders_facet_type = [];
    foreach ($results as $result) {
      $finders_facet = $finders_facets[$result->getRawValue()];

      $results_by_finders_facet_type[$finders_facet->bundle()][] = $result;
    }

    // Re-create the results array to be grouped, with dummy results as the
    // top-level items.
    $grouped_results = [];
    foreach ($results_by_finders_facet_type as $finders_facet_type_id => $finders_facet_type_results) {
      $finders_facet_type = $facet_type_storage->load($finders_facet_type_id);

      // Make a dummy facet result for each bundle, which can act as a hierarchy
      // parent.
      $dummy_result = new Result($facet, '__dummy_' . $finders_facet_type_id, $finders_facet_type->label(), 0);

      $dummy_result->setChildren($finders_facet_type_results);

      // We need to set a dummy URL on our result, as otherwise Facets will not
      // treat it as having child items. We rely on our hook_preprocess()
      // implementation to prevent output of this as an actual link.
      // @see \Drupal\facets\Widget\WidgetPluginBase::build()
      // @see \Drupal\finders_facets\Hook\FacetsHooks::preprocessFacetsItemList()
      $dummy_result->setUrl(Url::fromUri('internal:#'));

      // The result needs to be active to show children.
      $dummy_result->setActiveState(TRUE);

      $grouped_results[] = $dummy_result;
    }

    return $grouped_results;
  }

}
