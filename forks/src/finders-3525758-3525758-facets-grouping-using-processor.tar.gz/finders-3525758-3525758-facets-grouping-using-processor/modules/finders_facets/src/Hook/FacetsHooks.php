<?php

namespace Drupal\finders_facets\Hook;

use Drupal\Core\Hook\Attribute\Hook;

/**
 * Contains facets hook implementations for the Finders facets module.
 */
class FacetsHooks {

  /**
   * The data type name used to switch the query for facets.
   */
  public const QUERY_TYPE = 'finders_facets';

  /**
   * Implements hook_facets_search_api_query_type_mapping_alter().
   */
  #[Hook('facets_search_api_query_type_mapping_alter')]
  public function facetsSearchApiQueryTypeMappingAlter($backend_plugin_id, array &$query_types) {
    // Register a query type mapping so that our facets can use a custom query.
    // @see \Drupal\finders_facets\Plugin\facets\processor\FindersFacetBundlesProcessor
    // @see Drupal\finders_facets\Plugin\facets\query_type\FindersFacetsQueryType
    $query_types[static::QUERY_TYPE] = 'finders_facets_query_type';
  }

  /**
   * Implements hook_preprocess_HOOK() for facets_item_list.
   */
  #[Hook('preprocess_facets_item_list')]
  public function preprocessFacetsItemList(&$variables) {
    // Hack the top-level dummy results that we added in our processor.
    // @see Drupal\finders_facets\Plugin\facets\processor\FindersFacetsGrouping

    // AFAICT the facet is not set on child lists, and these don't concern us anyway.
    if (empty($variables['facet'])) {
      return;
    }

    // Only act on our facet.
    if ($variables['facet']->getFieldIdentifier() != FindersHooks::FACET_INDEXING_FIELD) {
      return;
    }

    // Only act if our grouping processor is enabled.
    if (!isset($variables['facet']->getProcessors()['finders_facets_grouping'])) {
      return;
    }

    foreach ($variables['items'] as &$item) {
      if (str_starts_with($item['value']['#title']['#raw_value'], '__dummy')) {
        $item['value'] = [
          '#markup' => '<h4>' . $item['value']['#title']['#value'] . '</h4>',
          'children' => $item['value']['children'],
        ];
      }
    }
  }

}
