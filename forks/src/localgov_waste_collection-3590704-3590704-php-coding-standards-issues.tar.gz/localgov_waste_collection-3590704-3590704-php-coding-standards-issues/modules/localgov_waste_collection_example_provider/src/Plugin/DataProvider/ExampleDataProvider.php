<?php

declare(strict_types=1);

namespace Drupal\localgov_waste_collection_example_provider\Plugin\DataProvider;

use Drupal\localgov_waste_collection\DataProviderBase;

/**
 * Example waste collection data provider.
 *
 * @DataProvider(
 *   id = "example_data_provider",
 *   label = @Translation("Example Data Provider")
 * )
 */
class ExampleDataProvider extends DataProviderBase {

  /**
   * {@inheritdoc}
   */
  public function findAddressesByPostcode(string $postcode): array {
    if (strtoupper($postcode) !== 'SF1 1AA') {
      return [];
    }

    return [
      '12345671' => '1 Surveillance Circular, Scarfolk. SF1 1AA',
      '12345672' => '2 Surveillance Circular, Scarfolk. SF1 1AA',
      '12345673' => '3 Surveillance Circular, Scarfolk. SF1 1AA',
      '12345674' => '4 Surveillance Circular, Scarfolk. SF1 1AA',
      '12345675' => '5 Surveillance Circular, Scarfolk. SF1 1AA',
      '12345676' => '6 Surveillance Circular, Scarfolk. SF1 1AA',
      '12345677' => '7 Surveillance Circular, Scarfolk. SF1 1AA',
      '12345678' => '8 Surveillance Circular, Scarfolk. SF1 1AA',
      '12345679' => '9 Surveillance Circular, Scarfolk. SF1 1AA',
    ];
  }

  /**
   * {@inheritdoc}
   */
  public function getAddressFromUprn(string $uprn): ?string {

    return '4 Surveillance Circular, Scarfolk. SF1 1AA';
  }

  /**
   * Get waste collections for a specified UPRN.
   *
   * @return array
   *   An array of waste collections.
   */
  public function getCollections(string $uprn): array {
    if ($uprn === '12345679') {
      return [];
    }

    $dates = [];
    $bins = [
      ["label" => "Non-recyclable waste", "colour" => "Grey"],
      ["label" => "Paper and cardboard", "colour" => "Blue"],
      ["label" => "Garden Waste", "colour" => "Green"],
    ];

    foreach (static::generateCollectionDates() as $i => $date) {
      $formattedDate = $date->format('d-m-Y');

      // Grey bin every collection, blue and green alternate.
      $dates[] = [
        "date" => $formattedDate,
        "type" => $bins[0],
      ];
      $dates[] = [
        "date" => $formattedDate,
        "type" => $bins[($i % 2 === 0) ? 1 : 2],
      ];
    }

    return [
      "weekly_collection" => [
        "label" => "food waste",
        "day" => "Tuesday",
      ],
      "dates" => $dates,
    ];
  }

  /**
   * Generate the collection date series.
   *
   * Starts roughly one week before the nearest Wednesday and produces 12
   * fortnightly dates. Public so tests can derive expected values without
   * duplicating the logic.
   *
   * @return \DateTime[]
   *   An ordered array of DateTime objects keyed by iteration index.
   */
  public static function generateCollectionDates(): array {
    // Start 2 weeks ago, generate fortnightly collections for 4 months.
    $start = new \DateTime('-2 weeks');
    // Align to the next Wednesday.
    $start->modify('next Wednesday');
    // Then back up one week so we have at least one date in the past.
    $start->modify('-1 week');

    $dates = [];
    for ($i = 0; $i < 12; $i++) {
      $date = clone $start;
      $date->modify('+' . ($i * 2) . ' weeks');
      $dates[$i] = $date;
    }

    return $dates;
  }

}
