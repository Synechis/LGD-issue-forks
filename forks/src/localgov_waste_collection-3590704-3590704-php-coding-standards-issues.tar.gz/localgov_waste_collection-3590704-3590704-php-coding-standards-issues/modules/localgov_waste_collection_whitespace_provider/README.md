# LocalGov Waste collection Whitespace data provider

This module provides a data provider for authorities using the [Whitespace Waste Management platform](https://whitespacews.com/).

## How to use

- Enable the module and set it as the active data provider in the [parent module settings](../../README.md#configuration).
- Configure the data provider in the Whitespace module settings at: 
Configuration > Web Services > Waste Collection > Whitespace 
settings (`/admin/config/services/waste_whitespace`)
- The module requires the endpoint URL for your Whitespace service, and your 
API username and password.

By default the SOAP connection timeout is set to 10 seconds, this can be 
overridden with `localgov_waste_collection_whitespace_provider.settings.connect_timeout` 
in settings.php, for example:

```php
$config['localgov_waste_collection_whitespace_provider.settings']
['connect_timeout'] = 20;`
```
