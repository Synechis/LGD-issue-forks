<?php

namespace Drupal\localgov_waste_collection\Exception;

/**
 * Exception thrown for a problem with a data provider's postcode search.
 */
class PostcodeSearchException extends \Exception {

}
