/**
 * @file
 *  Address select
 */
(function localgovFormsAddressSelect($, Drupal) {
  /**
   * Show the manual address form elements.
   *
   * @param  {jQuery} localgovFormsAddressLookupElement
   *   localgovFormsAddressLookup address element.
   */
  function showManualAddress(localgovFormsAddressLookupElement) {
    const manualAddressContainer = localgovFormsAddressLookupElement.find(
      '.js-address-entry-container',
    );
    const manualButton = localgovFormsAddressLookupElement.find('.js-manual-address');
    const addressSelectContainer = localgovFormsAddressLookupElement.find(
      '.js-address-select-container',
    );
    const addressError = addressSelectContainer.find('.js-address-error');
    manualAddressContainer.removeClass('hidden');
    manualButton.hide();
    // Remove the error element when making a manual address.
    addressError.remove();
  }

  /**
   * Adds manual entry button.
   *
   * @param {jQuery} localgovFormsAddressLookupElement
   *   localgovFormsAddressLookup address element.
   */
  function addManualEntryButton(localgovFormsAddressLookupElement) {
    // Add the manual lookup button.
    const manualButton = $('<button>', {
      text: "Can't find the address?",
      type: 'button',
      class: 'link-button manual-address js-manual-address',
      href: '#',
    });

    // Reset the form.
    manualButton.click(function manualButtonClick() {
      showManualAddress(localgovFormsAddressLookupElement);
    });

    // Append the manual lookup button.
    localgovFormsAddressLookupElement
      .find('.js-localgov-forms-address-lookup')
      .append(manualButton);
  }

  /**
   * Hide manual address form.
   *
   * @param {jQuery} localgovFormsAddressLookupElement
   *   Address lookup address lookup element.
   * @param {String} type
   *   'soft' = Do not clear the address values.
   *            (used when an address is selected)
   *   'hard' = Clear the address values.
   * @param {Object} settings
   *   drupalSettings.
   */
  function hideManualAddress(localgovFormsAddressLookupElement, type, settings) {
    const manualAddressContainer = localgovFormsAddressLookupElement.find(
      '.js-address-entry-container',
    );
    const manualButton = localgovFormsAddressLookupElement.find('.js-manual-address');
    manualAddressContainer.addClass('hidden');

    if (type === 'hard') {
      // Clear all values.
      manualAddressContainer.find('input').val('');

      // Trigger change events so UPRN and extra fields are cleared.
      manualAddressContainer.find('input').first().trigger('change');
    }

    // Hide manual entry button if asked for.
    if (
      typeof settings.localgovFormsAddressLookup.isManualAddressEntryBtnAlwaysVisible !==
        'undefined' &&
      !settings.localgovFormsAddressLookup.isManualAddressEntryBtnAlwaysVisible
    ) {
      manualButton.hide();
    }
  }

  /**
   * Check if a manual address has been entered.
   *
   * @param {jQuery} localgovFormsAddressLookupElement
   *   localgovFormsAddressLookup address element.
   * @return {Boolean}
   *   True if the a manual address is present and the search box is empty.
   */
  function isManualAddressEntered(localgovFormsAddressLookupElement) {
    const manualAddressContainer = localgovFormsAddressLookupElement.find(
      '.js-address-entry-container',
    );
    // Test manual address if the element is visible.
    if (manualAddressContainer.is(':visible')) {
      let hasManualValue = false;
      manualAddressContainer
        .find('input[type="text"]')
        .each(function checkManualValue() {
          if (this.value !== '') {
            hasManualValue = true;
          }
        });
      return hasManualValue;
    }
    return false;
  }

  /**
   * Hide errors on an element
   *
   * @param {jQuery} indvElement
   *   The individual form input element to hide errors.
   */
  function hideErrorsOnElement(indvElement) {
    const indvElementWrapper = indvElement.closest('.js-form-item');
    indvElement.not('.js-address-searchstring').removeClass('error');
    indvElementWrapper.removeClass('has-error');
    indvElementWrapper.find('.invalid-feedback').remove();
  }

  /**
   * Hide address search errors.
   *
   * On webform, when a form fails validation, errors can cascade to the child
   * elements, including the search box.
   * This will remove the errors in javascript, leaving the error message on
   * the parent element only.
   * @see https://www.drupal.org/project/drupal/issues/2848319
   * @param  {jQuery} localgovFormsAddressLookupElement
   *   localgovFormsAddressLookup address element.
   */
  function hideAddressSearchErrors(localgovFormsAddressLookupElement) {
    const searchElementContainer = localgovFormsAddressLookupElement.find(
      '.js-address-search-container',
    );
    const searchElement = searchElementContainer.find(
      '.js-address-searchstring',
    );
    const manualAddressContainer = localgovFormsAddressLookupElement.find(
      '.js-address-entry-container',
    );
    hideErrorsOnElement(searchElement);
    if (manualAddressContainer.is(':hidden')) {
      manualAddressContainer.find('input').each(function hideErrorsEachInput() {
        hideErrorsOnElement($(this));
      });
    }
  }

  /**
   * Address lookup select change handler.
   * Populates the address fields when selecting an address.
   * @function
   */
  const localgovFormsWebformChangeHandler =
    function localgovFormsWebformChangeHandler() {
      // Guard check, don't run if localgovFormsAddressLookup not yet defined.
      if (typeof drupalSettings.localgovFormsAddressLookup === 'undefined') {
        return;
      }
      const localgovFormsAddressLookupElement = $(this).closest(
        '.js-webform-type-localgov-webform-uk-address',
      );
      const localgovFormsAddressLookupWebformAddressContainer = $(this).closest(
        '.js-webform-type-localgov-webform-uk-address',
      );
      const localgovFormsAddressLookupWebformAddressEntry =
        localgovFormsAddressLookupWebformAddressContainer.find('.js-address-entry-container');

      if (drupalSettings.localgovFormsAddressLookup.selectedAddress) {
        const addressSelected = drupalSettings.localgovFormsAddressLookup.selectedAddress;
        localgovFormsAddressLookupWebformAddressEntry
          .find('input.js-localgov-forms-webform-uk-address--address-1')
          .val(addressSelected.line1);
        localgovFormsAddressLookupWebformAddressEntry
          .find('input.js-localgov-forms-webform-uk-address--address-2')
          .val(addressSelected.line2);
        localgovFormsAddressLookupWebformAddressEntry
          .find('input.js-localgov-forms-webform-uk-address--town-city')
          .val(addressSelected.town);
        localgovFormsAddressLookupWebformAddressEntry
          .find('input.js-localgov-forms-webform-uk-address--postcode')
          .val(addressSelected.postcode);

        // Add any extra fields from centrahub for Twig access.
        const extraElements = ['lat', 'lng', 'uprn', 'ward'];
        $.each(extraElements, function extraElementsIterator(index, value) {
          localgovFormsAddressLookupWebformAddressContainer
            .find(`input.js-localgov-forms-webform-uk-address--${value}`)
            .val(addressSelected[value]);
        });

        showManualAddress(localgovFormsAddressLookupElement);
      } else if (this.value === 0) {
        // If choosing the empty option, clear out the address fields.
        hideManualAddress(localgovFormsAddressLookupElement, 'hard', drupalSettings);
      }
    };

  /**
   * Address lookup manual address change handler.
   * Clears any Address lookup values such as UPRN from the address handler.
   * @function
   */
  const localgovFormsWebformManualAddressChangeHandler =
    function localgovFormsWebformManualAddressChangeHandler() {
      const localgovFormsAddressLookupWebformAddressContainer = $(this).closest(
        '.js-webform-type-localgov-webform-uk-address',
      );

      // Clear any extra fields from centrahub for Twig access.
      const extraElements = ['lat', 'lng', 'uprn', 'ward'];
      $.each(
        extraElements,
        function localgovFormsWebformManualAddressChangeHandlerEach(
          index,
          value,
        ) {
          localgovFormsAddressLookupWebformAddressContainer
            .find(`input.js-localgov-forms-webform-uk-address--${value}`)
            .val('');
        },
      );
    };

  // Attach after an ajax refresh
  Drupal.behaviors.localgov_forms_webform = {
    attach(context, settings) {
      $(
        once(
          'localgov-address-webform',
          '.js-webform-type-localgov-webform-uk-address',
          context,
        ),
      ).each(function localgovFormsAddressEach() {
        const localgovFormsAddressLookupElement = $(this);
        addManualEntryButton(localgovFormsAddressLookupElement);

        // Hide the manual address element, if it has no values.
        if (!isManualAddressEntered(localgovFormsAddressLookupElement)) {
          hideManualAddress(localgovFormsAddressLookupElement, 'soft', settings);
        }

        localgovFormsAddressLookupElement
          .find('.js-reset-address')
          .click(function handleResetAddressClick() {
            hideManualAddress(localgovFormsAddressLookupElement, 'hard', settings);
          });
        hideAddressSearchErrors(localgovFormsAddressLookupElement);
      });

      // Manual address change handler first.
      $('.js-address-entry-container input').on(
        'change',
        localgovFormsWebformManualAddressChangeHandler,
      );

      // Select box change handler.
      $('.js-address-select').on('change', localgovFormsWebformChangeHandler);
    },
    detach() {
      $('.js-address-entry-container input').off(
        'change',
        localgovFormsWebformManualAddressChangeHandler,
      );
      $('.js-address-select').off('change', localgovFormsWebformChangeHandler);
    },
  };
})(jQuery, Drupal);
