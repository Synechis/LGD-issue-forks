<?php

namespace Drupal\localgov_openreferral\EventSubscriber;

use Drupal\Core\Entity\FieldableEntityInterface;
use Drupal\Core\Field\FieldDefinitionInterface;
use Drupal\localgov_openreferral\Event\GenerateEntityMapping;

/**
 * Event subscriber for suggested map from entity to open referral service.
 */
class GenerateMappingOrganization extends GenerateMappingBase {

  /**
   * Generate suggested mapping to a organization.
   *
   * @param \Drupal\localgov_openreferral\Event\GenerateEntityMapping $event
   *   The Event to process.
   */
  public function generateSuggestions(GenerateEntityMapping $event) {
    if ($event->getPublicType() != 'organization') {
      return;
    }
    $definition = $this->entityTypeManager->getDefinition($event->getEntityTypeId());
    if (!$definition->entityClassImplements(FieldableEntityInterface::class)) {
      return;
    }

    foreach ($this->fieldManager->getFieldDefinitions($event->getEntityTypeId(), $event->getBundle()) as $field) {
      $single_suggestions = [];
      $single_suggestions[] = $this->fieldSuggestionsKnownDescription($field);
      $single_suggestions[] = $this->fieldSuggestionsKnownEmail($field);
      $single_suggestions[] = $this->fieldSuggestionsKnownWebsite($field);
      $single_suggestions[] = $this->fieldSuggestionsKnownLogo($field);
      $single_suggestions[] = $this->fieldSuggestionsKnownUri($field);
      $single_suggestions[] = $this->fieldSuggestionsKnownParentOrganization($field);
      $single_suggestions[] = $this->fieldSuggestionsKnownParentOrganizationId($field);
      $event->addSuggestionsSingle(array_filter($single_suggestions));
    }
  }

  /**
   * Suggestion for organization description fields.
   */
  protected function fieldSuggestionsKnownDescription(FieldDefinitionInterface $field): array {
    return $this->fieldSuggestionsKnown($field, [
      'body' => 'description',
    ], [
      'description' => 'description',
    ]);
  }

  /**
   * Suggestion for organization email fields.
   */
  protected function fieldSuggestionsKnownEmail(FieldDefinitionInterface $field): array {
    return $this->fieldSuggestionsKnown($field, [], [
      'email' => 'email',
      'mail' => 'email',
    ]);
  }

  /**
   * Suggestion for organization website fields.
   */
  protected function fieldSuggestionsKnownWebsite(FieldDefinitionInterface $field): array {
    return $this->fieldSuggestionsKnown($field, [], [
      'website' => 'website',
      'web' => 'website',
    ]);
  }

  /**
   * Suggestion for organization logo fields.
   */
  protected function fieldSuggestionsKnownLogo(FieldDefinitionInterface $field): array {
    return $this->fieldSuggestionsKnown($field, [], [
      'logo' => 'logo',
      'image' => 'logo',
    ]);
  }

  /**
   * Suggestion for organization URI fields.
   */
  protected function fieldSuggestionsKnownUri(FieldDefinitionInterface $field): array {
    return $this->fieldSuggestionsKnown($field, [], [
      'uri' => 'uri',
    ]);
  }

  /**
   * Suggestion for organization parent organization fields.
   */
  protected function fieldSuggestionsKnownParentOrganization(FieldDefinitionInterface $field): array {
    return $this->fieldSuggestionsReference($field, [
      'organization' => 'parent_organization',
    ]);
  }

  /**
   * Suggestion for organization parent_organization_id fields.
   */
  protected function fieldSuggestionsKnownParentOrganizationId(FieldDefinitionInterface $field): array {
    $parent_organization_suggestion = $this->fieldSuggestionsKnownParentOrganization($field);
    if ($parent_organization_suggestion === []) {
      return [];
    }

    return [
      'field_name' => $parent_organization_suggestion['field_name'] . ':uuid',
      'public_name' => 'parent_organization_id',
    ];
  }

}
