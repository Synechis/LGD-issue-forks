<?php

namespace Drupal\localgov_openreferral\EventSubscriber;

use Drupal\Core\Entity\FieldableEntityInterface;
use Drupal\Core\Field\FieldDefinitionInterface;
use Drupal\localgov_openreferral\Event\GenerateEntityMapping;

/**
 * Event subscriber for suggested map from entity to service_at_location.
 */
class GenerateMappingServiceAtLocation extends GenerateMappingBase {

  /**
   * Generate suggested mapping to a service_at_location.
   *
   * @param \Drupal\localgov_openreferral\Event\GenerateEntityMapping $event
   *   The Event to process.
   */
  public function generateSuggestions(GenerateEntityMapping $event) {
    if ($event->getPublicType() != 'service_at_location') {
      return;
    }
    $definition = $this->entityTypeManager->getDefinition($event->getEntityTypeId());
    if (!$definition->entityClassImplements(FieldableEntityInterface::class)) {
      return;
    }

    foreach ($this->fieldManager->getFieldDefinitions($event->getEntityTypeId(), $event->getBundle()) as $field) {
      $single_suggestions = [];
      $single_suggestions[] = $this->fieldSuggestionsKnownDescription($field);
      $single_suggestions[] = $this->fieldSuggestionsKnownServiceId($field);
      $single_suggestions[] = $this->fieldSuggestionsKnownLocationId($field);
      $single_suggestions[] = $this->fieldSuggestionsKnownLocation($field);
      $event->addSuggestionsSingle(array_filter($single_suggestions));
    }
  }

  /**
   * Suggestion for service_at_location description fields.
   */
  protected function fieldSuggestionsKnownDescription(FieldDefinitionInterface $field): array {
    return $this->fieldSuggestionsKnown($field, [
      'body' => 'description',
    ], [
      'description' => 'description',
    ]);
  }

  /**
   * Suggestion for service_at_location service_id fields.
   */
  protected function fieldSuggestionsKnownServiceId(FieldDefinitionInterface $field): array {
    return [
      'field_name' => 'parent:uuid',
      'public_name' => 'service_id',
    ];
  }

  /**
   * Suggestion for service_at_location location fields.
   */
  protected function fieldSuggestionsKnownLocation(FieldDefinitionInterface $field): array {
    return $this->fieldSuggestionsReference($field, [
      'location' => 'location',
    ]);
  }

  /**
   * Suggestion for service_at_location location_id fields.
   */
  protected function fieldSuggestionsKnownLocationId(FieldDefinitionInterface $field): array {
    $location_suggestion = $this->fieldSuggestionsReference($field, [
      'location' => 'location',
    ]);
    if ($location_suggestion === []) {
      return [];
    }

    return [
      'field_name' => $location_suggestion['field_name'] . ':uuid',
      'public_name' => 'location_id',
    ];
  }

}
