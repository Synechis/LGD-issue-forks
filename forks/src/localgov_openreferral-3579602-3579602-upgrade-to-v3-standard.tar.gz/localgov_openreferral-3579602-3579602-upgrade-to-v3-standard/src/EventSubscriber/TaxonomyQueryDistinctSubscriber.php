<?php

namespace Drupal\localgov_openreferral\EventSubscriber;

use Drupal\Core\Database\Connection;
use Drupal\search_api\Event\QueryPreExecuteEvent;
use Drupal\search_api\Event\SearchApiEvents;
use Drupal\search_api_db\Event\QueryPreExecuteEvent as DbQueryPreExecuteEvent;
use Drupal\search_api_db\Event\SearchApiDbEvents;
use Symfony\Component\EventDispatcher\EventSubscriberInterface;

/**
 * Deduplicates tagged taxonomy queries by bundle UUID.
 */
class TaxonomyQueryDistinctSubscriber implements EventSubscriberInterface {

  /**
   * Query tag used to target taxonomy list queries.
   */
  const QUERY_TAG = 'localgov_openreferral_taxonomies_distinct';

  /**
   * Query option used to mark DB dedupe requirement.
   */
  const DEDUPE_OPTION = 'localgov_openreferral_dedupe_bundle_uuid';

  /**
   * Search API field identifier for bundle UUID.
   */
  const BUNDLE_UUID_FIELD = 'localgov_openreferral_bundle_uuid';

  /**
   * Database connection.
   *
   * @var \Drupal\Core\Database\Connection
   */
  protected $database;

  /**
   * Constructs the taxonomy query distinct subscriber.
   *
   * @param \Drupal\Core\Database\Connection $database
   *   The database connection.
   */
  public function __construct(Connection $database) {
    $this->database = $database;
  }

  /**
   * Marks tagged search queries for bundle UUID deduplication.
   *
   * @param \Drupal\search_api\Event\QueryPreExecuteEvent $event
   *   The query pre-execute event.
   */
  public function onQueryPreExecute(QueryPreExecuteEvent $event): void {
    $query = $event->getQuery();
    if (!$query->hasTag(static::QUERY_TAG)) {
      return;
    }

    $backend_id = $query->getIndex()->getServerInstance()->getBackendId();
    if ($backend_id === 'search_api_db') {
      $query->setOption(static::DEDUPE_OPTION, TRUE);
      return;
    }

    if ($backend_id === 'search_api_solr') {
      $query->setOption('search_api_grouping', [
        'use_grouping' => TRUE,
        'fields' => [static::BUNDLE_UUID_FIELD],
        'group_limit' => 1,
      ]);
    }
  }

  /**
   * Applies DB-level bundle UUID deduplication before query execution.
   *
   * @param \Drupal\search_api_db\Event\QueryPreExecuteEvent $event
   *   The DB query pre-execute event.
   */
  public function onDbQueryPreExecute(DbQueryPreExecuteEvent $event): void {
    $query = $event->getQuery();
    if (!$query->hasTag(static::QUERY_TAG) || !$query->getOption(static::DEDUPE_OPTION)) {
      return;
    }

    $db_query = $event->getDbQuery();
    $fields = $db_query->getMetaData('search_api_db_fields') ?? [];
    $bundle_uuid_field = $fields[static::BUNDLE_UUID_FIELD] ?? [];
    $bundle_uuid_table = $bundle_uuid_field['table'] ?? NULL;
    if (!$bundle_uuid_table) {
      return;
    }

    $subquery = $this->database->select($bundle_uuid_table, 'bundle_uuid');
    $subquery->addExpression('MIN(bundle_uuid.item_id)', 'item_id');
    $subquery->isNotNull('bundle_uuid.value');
    $subquery->groupBy('bundle_uuid.value');

    $tables = $db_query->getTables();
    $base_alias = array_key_first($tables);
    if (!$base_alias) {
      return;
    }

    $db_query->condition("$base_alias.item_id", $subquery, 'IN');
  }

  /**
   * {@inheritdoc}
   */
  public static function getSubscribedEvents(): array {
    return [
      SearchApiEvents::QUERY_PRE_EXECUTE => 'onQueryPreExecute',
      SearchApiDbEvents::QUERY_PRE_EXECUTE => 'onDbQueryPreExecute',
    ];
  }

}
