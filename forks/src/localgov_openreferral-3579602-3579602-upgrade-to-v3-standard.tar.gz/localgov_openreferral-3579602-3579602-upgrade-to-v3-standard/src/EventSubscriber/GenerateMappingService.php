<?php

namespace Drupal\localgov_openreferral\EventSubscriber;

use Drupal\Core\Entity\FieldableEntityInterface;
use Drupal\Core\Field\FieldDefinitionInterface;
use Drupal\localgov_openreferral\Event\GenerateEntityMapping;

/**
 * Event subscriber for suggested map from entity to open referral service.
 */
class GenerateMappingService extends GenerateMappingBase {

  /**
   * Generate suggested mapping to a service.
   *
   * @param \Drupal\localgov_openreferral\Event\GenerateEntityMapping $event
   *   The Event to process.
   */
  public function generateSuggestions(GenerateEntityMapping $event) {
    if ($event->getPublicType() != 'service') {
      return;
    }
    $definition = $this->entityTypeManager->getDefinition($event->getEntityTypeId());
    if (!$definition->entityClassImplements(FieldableEntityInterface::class)) {
      return;
    }

    foreach ($this->fieldManager->getFieldDefinitions($event->getEntityTypeId(), $event->getBundle()) as $field) {
      $single_suggestions = [];
      $single_suggestions[] = $this->fieldSuggestionsKnownDescription($field);
      $single_suggestions[] = $this->fieldSuggestionsKnownStatus($field);
      $single_suggestions[] = $this->fieldSuggestionsKnownEmail($field);
      $single_suggestions[] = $this->fieldSuggestionsKnownAccreditations($field);
      $single_suggestions[] = $this->fieldSuggestionsKnownMinimumAge($field);
      $single_suggestions[] = $this->fieldSuggestionsKnownMaximumAge($field);
      $single_suggestions[] = $this->fieldSuggestionsKnownAssuredDate($field);
      $single_suggestions[] = $this->fieldSuggestionsKnownAssurerEmail($field);
      $single_suggestions[] = $this->fieldSuggestionsKnownAlert($field);
      $single_suggestions[] = $this->fieldSuggestionsKnownLastModified($field);
      $single_suggestions[] = $this->fieldSuggestionsTypeUrl($field);
      $single_suggestions[] = $this->fieldSuggestionsKnownOrganization($field);
      $single_suggestions[] = $this->fieldSuggestionsKnownOrganisationId($field);
      $event->addSuggestionsSingle(array_filter($single_suggestions));

      $multiple_suggestions = [];
      $multiple_suggestions[] = $this->fieldSuggestionsKnownServiceTaxonomies($field);
      $event->addSuggestions(array_filter($multiple_suggestions));
    }
  }

  /**
   * Suggestion for service description fields.
   */
  protected function fieldSuggestionsKnownDescription(FieldDefinitionInterface $field): array {
    return $this->fieldSuggestionsKnown($field, [
      'body' => 'description',
    ], [
      'description' => 'description',
    ]);
  }

  /**
   * Suggestion for service status fields.
   */
  protected function fieldSuggestionsKnownStatus(FieldDefinitionInterface $field): array {
    return $this->fieldSuggestionsKnown($field, [
      'status' => 'status',
    ], [
      'status' => 'status',
    ]);
  }

  /**
   * Suggestion for service accreditations fields.
   */
  protected function fieldSuggestionsKnownAccreditations(FieldDefinitionInterface $field): array {
    return $this->fieldSuggestionsKnown($field, [], [
      'accreditation' => 'accreditations',
      'accreditations' => 'accreditations',
    ]);
  }

  /**
   * Suggestion for service minimum age fields.
   */
  protected function fieldSuggestionsKnownMinimumAge(FieldDefinitionInterface $field): array {
    return $this->fieldSuggestionsKnown($field, [], [
      'minimum_age' => 'minimum_age',
      'min_age' => 'minimum_age',
    ]);
  }

  /**
   * Suggestion for service maximum age fields.
   */
  protected function fieldSuggestionsKnownMaximumAge(FieldDefinitionInterface $field): array {
    return $this->fieldSuggestionsKnown($field, [], [
      'maximum_age' => 'maximum_age',
      'max_age' => 'maximum_age',
    ]);
  }

  /**
   * Suggestion for service assured date fields.
   */
  protected function fieldSuggestionsKnownAssuredDate(FieldDefinitionInterface $field): array {
    return $this->fieldSuggestionsKnown($field, [], [
      'assured_date' => 'assured_date',
    ]);
  }

  /**
   * Suggestion for service assurer email fields.
   */
  protected function fieldSuggestionsKnownAssurerEmail(FieldDefinitionInterface $field): array {
    return $this->fieldSuggestionsKnown($field, [
      'assurer_email' => 'assurer_email',
    ], [
      'assurer_email' => 'assurer_email',
      'assurer_mail' => 'assurer_email',
    ]);
  }

  /**
   * Suggestion for service alert fields.
   */
  protected function fieldSuggestionsKnownAlert(FieldDefinitionInterface $field): array {
    return $this->fieldSuggestionsKnown($field, [], [
      'alert' => 'alert',
    ]);
  }

  /**
   * Suggestion for service last modified fields.
   */
  protected function fieldSuggestionsKnownLastModified(FieldDefinitionInterface $field): array {
    return $this->fieldSuggestionsKnown($field, [], [
      'last_modified' => 'last_modified',
      'changed' => 'last_modified',
      'modified' => 'last_modified',
      'updated' => 'last_modified',
    ]);
  }

  /**
   * Suggestion for service email fields.
   */
  protected function fieldSuggestionsKnownEmail(FieldDefinitionInterface $field): array {
    return $this->fieldSuggestionsKnown($field, [], [
      'email' => 'email',
    ]);
  }

  /**
   * Suggestion for service URL fields.
   */
  protected function fieldSuggestionsTypeUrl(FieldDefinitionInterface $field): array {
    if ($field->getName() === 'path' && $field->getItemDefinition()->getDataType() === 'field_item:path') {
      return [
        'field_name' => 'path',
        'public_name' => 'url',
      ];
    }

    return $this->fieldSuggestionsType($field, [
      'field_item:link' => 'url',
    ]);
  }

  /**
   * Suggestion for service organization fields.
   */
  protected function fieldSuggestionsKnownOrganization(FieldDefinitionInterface $field): array {
    return $this->fieldSuggestionsReference($field, [
      'organization' => 'organization',
    ]);
  }

  /**
   * Suggestion for service organisation_id fields.
   */
  protected function fieldSuggestionsKnownOrganisationId(FieldDefinitionInterface $field): array {
    $field_name = $field->getName();
    if (stripos($field_name, 'organisation_id') === FALSE && stripos($field_name, 'organization_id') === FALSE) {
      return [];
    }
    if ($field->getItemDefinition()->getDataType() !== 'field_item:entity_reference') {
      return [];
    }

    return [
      'field_name' => $field_name . ':uuid',
      'public_name' => 'organisation_id',
    ];
  }

  /**
   * Suggestion for service taxonomy fields.
   */
  protected function fieldSuggestionsKnownServiceTaxonomies(FieldDefinitionInterface $field): array {
    return $this->fieldSuggestionsReference($field, [
      'taxonomy' => 'attributes',
    ]);
  }

}
