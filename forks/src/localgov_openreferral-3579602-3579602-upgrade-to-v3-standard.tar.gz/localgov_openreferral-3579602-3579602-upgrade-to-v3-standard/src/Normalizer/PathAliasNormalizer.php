<?php

namespace Drupal\localgov_openreferral\Normalizer;

use Drupal\Core\Field\FieldItemInterface;
use Drupal\Core\Url;
use Drupal\path\Plugin\Field\FieldType\PathItem;
use Drupal\path_alias\PathAliasInterface;

/**
 * Converts path alias field items to absolute URLs.
 */
class PathAliasNormalizer extends FieldItemNormalizer {

  /**
   * {@inheritdoc}
   */
  public function normalize($field_item, $format = NULL, array $context = []): array|string|int|float|bool|\ArrayObject|null {
    assert($field_item instanceof FieldItemInterface);
    if (($context['field']['public_name'] ?? NULL) !== 'url') {
      return parent::normalize($field_item, $format, $context);
    }

    $alias = $field_item->alias ?? '';
    if (is_string($alias) && $alias !== '') {
      if ($alias[0] !== '/') {
        $alias = '/' . $alias;
      }
      return Url::fromUserInput($alias, ['absolute' => TRUE])->toString();
    }

    return $field_item->getEntity()->toUrl('canonical', ['absolute' => TRUE])->toString();
  }

  /**
   * {@inheritdoc}
   */
  public function getSupportedTypes(?string $format): array {
    return [
      PathItem::class => TRUE,
    ];
  }

}
