<?php

namespace Drupal\localgov_openreferral\Normalizer;

use Drupal\Core\Field\EntityReferenceFieldItemListInterface;
use Drupal\Core\Field\FieldItemListInterface;
use Drupal\localgov_openreferral\MappingInformation;
use Drupal\serialization\Normalizer\NormalizerBase;

/**
 * Normalizer class specific for entity reference items in field.
 */
class EntityReferenceFieldNormalizer extends NormalizerBase {

  /**
   * The formats that the Normalizer can handle.
   *
   * @var array
   */
  protected $format = ['openreferral_json'];

  /**
   * Mapping information service.
   *
   * @var \Drupal\localgov_openreferral\MappingInformation
   */
  protected $mappingInformation;

  /**
   * Normalizer constructor.
   *
   * @param \Drupal\localgov_openreferral\MappingInformation $mapping_information
   *   Mapping information helper service.
   */
  public function __construct(MappingInformation $mapping_information) {
    $this->mappingInformation = $mapping_information;
  }

  /**
   * {@inheritdoc}
   */
  public function normalize($field, $format = NULL, array $context = []): array|string|int|float|bool|\ArrayObject|null {
    // There are two types of references in the standard.
    // One has an intervening 'relationship entity' between the parent and
    // child.
    // This is defined in the standard by the property field. So we hard code it
    // here, if the standard changes, it should be updated.
    $reference_parent = [
      'service_at_locations' => 'service',
      'attributes' => 'service',
    ];
    // The other links directly to them, and aren't even multiple.
    $reference_single = [
      'organization' => 'organization',
      'vocabulary' => 'vocabulary',
      'parent_id' => 'parent_id',
      'organization_id' => 'organization_id',
      'location_id' => 'location_id',
      'service_id' => 'service_id',
      'parent_organization_id' => 'parent_organization_id',
      'location' => 'location',
      'service' => 'service',
    ];

    assert($field instanceof FieldItemListInterface && method_exists($field, 'referencedEntities'));
    $attributes = [];

    if (isset($reference_parent[$context['field']['public_name']])) {
      foreach ($field->referencedEntities() as $entity) {
        $this->addCacheableDependency($context, $entity);
        if (!$entity->access('view')) {
          continue;
        }
        $type = $this->mappingInformation->getPublicType($entity->getEntityTypeId(), $entity->bundle());
        if ($type === 'unknown') {
          continue;
        }
        $attribute = ['id' => $entity->uuid()];
        if (count($context['parents']) < 3) {
          $attribute = $this->serializer->normalize($entity, $format, $context);
        }
        if ($context['field']['public_name'] === 'attributes') {
          // Id and taxonomy_term_id will be used the same uuid of the term.
          $attributes[] = [
            'id' => $attribute['id'],
            'link_id' => $entity->uuid(),
            'taxonomy_term_id' => $attribute['id'],
            'taxonomy_term' => $attribute,
          ];
        }
        else {
          $attributes[] = $attribute;
        }

      }
    }
    elseif (isset($reference_single[$context['field']['public_name']])) {
      $refrenced_entities = $field->referencedEntities();
      if ($entity = reset($refrenced_entities)) {
        $this->addCacheableDependency($context, $entity);
        if ($entity->access('view')) {
          if (count($context['parents']) < 3) {
            $attributes = $this->serializer->normalize($entity, $format, $context);
          }
          else {
            $attributes = $entity->uuid();
          }
        }
      }
    }
    else {
      foreach ($field->referencedEntities() as $entity) {
        $this->addCacheableDependency($context, $entity);
        if ($entity->access('view')) {
          if (is_array($context['parents']) && count($context['parents']) < 3) {
            $attributes[] = $this->serializer->normalize($entity, $format, $context);
          }
          else {
            $attributes[] = ['id' => $entity->uuid()];
          }
        }
      }
    }

    return $attributes;
  }

  /**
   * {@inheritdoc}
   */
  public function getSupportedTypes(?string $format): array {
    return [
      EntityReferenceFieldItemListInterface::class => TRUE,
    ];
  }

}
