<?php

namespace Drupal\localgov_openreferral\Normalizer;

use Drupal\Core\TypedData\TypedDataInternalPropertiesHelper;
use Drupal\options\Plugin\Field\FieldType\ListItemBase;
use Drupal\serialization\Normalizer\NormalizerBase;

/**
 * Converts list items to their configured option labels.
 */
class ListItemBaseNormalizer extends NormalizerBase {

  /**
   * The formats that the Normalizer can handle.
   *
   * @var array
   */
  protected $format = ['openreferral_json'];

  /**
   * {@inheritdoc}
   */
  public function normalize($field_item, $format = NULL, array $context = []): array|string|int|float|bool|\ArrayObject|null {
    assert($field_item instanceof ListItemBase);
    $field_properties = TypedDataInternalPropertiesHelper::getNonInternalProperties($field_item);
    $main_property = $field_item::mainPropertyName();
    if (!isset($field_properties[$main_property])) {
      return NULL;
    }

    $value = $this->serializer->normalize($field_properties[$main_property], $format, $context);
    if (!is_string($value) && !is_int($value)) {
      return $value;
    }

    $allowed_values = $field_item->getFieldDefinition()->getSetting('allowed_values');
    if (!is_array($allowed_values) || $allowed_values === []) {
      return $value;
    }

    if (array_key_exists($value, $allowed_values)) {
      return $allowed_values[$value];
    }

    $value_string = (string) $value;
    foreach ($allowed_values as $allowed_key => $allowed_label) {
      if ((string) $allowed_key === $value_string) {
        return $allowed_label;
      }
    }

    return $value;
  }

  /**
   * {@inheritdoc}
   */
  public function getSupportedTypes(?string $format): array {
    return [
      ListItemBase::class => TRUE,
    ];
  }

}
