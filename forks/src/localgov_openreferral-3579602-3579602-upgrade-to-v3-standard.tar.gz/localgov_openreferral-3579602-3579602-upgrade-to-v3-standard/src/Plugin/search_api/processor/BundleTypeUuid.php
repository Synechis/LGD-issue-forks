<?php

namespace Drupal\localgov_openreferral\Plugin\search_api\processor;

use Drupal\Core\Entity\ContentEntityInterface;
use Drupal\localgov_openreferral\BundleUuidTrait;
use Drupal\search_api\Datasource\DatasourceInterface;
use Drupal\search_api\Item\ItemInterface;
use Drupal\search_api\Processor\ProcessorPluginBase;
use Drupal\search_api\Processor\ProcessorProperty;
use Symfony\Component\DependencyInjection\ContainerInterface;

/**
 * Converts bundle machine names to bundle UUIDs.
 *
 * @SearchApiProcessor(
 *   id = "localgov_openreferral_bundle_uuid",
 *   label = @Translation("Open Referral Bundle UUID"),
 *   description = @Translation("Indexes bundle UUID values for indexed entities."),
 *   stages = {
 *     "add_properties" = 0,
 *   },
 *   locked = true,
 *   hidden = true,
 * )
 */
class BundleTypeUuid extends ProcessorPluginBase {

  use BundleUuidTrait;

  /**
   * Entity type manager.
   *
   * @var \Drupal\Core\Entity\EntityTypeManagerInterface
   */
  protected $entityTypeManager;

  /**
   * {@inheritdoc}
   */
  public static function create(ContainerInterface $container, array $configuration, $plugin_id, $plugin_definition) {
    /** @var static $processor */
    $processor = parent::create($container, $configuration, $plugin_id, $plugin_definition);
    $processor->entityTypeManager = $container->get('entity_type.manager');
    return $processor;
  }

  /**
   * {@inheritdoc}
   */
  public function getPropertyDefinitions(?DatasourceInterface $datasource = NULL) {
    if ($datasource) {
      return [];
    }

    $definition = [
      'label' => $this->t('Open Referral: Bundle UUID'),
      'description' => $this->t('The UUID for the indexed entity bundle.'),
      'type' => 'string',
      'processor_id' => $this->getPluginId(),
    ];

    return ['localgov_openreferral_bundle_uuid' => new ProcessorProperty($definition)];
  }

  /**
   * {@inheritdoc}
   */
  public function addFieldValues(ItemInterface $item) {
    $entity = $item->getOriginalObject()->getValue();
    if (!$entity instanceof ContentEntityInterface) {
      return;
    }

    $bundle_uuid = $this->getBundleUuid($entity);
    if (!$bundle_uuid) {
      return;
    }

    $fields = $item->getFields(FALSE);
    $fields = $this->getFieldsHelper()
      ->filterForPropertyPath($fields, NULL, 'localgov_openreferral_bundle_uuid');
    foreach ($fields as $field) {
      $field->addValue($bundle_uuid);
    }
  }

}
