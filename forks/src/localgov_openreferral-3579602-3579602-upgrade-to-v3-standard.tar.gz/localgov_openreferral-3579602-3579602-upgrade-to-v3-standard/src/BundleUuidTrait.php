<?php

namespace Drupal\localgov_openreferral;

use Drupal\Core\Entity\ContentEntityInterface;
use Drupal\Core\Entity\EntityInterface;
use Drupal\Core\Entity\EntityTypeManagerInterface;

/**
 * Provides helper methods for resolving entity bundle UUIDs.
 */
trait BundleUuidTrait {

  /**
   * Gets a content entity bundle UUID.
   *
   * @param \Drupal\Core\Entity\ContentEntityInterface $entity
   *   The indexed content entity.
   *
   * @return string|null
   *   The bundle UUID, or NULL if the bundle entity cannot be resolved.
   */
  protected function getBundleUuid(ContentEntityInterface $entity): ?string {
    $bundle_entity = $this->getBundleEntity($entity);

    if (!$bundle_entity || !method_exists($bundle_entity, 'uuid')) {
      return NULL;
    }

    return $bundle_entity->uuid();
  }

  /**
   * Gets a content entity bundle label.
   *
   * @param \Drupal\Core\Entity\ContentEntityInterface $entity
   *   The indexed content entity.
   *
   * @return string|null
   *   The bundle label, or NULL if unavailable.
   */
  protected function getBundleLabel(ContentEntityInterface $entity): ?string {
    $bundle_entity = $this->getBundleEntity($entity);
    if (!$bundle_entity || !method_exists($bundle_entity, 'label')) {
      return NULL;
    }

    $label = $bundle_entity->label();
    return is_string($label) && $label !== '' ? $label : NULL;
  }

  /**
   * Gets the bundle entity for a content entity.
   */
  protected function getBundleEntity(ContentEntityInterface $entity): ?EntityInterface {
    $bundle_entity_type_id = $entity->getEntityType()->getBundleEntityType();
    if (!$bundle_entity_type_id) {
      return NULL;
    }

    $bundle_entity = $this->getBundleUuidEntityTypeManager()
      ->getStorage($bundle_entity_type_id)
      ->load($entity->bundle());

    return $bundle_entity instanceof EntityInterface ? $bundle_entity : NULL;
  }

  /**
   * Returns the entity type manager used by bundle UUID resolution.
   */
  protected function getBundleUuidEntityTypeManager(): EntityTypeManagerInterface {
    if (property_exists($this, 'entityTypeManager') && $this->entityTypeManager instanceof EntityTypeManagerInterface) {
      return $this->entityTypeManager;
    }

    return \Drupal::entityTypeManager();
  }

}
