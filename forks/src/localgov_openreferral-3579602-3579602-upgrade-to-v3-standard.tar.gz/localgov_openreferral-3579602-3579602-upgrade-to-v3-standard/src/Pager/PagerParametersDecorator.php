<?php

namespace Drupal\localgov_openreferral\Pager;

use Drupal\Core\Config\ConfigFactoryInterface;
use Drupal\Core\Pager\PagerParametersInterface;
use Drupal\localgov_openreferral\OpenReferralPath;
use Symfony\Component\HttpFoundation\RequestStack;

/**
 * Accounts for Open Referral pager starting at 1.
 *
 * @see \Drupal\Core\Pager\PagerParameters
 */
class PagerParametersDecorator implements PagerParametersInterface {

  /**
   * The HTTP request stack.
   *
   * @var \Symfony\Component\HttpFoundation\RequestStack
   */
  protected $requestStack;

  /**
   * The pager parameters service being decorated.
   *
   * @var \Drupal\Core\Pager\PagerParametersInterface
   */
  protected $pagerParameters;

  /**
   * Open Referral API base path.
   *
   * @var string
   */
  protected $apiBasePath;

  /**
   * Construct a PagerManager object.
   *
   * @param \Drupal\Core\Pager\PagerParametersInterface $pager_parameters
   *   The pager parameters service being decorated.
   * @param \Symfony\Component\HttpFoundation\RequestStack $stack
   *   The current HTTP request stack.
   * @param \Drupal\Core\Config\ConfigFactoryInterface $config_factory
   *   The configuration factory.
   */
  public function __construct(PagerParametersInterface $pager_parameters, RequestStack $stack, ConfigFactoryInterface $config_factory) {
    $this->requestStack = $stack;
    $this->pagerParameters = $pager_parameters;
    $this->apiBasePath = OpenReferralPath::getApiBasePath($config_factory);
  }

  /**
   * {@inheritdoc}
   */
  public function getQueryParameters() {
    return $this->pagerParameters->getQueryParameters();
  }

  /**
   * {@inheritdoc}
   */
  public function findPage($pager_id = 0) {
    // If an openreferral path, the first pager and not on the default page 0,
    // then reduce the page by one.
    $page = $this->pagerParameters->findPage($pager_id);
    $path_info = $this->requestStack->getCurrentRequest()->getPathInfo();
    if ((strpos($path_info, $this->apiBasePath . '/') === 0 || $path_info === $this->apiBasePath) && $pager_id == 0 && $page > 0) {
      $page--;
    }
    return $page;
  }

  /**
   * {@inheritdoc}
   */
  public function getPagerQuery() {
    return $this->pagerParameters->getPagerQuery();
  }

  /**
   * {@inheritdoc}
   */
  public function getPagerParameter() {
    return $this->pagerParameters->getPagerQuery();
  }

}
