<?php

namespace Drupal\localgov_openreferral\Routing;

use Drupal\Core\Config\ConfigFactoryInterface;
use Drupal\Core\Routing\RouteSubscriberBase;
use Drupal\localgov_openreferral\OpenReferralPath;
use Symfony\Component\Routing\RouteCollection;

/**
 * Alters Open Referral routes to use configured API base path.
 */
class OpenReferralRouteSubscriber extends RouteSubscriberBase {

  /**
   * The configuration factory.
   *
   * @var \Drupal\Core\Config\ConfigFactoryInterface
   */
  protected $configFactory;

  /**
   * Constructs an OpenReferralRouteSubscriber object.
   *
   * @param \Drupal\Core\Config\ConfigFactoryInterface $config_factory
   *   The config factory.
   */
  public function __construct(ConfigFactoryInterface $config_factory) {
    $this->configFactory = $config_factory;
  }

  /**
   * {@inheritdoc}
   */
  protected function alterRoutes(RouteCollection $collection): void {
    $configured_base_path = OpenReferralPath::getApiBasePath($this->configFactory);
    $default_base_path = OpenReferralPath::DEFAULT_API_BASE_PATH;

    $route_names = [
      'localgov_openreferral.metadata',
      'localgov_openreferral.service',
      'localgov_openreferral.organization',
      'localgov_openreferral.service_at_location',
      'localgov_openreferral.taxonomy',
      'localgov_openreferral.taxonomy_term',
      'view.localgov_openreferral_services.openreferral_json',
      'view.localgov_openreferral_service_at_locations.openreferral_json',
      'view.localgov_openreferral_organizations.openreferral_json',
      'view.localgov_openreferral_taxonomies.openreferral_json',
      'view.localgov_openreferral_taxonomy_terms.openreferral_json',
    ];

    foreach ($route_names as $route_name) {
      $route = $collection->get($route_name);
      if (!$route) {
        continue;
      }

      $path = $route->getPath();
      if (!str_starts_with($path, $default_base_path)) {
        continue;
      }

      $route->setPath($configured_base_path . substr($path, strlen($default_base_path)));
    }
  }

}
