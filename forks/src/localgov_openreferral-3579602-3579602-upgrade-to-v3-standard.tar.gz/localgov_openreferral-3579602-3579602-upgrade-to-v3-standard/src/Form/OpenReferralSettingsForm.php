<?php

namespace Drupal\localgov_openreferral\Form;

use Drupal\Core\Form\ConfigFormBase;
use Drupal\Core\Form\FormStateInterface;
use Drupal\localgov_openreferral\OpenReferralPath;

/**
 * Settings form for Open Referral API metadata and base path.
 */
class OpenReferralSettingsForm extends ConfigFormBase {

  /**
   * {@inheritdoc}
   */
  public function getFormId() {
    return 'localgov_openreferral_settings_form';
  }

  /**
   * {@inheritdoc}
   */
  protected function getEditableConfigNames() {
    return ['localgov_openreferral.settings'];
  }

  /**
   * {@inheritdoc}
   */
  public function buildForm(array $form, FormStateInterface $form_state) {
    $form['api_base_path'] = [
      '#type' => 'textfield',
      '#title' => $this->t('API base path'),
      '#description' => $this->t('Base path for Open Referral endpoints, for example /openreferral/v3.'),
      '#config_target' => 'localgov_openreferral.settings:api_base_path',
      '#required' => TRUE,
    ];

    $form['version'] = [
      '#type' => 'textfield',
      '#title' => $this->t('Version'),
      '#config_target' => 'localgov_openreferral.settings:version',
    ];

    $form['profile'] = [
      '#type' => 'textfield',
      '#title' => $this->t('Profile'),
      '#config_target' => 'localgov_openreferral.settings:profile',
    ];

    $form['openapi_url'] = [
      '#type' => 'url',
      '#title' => $this->t('OpenAPI URL'),
      '#config_target' => 'localgov_openreferral.settings:openapi_url',
    ];

    return parent::buildForm($form, $form_state);
  }

  /**
   * {@inheritdoc}
   */
  public function validateForm(array &$form, FormStateInterface $form_state) {
    parent::validateForm($form, $form_state);
    $form_state->setValue('api_base_path', OpenReferralPath::normalizeBasePath($form_state->getValue('api_base_path')));
  }

}
