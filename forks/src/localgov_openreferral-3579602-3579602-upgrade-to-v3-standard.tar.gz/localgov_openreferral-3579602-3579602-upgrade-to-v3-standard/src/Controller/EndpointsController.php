<?php

namespace Drupal\localgov_openreferral\Controller;

use Drupal\Core\Controller\ControllerBase;
use Drupal\Core\Entity\ContentEntityInterface;
use Drupal\Core\Entity\EntityTypeManagerInterface;
use Drupal\Core\Field\FieldItemListInterface;
use Drupal\localgov_openreferral\MappingInformation;
use Drupal\rest\ResourceResponse;
use Symfony\Component\DependencyInjection\ContainerInterface;
use Symfony\Component\HttpKernel\Exception\NotFoundHttpException;

/**
 * Returns responses for Open Referral API endpoint routes.
 */
class EndpointsController extends ControllerBase {

  /**
   * Mapping information helper.
   *
   * @var \Drupal\localgov_openreferral\MappingInformation
   */
  protected $mappingInformation;

  /**
   * Entity type manager.
   *
   * @var \Drupal\Core\Entity\EntityTypeManagerInterface
   */
  protected $entityTypeManager;

  /**
   * Constructs an EndpointsController object.
   */
  public function __construct(MappingInformation $mapping_information, EntityTypeManagerInterface $entity_type_manager) {
    $this->mappingInformation = $mapping_information;
    $this->entityTypeManager = $entity_type_manager;
  }

  /**
   * {@inheritdoc}
   */
  public static function create(ContainerInterface $container) {
    return new static(
      $container->get('localgov_openreferral.mapping_information'),
      $container->get('entity_type.manager')
    );
  }

  /**
   * Single entity endpoint.
   */
  public function single(ContentEntityInterface $entity) {
    $response = new ResourceResponse($entity, 200);

    $response->addCacheableDependency($entity);

    foreach ($entity as $field_name => $field) {
      assert($field instanceof FieldItemListInterface);
      $field_access = $field->access('view', NULL, TRUE);
      $response->addCacheableDependency($field_access);

      if (!$field_access->isAllowed()) {
        $entity->set($field_name, NULL);
      }
    }

    return $response;
  }

  /**
   * Single taxonomy endpoint by UUID.
   */
  public function taxonomy(string $uuid): ResourceResponse {
    foreach ($this->mappingInformation->getInternalTypes('taxonomy') as $type_info) {
      $entity_type_id = $type_info['entity_type'];
      $bundle = $type_info['bundle'];
      $entity_type = $this->entityTypeManager->getDefinition($entity_type_id, FALSE);
      if (!$entity_type) {
        continue;
      }
      $bundle_entity_type_id = $entity_type->getBundleEntityType();
      if (!$bundle_entity_type_id) {
        continue;
      }
      $bundle_entity_definition = $this->entityTypeManager->getDefinition($bundle_entity_type_id, FALSE);
      if (!$bundle_entity_definition) {
        continue;
      }
      $uuid_key = $bundle_entity_definition->getKey('uuid');
      $id_key = $bundle_entity_definition->getKey('id');
      if (!$uuid_key || !$id_key) {
        continue;
      }

      $bundle_entities = $this->entityTypeManager
        ->getStorage($bundle_entity_type_id)
        ->loadByProperties([$uuid_key => $uuid]);
      if (!$bundle_entities) {
        continue;
      }

      $bundle_entity = reset($bundle_entities);
      if (!$bundle_entity || $bundle_entity->id() !== $bundle) {
        continue;
      }

      $response = new ResourceResponse([
        'id' => $bundle_entity->uuid(),
        'name' => $bundle_entity->label(),
        'description' => '',
      ], 200);
      $response->addCacheableDependency($bundle_entity);
      return $response;
    }

    throw new NotFoundHttpException();
  }

  /**
   * Metadata endpoint.
   *
   * @return \Drupal\rest\ResourceResponse
   *   Return the metadata resonse.
   */
  public function metadata(): ResourceResponse {
    $config = $this->config('localgov_openreferral.settings');

    $response = new ResourceResponse([
      'version' => $config->get('version'),
      'profile' => $config->get('profile'),
      'openapi_url' => $config->get('openapi_url'),
    ], 200);
    $response->addCacheableDependency($config);

    return $response;
  }

}
