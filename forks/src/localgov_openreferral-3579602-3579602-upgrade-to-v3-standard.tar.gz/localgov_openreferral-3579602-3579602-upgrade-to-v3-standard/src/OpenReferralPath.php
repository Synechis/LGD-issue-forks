<?php

namespace Drupal\localgov_openreferral;

use Drupal\Core\Config\ConfigFactoryInterface;

/**
 * Provides helpers for Open Referral API paths.
 */
final class OpenReferralPath {

  /**
   * Default API base path.
   */
  public const DEFAULT_API_BASE_PATH = '/openreferral/v3';

  /**
   * Get API base path from module settings.
   *
   * @param \Drupal\Core\Config\ConfigFactoryInterface $config_factory
   *   The configuration factory.
   *
   * @return string
   *   Normalized API base path.
   */
  public static function getApiBasePath(ConfigFactoryInterface $config_factory): string {
    $configured_path = $config_factory
      ->get('localgov_openreferral.settings')
      ->get('api_base_path');

    return self::normalizeBasePath($configured_path);
  }

  /**
   * Normalize and validate a base path.
   *
   * @param string|null $path
   *   The configured base path.
   *
   * @return string
   *   A normalized path with a leading slash and no trailing slash.
   */
  public static function normalizeBasePath(?string $path): string {
    $path = trim((string) $path);

    if ($path === '') {
      return self::DEFAULT_API_BASE_PATH;
    }

    if ($path[0] !== '/') {
      $path = '/' . $path;
    }

    $path = rtrim($path, '/');

    return $path === '' ? self::DEFAULT_API_BASE_PATH : $path;
  }

}
