<?php

declare(strict_types=1);

namespace Drupal\Tests\localgov_microsites_demo\Functional;

use PHPUnit\Framework\Attributes\Group;
use Drupal\Tests\BrowserTestBase;

/**
 * Data integrity checks for LocalGov Microsites demo content.
 */
#[Group('localgov_microsites_demo')]
class LocalgovMicrositesDemoIntegrityTest extends BrowserTestBase {

  /**
   * {@inheritdoc}
   */
  protected $profile = 'standard';

  /**
   * {@inheritdoc}
   */
  protected $defaultTheme = 'stark';

  /**
   * {@inheritdoc}
   */
  protected static $modules = [
    'localgov_microsites_demo_test_schema',
    'node',
    'node_storage_body_field',
    'media',
    'path',
    'search',
    'search_node',
    'views',
    'ctools',
    'localgov_core',
    'localgov_media',
  ];

  /**
   * {@inheritdoc}
   */
  protected function setUp(): void {
    parent::setUp();

    $view_mode_storage = $this->container->get('entity_type.manager')->getStorage('entity_view_mode');
    $required_view_modes = [
      'search_index' => 'Search index',
      'search_result' => 'Search result highlighting input',
    ];

    foreach ($required_view_modes as $machine_name => $label) {
      $id = 'node.' . $machine_name;
      if (!$view_mode_storage->load($id)) {
        $view_mode_storage->create([
          'id' => $id,
          'targetEntityType' => 'node',
          'label' => $label,
          'status' => FALSE,
        ])->save();
      }
    }

    $this->container->get('module_installer')->install([
      'localgov_topics',
      'localgov_microsites_group_term_ui',
      'localgov_microsites_blogs',
      'localgov_microsites_news',
      'localgov_microsites_events',
      'localgov_microsites_directories',
      'localgov_microsites_group_webform',
      'localgov_microsites_demo',
    ]);
  }

  /**
   * Ensures expected demo users, Drupal roles and group memberships exist.
   */
  public function testExpectedUsersRolesAndMemberships(): void {
    $users = [
      'park-controller' => [
        'roles' => ['microsites_controller', 'microsites_trusted_editor'],
        'group_uuid' => 'd8b010b5-5bbd-4333-a81b-5a58eae9b121',
        'expects_group_admin' => TRUE,
      ],
      'park-editor' => [
        'roles' => ['microsites_trusted_editor'],
        'group_uuid' => 'd8b010b5-5bbd-4333-a81b-5a58eae9b121',
        'expects_group_admin' => FALSE,
      ],
      'living-controller' => [
        'roles' => ['microsites_controller', 'microsites_trusted_editor'],
        'group_uuid' => '39342783-d0a8-4f83-9528-f8fce250e21f',
        'expects_group_admin' => TRUE,
      ],
      'living-editor' => [
        'roles' => ['microsites_trusted_editor'],
        'group_uuid' => '39342783-d0a8-4f83-9528-f8fce250e21f',
        'expects_group_admin' => FALSE,
      ],
      'blog-controller' => [
        'roles' => ['microsites_controller', 'microsites_trusted_editor'],
        'group_uuid' => '53e7283e-e826-4bad-928e-fbbddc6cfbbf',
        'expects_group_admin' => TRUE,
      ],
      'blog-editor' => [
        'roles' => ['microsites_trusted_editor'],
        'group_uuid' => '53e7283e-e826-4bad-928e-fbbddc6cfbbf',
        'expects_group_admin' => FALSE,
      ],
    ];

    $user_storage = $this->container->get('entity_type.manager')->getStorage('user');
    $group_storage = $this->container->get('entity_type.manager')->getStorage('group');
    $relationship_storage = $this->container->get('entity_type.manager')->getStorage('group_relationship');

    foreach ($users as $username => $expectation) {
      $matched_users = $user_storage->loadByProperties(['name' => $username]);
      $this->assertCount(1, $matched_users, sprintf('User "%s" should exist exactly once.', $username));
      $user = reset($matched_users);

      foreach ($expectation['roles'] as $role) {
        $this->assertTrue($user->hasRole($role), sprintf('User "%s" should have role "%s".', $username, $role));
      }

      $matched_groups = $group_storage->loadByProperties(['uuid' => $expectation['group_uuid']]);
      $this->assertCount(1, $matched_groups, sprintf('Expected group UUID "%s" should exist.', $expectation['group_uuid']));
      $group = reset($matched_groups);

      $memberships = $relationship_storage->loadByProperties([
        'type' => 'microsite-group_membership',
        'entity_id' => $user->id(),
        'gid' => $group->id(),
      ]);

      $this->assertCount(1, $memberships, sprintf('User "%s" should be a member of group "%s".', $username, $group->label()));
      $membership = reset($memberships);
      $membership_roles = array_column($membership->get('group_roles')->getValue(), 'target_id');

      if ($expectation['expects_group_admin']) {
        $this->assertContains('microsite-admin', $membership_roles, sprintf('User "%s" should be a microsite-admin in group "%s".', $username, $group->label()));
      }
    }
  }

  /**
   * Verifies groups, domains and domain->group reference are correctly created.
   */
  public function testGroupsDomainsAndGroupReference(): void {
    $expected = $this->expectedMicrosites();
    $group_storage = $this->container->get('entity_type.manager')->getStorage('group');
    $domain_storage = $this->container->get('entity_type.manager')->getStorage('domain');

    foreach ($expected as $group_uuid => $settings) {
      $groups = $group_storage->loadByProperties(['uuid' => $group_uuid]);
      $this->assertCount(1, $groups, sprintf('Group UUID "%s" should exist.', $group_uuid));
      $group = reset($groups);

      $domain = $domain_storage->load('group_' . $group->id());
      $this->assertNotNull($domain, sprintf('Expected domain for group "%s".', $group->label()));
      $this->assertSame($settings['hostname'], $domain->getHostname());
      $this->assertSame($group_uuid, $domain->getThirdPartySetting('group_context_domain', 'group_uuid'));
    }
  }

  /**
   * Verifies each microsite domain config has name/slogan/front-page set.
   */
  public function testDomainSiteConfigIsSet(): void {
    $expected = $this->expectedMicrosites();
    $group_storage = $this->container->get('entity_type.manager')->getStorage('group');

    foreach ($expected as $group_uuid => $settings) {
      $groups = $group_storage->loadByProperties(['uuid' => $group_uuid]);
      $this->assertCount(1, $groups);
      $group = reset($groups);

      $config = $this->config('domain.config.group_' . $group->id() . '.system.site');
      $this->assertSame($group->label(), $config->get('name'));
      $this->assertSame($settings['site_slogan'], $config->get('slogan'));
      $this->assertNotEmpty($config->get('page.front'));
    }
  }

  /**
   * Ensures all demo menu links reference menus that exist.
   */
  public function testAllMenuLinksReferenceExistingMenus(): void {
    $link_storage = $this->container->get('entity_type.manager')->getStorage('menu_link_content');
    $menu_storage = $this->container->get('entity_type.manager')->getStorage('menu');
    $group_menu_storage = $this->container->get('entity_type.manager')->getStorage('group_content_menu');

    $links = $link_storage->loadMultiple();
    $this->assertNotEmpty($links, 'Expected demo menu links to be present.');

    foreach ($links as $link) {
      $menu_name = $link->getMenuName();
      $this->assertNotEmpty($menu_name, sprintf('Menu link "%s" should define a menu.', $link->label()));

      $menu = $menu_storage->load($menu_name);
      if ($menu) {
        continue;
      }

      if (str_starts_with($menu_name, 'group_menu_link_content-')) {
        $group_menu_id = str_replace('group_menu_link_content-', '', $menu_name);
        $this->assertNotNull(
          $group_menu_storage->load($group_menu_id),
          sprintf('Group content menu "%s" should exist for link "%s".', $menu_name, $link->label())
        );
        continue;
      }

      $this->fail(sprintf('Menu "%s" should exist for link "%s".', $menu_name, $link->label()));
    }
  }

  /**
   * Checks newsroom featured list and reverse article newsroom references.
   */
  public function testNewsroomFeaturedArticlesIntegrity(): void {
    $node_storage = $this->container->get('entity_type.manager')->getStorage('node');

    $newsroom_ids = $node_storage->getQuery()
      ->accessCheck(FALSE)
      ->condition('type', 'localgov_newsroom')
      ->condition('status', 1)
      ->execute();

    $this->assertNotEmpty($newsroom_ids, 'Expected at least one published newsroom.');

    foreach ($node_storage->loadMultiple($newsroom_ids) as $newsroom) {
      $featured = $newsroom->get('localgov_newsroom_featured')->referencedEntities();
      $this->assertNotEmpty($featured, sprintf('Newsroom "%s" should have featured articles.', $newsroom->label()));

      foreach ($featured as $article) {
        $this->assertSame('localgov_news_article', $article->bundle(), sprintf('Featured item "%s" should be a news article.', $article->label()));
        $referenced_newsroom_ids = array_column($article->get('localgov_newsroom')->getValue(), 'target_id');
        $this->assertContains((string) $newsroom->id(), array_map('strval', $referenced_newsroom_ids), sprintf('Article "%s" should reference newsroom "%s".', $article->label(), $newsroom->label()));
      }
    }
  }

  /**
   * Checks facets demo content and expected facet-type config entities.
   */
  public function testFacetsSetup(): void {
    $facet_type_storage = $this->container->get('entity_type.manager')->getStorage('localgov_directories_facets_type');
    $facet_storage = $this->container->get('entity_type.manager')->getStorage('localgov_directories_facets');
    $relationship_storage = $this->container->get('entity_type.manager')->getStorage('group_relationship');
    $living_group_id = $this->groupIdByUuid('39342783-d0a8-4f83-9528-f8fce250e21f');

    foreach (['age_group', 'area', 'service'] as $facet_type) {
      $this->assertNotNull($facet_type_storage->load($facet_type), sprintf('Facet type "%s" should exist.', $facet_type));
    }

    $expected_titles = [
      '16-18 years',
      '18-25 years',
      '25-65 years',
      'Over 65s',
      'West Scarfolk',
      'National',
      'Independent Living',
      'Getting out and about',
    ];

    foreach ($expected_titles as $title) {
      $facets = $facet_storage->loadByProperties(['title' => $title]);
      $this->assertCount(1, $facets, sprintf('Facet "%s" should exist exactly once.', $title));
      $facet = reset($facets);

      $relationships = $relationship_storage->loadByProperties(['entity_id' => $facet->id()]);
      $facet_relationships = [];
      foreach ($relationships as $relationship) {
        $related = $relationship->get('entity_id')->entity;
        if ($related && $related->getEntityTypeId() === 'localgov_directories_facets') {
          $facet_relationships[] = $relationship;
        }
      }

      $this->assertNotEmpty($facet_relationships, sprintf('Facet "%s" should belong to a group.', $title));
      $matching = array_filter($facet_relationships, static fn($relationship) => (int) $relationship->get('gid')->target_id === $living_group_id);
      $this->assertNotEmpty($matching, sprintf('Facet "%s" should belong to the Independent Living group.', $title));
    }
  }

  /**
   * Running settings assignment repeatedly should not duplicate domains.
   */
  public function testSettingsFunctionIsIdempotent(): void {
    $domain_storage = $this->container->get('entity_type.manager')->getStorage('domain');

    $before_ids = $this->groupDomainIds($domain_storage->loadMultiple());

    \_localgov_microsites_demo_set_group_settings();
    \_localgov_microsites_demo_set_group_settings();

    $after_domains = $domain_storage->loadMultiple();
    $after_ids = $this->groupDomainIds($after_domains);

    sort($before_ids);
    sort($after_ids);

    $this->assertSame($before_ids, $after_ids, 'Group domain IDs should remain unchanged after repeated settings runs.');
    $this->assertCount(3, $after_ids, 'Expected exactly three microsite domains.');
    $this->assertCount(3, array_unique($after_ids), 'Microsite domain IDs should be unique.');
  }

  /**
   * Exporting/reimporting a group relationship must preserve its group link.
   */
  public function testGroupRelationshipExportImportKeepsGroup(): void {
    $relationship_storage = $this->container->get('entity_type.manager')->getStorage('group_relationship');
    $normalizer = $this->container->get('default_content.content_entity_normalizer');

    $matches = $relationship_storage->loadByProperties(['uuid' => 'ddcb3582-b009-4805-b491-43e6c5712f4a']);
    $original = reset($matches);
    $this->assertNotFalse($original, 'Expected test group relationship entity to exist.');

    $original_group_uuid = $original->get('gid')->entity->uuid();
    $original_related_uuid = $original->get('entity_id')->entity->uuid();

    $normalized = $normalizer->normalize($original);
    $original->delete();

    $recreated = $normalizer->denormalize($normalized);
    $recreated->save();

    $this->assertSame($original_group_uuid, $recreated->get('gid')->entity->uuid());
    $this->assertSame($original_related_uuid, $recreated->get('entity_id')->entity->uuid());
  }

  /**
   * Confirms exact demo group UUID set exists and only once each.
   */
  public function testGroupUuidMatching(): void {
    $group_storage = $this->container->get('entity_type.manager')->getStorage('group');

    foreach (array_keys($this->expectedMicrosites()) as $group_uuid) {
      $groups = $group_storage->loadByProperties(['uuid' => $group_uuid]);
      $this->assertCount(1, $groups, sprintf('Group UUID "%s" should match exactly one group.', $group_uuid));
    }
  }

  /**
   * Sanity check that the module can be uninstalled without fatal errors.
   */
  public function testModuleUninstallsCleanly(): void {
    $installer = $this->container->get('module_installer');
    $module_handler = $this->container->get('module_handler');

    $this->assertTrue($module_handler->moduleExists('localgov_microsites_demo'));
    $installer->uninstall(['localgov_microsites_demo']);
    $this->assertFalse($module_handler->moduleExists('localgov_microsites_demo'));
  }

  /**
   * Expected UUID-keyed microsite settings used by install logic.
   */
  protected function expectedMicrosites(): array {
    return [
      'd8b010b5-5bbd-4333-a81b-5a58eae9b121' => [
        'hostname' => 'localgov-micro-1.ddev.site',
        'site_slogan' => 'The people\'s park',
      ],
      '39342783-d0a8-4f83-9528-f8fce250e21f' => [
        'hostname' => 'localgov-micro-2.ddev.site',
        'site_slogan' => 'Supporting independent living in Scarfolk',
      ],
      '53e7283e-e826-4bad-928e-fbbddc6cfbbf' => [
        'hostname' => 'localgov-micro-3.ddev.site',
        'site_slogan' => 'Musings from the Digital team',
      ],
    ];
  }

  /**
   * Resolve group ID by UUID.
   */
  protected function groupIdByUuid(string $group_uuid): int {
    $group_storage = $this->container->get('entity_type.manager')->getStorage('group');
    $groups = $group_storage->loadByProperties(['uuid' => $group_uuid]);
    $this->assertCount(1, $groups, sprintf('Group UUID "%s" should exist.', $group_uuid));

    return (int) reset($groups)->id();
  }

  /**
   * Filters domain IDs created for microsites.
   */
  protected function groupDomainIds(array $domains): array {
    $ids = [];

    foreach ($domains as $domain) {
      $id = (string) $domain->id();
      if (str_starts_with($id, 'group_')) {
        $ids[] = $id;
      }
    }

    return $ids;
  }

}
