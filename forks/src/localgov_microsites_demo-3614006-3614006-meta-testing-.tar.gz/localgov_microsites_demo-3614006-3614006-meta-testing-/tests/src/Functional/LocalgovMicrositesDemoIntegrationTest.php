<?php

declare(strict_types=1);

namespace Drupal\Tests\localgov_microsites_demo\Functional;

use PHPUnit\Framework\Attributes\Group;
use Drupal\Tests\BrowserTestBase;

/**
 * Functional smoke checks for LocalGov Microsites demo content.
 */
#[Group('localgov_microsites_demo')]
class LocalgovMicrositesDemoIntegrationTest extends BrowserTestBase {

  /**
   * {@inheritdoc}
   */
  protected $profile = 'standard';

  /**
   * {@inheritdoc}
   */
  protected $defaultTheme = 'stark';

  /**
   * {@inheritdoc}
   */
  protected static $modules = [
    'localgov_microsites_demo_test_schema',
    'node',
    'node_storage_body_field',
    'media',
    'path',
    'search',
    'search_node',
    'views',
    'ctools',
    'localgov_core',
    'localgov_media',
  ];

  /**
   * {@inheritdoc}
   */
  protected function setUp(): void {
    parent::setUp();

    $view_mode_storage = $this->container->get('entity_type.manager')->getStorage('entity_view_mode');
    $required_view_modes = [
      'search_index' => 'Search index',
      'search_result' => 'Search result highlighting input',
    ];

    foreach ($required_view_modes as $machine_name => $label) {
      $id = 'node.' . $machine_name;
      if (!$view_mode_storage->load($id)) {
        $view_mode_storage->create([
          'id' => $id,
          'targetEntityType' => 'node',
          'label' => $label,
          'status' => FALSE,
        ])->save();
      }
    }

    $this->container->get('module_installer')->install([
      'localgov_topics',
      'localgov_microsites_group_term_ui',
      'localgov_microsites_blogs',
      'localgov_microsites_news',
      'localgov_microsites_events',
      'localgov_microsites_directories',
      'localgov_microsites_group_webform',
      'localgov_microsites_demo',
    ]);
  }

  /**
   * Confirms module install and dependency modules in Standard profile.
   */
  public function testModuleInstallsInStandardProfile(): void {
    $module_handler = $this->container->get('module_handler');

    $this->assertSame('standard', \Drupal::installProfile());
    $this->assertTrue($module_handler->moduleExists('localgov_microsites_demo'));
    $this->assertTrue($module_handler->moduleExists('localgov_microsites_group'));
    $this->assertTrue($module_handler->moduleExists('localgov_directories'));
    $this->assertTrue($module_handler->moduleExists('default_content'));
  }

  /**
   * Verifies each microsite front page can be loaded.
   */
  public function testMicrositeFrontPagesLoad(): void {
    $expected = $this->expectedMicrosites();
    $group_storage = $this->container->get('entity_type.manager')->getStorage('group');

    foreach ($expected as $group_uuid => $settings) {
      $groups = $group_storage->loadByProperties(['uuid' => $group_uuid]);
      $this->assertCount(1, $groups);
      $group = reset($groups);

      $domain_config = $this->config('domain.config.group_' . $group->id() . '.system.site');
      $front_page = $domain_config->get('page.front');
      $this->assertNotEmpty($front_page, sprintf('Front page should be set for group "%s".', $group->label()));
      $this->assertPathIsReachable((string) $front_page, sprintf('Front page path should resolve and be accessible for group "%s".', $group->label()));
    }
  }

  /**
   * Ensures sample published content exists by bundle with valid paths/groups.
   */
  public function testSampleContentByTypeWithGroupAndWorkingPath(): void {
    $node_storage = $this->container->get('entity_type.manager')->getStorage('node');
    $relationship_storage = $this->container->get('entity_type.manager')->getStorage('group_relationship');
    $path_alias_manager = $this->container->get('path_alias.manager');
    $expected_group_ids = $this->expectedGroupIds();

    $node_bundles = [
      'localgov_blog_channel',
      'localgov_blog_post',
      'localgov_directories_page',
      'localgov_directories_venue',
      'localgov_directory',
      'localgov_directory_promo_page',
      'localgov_event',
      'localgov_news_article',
      'localgov_newsroom',
      'localgov_page',
      'localgov_webform',
    ];

    foreach ($node_bundles as $bundle) {
      $ids = $node_storage->getQuery()
        ->accessCheck(FALSE)
        ->condition('type', $bundle)
        ->condition('status', 1)
        ->range(0, 1)
        ->execute();

      $this->assertNotEmpty($ids, sprintf('Expected at least one published node of type "%s".', $bundle));
      $node = $node_storage->load(reset($ids));

      $relationships = $relationship_storage->loadByProperties(['entity_id' => $node->id()]);
      $linked_group_ids = [];
      foreach ($relationships as $relationship) {
        $related = $relationship->get('entity_id')->entity;
        if (!$related || $related->getEntityTypeId() !== 'node') {
          continue;
        }
        $linked_group_ids[] = (int) $relationship->get('gid')->target_id;
      }

      $linked_group_ids = array_values(array_unique($linked_group_ids));
      $this->assertNotEmpty(array_intersect($expected_group_ids, $linked_group_ids), sprintf('Node "%s" should be related to one of the expected microsite groups.', $node->label()));

      $system_path = '/node/' . $node->id();
      $alias = $path_alias_manager->getAliasByPath($system_path);
      $visit_path = $alias !== $system_path ? $alias : $system_path;
      $this->assertPathIsReachable($visit_path, sprintf('Node "%s" should have a reachable path.', $node->label()));
    }
  }

  /**
   * Expected UUID-keyed microsite settings used by install logic.
   */
  protected function expectedMicrosites(): array {
    return [
      'd8b010b5-5bbd-4333-a81b-5a58eae9b121' => [
        'hostname' => 'localgov-micro-1.ddev.site',
        'site_slogan' => 'The people\'s park',
      ],
      '39342783-d0a8-4f83-9528-f8fce250e21f' => [
        'hostname' => 'localgov-micro-2.ddev.site',
        'site_slogan' => 'Supporting independent living in Scarfolk',
      ],
      '53e7283e-e826-4bad-928e-fbbddc6cfbbf' => [
        'hostname' => 'localgov-micro-3.ddev.site',
        'site_slogan' => 'Musings from the Digital team',
      ],
    ];
  }

  /**
   * Returns numeric group IDs for the expected microsites.
   */
  protected function expectedGroupIds(): array {
    $group_storage = $this->container->get('entity_type.manager')->getStorage('group');
    $ids = [];

    foreach (array_keys($this->expectedMicrosites()) as $group_uuid) {
      $groups = $group_storage->loadByProperties(['uuid' => $group_uuid]);
      $this->assertCount(1, $groups, sprintf('Group UUID "%s" should exist.', $group_uuid));
      $ids[] = (int) reset($groups)->id();
    }

    return $ids;
  }

  /**
   * Asserts that a path resolves to a routable URL and is accessible.
   */
  protected function assertPathIsReachable(string $path, string $message = ''): void {
    $normalized_path = '/' . ltrim($path, '/');
    $url = $this->container->get('path.validator')->getUrlIfValid($normalized_path);

    $this->assertNotNull(
      $url,
      $message !== '' ? $message : sprintf('Path "%s" should resolve to a valid route.', $normalized_path)
    );

    if ($url) {
      $access = $this->container->get('access_manager')->checkNamedRoute(
        $url->getRouteName(),
        $url->getRouteParameters(),
        $this->container->get('current_user')
      );

      $this->assertTrue(
        $access->isAllowed(),
        sprintf('Path "%s" should be accessible.', $normalized_path)
      );
    }
  }

}
