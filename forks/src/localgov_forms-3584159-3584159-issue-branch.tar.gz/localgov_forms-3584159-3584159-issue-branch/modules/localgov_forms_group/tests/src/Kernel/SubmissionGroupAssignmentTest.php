<?php

declare(strict_types=1);

namespace Drupal\Tests\localgov_forms_group\Kernel;

use Drupal\group\Entity\GroupRelationship;
use Drupal\webform\Entity\WebformSubmission;

/**
 * Tests automatic assignment of webform submissions to groups.
 *
 * @group localgov_forms_group
 *
 * @covers ::localgov_forms_group_entity_insert
 */
class SubmissionGroupAssignmentTest extends LocalGovFormsGroupKernelTestBase {

  /**
   * A submission for a grouped webform joins the same group.
   */
  public function testSubmissionJoinsWebformGroup(): void {
    $group_type = $this->createGroupType();
    $this->installWebformRelation($group_type);

    $webform = $this->createWebform();
    $group = $this->createGroup(['type' => $group_type->id()]);
    $group->addRelationship($webform, 'group_webform');

    $submission = WebformSubmission::create([
      'webform_id' => $webform->id(),
      'data' => ['name' => 'Jo'],
    ]);
    $submission->save();

    $relationships = GroupRelationship::loadByEntity($submission);
    $this->assertCount(1, $relationships, 'The submission has exactly one group relationship.');

    $relationship = reset($relationships);
    $this->assertEquals('group_webform_submission', $relationship->getPluginId());
    $this->assertEquals($group->id(), $relationship->getGroupId(), 'The submission joined the webform group.');
  }

  /**
   * A submission for a webform shared by two groups joins both.
   */
  public function testSubmissionJoinsAllWebformGroups(): void {
    $group_type = $this->createGroupType();
    $this->installWebformRelation($group_type);

    $webform = $this->createWebform();
    $group_a = $this->createGroup(['type' => $group_type->id()]);
    $group_b = $this->createGroup(['type' => $group_type->id()]);
    $group_a->addRelationship($webform, 'group_webform');
    $group_b->addRelationship($webform, 'group_webform');

    $submission = WebformSubmission::create([
      'webform_id' => $webform->id(),
      'data' => ['name' => 'Jo'],
    ]);
    $submission->save();

    $relationships = GroupRelationship::loadByEntity($submission);
    $group_ids = array_map(static fn ($relationship) => $relationship->getGroupId(), $relationships);
    sort($group_ids);
    $expected = [$group_a->id(), $group_b->id()];
    sort($expected);

    $this->assertEquals($expected, $group_ids, 'The submission joined both groups the webform belongs to.');
  }

  /**
   * A submission for an ungrouped webform creates no relationship.
   */
  public function testUngroupedWebformSubmissionHasNoRelationship(): void {
    $group_type = $this->createGroupType();
    $this->installWebformRelation($group_type);

    // Webform is never related to any group.
    $webform = $this->createWebform();

    $submission = WebformSubmission::create([
      'webform_id' => $webform->id(),
      'data' => ['name' => 'Jo'],
    ]);
    $submission->save();

    $this->assertEmpty(
      GroupRelationship::loadByEntity($submission),
      'A submission for an ungrouped webform is not added to any group.'
    );
  }

  /**
   * An authenticated user's submission stores no anonymous session id.
   *
   * GroupKernelTestBase sets the current user to a real account, so the
   * anonymous branch of hook_entity_insert() must not run.
   */
  public function testAuthenticatedSubmissionHasNoSessionId(): void {
    $group_type = $this->createGroupType();
    $this->installWebformRelation($group_type);

    $webform = $this->createWebform();
    $group = $this->createGroup(['type' => $group_type->id()]);
    $group->addRelationship($webform, 'group_webform');

    $this->assertFalse($this->getCurrentUser()->isAnonymous(), 'Sanity check: current user is authenticated.');

    $submission = WebformSubmission::create([
      'webform_id' => $webform->id(),
      'data' => ['name' => 'Jo'],
    ]);
    $submission->save();

    $this->assertArrayNotHasKey(
      'anonymous_session_id',
      $submission->getData(),
      'Authenticated submissions do not get an anonymous_session_id.'
    );
  }

}
