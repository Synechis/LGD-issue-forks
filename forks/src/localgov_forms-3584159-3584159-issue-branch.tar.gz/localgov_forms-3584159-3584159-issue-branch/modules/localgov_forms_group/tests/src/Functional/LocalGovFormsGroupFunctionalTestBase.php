<?php

declare(strict_types=1);

namespace Drupal\Tests\localgov_forms_group\Functional;

use Drupal\Tests\BrowserTestBase;
use Drupal\Tests\group\Traits\GroupTestTrait;
use Drupal\user\RoleInterface;
use Drupal\group\Entity\GroupInterface;
use Drupal\group\Entity\Storage\GroupRelationshipTypeStorageInterface;
use Drupal\webform\Entity\Webform;
use Drupal\webform\WebformInterface;

/**
 * Base class for LocalGov Forms Group functional tests.
 */
abstract class LocalGovFormsGroupFunctionalTestBase extends BrowserTestBase {

  use GroupTestTrait;

  /**
   * The machine name of the fixture webform.
   */
  protected const WEBFORM_ID = 'lgf_group_test';

  /**
   * {@inheritdoc}
   */
  protected $defaultTheme = 'stark';

  /**
   * {@inheritdoc}
   */
  protected static $modules = ['localgov_forms_group_test'];

  /**
   * The group the fixture webform is related to.
   *
   * @var \Drupal\group\Entity\GroupInterface
   */
  protected GroupInterface $group;

  /**
   * The group type used in testing.
   *
   * @var \Drupal\group\Entity\GroupTypeInterface
   */
  protected $groupType;

  /**
   * {@inheritdoc}
   */
  protected function setUp(): void {
    parent::setUp();

    $this->entityTypeManager = $this->container->get('entity_type.manager');

    // Let anonymous submitters track and view their own submission. This is
    // what makes Webform record the submission against the session, and is the
    // grant that Group would otherwise override for non-members.
    user_role_grant_permissions(RoleInterface::ANONYMOUS_ID, ['view own webform submission']);

    // Enable the group_webform relation (and, automatically, its companion).
    $this->groupType = $this->createGroupType(['creator_membership' => FALSE]);
    $storage = $this->entityTypeManager->getStorage('group_relationship_type');
    assert($storage instanceof GroupRelationshipTypeStorageInterface);
    $storage->createFromPlugin($this->groupType, 'group_webform')->save();

    // Relate the fixture webform to a group.
    $this->group = $this->createGroup(['type' => $this->groupType->id()]);
    $this->group->addRelationship($this->getWebform(), 'group_webform');
  }

  /**
   * Loads the fixture webform.
   *
   * @return \Drupal\webform\WebformInterface
   *   The webform.
   */
  protected function getWebform(): WebformInterface {
    return Webform::load(static::WEBFORM_ID);
  }

  /**
   * Loads the most recently created submission for the fixture webform.
   *
   * @return \Drupal\webform\WebformSubmissionInterface
   *   The submission.
   */
  protected function getLastSubmission() {
    $storage = $this->entityTypeManager->getStorage('webform_submission');
    $ids = $storage->getQuery()
      ->accessCheck(FALSE)
      ->condition('webform_id', static::WEBFORM_ID)
      ->sort('sid', 'DESC')
      ->range(0, 1)
      ->execute();
    $this->assertNotEmpty($ids, 'A submission exists for the fixture webform.');
    return $storage->loadUnchanged((int) reset($ids));
  }

}
