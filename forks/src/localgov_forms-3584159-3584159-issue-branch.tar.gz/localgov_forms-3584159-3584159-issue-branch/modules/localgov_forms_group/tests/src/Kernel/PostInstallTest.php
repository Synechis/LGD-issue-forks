<?php

declare(strict_types=1);

namespace Drupal\Tests\localgov_forms_group\Kernel;

use Drupal\group\Entity\Storage\GroupRelationshipTypeStorageInterface;

/**
 * Tests installation and removal of the group_webform relation pair.
 *
 * The group_webform_submission relation is code-only and is installed
 * automatically alongside group_webform by LocalGovGroupWebformPostInstall.
 * When group_webform is removed its companion must be removed too.
 *
 * @group localgov_forms_group
 *
 * @covers \Drupal\localgov_forms_group\Plugin\Group\RelationHandler\LocalGovGroupWebformPostInstall
 * @covers ::localgov_forms_group_group_relationship_type_delete
 */
class PostInstallTest extends LocalGovFormsGroupKernelTestBase {

  /**
   * The group relationship type storage.
   *
   * @var \Drupal\group\Entity\Storage\GroupRelationshipTypeStorageInterface
   */
  protected $relationshipTypeStorage;

  /**
   * {@inheritdoc}
   */
  protected function setUp(): void {
    parent::setUp();

    $storage = $this->entityTypeManager->getStorage('group_relationship_type');
    assert($storage instanceof GroupRelationshipTypeStorageInterface);
    $this->relationshipTypeStorage = $storage;
  }

  /**
   * Installing group_webform auto-installs the group_webform_submission peer.
   */
  public function testCompanionInstalledAutomatically(): void {
    $group_type = $this->createGroupType();

    // Before installation neither relation should exist.
    $this->assertNull($this->loadRelationshipType($group_type->id(), 'group_webform'));
    $this->assertNull($this->loadRelationshipType($group_type->id(), 'group_webform_submission'));

    $this->installWebformRelation($group_type);

    // Both the webform relation and its companion should now exist.
    $this->assertNotNull($this->loadRelationshipType($group_type->id(), 'group_webform'));
    $this->assertNotNull(
      $this->loadRelationshipType($group_type->id(), 'group_webform_submission'),
      'The code-only group_webform_submission companion was installed automatically.'
    );
  }

  /**
   * Installing the relation twice is idempotent and creates one companion.
   */
  public function testCompanionInstallIsIdempotent(): void {
    $group_type = $this->createGroupType();

    $this->installWebformRelation($group_type);
    // A second creation of the same plugin would normally collide; the
    // post-install handler must guard against installing the companion twice.
    // Re-running the install task directly simulates a repeated install.
    $relationship_type = $this->loadRelationshipType($group_type->id(), 'group_webform');
    $handler = $this->container->get('group_relation_type.manager')
      ->getPostInstallHandler('group_webform');
    foreach ($handler->getInstallTasks() as $task) {
      call_user_func_array($task, [$relationship_type, FALSE]);
    }

    $companion = $this->loadRelationshipType($group_type->id(), 'group_webform_submission');
    $this->assertNotNull($companion);
  }

  /**
   * Deleting group_webform cascades to delete its companion.
   */
  public function testCompanionRemovedWithWebformRelation(): void {
    $group_type = $this->createGroupType();
    $this->installWebformRelation($group_type);

    $webform_relation = $this->loadRelationshipType($group_type->id(), 'group_webform');
    $this->assertNotNull($webform_relation);
    $this->assertNotNull($this->loadRelationshipType($group_type->id(), 'group_webform_submission'));

    $webform_relation->delete();

    $this->assertNull(
      $this->loadRelationshipType($group_type->id(), 'group_webform_submission'),
      'Deleting group_webform also removed its group_webform_submission companion.'
    );
  }

  /**
   * Loads a relationship type by group type and plugin id, or NULL.
   *
   * @param string $group_type_id
   *   The group type id.
   * @param string $plugin_id
   *   The relation plugin id.
   *
   * @return \Drupal\group\Entity\GroupRelationshipTypeInterface|null
   *   The relationship type, or NULL when it does not exist.
   */
  protected function loadRelationshipType(string $group_type_id, string $plugin_id) {
    $id = $this->relationshipTypeStorage->getRelationshipTypeId($group_type_id, $plugin_id);
    return $this->relationshipTypeStorage->load($id);
  }

}
