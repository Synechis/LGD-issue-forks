<?php

declare(strict_types=1);

namespace Drupal\Tests\localgov_forms_group\Kernel;

/**
 * Tests the group_webform_submission permission provider.
 *
 * Submissions are related to groups programmatically, so the manual "create"
 * permissions (relate an existing entity / create a new entity in the group)
 * are hidden, while view/update/delete permissions remain.
 *
 * @group localgov_forms_group
 *
 * @covers \Drupal\localgov_forms_group\Plugin\Group\RelationHandler\LocalGovGroupWebformSubmissionPermissionProvider
 */
class SubmissionPermissionProviderTest extends LocalGovFormsGroupKernelTestBase {

  /**
   * The permission provider for the group_webform_submission relation.
   *
   * @var \Drupal\group\Plugin\Group\RelationHandler\PermissionProviderInterface
   */
  protected $permissionProvider;

  /**
   * {@inheritdoc}
   */
  protected function setUp(): void {
    parent::setUp();

    $this->permissionProvider = $this->container->get('group_relation_type.manager')
      ->getPermissionProvider('group_webform_submission');
  }

  /**
   * The "create" permissions are hidden for both targets.
   */
  public function testCreatePermissionsHidden(): void {
    $this->assertFalse(
      $this->permissionProvider->getPermission('create', 'entity'),
      'Creating a submission directly in the group is not offered.',
    );
    $this->assertFalse(
      $this->permissionProvider->getPermission('create', 'relationship'),
      'Relating an existing submission to the group is not offered.',
    );
  }

  /**
   * View/update/delete permissions are still provided.
   */
  public function testAccessPermissionsStillProvided(): void {
    $this->assertNotFalse(
      $this->permissionProvider->getPermission('view', 'entity', 'any'),
      'The view-any entity permission is still provided.',
    );
    $this->assertNotFalse(
      $this->permissionProvider->getPermission('update', 'entity', 'any'),
      'The update-any entity permission is still provided.',
    );
    $this->assertNotFalse(
      $this->permissionProvider->getPermission('delete', 'entity', 'any'),
      'The delete-any entity permission is still provided.',
    );
  }

  /**
   * The built permission list omits the "create" permissions.
   */
  public function testBuiltPermissionsOmitCreate(): void {
    $permissions = $this->permissionProvider->buildPermissions();

    $this->assertArrayNotHasKey('create group_webform_submission entity', $permissions);
    $this->assertArrayNotHasKey('create group_webform_submission relationship', $permissions);
    $this->assertArrayHasKey('view group_webform_submission entity', $permissions);
  }

}
