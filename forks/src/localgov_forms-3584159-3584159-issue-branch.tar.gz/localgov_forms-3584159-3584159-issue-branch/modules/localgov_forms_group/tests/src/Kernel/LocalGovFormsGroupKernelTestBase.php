<?php

declare(strict_types=1);

namespace Drupal\Tests\localgov_forms_group\Kernel;

use Drupal\Tests\group\Kernel\GroupKernelTestBase;
use Drupal\group\Entity\GroupTypeInterface;
use Drupal\group\Entity\Storage\GroupRelationshipTypeStorageInterface;
use Drupal\webform\Entity\Webform;
use Drupal\webform\WebformInterface;

/**
 * Base class for LocalGov Forms Group kernel tests.
 *
 * Bootstraps Group + Webform together and provides helpers for installing the
 * group_webform relation on a group type and creating webforms.
 */
abstract class LocalGovFormsGroupKernelTestBase extends GroupKernelTestBase {

  /**
   * {@inheritdoc}
   */
  protected static $modules = [
    'entity',
    'flexible_permissions',
    'group',
    'options',
    'webform',
    'localgov_forms_group',
  ];

  /**
   * {@inheritdoc}
   */
  protected function setUp(): void {
    parent::setUp();

    $this->installSchema('webform', ['webform']);
    $this->installConfig(['webform']);
    $this->installEntitySchema('webform_submission');
  }

  /**
   * Installs the group_webform relation on a group type.
   *
   * Saving the relationship type triggers the post-install handler which
   * installs the code-only group_webform_submission companion automatically.
   *
   * @param \Drupal\group\Entity\GroupTypeInterface $group_type
   *   The group type to enable the relation on.
   */
  protected function installWebformRelation(GroupTypeInterface $group_type): void {
    $storage = $this->entityTypeManager->getStorage('group_relationship_type');
    assert($storage instanceof GroupRelationshipTypeStorageInterface);
    $storage->createFromPlugin($group_type, 'group_webform')->save();
  }

  /**
   * Creates and saves a simple test webform.
   *
   * @param string $id
   *   The webform machine name.
   *
   * @return \Drupal\webform\WebformInterface
   *   The saved webform.
   */
  protected function createWebform(string $id = 'test_form'): WebformInterface {
    $webform = Webform::create([
      'id' => $id,
      'title' => $id,
      'elements' => [
        'name' => [
          '#type' => 'textfield',
          '#title' => 'Name',
        ],
      ],
    ]);
    $webform->save();
    return $webform;
  }

}
