<?php

declare(strict_types=1);

namespace Drupal\Tests\localgov_forms_group\Functional;

use Drupal\Core\Url;
use Drupal\group\PermissionScopeInterface;
use Drupal\user\RoleInterface;
use Drupal\webform\Entity\WebformSubmission;

/**
 * Tests group-based access control for submissions for authenticated users.
 *
 * @group localgov_forms_group
 */
class SubmissionGroupAccessTest extends LocalGovFormsGroupFunctionalTestBase {

  /**
   * A non-member is denied, a member with permission is granted, access.
   */
  public function testMemberAndNonMemberAccess(): void {
    // Create a grouped submission for the fixture webform.
    $submission = WebformSubmission::create([
      'webform_id' => self::WEBFORM_ID,
      'data' => ['name' => 'Jo', 'email' => 'jo@example.com'],
    ]);
    $submission->save();

    $submission_url = Url::fromRoute('entity.webform.user.submission', [
      'webform' => self::WEBFORM_ID,
      'webform_submission' => $submission->id(),
    ]);

    // An authenticated non-member is denied access to the grouped submission.
    $non_member = $this->drupalCreateUser();
    $this->drupalLogin($non_member);
    $this->drupalGet($submission_url);
    $this->assertSession()->statusCodeEquals(403);
    $this->drupalLogout();

    // Grant insiders the group "view any webform submission entity" permission.
    $view_permission = $this->container->get('group_relation_type.manager')
      ->getPermissionProvider('group_webform_submission')
      ->getPermission('view', 'entity', 'any');
    $this->createGroupRole([
      'group_type' => $this->groupType->id(),
      'scope' => PermissionScopeInterface::INSIDER_ID,
      'global_role' => RoleInterface::AUTHENTICATED_ID,
      'permissions' => [$view_permission],
    ]);

    // A member with that permission can view the grouped submission.
    $member = $this->drupalCreateUser();
    $this->group->addMember($member);
    $this->drupalLogin($member);
    $this->drupalGet($submission_url);
    $this->assertSession()->statusCodeEquals(200);
  }

}
