<?php

declare(strict_types=1);

namespace Drupal\Tests\localgov_forms_group\Kernel;

use Drupal\group\PermissionScopeInterface;
use Drupal\user\RoleInterface;
use Drupal\webform\Entity\WebformSubmission;
use Drupal\webform\WebformSubmissionInterface;

/**
 * Tests group-based access control for webform submissions.
 *
 * The group_webform_submission relation declares entity_access = TRUE, so
 * Group's access integration governs view/update/delete on grouped
 * submissions. For authenticated users the anonymous session bypass does not
 * apply, so these checks isolate the group access behaviour.
 *
 * @group localgov_forms_group
 */
class SubmissionAccessTest extends LocalGovFormsGroupKernelTestBase {

  /**
   * The webform_submission access control handler.
   *
   * @var \Drupal\Core\Entity\EntityAccessControlHandlerInterface
   */
  protected $accessControlHandler;

  /**
   * {@inheritdoc}
   */
  protected function setUp(): void {
    parent::setUp();

    // Needed so group roles can target the authenticated global role.
    $this->createRole([], RoleInterface::AUTHENTICATED_ID);

    $this->accessControlHandler = $this->entityTypeManager->getAccessControlHandler('webform_submission');
  }

  /**
   * A non-member is denied access to a grouped submission.
   */
  public function testNonMemberDenied(): void {
    $submission = $this->createGroupedSubmission($group);

    $non_member = $this->createUser();

    foreach (['view', 'update', 'delete'] as $operation) {
      $this->assertFalse(
        $this->accessControlHandler->access($submission, $operation, $non_member),
        "A non-member is denied $operation on a grouped submission.",
      );
    }
  }

  /**
   * A member with the group view permission can view a grouped submission.
   */
  public function testMemberWithPermissionAllowed(): void {
    $group_type_id = NULL;
    $submission = $this->createGroupedSubmission($group, $group_type_id);

    // Grant insiders the "view any webform submission entity" group permission.
    $view_permission = $this->container->get('group_relation_type.manager')
      ->getPermissionProvider('group_webform_submission')
      ->getPermission('view', 'entity', 'any');
    $this->assertNotFalse($view_permission, 'The view-any entity permission exists.');

    $this->createGroupRole([
      'group_type' => $group_type_id,
      'scope' => PermissionScopeInterface::INSIDER_ID,
      'global_role' => RoleInterface::AUTHENTICATED_ID,
      'permissions' => [$view_permission],
    ]);

    $member = $this->createUser();
    $group->addMember($member);

    $this->accessControlHandler->resetCache();
    $this->assertTrue(
      $this->accessControlHandler->access($submission, 'view', $member),
      'A group member with the view permission can view the grouped submission.',
    );

    // A member without that permission elsewhere (non-member) is still denied.
    $this->assertFalse(
      $this->accessControlHandler->access($submission, 'view', $this->createUser()),
      'A non-member is still denied even when insiders are granted access.',
    );
  }

  /**
   * Creates a grouped webform submission.
   *
   * @param \Drupal\group\Entity\GroupInterface|null $group
   *   Set by reference to the group the submission belongs to.
   * @param string|null $group_type_id
   *   Set by reference to the group type id used.
   *
   * @return \Drupal\webform\WebformSubmissionInterface
   *   The saved, grouped submission.
   */
  protected function createGroupedSubmission(&$group = NULL, &$group_type_id = NULL): WebformSubmissionInterface {
    $group_type = $this->createGroupType(['creator_membership' => FALSE]);
    $group_type_id = $group_type->id();
    $this->installWebformRelation($group_type);

    $webform = $this->createWebform();
    $group = $this->createGroup(['type' => $group_type->id()]);
    $group->addRelationship($webform, 'group_webform');

    $submission = WebformSubmission::create([
      'webform_id' => $webform->id(),
      'data' => ['name' => 'Jo'],
    ]);
    $submission->save();

    return $submission;
  }

}
