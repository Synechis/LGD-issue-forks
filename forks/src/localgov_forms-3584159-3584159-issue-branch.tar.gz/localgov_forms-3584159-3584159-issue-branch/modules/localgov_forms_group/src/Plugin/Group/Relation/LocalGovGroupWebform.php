<?php

namespace Drupal\localgov_forms_group\Plugin\Group\Relation;

use Drupal\group\Plugin\Group\Relation\GroupRelationBase;
use Drupal\Core\Form\FormStateInterface;

/**
 * Provides a group relation type for webforms.
 *
 * When a webform is added to a group, all submissions to that webform
 * will automatically be associated with the same group(s). This enables
 * group-based access control and organization of webform data.
 *
 * @GroupRelationType(
 *   id = "group_webform",
 *   label = @Translation("Group Webform (manages submission access)"),
 *   description = @Translation("Relates a webform to this group. All of its submissions are automatically added to the group and restricted to group members."),
 *   reference_label = @Translation("Webform"),
 *   reference_description = @Translation("The webform to relate to this group. Its submissions are added automatically and access-controlled by group membership."),
 *   entity_type_id = "webform",
 *   entity_access = FALSE,
 * )
 */
class LocalGovGroupWebform extends GroupRelationBase {

  /**
   * {@inheritdoc}
   */
  public function getEntityBundleIds() {
    return ['webform']; // Supports all Webforms.
  }
  /**
   * {@inheritdoc}
   */
  public function defaultConfiguration() {
    $config = parent::defaultConfiguration();
    $config['group_cardinality'] = 0;
    $config['entity_cardinality'] = 1;
    return $config;
  }

  /**
   * {@inheritdoc}
   */
  public function buildConfigurationForm(array $form, FormStateInterface $form_state) {
    $form = parent::buildConfigurationForm($form, $form_state);

    // Disable cardinality fields as the functionality of this module depends on
    // set values.
    $info = $this->t("This field has been disabled to ensure automatic submission assignment works correctly.");
    $form['entity_cardinality']['#disabled'] = TRUE;
    $form['entity_cardinality']['#description'] .= '<br /><em>' . $info . '</em>';
    $form['group_cardinality']['#disabled'] = TRUE;
    $form['group_cardinality']['#description'] .= '<br /><em>' . $info . '</em>';

    return $form;
  }
}
