<?php

namespace Drupal\localgov_forms_group\Plugin\Group\Relation;
use Drupal\group\Plugin\Group\Relation\GroupRelationBase;
use Drupal\Core\Form\FormStateInterface;

/**
 * Provides a group relation type for webform submissions.
 *
 * @GroupRelationType(
 *   id = "group_webform_submission",
 *   label = @Translation("Group Webform Submission"),
 *   description = @Translation("Associates Webforms submissions with Groups."),
 *   entity_type_id = "webform_submission",
 *   entity_access = TRUE,
 *   code_only = TRUE,
 * )
 */
class LocalGovGroupWebformSubmission extends GroupRelationBase {

  /**
   * {@inheritdoc}
   */
  public function defaultConfiguration() {
    $config = parent::defaultConfiguration();
    $config['group_cardinality'] = 0;
    $config['entity_cardinality'] = 1;
    $config['use_creation_wizard'] = 0;
    return $config;
  }

  /**
   * {@inheritdoc}
   */
  public function buildConfigurationForm(array $form, FormStateInterface $form_state) {
    $form = parent::buildConfigurationForm($form, $form_state);

    // Disable cardinality fields as the functionality of this module depends on
    // set values. Disable the user creation wizard as relationships are created
    // automatically.
    $info = $this->t("This field has been disabled by the plugin to guarantee the functionality that's expected of it.");
    $form['entity_cardinality']['#disabled'] = TRUE;
    $form['entity_cardinality']['#description'] .= '<br /><em>' . $info . '</em>';
    $form['group_cardinality']['#disabled'] = TRUE;
    $form['group_cardinality']['#description'] .= '<br /><em>' . $info . '</em>';
    $form['use_creation_wizard']['#disabled'] = TRUE;
    $form['use_creation_wizard']['#description'] .= '<br /><em>' . $info . '</em>';

    return $form;
  }
}
