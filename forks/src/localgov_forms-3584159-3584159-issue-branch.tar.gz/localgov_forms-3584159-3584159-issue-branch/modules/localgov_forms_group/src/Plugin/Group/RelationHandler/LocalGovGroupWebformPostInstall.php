<?php

namespace Drupal\localgov_forms_group\Plugin\Group\RelationHandler;

use Drupal\Core\Entity\EntityTypeManagerInterface;
use Drupal\group\Entity\GroupRelationshipTypeInterface;
use Drupal\group\Entity\Storage\GroupRelationshipTypeStorageInterface;
use Drupal\group\Plugin\Group\RelationHandler\PostInstallInterface;
use Drupal\group\Plugin\Group\RelationHandler\PostInstallTrait;

/**
 * Post install handler for the group_webform relation plugin.
 *
 * When a site builder installs "Group Webform" on a group type, this handler
 * automatically installs the companion "group_webform_submission" relation on
 * the same group type. The submission relation is marked code_only, so it has
 * no UI install action of its own, it is always installed and uninstalled
 * alongside the webform relation. This keeps setup to a single action.
 *
 * @see localgov_forms_group_group_relationship_type_delete()
 */
class LocalGovGroupWebformPostInstall implements PostInstallInterface {

  use PostInstallTrait;

  /**
   * The plugin ID of the companion submission relation.
   */
  const COMPANION_PLUGIN_ID = 'group_webform_submission';

  /**
   * The entity type manager.
   *
   * @var \Drupal\Core\Entity\EntityTypeManagerInterface
   */
  protected $entityTypeManager;

  /**
   * Constructs a new LocalGovGroupWebformPostInstall.
   *
   * @param \Drupal\group\Plugin\Group\RelationHandler\PostInstallInterface $parent
   *   The default post install handler.
   * @param \Drupal\Core\Entity\EntityTypeManagerInterface $entity_type_manager
   *   The entity type manager.
   */
  public function __construct(PostInstallInterface $parent, EntityTypeManagerInterface $entity_type_manager) {
    $this->parent = $parent;
    $this->entityTypeManager = $entity_type_manager;
  }

  /**
   * {@inheritdoc}
   */
  public function getInstallTasks() {
    $tasks = $this->parent->getInstallTasks();
    $tasks['install-webform-submission-relation'] = [$this, 'installSubmissionRelation'];
    return $tasks;
  }

  /**
   * Installs the companion group_webform_submission relation.
   *
   * @param \Drupal\group\Entity\GroupRelationshipTypeInterface $relationship_type
   *   The group_webform relationship type that was just installed.
   * @param bool $is_syncing
   *   Whether config is currently being imported.
   */
  public function installSubmissionRelation(GroupRelationshipTypeInterface $relationship_type, $is_syncing) {
    // During a config import the companion relationship type is part of the
    // imported configuration, so we must not create it ourselves.
    if ($is_syncing === TRUE) {
      return;
    }

    $storage = $this->entityTypeManager->getStorage('group_relationship_type');
    assert($storage instanceof GroupRelationshipTypeStorageInterface);

    $group_type = $relationship_type->getGroupType();

    // Bail if the companion is already installed on this group type.
    $companion_id = $storage->getRelationshipTypeId($group_type->id(), self::COMPANION_PLUGIN_ID);
    if ($storage->load($companion_id)) {
      return;
    }

    $storage->createFromPlugin($group_type, self::COMPANION_PLUGIN_ID)->save();
  }

}
