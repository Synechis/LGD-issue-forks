<?php

namespace Drupal\localgov_forms_group\Plugin\Group\RelationHandler;

use Drupal\group\Plugin\Group\RelationHandler\PermissionProviderInterface;
use Drupal\group\Plugin\Group\RelationHandler\PermissionProviderTrait;

/**
 * Permission provider for the group_webform_submission relation plugin.
 *
 * Removes the "create" permissions (both relating an existing submission and
 * creating one in the group) so the plugin never appears on a group's "Add
 * relationship" or "Create entity" pages. Submissions are added to their
 * group(s) automatically by localgov_forms_group_entity_insert(), so manual
 * creation through the UI is never appropriate.
 *
 * All other permissions (view/update/delete) are left untouched so that
 * group-based access control over submissions keeps working. Removing the
 * create permission does not affect the automatic assignment, because
 * GroupInterface::addRelationship() does not perform a permission check.
 */
class LocalGovGroupWebformSubmissionPermissionProvider implements PermissionProviderInterface {

  use PermissionProviderTrait;

  /**
   * Constructs a new LocalGovGroupWebformSubmissionPermissionProvider.
   *
   * @param \Drupal\group\Plugin\Group\RelationHandler\PermissionProviderInterface $parent
   *   The default permission provider.
   */
  public function __construct(PermissionProviderInterface $parent) {
    $this->parent = $parent;
  }

  /**
   * {@inheritdoc}
   */
  public function getPermission($operation, $target, $scope = 'any') {
    // Hide the manual "relate" and "create in group" actions; relationships
    // are created programmatically on submission.
    if ($operation === 'create' && in_array($target, ['relationship', 'entity'], TRUE)) {
      return FALSE;
    }
    return $this->parent->getPermission($operation, $target, $scope);
  }

}
