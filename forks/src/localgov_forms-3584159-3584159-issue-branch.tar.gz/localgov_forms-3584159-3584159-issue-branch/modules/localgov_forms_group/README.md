## INTRODUCTION

The LocalGov Forms Group module defines group relationship plugins for Webform and Webform submissions.

The primary use case for this module is:

- Control access to view and update webform submission to specific groups of site users
- Enable anonymous users to create and submit webforms in a single session without access checks

## REQUIREMENTS

The module depends on

- group
- webform

## INSTALLATION

Install as you would normally install a contributed Drupal module.
See: <https://www.drupal.org/node/895232> for further information.

## CONFIGURATION

- Install and enable the module
- Install 'Group Webform (manages submission access)' on the group types you want to relate Webforms to (/admin/group/types/manage/{group_type}/content). The companion 'Group Webform Submission' relation is installed automatically alongside it - it is code-only and does not need (or offer) a separate install step.
- Add a Webform to the required group (/group/{gid}/content). Submissions to that webform are then assigned to the same group(s) automatically.

### Access control and permissions

This module enforces per-entity access control for Webform submissions via Group integration. Submissions are restricted to their group by default—users outside a submission's group (or lacking group permissions) are denied access to individual routes (`webform_submission.view`, `update`, `delete`).

#### Critical Limitations

- Bulk Results UI is not group-aware, the `/admin/structure/webform/manage/{webform}/results/submissions` page bypasses group checks. Users with access to this page can view ALL submissions for that webform, regardless of group membership.

#### Dangerous Permissions to Restrict

Granting these global permissions bypasses group restrictions entirely. Restrict them to trusted site administrators only:

- `administer webform` - Full control over all webforms/submissions.
- `administer webform submission` - Edit/delete all submissions.
- `view any webform submission` - View all submissions.
- `edit any webform submission` / `delete any webform submission` - Modify/delete all submissions.

Webform’s "Access" tab (per-webform settings) can also grant equivalent "view/update/delete any" access, bypassing group checks.

#### Key Admin Principles

1. Do not grant global webform permissions to group members, use group permissions instead:
   - Grant access via the group’s "View any Webform submission entity" permission (scoped to "Member (insider)").
   - Users should access submissions through group-aware routes (e.g., individual submission links or Views filtered by `group_relationship`).

2. Group permissions take precedence for individual submission routes. Global "view any" grants only bypass group checks on the bulk results UI.

## MAINTAINERS

Current maintainers for Drupal 10:

- Simon Chapman - <https://www.drupal.org/u/skgchp>
