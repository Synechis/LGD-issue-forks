<?php

namespace Drupal\localgov_elections\Hook;

use Drupal\Core\Template\Attribute;
use Drupal\paragraphs\ParagraphInterface;
use Drupal\views\ViewExecutable;
use Drupal\Core\Form\FormStateInterface;
use Drupal\node\Entity\Node;
use Drupal\Core\Url;
use Drupal\Core\Entity\EntityStorageException;
use Drupal\node\NodeInterface;
use Drupal\Component\Utility\DeprecationHelper;
use Drupal\Core\Entity\EntityInterface;
use Drupal\Core\Hook\Attribute\Hook;
use Drupal\Core\StringTranslation\StringTranslationTrait;

/**
 * Hook implementations for localgov_elections.
 */
class LocalgovElectionsHooks {
  use StringTranslationTrait;

  /**
   * Implements hook_theme().
   */
  #[Hook('theme')]
  public function theme($existing, $type, $theme, $path): mixed {
    return [
      'area_result' => [
        'variables' => [
          'chart' => NULL,
          'result' => NULL,
          'analysis' => NULL,
        ],
      ],
      'election_menu' => [
        'variables' => [
          'links' => NULL,
        ],
      ],
      'localgov_elections_results_heading' => [
        'variables' => [
          'election_type' => '',
        ],
      ],
      'views_view_table__localgov_election_results__summary_table' => [
        'base hook' => 'views_view_table',
      ],
      'views_view_table__localgov_election_area_results__block_area_results_table' => [
        'base hook' => 'views_view_table',
      ],
      'views_view__localgov_election_results_vote__page_vote_share' => [
        'base hook' => 'views_view',
      ],
      'election_results_chart' => [
        'variables' => [
          'parties' => [],
          'max_seats' => 0,
        ],
      ],
      'election_vote_share_chart' => [
        'variables' => [
          'parties' => [],
          'total_votes' => '0',
          'max_share' => 1.0,
        ],
      ],
      'area_vote_chart' => [
        'variables' => [
          'candidates' => [],
        ],
      ],
      'election_timeline_table_row' => [
        'variables' => [
          'time' => NULL,
          'area' => NULL,
          'area_url' => NULL,
          'seats' => 0,
          'candidates' => [],
        ],
        'template' => 'election-timeline-area',
      ],
      'views_view_unformatted__localgov_election_results_timeline' => [
        'variables' => [
          'rows' => [],
          'title' => NULL,
        ],
        'template' => 'election-timeline',
      ],
      'analysis_block' => [
        'variables' => [
          'data' => [],
        ],
      ],
      'views_view__localgov_election_notices__page_notices' => [
        'base hook' => 'views_view',
      ],
      'views_view__localgov_election_notices__page_notice_detail' => [
        'base hook' => 'views_view',
      ],
    ];
  }

  /**
   * Implements hook_modules_installed().
   */
  #[Hook('modules_installed')]
  public function modulesInstalled($modules, $is_syncing): void {
    if ($is_syncing) {
      return;
    }
    $services = in_array('localgov_services_navigation', $modules, TRUE);
    if ($services) {
      \Drupal::service('config.installer')->installOptionalConfig(NULL, [
        'config' => 'field.storage.node.localgov_services_parent',
      ]);
      _localgov_elections_optional_fields_settings($services);
    }
  }

  /**
   * Implements hook_entity_presave().
   */
  #[Hook('entity_presave')]
  public function entityPresave(EntityInterface $entity): void {
    if ($entity->getEntityTypeId() === 'node' && $entity->getType() === 'localgov_area_vote') {
      $finalised = (int) $entity->get('localgov_election_votes_final')->value;
      $uncontested_area = (int) $entity->get('localgov_election_no_contest')->value;
      if ($finalised === 1 || $uncontested_area === 1) {
        /** @var \Drupal\localgov_elections\Service\WinnerCalculator $calculator */
        $calculator = \Drupal::service('localgov_elections.winner_calculator');
        $winners = $calculator->calculateWinners($entity);
        $entity->set('localgov_election_winner', $winners);
      }
      elseif ($original = DeprecationHelper::backwardsCompatibleCall(\Drupal::VERSION, '11.2.0', fn() => $entity->getOriginal(), fn() => $entity->original)) {
        if ($original->get('localgov_election_votes_final')->value == 1) {
          $entity->set('localgov_election_winner', []);
        }
      }
      // Remove completely empty candidates from seats.
      if ($entity->hasField('localgov_election_seats')) {
        foreach ($entity->get('localgov_election_seats') as $seat_item) {
          $seat = $seat_item->entity;
          if ($seat && $seat->bundle() === 'localgov_area_seat') {
            $candidates = $seat->get('localgov_candidate_uncontested');
            $to_delete = [];
            foreach ($candidates as $delta => $candidate_item) {
              $candidate = $candidate_item->entity;
              if ($candidate) {
                // Check all candidate fields for content.
                $has_any_data = FALSE;
                $excluded_fields = [
                  'id',
                  'uuid',
                  'type',
                  'langcode',
                  'status',
                  'created',
                  'changed',
                  'parent_id',
                  'parent_type',
                  'parent_field_name',
                ];
                foreach ($candidate->getFields() as $field) {
                  if (!$field->isEmpty() && !in_array($field->getName(), $excluded_fields, TRUE)) {
                    $has_any_data = TRUE;
                    break;
                  }
                }
                // If completely empty, delete it.
                if (!$has_any_data) {
                  $to_delete[] = $delta;
                }
              }
            }
            // Remove and delete.
            foreach (array_reverse($to_delete) as $delta) {
              $candidate = $candidates[$delta]->entity;
              $candidates->removeItem($delta);
              $candidate->delete();
            }
          }
        }
      }
    }
    // Prevent creating multiple revisions for candidate paragraphs.
    if ($entity->getEntityTypeId() === 'paragraph' && $entity->getType() === 'localgov_election_candidate') {
      $entity->setNewRevision(FALSE);
    }
  }

  /**
   * Implements hook_ENTITY_TYPE_presave().
   *
   * Create default seats when area vote is created.
   */
  #[Hook('node_presave')]
  public function nodePresave(NodeInterface $node): void {
    if ($node->bundle() !== 'localgov_area_vote') {
      return;
    }
    // Ensure the reference to parent election exists.
    if ($node->hasField('localgov_election') && !$node->get('localgov_election')->isEmpty()) {
      $parent = $node->get('localgov_election')->entity;
      if ($parent instanceof NodeInterface && $parent->hasField('localgov_election_seat_count')) {
        $seat_count = (int) $parent->get('localgov_election_seat_count')->value;
        // Only proceed if no seats already exist.
        if (!$node->get('localgov_election_seats')->isEmpty()) {
          return;
        }
        // Base name for seats.
        $area_name = $node->get('localgov_election_area_name')->value ?? 'Seat';
        // If the area is marked as uncontested, set all seats to uncontested.
        $area_uncontested = $node->get('localgov_election_no_contest')->value ?? 0;
        $paragraph_storage = \Drupal::entityTypeManager()->getStorage('paragraph');
        $seat_paragraphs = [];
        // Always create at least 1 seat, more if parent requires it.
        for ($i = 1; $i <= $seat_count; $i++) {
          $seat_label = $seat_count > 1 ? $area_name . ' ' . $i : $area_name;
          $seat_paragraph = $paragraph_storage->create([
            'type' => 'localgov_area_seat',
            'localgov_seat' => $seat_label,
            'localgov_seat_not_contested' => $area_uncontested,
          ]);
          $seat_paragraph->save();
          $seat_paragraphs[] = $seat_paragraph;
        }
        // Attach them to the node's reference field.
        foreach ($seat_paragraphs as $seat_paragraph) {
          $node->get('localgov_election_seats')->appendItem($seat_paragraph);
        }
      }
    }
  }

  /**
   * Implements hook_entity_predelete().
   */
  #[Hook('entity_predelete')]
  public function entityPredelete(EntityInterface $entity): void {
    // Triggered just before an Election node is deleted.
    if ($entity->getEntityTypeId() == 'node' && $entity->getType() == 'localgov_election') {
      $election_id = $entity->id();
      $election_title = $entity->getTitle();
      $deleted = 0;
      // Delete all Division Vote entities referencing this election.
      $areas_query = \Drupal::entityTypeManager()->getStorage('node')->getQuery();
      $areas_query->condition('type', 'localgov_area_vote');
      $areas_query->condition('status', 1);
      $areas_query->condition('localgov_election', $election_id);
      $areas_query->accessCheck(FALSE);
      $areas = $areas_query->execute();
      if ($areas) {
        $areas = \Drupal::entityTypeManager()->getStorage('node')->loadMultiple($areas);
        foreach ($areas as $area) {
          try {
            $area->delete();
            $deleted++;
          }
          catch (EntityStorageException $exception) {
            \Drupal::logger('localgov_election')->error("Could not delete area with id " . $area->id());
          }
        }
      }
      \Drupal::logger('localgov_election')->notice("Election " . $election_title . " (ID " . $election_id . ") was deleted. " . $deleted . " Division Votes deleted");
      \Drupal::messenger()->addStatus($deleted . ' Division Votes deleted from system');
    }
  }

  /**
   * Implements hook_ENTITY_TYPE_insert().
   */
  #[Hook('path_alias_insert')]
  public function pathAliasInsert(EntityInterface $entity): void {
    $path = $entity->getPath();
    $url = Url::fromUserInput($path);
    $params = $url->getRouteParameters();
    if (is_array($params) && array_key_exists('node', $params)) {
      if ($node = Node::load($params['node'])) {
        if ($node->bundle() === "localgov_election") {
          $canonical_route = '/' . $node->toUrl()->getInternalPath();
          if ($path === $canonical_route) {
            /** @var \Drupal\localgov_elections\Service\ElectionAliasManager $alias_manager */
            $alias_manager = \Drupal::service('localgov_elections.alias_manager');
            $alias_manager->generateElectionAliases($node);
          }
        }
      }
    }
  }

  /**
   * Implements hook_ENTITY_TYPE_update().
   */
  #[Hook('path_alias_update')]
  public function pathAliasUpdate(EntityInterface $entity): void {
    /** @var \Drupal\path_alias\Entity\PathAlias $original_entity */
    $original_entity = DeprecationHelper::backwardsCompatibleCall(\Drupal::VERSION, '11.2.0', fn() => $entity->getOriginal(), fn() => $entity->original);
    if ($entity->getAlias() !== $original_entity->getAlias()) {
      $path = $entity->getPath();
      $url = Url::fromUserInput($path);
      $params = $url->getRouteParameters();
      if (is_array($params) && array_key_exists('node', $params)) {
        if ($node = Node::load($params['node'])) {
          if ($node->bundle() === "localgov_election") {
            $canonical_route = '/' . $node->toUrl()->getInternalPath();
            if ($path === $canonical_route) {
              /** @var \Drupal\localgov_elections\Service\ElectionAliasManager $alias_manager */
              $alias_manager = \Drupal::service('localgov_elections.alias_manager');
              $alias_manager->deleteElectionAliases($node);
              $alias_manager->generateElectionAliases($node);
            }
          }
        }
      }
    }
  }

  /**
   * Implements hook_form_BASE_FORM_ID_alter() for add form.
   */
  #[Hook('form_node_localgov_area_vote_form_alter')]
  public function formNodeLocalgovAreaVoteFormAlter(&$form, FormStateInterface $form_state, $form_id): void {
    /** @var \Drupal\localgov_elections\Form\AreaVoteFormHelper $form_helper */
    $form_helper = \Drupal::service('localgov_elections.area_vote_form_helper');
    $form_helper->configureForm($form, $form_state);
  }

  /**
   * Implements hook_form_BASE_FORM_ID_alter() for edit form.
   */
  #[Hook('form_node_localgov_area_vote_edit_form_alter')]
  public function formNodeLocalgovAreaVoteEditFormAlter(&$form, FormStateInterface $form_state, $form_id): void {
    /** @var \Drupal\localgov_elections\Form\AreaVoteFormHelper $form_helper */
    $form_helper = \Drupal::service('localgov_elections.area_vote_form_helper');
    $form_helper->configureForm($form, $form_state);
  }

  /**
   * Implements hook_form_BASE_FORM_ID_alter().
   */
  #[Hook('form_taxonomy_term_localgov_party_form_alter')]
  public function formTaxonomyTermLocalgovPartyFormAlter(&$form, FormStateInterface $form_state, $form_id): void {
    if (isset($form["name"]["widget"][0]['value'])) {
      $form["name"]["widget"][0]['value']["#description"] = $this->t("The party name. Do not enter brackets in the party name.");
    }
  }

  /**
   * Implements hook_views_data_alter().
   */
  #[Hook('views_data_alter')]
  public function viewsDataAlter(array &$data): void {
    $data['node']['ward_majority'] = [
      'title' => $this->t('Area majority'),
      'field' => [
        'title' => $this->t('Area majority'),
        'help' => $this->t('Calculates the difference between number of votes of first and second results in an electoral area.'),
        'id' => 'ward_majority',
      ],
    ];
    $data['node']['area_party'] = [
      'title' => $this->t('Area winning party'),
      'field' => [
        'title' => $this->t('Area winning party'),
        'help' => $this->t('Winning party in an electoral area for an election.'),
        'id' => 'area_party',
      ],
    ];
    $data['node']['election_turnout'] = [
      'title' => $this->t('Election turnout'),
      'field' => [
        'title' => $this->t('Election turnout'),
        'help' => $this->t('Sums all votes cast with all candidates in election plus all spoiled votes.'),
        'id' => 'election_turnout',
      ],
    ];
    $data['node']['election_timeline'] = [
      'title' => $this->t('Election timeline'),
      'field' => [
        'title' => $this->t('Election timeline'),
        'help' => $this->t('Gathers timeline data for an area.'),
        'id' => 'election_timeline',
      ],
    ];
    $data['node']['election_majority'] = [
      'title' => $this->t('Election majority'),
      'field' => [
        'title' => $this->t('Election majority'),
        'help' => $this->t('Counts number of seats in election, divides by 2 and adds 1 to calculate majority.'),
        'id' => 'election_majority',
      ],
    ];
    $data['node']['area_seats_count'] = [
      'title' => $this->t('Area seats count'),
      'field' => [
        'title' => $this->t('Area seats count'),
        'help' => $this->t('Counts the number of seats in an electoral area.'),
        'id' => 'area_seats_count',
      ],
    ];
    $data['paragraph']['winner_tie_indicator'] = [
      'title' => $this->t('Winner tie indicator'),
      'group' => $this->t('Paragraph'),
      'field' => [
        'title' => $this->t('Winner tie indicator'),
        'help' => $this->t('Displays " (tie winner)" if the winner won on a tie.'),
        'id' => 'winner_tie_indicator',
      ],
    ];
    $data['taxonomy_term_data']['election_share'] = [
      'title' => $this->t('Percentage of election share'),
      'field' => [
        'title' => $this->t('Percentage of election share'),
        'help' => $this->t('List percentage of election share for each party in a specific election.'),
        'id' => 'election_share',
      ],
    ];
    $data['taxonomy_term_data']['election_seats_party'] = [
      'title' => $this->t('Election seat wins'),
      'field' => [
        'title' => $this->t('Election seat wins'),
        'help' => $this->t('Sums all seats won by party in this election.'),
        'id' => 'election_seats_party',
      ],
      'sort' => [
        'id' => 'standard',
      ],
      'filter' => [
        'id' => 'standard',
      ],
    ];
    $data['views']['area_election_results_heading'] = [
      'title' => $this->t('Election results heading'),
      'help' => $this->t('Sets dynamic heading depending on election type.'),
      'area' => [
        'id' => 'localgov_elections_results_heading',
      ],
    ];
  }

  /**
   * Implements hook_views_pre_render().
   */
  #[Hook('views_pre_render')]
  public function viewsPreRender(ViewExecutable $view): void {
    $view_storage = $view->storage;
    $dependencies = $view_storage ? $view_storage->get('dependencies') : [];
    $enforced_modules = $dependencies['enforced']['module'] ?? [];
    if (in_array('localgov_elections', $enforced_modules, TRUE)) {
      $view->element['#attached']['library'][] = 'localgov_elections/election';
    }
    if ($view->id() === 'localgov_electoral_candidates') {
      $view->element['#attached']['library'][] = 'localgov_elections/electoral_candidates_view';
    }
    if ($view->id() === 'localgov_election_notices') {
      $view->element['#attached']['library'][] = 'localgov_elections/election_notices';
    }
    if ($view->id() === 'localgov_election_results_timeline') {
      $view->element['#attached']['library'][] = 'localgov_elections/results_timeline';
      $view->element['#attached']['html_head'][] = [
        _localgov_elections_party_colours_style(),
        'localgov_elections_party_colours',
      ];
    }
    if ($view->id() === 'localgov_election_results') {
      if ($view->getDisplay()->display['id'] === 'summary_table') {
        $view->element['#attached']['html_head'][] = [
          _localgov_elections_party_colours_style(),
          'localgov_elections_party_colours',
        ];
      }
    }
    if ($view->id() === 'localgov_election_results_vote') {
      $view->element['#attached']['html_head'][] = [
        _localgov_elections_party_colours_style(),
        'localgov_elections_party_colours',
      ];
    }
    if ($view->id() === 'localgov_election_area_results') {
      $view->element['#attached']['html_head'][] = [
        _localgov_elections_party_colours_style(),
        'localgov_elections_party_colours',
      ];
    }
    // Apply candidate name fallbacks for views that display candidate names.
    if (in_array($view->id(), [
      'localgov_election_area_results',
      'localgov_election_results',
    ])) {
      foreach ($view->result as $row) {
        foreach ([
          'localgov_election_candidates',
          'localgov_election_winner',
        ] as $relationship) {
          $candidate = $row->_relationship_entities[$relationship] ?? NULL;
          if (!$candidate instanceof ParagraphInterface) {
            continue;
          }
          $forename = _localgov_elections_candidate_forename($candidate);
          if ($forename) {
            $candidate->set('localgov_election_forename', $forename);
          }
          $surname = _localgov_elections_candidate_surname($candidate);
          if ($surname) {
            $candidate->set('localgov_election_candidate', $surname);
          }
        }
      }
    }
  }

  /**
   * Implements hook_preprocess_HOOK() for the election results timeline view.
   *
   * Groups rows by date for the template.
   */
  #[Hook('preprocess_views_view_unformatted__localgov_election_results_timeline')]
  public function preprocessViewsViewUnformattedLocalgovElectionResultsTimeline(array &$variables): void {
    $groups = [];
    $date_formatter = \Drupal::service('date.formatter');
    foreach ($variables['rows'] as $row) {
      $node = $row['#row']->_entity ?? NULL;
      $date_formatted = '';
      $time_formatted = '';
      $datetime_attr = '';
      $area = '';
      $area_url = '';
      $seats = 0;
      $elected = 0;
      if ($node instanceof NodeInterface) {
        $finalised_date = $node->get('localgov_election_finalised_date')->value;
        if ($finalised_date) {
          $finalised_date_w_tz = "{$finalised_date}Z";
          $ts = strtotime($finalised_date_w_tz);
          $date_formatted = $ts ? $date_formatter->format($ts, 'custom', 'l j F Y') : '';
          // Example time formats: 5pm, 5:01pm, 11:09am, etc.
          $is_on_the_hour = $ts ? $date_formatter->format($ts, 'custom', 'i') === '00' : FALSE;
          $time_format = $is_on_the_hour ? 'ga' : 'g:ia';
          $time_formatted = $ts ? $date_formatter->format($ts, 'custom', $time_format) : '';
          $datetime_attr = $ts ? $date_formatter->format($ts, 'custom', 'Y-m-d\TH:i') : '';
        }
        $area = $node->get('localgov_election_area_name')->value ?? '';
        $area_url = $node->toUrl()->toString();
        $seat_entities = $node->get('localgov_election_seats')->referencedEntities();
        $seats = count($seat_entities);
        foreach ($seat_entities as $seat) {
          if (!$seat->get('localgov_seat_not_contested')->value) {
            $elected++;
          }
        }
      }
      if (!isset($groups[$date_formatted])) {
        $groups[$date_formatted] = [
          'date' => $date_formatted,
          'rows' => [],
        ];
      }
      $groups[$date_formatted]['rows'][] = [
        'time' => $time_formatted,
        'datetime' => $datetime_attr,
        'area' => $area,
        'area_url' => $area_url,
        'seats' => $seats,
        'elected' => $elected,
        'content' => $row,
      ];
    }
    $variables['groups'] = array_values($groups);
  }

  /**
   * Implements hook_preprocess_HOOK().
   *
   * Specialized displays for the default view mode for Election nodes and
   * Election area nodes.
   *
   * @todo Replace with Extra fields which are configurable per view mode.
   */
  #[Hook('preprocess_node__full')]
  public function preprocessNodeFull(&$variables): void {
    $node = $variables['elements']['#node'];
    if ($node->bundle() == 'localgov_area_vote') {
      $finalised = $node->get('localgov_election_votes_final')->value;
      $not_contested = $node->get('localgov_election_no_contest')->value;
      if ($finalised == 1) {
        if ($not_contested) {
          $variables['content']['results'] = [
            '#children' => $this->t('This seat was not contested.'),
          ];
        }
        else {
          $block_manager = \Drupal::service('plugin.manager.block');
          $plugin_block = $block_manager->createInstance('analysis_block', []);
          $analysis = $plugin_block->build();
          // Add the cache tags/contexts.
          \Drupal::service('renderer')->addCacheableDependency($analysis, $plugin_block);
          $chart_data = _localgov_elections_area_vote_chart_data($node);
          $variables['content']['results'] = [
            '#theme' => 'area_result',
            '#chart' => [
              '#theme' => 'area_vote_chart',
              '#candidates' => $chart_data['candidates'],
              '#attached' => [
                'library' => [
                  'localgov_elections/election_results_chart',
                ],
              ],
            ],
            '#result' => [
              '#type' => 'view',
              '#name' => 'localgov_election_area_results',
              '#display_id' => 'block_area_results_table',
              '#arguments' => [
                $node->id(),
              ],
            ],
            '#analysis' => $analysis,
          ];
        }
      }
      else {
        $variables['content']['results'] = [
          '#children' => $this->t('No results have been declared yet.'),
        ];
        $variables['content']['localgov_election_further_detail'] = [
          '#access' => FALSE,
        ];
      }
    }
    elseif ($node->bundle() == 'localgov_election') {
      if ($node->hasField('localgov_election_majority')) {
        $display_majority = $node->get("localgov_election_majority")?->value;
      }
      else {
        $display_majority = FALSE;
      }
      $variables['content']['results_fieldset'] = [
        '#type' => 'container',
        '#prefix' => '<div class="area-summary"> <div class="area-summary__header" ><h2>' . $this->t("Seats elected") . '</h2></div>',
        '#suffix' => '</div>',
      ];
      $variables['content']['results_fieldset']['sub_heading'] = [
        '#type' => 'container',
        '#prefix' => '<div class="area-summary__subheading">',
        '#suffix' => '</div>',
      ];
      $variables['content']['results_fieldset']['sub_heading']['election_results_electorate'] = [
        '#type' => 'view',
        '#name' => 'localgov_election_results',
        '#display_id' => 'block_electorate',
        '#arguments' => [
          $node->id(),
        ],
      ];
      $variables['content']['results_fieldset']['sub_heading']['election_results_turnout'] = [
        '#type' => 'view',
        '#name' => 'localgov_election_results',
        '#display_id' => 'block_area_winners',
        '#arguments' => [
          $node->id(),
        ],
      ];
      $chart_data = _localgov_elections_chart_data($node);
      $variables['content']['results_fieldset']['election_results_by_party'] = [
        '#theme' => 'election_results_chart',
        '#parties' => $chart_data['parties'],
        '#max_seats' => $chart_data['max_seats'],
        '#attached' => [
          'library' => [
            'localgov_elections/election_results_chart',
          ],
        ],
      ];
      if ($display_majority) {
        $variables['content']['results_fieldset']['election_results_majority'] = [
          '#type' => 'view',
          '#name' => 'localgov_election_results',
          '#display_id' => 'block_majority',
          '#arguments' => [
            $node->id(),
          ],
        ];
      }
      $variables['content']['election_results_summary_table'] = [
        '#type' => 'view',
        '#name' => 'localgov_election_results',
        '#display_id' => 'summary_table',
        '#arguments' => [
          $node->id(),
        ],
      ];
    }
  }

  /**
   * Implements hook_preprocess_HOOK().
   */
  #[Hook('preprocess_election_menu')]
  public function preprocessElectionMenu(&$variables): void {
    $attributes = new Attribute();
    $attributes->setAttribute('id', 'election-menu');
    $variables['attributes'] = $attributes;
    // Map child routes to their parent menu item route for active state.
    $active_route_map = [
      'view.localgov_election_notices.page_notice_detail' => 'view.localgov_election_notices.page_notices',
    ];
    $current = \Drupal::routeMatch()->getRouteName();
    $current = $active_route_map[$current] ?? $current;
    foreach ($variables['links'] as $link) {
      /** @var \Drupal\Core\Link $url */
      $url = $link['link'];
      if ($url->getUrl()->getRouteName() == $current) {
        $link['attributes']->addClass('active');
      }
    }
  }

  /**
   * Implements hook_preprocess_HOOK().
   */
  #[Hook('preprocess_block')]
  public function preprocessBlock(&$variables): void {
    if ($variables['base_plugin_id'] == 'localgov_elections_electionmenu') {
      $variables['attributes']['class'][] = 'election-menu-block';
    }
    // Set the page title to be the name of the area.
    $node = \Drupal::request()->attributes->get('node');
    if ($node && $node instanceof NodeInterface) {
      if ($node->bundle() == 'localgov_area_vote') {
        if ($variables['base_plugin_id'] == 'localgov_page_header_block') {
          $variables['content'][0]['#title'] = $node->get('localgov_election_area_name')->value;
        }
      }
    }
  }

  /**
   * Implements hook_menu_local_tasks_alter().
   */
  #[Hook('menu_local_tasks_alter')]
  public function menuLocalTasksAlter(&$data, $route_name): void {
    $node = \Drupal::routeMatch()->getParameter('node');
    if ($node instanceof NodeInterface) {
      $type = $node->getType();
      if ($type != 'localgov_election') {
        // Hide election-specific tabs from non-election nodes.
        unset($data['tabs'][0]['views_view:view.localgov_election_results_timeline.page_timeline']);
        unset($data['tabs'][0]['views_view:view.localgov_election_results_vote.page_vote_share']);
        unset($data['tabs'][0]['views_view:view.localgov_electoral_candidates.page_candidates']);
        unset($data['tabs'][0]['views_view:view.localgov_election_electoral_map.page_map']);
        unset($data['tabs'][0]['views_view:view.localgov_election_areas_admin.page_table']);
      }
      else {
        $appropriate_fetch_routes = [
          "entity.node.canonical",
          "entity.node.edit_form",
          "entity.node.version_history",
          "entity.node.delete_form",
          "entity.node.preview_link_generate",
        ];
        // Add the "add area" button to the local tasks if user has permission.
        $can_add_areas = \Drupal::currentUser()->hasPermission('can fetch boundaries');
        if ($can_add_areas && in_array($route_name, $appropriate_fetch_routes, TRUE)) {
          $data['tabs'][0]['boundary_fetch'] = [
            '#theme' => 'menu_local_task',
            '#weight' => 100,
            '#link' => [
              'title' => $this->t('Add areas'),
              'url' => Url::fromRoute('localgov_elections.boundary_fetch', [
                'node' => $node->id(),
              ]),
            ],
          ];
        }
      }
    }
    if ($route_name === 'entity.node.canonical') {
      $node = \Drupal::routeMatch()->getParameter('node');
      if ($node instanceof NodeInterface && $node->bundle() !== 'localgov_election') {
        // Remove duplicate tab if not localgov_election.
        unset($data['tabs'][0]['localgov_elections.election_duplicate_tab']);
      }
    }
  }

  /**
   * Implements hook_preprocess_HOOK() for the vote share view.
   */
  #[Hook('preprocess_views_view__localgov_election_results_vote')]
  public function preprocessViewsViewLocalgovElectionResultsVote(array &$variables): void {
    $view = $variables['view'];
    $args = $view->args;
    if (empty($args[0])) {
      return;
    }
    $node = \Drupal::entityTypeManager()->getStorage('node')->load($args[0]);
    if (!$node instanceof NodeInterface || $node->bundle() !== 'localgov_election') {
      return;
    }
    $chart_data = _localgov_elections_vote_share_data($node);
    $variables['vote_share_chart'] = [
      '#theme' => 'election_vote_share_chart',
      '#parties' => $chart_data['parties'],
      '#total_votes' => number_format($chart_data['total_votes']),
      '#max_share' => $chart_data['max_share'],
      '#attached' => [
        'library' => [
          'localgov_elections/election_vote_share_chart',
        ],
      ],
    ];
  }

  /**
   * Implements hook_preprocess_HOOK() for the election notices list page.
   */
  #[Hook('preprocess_views_view__localgov_election_notices__page_notices')]
  public function preprocessViewsViewLocalgovElectionNoticesPageNotices(array &$variables): void {
    $view = $variables['view'];
    $node_id = $view->args[0] ?? NULL;
    $notices = [];
    foreach ($view->result as $row) {
      $paragraph = $row->_relationship_entities['localgov_election_notices'] ?? NULL;
      if (!$paragraph) {
        continue;
      }
      $date_raw = $paragraph->get('localgov_election_notice_date')->value ?? NULL;
      $date_formatted = '';
      $date_attr = '';
      if ($date_raw) {
        $date_obj = new \DateTime($date_raw);
        $date_formatted = $date_obj->format('j F Y');
        $date_attr = $date_obj->format('Y-m-d');
      }
      $url = Url::fromUri('internal:/node/' . $node_id . '/notices/' . $paragraph->id())->toString();
      $notices[] = [
        'id' => $paragraph->id(),
        'title' => $paragraph->get('localgov_election_notice_title')->value ?? '',
        'date' => $date_formatted,
        'date_attr' => $date_attr,
        'url' => $url,
      ];
    }
    $variables['notices'] = $notices;
  }

  /**
   * Implements hook_preprocess_HOOK() for the election notice detail page.
   */
  #[Hook('preprocess_views_view__localgov_election_notices__page_notice_detail')]
  public function preprocessViewsViewLocalgovElectionNoticesPageNoticeDetail(array &$variables): void {
    $view = $variables['view'];
    $paragraph_id = $view->args[1] ?? NULL;
    if (!$paragraph_id) {
      return;
    }
    $paragraph = \Drupal::entityTypeManager()->getStorage('paragraph')->load($paragraph_id);
    if (!$paragraph || $paragraph->bundle() !== 'localgov_election_notice') {
      return;
    }
    $date_raw = $paragraph->get('localgov_election_notice_date')->value ?? NULL;
    $date_formatted = '';
    $date_attr = '';
    if ($date_raw) {
      $date_obj = new \DateTime($date_raw);
      $date_formatted = $date_obj->format('j F Y');
      $date_attr = $date_obj->format('Y-m-d');
    }
    $variables['notice'] = [
      'title' => $paragraph->get('localgov_election_notice_title')->value ?? '',
      'date' => $date_formatted,
      'date_attr' => $date_attr,
      'content' => $paragraph->get('localgov_election_notice_content')->view('default'),
    ];
  }

  /**
   * Implements hook_entity_update().
   */
  #[Hook('entity_update')]
  public function entityUpdate(EntityInterface $entity): void {
    if ($entity->getEntityTypeId() === 'node' && $entity->getType() === 'localgov_election') {
      /** @var \Drupal\localgov_elections\Service\ElectionAliasManager $alias_manager */
      $alias_manager = \Drupal::service('localgov_elections.alias_manager');
      $alias_manager->generateElectionAliases($entity);
    }
    if ($entity->getEntityTypeId() === 'node' && $entity->getType() === 'localgov_area_vote') {
      // Clean up empty uncontested candidates from seats.
      if ($entity->hasField('localgov_election_seats')) {
        $seats = $entity->get('localgov_election_seats')->referencedEntities();
        foreach ($seats as $seat) {
          if ($seat->bundle() === 'localgov_area_seat') {
            $seat_not_contested = $seat->get('localgov_seat_not_contested')->value;
            $candidate = $seat->get('localgov_candidate_uncontested')->entity;
            if ($candidate) {
              $should_delete = !$seat_not_contested || $candidate->get('localgov_election_party')->isEmpty();
              if ($should_delete) {
                $candidate->delete();
              }
            }
          }
        }
      }
    }
  }

  /**
   * Implements hook_preprocess_html().
   */
  #[Hook('preprocess_html')]
  public function preprocessHtml(&$variables): void {
    $route = \Drupal::routeMatch()->getRouteName();
    if ($route && (str_starts_with($route, 'view.localgov_election') || str_starts_with($route, 'view.localgov_electoral'))) {
      $variables['attributes']['class'][] = 'localgov-elections';
      return;
    }
    $node = \Drupal::routeMatch()->getParameter('node');
    if ($node instanceof NodeInterface && in_array($node->bundle(), [
      'localgov_election',
      'localgov_area_vote',
    ], TRUE)) {
      $variables['attributes']['class'][] = 'localgov-elections';
    }
  }

  /**
   * Implements hook_theme_suggestions_HOOK_alter().
   */
  #[Hook('theme_suggestions_localgov_page_header_block_alter')]
  public function themeSuggestionsLocalgovPageHeaderBlockAlter(array &$suggestions, array $variables): void {
    $route = \Drupal::routeMatch()->getRouteName();
    if ($route && (str_starts_with($route, 'view.localgov_election') || str_starts_with($route, 'view.localgov_electoral'))) {
      $suggestions[] = 'localgov_page_header_block__localgov_election';
    }
  }

  /**
   * Implements hook_theme_registry_alter().
   */
  #[Hook('theme_registry_alter')]
  public function themeRegistryAlter(&$theme_registry): void {
    if (isset($theme_registry['localgov_page_header_block'])) {
      $module_path = \Drupal::service('extension.list.module')->getPath('localgov_elections');
      $base = $theme_registry['localgov_page_header_block'];
      $suggestion_entry = [
        'base hook' => 'localgov_page_header_block',
        'template' => 'localgov-page-header-block--localgov-election',
        'path' => $module_path . '/templates',
        'type' => 'module',
        'theme path' => $module_path,
        'variables' => $base['variables'],
        'preprocess functions' => $base['preprocess functions'] ?? [],
      ];
      $theme_registry['localgov_page_header_block__localgov_election'] = $suggestion_entry;
      $theme_registry['localgov_page_header_block__localgov_area_vote'] = $suggestion_entry;
    }
  }

}
