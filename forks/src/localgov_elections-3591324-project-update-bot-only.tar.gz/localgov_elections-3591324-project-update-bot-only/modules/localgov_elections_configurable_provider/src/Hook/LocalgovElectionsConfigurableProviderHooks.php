<?php

namespace Drupal\localgov_elections_configurable_provider\Hook;

use Drupal\Core\Url;
use Drupal\Core\Entity\EntityInterface;
use Drupal\Core\Hook\Attribute\Hook;
use Drupal\Core\StringTranslation\StringTranslationTrait;

/**
 * Hook implementations for localgov_elections_configurable_provider.
 */
class LocalgovElectionsConfigurableProviderHooks {
  use StringTranslationTrait;

  /**
   * Implements hook_entity_operation().
   */
  #[Hook('entity_operation')]
  public function entityOperation(EntityInterface $entity): array {
    $operations = [];
    if ($entity->getEntityTypeId() === 'boundary_source') {
      // Only show export for configurable provider sources.
      if ($entity->get('plugin') === 'configurable_provider') {
        $operations['export'] = [
          'title' => $this->t('Export'),
          'url' => Url::fromRoute('localgov_elections_configurable_provider.boundary_source.export', [
            'boundary_source' => $entity->id(),
          ]),
          'weight' => 50,
        ];
      }
    }
    return $operations;
  }

}
