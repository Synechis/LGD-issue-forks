<?php

namespace Drupal\localgov_elections_demo_content\Hook;

use Drupal\Core\Hook\Attribute\Hook;

/**
 * Hook implementations for localgov_elections_demo_content.
 */
class LocalgovElectionsDemoContentHooks {
  /**
   * @file
   * LocalGovDrupal elections demo module file.
   */

  /**
   * Implements hook_modules_installed().
   */
  #[Hook('modules_installed')]
  public function modulesInstalled($modules, $is_syncing): void {
    if ($is_syncing) {
      return;
    }
    // When this module is installed, process the imported demo content.
    if (in_array('localgov_elections_demo_content', $modules, TRUE)) {
      _localgov_elections_demo_content_post_import();
    }
  }

}
