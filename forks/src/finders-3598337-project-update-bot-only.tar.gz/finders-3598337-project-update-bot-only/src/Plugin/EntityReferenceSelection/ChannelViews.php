<?php

namespace Drupal\finders\Plugin\EntityReferenceSelection;

use Drupal\Core\Config\Entity\ConfigEntityInterface;
use Drupal\Core\Entity\Attribute\EntityReferenceSelection;
use Drupal\Core\Entity\EntityReferenceSelection\SelectionPluginBase;
use Drupal\Core\Entity\EntityTypeManagerInterface;
use Drupal\Core\Plugin\ContainerFactoryPluginInterface;
use Drupal\Core\StringTranslation\TranslatableMarkup;
use Drupal\finders\FinderTypeManager;
use Symfony\Component\DependencyInjection\ContainerInterface;

/**
 * Selection plugin for  channel views fields on a channel entity.
 *
 * This limits the referenceable views to those whose base table is a SearchAPI
 * index for the same finder type as the host entity.
 */
#[EntityReferenceSelection(
  id: 'finders_channel_views',
  label: new TranslatableMarkup("Channel Views"),
  group: 'finders_channel_views',
  weight: 0,
  entity_types: [
    'view',
  ],
)]
class ChannelViews extends SelectionPluginBase implements ContainerFactoryPluginInterface {

  /**
   * {@inheritdoc}
   */
  public static function create(ContainerInterface $container, array $configuration, $plugin_id, $plugin_definition) {
    return new static(
      $configuration,
      $plugin_id,
      $plugin_definition,
      $container->get('entity_type.manager'),
      $container->get('plugin.manager.finders_finder_type'),
    );
  }

  /**
   * Creates a ChannelViews instance.
   *
   * @param array $configuration
   *   A configuration array containing information about the plugin instance.
   * @param string $plugin_id
   *   The plugin_id for the plugin instance.
   * @param mixed $plugin_definition
   *   The plugin implementation definition.
   * @param \Drupal\Core\Entity\EntityTypeManagerInterface $entityTypeManager
   *   The entity type manager.
   * @param \Drupal\finders\FinderTypeManager $finderTypeManager
   *   The finder type manager.
   */
  public function __construct(
    array $configuration,
    $plugin_id,
    $plugin_definition,
    protected EntityTypeManagerInterface $entityTypeManager,
    protected FinderTypeManager $finderTypeManager,
  ) {
    parent::__construct($configuration, $plugin_id, $plugin_definition);
  }

  /**
   * {@inheritdoc}
   */
  public function getReferenceableEntities($match = NULL, $match_operator = 'CONTAINS', $limit = 0) {
    // Get the entity we are getting field values for.
    $host_entity = $this->configuration['entity'];
    $host_entity_bundle_entity_type_id = $host_entity->getEntityType()->getBundleEntityType();
    $host_entity_bundle_entity = $this->entityTypeManager->getStorage($host_entity_bundle_entity_type_id)->load($host_entity->bundle());
    assert($host_entity_bundle_entity instanceof ConfigEntityInterface);
    $finder_type_plugin = $this->entityTypeManager
      ->getStorage('finder')
      ->getFinderForBundleEntity($host_entity_bundle_entity)
      ->getFinderTypePlugin();

    $index_ids = $finder_type_plugin->getIndexIds();

    // Derive SearchAPI's Views database tables for the finder type's search
    // indexes.
    // @see search_api_views_data()
    $views_base_tables = array_map(fn ($index_id) => 'search_api_index_' . $index_id, $index_ids);

    // Filter to the views which are one of the index base tables for the
    // host entity's finder type.
    $views = $this->entityTypeManager->getStorage('view')->loadMultiple();
    $views = array_filter($views, fn ($view) => in_array($view->get('base_table'), $views_base_tables));

    $options = [];
    foreach ($views as $view_id => $view) {
      $options[$view_id] = $view->label();
    }
    natcasesort($options);

    $options = ['view' => $options];

    return $options;
  }

  /**
   * {@inheritdoc}
   */
  public function countReferenceableEntities($match = NULL, $match_operator = 'CONTAINS') {
    $options = $this->getReferenceableEntities($match, $match_operator);
    return count($options);
  }

  /**
   * {@inheritdoc}
   */
  public function validateReferenceableEntities(array $ids) {
    return $ids;
  }

}
