<?php

namespace Drupal\finders\Hook;

use Drupal\Core\Config\Entity\ConfigEntityInterface;
use Drupal\Core\Entity\ContentEntityInterface;
use Drupal\Core\Entity\EntityTypeManagerInterface;
use Drupal\Core\Hook\Attribute\Hook;
use Drupal\pathauto\Entity\PathautoPattern;

/**
 * Contains pathauto hook implementations for the Finders module.
 */
class PathautoHooks {

  /**
   * The entity type manager.
   *
   * @var \Drupal\Core\Entity\EntityTypeManagerInterface
   */
  protected $entityTypeManager;

  /**
   * Creates a PathautoHooks instance.
   *
   * @param \Drupal\Core\Entity\EntityTypeManagerInterface $entity_type_manager
   *   The entity type manager.
   */
  public function __construct(
    EntityTypeManagerInterface $entity_type_manager,
  ) {
    $this->entityTypeManager = $entity_type_manager;
  }

  /**
   * Implements hook_pathauto_pattern_alter().
   */
  #[Hook('pathauto_pattern_alter')]
  public function pathautoPatternAlter(PathautoPattern $pattern, array $context) {
    // If pathauto isn't set to include this entity into directory, but
    // it has opt-ed in with the field add the (optional) parent to the path.
    $entity = reset($context['data']);
    assert($entity instanceof ContentEntityInterface);

    $bundle_id = $entity->bundle();
    $bundle_entity_type_id = $entity->getEntityType()->getBundleEntityType();
    $bundle_entity = $this->entityTypeManager->getStorage($bundle_entity_type_id)->load($bundle_id);
    assert($bundle_entity instanceof ConfigEntityInterface);

    $finder = $this->entityTypeManager->getStorage('finder')->getFinderForBundleEntity($bundle_entity);

    if (is_null($finder)) {
      return;
    }

    $channel_selection_field = $finder->getFinderTypePlugin()->getFinderTypeConstant('CHANNEL_SELECTION_FIELD');

    if (!$entity->hasField($channel_selection_field)) {
      return;
    }

    // Add the channel path pattern if the entry path pattern does not already
    // contain it.
    $parent_pattern = '[node:' . $channel_selection_field . ':0:entity:url:relative]';
    if (!str_contains($pattern->getPattern(), $parent_pattern)) {
      $pattern->setPattern($parent_pattern . $pattern->getPattern());
    }
  }

}
