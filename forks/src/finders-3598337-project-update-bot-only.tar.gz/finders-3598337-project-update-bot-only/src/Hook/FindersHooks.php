<?php

namespace Drupal\finders\Hook;

use Drupal\pathauto\Entity\PathautoPattern;
use Drupal\Core\Hook\Attribute\Hook;

/**
 * Hook implementations for finders.
 */
class FindersHooks {

  /**
   * Implements hook_pathauto_pattern_alter().
   */
  #[LegacyHook]
  #[Hook('pathauto_pattern_alter')]
  public function pathautoPatternAlter(PathautoPattern $pattern, array $context) {
    return \Drupal::service(PathautoHooks::class)->pathautoPatternAlter($pattern, $context);
  }

}
