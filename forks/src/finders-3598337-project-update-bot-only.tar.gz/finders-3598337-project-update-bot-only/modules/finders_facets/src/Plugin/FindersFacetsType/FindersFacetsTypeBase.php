<?php

namespace Drupal\finders_facets\Plugin\FindersFacetsType;

use Drupal\Component\Plugin\PluginBase;
use Drupal\Core\Entity\EntityTypeManagerInterface;
use Drupal\Core\Extension\ModuleExtensionList;
use Drupal\Core\Plugin\ContainerFactoryPluginInterface;
use Drupal\finders\Entity\FinderInterface;
use Drupal\finders_facets\Hook\FindersHooks;
use Drupal\search_api\IndexInterface;
use Drupal\views\ViewEntityInterface;
use Symfony\Component\DependencyInjection\ContainerInterface;

/**
 * Base class for Finders Facets Type plugins.
 */
abstract class FindersFacetsTypeBase extends PluginBase implements FindersFacetsTypeInterface, ContainerFactoryPluginInterface {

  /**
   * {@inheritdoc}
   */
  public static function create(ContainerInterface $container, array $configuration, $plugin_id, $plugin_definition) {
    return new static(
      $configuration,
      $plugin_id,
      $plugin_definition,
      $container->get('entity_type.manager'),
      $container->get('extension.list.module'),
    );
  }

  /**
   * Creates a Default instance.
   *
   * @param array $configuration
   *   A configuration array containing information about the plugin instance.
   * @param string $plugin_id
   *   The plugin_id for the plugin instance.
   * @param mixed $plugin_definition
   *   The plugin implementation definition.
   * @param \Drupal\Core\Entity\EntityTypeManagerInterface $entityTypeManager
   *   The entity type manager.
   * @param \Drupal\Core\Extension\ModuleExtensionList $moduleExtensionList
   *   The module handler.
   */
  public function __construct(
    array $configuration,
    $plugin_id,
    $plugin_definition,
    protected EntityTypeManagerInterface $entityTypeManager,
    protected ModuleExtensionList $moduleExtensionList,
  ) {
    parent::__construct($configuration, $plugin_id, $plugin_definition);
  }

  /**
   * {@inheritdoc}
   */
  public function findersPostConfigure(FinderInterface $finder): void {
    $finder_type = $finder->getFinderTypePlugin();

    // Ensure a facet for each view.
    $indexes = $this->entityTypeManager->getStorage('search_api_index')->loadMultiple($finder_type->getIndexIds());
    foreach ($indexes as $index) {
      $view_ids = $finder_type->getViewIds($index);
      $views = $this->entityTypeManager->getStorage('view')->loadMultiple($view_ids);

      foreach ($views as $view) {

        $facet_ids = [];

        // We insert the facet filters into the view's configuration. We hack
        // them directly into the config array because the API in Views seems to
        // go via the ViewsExecutable object and no idea how that works.
        $displays = $view->get('display');

        // Get the config template for the content facet filter.
        $content_facet_values = $this->loadViewContentFacetsFacet($view, $index, $finder);
        if ($content_facet_values) {
          // Do not overwrite an existing filter.
          $facet_id = $content_facet_values['id'];
          if (!isset($displays['default']['display_options']['filters'][$facet_id])) {
            $displays['default']['display_options']['filters'][$facet_id] = $content_facet_values;
          }
          $facet_ids[] = $facet_id;
        }

        // Allow plugins to add further facets.
        $extra_facets = $this->getExtraViewFacetFilters($view, $index, $finder);
        // Do not overwrite an existing filters.
        $displays['default']['display_options']['filters'] += $extra_facets;

        $view->set('display', $displays);

        // Set up the exposed form options.
        $displays['default']['display_options']['exposed_form']['type'] = 'bef';
        $displays['default']['display_options']['exposed_form']['options']['reset_button'] = TRUE;

        // Set up the facets filter exposed options.
        $facet_ids = array_merge($facet_ids, array_keys($extra_facets));
        $this->alterFacetFilterExposedFormOptions($displays['default']['display_options']['exposed_form']['options'], $facet_ids, $view, $finder);

        // Set the display options back in the view.
        $view->set('display', $displays);

        $view->save();
      }
    }
  }

  /**
   * Gets the config values for the content facet filter.
   *
   * @param \Drupal\views\ViewEntityInterface $view
   *   The view on the given search index to add the facet filter into.
   * @param \Drupal\search_api\IndexInterface $index
   *   The search index to add facets for.
   * @param \Drupal\finders\Entity\FinderInterface $finder
   *   The finder being configured.
   *
   * @return array|null
   *   An array of Views facet filter values, NULL to not create a facet for
   *   this view and index.
   */
  protected function loadViewContentFacetsFacet(ViewEntityInterface $view, IndexInterface $index, FinderInterface $finder): ?array {
    // There is no API we can call on Facets module to get this prefix
    // -- this is the same thing
    // facets_exposed_filters_views_data_alter() does.
    $facet_id = 'facets_' . FindersHooks::FACET_INDEXING_FIELD;

    $config_values = \Drupal::service('finders.config_template_loader')->loadTemplateConfigValues(
      'views.view.snippet.finder_channel.filter.facet',
      'views.view.snippet.finder_channel.filter.facet',
      $finder->getFinderTypePlugin(),
      'finders_facets',
      [
        'BASE_TABLE' => $view->get('base_table'),
        'FIELD_ID' => $facet_id,
      ],
    );

    return $config_values;
  }

  /**
   * Sets up the exposed form options for the facet filters.
   *
   * @param array &$view_exposed_form_options
   *   The exposed form options array for the view, passed by reference. It is
   *   the caller's responsibility to set these back in the view.
   * @param array $facet_ids
   *   An array of the facet IDs being set up on this view. This includes the
   *   default facet entity facet and the facets returned by
   *   static::getExtraViewFacetFilters().
   * @param \Drupal\views\ViewEntityInterface $view
   *   The view being altered. It is the caller's responsibility to save it.
   * @param \Drupal\finders\Entity\FinderInterface $finder
   *   The finder being configured.
   */
  protected function alterFacetFilterExposedFormOptions(array &$view_exposed_form_options, array $facet_ids, ViewEntityInterface $view, FinderInterface $finder) {
    foreach ($facet_ids as $facet_id) {
      // Set up the facets filter exposed options.
      if (!isset($view_exposed_form_options['bef']['filter'][$facet_id])) {
        // Set the filter widget to checkboxes.
        $view_exposed_form_options['bef']['filter'][$facet_id]['plugin_id'] = 'bef';
        // @todo None of the other properties get set. We only want the
        // defaults, but getting the default values of the properties out of the
        // plugin is hard.
      }
    }

    // Use our custom checkboxes widget on the content facets filter.
    $finders_content_facet_id = 'facets_' . FindersHooks::FACET_INDEXING_FIELD;
    $view_exposed_form_options['bef']['filter'][$finders_content_facet_id]['plugin_id'] = 'finders_facets_checkboxes';
  }

  /**
   * Gets additional facet filters for an index and view.
   *
   * @param \Drupal\views\ViewEntityInterface $view
   *   The view on the given search index to add facets for.
   * @param \Drupal\search_api\IndexInterface $index
   *   The search index to add facets for.
   * @param \Drupal\finders\Entity\FinderInterface $finder
   *   The finder being configured.
   *
   * @return array
   *   An array of configuration for facet filters.
   */
  protected function getExtraViewFacetFilters(ViewEntityInterface $view, IndexInterface $index, FinderInterface $finder): array {
    // Do nothing in the base class.
    return [];
  }

}
