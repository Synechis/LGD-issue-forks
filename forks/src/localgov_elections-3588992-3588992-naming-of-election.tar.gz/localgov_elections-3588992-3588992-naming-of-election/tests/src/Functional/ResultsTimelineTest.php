<?php

declare(strict_types=1);

namespace Drupal\Tests\localgov_elections\Functional;

use Drupal\Core\Url;
use Drupal\Tests\BrowserTestBase;
use Drupal\Tests\node\Traits\NodeCreationTrait;
use Drupal\node\NodeInterface;

/**
 * Tests election result finalization times in the Results timeline page.
 *
 * Date and times are stored in UTC timezone and displayed in the Europe/London
 * timezone.
 *
 * Note: Drupal tests use the Australia/Sydney timezone by default.
 *
 * @see core/tests/bootstrap.php
 * @group localgov_elections
 */
class ResultsTimelineTest extends BrowserTestBase {

  use NodeCreationTrait;

  /**
   * Tests result heading text.
   */
  public function testResultHeadingOnSummaryPage(): void {

    $results_timeline_url = Url::fromRoute('view.localgov_election_results_timeline.page_timeline', [
      'node' => $this->electionPage->id(),
    ]);

    $this->drupalGet($results_timeline_url);
    $this->assertSession()->statusCodeEquals(200);
    $this->assertSession()->pageTextContains('24th April 2026');
    $this->assertSession()->pageTextContains('29th March 2026');

    $this->assertSession()->pageTextContains('10:01');
    $this->assertSession()->pageTextContains('00:01');
    $this->assertSession()->pageTextContains('02:01');
  }

  /**
   * {@inheritdoc}
   *
   * Sets up an Election page and attaches three Electoral areas to it with the
   * following finalization *UTC* date and times:
   * - 2026-03-29T00:01:01 -> Should be displayed as 2026-03-29T00:01:01
   * - 2026-03-29T01:01:01 -> Should be displayed as 2026-03-29T02:01:01
   * - 2026-04-24T09:01:01 -> Should be displayed as 2026-04-24T10:01:01
   *
   * These date and time are later displayed in the Europe/London timezone.
   */
  protected function setUp(): void {

    parent::setUp();

    $this->config('system.date')
      ->set('timezone.default', 'Europe/London')
      ->save();

    // Install localgov_elections here to include optional configuration in D11.
    $this->container->get('module_installer')->install([
      'localgov_elections',
      'localgov_elections_uk_parties',
    ]);
    $this->rebuildContainer();
    $this->container->get('router.builder')->rebuild();

    $this->electionPage = $this->createNode([
      'type'   => "localgov_election",
      'title'  => "UK Election 2024",
      'status' => TRUE,
    ]);

    // 3x Electoral area nodes.
    $this->createNode([
      'title'                            => 'This election - an area',
      'status'                           => TRUE,
      'type'                             => 'localgov_area_vote',
      'localgov_election'                => $this->electionPage->id(),
      'localgov_election_area_name'      => 'An area',
      'localgov_election_votes_final'    => TRUE,
      'localgov_election_finalised_date' => '2026-03-29T00:01:01',
      'localgov_election_no_contest'     => FALSE,
    ]);

    $this->createNode([
      'title'                            => 'This election - another area',
      'status'                           => TRUE,
      'type'                             => 'localgov_area_vote',
      'localgov_election'                => $this->electionPage->id(),
      'localgov_election_area_name'      => 'Another area',
      'localgov_election_votes_final'    => TRUE,
      'localgov_election_finalised_date' => '2026-03-29T01:01:01',
      'localgov_election_no_contest'     => FALSE,
    ]);

    $this->createNode([
      'title'                            => 'This election - yet another area',
      'status'                           => TRUE,
      'type'                             => 'localgov_area_vote',
      'localgov_election'                => $this->electionPage->id(),
      'localgov_election_area_name'      => 'Yet another area',
      'localgov_election_votes_final'    => TRUE,
      'localgov_election_finalised_date' => '2026-04-24T09:01:01',
      'localgov_election_no_contest'     => FALSE,
    ]);
  }

  /**
   * Drupal theme used during test runs.
   *
   * @var string
   */
  protected $defaultTheme = 'stark';

  /**
   * Modules to activate.
   *
   * @var array
   */
  protected static $modules = [
    'localgov_core',
    'localgov_media',
  ];

  /**
   * An election node.
   *
   * @var Drupal\node\NodeInterface
   */
  protected NodeInterface $electionPage;

  /**
   * {@inheritdoc}
   */
  // @codingStandardsIgnoreStart
  protected $strictConfigSchema = FALSE;
  // @codingStandardsIgnoreEnd

}
