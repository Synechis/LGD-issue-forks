<?php

namespace Drupal\finders_facets;

use Drupal\Component\Utility\Html;
use Drupal\Core\Block\BlockManagerInterface;
use Drupal\Core\DependencyInjection\ContainerInjectionInterface;
use Drupal\Core\Entity\EntityFieldManagerInterface;
use Drupal\Core\Entity\EntityRepositoryInterface;
use Drupal\Core\Entity\EntityTypeManagerInterface;
use Drupal\Core\Form\FormBuilderInterface;
use Drupal\Core\Render\Element;
use Drupal\Core\Routing\RouteMatchInterface;
use Drupal\Core\Template\Attribute;
use Drupal\finders_facets\Entity\FindersFacetTypeInterface;
use Drupal\finders_facets\Entity\FindersFacetInterface;
use Drupal\node\NodeInterface;
use Symfony\Component\DependencyInjection\ContainerInterface;

/**
 * Groups facet values.
 */
class FindersFacetsProcessor implements ContainerInjectionInterface {

  /**
   * Constructor.
   */
  public function __construct(
    protected EntityTypeManagerInterface $entityTypeManager,
    protected EntityRepositoryInterface $entityRepository,
    protected EntityFieldManagerInterface $entityFieldManager,
    protected BlockManagerInterface $pluginBlockManager,
    protected FormBuilderInterface $formBuilder,
    protected RouteMatchInterface $routeMatch,
  ) {
  }

  /**
   * {@inheritdoc}
   */
  public static function create(ContainerInterface $container) {
    return new static(
      $container->get('entity_type.manager'),
      $container->get('entity.repository'),
      $container->get('entity_field.manager'),
      $container->get('plugin.manager.block'),
      $container->get('form_builder'),
      $container->get('current_route_match'),
    );
  }

  /**
   * Prepares variables for our bundle grouped facets item list template.
   *
   * Facet bundles are sorted based on their weight.
   *
   * @see templates/facets-item-list--links--finders-facets.html.twig
   */
  public function preprocessFacetList(array &$variables) {

    $show_reset_link = [];

    // Check if the show reset link has been enabled.
    foreach ($variables['items'] as $key => $item) {
      if ($variables["items"][$key]["value"]["#attributes"]["data-drupal-facet-item-value"] == 'reset_all') {
        $variables["attributes"]["class"][] = "facet-show-reset";
        $show_reset_link = current($variables["items"]);
      }
    }

    $variables['items'] = $this->groupFacetItems($variables['items']);

    if (!empty($show_reset_link)) {
      // Add the reset link.
      $variables['items']['show_reset_all']['items'][] = $show_reset_link;
      $reset_all = $variables['items']['show_reset_all'];
      // Place the reset link at the top of the facet filters.
      array_unshift($variables['items'], $reset_all);
      array_pop($variables['items']);
    }
  }

  /**
   * Groups facet checkboxes.
   *
   * Prepares variables for facet checkboxes grouped by facet types.
   *
   * @see templates/checkboxes--finders-facets.html.twig
   */
  public function preprocessFacetCheckboxes(array &$variables): void {

    $facet_id_list = Element::children($variables['element']);
    $facet_options = array_filter($variables['element'], fn($facet_id) => in_array($facet_id, $facet_id_list, strict: TRUE), ARRAY_FILTER_USE_KEY);
    $variables['grouped_options'] = $this->groupFacetItems($facet_options);
  }

  /**
   * Groups facet items by facet types.
   */
  protected function groupFacetItems(array $facet_items): array {

    $facet_storage = $this->entityTypeManager->getStorage('finders_facet');
    $group_items = [];
    foreach ($facet_items as $key => $item) {
      $facet_id = $item['value']['#attributes']['data-drupal-facet-item-value'] ?? $key;
      if ($facet_entity = $facet_storage->load($facet_id)) {
        assert($facet_entity instanceof FindersFacetInterface);
        $group_items[$facet_entity->bundle()]['items'][$key] = $item;
      }
    }

    // This is usually on a channel node. If so remove facets not active on
    // channel.
    // @todo Handle other entities that can also be finder channels.
    $channel = $this->routeMatch->getParameter('node');
    $active_facets = NULL;
    if ($channel instanceof NodeInterface && $channel->hasField('finders_facets_enable')) {
      $active_facets = array_column($channel->finders_facets_enable->getValue(), 'target_id');
    }
    if (!is_null($active_facets)) {
      $group_items = array_intersect_key($group_items, array_flip($active_facets));
    }

    $type_storage = $this->entityTypeManager->getStorage('finders_facet_type');
    foreach ($group_items as $bundle => $items) {
      $facet_type_entity = $type_storage->load($bundle);
      assert($facet_type_entity instanceof FindersFacetTypeInterface);
      $group_items[$bundle]['title'] = Html::escape($this->entityRepository->getTranslationFromContext($facet_type_entity)->label());
      $group_items[$bundle]['weight'] = $facet_type_entity->get('weight');
    }
    uasort($group_items, static::compareFacetBundlesByWeight(...));

    return $group_items;
  }

  /**
   * Facet bundle comparison callback for sorting.
   *
   * Bundles are compared by their weights.  When weights are equal, labels take
   * over.
   *
   * @param array $bundle1
   *   Necessary keys: weight, title.
   * @param array $bundle2
   *   Same as $bundle1.
   */
  public static function compareFacetBundlesByWeight(array $bundle1, array $bundle2): int {

    if ($bundle1['weight'] === $bundle2['weight']) {
      return strnatcasecmp($bundle1['title'], $bundle2['title']);
    }

    return $bundle1['weight'] < $bundle2['weight'] ? -1 : 1;
  }

}
