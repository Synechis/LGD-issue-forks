<?php

namespace Drupal\finders_facets\Plugin\FindersFacetsType;

use Drupal\Component\Plugin\PluginBase;
use Drupal\Core\Entity\EntityTypeManagerInterface;
use Drupal\Core\Extension\ModuleExtensionList;
use Drupal\Core\Plugin\ContainerFactoryPluginInterface;
use Drupal\finders\Entity\FinderInterface;
use Drupal\finders_facets\Hook\FindersHooks;
use Drupal\search_api\IndexInterface;
use Drupal\views\ViewEntityInterface;
use Symfony\Component\DependencyInjection\ContainerInterface;

/**
 * Base class for Finders Facets Type plugins.
 */
abstract class FindersFacetsTypeBase extends PluginBase implements FindersFacetsTypeInterface, ContainerFactoryPluginInterface {

  /**
   * The entity type manager.
   *
   * @var \Drupal\Core\Entity\EntityTypeManagerInterface
   */
  protected $entityTypeManager;

  /**
   * The module handler.
   *
   * @var \Drupal\Core\Extension\ModuleHandlerInterface
   */
  protected $moduleExtensionList;

  /**
   * {@inheritdoc}
   */
  public static function create(ContainerInterface $container, array $configuration, $plugin_id, $plugin_definition) {
    return new static(
      $configuration,
      $plugin_id,
      $plugin_definition,
      $container->get('entity_type.manager'),
      $container->get('extension.list.module'),
    );
  }

  /**
   * Creates a Default instance.
   *
   * @param array $configuration
   *   A configuration array containing information about the plugin instance.
   * @param string $plugin_id
   *   The plugin_id for the plugin instance.
   * @param mixed $plugin_definition
   *   The plugin implementation definition.
   * @param \Drupal\Core\Entity\EntityTypeManagerInterface $entity_type_manager
   *   The entity type manager.
   * @param \Drupal\Core\Extension\ModuleExtensionList $module_extension_list
   *   The module handler.
   */
  public function __construct(
    array $configuration,
    $plugin_id,
    $plugin_definition,
    EntityTypeManagerInterface $entity_type_manager,
    ModuleExtensionList $module_extension_list,
  ) {
    parent::__construct($configuration, $plugin_id, $plugin_definition);
    $this->entityTypeManager = $entity_type_manager;
    $this->moduleExtensionList = $module_extension_list;
  }

  /**
   * {@inheritdoc}
   */
  public function findersPostConfigure(FinderInterface $finder): void {
    $finder_type = $finder->getFinderTypePlugin();

    // Ensure a facet for each view.
    $indexes = $this->entityTypeManager->getStorage('search_api_index')->loadMultiple($finder_type->getIndexIds());
    foreach ($indexes as $index) {
      $view_ids = $finder_type->getViewIds($index);
      $views = $this->entityTypeManager->getStorage('view')->loadMultiple($view_ids);

      foreach ($views as $view) {
        // We insert the facet filters into the view's configuration. We hack
        // them directly into the config array because the API in Views seems to
        // go via the ViewsExecutable object and no idea how that works.
        $displays = $view->get('display');

        // Get the config template for the content facet filter.
        $content_facet_values = $this->loadViewContentFacetsFacet($finder, $index, $view);
        if ($content_facet_values) {
          // Do not overwrite an existing filter.
          $facet_id = $content_facet_values['id'];
          if (!isset($displays['default']['display_options']['filters'][$facet_id])) {
            $displays['default']['display_options']['filters'][$facet_id] = $content_facet_values;
          }
        }

        // Allow plugins to add further facets.
        $extra_facets = $this->getExtraViewFacetFilters($finder, $index, $view);
        // Do not overwrite an existing filters.
        $displays['default']['display_options']['filters'] += $extra_facets;

        $view->set('display', $displays);
        // dump($displays['default']['display_options']['filters']);

        // Set up the exposed form options.
        $displays['default']['display_options']['exposed_form']['type'] = 'bef';
        $displays['default']['display_options']['exposed_form']['options']['reset_button'] = TRUE;

        // Set up the facets filter exposed options.
        $facet_ids = array_merge([$facet_id], array_keys($extra_facets));
        $this->alterFacetFilterExposedFormOptions($finder, $view, $displays['default']['display_options']['exposed_form']['options'], $facet_ids);

        // Set the display options back in the view.
        $view->set('display', $displays);

        $view->save();
      }
    }
  }

  /**
   * Gets the config values for the content facet filter.
   *
   * @param \Drupal\finders\Entity\FinderInterface $finder
   *   The finder being configured.
   * @param \Drupal\search_api\IndexInterface $index
   *   The search index to add facets for.
   * @param \Drupal\views\ViewEntityInterface $view
   *   The view on the given search index to add the facet filter into.
   *
   * @return array|null
   *   An array of Views facet filter values, NULL to not create a facet for
   *   this view and index.
   */
  protected function loadViewContentFacetsFacet(FinderInterface $finder, IndexInterface $index, ViewEntityInterface $view): ?array {
    // There is no API we can call on Facets module to get this prefix
    // -- this is the same thing
    // facets_exposed_filters_views_data_alter() does.
    $facet_id = 'facets_' . FindersHooks::FACET_INDEXING_FIELD;

    $config_values = \Drupal::service('finders.config_template_loader')->loadTemplateConfigValues(
      'views.view.snippet.finder_channel.filter.facet',
      'views.view.snippet.finder_channel.filter.facet',
      $finder->getFinderTypePlugin(),
      'finders_facets',
      [
        'BASE_TABLE' => $view->get('base_table'),
        'FIELD_ID' => $facet_id,
      ],
    );

    return $config_values;
  }

  /**
   * Sets up the exposed form options for the facet filters.
   *
   * @param \Drupal\finders\Entity\FinderInterface $finder
   *   The finder being configured.
   * @param \Drupal\views\ViewEntityInterface $view
   *   The view being altered. It is the caller's responsibility to save it.
   * @param array &$view_exposed_form_options
   *   The exposed form options array for the view, passed by reference. It is
   *   the caller's responsibility to set these back in the view.
   * @param array $facet_ids
   *   An array of the facet IDs being set up on this view. This includes the
   *   default facet entity facet and the facets returned by
   *   static::getExtraViewFacetFilters().
   */
  protected function alterFacetFilterExposedFormOptions(FinderInterface $finder, ViewEntityInterface $view, array &$view_exposed_form_options, array $facet_ids) {
    foreach ($facet_ids as $facet_id) {
      // Set up the facets filter exposed options.
      if (!isset($view_exposed_form_options['bef']['filter'][$facet_id])) {
        // Set the filter widget to checkboxes.
        $view_exposed_form_options['bef']['filter'][$facet_id]['plugin_id'] = 'bef';
        // @todo None of the other properties get set. We only want the
        // defaults, but getting the default values of the properties out of the
        // plugin is hard.
      }
    }
  }

  /**
   * Gets additional facet filters for an index and view.
   *
   * @param \Drupal\finders\Entity\FinderInterface $finder
   *   The finder being configured.
   * @param \Drupal\search_api\IndexInterface $index
   *   The search index to add facets for.
   * @param \Drupal\views\ViewEntityInterface $view
   *   The view on the given search index to add facets for.
   *
   * @return array
   *   An array of configuration for facet filters.
   */
  protected function getExtraViewFacetFilters(FinderInterface $finder, IndexInterface $index, ViewEntityInterface $view): array {
    // Do nothing in the base class.
    return [];
  }

}
