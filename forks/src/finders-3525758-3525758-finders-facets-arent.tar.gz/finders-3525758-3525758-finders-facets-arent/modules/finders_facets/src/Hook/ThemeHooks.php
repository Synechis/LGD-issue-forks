<?php

namespace Drupal\finders_facets\Hook;

use Drupal\Core\Hook\Attribute\Hook;
use Drupal\facets\FacetInterface;

/**
 * Contains theme hook implementations for the Finders facets module.
 */
class ThemeHooks {

  /**
   * Implements hook_theme().
   */
  #[Hook('theme')]
  public function theme(): array {
    return [
      'finders_facet' => [
        'render element' => 'elements',
      ],
      'facets_item_list__links__finders_facets' => [
        'base hook' => 'facets_item_list',
      ],
      // Facets for proximity search look no different.
      'facets_item_list__links__finders_facets_proximity_search' => [
        'base hook' => 'facets_item_list',
        'template'  => 'facets-item-list--links--finders-facets',
      ],
      // Facet Checkboxes are rendered through Javascript.  So the same markup as
      // "link" Facets suffices.
      'facets_item_list__checkbox__finders_facets' => [
        'base hook' => 'facets_item_list',
        'template'  => 'facets-item-list--links--finders-facets',
      ],
      'facets_item_list__checkbox__finders_facets_proximity_search' => [
        'base hook' => 'facets_item_list',
        'template'  => 'facets-item-list--links--finders-facets',
      ],
      'facets_item_list__dropdown__finders_facets' => [
        'base hook' => 'facets_item_list',
        'template'  => 'facets-item-list--dropdown--finders-facets',
      ],
      'facets_item_list__dropdown__finders_facets_proximity_search' => [
        'base hook' => 'facets_item_list',
        'template'  => 'facets-item-list--dropdown--finders-facets',
      ],
      'checkboxes__finders_facets' => [
        'base hook' => 'checkboxes',
      ],
    ];
  }

  /**
   * Implements hook_preprocess_facets_item_list().
   */
  #[Hook('preprocess_facets_item_list')]
  function preprocessFacetsItemList(array &$variables): void {

    /** @var \Drupal\facets\Entity\Facet $facet */
    $facet = $variables['facet'];

    if ($this->isFindersFacet($facet)) {
      \Drupal::service('class_resolver')
        ->getInstanceFromDefinition(\Drupal\finders_facets\FindersFacetsProcessor::class)
        ->preprocessFacetList($variables);
    }
  }

  /**
   * Implements hook_theme_suggestions_HOOK_alter() for facets_item_list.
   *
   * This lets our own theme implementations
   * (EG facets_item_list__checkbox__finders_facets) render the item list with
   * grouping, instead of the defaults.
   *
   */
  #[Hook('theme_suggestions_facets_item_list_alter')]
  function themeSuggestionsFacetsItemListAlter(array &$suggestions, array $variables): void {

    /** @var \Drupal\facets\Entity\Facet $facet */
    $facet = $variables['facet'];

    if ($this->isFindersFacet($facet)) {
      $widget = $facet->getWidget();
      $suggestions[] = 'facets_item_list__' . $widget['type'] . '__finders_facets';
    }
  }

  /**
   * Is this facet a finders facet?
   */
  protected function isFindersFacet(FacetInterface $facet): bool {
    $fieldName = $facet->getDataDefinition()->getFieldDefinition()->getName();
    return $fieldName === FindersHooks::FACET_SELECTION_FIELD;
  }

}
