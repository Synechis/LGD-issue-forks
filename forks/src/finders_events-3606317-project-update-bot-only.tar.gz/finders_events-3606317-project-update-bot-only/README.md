# Finders Events

The Finders Events module extends the Finders module by providing an 'Events'
finder type.

Event entries have a date field which supports recurring dates, and event
channels show these events in both a listing and a calendar.

## Requirements

This module requires the following modules:

- [finders](https://www.drupal.org/project/finders)
- [date_recur](https://www.drupal.org/project/date_recur)
- [date_recur_modular](https://www.drupal.org/project/date_recur_modular)
- [search_api](https://www.drupal.org/project/search_api)
- [date_recur_search_api](https://www.drupal.org/project/date_recur_search_api)
- [calendar_view](https://www.drupal.org/project/calendar_view)

The following patches are required:

- https://www.drupal.org/project/date_recur/issues/3486727 - fixes a warning
  from Views data not properly handling the bundle field.

The following patches are recommended:

- https://www.drupal.org/project/calendar_view/issues/3547610 - fixes PHP 8.4
  deprecation warnings.
