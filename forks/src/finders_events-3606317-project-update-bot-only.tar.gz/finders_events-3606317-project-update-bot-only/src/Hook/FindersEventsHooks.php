<?php

declare(strict_types=1);

namespace Drupal\finders_events\Hook;

use Drupal\Core\Entity\EntityTypeManagerInterface;
use Drupal\Core\Form\FormStateInterface;
use Drupal\Core\Hook\Attribute\Hook;
use Drupal\Core\StringTranslation\StringTranslationTrait;
use Drupal\finders_events\Plugin\FinderType\Events;

/**
 * Contains hook implementations for the Finders Events module.
 */
class FindersEventsHooks {

  use StringTranslationTrait;

  /**
   * Creates a FindersEventsHooks instance.
   *
   * @param \Drupal\Core\Entity\EntityTypeManagerInterface $entityTypeManager
   *   The entity type manager.
   */
  public function __construct(
    protected EntityTypeManagerInterface $entityTypeManager,
  ) {
  }

  /**
   * Implements hook_form_FORM_ID_alter().
   */
  #[Hook('form_entity_view_display_edit_form_alter')]
  public function formEntityViewDisplayEditFormAlter(&$form, FormStateInterface $form_state, $form_id) {
    // Tweak the labels of the date field and the occurrence computed field, as
    // otherwise they show the same label and it's impossible to distinguish
    // them.
    $entity_type = $form['#entity_type'];
    $bundle = $form['#bundle'];

    $bundle_entity_type_id = $this->entityTypeManager->getDefinition($entity_type)->getBundleEntityType();

    // Bail if this display is not for a bundle that has a config entity, as
    // in that case, it can't participate in a finder.
    if (is_null($bundle_entity_type_id)) {
      return;
    }

    $bundle_entity = $this->entityTypeManager->getStorage($bundle_entity_type_id)->load($bundle);

    /** @var \Drupal\finders\Entity\FinderInterface $finder */
    $finder = $this->entityTypeManager->getStorage('finder')->getFinderForBundleEntity($bundle_entity);

    // Bail if this bundle does not participate in a finder.
    if (is_null($finder)) {
      return;
    }

    // Bail if this bundle is not an entry bundle.
    $finder_entry_bundles = $finder->getEntryBundleIds();
    if (!in_array($bundle, $finder_entry_bundles)) {
      return;
    }

    $finder_type = $finder->getFinderTypePlugin();

    if ($finder_type->getPluginId() != 'events') {
      return;
    }

    // It's fine to zap the original label, as it comes from our code anyway:
    // it's not admin-set text.
    $form['fields'][Events::EVENT_DATE_FIELD]['human_name']['#plain_text'] = $this->t('Event recurring date');
    $form['fields'][Events::EVENT_DATE_OCCURRENCE_FIELD]['human_name']['#plain_text'] = $this->t('Date occurrence computed field');
  }

}
