<?php

declare(strict_types=1);

namespace Drupal\finders_events\Hook;

use Drupal\Core\Entity\EntityTypeManagerInterface;
use Drupal\Core\Hook\Attribute\Hook;
use Drupal\finders_events\Plugin\FinderType\Events;

/**
 * Contains Views hook implementations for the Finders Events module.
 */
class ViewsHooks {

  /**
   * The entity type manager.
   *
   * @var \Drupal\Core\Entity\EntityTypeManagerInterface
   */
  protected $entityTypeManager;

  /**
   * Creates a ViewsHooks instance.
   *
   * @param \Drupal\Core\Entity\EntityTypeManagerInterface $entity_type_manager
   *   The entity type manager.
   */
  public function __construct(
    EntityTypeManagerInterface $entity_type_manager,
  ) {
    $this->entityTypeManager = $entity_type_manager;
  }

  /**
   * Implements hook_views_data_alter().
   */
  #[Hook('views_data_alter')]
  public function viewsDataAlter(array &$data) {
    // Workaround for bug in SearchAPI.
    // @todo Remove this when https://www.drupal.org/project/search_api/issues/3591122
    // is fixed.
    // Get event and event-ish finders.
    $finders =  $this->entityTypeManager->getStorage('finder')->loadMultiple();
    $event_finders = array_filter($finders, fn ($finder) => $finder->getFinderTypePlugin() instanceof Events);
    $handled_index_ids = [];

    foreach ($event_finders as $finder) {
      $finder_type_plugin = $finder->getFinderTypePlugin();
      foreach ($finder_type_plugin->getIndexIds() as $index_id) {
        // Bail if we've already done this index: multiple finders might share
        // it.
        if (isset($handled_index_ids[$index_id])) {
          continue;
        }

        // Construct the Views data key.
        // See \Drupal\search_api\Hook\SearchApiViewsHooks
        $views_data_key = 'search_api_index_' . $index_id;

        if (!isset($data[$views_data_key])) {
          continue;
        }

        $occurrence_field_name = $finder_type_plugin->getFinderTypeConstant('EVENT_DATE_OCCURRENCE_FIELD');

        if (!isset($data[$views_data_key][$occurrence_field_name])) {
          continue;
        }

        // Change the field handler to the SearchAPI date handler.
        $data[$views_data_key][$occurrence_field_name]['field']['id'] = 'search_api_date';

        $handled_index_ids[$index_id] = TRUE;
      }
    }
  }

}
