<?php

namespace Drupal\finders_events\Plugin\FindersFacetsType;

use Drupal\finders\Entity\FinderInterface;
use Drupal\finders_events\Plugin\FinderType\Events as FinderTypeEvents;
use Drupal\finders_facets\Attribute\FindersFacetsType;
use Drupal\finders_facets\Plugin\FindersFacetsType\FindersFacetsTypeBase;
use Drupal\search_api\IndexInterface;
use Drupal\views\ViewEntityInterface;

/**
 * Finders facets type for events.
 *
 * Events use a facet for each view, calendar and list. These use the same facet
 * url_alias, which means that we can show a block just for one facet, and have
 * the facet links control both view simultaneously.
 */
#[FindersFacetsType(
  id: 'events',
)]
class Events extends FindersFacetsTypeBase {

  /**
   * {@inheritdoc}
   */
  protected function getExtraViewFacetFilters(ViewEntityInterface $view, IndexInterface $index, FinderInterface $finder): array {
    return $this->loadDateOccurrenceFacet($view, $index, $finder);
  }

  /**
   * Gets the config values for the date occurrence facet filter.
   *
   * @param \Drupal\views\ViewEntityInterface $view
   *   The view on the given search index to add facets for.
   * @param \Drupal\search_api\IndexInterface $index
   *   The search index to add facets for.
   * @param \Drupal\finders\Entity\FinderInterface $finder
   *   The finder being configured.
   *
   * @return array
   *   The config values for the Views facet filter.
   */
  protected function loadDateOccurrenceFacet(ViewEntityInterface $view, IndexInterface $index, FinderInterface $finder): array {
    // There is no API we can call on Facets module to get this prefix
    // -- this is the same thing
    // facets_exposed_filters_views_data_alter() does.
    $facet_id = 'facets_' . FinderTypeEvents::EVENT_DATE_OCCURRENCE_FIELD;

    // Get the config template for the facet filter
    $config_values = \Drupal::service('finders.config_template_loader')->loadTemplateConfigValues(
      'views.view.snippet.finder_channel.filter.date_occurrence',
      'views.view.snippet.finder_channel.filter.date_occurrence',
      $finder->getFinderTypePlugin(),
      'finders_facets',
      [
        'BASE_TABLE' => $view->get('base_table'),
        'FIELD_ID' => $facet_id,
      ],
    );

    return [
      $facet_id => $config_values,
    ];
  }

}
