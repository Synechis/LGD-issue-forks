<?php

namespace Drupal\Tests\finders_events\Kernel;

use PHPUnit\Framework\Attributes\Group;
use PHPUnit\Framework\Attributes\RunTestsInSeparateProcesses;
use Drupal\KernelTests\KernelTestBase;

/**
 * Tests the events finder type plugin with facets.
 *
 * @group finders_events
 */
#[Group('finders_events')]
#[RunTestsInSeparateProcesses]
class EventFinderFacetsPluginTest extends KernelTestBase {

  /**
   * The entity type manager service.
   *
   * @var \Drupal\Core\Entity\EntityTypeManagerInterface
   */
  protected $entityTypeManager;

  /**
   * The modules to enable.
   *
   * @var array
   */
  protected static $modules = [
    'system',
    'user',
    'block',
    'views',
    'node',
    // We need field module for our workaround in
    // \Drupal\finders_events\Hooks\FindersEventsHooks::viewsData()
    'field',
    'finders',
    'search_api',
    'viewsreference',
    'datetime',
    'datetime_range',
    'calendar_view',
    'date_recur',
    'computed_field',
    'date_recur_search_api',
    'finders_events',
    'facets',
    'better_exposed_filters',
    'facets_exposed_filters',
    'finders_facets',
  ];

  /**
   * Disable config checking of the calendar view.
   *
   * The calendar_view module is missing config schema.
   *
   * @see https://www.drupal.org/project/calendar_view/issues/3488649
   *
   * @var array
   */
  protected static $configSchemaCheckerExclusions = [
    'views.view.finders_events_channel_calendar',
    // Finders Facet's facet processors don't have config schema.
    'facets.facet.finders_index_events_finders_events_channel_list_date',
    'facets.facet.finders_index_events_finders_events_channel_calendar_date',
  ];

  /**
   * {@inheritdoc}
   */
  protected function setUp(): void {
    parent::setUp();

    $this->installConfig('finders');

    $this->installEntitySchema('search_api_task');

    // We have to use the node entity type in this test rather than
    // entity_test_with_bundle because that makes the table name too long. See
    // https://www.drupal.org/project/date_recur/issues/3485912
    $this->installEntitySchema('node');

    $this->entityTypeManager = $this->container->get('entity_type.manager');
  }

  /**
   * Tests event finder type with facets.
   */
  public function testEventFinderTypeWithFacets() {
    // Create a channel bundle.
    $channel_bundle = $this->entityTypeManager->getStorage('node_type')->create([
      'type' => 'test_channel_bundle',
      'status' => TRUE,
    ]);
    $channel_bundle->save();

    // Create an entry bundle.
    $entry_bundle = $this->entityTypeManager->getStorage('node_type')->create([
      'type' => 'test_entry_bundle_one',
      'status' => TRUE,
    ]);
    $entry_bundle->save();
    $entry_bundle->save();

    $finder = $this->entityTypeManager->getStorage('finder')->create([
      'id' => 'test',
      'label' => 'Test',
      'type' => 'events',
      'channels' => [
        'node' => [
          'test_channel_bundle',
        ],
      ],
      'entries' => [
        'node' => [
          'test_entry_bundle_one',
        ],
      ],
    ]);
    $finder->save();

    // Enable facets on the finder.
    $finder->setThirdPartySetting(
      'finders_facets',
      'facets',
      TRUE
    );
    $finder->save();

    // The facet filters have been added to the channel view.
    $view = $this->entityTypeManager->getStorage('view')->load('finders_events_channel_list');
    $this->assertNotEmpty($view);

    $displays = $view->get('display');
    $filters = $displays['default']['display_options']['filters'];

    $this->assertArrayHasKey('search_api_fulltext', $filters, 'The channel view has the full text search filter.');
    $this->assertArrayHasKey('facets_finders_facets_filter', $filters, 'The channel view has the facet filter.');
    $this->assertArrayHasKey('facets_finders_events_date_occurrence', $filters, 'The channel view has the date occurrence facet filter.');

    // The facet filters have been added to the calendar view.
    $view = $this->entityTypeManager->getStorage('view')->load('finders_events_channel_calendar');
    $this->assertNotEmpty($view);

    $displays = $view->get('display');
    $filters = $displays['default']['display_options']['filters'];

    $this->assertArrayNotHasKey('search_api_fulltext', $filters, 'The calendar view does not have the full text search filter.');
    $this->assertArrayHasKey('facets_finders_facets_filter', $filters, 'The calendar view has the facet filter.');
    $this->assertArrayHasKey('facets_finders_events_date_occurrence', $filters, 'The calendar view has the date occurrence facet filter.');

    // No facet config entities have been created.
    $facets = $this->entityTypeManager->getStorage('facets_facet')->loadMultiple();
    $this->assertEmpty($facets);
  }

}
