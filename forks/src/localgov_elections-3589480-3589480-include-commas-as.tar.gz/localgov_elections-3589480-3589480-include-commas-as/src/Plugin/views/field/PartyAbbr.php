<?php

namespace Drupal\localgov_elections\Plugin\views\field;

use Drupal\views\Plugin\views\field\FieldPluginBase;
use Drupal\views\ResultRow;

/**
 * Field handler to flag the node type.
 *
 * @ViewsField("party_abbr")
 */
class PartyAbbr extends FieldPluginBase {

  /**
   * Leave empty to avoid a query on this field.
   */
  public function query(): void {

  }

  /**
   * Render function for the party_abbr field.
   *
   * @{inheritdoc}
   */
  public function render(ResultRow $values): string {

    // @todo Get rid
    return "IND";
  }

}
