# LocalGov Elections Reporting ONS Divisions 2024 (Boundary Source Provider)
## NOTE: This is **Deprecated** for all new installs use: LocalGov Elections - Configurable Provider

A key part of the module is the idea of boundary source providers. Given that there are many different ways to classify
election areas (wards, parishes, constituencies) and also change over time. This means we can't provide a one size fits
all solution.

See the [documentation](../../docs/index.md) for details on how to use this.

## Data Sources

The data for ONS Divisions 2024 plugin is provided by the Office for National Statistics (ONS). The ONS provides various
types of geo-data through their Open Geography Portal https://geoportal.statistics.gov.uk/. The datasets we use for the
plugin are
1. [Ward to LAD to County to County Electoral Division (May 2024) Lookup for EN](https://open-geography-portalx-ons.hub.arcgis.com/datasets/ons::ward-to-lad-to-county-to-county-electoral-division-may-2024-lookup-for-en/explore). This dataset provides data for English County Division codes and names and can be filtered by County and District.
2. [County Electoral Division (May 2023) Boundaries EN BFE](https://geoportal.statistics.gov.uk/datasets/ons::county-electoral-division-may-2023-boundaries-en-bfe-2/explore?showTable=true). This dataset provides the boundary data for English County Divisions.


We also link to two different datasest in the plugin form which is used to help the user find the correct Local Authority
District Code and County Council Code for when specifying their electoral area. These datasets are
titled "[Local Authority Districts (April 2023) Names and Codes in the United Kingdom](https://geoportal.statistics.gov.uk/datasets/ons::local-authority-districts-april-2023-names-and-codes-in-the-uk/explore)" and "[Counties (December 2024) Names and Codes in EN](https://geoportal.statistics.gov.uk/datasets/ons::counties-december-2024-names-and-codes-in-en/explore)".

## Boundary Fetching Process

The boundary fetching process used by the ONS Divisions 2024 Plugin is fairly simple and can be described in a few steps:

1. Get the County Code (and optionally the Local Authority District Code) on the plugin configuration form. This limits the fetched boundaries to a
   specific area. The plugin form validates the county code (and district code) is valid, so you can't just enter anything here.
2. The user press saves and a boundary source entity is saved with a reference to the plugin.
3. The user is able to select the source entity from the boundary fetch form which is linked to from the election node.
4. The plugin presents a subform which shows all the individual areas in the electoral county (specified by the
   county code and optional distrct code).
5. The user selects the areas they want and then clicks submit. The areas are then downloaded to area vote nodes with
   the boundary data attached.
