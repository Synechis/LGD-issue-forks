#  LocalGov Elections Reporting Demo module

This module provides default election content making it easier for people to test the LocalGov Elections Reporting
module. It includes three elections:

- **Sutton Borough Election May 2022** — a full set of real local election results from the London Borough of Sutton,
  featuring 20 wards with a mix of two-seat and three-seat areas, ward boundary data, and electorate figures, and 2 election notices.
- **General Election July 2024** — a dummy single-seat parliamentary election in the Oxfordshire area, with fictional
  candidate names and randomly generated results.
- **Local Government Elections 2025** — a dummy multi-seat local election in the Oxford area, with fictional candidate
  names and randomly generated results.

## Updating demo content

Demo content can up updated by enabling this module, making the desired changes, exporting the content and then
adjusting the YAML to deal with a complexity in how paragraph content is handled.

To export the latest changes run:

```shell
drush default-content:export-module localgov_elections_demo_content
```

You'll then need to go through all the YAML files in the `content\node` directory and delete the
`localgov_election_winner` field configuration. This is because Default Content creates paragraph content in the node
export files and so contains duplicate paragraphs with the same UUID.
