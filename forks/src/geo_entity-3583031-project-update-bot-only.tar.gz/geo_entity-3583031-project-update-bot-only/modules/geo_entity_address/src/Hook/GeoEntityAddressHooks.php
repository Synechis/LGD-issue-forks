<?php

namespace Drupal\geo_entity_address\Hook;

use Drupal\Core\Hook\Attribute\Hook;

/**
 * Hook implementations for geo_entity_address.
 */
class GeoEntityAddressHooks {
  /**
   * @file
   * Provides a geo entity address type.
   */

  /**
   * Implements hook_theme().
   */
  #[Hook('theme')]
  public function theme($existing, $type, $theme, $path) {
    return [
      'geo_entity__address__embed' => [
        'template' => 'geo-entity--address--embed',
        'base hook' => 'geo_entity',
      ],
    ];
  }

}
