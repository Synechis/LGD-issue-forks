<?php

namespace Drupal\geo_entity\Hook;

use Drupal\Component\Utility\Html;
use Drupal\views\ViewExecutable;
use Drupal\Core\Form\FormStateInterface;
use Drupal\Core\Hook\Attribute\Hook;

/**
 * Hook implementations for geo_entity.
 */
class GeoEntityHooks {

  /**
   * Implements hook_theme().
   */
  #[Hook('theme')]
  public function theme() {
    return [
      'geo_entity' => [
        'render element' => 'elements',
      ],
    ];
  }

  /**
   * Implements hook_field_widget_complete_WIDGET_TYPE_form_alter().
   */
  #[Hook('field_widget_complete_entity_browser_entity_reference_form_alter')]
  public function fieldWidgetCompleteEntityBrowserEntityReferenceFormAlter(&$field_widget_complete_form, FormStateInterface $form_state, $context) {
    if ($context['widget']->getSetting('entity_browser') == 'geo_entity_library') {
      $field_widget_complete_form['#attached']['library'][] = 'geo_entity/geobrowser';
      $field_widget_complete_form['#attributes']['class'][] = 'geo-entity-geobrowser';
    }
  }

  /**
   * Implements hook_theme_suggestions_HOOK().
   */
  #[Hook('theme_suggestions_geo_entity')]
  public function themeSuggestionsGeoEntity(array $variables) {
    $suggestions = [];
    $geo = $variables['elements']['#geo_entity'];
    $sanitized_view_mode = strtr($variables['elements']['#view_mode'], '.', '_');
    $suggestions[] = 'geo_entity__' . $sanitized_view_mode;
    $suggestions[] = 'geo_entity__' . $geo->bundle();
    $suggestions[] = 'geo_entity__' . $geo->bundle() . '__' . $sanitized_view_mode;
    return $suggestions;
  }

  /**
   * Implements hook_form_FORM_ID_alter().
   *
   * This removes entity forms if the bundle is not enabled for the field.
   * There are a few patches in the issue queue to remove the need to do this.
   * The most promising:
   *   https://www.drupal.org/project/entity_browser/issues/2765295
   */
  #[Hook('form_entity_browser_geo_entity_library_form_alter')]
  public function formEntityBrowserGeoEntityLibraryFormAlter(&$form, FormStateInterface $form_state, $form_id) {
    $storage = $form_state->getStorage();
    $bundles = $storage['entity_browser']['widget_context']['target_bundles'];
    // UUIDs are defined by the configuration we're installing.
    // @see config/install/entity_browser.browser.geo_entity_library.yml
    if (!array_key_exists('address', $bundles)) {
      unset($form['widget_selector']['tab_selector_3edf0a0f-cb61-4324-8d36-1898e23a16ed']);
    }
    if (!array_key_exists('area', $bundles)) {
      unset($form['widget_selector']['tab_selector_beda8d11-9000-4069-95e7-dbb4282941db']);
    }
  }

  /**
   * Implements hook_views_pre_render().
   */
  #[Hook('views_pre_render')]
  public function viewsPreRender(ViewExecutable $view) {
    if ($view->id() == 'geo_entity_library') {
      $view->element['#attached']['library'][] = 'geo_entity/geobrowser';
    }
  }

  /**
   * Implements hook_geofield_map_latlon_element_alter().
   *
   * Adds JS event handler to Geofield Map lon lat fields for geocoder.
   */
  #[Hook('geofield_map_latlon_element_alter')]
  public function geofieldMapLatlonElementAlter(array &$map_settings, array &$complete_form, array &$form_state_values) {
    $complete_form['#attached']['library'][] = 'geo_entity/geocode-geofield';
    $complete_form['#attached']['drupalSettings']['geoEntityGeocode']['geofield'][$complete_form['#id']] = [
      'lon' => $map_settings['lngid'],
      'lat' => $map_settings['latid'],
    ];
  }

  /**
   * Implements hook_field_widget_single_element_WIDGET_TYPE_form_alter().
   *
   * Adds JS event handler to Leaflet fields for geocoder.
   */
  #[Hook('field_widget_single_element_leaflet_widget_default_form_alter')]
  public function fieldWidgetSingleElementLeafletWidgetDefaultFormAlter(&$element, FormStateInterface $form_state, $context) {
    $element['map']['#attached']['drupalSettings']['geoEntityGeocode']['leaflet'][Html::getId($form_state->getFormObject()->getFormId())] = $element['map']['#map_id'];
    $element['map']['#attached']['library'][] = 'geo_entity/geocode-leaflet';
  }

}
