<?php

namespace Drupal\finders_events\Plugin\FindersFacetsType;

use Drupal\Core\Config\FileStorage as ConfigFileStorage;
use Drupal\facets\FacetInterface;
use Drupal\finders\Entity\FinderInterface;
use Drupal\finders_facets\Attribute\FindersFacetsType;
use Drupal\finders_facets\Plugin\FindersFacetsType\FindersFacetsTypeBase;
use Drupal\search_api\IndexInterface;
use Drupal\views\ViewEntityInterface;

/**
 * Finders facets type for events.
 *
 * Events use a facet for each view, calendar and list. These use the same facet
 * url_alias, which means that we can show a block just for one facet, and have
 * the facet links control both view simultaneously.
 */
#[FindersFacetsType(
  id: 'events',
)]
class Events extends FindersFacetsTypeBase {

  /**
   * {@inheritdoc}
   */
  protected function ensureViewFacets(FinderInterface $finder, IndexInterface $index, ViewEntityInterface $view): array {
    // Add a facet for the date occurrence field.
    $facet_storage = $this->entityTypeManager->getStorage('facets_facet');

    $facet_id = $index->id() . '_' . $view->id() . '_date';
    $date_occurrence_facet = $facet_storage->load($facet_id);
    if (!$date_occurrence_facet) {
      $date_occurrence_facet = $this->loadDateOccurrenceFacet($facet_id, $finder, $index, $view);
      $date_occurrence_facet->save();
    }

    return [
      $date_occurrence_facet,
    ];
  }

  /**
   * Creates a facet for the date occurrence from the config template file.
   *
   * @param string $facet_id
   *   The ID of the facet to create.
   * @param \Drupal\finders\Entity\FinderInterface $finder
   *   The finder being configured.
   * @param \Drupal\search_api\IndexInterface $index
   *   The search index to add facets for.
   * @param \Drupal\views\ViewEntityInterface $view
   *   The view on the given search index to add facets for.
   *
   * @return \Drupal\facets\FacetInterface
   *   The facet entity. It is the caller's responsibility to save this.
   */
  protected function loadDateOccurrenceFacet(string $facet_id, FinderInterface $finder, IndexInterface $index, ViewEntityInterface $view): FacetInterface {
    // Get the config template for the facet.
    $template_directory = $this->moduleExtensionList->getPath('finders_events') . '/config/template';
    $config_source = new ConfigFileStorage($template_directory);
    $config_filename = 'facets.facet.finders_facets_date_occurrence_template';
    $facet_values = $config_source->read($config_filename);

    $facet_values['id'] = $facet_id;
    $facet_values['name'] = 'Finders - ' . $finder->label() . ' - ' . $view->id() . ' - ' . 'Date occurrence';

    $replacements = [
      'FACET_ID' => $facet_id,
      'INDEX_ID' => $index->id(),
      'VIEW_ID' => $view->id(),
      'DISPLAY_ID' => 'channel_embed',
    ];

    $this->replaceConfigValuesPlaceholders($facet_values, $replacements);

    $facet_storage = $this->entityTypeManager->getStorage('facets_facet');
    $facet = $facet_storage->create($facet_values);
    return $facet;
  }

  /**
   * {@inheritdoc}
   */
  protected function ensureFacetBlock(FacetInterface $facet, FinderInterface $finder, IndexInterface $index, ViewEntityInterface $view): void {
    // Don't create a facet block for a facet on the calendar view. Facet block
    // for the list view will control both views.
    if ($view->id() == 'finders_events_channel_calendar') {
      return;
    }

    parent::ensureFacetBlock($facet, $finder, $index, $view);
  }

}
