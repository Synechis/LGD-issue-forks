<?php

namespace Drupal\Tests\finders_events\Kernel;

use Drupal\KernelTests\KernelTestBase;

/**
 * Tests the events finder type plugin with facets.
 *
 * @group finders_events
 */
class EventFinderFacetsPluginTest extends KernelTestBase {

  /**
   * The entity type manager service.
   *
   * @var \Drupal\Core\Entity\EntityTypeManagerInterface
   */
  protected $entityTypeManager;

  /**
   * The modules to enable.
   *
   * @var array
   */
  protected static $modules = [
    'system',
    'user',
    'block',
    'views',
    'node',
    // We need field module for our workaround in
    // \Drupal\finders_events\Hooks\FindersEventsHooks::viewsData()
    'field',
    'finders',
    'search_api',
    'viewsreference',
    'datetime',
    'datetime_range',
    'calendar_view',
    'date_recur',
    'computed_field',
    'date_recur_search_api',
    'finders_events',
    'facets',
    'finders_facets',
  ];

  /**
   * Disable config checking of the calendar view.
   *
   * The calendar_view module is missing config schema.
   *
   * @see https://www.drupal.org/project/calendar_view/issues/3488649
   *
   * @var array
   */
  protected static $configSchemaCheckerExclusions = [
    'views.view.finders_events_channel_calendar',
    // Finders Facet's facet processors don't have config schema.
    'facets.facet.finders_index_events_finders_events_channel_list_date',
    'facets.facet.finders_index_events_finders_events_channel_calendar_date',
  ];

  /**
   * {@inheritdoc}
   */
  protected function setUp(): void {
    parent::setUp();

    parent::setUp();

    $this->installConfig('finders');

    $this->installEntitySchema('search_api_task');

    // We have to use the node entity type in this test rather than
    // entity_test_with_bundle because that makes the table name too long. See
    // https://www.drupal.org/project/date_recur/issues/3485912
    $this->installEntitySchema('node');

    $this->entityTypeManager = $this->container->get('entity_type.manager');
  }

  /**
   * Tests event finder type with facets
   */
  public function testEventFinderTypeWithFacets() {
    // Create a channel bundle.
    $channel_bundle = $this->entityTypeManager->getStorage('node_type')->create([
      'type' => 'test_channel_bundle',
      'status' => TRUE,
    ]);
    $channel_bundle->save();

    // Create an entry bundle.
    $entry_bundle = $this->entityTypeManager->getStorage('node_type')->create([
      'type' => 'test_entry_bundle_one',
      'status' => TRUE,
    ]);
    $entry_bundle->save();
    $entry_bundle->save();

    $finder = $this->entityTypeManager->getStorage('finder')->create([
      'id' => 'test',
      'label' => 'Test',
      'type' => 'events',
      'channels' => [
        'node' => [
          'test_channel_bundle',
        ],
      ],
      'entries' => [
        'node' => [
          'test_entry_bundle_one',
        ],
      ],
    ]);
    $finder->save();

    // Enable facets on the finder.
    $finder->setThirdPartySetting(
      'finders_facets',
      'facets',
      TRUE
    );
    $finder->save();

    // The date occurrence facets have been created for both list and calendar
    // views.
    $facet = $this->entityTypeManager->getStorage('facets_facet')->load('finders_index_events_finders_events_channel_list_date');
    $this->assertNotEmpty($facet);
    $facet = $this->entityTypeManager->getStorage('facets_facet')->load('finders_index_events_finders_events_channel_calendar_date');
    $this->assertNotEmpty($facet);

    // A block exists for the occurrence date on the list view.
    $block = $this->entityTypeManager->getStorage('block')->load('finders_facets_finders_index_events_finders_events_channel_list_date');
    $this->assertNotEmpty($block);
  }

}
