<?php

declare(strict_types=1);

namespace Drupal\localgov_media_document\Hook;

use Drupal\Core\Entity\EntityTypeManagerInterface;
use Drupal\Core\Hook\Attribute\Hook;
use Drupal\localgov_roles\RolesHelper;

/**
 * Hook implementations for LocalGov Media Document.
 */
class RolesHooks {

  /**
   * Constructs the hook implementations.
   *
   * @param \Drupal\Core\Entity\EntityTypeManagerInterface $entityTypeManager
   *   The entity type manager.
   */
  public function __construct(protected EntityTypeManagerInterface $entityTypeManager) {}

  /**
   * Implements hook_localgov_roles_default().
   *
   * Carried forward from localgov_media 3.3.0.
   *
   * @return array
   *   Permissions keyed by role.
   */
  #[Hook('localgov_roles_default')]
  public function localgovRolesDefault(): array {
    if (!$this->entityTypeManager->getStorage('media_type')->load('document')) {
      return [];
    }
    $common = [
      'create document media',
      'delete own document media',
      'edit any document media',
      'edit own document media',
    ];
    return [
      RolesHelper::AUTHOR_ROLE => $common,
      RolesHelper::CONTRIBUTOR_ROLE => $common,
      RolesHelper::EDITOR_ROLE => array_merge($common, ['delete any document media']),
    ];
  }

}
