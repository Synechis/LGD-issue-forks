<?php

declare(strict_types=1);

namespace Drupal\Tests\localgov_media_legacy\Kernel;

use Drupal\image\Entity\ImageStyle;
use Drupal\KernelTests\KernelTestBase;
use Drupal\responsive_image\Entity\ResponsiveImageStyle;
use PHPUnit\Framework\Attributes\Group;
use PHPUnit\Framework\Attributes\RunTestsInSeparateProcesses;

/**
 * Tests the move of the pre-3.4 breakpoint group to localgov_media_legacy.
 *
 * @group localgov_media
 */
#[Group('localgov_media')]
#[RunTestsInSeparateProcesses]
class LegacyBreakpointsTest extends KernelTestBase {

  /**
   * {@inheritdoc}
   */
  protected static $modules = [
    'system',
    'user',
    'field',
    'file',
    'image',
    'media',
    'breakpoint',
    'responsive_image',
    'localgov_media',
  ];

  /**
   * The pre-3.4 breakpoint ids, as a site built before 3.4 has them.
   */
  const BREAKPOINTS = [
    'localgov_media.bootstrap4_xl_1200px',
    'localgov_media.bootstrap4_md_768px',
    'localgov_media.bootstrap4_xs',
  ];

  /**
   * {@inheritdoc}
   */
  protected function setUp(): void {
    parent::setUp();
    $this->installEntitySchema('user');
    $this->installEntitySchema('file');
    $this->installEntitySchema('media');
    $this->installConfig(['system', 'image']);
    foreach (['banner_large', 'banner_medium', 'banner_small', 'other'] as $id) {
      ImageStyle::create(['name' => $id, 'label' => $id])->save();
    }
  }

  /**
   * Creates a responsive image style on a breakpoint group.
   *
   * @param string $id
   *   The style id.
   * @param string $group
   *   The breakpoint group.
   * @param string[] $breakpoints
   *   The breakpoint ids, largest first.
   */
  protected function createStyle(string $id, string $group, array $breakpoints): ResponsiveImageStyle {
    $style = ResponsiveImageStyle::create([
      'id' => $id,
      'label' => $id,
      'breakpoint_group' => $group,
      'fallback_image_style' => 'banner_small',
    ]);
    foreach (array_combine($breakpoints, ['banner_large', 'banner_medium', 'banner_small']) as $breakpoint => $image_style) {
      $style->addImageStyleMapping($breakpoint, '1x', [
        'image_mapping_type' => 'image_style',
        'image_mapping' => $image_style,
      ]);
    }
    $style->save();
    return $style;
  }

  /**
   * Tests that installing the module repoints styles on the old group.
   */
  public function testInstallRepointsResponsiveImageStyles(): void {
    $this->createStyle('banner_28_9', 'localgov_media', self::BREAKPOINTS);
    $this->createStyle('untouched', 'responsive_image', [
      'responsive_image.viewport_sizing',
      'responsive_image.viewport_sizing',
      'responsive_image.viewport_sizing',
    ]);
    $before = ResponsiveImageStyle::load('untouched')->toArray();

    \Drupal::service('module_installer')->install(['localgov_media_legacy']);

    $style = ResponsiveImageStyle::load('banner_28_9');
    $this->assertSame('localgov_media_legacy', $style->getBreakpointGroup());
    $mappings = $style->getKeyedImageStyleMappings();
    $this->assertSame([
      'localgov_media_legacy.bootstrap4_xl_1200px',
      'localgov_media_legacy.bootstrap4_md_768px',
      'localgov_media_legacy.bootstrap4_xs',
    ], array_keys($mappings), 'Every mapping moved to the legacy group');
    $this->assertSame('banner_large', $mappings['localgov_media_legacy.bootstrap4_xl_1200px']['1x']['image_mapping']);
    $this->assertSame('banner_small', $mappings['localgov_media_legacy.bootstrap4_xs']['1x']['image_mapping']);
    $this->assertSame('banner_small', $style->getFallbackImageStyle());

    $breakpoints = \Drupal::service('breakpoint.manager')->getBreakpointsByGroup('localgov_media_legacy');
    $this->assertSame([
      '(min-width: 0)',
      '(min-width: 576px)',
      '(min-width: 768px)',
      '(min-width: 992px)',
      'screen and (min-width: 1200px)',
    ], array_values(array_map(fn($b) => $b->getMediaQuery(), $breakpoints)), 'The legacy group carries the pre-3.4 media queries');

    $this->assertSame($before, ResponsiveImageStyle::load('untouched')->toArray(), 'A style on another group is left alone');
  }

  /**
   * Tests the update that installs the module on an existing site.
   */
  public function testUpdateInstallsLegacyModule(): void {
    $this->createStyle('banner_28_9', 'localgov_media', self::BREAKPOINTS);
    \Drupal::moduleHandler()->loadInclude('localgov_media', 'install');

    $message = localgov_media_update_10002();
    $this->assertTrue(\Drupal::moduleHandler()->moduleExists('localgov_media_legacy'));
    $this->assertStringContainsString('Installed LocalGov Media Legacy', $message);
    $this->assertSame('localgov_media_legacy', ResponsiveImageStyle::load('banner_28_9')->getBreakpointGroup());

    $this->assertStringContainsString('already installed', localgov_media_update_10002(), 'Running it again is harmless');
  }

}
