<?php

declare(strict_types=1);

namespace Drupal\localgov_media;

use Drupal\Core\Entity\EntityTypeManagerInterface;
use Drupal\Core\Extension\ModuleExtensionList;
use Drupal\Core\Extension\Requirement\RequirementSeverity;
use Drupal\Core\StringTranslation\StringTranslationTrait;

/**
 * Reports crop data belonging to the crop tool this site does not use.
 *
 * Configuration import and restored databases can both produce it, and neither
 * tool renders the other's crops.
 */
class CropDataReport {

  use StringTranslationTrait;

  public function __construct(
    protected EntityTypeManagerInterface $entityTypeManager,
    protected ModuleExtensionList $moduleList,
    protected CropTools $cropTools,
  ) {}

  /**
   * Returns the status report entry, or an empty array when there is none.
   *
   * @return array
   *   A requirements array.
   */
  public function requirements(): array {
    $applied = $this->cropTools->applied();
    if ($applied === NULL || !$this->entityTypeManager->hasDefinition('crop')) {
      return [];
    }
    $counts = [];
    foreach ($this->foreignCropTypes($applied) as $tool => $types) {
      foreach ($types as $type) {
        $count = (int) $this->entityTypeManager->getStorage('crop')->getQuery()
          ->accessCheck(FALSE)
          ->condition('type', $type)
          ->count()
          ->execute();
        if ($count > 0) {
          $counts[$tool] = ($counts[$tool] ?? 0) + $count;
        }
      }
    }
    if (!$counts) {
      return [];
    }
    $described = [];
    foreach ($counts as $tool => $count) {
      $described[] = $this->formatPlural($count, '1 crop set with @tool', '@count crops set with @tool', [
        '@tool' => $this->cropTools->name($tool),
      ]);
    }
    return [
      'localgov_media_crop_data' => [
        'title' => $this->t('LocalGov Media crop data'),
        'value' => $this->t('@counts', ['@counts' => implode(', ', array_map('strval', $described))]),
        'description' => $this->t('This site crops with @tool, and a crop set with the other tool is not rendered by it: those images are framed by something the editor cannot see or change. The crops came from a configuration import or a restored database; moving them is a migration.', [
          '@tool' => $this->cropTools->name($applied),
        ]),
        'severity' => class_exists(RequirementSeverity::class) ? RequirementSeverity::Error : 2,
      ],
    ];
  }

  /**
   * Returns the crop types of every tool but the applied one.
   *
   * @return array[]
   *   Lists of crop type ids, keyed by tool.
   */
  protected function foreignCropTypes(string $applied): array {
    $types = [];
    foreach ($this->cropTools->tools() as $tool) {
      if ($tool === $applied) {
        continue;
      }
      foreach ($this->cropTools->toolModules($tool) as $module) {
        if (!$this->moduleList->exists($module)) {
          continue;
        }
        $path = $this->moduleList->getPath($module) . '/config/install';
        foreach (glob($path . '/crop.type.*.yml') ?: [] as $file) {
          $types[$tool][] = substr(basename($file, '.yml'), strlen('crop.type.'));
        }
      }
    }
    return $types;
  }

}
