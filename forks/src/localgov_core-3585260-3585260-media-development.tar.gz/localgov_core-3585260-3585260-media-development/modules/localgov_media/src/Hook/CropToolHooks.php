<?php

declare(strict_types=1);

namespace Drupal\localgov_media\Hook;

use Drupal\Core\Extension\Extension;
use Drupal\Core\Extension\ModuleHandlerInterface;
use Drupal\Core\Hook\Attribute\Hook;
use Drupal\localgov_media\CropTools;

/**
 * Hook implementations that run before there is a database connection.
 *
 * Core builds the module list to find the database driver, so
 * hook_system_info_alter() is invoked with no connection open. A hook class is
 * constructed with its services, so none of them can depend on the database.
 */
class CropToolHooks {

  /**
   * Constructs the hook implementations.
   *
   * @param \Drupal\Core\Extension\ModuleHandlerInterface $moduleHandler
   *   The module handler.
   * @param \Drupal\localgov_media\CropTools $cropTools
   *   The one-crop-tool-per-site rule.
   */
  public function __construct(
    protected ModuleHandlerInterface $moduleHandler,
    protected CropTools $cropTools,
  ) {}

  /**
   * Implements hook_system_info_alter().
   *
   * Gives the other crop tool a dependency that does not exist. Nothing here
   * may ask the module list for anything: it is the list being built.
   */
  #[Hook('system_info_alter')]
  public function systemInfoAlter(array &$info, Extension $file, string $type): void {
    if ($type !== 'module' || $this->cropTools->tool($file->getName()) === NULL) {
      return;
    }
    if ($this->moduleHandler->moduleExists($file->getName())) {
      return;
    }
    if ($this->cropTools->refusal([$file->getName()])) {
      $info['dependencies'][] = CropTools::ONE_PER_SITE;
    }
  }

}
