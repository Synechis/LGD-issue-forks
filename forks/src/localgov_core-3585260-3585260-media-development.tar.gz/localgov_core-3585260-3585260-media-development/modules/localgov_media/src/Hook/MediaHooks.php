<?php

declare(strict_types=1);

namespace Drupal\localgov_media\Hook;

use Drupal\Core\Config\ConfigInstallerInterface;
use Drupal\Core\Config\FileStorage;
use Drupal\Core\Extension\ModuleExtensionList;
use Drupal\Core\Extension\ModuleHandlerInterface;
use Drupal\Core\Hook\Attribute\Hook;
use Drupal\localgov_roles\RolesHelper;

/**
 * Hook implementations for LocalGov Media.
 */
class MediaHooks {

  /**
   * Modules whose optional configuration is installed on install.
   */
  const MODULES = [
    'localgov_media',
    'localgov_media_document',
    'localgov_media_video',
    'localgov_media_image_manual_crop',
    'localgov_media_image_focal_point',
    'localgov_media_image_optional_manual_crop',
    'localgov_media_image_optional_focal_point',
    'localgov_media_wysiwyg',
  ];

  /**
   * Constructs the hook implementations.
   *
   * @param \Drupal\Core\Config\ConfigInstallerInterface $configInstaller
   *   The config installer.
   * @param \Drupal\Core\Extension\ModuleHandlerInterface $moduleHandler
   *   The module handler.
   * @param \Drupal\Core\Extension\ModuleExtensionList $moduleList
   *   The module extension list.
   */
  public function __construct(
    protected ConfigInstallerInterface $configInstaller,
    protected ModuleHandlerInterface $moduleHandler,
    protected ModuleExtensionList $moduleList,
  ) {}

  /**
   * Implements hook_menu_links_discovered_alter().
   *
   * Carried forward from localgov_media 3.3.0.
   */
  #[Hook('menu_links_discovered_alter')]
  public function menuLinksDiscoveredAlter(&$links): void {
    unset($links['admin_toolbar_tools.extra_links:view.files']);
  }

  /**
   * Implements hook_modules_installed().
   *
   * Carried forward from localgov_media 3.3.0. Runs two passes so
   * cross-module dependencies resolve.
   */
  #[Hook('modules_installed')]
  public function modulesInstalled($modules, $is_syncing): void {
    if ($is_syncing || !array_intersect($modules, self::MODULES)) {
      return;
    }
    for ($pass = 0; $pass < 2; $pass++) {
      foreach (self::MODULES as $module) {
        if (!$this->moduleHandler->moduleExists($module)) {
          continue;
        }
        $path = $this->moduleList->getPath($module) . '/config/optional';
        if (is_dir($path)) {
          $this->configInstaller->installOptionalConfig(new FileStorage($path));
        }
      }
    }
  }

  /**
   * Implements hook_localgov_roles_default().
   *
   * Carried forward from localgov_media 3.3.0.
   *
   * @return array
   *   Permissions keyed by role.
   */
  #[Hook('localgov_roles_default')]
  public function localgovRolesDefault(): array {
    $author = [
      'access media overview',
      'create image media',
      'create media',
      'delete media',
      'delete own image media',
      'edit any image media',
      'edit own image media',
      'update media',
      'view own unpublished media',
    ];
    return [
      RolesHelper::AUTHOR_ROLE => $author,
      RolesHelper::CONTRIBUTOR_ROLE => $author,
      RolesHelper::EDITOR_ROLE => [
        'access media overview',
        'create image media',
        'create media',
        'delete any image media',
        'delete any media',
        'delete media',
        'delete own image media',
        'edit any image media',
        'edit own image media',
        'update any media',
        'update media',
        'view own unpublished media',
      ],
    ];
  }

}
