<?php

declare(strict_types=1);

namespace Drupal\localgov_media\Hook;

use Drupal\Core\Config\ConfigInstallerInterface;
use Drupal\Core\Config\FileStorage;
use Drupal\Core\Extension\ModuleExtensionList;
use Drupal\Core\Extension\ModuleHandlerInterface;
use Drupal\Core\Extension\ModuleInstallerInterface;
use Drupal\Core\Form\FormStateInterface;
use Drupal\Core\Hook\Attribute\Hook;
use Drupal\Core\Render\Element;
use Drupal\localgov_media\CropDataReport;
use Drupal\localgov_media\CropTools;
use Drupal\localgov_roles\RolesHelper;

/**
 * Hook implementations for LocalGov Media.
 */
class MediaHooks {

  /**
   * Modules whose optional configuration is installed on install.
   */
  const MODULES = [
    'localgov_media',
    'localgov_media_document',
    'localgov_media_video',
    'localgov_media_image',
    'localgov_media_image_optional',
    'localgov_media_wysiwyg',
  ];

  /**
   * Modules that create the responsive image styles other displays name.
   */
  const IMAGE_MODULES = [
    'localgov_media_image',
    'localgov_media_image_optional',
  ];

  /**
   * The optional aspect ratios, whose image styles come from a crop tool.
   */
  const OPTIONAL_RATIOS = 'localgov_media_image_optional';

  /**
   * Constructs the hook implementations.
   *
   * @param \Drupal\Core\Config\ConfigInstallerInterface $configInstaller
   *   The config installer.
   * @param \Drupal\Core\Extension\ModuleHandlerInterface $moduleHandler
   *   The module handler.
   * @param \Drupal\Core\Extension\ModuleInstallerInterface $moduleInstaller
   *   The module installer.
   * @param \Drupal\Core\Extension\ModuleExtensionList $moduleList
   *   The module extension list.
   * @param \Drupal\localgov_media\CropTools $cropTools
   *   The one-crop-tool-per-site rule.
   * @param \Drupal\localgov_media\CropDataReport $cropDataReport
   *   The crop data report.
   */
  public function __construct(
    protected ConfigInstallerInterface $configInstaller,
    protected ModuleHandlerInterface $moduleHandler,
    protected ModuleInstallerInterface $moduleInstaller,
    protected ModuleExtensionList $moduleList,
    protected CropTools $cropTools,
    protected CropDataReport $cropDataReport,
  ) {}

  /**
   * Implements hook_menu_links_discovered_alter().
   *
   * Carried forward from localgov_media 3.3.0.
   */
  #[Hook('menu_links_discovered_alter')]
  public function menuLinksDiscoveredAlter(&$links): void {
    unset($links['admin_toolbar_tools.extra_links:view.files']);
  }

  /**
   * Implements hook_modules_installed().
   *
   * Two passes, because core only re-examines optional configuration for the
   * modules it is told about. Crop tool modules are watched because the image
   * modules' optional configuration names their image styles.
   */
  #[Hook('modules_installed')]
  public function modulesInstalled($modules, $is_syncing): void {
    $watched = [...self::MODULES, ...$this->cropTools->modules()];
    if ($is_syncing || !array_intersect($modules, $watched)) {
      return;
    }
    $this->pairOptionalRatios();
    for ($pass = 0; $pass < 2; $pass++) {
      foreach (self::MODULES as $module) {
        if (!$this->moduleHandler->moduleExists($module)) {
          continue;
        }
        $path = $this->moduleList->getPath($module) . '/config/optional';
        if (is_dir($path)) {
          $this->configInstaller->installOptionalConfig(new FileStorage($path));
        }
      }
    }
    if (array_intersect($modules, self::IMAGE_MODULES)) {
      $this->configInstaller->installOptionalConfig(NULL, ['module' => 'localgov_breakpoints']);
    }
  }

  /**
   * Installs the optional aspect ratio styles of the installed crop tool.
   *
   * The ratios cannot be installed without their image styles.
   */
  protected function pairOptionalRatios(): void {
    $tool = $this->cropTools->applied();
    if ($tool === NULL || !$this->moduleHandler->moduleExists(self::OPTIONAL_RATIOS)) {
      return;
    }
    $module = $this->cropTools->moduleFor($tool, 'optional_ratios');
    if ($module === NULL || $this->moduleHandler->moduleExists($module)) {
      return;
    }
    $this->moduleInstaller->install([$module]);
  }

  /**
   * Implements hook_form_FORM_ID_alter() for system_modules.
   *
   * Replaces the missing dependency's name with the reason, and refuses both
   * tools ticked at once.
   */
  #[Hook('form_system_modules_alter')]
  public function formSystemModulesAlter(array &$form, FormStateInterface $form_state): void {
    foreach ($this->cropTools->modules() as $module) {
      foreach (Element::children($form['modules']) as $package) {
        if (isset($form['modules'][$package][$module]['#requires'][CropTools::ONE_PER_SITE])) {
          $form['modules'][$package][$module]['#requires'][CropTools::ONE_PER_SITE] = $this->cropTools->refusal([$module]);
        }
      }
    }
    $form['#validate'][] = [static::class, 'validateOneCropTool'];
  }

  /**
   * Refuses the Extend page form when it would install both crop tools.
   */
  public static function validateOneCropTool(array &$form, FormStateInterface $form_state): void {
    $crop_tools = \Drupal::service(CropTools::class);
    $ticked = array_filter(
      $crop_tools->modules(),
      fn(string $module) => !empty($form_state->getValue(['modules', $module, 'enable']))
    );
    if ($refusal = $crop_tools->refusal($ticked)) {
      foreach ($ticked as $module) {
        $form_state->setErrorByName("modules][$module][enable", $refusal);
      }
    }
  }

  /**
   * Implements hook_runtime_requirements().
   */
  #[Hook('runtime_requirements')]
  public function runtimeRequirements(): array {
    return $this->cropTools->requirements() + $this->cropDataReport->requirements();
  }

  /**
   * Implements hook_localgov_roles_default().
   *
   * Carried forward from localgov_media 3.3.0.
   *
   * @return array
   *   Permissions keyed by role.
   */
  #[Hook('localgov_roles_default')]
  public function localgovRolesDefault(): array {
    $author = [
      'access media overview',
      'create image media',
      'create media',
      'delete media',
      'delete own image media',
      'edit any image media',
      'edit own image media',
      'update media',
      'view own unpublished media',
    ];
    return [
      RolesHelper::AUTHOR_ROLE => $author,
      RolesHelper::CONTRIBUTOR_ROLE => $author,
      RolesHelper::EDITOR_ROLE => [
        'access media overview',
        'create image media',
        'create media',
        'delete any image media',
        'delete any media',
        'delete media',
        'delete own image media',
        'edit any image media',
        'edit own image media',
        'update any media',
        'update media',
        'view own unpublished media',
      ],
    ];
  }

}
