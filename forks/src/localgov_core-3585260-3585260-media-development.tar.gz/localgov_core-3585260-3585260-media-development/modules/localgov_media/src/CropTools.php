<?php

declare(strict_types=1);

namespace Drupal\localgov_media;

use Drupal\Core\Extension\ModuleHandlerInterface;
use Drupal\Core\Extension\Requirement\RequirementSeverity;
use Drupal\Core\StringTranslation\StringTranslationTrait;
use Drupal\Core\StringTranslation\TranslatableMarkup;

/**
 * One crop tool per site: manual crop or focal point, chosen at install.
 *
 * Core cannot declare that two modules conflict, so the other tool's modules
 * are given a dependency that does not exist: see
 * CropToolHooks::systemInfoAlter(). Configuration import does not check
 * dependencies; requirements() reports a site that ends up with both.
 */
class CropTools {

  /**
   * The dependency the other crop tool is given so it cannot be installed.
   */
  const ONE_PER_SITE = 'localgov_media_one_crop_tool_per_site';

  /**
   * The module whose image styles come from a crop tool.
   */
  const IMAGE_MODULE = 'localgov_media_image';

  use StringTranslationTrait;

  /**
   * Constructs the rule.
   *
   * @param \Drupal\Core\Extension\ModuleHandlerInterface $moduleHandler
   *   The module handler.
   * @param array $tools
   *   The localgov_media.crop_tools container parameter: each tool's modules,
   *   keyed by tool and then by part (widget, image, optional_ratios).
   */
  public function __construct(
    protected ModuleHandlerInterface $moduleHandler,
    protected array $tools,
  ) {}

  /**
   * Returns the tools.
   *
   * @return string[]
   *   Tool names: manual_crop and focal_point.
   */
  public function tools(): array {
    return array_keys($this->tools);
  }

  /**
   * Returns every module of every tool.
   *
   * @return string[]
   *   Module names.
   */
  public function modules(): array {
    return array_merge(...array_map('array_values', array_values($this->tools)));
  }

  /**
   * Returns the modules of a tool.
   *
   * @return string[]
   *   Module names.
   */
  public function toolModules(string $tool): array {
    return array_values($this->tools[$tool] ?? []);
  }

  /**
   * Returns a tool's module for one part, or NULL where it has none.
   *
   * @param string $tool
   *   The tool: manual_crop or focal_point.
   * @param string $part
   *   The part: widget, image or optional_ratios.
   *
   * @return string|null
   *   The module name.
   */
  public function moduleFor(string $tool, string $part): ?string {
    return $this->tools[$tool][$part] ?? NULL;
  }

  /**
   * Returns the tool a module belongs to, or NULL for any other module.
   */
  public function tool(string $module): ?string {
    foreach ($this->tools as $tool => $modules) {
      if (in_array($module, array_values($modules), TRUE)) {
        return $tool;
      }
    }
    return NULL;
  }

  /**
   * Returns the installed modules of each installed tool.
   *
   * @return array[]
   *   Lists of module names, keyed by tool. Tools with nothing installed are
   *   omitted.
   */
  public function installed(): array {
    $installed = [];
    foreach ($this->tools as $tool => $modules) {
      $present = array_values(array_filter(array_values($modules), $this->moduleHandler->moduleExists(...)));
      if ($present) {
        $installed[$tool] = $present;
      }
    }
    return $installed;
  }

  /**
   * Returns the site's crop tool, or NULL when neither or both are installed.
   */
  public function applied(): ?string {
    $installed = $this->installed();
    return count($installed) === 1 ? array_key_first($installed) : NULL;
  }

  /**
   * Returns a tool's name for a message.
   */
  public function name(string $tool): TranslatableMarkup {
    return match ($tool) {
      'manual_crop' => $this->t('manual crop'),
      'focal_point' => $this->t('focal point'),
      default => $this->t('@tool', ['@tool' => str_replace('_', ' ', $tool)]),
    };
  }

  /**
   * Returns why installing modules would break the rule, or NULL if not.
   *
   * @param string[] $modules
   *   The modules about to be installed.
   *
   * @return \Drupal\Core\StringTranslation\TranslatableMarkup|null
   *   The refusal.
   */
  public function refusal(array $modules): ?TranslatableMarkup {
    $installed = $this->installed();
    $new = [];
    foreach ($modules as $module) {
      $tool = $this->tool($module);
      if ($tool !== NULL && !isset($installed[$tool])) {
        $new[$tool] = $tool;
      }
    }
    if (!$new || count($installed) + count($new) < 2) {
      return NULL;
    }
    if (!$installed) {
      return $this->t('One crop tool per site: install manual crop (@manual) or focal point (@focal), not both.', [
        '@manual' => implode(', ', $this->toolModules('manual_crop')),
        '@focal' => implode(', ', $this->toolModules('focal_point')),
      ]);
    }
    return $this->t('One crop tool per site: this site crops with @tool (@modules). A site keeps the crop tool it was installed with; moving it to the other one is a migration, not a module install.', [
      '@tool' => $this->name(array_key_first($installed)),
      '@modules' => implode(', ', reset($installed)),
    ]);
  }

  /**
   * Returns the status report entries for the crop tools.
   *
   * @return array
   *   A requirements array: errors for both tools installed, and for
   *   localgov_media_image installed without one.
   */
  public function requirements(): array {
    $requirements = [];
    $installed = $this->installed();
    if (count($installed) > 1) {
      $requirements['localgov_media_crop_tools'] = [
        'title' => $this->t('LocalGov Media crop tools'),
        'value' => $this->t('Both installed: @modules', ['@modules' => implode(', ', array_merge(...array_values($installed)))]),
        'description' => $this->t("A site crops with one tool, manual crop or focal point. With both installed, editors can store crop data for either, and neither tool renders the other's. Uninstall the one this site does not use."),
        'severity' => $this->error(),
      ];
    }
    if (!$installed && $this->moduleHandler->moduleExists(self::IMAGE_MODULE)) {
      $requirements['localgov_media_crop_tool_missing'] = [
        'title' => $this->t('LocalGov Media crop tool'),
        'value' => $this->t('None installed'),
        'description' => $this->t('LocalGov Media Image (@module) ships the view modes, displays and responsive image styles; the image styles themselves come from a crop tool. Install @manual or @focal.', [
          '@module' => self::IMAGE_MODULE,
          '@manual' => implode(' and ', $this->toolModules('manual_crop')),
          '@focal' => implode(' and ', $this->toolModules('focal_point')),
        ]),
        'severity' => $this->error(),
      ];
    }
    return $requirements;
  }

  /**
   * The error severity. REQUIREMENT_ERROR needs install.inc, not always loaded.
   */
  protected function error(): int|object {
    return class_exists(RequirementSeverity::class) ? RequirementSeverity::Error : 2;
  }

}
