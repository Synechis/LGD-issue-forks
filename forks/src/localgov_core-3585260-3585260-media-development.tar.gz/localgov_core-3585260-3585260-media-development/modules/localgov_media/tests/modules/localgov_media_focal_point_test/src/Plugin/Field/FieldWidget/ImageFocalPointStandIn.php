<?php

declare(strict_types=1);

namespace Drupal\localgov_media_focal_point_test\Plugin\Field\FieldWidget;

use Drupal\Core\Field\Attribute\FieldWidget;
use Drupal\Core\StringTranslation\TranslatableMarkup;
use Drupal\image\Plugin\Field\FieldWidget\ImageWidget;

/**
 * Stands in for focal_point's widget: same id and settings, no picker.
 */
#[FieldWidget(
  id: 'image_focal_point',
  label: new TranslatableMarkup('Image focal point (stand-in)'),
  field_types: ['image'],
)]
class ImageFocalPointStandIn extends ImageWidget {

  /**
   * {@inheritdoc}
   */
  public static function defaultSettings() {
    return ['preview_link' => TRUE, 'offsets' => '50,50'] + parent::defaultSettings();
  }

}
