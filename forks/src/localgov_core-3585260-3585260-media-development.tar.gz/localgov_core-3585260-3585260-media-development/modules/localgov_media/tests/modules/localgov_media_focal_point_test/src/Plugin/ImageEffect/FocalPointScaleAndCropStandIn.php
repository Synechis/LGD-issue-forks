<?php

declare(strict_types=1);

namespace Drupal\localgov_media_focal_point_test\Plugin\ImageEffect;

use Drupal\Core\Image\ImageInterface;
use Drupal\image\Attribute\ImageEffect;
use Drupal\image\Plugin\ImageEffect\ScaleAndCropImageEffect;
use Drupal\Core\StringTranslation\TranslatableMarkup;

/**
 * Stands in for focal_point's effect: same id and settings, centred crop.
 */
#[ImageEffect(
  id: 'focal_point_scale_and_crop',
  label: new TranslatableMarkup('Focal point scale and crop (stand-in)'),
)]
class FocalPointScaleAndCropStandIn extends ScaleAndCropImageEffect {

  /**
   * {@inheritdoc}
   */
  public function defaultConfiguration() {
    return ['width' => NULL, 'height' => NULL, 'crop_type' => 'focal_point'];
  }

  /**
   * {@inheritdoc}
   */
  public function applyEffect(ImageInterface $image) {
    return $image->scaleAndCrop($this->configuration['width'], $this->configuration['height']);
  }

}
