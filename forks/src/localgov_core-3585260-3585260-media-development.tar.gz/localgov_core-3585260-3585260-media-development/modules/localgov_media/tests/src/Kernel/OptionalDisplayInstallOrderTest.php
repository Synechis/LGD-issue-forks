<?php

declare(strict_types=1);

namespace Drupal\Tests\localgov_media\Kernel;

use Drupal\KernelTests\KernelTestBase;
use PHPUnit\Framework\Attributes\Group;
use PHPUnit\Framework\Attributes\RunTestsInSeparateProcesses;

/**
 * Tests optional displays that other modules ship on LocalGov image styles.
 *
 * Consumer modules ship displays naming a responsive image style that
 * localgov_media_image creates once a crop tool is installed. Either install
 * order must end with the display existing.
 *
 * @group localgov_media
 */
#[Group('localgov_media')]
#[RunTestsInSeparateProcesses]
class OptionalDisplayInstallOrderTest extends KernelTestBase {

  /**
   * {@inheritdoc}
   */
  protected static $modules = [
    'system',
    'user',
    'field',
    'file',
    'path',
    'image',
    'media',
    'crop',
    'breakpoint',
    'responsive_image',
    'localgov_breakpoints',
    'localgov_media',
  ];

  /**
   * {@inheritdoc}
   */
  protected function setUp(): void {
    parent::setUp();
    $this->installEntitySchema('user');
    $this->installEntitySchema('file');
    $this->installEntitySchema('crop');
    $this->installEntitySchema('media');
    $this->installSchema('user', ['users_data']);
    $this->installConfig(['system', 'field', 'image', 'media']);
  }

  /**
   * Tests a consumer module installed after the crop tool.
   */
  public function testConsumerAfterImageModule(): void {
    \Drupal::service('module_installer')->install(['localgov_media_image_manual_crop']);
    \Drupal::service('module_installer')->install(['localgov_media_display_test']);
    $this->assertDisplayExists();
  }

  /**
   * Tests a consumer module installed before the crop tool.
   */
  public function testConsumerBeforeImageModule(): void {
    \Drupal::service('module_installer')->install(['localgov_media_display_test']);
    $this->assertNull(
      \Drupal::entityTypeManager()->getStorage('entity_view_display')->load('media.image.display_test'),
      'The display waits for the responsive image style it names'
    );
    \Drupal::service('module_installer')->install(['localgov_media_image_manual_crop']);
    $this->assertDisplayExists();
  }

  /**
   * Asserts the test module's display exists and names an existing style.
   */
  protected function assertDisplayExists(): void {
    $display = \Drupal::entityTypeManager()->getStorage('entity_view_display')->load('media.image.display_test');
    $this->assertNotNull($display);
    $style = $display->getComponent('field_media_image')['settings']['responsive_image_style'];
    $this->assertNotNull(\Drupal::entityTypeManager()->getStorage('responsive_image_style')->load($style));
  }

}
