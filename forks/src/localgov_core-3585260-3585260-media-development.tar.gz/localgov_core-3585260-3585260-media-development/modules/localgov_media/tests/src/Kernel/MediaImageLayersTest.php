<?php

declare(strict_types=1);

namespace Drupal\Tests\localgov_media\Kernel;

use Drupal\image\Entity\ImageStyle;
use Drupal\KernelTests\KernelTestBase;
use PHPUnit\Framework\Attributes\RunTestsInSeparateProcesses;

/**
 * Tests the image configuration installed by the crop tool modules.
 */
#[RunTestsInSeparateProcesses]
class MediaImageLayersTest extends KernelTestBase {

  /**
   * The default aspect ratios.
   */
  const RATIOS = ['21_9', '16_9', '4_3', '1_1', 'freestyle'];

  /**
   * The optional aspect ratios.
   */
  const OPTIONAL_RATIOS = ['3_2', '2_3', '3_4', '9_16'];

  /**
   * The sizes available to every aspect ratio.
   */
  const SIZES = ['small', 'medium', 'large'];

  /**
   * The aspect ratios that have the wide size.
   */
  const WIDE_RATIOS = ['21_9', '16_9'];

  /**
   * The file widths for the default sizes.
   */
  const WIDTHS = [384, 576, 768, 960, 1152, 1200, 1536, 1800, 2400];

  /**
   * The file widths the wide size adds.
   */
  const WIDE_WIDTHS = [1920, 2880, 3840];

  /**
   * The layout width of each size.
   */
  const LAYOUT = ['small' => 384, 'medium' => 768, 'large' => 1200, 'wide' => 1920];

  /**
   * The expected dimensions of each aspect ratio at each file width.
   */
  const HEIGHTS = [
    '21_9' => 9 / 21,
    '16_9' => 9 / 16,
    '4_3' => 3 / 4,
    '1_1' => 1.0,
  ];

  /**
   * {@inheritdoc}
   */
  protected static $modules = [
    'system',
    'user',
    'field',
    'file',
    'path',
    'image',
    'media',
    'crop',
    'breakpoint',
    'responsive_image',
    'localgov_breakpoints',
    'localgov_media',
  ];

  /**
   * {@inheritdoc}
   */
  protected function setUp(): void {
    parent::setUp();
    $this->installEntitySchema('user');
    $this->installEntitySchema('file');
    $this->installEntitySchema('crop');
    $this->installEntitySchema('media');
    $this->installSchema('user', ['users_data']);
    $this->installConfig(['system', 'field', 'image', 'media']);
    \Drupal::service('module_installer')->install(['localgov_media_document']);
  }

  /**
   * Installs a crop tool module.
   *
   * @param string $tool
   *   The crop tool, either manual_crop or focal_point.
   * @param bool $optional
   *   Whether to install the optional aspect ratios.
   */
  protected function installCropTool(string $tool = 'manual_crop', bool $optional = FALSE): void {
    $widget = $tool === 'manual_crop' ? 'image_widget_crop' : 'focal_point';
    $modules = [$widget, 'localgov_media_image_' . $tool];
    if ($optional) {
      $modules[] = 'localgov_media_image_optional_' . $tool;
    }
    \Drupal::service('module_installer')->install($modules);
  }

  /**
   * Returns the image style id for an aspect ratio at a file width.
   *
   * @param string $ratio
   *   The aspect ratio id.
   * @param int $width
   *   The file width.
   * @param string $tool
   *   The crop tool.
   *
   * @return string
   *   The image style id.
   */
  protected static function styleId(string $ratio, int $width, string $tool): string {
    return 'localgov_' . $ratio . '_' . $width . '_' . $tool;
  }

  /**
   * Returns the file widths for an aspect ratio.
   *
   * @param string $ratio
   *   The aspect ratio id.
   *
   * @return int[]
   *   The file widths, smallest first.
   */
  protected static function widths(string $ratio): array {
    $widths = self::WIDTHS;
    if (in_array($ratio, self::WIDE_RATIOS, TRUE)) {
      $widths = array_merge($widths, self::WIDE_WIDTHS);
    }
    sort($widths);
    return $widths;
  }

  /**
   * Returns the size ids for an aspect ratio.
   *
   * @param string $ratio
   *   The aspect ratio id.
   *
   * @return string[]
   *   The size ids.
   */
  protected static function sizes(string $ratio): array {
    $sizes = self::SIZES;
    if (in_array($ratio, self::WIDE_RATIOS, TRUE)) {
      $sizes[] = 'wide';
    }
    return $sizes;
  }

  /**
   * Tests that no image configuration is installed before a crop tool.
   */
  public function testNoConfigurationBeforeCropTool(): void {
    $etm = \Drupal::entityTypeManager();
    $this->assertCount(0, $etm->getStorage('crop_type')->loadMultiple(), 'No crop types');
    $this->assertCount(0, $etm->getStorage('responsive_image_style')->loadMultiple(), 'No responsive styles');
    foreach (self::RATIOS as $ratio) {
      foreach (self::widths($ratio) as $width) {
        $this->assertNull(ImageStyle::load(self::styleId($ratio, $width, 'manual_crop')));
        $this->assertNull(ImageStyle::load(self::styleId($ratio, $width, 'focal_point')));
      }
    }
  }

  /**
   * Tests the image styles installed by manual crop.
   */
  public function testCropToolImageStyles(): void {
    $this->installCropTool('manual_crop');

    $found = 0;
    foreach (self::RATIOS as $ratio) {
      foreach (self::widths($ratio) as $width) {
        $this->assertNotNull(
          ImageStyle::load(self::styleId($ratio, $width, 'manual_crop')),
          "$ratio at {$width}px is installed"
        );
        $this->assertNull(
          ImageStyle::load(self::styleId($ratio, $width, 'focal_point')),
          'The other crop tool is not'
        );
        $found++;
      }
    }
    $this->assertSame(51, $found, 'Nine widths for three shapes, twelve for the two wide ones');

    $widget = \Drupal::entityTypeManager()->getStorage('entity_form_display')
      ->load('media.image.default')
      ->getComponent('field_media_image');
    $this->assertSame('image_widget_crop', $widget['type'], 'The crop tool ships its own widget');
  }

  /**
   * Tests the image styles installed by focal point.
   */
  public function testFocalPointImageStyles(): void {
    $this->installCropTool('focal_point');

    foreach (self::RATIOS as $ratio) {
      foreach (self::widths($ratio) as $width) {
        $this->assertNotNull(ImageStyle::load(self::styleId($ratio, $width, 'focal_point')));
        $this->assertNull(ImageStyle::load(self::styleId($ratio, $width, 'manual_crop')));
      }
    }
    $widget = \Drupal::entityTypeManager()->getStorage('entity_form_display')
      ->load('media.image.default')
      ->getComponent('field_media_image');
    $this->assertSame('image_focal_point', $widget['type']);

    $teaser = \Drupal::entityTypeManager()->getStorage('entity_view_display')
      ->load('media.image.localgov_teaser')
      ->getComponent('field_media_image');
    $this->assertSame('localgov_16_9_384_focal_point', $teaser['settings']['image_style']);
  }

  /**
   * Tests the candidates of each responsive image style.
   */
  public function testResponsiveImageStyleCandidates(): void {
    $this->installCropTool('manual_crop');

    $storage = \Drupal::entityTypeManager()->getStorage('responsive_image_style');
    $checked = 0;
    foreach (self::RATIOS as $ratio) {
      foreach (self::sizes($ratio) as $size) {
        $id = 'localgov_' . $ratio . '_' . $size;
        $style = $storage->load($id);
        $this->assertNotNull($style, "Responsive style $id exists");

        $mappings = $style->getImageStyleMappings();
        $this->assertCount(1, $mappings, "$id has one mapping");
        $this->assertSame('sizes', $mappings[0]['image_mapping_type'], "$id uses the sizes mapping type");

        $ladder = array_values($mappings[0]['image_mapping']['sizes_image_styles']);
        $expected = array_map(
          fn(int $w) => self::styleId($ratio, $w, 'manual_crop'),
          self::widths($ratio)
        );
        $this->assertSame($expected, $ladder, "$id offers every width of its shape, in order");

        $this->assertStringContainsString(
          self::LAYOUT[$size] . 'px',
          $mappings[0]['image_mapping']['sizes'],
          "$id tells the browser the layout width, not a file width"
        );
        $checked++;
      }
    }
    $this->assertSame(17, $checked, 'Three sizes for every shape, and Wide for two of them');
  }

  /**
   * Tests that the wide size is limited to the wide aspect ratios.
   */
  public function testWideSizeRestrictedToWideRatios(): void {
    $this->installCropTool('manual_crop');
    $storage = \Drupal::entityTypeManager()->getStorage('responsive_image_style');

    foreach (self::WIDE_RATIOS as $ratio) {
      $this->assertNotNull($storage->load('localgov_' . $ratio . '_wide'));
      $this->assertNotNull(ImageStyle::load(self::styleId($ratio, 1920, 'manual_crop')));
      $this->assertNotNull(ImageStyle::load(self::styleId($ratio, 3840, 'manual_crop')));
    }
    foreach (array_diff(self::RATIOS, self::WIDE_RATIOS) as $ratio) {
      $this->assertNull($storage->load('localgov_' . $ratio . '_wide'), "$ratio has no Wide");
      $this->assertNull(ImageStyle::load(self::styleId($ratio, 1920, 'manual_crop')));
    }
  }

  /**
   * Tests the teaser display.
   */
  public function testTeaserDisplay(): void {
    $this->installCropTool('manual_crop');

    $display = \Drupal::entityTypeManager()->getStorage('entity_view_display')
      ->load('media.image.localgov_teaser');
    $this->assertNotNull($display, 'The teaser display exists');
    $component = $display->getComponent('field_media_image');
    $this->assertSame('image', $component['type'], 'One request per card, not a picture element');
    $this->assertSame('localgov_16_9_384_manual_crop', $component['settings']['image_style']);
    $this->assertArrayNotHasKey('responsive_image_style', $component['settings']);
  }

  /**
   * Tests the view modes and their displays.
   */
  public function testViewModeDisplays(): void {
    \Drupal::service('module_installer')->install(['localgov_media_video']);
    $this->installCropTool('manual_crop');

    $modes = \Drupal::entityTypeManager()->getStorage('entity_view_mode');
    $displays = \Drupal::entityTypeManager()->getStorage('entity_view_display');

    $ids = ['localgov_teaser'];
    foreach (self::RATIOS as $ratio) {
      foreach (self::sizes($ratio) as $size) {
        $ids[] = 'localgov_' . $ratio . '_' . $size;
      }
    }
    $this->assertCount(18, $ids, 'Seventeen pairings plus Teaser Default');

    foreach ($ids as $id) {
      $this->assertNotNull($modes->load('media.' . $id), "View mode $id exists");
      $this->assertStringNotContainsString('embed', $id, 'Nothing is called embed');
      foreach (['image', 'document', 'remote_video'] as $bundle) {
        $this->assertNotNull($displays->load("media.$bundle.$id"), "$id has a display on $bundle");
      }
    }
  }

  /**
   * Tests the view modes allowed in the WYSIWYG text format.
   */
  public function testWysiwygViewModes(): void {
    \Drupal::service('module_installer')->install([
      'filter',
      'editor',
      'ckeditor5',
      'media_library',
      'linkit',
      'localgov_media_wysiwyg',
    ]);
    $settings = \Drupal::config('filter.format.wysiwyg')->get('filters.media_embed.settings');
    $storage = \Drupal::entityTypeManager()->getStorage('entity_view_mode');

    $offered = array_keys($settings['allowed_view_modes']);
    $this->assertContains($settings['default_view_mode'], $offered, 'The default is offered');
    $this->assertCount(11, $offered, 'The default mode, plus small and medium for five shapes');
    foreach ($offered as $id) {
      if ($id === 'default') {
        continue;
      }
      $this->assertNotNull($storage->load('media.' . $id), "The format offers $id, which exists");
      $this->assertMatchesRegularExpression('/_(small|medium)$/', $id, "$id is a small or a medium");
    }
  }

  /**
   * Tests the optional aspect ratios.
   */
  public function testOptionalRatios(): void {
    $this->installCropTool('manual_crop');
    $before = $this->installedStyles();

    \Drupal::service('module_installer')->install(['localgov_media_image_optional_manual_crop']);

    $cropTypes = \Drupal::entityTypeManager()->getStorage('crop_type');
    $storage = \Drupal::entityTypeManager()->getStorage('responsive_image_style');
    foreach (self::OPTIONAL_RATIOS as $ratio) {
      $this->assertNotNull($cropTypes->load($ratio), "Optional crop type $ratio exists");
      foreach (self::SIZES as $size) {
        $this->assertNotNull($storage->load('localgov_' . $ratio . '_' . $size));
      }
      $this->assertNull($storage->load('localgov_' . $ratio . '_wide'), 'No Wide on an optional shape');
      foreach (self::WIDTHS as $width) {
        $this->assertNotNull(ImageStyle::load(self::styleId($ratio, $width, 'manual_crop')));
      }
    }
    $this->assertSame($before, $this->installedStyles(), 'The default set is untouched');
  }

  /**
   * Returns the installed image styles of the default set.
   *
   * @return string[]
   *   The image style ids.
   */
  protected function installedStyles(): array {
    $out = [];
    foreach (self::RATIOS as $ratio) {
      foreach (self::widths($ratio) as $width) {
        $id = self::styleId($ratio, $width, 'manual_crop');
        if (ImageStyle::load($id)) {
          $out[] = $id;
        }
      }
    }
    return $out;
  }

  /**
   * Tests the dimensions produced by each image style.
   */
  public function testImageStyleDimensions(): void {
    $this->installCropTool('manual_crop');
    $source = 'public://matrix.png';
    imagepng(imagecreatetruecolor(4000, 3000), \Drupal::service('file_system')->realpath('public://') . '/matrix.png');

    $factory = \Drupal::service('image.factory');
    $checked = 0;
    foreach (self::RATIOS as $ratio) {
      foreach (self::widths($ratio) as $width) {
        $id = self::styleId($ratio, $width, 'manual_crop');
        $style = ImageStyle::load($id);
        $this->assertNotNull($style, "$id exists");
        $derivative = $style->buildUri($source);
        $this->assertTrue($style->createDerivative($source, $derivative), "$id derives");
        $result = $factory->get($derivative);
        $this->assertSame($width, $result->getWidth(), "$id is $width wide");
        if (isset(self::HEIGHTS[$ratio])) {
          $this->assertSame(
            (int) round($width * self::HEIGHTS[$ratio], 0, PHP_ROUND_HALF_EVEN),
            $result->getHeight(),
            "$id is the height its shape promises"
          );
        }
        $this->assertSame('image/webp', $result->getMimeType(), "$id converts to WebP");
        $checked++;
      }
    }
    $this->assertSame(51, $checked);
  }

  /**
   * Tests that freestyle image styles keep the original aspect ratio.
   */
  public function testFreestyleHeight(): void {
    $this->installCropTool('manual_crop');
    $fs = \Drupal::service('file_system')->realpath('public://');
    imagepng(imagecreatetruecolor(1600, 800), $fs . '/wide.png');
    imagepng(imagecreatetruecolor(800, 1600), $fs . '/tall.png');

    $factory = \Drupal::service('image.factory');
    $height = function (string $ratio, string $name) use ($factory): int {
      $source = "public://$name.png";
      $style = ImageStyle::load(self::styleId($ratio, 768, 'manual_crop'));
      $uri = $style->buildUri($source);
      $style->createDerivative($source, $uri);
      return $factory->get($uri)->getHeight();
    };

    $this->assertSame(384, $height('freestyle', 'wide'));
    $this->assertSame(1536, $height('freestyle', 'tall'));
    $this->assertSame(432, $height('16_9', 'wide'));
    $this->assertSame(432, $height('16_9', 'tall'));
  }

}
