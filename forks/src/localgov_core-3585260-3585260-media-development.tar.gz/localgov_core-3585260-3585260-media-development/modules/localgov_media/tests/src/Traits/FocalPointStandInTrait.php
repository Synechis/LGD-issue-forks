<?php

declare(strict_types=1);

namespace Drupal\Tests\localgov_media\Traits;

/**
 * Stands the test module in for drupal/focal_point.
 *
 * The rule is about which modules a site has, so a test module registered as
 * the focal point tool is enough to install and refuse. The image styles are
 * not tested here: MediaImageConfigurationTest needs the real module.
 */
trait FocalPointStandInTrait {

  /**
   * The module that stands in for focal_point.
   */
  protected static string $standIn = 'localgov_media_focal_point_test';

  /**
   * The localgov_media.crop_tools parameter with the stand-in as focal point.
   */
  protected static function standInCropTools(): array {
    return [
      'manual_crop' => [
        'widget' => 'image_widget_crop',
        'image' => 'localgov_media_image_manual_crop',
        'optional_ratios' => 'localgov_media_image_optional_manual_crop',
      ],
      'focal_point' => [
        'widget' => self::$standIn,
      ],
    ];
  }

}
