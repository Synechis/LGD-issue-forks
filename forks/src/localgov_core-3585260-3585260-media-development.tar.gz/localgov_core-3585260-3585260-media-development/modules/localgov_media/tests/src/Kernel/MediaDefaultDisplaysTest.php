<?php

declare(strict_types=1);

namespace Drupal\Tests\localgov_media\Kernel;

use Drupal\file\Entity\File;
use Drupal\KernelTests\KernelTestBase;
use Drupal\media\Entity\Media;
use PHPUnit\Framework\Attributes\Group;
use PHPUnit\Framework\Attributes\RunTestsInSeparateProcesses;

/**
 * Tests the default displays of the three media types.
 *
 * @group localgov_media
 */
#[Group('localgov_media')]
#[RunTestsInSeparateProcesses]
class MediaDefaultDisplaysTest extends KernelTestBase {

  /**
   * {@inheritdoc}
   */
  protected static $modules = [
    'system',
    'user',
    'field',
    'file',
    'path',
    'image',
    'media',
    'crop',
    'breakpoint',
    'responsive_image',
    'localgov_breakpoints',
    'localgov_media',
  ];

  /**
   * {@inheritdoc}
   */
  protected function setUp(): void {
    parent::setUp();
    $this->installEntitySchema('user');
    $this->installEntitySchema('file');
    $this->installEntitySchema('crop');
    $this->installEntitySchema('media');
    $this->installSchema('file', ['file_usage']);
    $this->installSchema('user', ['users_data']);
    $this->installConfig(['system', 'field', 'image', 'media']);
    \Drupal::service('module_installer')->install([
      'localgov_media_document',
      'localgov_media_video',
      'localgov_media_image',
      'localgov_media_image_manual_crop',
    ]);
  }

  /**
   * Tests that every media type has a default display with a crop tool.
   */
  public function testDefaultDisplaysExist(): void {
    $storage = \Drupal::entityTypeManager()->getStorage('entity_view_display');
    foreach (['image', 'document', 'remote_video'] as $bundle) {
      $this->assertNotNull($storage->load("media.$bundle.default"), "media.$bundle.default exists");
    }
    $component = $storage->load('media.image.default')->getComponent('field_media_image');
    $this->assertSame('responsive_image', $component['type']);
    $this->assertNotNull(
      \Drupal::entityTypeManager()->getStorage('responsive_image_style')->load($component['settings']['responsive_image_style']),
      'The default display names a responsive image style that exists'
    );
  }

  /**
   * Tests that an image renders through a responsive image style by default.
   */
  public function testDefaultDisplayRendersResponsiveImage(): void {
    $uri = \Drupal::service('file_system')->copy('core/modules/image/sample.png', 'public://sample.png');
    $file = File::create(['uri' => $uri, 'status' => 1]);
    $file->save();
    $media = Media::create([
      'bundle' => 'image',
      'name' => 'Sample',
      'field_media_image' => ['target_id' => $file->id(), 'alt' => 'Sample'],
    ]);
    $media->save();

    $build = \Drupal::entityTypeManager()->getViewBuilder('media')->view($media, 'default');
    $html = (string) \Drupal::service('renderer')->renderInIsolation($build);
    $this->assertStringContainsString('<picture', $html, 'The default display is a responsive image');
    $this->assertStringContainsString('localgov_16_9_', $html, 'The default display uses the 16:9 styles');
    $this->assertStringNotContainsString('styles/thumbnail/', $html, 'Not the core fallback display');
  }

}
