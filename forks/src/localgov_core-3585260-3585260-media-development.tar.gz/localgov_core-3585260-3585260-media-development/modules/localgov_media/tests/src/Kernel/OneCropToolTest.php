<?php

declare(strict_types=1);

namespace Drupal\Tests\localgov_media\Kernel;

use Drupal\Core\DependencyInjection\ContainerBuilder;
use Drupal\Core\Extension\MissingDependencyException;
use Drupal\Core\Recipe\Recipe;
use Drupal\Core\Recipe\RecipeMissingExtensionsException;
use Drupal\Core\Recipe\RecipeRunner;
use Drupal\KernelTests\KernelTestBase;
use Drupal\localgov_media\CropTools;
use Drupal\Tests\localgov_media\Traits\FocalPointStandInTrait;
use PHPUnit\Framework\Attributes\Group;
use PHPUnit\Framework\Attributes\RunTestsInSeparateProcesses;
use Symfony\Component\Yaml\Yaml;

/**
 * Tests that a site has one crop tool, by any install route.
 *
 * The stand-in module is registered as the focal point tool, so the rule can
 * be tested on a build with no drupal/focal_point.
 *
 * @group localgov_media
 */
#[Group('localgov_media')]
#[RunTestsInSeparateProcesses]
class OneCropToolTest extends KernelTestBase {

  use FocalPointStandInTrait;

  /**
   * {@inheritdoc}
   */
  protected static $modules = [
    'system',
    'user',
    'field',
    'file',
    'path',
    'image',
    'media',
    'crop',
    'breakpoint',
    'responsive_image',
    'localgov_breakpoints',
    'localgov_media',
  ];

  /**
   * {@inheritdoc}
   */
  public function register(ContainerBuilder $container): void {
    parent::register($container);
    $container->setParameter('localgov_media.crop_tools', self::standInCropTools());
  }

  /**
   * {@inheritdoc}
   */
  protected function setUp(): void {
    parent::setUp();
    $this->installEntitySchema('user');
    $this->installEntitySchema('file');
    $this->installEntitySchema('crop');
    $this->installEntitySchema('media');
    $this->installSchema('user', ['users_data']);
    $this->installSchema('file', ['file_usage']);
    $this->installConfig(['system', 'field', 'image', 'media']);
    $this->installer()->install(['localgov_media_image_manual_crop']);
  }

  /**
   * Tests that once one crop tool is installed the other cannot be.
   */
  public function testOneCropToolPerSite(): void {
    $widget = 'image_widget_crop';
    $image = 'localgov_media_image_manual_crop';
    $focal = self::$standIn;

    $this->assertSame(['manual_crop' => [$widget, $image]], $this->rule()->installed());
    $this->assertSame('manual_crop', $this->rule()->applied());
    $this->assertSame([], $this->rule()->requirements());
    $this->assertNull($this->rule()->refusal([$widget]), 'Installing what is installed is allowed');
    $this->assertSame(
      "One crop tool per site: this site crops with manual crop ($widget, $image). A site keeps the crop tool it was installed with; moving it to the other one is a migration, not a module install.",
      (string) $this->rule()->refusal([$focal])
    );
    $this->assertRequires($focal, TRUE);
    $this->assertRequires($widget, FALSE);
    try {
      $this->installer()->install([$focal]);
      $this->fail('Core refuses the other crop tool');
    }
    catch (MissingDependencyException $e) {
      $this->assertStringContainsString("module '$focal' is missing its dependency module " . CropTools::ONE_PER_SITE, $e->getMessage());
    }
    $this->assertFalse(\Drupal::service('module_handler')->moduleExists($focal));

    // A recipe's dependencies are checked when it is read.
    $dir = $this->siteDirectory . '/recipes/other_tool';
    mkdir($dir, 0777, TRUE);
    file_put_contents($dir . '/recipe.yml', Yaml::dump([
      'name' => 'Other tool',
      'type' => 'Testing',
      'install' => [$focal],
    ]));
    try {
      RecipeRunner::processRecipe(Recipe::createFromDirectory($dir));
      $this->fail('A recipe cannot install the other crop tool either');
    }
    catch (RecipeMissingExtensionsException $e) {
      $this->assertStringContainsString(CropTools::ONE_PER_SITE, $e->getMessage());
    }
    $this->assertFalse(\Drupal::service('module_handler')->moduleExists($focal));

    $this->installer()->uninstall([$image, $widget]);
    $this->assertSame([], $this->rule()->installed());
    $this->assertNull($this->rule()->applied());
    $this->assertRequires($focal, FALSE);
    $this->assertRequires($widget, FALSE);
    $this->assertNull($this->rule()->refusal([$focal]));
    $this->assertNull($this->rule()->refusal([$widget]));
    $this->assertSame(
      "One crop tool per site: install manual crop ($widget, $image, localgov_media_image_optional_manual_crop) or focal point ($focal), not both.",
      (string) $this->rule()->refusal([$widget, $focal])
    );

    $this->installer()->install([$focal]);
    $this->assertSame(['focal_point' => [$focal]], $this->rule()->installed());
    $this->assertRequires($widget, TRUE);
    $this->assertRequires($image, TRUE);
    $this->assertRequires($focal, FALSE);
    foreach ([$widget, $image] as $refused) {
      try {
        $this->installer()->install([$refused]);
        $this->fail("Core refuses $refused too");
      }
      catch (MissingDependencyException $e) {
        $this->assertStringContainsString(CropTools::ONE_PER_SITE, $e->getMessage());
      }
    }

    // Configuration import does not check dependencies.
    $this->installer()->install([$widget], FALSE);
    $this->assertSame(['manual_crop' => [$widget], 'focal_point' => [$focal]], $this->rule()->installed());
    $this->assertRequires($widget, FALSE);
    $this->assertRequires($focal, FALSE);
    $requirements = $this->statusReport();
    $this->assertArrayHasKey('localgov_media_crop_tools', $requirements);
    $entry = $requirements['localgov_media_crop_tools'];
    $this->assertSame("Both installed: $widget, $focal", (string) $entry['value']);
    $this->assertStringContainsString('Uninstall the one this site does not use.', (string) $entry['description']);
    $this->assertSame(2, is_object($entry['severity']) ? $entry['severity']->value : $entry['severity'], 'An error');
  }

  /**
   * Tests the status report for localgov_media_image with no crop tool.
   */
  public function testImageModuleWithoutCropTool(): void {
    $this->assertArrayNotHasKey('localgov_media_crop_tool_missing', $this->statusReport());

    $this->installer()->uninstall(['localgov_media_image_manual_crop', 'image_widget_crop']);
    $this->assertTrue(\Drupal::service('module_handler')->moduleExists('localgov_media_image'));
    $requirements = $this->statusReport();
    $this->assertArrayHasKey('localgov_media_crop_tool_missing', $requirements);
    $entry = $requirements['localgov_media_crop_tool_missing'];
    $this->assertSame('None installed', (string) $entry['value']);
    $this->assertStringContainsString('the image styles themselves come from a crop tool', (string) $entry['description']);
    $this->assertSame(2, is_object($entry['severity']) ? $entry['severity']->value : $entry['severity'], 'An error');
  }

  /**
   * Tests that the optional aspect ratios arrive with their image styles.
   */
  public function testOptionalRatiosBringTheirStyles(): void {
    $this->installer()->install(['localgov_media_image_optional']);
    $handler = \Drupal::service('module_handler');
    $this->assertTrue($handler->moduleExists('localgov_media_image_optional_manual_crop'), 'The installed tool\'s optional styles are added');
    $this->assertFalse($handler->moduleExists('localgov_media_image_optional_focal_point'));
    $this->assertNotNull(\Drupal::entityTypeManager()->getStorage('crop_type')->load('3_2'));
  }

  /**
   * Asserts whether a module has been given the dependency that refuses it.
   */
  protected function assertRequires(string $module, bool $refused): void {
    $requires = array_keys(\Drupal::service('extension.list.module')->reset()->getList()[$module]->requires);
    $this->assertSame($refused, in_array(CropTools::ONE_PER_SITE, $requires, TRUE), "$module " . ($refused ? 'is refused' : 'can be installed'));
  }

  /**
   * Returns the status report.
   *
   * Drupal 10 invokes hook_requirements('runtime'), 11.3 and later
   * hook_runtime_requirements(), and 11.2 both.
   */
  protected function statusReport(): array {
    $module_handler = \Drupal::service('module_handler');
    $module_handler->loadInclude('localgov_media', 'install');
    return array_merge(
      $module_handler->invokeAll('requirements', ['runtime']),
      $module_handler->invokeAll('runtime_requirements'),
    );
  }

  /**
   * The rule, from the current container.
   */
  protected function rule(): CropTools {
    return \Drupal::service(CropTools::class);
  }

  /**
   * The module installer, fetched fresh: an install rebuilds the container.
   */
  protected function installer() {
    return \Drupal::service('module_installer');
  }

}
