<?php

declare(strict_types=1);

namespace Drupal\Tests\localgov_media\Functional;

use Drupal\Tests\BrowserTestBase;
use Drupal\Tests\localgov_media\Traits\FocalPointStandInTrait;
use PHPUnit\Framework\Attributes\Group;
use PHPUnit\Framework\Attributes\RunTestsInSeparateProcesses;

/**
 * Tests the one-crop-tool rule on the Extend page.
 *
 * @group localgov_media
 */
#[Group('localgov_media')]
#[RunTestsInSeparateProcesses]
class OneCropToolExtendPageTest extends BrowserTestBase {

  use FocalPointStandInTrait;

  /**
   * {@inheritdoc}
   */
  protected $defaultTheme = 'stark';

  /**
   * {@inheritdoc}
   */
  protected static $modules = [
    'localgov_media',
    'localgov_media_image',
    'localgov_media_image_manual_crop',
  ];

  /**
   * {@inheritdoc}
   */
  protected function setUp(): void {
    parent::setUp();
    $this->setContainerParameter('localgov_media.crop_tools', self::standInCropTools());
    $this->rebuildContainer();
    $this->container->get('extension.list.module')->reset();
    $this->drupalLogin($this->drupalCreateUser(['administer modules']));
  }

  /**
   * Tests that the other crop tool is disabled, with a reason, on the page.
   */
  public function testOtherCropToolIsDisabled(): void {
    $widget = 'image_widget_crop';
    $image = 'localgov_media_image_manual_crop';
    $focal = self::$standIn;
    $assert = $this->assertSession();

    $this->drupalGet('admin/modules');
    $assert->checkboxChecked("modules[$widget][enable]");
    $assert->checkboxNotChecked("modules[$focal][enable]");
    $assert->fieldDisabled("modules[$focal][enable]");
    $assert->pageTextContains("One crop tool per site: this site crops with manual crop ($widget, $image). A site keeps the crop tool it was installed with; moving it to the other one is a migration, not a module install.");
    $assert->pageTextNotContains('Localgov_media_one_crop_tool_per_site');

    $this->container->get('module_installer')->uninstall([$image, $widget]);
    $this->drupalGet('admin/modules');
    $assert->fieldEnabled("modules[$widget][enable]");
    $assert->fieldEnabled("modules[$focal][enable]");
    $assert->pageTextNotContains('One crop tool per site:');
    $this->submitForm(["modules[$widget][enable]" => TRUE, "modules[$focal][enable]" => TRUE], 'Install');
    $assert->pageTextContains("One crop tool per site: install manual crop ($widget, $image, localgov_media_image_optional_manual_crop) or focal point ($focal), not both.");
    $this->rebuildContainer();
    $this->assertFalse($this->container->get('module_handler')->moduleExists($widget));
    $this->assertFalse($this->container->get('module_handler')->moduleExists($focal));

    $this->drupalGet('admin/modules');
    $this->submitForm(["modules[$focal][enable]" => TRUE], 'Install');
    $this->rebuildContainer();
    $this->assertTrue($this->container->get('module_handler')->moduleExists($focal));
    $this->drupalGet('admin/modules');
    $assert->checkboxChecked("modules[$focal][enable]");
    $assert->checkboxNotChecked("modules[$widget][enable]");
    $assert->fieldDisabled("modules[$widget][enable]");
    $assert->fieldDisabled("modules[$image][enable]");
    $assert->pageTextContains("One crop tool per site: this site crops with focal point ($focal). A site keeps the crop tool it was installed with; moving it to the other one is a migration, not a module install.");
  }

}
