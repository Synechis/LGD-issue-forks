<?php

declare(strict_types=1);

namespace Drupal\Tests\localgov_media\Kernel;

use Drupal\KernelTests\KernelTestBase;
use Drupal\localgov_roles\RolesHelper;
use Drupal\user\Entity\Role;
use PHPUnit\Framework\Attributes\Group;
use PHPUnit\Framework\Attributes\RunTestsInSeparateProcesses;

/**
 * Tests the permissions the media modules grant the LocalGov roles.
 *
 * The document and remote video modules grant their permissions through
 * hook_localgov_roles_default(), which localgov_roles can invoke before the
 * media type exists. Whichever order the modules install in, the roles must
 * end up with the permissions.
 *
 * @group localgov_media
 */
#[Group('localgov_media')]
#[RunTestsInSeparateProcesses]
class MediaRolesTest extends KernelTestBase {

  /**
   * {@inheritdoc}
   */
  protected static $modules = [
    'system',
    'user',
    'field',
    'file',
    'path',
    'image',
    'media',
    'toolbar',
  ];

  /**
   * {@inheritdoc}
   */
  protected function setUp(): void {
    parent::setUp();
    $this->installEntitySchema('user');
    $this->installEntitySchema('file');
    $this->installEntitySchema('media');
    $this->installSchema('user', ['users_data']);
    $this->installConfig(['system', 'user', 'field', 'image', 'media']);
    \Drupal::service('module_installer')->install(['localgov_media']);
  }

  /**
   * Tests the media types installed before the roles.
   */
  public function testRolesInstalledLast(): void {
    \Drupal::service('module_installer')->install(['localgov_media_document', 'localgov_media_video']);
    \Drupal::service('module_installer')->install(['localgov_roles']);
    $this->assertMediaPermissions();
  }

  /**
   * Tests the media types installed after the roles.
   */
  public function testRolesInstalledFirst(): void {
    \Drupal::service('module_installer')->install(['localgov_roles']);
    \Drupal::service('module_installer')->install(['localgov_media_document', 'localgov_media_video']);
    $this->assertMediaPermissions();
  }

  /**
   * Tests the hooks grant nothing before their media type exists.
   */
  public function testNoPermissionsWithoutMediaType(): void {
    $this->enableModules(['localgov_media_document', 'localgov_media_video']);
    foreach (['document', 'remote_video'] as $bundle) {
      $this->assertNull(\Drupal::entityTypeManager()->getStorage('media_type')->load($bundle));
    }
    $permissions = array_merge(...array_values(\Drupal::moduleHandler()->invokeAll('localgov_roles_default')));
    $this->assertContains('create image media', $permissions);
    foreach ($permissions as $permission) {
      $this->assertStringNotContainsString('document media', $permission);
      $this->assertStringNotContainsString('remote_video media', $permission);
    }
  }

  /**
   * Asserts the roles have the media type permissions.
   */
  protected function assertMediaPermissions(): void {
    $editor = Role::load(RolesHelper::EDITOR_ROLE);
    $author = Role::load(RolesHelper::AUTHOR_ROLE);
    $contributor = Role::load(RolesHelper::CONTRIBUTOR_ROLE);
    foreach (['image', 'document', 'remote_video'] as $bundle) {
      foreach ([$editor, $author, $contributor] as $role) {
        $this->assertTrue($role->hasPermission("create $bundle media"), "{$role->id()} can create $bundle media");
        $this->assertTrue($role->hasPermission("edit own $bundle media"), "{$role->id()} can edit own $bundle media");
        $this->assertTrue($role->hasPermission("delete own $bundle media"), "{$role->id()} can delete own $bundle media");
      }
      $this->assertTrue($editor->hasPermission("delete any $bundle media"), "Editors can delete any $bundle media");
      $this->assertFalse($author->hasPermission("delete any $bundle media"), "Authors cannot delete any $bundle media");
      $this->assertFalse($contributor->hasPermission("delete any $bundle media"), "Contributors cannot delete any $bundle media");
    }
  }

}
