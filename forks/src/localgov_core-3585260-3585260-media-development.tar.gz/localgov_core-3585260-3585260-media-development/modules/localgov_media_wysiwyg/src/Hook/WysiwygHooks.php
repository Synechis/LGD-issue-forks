<?php

declare(strict_types=1);

namespace Drupal\localgov_media_wysiwyg\Hook;

use Drupal\Core\Config\ConfigFactoryInterface;
use Drupal\Core\Entity\EntityTypeManagerInterface;
use Drupal\Core\Hook\Attribute\Hook;

/**
 * Hook implementations for LocalGov Media WYSIWYG.
 */
class WysiwygHooks {

  /**
   * Constructs the hook implementations.
   *
   * @param \Drupal\Core\Config\ConfigFactoryInterface $configFactory
   *   The config factory.
   * @param \Drupal\Core\Entity\EntityTypeManagerInterface $entityTypeManager
   *   The entity type manager.
   */
  public function __construct(
    protected ConfigFactoryInterface $configFactory,
    protected EntityTypeManagerInterface $entityTypeManager,
  ) {}

  /**
   * Implements hook_modules_installed().
   *
   * Carried forward from localgov_media 3.3.0.
   */
  #[Hook('modules_installed')]
  public function modulesInstalled($modules, $is_syncing): void {
    if ($is_syncing || !in_array('localgov_media_wysiwyg', $modules, TRUE)) {
      return;
    }
    if (!$this->configFactory->get('filter.format.wysiwyg')->getRawData()) {
      return;
    }
    $role = $this->entityTypeManager->getStorage('user_role')->load('authenticated');
    if ($role && !$role->hasPermission('use text format wysiwyg')) {
      $role->grantPermission('use text format wysiwyg')->save();
    }
  }

}
