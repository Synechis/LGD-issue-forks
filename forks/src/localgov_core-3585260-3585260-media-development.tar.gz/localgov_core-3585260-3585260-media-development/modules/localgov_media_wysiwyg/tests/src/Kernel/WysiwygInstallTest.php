<?php

declare(strict_types=1);

namespace Drupal\Tests\localgov_media_wysiwyg\Kernel;

use Drupal\editor\Entity\Editor;
use Drupal\filter\Entity\FilterFormat;
use Drupal\KernelTests\KernelTestBase;
use Drupal\user\Entity\Role;
use Drupal\user\RoleInterface;
use PHPUnit\Framework\Attributes\Group;
use PHPUnit\Framework\Attributes\RunTestsInSeparateProcesses;

/**
 * Tests what installing LocalGov Media WYSIWYG puts in place.
 *
 * @group localgov_media
 */
#[Group('localgov_media')]
#[RunTestsInSeparateProcesses]
class WysiwygInstallTest extends KernelTestBase {

  /**
   * {@inheritdoc}
   */
  protected static $modules = [
    'system',
    'user',
    'field',
    'file',
    'path',
    'image',
    'media',
    'filter',
    'editor',
    'ckeditor5',
    'media_library',
    'views',
    'linkit',
    'crop',
    'breakpoint',
    'responsive_image',
    'localgov_breakpoints',
    'localgov_media',
  ];

  /**
   * {@inheritdoc}
   */
  protected function setUp(): void {
    parent::setUp();
    $this->installEntitySchema('user');
    $this->installEntitySchema('file');
    $this->installEntitySchema('media');
    $this->installSchema('user', ['users_data']);
    $this->installConfig(['system', 'user', 'field', 'image', 'media', 'filter']);
    \Drupal::service('module_installer')->install(['localgov_media_wysiwyg']);
  }

  /**
   * Tests the text format and editor.
   */
  public function testFormatAndEditor(): void {
    $format = FilterFormat::load('wysiwyg');
    $this->assertNotNull($format);
    $this->assertTrue($format->filters('media_embed')->status);
    $this->assertTrue($format->filters('linkit')->status);

    $editor = Editor::load('wysiwyg');
    $this->assertNotNull($editor);
    $this->assertSame('ckeditor5', $editor->getEditor());
    $this->assertSame('default', $editor->getSettings()['plugins']['linkit_extension']['linkit_profile']);
  }

  /**
   * Tests that logged-in users may use the format.
   */
  public function testAuthenticatedUsersMayUseTheFormat(): void {
    $this->assertTrue(Role::load(RoleInterface::AUTHENTICATED_ID)->hasPermission('use text format wysiwyg'));
    $this->assertFalse(Role::load(RoleInterface::ANONYMOUS_ID)->hasPermission('use text format wysiwyg'));
  }

  /**
   * Tests that the media view modes the format offers exist.
   */
  public function testEmbedViewModesExist(): void {
    $settings = FilterFormat::load('wysiwyg')->filters('media_embed')->getConfiguration()['settings'];
    $storage = \Drupal::entityTypeManager()->getStorage('entity_view_mode');
    foreach (array_keys($settings['allowed_view_modes']) as $id) {
      if ($id !== 'default') {
        $this->assertNotNull($storage->load('media.' . $id), "View mode $id exists before any crop tool is installed");
      }
    }
    $this->assertArrayHasKey($settings['default_view_mode'], $settings['allowed_view_modes']);
  }

}
