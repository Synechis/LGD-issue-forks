<?php

declare(strict_types=1);

namespace Drupal\Tests\localgov_media_wysiwyg\Functional;

use Drupal\Tests\BrowserTestBase;
use PHPUnit\Framework\Attributes\Group;
use PHPUnit\Framework\Attributes\RunTestsInSeparateProcesses;

/**
 * Tests the WYSIWYG format on a site with its Linkit profile's dependencies.
 *
 * @group localgov_media
 */
#[Group('localgov_media')]
#[RunTestsInSeparateProcesses]
class WysiwygEditorTest extends BrowserTestBase {

  /**
   * {@inheritdoc}
   */
  protected $defaultTheme = 'stark';

  /**
   * {@inheritdoc}
   */
  protected static $modules = [
    'node',
    'localgov_core',
    'paragraphs_library',
    'localgov_media_wysiwyg',
  ];

  /**
   * Tests that the editor's Linkit profile exists and the format is usable.
   */
  public function testEditorAndLinkitProfile(): void {
    $this->assertNotNull(\Drupal::entityTypeManager()->getStorage('linkit_profile')->load('default'), 'The Linkit profile the editor names exists');

    $this->drupalCreateContentType(['type' => 'page', 'name' => 'Page']);
    $this->drupalLogin($this->drupalCreateUser(['create page content', 'use text format wysiwyg']));
    $this->drupalGet('node/add/page');
    $this->assertSession()->statusCodeEquals(200);
    $this->assertSession()->hiddenFieldValueEquals('body[0][format]', 'wysiwyg');
    $this->assertSession()->responseContains('ckeditor5');
  }

}
