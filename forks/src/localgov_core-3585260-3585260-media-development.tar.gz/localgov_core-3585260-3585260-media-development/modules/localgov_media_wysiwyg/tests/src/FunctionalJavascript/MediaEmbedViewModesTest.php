<?php

declare(strict_types=1);

namespace Drupal\Tests\localgov_media_wysiwyg\FunctionalJavascript;

use Drupal\Core\Entity\Entity\EntityViewMode;
use Drupal\file\Entity\File;
use Drupal\filter\Entity\FilterFormat;
use Drupal\FunctionalJavascriptTests\WebDriverTestBase;
use Drupal\media\Entity\Media;
use Drupal\node\Entity\Node;
use Drupal\Tests\ckeditor5\Traits\CKEditor5TestTrait;
use PHPUnit\Framework\Attributes\Group;
use PHPUnit\Framework\Attributes\RunTestsInSeparateProcesses;

/**
 * Tests the media view modes an editor can choose in the WYSIWYG editor.
 *
 * @group localgov_media
 */
#[Group('localgov_media')]
#[RunTestsInSeparateProcesses]
class MediaEmbedViewModesTest extends WebDriverTestBase {

  use CKEditor5TestTrait;

  /**
   * {@inheritdoc}
   */
  protected $defaultTheme = 'claro';

  /**
   * {@inheritdoc}
   */
  protected static $modules = [
    'node',
    'localgov_core',
    'paragraphs_library',
    'localgov_media_wysiwyg',
    'localgov_media_image',
    'localgov_media_image_manual_crop',
  ];

  /**
   * The node holding the embedded media.
   */
  protected Node $host;

  /**
   * {@inheritdoc}
   */
  protected function setUp(): void {
    parent::setUp();
    $this->drupalCreateContentType(['type' => 'page', 'name' => 'Page']);

    $uri = $this->container->get('file_system')->copy('core/modules/image/sample.png', 'public://sample.png');
    $file = File::create(['uri' => $uri, 'status' => 1]);
    $file->save();
    $media = Media::create([
      'bundle' => 'image',
      'name' => 'Sample',
      'field_media_image' => ['target_id' => $file->id(), 'alt' => 'Sample'],
    ]);
    $media->save();

    $this->host = $this->drupalCreateNode([
      'type' => 'page',
      'title' => 'Host',
      'body' => [
        'value' => '<drupal-media data-entity-type="media" data-entity-uuid="' . $media->uuid() . '" data-view-mode="localgov_16_9_medium"></drupal-media>',
        'format' => 'wysiwyg',
      ],
    ]);

    $this->drupalLogin($this->drupalCreateUser([
      'access content',
      'view media',
      'edit any page content',
      'use text format wysiwyg',
    ]));
  }

  /**
   * Tests that the media balloon offers every view mode the format allows.
   */
  public function testViewModesOffered(): void {
    $format = FilterFormat::load('wysiwyg');
    $allowed = $format->filters('media_embed')->getConfiguration()['settings']['allowed_view_modes'];
    $expected = [];
    foreach (array_keys($allowed) as $id) {
      $expected[] = $id === 'default' ? 'Default' : EntityViewMode::load('media.' . $id)->label();
    }
    $this->assertCount(11, $expected, 'Default, then small and medium for the five default shapes');

    $this->drupalGet($this->host->toUrl('edit-form'));
    $this->waitForEditor();
    $this->assertNotEmpty($this->assertSession()->waitForElementVisible('css', '.ck-widget.drupal-media img'));
    $this->click('.ck-widget.drupal-media');
    $this->assertVisibleBalloon('[aria-label="Drupal Media toolbar"]');

    $dropdown = $this->getSession()->getPage()->find('css', '.ck-balloon-panel button.ck-dropdown__button > span.ck-button__label');
    $this->assertSame('16:9 Medium', $dropdown->getText(), 'The balloon shows the embedded view mode');

    $this->getBalloonButton('16:9 Medium')->click();
    $offered = array_map(
      fn($item) => $item->getText(),
      $this->getSession()->getPage()->findAll('css', '.ck-balloon-panel .ck-dropdown__panel .ck-list__item .ck-button__label')
    );
    $this->assertEqualsCanonicalizing($expected, $offered, 'The dropdown offers exactly what the format allows');
    foreach (array_keys($allowed) as $id) {
      $this->assertNotNull(
        \Drupal::entityTypeManager()->getStorage('entity_view_display')->load('media.image.' . $id),
        "Image media has a display for $id, so the editor can offer it"
      );
    }
  }

  /**
   * Tests that a chosen view mode is stored on the embed.
   */
  public function testChoosingViewMode(): void {
    $this->drupalGet($this->host->toUrl('edit-form'));
    $this->waitForEditor();
    $this->assertNotEmpty($this->assertSession()->waitForElementVisible('css', '.ck-widget.drupal-media img'));
    $this->click('.ck-widget.drupal-media');
    $this->assertVisibleBalloon('[aria-label="Drupal Media toolbar"]');
    $this->getBalloonButton('16:9 Medium')->click();
    $this->getBalloonButton('4:3 Small')->click();

    $embed = $this->getEditorDataAsDom()->getElementsByTagName('drupal-media')->item(0);
    $this->assertSame('localgov_4_3_small', $embed->getAttribute('data-view-mode'));

    $this->getSession()->getPage()->pressButton('Save');
    $this->assertSession()->waitForText('Host');
    $body = Node::load($this->host->id())->get('body')->value;
    $this->assertStringContainsString('data-view-mode="localgov_4_3_small"', $body, 'The chosen view mode is saved with the content');
  }

}
