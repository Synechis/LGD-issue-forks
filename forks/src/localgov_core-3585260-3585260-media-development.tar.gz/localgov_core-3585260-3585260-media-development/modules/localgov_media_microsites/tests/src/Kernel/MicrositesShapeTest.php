<?php

declare(strict_types=1);

namespace Drupal\Tests\localgov_media_microsites\Kernel;

use Drupal\KernelTests\KernelTestBase;
use PHPUnit\Framework\Attributes\Group;
use PHPUnit\Framework\Attributes\RunTestsInSeparateProcesses;

/**
 * Tests that Microsites get 4:3 images from a module, not from a profile.
 *
 * @group localgov_media_microsites
 */
#[Group('localgov_media_microsites')]
#[RunTestsInSeparateProcesses]
class MicrositesShapeTest extends KernelTestBase {

  /**
   * {@inheritdoc}
   */
  protected static $modules = [
    'system',
    'user',
    'field',
    'file',
    'path',
    'image',
    'media',
    'crop',
    'breakpoint',
    'responsive_image',
    'localgov_breakpoints',
    'localgov_media',
  ];

  /**
   * {@inheritdoc}
   */
  protected function setUp(): void {
    parent::setUp();
    $this->installEntitySchema('user');
    $this->installEntitySchema('file');
    $this->installEntitySchema('crop');
    $this->installEntitySchema('media');
    $this->installSchema('user', ['users_data']);
    $this->installConfig(['system', 'field', 'image', 'media']);
  }

  /**
   * Tests the two displays with localgov_media_image installed first.
   */
  public function testShapeAfterImageModule(): void {
    \Drupal::service('module_installer')->install(['localgov_media_image_manual_crop']);
    $this->assertShape('localgov_16_9_large', 'localgov_16_9_384', 'LocalGov shapes before the module');
    \Drupal::service('module_installer')->install(['localgov_media_microsites']);
    $this->assertShape('localgov_4_3_large', 'localgov_4_3_384', 'Microsites shapes after it');
  }

  /**
   * Tests the module installed in the same request as localgov_media_image.
   *
   * The displays it changes are created by a hook that runs after the whole
   * batch, so the module has to create them itself first.
   */
  public function testShapeInTheSameRequest(): void {
    \Drupal::service('module_installer')->install([
      'localgov_media_image',
      'localgov_media_image_manual_crop',
      'localgov_media_microsites',
    ]);
    $this->assertShape('localgov_4_3_large', 'localgov_4_3_384', 'Microsites shapes from one install call');
  }

  /**
   * Asserts the default and teaser displays, and their dependencies.
   */
  protected function assertShape(string $responsive, string $style, string $message): void {
    $storage = \Drupal::entityTypeManager()->getStorage('entity_view_display');
    $default = $storage->load('media.image.default');
    $this->assertNotNull($default, "$message: the default display exists");
    $this->assertSame($responsive, $default->getComponent('field_media_image')['settings']['responsive_image_style'], $message);
    $this->assertContains("responsive_image.styles.$responsive", $default->getDependencies()['config'], "$message: the dependency moved with it");
    $teaser = $storage->load('media.image.localgov_teaser');
    $this->assertSame($style, $teaser->getComponent('field_media_image')['settings']['image_style'], $message);
    $this->assertContains("image.style.$style", $teaser->getDependencies()['config'], "$message: the teaser dependency moved with it");
  }

}
