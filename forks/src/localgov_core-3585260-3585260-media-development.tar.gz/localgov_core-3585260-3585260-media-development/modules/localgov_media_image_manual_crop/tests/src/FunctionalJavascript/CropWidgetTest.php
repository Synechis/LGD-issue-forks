<?php

declare(strict_types=1);

namespace Drupal\Tests\localgov_media_image_manual_crop\FunctionalJavascript;

use Drupal\crop\Entity\Crop;
use Drupal\file\Entity\File;
use Drupal\FunctionalJavascriptTests\WebDriverTestBase;
use Drupal\image\Entity\ImageStyle;
use Drupal\media\Entity\Media;
use Drupal\Tests\TestFileCreationTrait;
use PHPUnit\Framework\Attributes\Group;
use PHPUnit\Framework\Attributes\RunTestsInSeparateProcesses;

/**
 * Tests the crop widget on the image media form.
 *
 * @group localgov_media_image_manual_crop
 */
#[Group('localgov_media_image_manual_crop')]
#[RunTestsInSeparateProcesses]
class CropWidgetTest extends WebDriverTestBase {

  use TestFileCreationTrait;

  /**
   * {@inheritdoc}
   */
  protected $defaultTheme = 'claro';

  /**
   * {@inheritdoc}
   */
  protected static $modules = [
    'path',
    'localgov_media',
    'localgov_media_image',
    'localgov_media_image_manual_crop',
  ];

  /**
   * The crop types the widget offers, in the order they are shown.
   */
  const CROP_TYPES = ['21_9', '16_9', '4_3', '1_1', 'freestyle'];

  /**
   * {@inheritdoc}
   */
  protected function setUp(): void {
    parent::setUp();
    // image_widget_crop loads Cropper from cdnjs unless a local copy is set.
    if (file_exists(DRUPAL_ROOT . '/libraries/cropper/dist/cropper.min.js')) {
      $this->config('image_widget_crop.settings')
        ->set('settings.library_url', 'libraries/cropper/dist/cropper.min.js')
        ->set('settings.css_url', 'libraries/cropper/dist/cropper.min.css')
        ->save();
    }
    $this->drupalLogin($this->drupalCreateUser(['access content', 'create media', 'update media', 'view media']));
  }

  /**
   * Tests that uploading an image offers a crop for every shape.
   */
  public function testEveryShapeCanBeCropped(): void {
    $page = $this->getSession()->getPage();
    $assert = $this->assertSession();

    $this->drupalGet('media/add/image');
    $assert->elementNotExists('css', '[data-drupal-iwc=wrapper]');

    $image = $this->largestTestImage();
    $page->attachFileToField('files[field_media_image_0]', $this->container->get('file_system')->realpath($image->uri));
    $this->assertNotEmpty($assert->waitForElementVisible('css', '[data-drupal-iwc=wrapper]'));

    $offered = array_map(
      fn($element) => $element->getAttribute('data-drupal-iwc-id'),
      $page->findAll('css', '[data-drupal-iwc=type]')
    );
    $this->assertSame(self::CROP_TYPES, $offered, 'The five default shapes are offered, widest first');
  }

  /**
   * Tests that a crop set in the widget is stored and used by the styles.
   */
  public function testCropIsStoredAndApplied(): void {
    $page = $this->getSession()->getPage();
    $assert = $this->assertSession();

    $this->drupalGet('media/add/image');
    $image = $this->largestTestImage();
    $page->attachFileToField('files[field_media_image_0]', $this->container->get('file_system')->realpath($image->uri));
    $this->assertNotEmpty($assert->waitForElementVisible('css', '[data-drupal-iwc=wrapper]'));
    $page->fillField('name[0][value]', 'Cropped');
    $page->fillField('field_media_image[0][alt]', 'Cropped');

    $page->find('css', '[data-drupal-iwc=wrapper] > summary')->click();
    $page->find('css', 'a.vertical-tabs__menu-link[href^="#edit-field-media-image-0-image-crop-crop-wrapper-16-9"]')->click();
    $this->assertNotEmpty($assert->waitForElementVisible('css', '[data-drupal-iwc-id="16_9"] .cropper-container'));

    // The widget records the crop on cropend.
    $this->getSession()->executeScript(<<<JS
      (function () {
        var image = jQuery('[data-drupal-iwc-id="16_9"] [data-drupal-iwc=image]');
        image.data('cropper').setData({x: 0, y: 0, width: 160, height: 90});
        image.trigger('cropend');
      })();
    JS);
    $this->assertJsCondition('jQuery(\'input[data-drupal-iwc-value=applied][data-drupal-iwc-id="16_9"]\').val() == "1"');

    $page->pressButton('Save');
    $assert->waitForText('Cropped');

    $media = Media::load(1);
    $this->assertNotNull($media);
    $file = File::load($media->get('field_media_image')->target_id);
    $crop = Crop::findCrop($file->getFileUri(), '16_9');
    $this->assertNotNull($crop);
    $this->assertSame(160, (int) $crop->size()['width']);
    $this->assertSame(90, (int) $crop->size()['height']);
    $this->assertNull(Crop::findCrop($file->getFileUri(), '4_3'), 'Shapes that were not touched have no crop');

    $style = ImageStyle::load('localgov_16_9_384');
    $derivative = $style->buildUri($file->getFileUri());
    $this->assertTrue($style->createDerivative($file->getFileUri(), $derivative));
    $size = getimagesize($this->container->get('file_system')->realpath($derivative));
    $this->assertSame([384, 216], [$size[0], $size[1]], 'The stored crop is applied, then scaled to 384 wide');
  }

  /**
   * Returns the largest of core's test images.
   *
   * @return object
   *   The file object, with a uri property.
   */
  protected function largestTestImage(): object {
    $largest = NULL;
    foreach ($this->getTestFiles('image') as $file) {
      $size = getimagesize($this->container->get('file_system')->realpath($file->uri));
      if ($size && (!$largest || $size[0] > $largest[0])) {
        $largest = [$size[0], $file];
      }
    }
    return $largest[1];
  }

}
