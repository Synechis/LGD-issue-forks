<?php

namespace Drupal\localgov_events\Hook;

use Drupal\date_recur\DateRecurOccurrences;
use Drupal\localgov_events\Form\EventsAddEditCallbacks;
use Drupal\Core\Form\FormStateInterface;
use Drupal\localgov_roles\RolesHelper;
use Drupal\Core\Hook\Attribute\Hook;
use Drupal\Core\StringTranslation\StringTranslationTrait;

/**
 * Hook implementations for localgov_events.
 */
class LocalgovEventsHooks {
  use StringTranslationTrait;

  /**
   * Implements hook_theme().
   */
  #[Hook('theme')]
  public function theme($existing, $type, $theme, $path) {
    return [
      'node__localgov_event__teaser' => [
        'template' => 'node--localgov-event--teaser',
        'base hook' => 'node',
      ],
    ];
  }

  /**
   * Implements hook_localgov_roles_default().
   */
  #[Hook('localgov_roles_default')]
  public function localgovRolesDefault(): array {
    // Content editing permissions.
    $perms = [
      RolesHelper::EDITOR_ROLE => [
        'create localgov_event content',
        'delete any localgov_event content',
        'delete localgov_event revisions',
        'delete own localgov_event content',
        'edit any localgov_event content',
        'edit own localgov_event content',
        'revert localgov_event revisions',
        'view localgov_event revisions',
        'create terms in localgov_event_category',
        'create terms in localgov_event_locality',
        'create terms in localgov_event_price',
        'delete terms in localgov_event_category',
        'delete terms in localgov_event_locality',
        'delete terms in localgov_event_price',
        'edit terms in localgov_event_category',
        'edit terms in localgov_event_locality',
        'edit terms in localgov_event_price',
        'view term revisions in localgov_event_category',
        'view term revisions in localgov_event_locality',
        'view term revisions in localgov_event_price',
      ],
      RolesHelper::AUTHOR_ROLE => [
        'create localgov_event content',
        'delete own localgov_event content',
        'edit own localgov_event content',
        'revert localgov_event revisions',
        'view localgov_event revisions',
      ],
      RolesHelper::CONTRIBUTOR_ROLE => [
        'create localgov_event content',
        'delete own localgov_event content',
        'edit own localgov_event content',
        'view localgov_event revisions',
      ],
    ];
    // Content scheduling permissions required by localgov_workflows.
    if (\Drupal::moduleHandler()->moduleExists('localgov_workflows')) {
      $perms[RolesHelper::EDITOR_ROLE] = array_merge($perms[RolesHelper::EDITOR_ROLE], [
        'add scheduled transitions node localgov_event',
        'reschedule scheduled transitions node localgov_event',
        'view scheduled transitions node localgov_event',
      ]);
      $perms[RolesHelper::AUTHOR_ROLE] = array_merge($perms[RolesHelper::AUTHOR_ROLE], [
        'add scheduled transitions node localgov_event',
        'reschedule scheduled transitions node localgov_event',
        'view scheduled transitions node localgov_event',
      ]);
      $perms[RolesHelper::CONTRIBUTOR_ROLE] = array_merge($perms[RolesHelper::CONTRIBUTOR_ROLE], [
        'add scheduled transitions node localgov_event',
        'reschedule scheduled transitions node localgov_event',
        'view scheduled transitions node localgov_event',
      ]);
    }
    return $perms;
  }

  /**
   * Implements hook_page_attachments().
   */
  #[Hook('page_attachments')]
  public function pageAttachments(array &$attachments) {
    // Attach events styling library to events pages and views.
    $current_path = \Drupal::service('path.current')->getPath();
    if (substr($current_path, 0, 7) == '/events') {
      $attachments['#attached']['library'][] = 'localgov_events/events-styling';
    }
  }

  /**
   * Implements hook_modules_installed().
   */
  #[Hook('modules_installed')]
  public function modulesInstalled($modules, $is_syncing) {
    // Don't configure the extra fields during config sync operations.
    if ($is_syncing) {
      return;
    }
    // Configure optional fields.
    $directory_page = in_array('localgov_directories_page', $modules, TRUE);
    $directory_venue = in_array('localgov_directories_venue', $modules, TRUE);
    if ($directory_page) {
      \Drupal::service('config.installer')->installOptionalConfig(NULL, [
        'config' => 'node.type.localgov_directories_page',
      ]);
    }
    if ($directory_venue) {
      \Drupal::service('config.installer')->installOptionalConfig(NULL, [
        'config' => 'node.type.localgov_directories_venue',
      ]);
    }
    localgov_events_optional_fields_settings($directory_page, $directory_venue);
  }

  /**
   * Implements hook_form_BASE_FORM_ID_alter() for the views_exposed_form form.
   */
  #[Hook('form_views_exposed_form_alter')]
  public function formViewsExposedFormAlter(&$form, FormStateInterface $form_state, $form_id) {
    // Modify the events listing exposed filters to add a nice date widget.
    if (isset($form['#id']) && $form['#id'] == 'views-exposed-form-localgov-events-listing-page-all-events') {
      // Date selection options.
      $date_options = [
        'choose' => $this->t('Choose date range'),
        'today' => $this->t('Today'),
        'tomorrow' => $this->t('Tomorrow'),
        'this_week' => $this->t('This week'),
        'this_month' => $this->t('This month'),
        'next_month' => $this->t('Next month'),
      ];
      $form['#attached']['library'][] = 'localgov_events/date-picker';
      $form['date_picker'] = [
        '#type' => 'fieldset',
        '#title' => $this->t('Dates'),
        '#attributes' => [
          'class' => [
            'date-picker',
          ],
        ],
      ];
      $form['date_picker']['dates'] = [
        '#type' => 'select',
        '#title' => $this->t('Date range'),
        '#options' => $date_options,
        '#default_value' => 'choose',
        '#attributes' => [
          'class' => [
            'js-date-picker',
          ],
        ],
      ];
      $form['date_picker']['start'] = [
        '#type' => 'date',
        '#title' => $this->t('Start date'),
        '#date_date_format' => 'Y-m-d',
        '#attributes' => [
          'type' => 'date',
          'class' => [
            'js-date-picker-start',
          ],
        ],
      ];
      unset($form['start']);
      $form['date_picker']['end'] = [
        '#type' => 'date',
        '#title' => $this->t('End date'),
        '#date_date_format' => 'Y-m-d',
        '#attributes' => [
          'type' => 'date',
          'class' => [
            'js-date-picker-end',
          ],
        ],
      ];
      unset($form['end']);
    }
  }

  /**
   * Implements hook_form_FORM_ID_alter() for node_localgov_event_form form.
   */
  #[Hook('form_node_localgov_event_form_alter')]
  public function formNodeLocalgovEventFormAlter(&$form, FormStateInterface $form_state, $form_id) {
    // Configure node add form.
    EventsAddEditCallbacks::configureNodeForm($form);
  }

  /**
   * Implements hook_form_FORM_ID_alter() for node_localgov_event_edit_form form.
   */
  #[Hook('form_node_localgov_event_edit_form_alter')]
  public function formNodeLocalgovEventEditFormAlter(&$form, FormStateInterface $form_state, $form_id) {
    // Configure node edit form.
    EventsAddEditCallbacks::configureNodeForm($form);
  }

  /**
   * Implements hook_cron().
   *
   * Regenerate the occurrence cache for infinite recurring events whose
   * pre-generated occurrences are approaching expiry. This prevents infinite
   * events from falling off calendar views after the initial cache window.
   */
  #[Hook('cron')]
  public function cron(): void {
    // Only run this check once per day.
    $state = \Drupal::state();
    $last_run = $state->get('localgov_events.infinite_cache_last_run', 0);
    $request_time = \Drupal::time()->getRequestTime();
    if ($request_time - $last_run < 86400) {
      return;
    }
    $state->set('localgov_events.infinite_cache_last_run', $request_time);
    try {
      // Verify the localgov_event_date field exists and is a date_recur field.
      $fieldDefinitions = \Drupal::service('entity_field.manager')->getFieldDefinitions('node', 'localgov_event');
      if (!isset($fieldDefinitions['localgov_event_date']) || $fieldDefinitions['localgov_event_date']->getType() !== 'date_recur') {
        return;
      }
      $database = \Drupal::database();
      $fieldStorageDefinitions = \Drupal::service('entity_field.manager')->getFieldStorageDefinitions('node');
      $occurrenceTableName = DateRecurOccurrences::getOccurrenceCacheStorageTableName($fieldStorageDefinitions['localgov_event_date']);
      // Find entity IDs of infinite events.
      $infiniteEvents = $database->select('node__localgov_event_date', 'fd')->fields('fd', [
        'entity_id',
      ])->condition('fd.localgov_event_date_infinite', 1)->distinct(TRUE)->execute()->fetchCol();
      if (empty($infiniteEvents)) {
        return;
      }
      // Regenerate when the last cached occurrence is within the next year.
      $threshold = new \DateTime('now');
      $threshold->add(new \DateInterval('P1Y'));
      $thresholdFormatted = $threshold->format('Y-m-d\TH:i:s');
      $count = 0;
      foreach ($infiniteEvents as $entityId) {
        // Get the max cached end date for this event.
        $maxDate = $database->select($occurrenceTableName, 'oc')->fields('oc', [
          'localgov_event_date_end_value',
        ])->condition('oc.entity_id', $entityId)->orderBy('oc.localgov_event_date_end_value', 'DESC')->range(0, 1)->execute()->fetchField();
        // If max cached date is within the threshold, re-save the node to
        // trigger date_recur to regenerate the occurrence cache.
        if ($maxDate && $maxDate < $thresholdFormatted) {
          $node = \Drupal::entityTypeManager()->getStorage('node')->load($entityId);
          if ($node) {
            $node->save();
            \Drupal::logger('localgov_events')->info('Regenerated occurrence cache for infinite event @id.', [
              '@id' => $entityId,
            ]);
            $count++;
          }
        }
        // Limit to 50 nodes per cron run to avoid timeouts.
        if ($count >= 50) {
          break;
        }
      }
    }
    catch (\Exception $e) {
      \Drupal::logger('localgov_events')->error('Error regenerating infinite event cache: @message', [
        '@message' => $e->getMessage(),
      ]);
    }
  }

}
