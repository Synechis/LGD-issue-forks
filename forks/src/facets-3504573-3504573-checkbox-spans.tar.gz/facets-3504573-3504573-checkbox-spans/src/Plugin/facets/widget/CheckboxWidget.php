<?php

namespace Drupal\facets\Plugin\facets\widget;

use Drupal\Core\Form\FormStateInterface;
use Drupal\facets\FacetInterface;
use Drupal\facets\Result\ResultInterface;

/**
 * The checkbox / radios widget.
 *
 * @FacetsWidget(
 *   id = "checkbox",
 *   label = @Translation("List of checkboxes"),
 *   description = @Translation("A configurable widget that shows a list of checkboxes"),
 * )
 */
class CheckboxWidget extends LinksWidget {

  /**
   * {@inheritdoc}
   */
  public function defaultConfiguration() {
    return ['use_span_elements' => FALSE] + parent::defaultConfiguration();
  }

  /**
   * {@inheritdoc}
   */
  protected function buildListItems(FacetInterface $facet, ResultInterface $result) {
    $items = parent::buildListItems($facet, $result);

    $items['#attributes']['data-drupal-facet-widget-element-class'] = 'facets-checkbox';

    // A span without #value renders its child elements inside the tag, so
    // move the nested list of children out of the hidden span.
    if (!empty($this->getConfiguration()['use_span_elements']) && isset($items['children'])) {
      $children = $items['children'];
      $wrapper_attributes = $items['#wrapper_attributes'];
      unset($items['children'], $items['#wrapper_attributes']);
      $items = [
        '#wrapper_attributes' => $wrapper_attributes,
        'item' => $items,
        'children' => $children,
      ];
    }

    return $items;
  }

  /**
   * {@inheritdoc}
   */
  protected function prepareLink(ResultInterface $result) {
    if (empty($this->getConfiguration()['use_span_elements']) || is_null($result->getUrl())) {
      return parent::prepareLink($result);
    }

    // Render a span instead of a link, so crawlers don't follow a link for
    // every combination of facets. The JS reads the URL from the attribute.
    return [
      '#type' => 'html_tag',
      '#tag' => 'span',
      '#attributes' => ['data-facet-url' => $result->getUrl()->toString()],
      'item' => $this->buildResultItem($result),
    ];
  }

  /**
   * {@inheritdoc}
   */
  public function buildConfigurationForm(array $form, FormStateInterface $form_state, FacetInterface $facet) {
    $form = parent::buildConfigurationForm($form, $form_state, $facet);

    $form['use_span_elements'] = [
      '#type' => 'checkbox',
      '#title' => $this->t('Use span elements instead of links'),
      '#description' => $this->t('Renders the hidden facet items as span elements with a data-facet-url attribute instead of links, so search engines do not crawl every facet combination.'),
      '#default_value' => $this->getConfiguration()['use_span_elements'],
    ];

    return $form;
  }

  /**
   * {@inheritdoc}
   */
  protected function appendWidgetLibrary(array &$build) {
    $build['#attributes']['class'][] = 'js-facets-checkbox-links';
    $build['#attached']['library'][] = 'facets/drupal.facets.checkbox-widget';
  }

}
