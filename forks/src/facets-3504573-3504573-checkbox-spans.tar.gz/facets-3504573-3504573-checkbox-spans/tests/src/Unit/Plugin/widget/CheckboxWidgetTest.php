<?php

namespace Drupal\Tests\facets\Unit\Plugin\widget;

use Drupal\Core\Routing\UrlGeneratorInterface;
use Drupal\facets\Plugin\facets\widget\CheckboxWidget;
use Drupal\facets\Result\Result;

/**
 * Unit test for widget.
 *
 * @group facets
 */
class CheckboxWidgetTest extends WidgetTestBase {

  /**
   * Creates a new processor object for use in the tests.
   */
  protected function setUp(): void {
    parent::setUp();

    $this->widget = new CheckboxWidget(['show_numbers' => TRUE], 'checkbox_widget', [], $this->urlProcessorManager, $this->facetsUrlGenerator, $this->requestStack);
  }

  /**
   * Tests widget without filters.
   */
  public function testNoFilterResults() {
    $facet = $this->facet;
    $facet->setResults($this->originalResults);

    $output = $this->widget->build($facet);

    $this->assertSame('array', gettype($output));
    $this->assertCount(4, $output['#items']);

    $this->assertEquals(['facet-inactive', 'js-facets-checkbox-links'], $output['#attributes']['class']);

    $expected_links = [
      $this->buildLinkAssertion('Llama', 'llama', $facet, 10),
      $this->buildLinkAssertion('Badger', 'badger', $facet, 20),
      $this->buildLinkAssertion('Duck', 'duck', $facet, 15),
      $this->buildLinkAssertion('Alpaca', 'alpaca', $facet, 9),
    ];
    foreach ($expected_links as $index => $value) {
      $this->assertSame('array', gettype($output['#items'][$index]));
      $this->assertEquals($value, $output['#items'][$index]['#title']);
      $this->assertSame('array', gettype($output['#items'][$index]['#title']));
      $this->assertEquals('link', $output['#items'][$index]['#type']);
      $this->assertEquals(['facet-item'], $output['#items'][$index]['#wrapper_attributes']['class']);
    }
  }

  /**
   * {@inheritdoc}
   */
  public function testDefaultConfiguration() {
    $default_config = $this->widget->defaultConfiguration();
    $this->assertArrayHasKey('show_numbers', $default_config);
    $this->assertArrayHasKey('soft_limit', $default_config);
    $this->assertArrayHasKey('show_reset_link', $default_config);
    $this->assertArrayHasKey('reset_text', $default_config);
    $this->assertArrayHasKey('soft_limit_settings', $default_config);
    $this->assertArrayHasKey('show_less_label', $default_config['soft_limit_settings']);
    $this->assertArrayHasKey('show_more_label', $default_config['soft_limit_settings']);

    $this->assertArrayHasKey('use_span_elements', $default_config);

    $this->assertEquals(FALSE, $default_config['show_numbers']);
    $this->assertEquals(0, $default_config['soft_limit']);
    $this->assertEquals(FALSE, $default_config['show_reset_link']);
    $this->assertEquals(FALSE, $default_config['use_span_elements']);
  }

  /**
   * Tests the span elements option with an expanded hierarchy.
   */
  public function testSpanElements() {
    $url_generator = $this->createMock(UrlGeneratorInterface::class);
    $url_generator->method('generateFromRoute')->willReturn('/test?f[0]=llama');
    \Drupal::getContainer()->set('url_generator', $url_generator);

    $facet = $this->facet;
    $original_results = $this->originalResults;
    $child = new Result($facet, 'snake', 'Snake', 5);
    $child->setUrl($original_results[0]->getUrl());
    $original_results[1]->setActiveState(TRUE);
    $original_results[1]->setChildren([$child]);
    $facet->setResults($original_results);

    $this->widget->setConfiguration(['show_numbers' => TRUE, 'use_span_elements' => TRUE]);
    $output = $this->widget->build($facet);
    $this->assertCount(4, $output['#items']);

    // Items without children are the span itself.
    $span = $output['#items'][0];
    $this->assertEquals('html_tag', $span['#type']);
    $this->assertEquals('span', $span['#tag']);
    $this->assertEquals('/test?f[0]=llama', $span['#attributes']['data-facet-url']);
    $this->assertEquals('llama', $span['#attributes']['data-drupal-facet-item-value']);
    $this->assertEquals('facets-checkbox', $span['#attributes']['data-drupal-facet-widget-element-class']);
    $this->assertEquals($this->buildLinkAssertion('Llama', 'llama', $facet, 10), $span['item']);
    $this->assertEquals(['facet-item'], $span['#wrapper_attributes']['class']);
    $this->assertArrayNotHasKey('children', $span);

    // The children of an expanded item are rendered next to the span, not in
    // it.
    $item = $output['#items'][1];
    $this->assertEquals(['facet-item', 'facet-item--expanded'], $item['#wrapper_attributes']['class']);
    $this->assertArrayNotHasKey('#type', $item);
    $this->assertEquals('span', $item['item']['#tag']);
    $this->assertEquals(['is-active'], $item['item']['#attributes']['class']);
    $this->assertArrayNotHasKey('children', $item['item']);
    $this->assertArrayNotHasKey('#wrapper_attributes', $item['item']);
    $this->assertCount(1, $item['children']['#items']);
    $this->assertEquals('span', $item['children']['#items'][0]['#tag']);
    $this->assertEquals('snake', $item['children']['#items'][0]['#attributes']['data-drupal-facet-item-value']);
  }

}
