<?php

/**
 * @file
 * Post-update hooks for the LocalGov Base Theme.
 */

/**
 * Update to reset number of top tasks per row on existing sites back to 3.
 */
function localgov_base_post_update_reset_top_tasks_per_row(array &$sandbox = NULL) {
  // Load the theme settings.
  $theme = \Drupal::theme()->getActiveTheme()->getName();
  $theme_settings = \Drupal::configFactory()->getEditable("{$theme}.settings");

  // Reset the number of top tasks per row to 3.
  // Check to see if the setting exists before updating.
  if ($theme_settings->get('localgov_base_services_top_tasks_per_row') === NULL) {
    $theme_settings->set('localgov_base_services_top_tasks_per_row', 3);
    $theme_settings->save();
    return t("Reset number of top tasks per row to 3 for the {$theme} theme.");
  }
  else {
    return t('No update needed. The setting for number of top tasks per row already exists.');
  }


}
