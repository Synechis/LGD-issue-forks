<?php

namespace Drupal\localgov_page\Hook;

use Drupal\Core\Hook\Attribute\Hook;

/**
 * Hook implementations for localgov_page.
 */
class LocalgovPageHooks {
  /**
   * @file
   * LocalGov Page module file.
   */

  /**
   * Implements hook_preprocess_HOOK().
   */
  #[Hook('preprocess_node')]
  public function preprocessNode(&$variables): void {
    $variables['view_mode'] = $variables['elements']['#view_mode'];
    $variables['node'] = $variables['elements']['#node'];
    $variables['content_type'] = $variables['node']->getType();
    if ($variables['view_mode'] === 'full' && $variables['content_type'] === 'localgov_page') {
      if (isset($variables['node']->get('localgov_hide_summary')[0])) {
        if ($variables['node']->get('localgov_hide_summary')[0]->getValue()['value'] === '1') {
          unset($variables['content']['localgov_page_summary'][0]);
        }
      }
    }
  }

}
