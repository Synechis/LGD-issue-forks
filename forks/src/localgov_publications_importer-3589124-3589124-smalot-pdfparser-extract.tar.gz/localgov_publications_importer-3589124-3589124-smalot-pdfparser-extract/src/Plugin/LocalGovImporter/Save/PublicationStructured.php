<?php

namespace Drupal\localgov_publications_importer\Plugin\LocalGovImporter\Save;

use Drupal\Core\Entity\EntityFieldManagerInterface;
use Drupal\Core\StringTranslation\TranslatableMarkup;
use Drupal\localgov_publications_importer\Attribute\Save;
use Drupal\localgov_publications_importer\ImportInterface;
use Drupal\localgov_publications_importer\Plugin\ParagraphTypesProviderInterface;
use Drupal\localgov_publications_importer\Service\ParagraphSchemaDiscovery;
use Drupal\node\NodeInterface;
use Drupal\paragraphs\Entity\Paragraph;
use Symfony\Component\DependencyInjection\ContainerInterface;

/**
 * Save operation that creates publications using structured paragraph types.
 *
 * When a page carries an array from getContent(), each element is passed to
 * ParagraphSchemaDiscovery::createParagraphFromData() to create the
 * appropriate paragraph entity. Falls back to the parent localgov_text
 * behaviour when getContent() returns a plain HTML string.
 */
#[Save(
  id: 'save_publication_structured',
  label: new TranslatableMarkup('Publication (structured paragraphs)'),
  description: new TranslatableMarkup('Save operation that creates an HTML publication using typed paragraph entities.')
)]
class PublicationStructured extends PublicationBase implements ParagraphTypesProviderInterface {

  /**
   * The node type this plugin saves to.
   */
  protected const NODE_TYPE = 'localgov_publication_page';

  /**
   * The field on the node type that holds paragraph content.
   */
  protected const CONTENT_FIELD = 'localgov_publication_content';

  /**
   * {@inheritdoc}
   */
  public static function create(ContainerInterface $container, array $configuration, $plugin_id, $plugin_definition) {
    return new static(
      $configuration,
      $plugin_id,
      $plugin_definition,
      $container->get('entity_type.manager'),
      $container->get('Drupal\localgov_publications_importer\Service\ParagraphSchemaDiscovery'),
      $container->get('entity_field.manager'),
    );
  }

  /**
   * Constructor.
   */
  public function __construct(
    array $configuration,
    $plugin_id,
    $plugin_definition,
    $entityTypeManager,
    protected ParagraphSchemaDiscovery $paragraphSchemaDiscovery,
    protected EntityFieldManagerInterface $entityFieldManager,
  ) {
    parent::__construct($configuration, $plugin_id, $plugin_definition, $entityTypeManager);
  }

  /**
   * {@inheritdoc}
   */
  public function getAllowedParagraphTypes(): array {
    $definitions = $this->entityFieldManager->getFieldDefinitions('node', self::NODE_TYPE);
    if (!isset($definitions[self::CONTENT_FIELD])) {
      return [];
    }
    $handlerSettings = $definitions[self::CONTENT_FIELD]->getSetting('handler_settings');
    return array_keys($handlerSettings['target_bundles'] ?? []);
  }

  /**
   * {@inheritDoc}
   */
  public function import(ImportInterface $import): ?NodeInterface {

    $rootPage = NULL;
    $weight = 0;
    $nodeStorage = $this->entityTypeManager->getStorage('node');

    foreach ($import->getPages() as $page) {

      if ($rootPage === NULL) {
        $book = ['bid' => 'new'];
      }
      else {
        $book = [
          'bid' => $rootPage->id(),
          'pid' => $rootPage->id(),
          'weight' => $weight++,
        ];
      }

      // Create a layout paragraph to hold our text.
      $layoutParagraph = Paragraph::create([
        'type' => 'localgov_page_section',
      ]);
      $layoutParagraph->setBehaviorSettings('layout_paragraphs', [
        'region' => '',
        'parent_uuid' => '',
        'layout' => 'layout_onecol',
        'config' => ['label' => ''],
      ]);
      $layoutParagraph->save();

      $paragraphs = [$layoutParagraph];

      /** @var \Drupal\node\NodeInterface $publicationPage */
      $publicationPage = $nodeStorage->create([
        'type' => 'localgov_publication_page',
        'title' => $page->getTitle(),
        'uid' => $import->getCreator()->id(),
        'book' => $book,
      ]);

      $pageContent = $page->getContent();
      assert(is_array($pageContent), 'PublicationStructured save plugin expects array content.');

      // Structured path: create a typed paragraph entity for each item.
      foreach ($pageContent as $paragraphData) {
        $paragraph = $this->paragraphSchemaDiscovery->createParagraphFromData($paragraphData);
        $paragraph->setBehaviorSettings('layout_paragraphs', [
          'region' => 'content',
          'parent_uuid' => $layoutParagraph->uuid(),
          'layout' => '',
          'config' => [],
        ]);
        $paragraph->save();
        $paragraphs[] = $paragraph;
      }

      $publicationContentField = $publicationPage->get('localgov_publication_content');

      unset($paragraph);

      foreach ($paragraphs as $paragraph) {
        $publicationContentField->appendItem([
          'target_id' => $paragraph->id(),
          'target_revision_id' => $paragraph->getRevisionId(),
        ]);
      }

      $publicationPage->save();

      if ($rootPage === NULL) {
        $rootPage = $publicationPage;
      }
    }

    $coverPage = $this->createCoverPage($rootPage, $import);
    if ($coverPage instanceof NodeInterface) {
      // If we made or used a cover page, return that as the result.
      return $coverPage;
    }

    // No cover page - return the publication root.
    return $rootPage;
  }

}
