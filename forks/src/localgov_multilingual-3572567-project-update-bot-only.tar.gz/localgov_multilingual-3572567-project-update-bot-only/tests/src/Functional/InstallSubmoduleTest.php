<?php

declare(strict_types=1);

namespace Drupal\Tests\localgov_multilingual\Functional;

use PHPUnit\Framework\Attributes\RunTestsInSeparateProcesses;
use Drupal\Tests\BrowserTestBase;
use Symfony\Component\HttpFoundation\Response;

/**
 * Tests submodule installs do not break front page.
 */
#[RunTestsInSeparateProcesses]
class InstallSubmoduleTest extends BrowserTestBase {

  /**
   * {@inheritdoc}
   */
  protected $defaultTheme = 'stark';

  /**
   * {@inheritdoc}
   */
  protected $strictConfigSchema = FALSE; // phpcs:ignore.

  /**
   * {@inheritdoc}
   */
  protected static $modules = [
    'node',
    'block',
    'system',
    'user',
    'field',
    'text',
    'options',
    'media',
    'geo_entity',
    'address',
    'leaflet',
    'datetime',
    'menu_ui',
    'localgov_core',
    'localgov_media',
  ];

  /**
   * Test alert_banners submodule install.
   */
  public function testAlertBannersInstallTest(): void {
    $this->installModule('localgov_multilingual_alert_banners');
    $this->drupalGet('<front>');
    $this->assertSession()->statusCodeEquals(Response::HTTP_OK);
  }

  /**
   * Test blogs submodule install.
   */
  public function testBlogsInstallTest(): void {
    $this->installModule('localgov_multilingual_blogs');
    $this->drupalGet('<front>');
    $this->assertSession()->statusCodeEquals(Response::HTTP_OK);
  }

  /**
   * Test directories submodule install.
   */
  public function testDirectoriesInstallTest(): void {
    $this->installModule('localgov_multilingual_directories');
    $this->drupalGet('<front>');
    $this->assertSession()->statusCodeEquals(Response::HTTP_OK);
  }

  /**
   * Test directory_organisation submodule install.
   */
  public function testDirectoryOrganisationInstallTest(): void {
    $this->installModule('localgov_multilingual_directory_organisation');
    $this->drupalGet('<front>');
    $this->assertSession()->statusCodeEquals(Response::HTTP_OK);
  }

  /**
   * Test directory_promo submodule install.
   */
  public function testDirectoryPromoInstallTest(): void {
    $this->installModule('localgov_multilingual_directory_promo');
    $this->drupalGet('<front>');
    $this->assertSession()->statusCodeEquals(Response::HTTP_OK);
  }

  /**
   * Test events submodule install.
   */
  public function testEventsInstallTest(): void {
    $this->installModule('localgov_multilingual_events');
    $this->drupalGet('<front>');
    $this->assertSession()->statusCodeEquals(Response::HTTP_OK);
  }

  /**
   * Test guides submodule install.
   */
  public function testGuidesInstallTest(): void {
    $this->installModule('localgov_multilingual_guides');
    $this->drupalGet('<front>');
    $this->assertSession()->statusCodeEquals(Response::HTTP_OK);
  }

  /**
   * Test irish_planning_notices submodule install.
   */
  public function testIrishPlanningNoticesInstallTest(): void {
    $this->installModule('localgov_multilingual_irish_planning_notices');
    $this->drupalGet('<front>');
    $this->assertSession()->statusCodeEquals(Response::HTTP_OK);
  }

  /**
   * Test news submodule install.
   */
  public function testNewsInstallTest(): void {
    $this->installModule('localgov_multilingual_news');
    $this->drupalGet('<front>');
    $this->assertSession()->statusCodeEquals(Response::HTTP_OK);
  }

  /**
   * Test services submodule install.
   */
  public function testServicesInstallTest(): void {
    $this->installModule('localgov_multilingual_services');
    $this->drupalGet('<front>');
    $this->assertSession()->statusCodeEquals(Response::HTTP_OK);
  }

  /**
   * Test step_by_step submodule install.
   */
  public function testStepByStepInstallTest(): void {
    $this->installModule('localgov_multilingual_step_by_step');
    $this->drupalGet('<front>');
    $this->assertSession()->statusCodeEquals(Response::HTTP_OK);
  }

  /**
   * Test subsites submodule install.
   */
  public function testSubsitesInstallTest(): void {
    $this->installModule('localgov_multilingual_subsites');
    $this->drupalGet('<front>');
    $this->assertSession()->statusCodeEquals(Response::HTTP_OK);
  }

  /**
   * Helper method to install a module and its dependencies.
   *
   * @param string $module_name
   *   The machine name of the module to install.
   */
  protected function installModule(string $module_name): void {
    $this->container->get('module_installer')->install([$module_name]);
    $this->resetAll();
  }

}
