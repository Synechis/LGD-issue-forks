<?php

declare(strict_types=1);

namespace Drupal\Tests\localgov_multilingual\Functional;

use PHPUnit\Framework\Attributes\RunTestsInSeparateProcesses;
use Drupal\Tests\BrowserTestBase;
use Symfony\Component\HttpFoundation\Response;

/**
 * Tests main module install does not break front page.
 */
#[RunTestsInSeparateProcesses]
class InstallTest extends BrowserTestBase {

  /**
   * {@inheritdoc}
   */
  protected $defaultTheme = 'stark';

  /**
   * {@inheritdoc}
   */
  protected static $modules = [
    'node',
    'block',
    'system',
    'user',
    'field',
    'text',
    'options',
  ];

  /**
   * Test main module install does not break front page.
   */
  public function testMainModuleInstallTest(): void {
    $this->installModule('localgov_multilingual');
    $this->drupalGet('<front>');
    $this->assertSession()->statusCodeEquals(Response::HTTP_OK);
  }

  /**
   * Helper method to install a module and its dependencies.
   *
   * @param string $module_name
   *   The machine name of the module to install.
   */
  protected function installModule(string $module_name): void {
    $this->container->get('module_installer')->install([$module_name]);
    $this->resetAll();
  }

}
