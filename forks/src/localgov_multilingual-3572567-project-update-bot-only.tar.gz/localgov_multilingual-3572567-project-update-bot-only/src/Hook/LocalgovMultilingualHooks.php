<?php

namespace Drupal\localgov_multilingual\Hook;

use Drupal\Core\Hook\Attribute\Hook;

/**
 * Hook implementations for localgov_multilingual.
 */
class LocalgovMultilingualHooks {
  /**
   * @file
   * Primary module hooks for LocalGov Services: Multilingual module.
   */

  /**
   * Implements hook_preprocess_HOOK().
   */
  #[Hook('preprocess_block')]
  public function preprocessBlock(&$variables) {
    if ($variables['derivative_plugin_id'] == 'language_interface') {
      $variables['content']['#attached']['library'][] = 'localgov_multilingual/localgov-multilingual';
    }
  }

}
