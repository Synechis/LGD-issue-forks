<?php

declare(strict_types=1);

namespace Drupal\Tests\localgov_forms_email_draft_link\Unit;

use Drupal\Core\Entity\EntityInterface;
use Drupal\Tests\UnitTestCase;
use Drupal\localgov_forms_email_draft_link\Plugin\WebformHandler\EmailDraftLink;
use Drupal\webform\WebformSubmissionInterface;

/**
 * Unit tests for the EmailDraftLink handler's recipient validation.
 *
 * @coversDefaultClass \Drupal\localgov_forms_email_draft_link\Plugin\WebformHandler\EmailDraftLink
 * @group localgov_forms_email_draft_link
 */
class EmailDraftLinkTest extends UnitTestCase {

  /**
   * A token that resolves to an empty string is not a valid recipient.
   *
   * @covers ::hasValidToAddress
   */
  public function testEmptyResolvingTokenHasNoValidToAddress(): void {
    $handler = new TestEmailDraftLink(['[webform_submission:values:email]'], []);
    $submission = $this->createMock(WebformSubmissionInterface::class);

    $this->assertFalse($handler->hasValidToAddress($submission));
  }

  /**
   * A token that resolves to a valid email address is a valid recipient.
   *
   * @covers ::hasValidToAddress
   */
  public function testValidEmailHasValidToAddress(): void {
    $handler = new TestEmailDraftLink(
      ['[webform_submission:values:email]'],
      ['[webform_submission:values:email]' => 'resident@example.com'],
    );
    $submission = $this->createMock(WebformSubmissionInterface::class);

    $this->assertTrue($handler->hasValidToAddress($submission));
  }

}

/**
 * Test double that bypasses the container-bound parent collaborators.
 *
 * Overrides the three parent methods hasValidToAddress() depends on so the
 * recipient-resolution logic can be exercised in isolation.
 */
class TestEmailDraftLink extends EmailDraftLink {

  /**
   * Emails returned by the stubbed getMessageEmails().
   *
   * @var string[]
   */
  private array $emails;

  /**
   * Map of token text to its resolved value for the stubbed replaceTokens().
   *
   * @var array<string, string>
   */
  private array $tokenMap;

  /**
   * Constructs the test double without invoking the parent constructor.
   *
   * @param string[] $emails
   *   Raw (pre-token-replacement) email values.
   * @param array<string, string> $token_map
   *   Map of token text to resolved value.
   */
  public function __construct(array $emails, array $token_map) {
    $this->emails = $emails;
    $this->tokenMap = $token_map;
  }

  /**
   * {@inheritdoc}
   */
  public function getConfiguration() {
    return ['settings' => ['to_mail' => '[webform_submission:values:email]']];
  }

  /**
   * {@inheritdoc}
   */
  protected function getMessageEmails(WebformSubmissionInterface $webform_submission, $configuration_name, $configuration_value) {
    return $this->emails;
  }

  /**
   * {@inheritdoc}
   */
  protected function replaceTokens($text, ?EntityInterface $entity = NULL, array $data = [], array $options = []) {
    return $this->tokenMap[$text] ?? '';
  }

}
