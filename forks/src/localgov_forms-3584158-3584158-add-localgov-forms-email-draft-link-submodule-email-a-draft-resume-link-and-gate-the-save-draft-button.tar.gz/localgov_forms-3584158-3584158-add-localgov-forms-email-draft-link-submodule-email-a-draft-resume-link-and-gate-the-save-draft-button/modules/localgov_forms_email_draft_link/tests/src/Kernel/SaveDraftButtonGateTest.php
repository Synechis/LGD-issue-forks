<?php

declare(strict_types=1);

namespace Drupal\Tests\localgov_forms_email_draft_link\Kernel;

use Drupal\Component\Serialization\Yaml;
use Drupal\KernelTests\KernelTestBase;
use Drupal\localgov_forms_email_draft_link\Plugin\WebformHandler\EmailDraftLink;
use Drupal\webform\Entity\Webform;
use Drupal\webform\Entity\WebformSubmission;
use Drupal\webform\WebformInterface;

/**
 * Tests that the "Save draft" button is gated on a valid recipient email.
 *
 * @group localgov_forms_email_draft_link
 */
class SaveDraftButtonGateTest extends KernelTestBase {

  /**
   * {@inheritdoc}
   */
  protected static $modules = [
    'system',
    'user',
    'webform',
    'localgov_forms_email_draft_link',
  ];

  /**
   * {@inheritdoc}
   */
  protected function setUp(): void {
    parent::setUp();
    $this->installEntitySchema('user');
    $this->installEntitySchema('webform_submission');
    $this->installSchema('webform', ['webform']);
    $this->installConfig(['webform']);

    Webform::create([
      'id' => 'test_draft_link',
      'title' => 'Test draft link',
      'elements' => Yaml::encode([
        'email' => [
          '#type' => 'email',
          '#title' => 'Email',
        ],
      ]),
      'settings' => ['draft' => WebformInterface::DRAFT_ALL],
      'handlers' => [
        'email_draft_link' => [
          'id' => 'localgov_forms_email_draft_link',
          'handler_id' => 'email_draft_link',
          'label' => 'Email Draft Link',
          'status' => TRUE,
          'weight' => 0,
          'settings' => ['to_mail' => '[webform_submission:values:email]'],
        ],
      ],
    ])->save();
  }

  /**
   * The handler config resolves to our renamed plugin class.
   */
  public function testHandlerIsRegisteredUnderNewId(): void {
    $webform = Webform::load('test_draft_link');
    $handler = $webform->getHandler('email_draft_link');
    $this->assertInstanceOf(EmailDraftLink::class, $handler);
  }

  /**
   * The "Save draft" button is removed when no valid recipient is set.
   */
  public function testDraftButtonHiddenWithoutValidRecipient(): void {
    $submission = WebformSubmission::create([
      'webform_id' => 'test_draft_link',
      'data' => ['email' => ''],
    ]);

    $form = ['actions' => ['draft' => ['#type' => 'submit', '#value' => 'Save draft']]];
    localgov_forms_email_draft_link_check_draft_email($form, $submission);

    $this->assertArrayNotHasKey('draft', $form['actions']);
  }

  /**
   * The "Save draft" button remains once a valid recipient is set.
   */
  public function testDraftButtonShownWithValidRecipient(): void {
    $submission = WebformSubmission::create([
      'webform_id' => 'test_draft_link',
      'data' => ['email' => 'resident@example.com'],
    ]);

    $form = ['actions' => ['draft' => ['#type' => 'submit', '#value' => 'Save draft']]];
    localgov_forms_email_draft_link_check_draft_email($form, $submission);

    $this->assertArrayHasKey('draft', $form['actions']);
  }

}
