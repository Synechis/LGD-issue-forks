<?php

declare(strict_types=1);

namespace Drupal\localgov_forms_email_draft_link\Plugin\WebformHandler;

use Drupal\Core\Form\FormStateInterface;
use Drupal\webform\Plugin\WebformHandler\EmailWebformHandler;
use Drupal\webform\Utility\WebformMailHelper;
use Drupal\webform\WebformSubmissionInterface;

/**
 * Emails a draft-resume link whenever a submission draft is saved.
 *
 * Extends the core email handler but locks its trigger states to "draft
 * created" and "draft updated", so the recipient (typically the form filler,
 * resolved from an email element via a token) receives a link to return to
 * their saved draft.
 *
 * Pairs with localgov_forms_email_draft_link_form_alter(), which hides the
 * "Save draft" button until the recipient email configured on this handler
 * resolves to a valid address — see hasValidToAddress().
 *
 * @WebformHandler(
 *   id = "localgov_forms_email_draft_link",
 *   label = @Translation("Email Draft Link"),
 *   category = @Translation("LocalGov Forms"),
 *   description = @Translation("Send a link on saving draft."),
 *   cardinality = \Drupal\webform\Plugin\WebformHandlerInterface::CARDINALITY_SINGLE,
 *   results = \Drupal\webform\Plugin\WebformHandlerInterface::RESULTS_PROCESSED,
 *   submission = \Drupal\webform\Plugin\WebformHandlerInterface::SUBMISSION_OPTIONAL,
 *   tokens = TRUE,
 * )
 */
class EmailDraftLink extends EmailWebformHandler {

  /**
   * {@inheritdoc}
   */
  public function defaultConfiguration() {
    $defaults = parent::defaultConfiguration();
    $defaults['states'] = [
      WebformSubmissionInterface::STATE_DRAFT_CREATED,
      WebformSubmissionInterface::STATE_DRAFT_UPDATED,
    ];
    return $defaults;
  }

  /**
   * {@inheritdoc}
   */
  public function buildConfigurationForm(array $form, FormStateInterface $form_state) {
    $form = parent::buildConfigurationForm($form, $form_state);

    $form['additional']['states'] = [
      '#type' => 'checkboxes',
      '#title' => $this->t('Send email'),
      '#options' => [
        WebformSubmissionInterface::STATE_DRAFT_CREATED => $this->t('…when <b>draft is created</b>.'),
        WebformSubmissionInterface::STATE_DRAFT_UPDATED => $this->t('…when <b>draft is updated</b>.'),
      ],
      '#access' => TRUE,
      '#disabled' => TRUE,
      '#default_value' => [
        WebformSubmissionInterface::STATE_DRAFT_CREATED,
        WebformSubmissionInterface::STATE_DRAFT_UPDATED,
      ],
    ];

    return $form;
  }

  /**
   * {@inheritdoc}
   */
  public function validateConfigurationForm(array &$form, FormStateInterface $form_state): void {
    parent::validateConfigurationForm($form, $form_state);
    $values = $form_state->getValues();
    $values['states'] = [
      WebformSubmissionInterface::STATE_DRAFT_CREATED,
      WebformSubmissionInterface::STATE_DRAFT_UPDATED,
    ];
    $form_state->setValues($values);
  }

  /**
   * Checks whether the configured "To" address resolves to a valid email.
   *
   * @param \Drupal\webform\WebformSubmissionInterface $webform_submission
   *   The submission whose data the "To" token is resolved against.
   *
   * @return bool
   *   TRUE if at least one resolved recipient is a valid email address.
   */
  public function hasValidToAddress(WebformSubmissionInterface $webform_submission): bool {
    $config = $this->getConfiguration();
    $emails = $this->getMessageEmails($webform_submission, 'to_mail', $config['settings']['to_mail']);
    foreach ($emails as $email) {
      $address = $this->replaceTokens($email, $webform_submission, [], ['clear' => TRUE]);
      if (WebformMailHelper::validateAddress($address)) {
        return TRUE;
      }
    }

    return FALSE;
  }

}
