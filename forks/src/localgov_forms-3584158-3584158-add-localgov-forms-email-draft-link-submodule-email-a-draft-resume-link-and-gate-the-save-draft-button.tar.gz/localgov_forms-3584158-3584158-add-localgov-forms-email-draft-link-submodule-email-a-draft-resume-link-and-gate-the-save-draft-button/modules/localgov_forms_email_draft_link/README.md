# LocalGov Forms - Email Draft Link

## What is it?

This module lets a webform email the person filling it in a link back to their
saved draft, so they can pick up where they left off.

It provides:

- An **Email Draft Link** webform handler (extending the core email handler)
  whose trigger is locked to "draft created" and "draft updated". When a draft
  is saved, it emails the configured recipient a link to resume it.
- A form alteration that **hides the "Save draft" button** until the handler's
  recipient email resolves to a valid address — so a draft is never saved with
  no address to send the resume link to.

## How to use it

- Install it like any other Drupal module from the "Extend" page.
- Make sure "Allow your users to save and finish the webform later" (draft
  saving) is enabled on the webform's settings.
- On the webform's **Emails / Handlers** tab, add the **Email Draft Link**
  handler. Set its "To" address to the form's email element token
  (e.g. `[webform_submission:values:email:raw]`) and compose the message body
  with a resume link using the `[webform_submission:token-update-url]` token.
- The resume-link token only produces a working link if the webform's
  "Allow users to update a submission using a secure token" setting is enabled
  (Settings → Submissions).
- The "Save draft" button stays hidden on the form until the filler enters a
  valid email in that element.

## Maintainers

Part of the LocalGov Drupal Forms project.
