<?php

namespace Drupal\finders\Plugin\Block;

use Drupal\Core\Block\Attribute\Block;
use Drupal\Core\Block\BlockBase;
use Drupal\Core\Cache\CacheableMetadata;
use Drupal\Core\Entity\ContentEntityInterface;
use Drupal\Core\Entity\EntityRepositoryInterface;
use Drupal\Core\Entity\EntityTypeManagerInterface;
use Drupal\Core\Form\FormBuilderInterface;
use Drupal\Core\Form\FormState;
use Drupal\Core\Plugin\ContainerFactoryPluginInterface;
use Drupal\Core\Plugin\Context\EntityContextDefinition;
use Drupal\Core\StringTranslation\TranslatableMarkup;
use Drupal\finders\Enum\FinderRole;
use Drupal\finders\Plugin\FinderType\FinderTypeInterface;
use Drupal\views\Form\ViewsExposedForm;
use Drupal\views\ViewExecutable;
use Drupal\views\Views;
use Symfony\Component\DependencyInjection\ContainerInterface;

/**
 * Shows the Views exposed filters of the channel view.
 *
 * This only works for entry entities which are nodes, because of the context
 * definition on the plugin definition.
 *
 * @todo Functional test for cache tag invalidation scenario.
 */
#[Block(
  id: 'finders_channel_search',
  admin_label: new TranslatableMarkup('Finders channel search'),
  context_definitions: [
    'node' => new EntityContextDefinition(
      data_type: 'entity:node',
    ),
  ],
)]
class ChannelSearchBlock extends BlockBase implements ContainerFactoryPluginInterface {

  /**
   * The entity type manager.
   *
   * @var \Drupal\Core\Entity\EntityTypeManagerInterface
   */
  protected $entityTypeManager;

  /**
   * The entity repository service.
   *
   * @var \Drupal\Core\Entity\EntityRepositoryInterface
   */
  protected $entityRepository;

  /**
   * The form builder service.
   *
   * @var \Drupal\Core\Form\FormBuilderInterface
   */
  protected $formBuilder;

  /**
   * {@inheritdoc}
   */
  public static function create(ContainerInterface $container, array $configuration, $plugin_id, $plugin_definition) {
    return new static(
      $configuration,
      $plugin_id,
      $plugin_definition,
      $container->get('entity_type.manager'),
      $container->get('entity.repository'),
      $container->get('form_builder'),
    );
  }

  /**
   * Creates a FindersChannelSearch instance.
   *
   * @param array $configuration
   *   A configuration array containing information about the plugin instance.
   * @param string $plugin_id
   *   The plugin_id for the plugin instance.
   * @param mixed $plugin_definition
   *   The plugin implementation definition.
   * @param \Drupal\Core\Entity\EntityTypeManagerInterface $entity_type_manager
   *   The entity type manager.
   * @param \Drupal\Core\Entity\EntityRepositoryInterface $entity_repository
   *   The entity repository service.
   * @param \Drupal\Core\Form\FormBuilderInterface $form_builder
   *   The form builder service.
   */
  public function __construct(
    array $configuration,
    $plugin_id,
    $plugin_definition,
    EntityTypeManagerInterface $entity_type_manager,
    EntityRepositoryInterface $entity_repository,
    FormBuilderInterface $form_builder,
  ) {
    parent::__construct($configuration, $plugin_id, $plugin_definition);
    $this->entityTypeManager = $entity_type_manager;
    $this->entityRepository = $entity_repository;
    $this->formBuilder = $form_builder;
  }

  /**
   * {@inheritdoc}
   */
  public function build() {
    /** @var \Drupal\node\NodeInterface $host_node */
    $host_node = $this->getContextValue('node');
    if (empty($host_node)) {
      return [];
    }

    // Get the finder for the host entity if one exists.
    $bundle_id = $host_node->bundle();
    $bundle_entity_type_id = $host_node->getEntityType()->getBundleEntityType();

    $bundle_entity = $this->entityTypeManager->getStorage($bundle_entity_type_id)->load($bundle_id);

    /** @var \Drupal\finders\Entity\FinderInterface $finder */
    $finder = $this->entityTypeManager->getStorage('finder')->getFinderForBundleEntity($bundle_entity);

    if (empty($finder)) {
      return [];
    }

    $finder_type = $finder->getFinderTypePlugin();

    $channel_view_id = $finder_type->getFinderTypeConstant('CHANNEL_VIEW');
    $channel_view = Views::getView($channel_view_id);

    if (empty($channel_view)) {
      return [];
    }

    $finder_role = $finder->getFinderRoleForBundle($bundle_entity);

    $build = match ($finder_role) {
      FinderRole::Channels => $this->getChannelForm($host_node, $channel_view),
      FinderRole::Entries => $this->getEntryForm($host_node, $finder_type),
    };

    return $build;
  }

  /**
   * Gets the Views exposed filter form for a channel entity.
   *
   * @param \Drupal\Core\Entity\ContentEntityInterface $channel_entity
   *   The channel entity.
   * @param \Drupal\views\ViewExecutable $channel_view
   *   The channel view.
   *
   * @return array
   *   A render array for the given view's exposed filter.
   */
  protected function getChannelForm(ContentEntityInterface $channel_entity, ViewExecutable $channel_view): array {
    $display_id = 'channel_embed';
    $channel_view->setDisplay($display_id);
    $channel_view->initHandlers();

    $form_state = (new FormState())
      ->setStorage([
        'view' => $channel_view,
        'display' => &$channel_view->display_handler->display,
        'rerender' => NULL,
        'parent-source' => self::class,
      ])
      ->setMethod('get')
      ->setAlwaysProcess()
      ->disableRedirect();

    $views_exposed_filter_form = $this->formBuilder->buildForm(ViewsExposedForm::class, $form_state);
    $views_exposed_filter_form['#id'] .= '-in-a-search-block';
    $views_exposed_filter_form['actions']['submit']['#value'] = $this->t('Search');

    // Add cacheability: this block depends on the view, and on the channel
    // node, since that could change the view that is used.
    $cacheability = CacheableMetadata::createFromRenderArray($views_exposed_filter_form);

    $cacheability->addCacheableDependency($channel_view);
    $cacheability->addCacheableDependency($channel_entity);

    $cacheability->applyTo($views_exposed_filter_form);

    return $views_exposed_filter_form;
  }

  /**
   * Gets the Views exposed filter form for an entry entity.
   */
  public function getEntryForm(ContentEntityInterface $entry_entity, FinderTypeInterface $finder_type): array {
    $forms = $form_list = [];

    $channels_field = $finder_type->getFinderTypeConstant('CHANNEL_SELECTION_FIELD');
    $view_field = $finder_type->getFinderTypeConstant('VIEW_FIELD');

    $cache_dependencies = [];
    foreach ($entry_entity->get($channels_field)->referencedEntities() as $delta => $channel_entity) {
      $view_id = $channel_entity->get($view_field)->target_id;

      $view = Views::getView($view_id);

      if (empty($view)) {
        continue;
      }

      $cache_dependencies[] = $channel_entity;
      $cache_dependencies[] = $view;

      $display_id = 'channel_embed';

      $view->setDisplay($display_id);
      $view->setArguments([$channel_entity->id()]);
      $view->initHandlers();

      $form_state = (new FormState())
        ->setStorage([
          'view' => $view,
          'display' => &$view->display_handler->display,
          'rerender' => NULL,
        ])
        ->setMethod('get')
        ->setAlwaysProcess()
        ->disableRedirect();

      $form = $this->formBuilder->buildForm(ViewsExposedForm::class, $form_state);

      $form['actions']['submit']['#value'] = $this->t('Search');
      $form['#action'] = $channel_entity->toUrl()->toString();
      $form['#attributes']['class'][] = $delta ? 'finders-search-channel-secondary' : 'finders-search-channel-primary';
      $channel_label = $this->entityRepository->getTranslationFromContext($channel_entity)->label();
      $form['#id'] .= '--' . $channel_entity->id();
      $form["#info"]["filter-search_api_fulltext"]["label"] = $this->t('Search <span class="finders-search-channel" id="@id--channel">@channel</span>', [
        '@id' => $form['#id'],
        '@channel' => $channel_label,
      ]);
      // Can we do this with the form builder?
      // Do we need to deal with date-drupal-selector?
      // Questions for search_api_autocomplete?
      $form_list[$form['#id']] = $channel_label;

      // @todo Copy this from localgov_directories.
      // $form['#attached']['library'][]
      // = 'localgov_directories/localgov_directories_search';
      $forms[] = $form;

      $forms['#attached']['drupalSettings']['finders']['findersSearch'] = $form_list;
    }

    // Add cacheability: this block depends on the view, and on the channel
    // node, since that could change the view that is used.
    $cacheability = CacheableMetadata::createFromRenderArray($forms);

    foreach ($cache_dependencies as $dependency) {
      $cacheability->addCacheableDependency($dependency);
    }

    $cacheability->applyTo($forms);

    return $forms;
  }

}
