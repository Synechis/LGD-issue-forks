<?php

namespace Drupal\finders\Plugin\FinderType;

use Drupal\Component\Plugin\PluginBase;
use Drupal\Core\Config\Entity\ConfigEntityInterface;
use Drupal\Core\Entity\EntityTypeManagerInterface;
use Drupal\Core\Plugin\ContainerFactoryPluginInterface;
use Drupal\Core\Session\AccountInterface;
use Drupal\finders\Entity\FinderInterface;
use Drupal\finders\Field\BundleFieldDefinition;
use Drupal\search_api\Datasource\DatasourceInterface;
use Drupal\search_api\IndexInterface;
use Drupal\search_api\Item\Field as SearchIndexField;
use Drupal\search_api\Utility\PluginHelperInterface;
use Drupal\views\ViewEntityInterface;
use Symfony\Component\DependencyInjection\ContainerInterface;

/**
 * Base class for Finder Type plugins.
 *
 * @todo there's a lot in here now.
 * Should some maybe go out into Traits / Services?
 */
abstract class FinderTypeBase extends PluginBase implements FinderTypeInterface, ContainerFactoryPluginInterface {

  /**
   * The entity type manager.
   *
   * @var \Drupal\Core\Entity\EntityTypeManagerInterface
   */
  protected $entityTypeManager;

  /**
   * The plugin helper service.
   *
   * @var \Drupal\search_api\Utility\PluginHelperInterface
   */
  protected $pluginHelper;

  /**
   * {@inheritdoc}
   */
  public static function create(ContainerInterface $container, array $configuration, $plugin_id, $plugin_definition) {
    return new static(
      $configuration,
      $plugin_id,
      $plugin_definition,
      $container->get('entity_type.manager'),
      $container->get('search_api.plugin_helper'),
    );
  }

  /**
   * Creates a FinderTypeBase instance.
   *
   * @param array $configuration
   *   A configuration array containing information about the plugin instance.
   * @param string $plugin_id
   *   The plugin ID for the plugin instance.
   * @param mixed $plugin_definition
   *   The plugin implementation definition.
   * @param \Drupal\Core\Entity\EntityTypeManagerInterface $entity_type_manager
   *   The entity type manager.
   * @param \Drupal\search_api\Utility\PluginHelperInterface $plugin_helper
   *   The plugin helper service.
   */
  public function __construct(
    array $configuration,
    $plugin_id,
    $plugin_definition,
    EntityTypeManagerInterface $entity_type_manager,
    PluginHelperInterface $plugin_helper,
  ) {
    parent::__construct($configuration, $plugin_id, $plugin_definition);

    $this->entityTypeManager = $entity_type_manager;
    $this->pluginHelper = $plugin_helper;
  }

  /**
   * The field name for the channel types field.
   *
   * @see self::getChannelTypesFieldDefinition()
   */
  const CHANNEL_TYPES_FIELD = 'finders_channel_types';

  /**
   * The field name for the channel view field.
   */
  const VIEW_FIELD = 'finders_view';

  /**
   * The field name for the channel selection field.
   *
   * @see self::getChannelSelectionFieldDefinition()
   */
  const CHANNEL_SELECTION_FIELD = 'finders_channels';

  /**
   * The field name for the title sort field.
   */
  const TITLE_SORT_FIELD = 'finders_title_sort';

  /**
   * The ID of the view mode used for indexing entries.
   */
  const INDEX_VIEW_MODE = 'finders_index';

  /**
   * The ID of the view mode used for showing entries.
   */
  const RESULTS_VIEW_MODE = 'finders_results';

  /**
   * The ID of the view used for the entry list.
   */
  const CHANNEL_VIEW = 'finders_channel_view';

  /**
   * {@inheritdoc}
   */
  public function getFinderTypeConstant(string $constant_name): string {
    return constant(static::class . '::' . $constant_name);
  }

  /**
   * {@inheritdoc}
   */
  public function getChannelFieldDefinitions(ConfigEntityInterface $bundle, FinderInterface $finder): array {
    $field_definitions = [];

    if ($channel_types_field_definition = $this->getChannelTypesFieldDefinition($bundle, $finder)) {
      $field_definitions[$channel_types_field_definition->getName()] = $channel_types_field_definition;
    }

    if ($view_field_definition = $this->getViewFieldDefinition($bundle)) {
      $field_definitions[$view_field_definition->getName()] = $view_field_definition;
    }

    return $field_definitions;
  }

  /**
   * {@inheritdoc}
   */
  public function getEntryFieldDefinitions(ConfigEntityInterface $bundle, FinderInterface $finder): array {
    $field_definitions = [];

    if ($channels_selection_field_definition = $this->getChannelSelectionFieldDefinition($bundle, $finder)) {
      $field_definitions[$channels_selection_field_definition->getName()] = $channels_selection_field_definition;
    }

    if ($title_sort_field = $this->getTitleSortFieldDefinition($bundle)) {
      $field_definitions[$title_sort_field->getName()] = $title_sort_field;
    }

    return $field_definitions;
  }

  /**
   * {@inheritdoc}
   */
  public function getIndexIds(): array {
    return [
      'finders_index_default',
    ];
  }

  /**
   * {@inheritdoc}
   */
  public function getViewIds(IndexInterface $search_index): array {
    return [
      static::CHANNEL_VIEW,
    ];
  }

  /**
   * {@inheritdoc}
   */
  public function getIndexDatasourceId(IndexInterface $index, string $entity_type_id): string {
    return 'entity:' . $entity_type_id;
  }

  /**
   * {@inheritdoc}
   */
  public function alterSearchIndex(IndexInterface $index, FinderInterface $finder): void {
    // Ensure the index datasource is set up.
    $this->getIndexDatasource($index, $finder);

    $this->addEntryBundlesToDatasource($index, $finder);
    $this->alterIndexFields($index, $finder);
  }

  /**
   * {@inheritdoc}
   */
  public function alterView(ViewEntityInterface $view, IndexInterface $index, FinderInterface $finder): void {
    $entry_entity_type_id = $finder->getEntryEntityTypeId();
    $entry_bundle_entities = $finder->getEntryBundles();

    $default_display_configuration =& $view->getDisplay('default');

    // Copy the channel field argument if the template argument is still
    // present; do not clobber any existing configuration. This has to be done
    // when altering for the entry, as that's when the search index receives the
    // field.
    if (
      $index->getField(static::CHANNEL_SELECTION_FIELD)
      && !isset($default_display_configuration['display_options']['arguments'][static::CHANNEL_SELECTION_FIELD])
      && isset($default_display_configuration['display_options']['arguments']['CHANNEL_SELECTION_FIELD'])
    ) {
      // The channel field argument is present in the template with a token ID.
      // Copy that and remove it from the view.
      $channel_field_argument_template = $default_display_configuration['display_options']['arguments']['CHANNEL_SELECTION_FIELD'];
      unset($default_display_configuration['display_options']['arguments']['CHANNEL_SELECTION_FIELD']);

      $channel_field_argument_template['id'] = static::CHANNEL_SELECTION_FIELD;
      $channel_field_argument_template['field'] = static::CHANNEL_SELECTION_FIELD;
      // No need to change the table, as that has been set already by
      // FinderConfigManager::loadTemplateView().
      $default_display_configuration['display_options']['arguments'][static::CHANNEL_SELECTION_FIELD] = $channel_field_argument_template;
    }

    // Only add a title sort on the view if the index has the field.
    if ($index->getField(static::TITLE_SORT_FIELD)) {
      // Don't clobber any existing configuration.
      if (!isset($default_display_configuration['display_options']['sorts'][static::TITLE_SORT_FIELD])) {
        $default_display_configuration['display_options']['sorts'][static::TITLE_SORT_FIELD] = [
          'id' => static::TITLE_SORT_FIELD,
          // Table name from search_api_views_data().
          'table' => 'search_api_index_' . $index->id(),
          'field' => static::TITLE_SORT_FIELD,
          'relationship' => 'none',
          'group_type' => 'group',
          'admin_label' => '',
          'order' => 'ASC',
          'exposed' => FALSE,
          'expose' => [
            'label' => '',
          ],
          'plugin_id' => 'search_api',
        ];
      }
    }

    // Ensure the row settings have all the entry bundles in the view mode
    // configuration.
    // Add the entry bundle to the view's row options.
    if ($default_display_configuration['display_options']['row']['type'] == 'search_api') {
      foreach ($entry_bundle_entities as $entry_bundle) {
        $default_display_configuration['display_options']['row']['options']['view_modes']['entity:' . $entry_entity_type_id][$entry_bundle->id()] = static::RESULTS_VIEW_MODE;
      }
    }
  }

  /**
   * Adds an entry bundle to an index's datasource.
   *
   * @todo could this be replaced with a Search API plugin that looks for
   * enabled bundles. It would be of all entity types though. And we still add
   * fields so change the config, so it's maybe fine to keep doing here?
   *
   * @param \Drupal\search_api\IndexInterface $index
   *   The search index being updated.
   * @param \Drupal\finders\Entity\FinderInterface $finder
   *   The finder entity.
   *
   * @throws \Exception
   *   Throws an exception if the bundle can't be added to the index datasource.
   */
  protected function addEntryBundlesToDatasource(IndexInterface $index, FinderInterface $finder): void {
    $entry_entity_type_id = $finder->getEntryEntityTypeId();
    $entry_bundle_entities = $finder->getEntryBundles();

    $datasource = $this->getIndexDatasource($index, $finder);
    if (!$datasource) {
      throw new \Exception('Failed to update the finders search index with new bundle');
    }

    $configuration = $datasource->getConfiguration();
    $configuration['bundles']['default'] = FALSE;

    foreach ($entry_bundle_entities as $entry_bundle) {
      if (!in_array($entry_bundle->id(), $configuration['bundles']['selected'])) {
        $configuration['bundles']['selected'][] = $entry_bundle->id();
      }
    }

    $datasource->setConfiguration($configuration);
  }

  /**
   * Adds and updates fields on an index.
   *
   * The datasource for the entry bundle entity has already has the entry bundle
   * added to it.
   *
   * @param \Drupal\search_api\IndexInterface $index
   *   The search index being updated.
   * @param \Drupal\finders\Entity\FinderInterface $finder
   *   The finder entity.
   */
  protected function alterIndexFields(IndexInterface $index, FinderInterface $finder): void {
    $entry_entity_type_id = $finder->getEntryEntityTypeId();

    $datasource_id = $this->getIndexDatasourceId($index, $entry_entity_type_id);

    $this->ensureIndexLabelField($index, $finder, $datasource_id);
    $this->ensureIndexTitleSortField($index, $finder, $datasource_id);
    $this->ensureIndexChannelSelectionField($index, $finder, $datasource_id);
    $this->alterIndexRenderedItemField($index, $finder, $datasource_id);
  }

  /**
   * Ensures the index has a label field for the entry bundle.
   *
   * @param \Drupal\search_api\IndexInterface $index
   *   The search index being updated.
   * @param \Drupal\finders\Entity\FinderInterface $finder
   *   The finder entity.
   * @param string $datasource_id
   *   The ID of the datasource for the entry bundle.
   *
   * @see self::alterIndexFields()
   */
  protected function ensureIndexLabelField(IndexInterface $index, FinderInterface $finder, string $datasource_id): void {
    $entry_entity_type_id = $finder->getEntryEntityTypeId();
    $label_field_name = $this->entityTypeManager->getDefinition($entry_entity_type_id)->getKey('label');

    if (!$index->getField($label_field_name)) {
      $title_field = new SearchIndexField($index, $label_field_name);
      $title_field->setDatasourceId($datasource_id);
      $title_field->setType('text');
      $title_field->setPropertyPath($label_field_name);
      $title_field->setBoost(5.0);
      $title_field->setLabel('Title');

      $index->addField($title_field);
    }
  }

  /**
   * Ensures the index has a title sort field for the entry bundle.
   *
   * @param \Drupal\search_api\IndexInterface $index
   *   The search index being updated.
   * @param \Drupal\finders\Entity\FinderInterface $finder
   *   The finder entity.
   * @param string $datasource_id
   *   The ID of the datasource for the entry bundle.
   *
   * @see self::alterIndexFields()
   */
  protected function ensureIndexTitleSortField(IndexInterface $index, FinderInterface $finder, string $datasource_id): void {
    $entry_entity_type_id = $finder->getEntryEntityTypeId();
    if (!$index->getField(static::TITLE_SORT_FIELD)) {
      $sort_title_field = new SearchIndexField($index, static::TITLE_SORT_FIELD);
      $sort_title_field->setDatasourceId($datasource_id);
      $sort_title_field->setType('string');
      $sort_title_field->setPropertyPath(static::TITLE_SORT_FIELD);
      $sort_title_field->setLabel('Title (sort)');
      $sort_title_field->setDependencies([
        'config' => [
          'field.storage.' . $entry_entity_type_id . '.' . static::TITLE_SORT_FIELD,
        ],
      ]);

      $index->addField($sort_title_field);
    }
  }

  /**
   * Ensures the index has a channel selection field for the entry bundle.
   *
   * @param \Drupal\search_api\IndexInterface $index
   *   The search index being updated.
   * @param \Drupal\finders\Entity\FinderInterface $finder
   *   The finder entity.
   * @param string $datasource_id
   *   The ID of the datasource for the entry bundle.
   *
   * @see self::alterIndexFields()
   */
  protected function ensureIndexChannelSelectionField(IndexInterface $index, FinderInterface $finder, string $datasource_id): void {
    $entry_entity_type_id = $finder->getEntryEntityTypeId();
    if (!$index->getField(static::CHANNEL_SELECTION_FIELD)) {
      $channel_selection_field = new SearchIndexField($index, static::CHANNEL_SELECTION_FIELD);
      $channel_selection_field->setLabel('Finder channels');
      $channel_selection_field->setDatasourceId($datasource_id);
      $channel_selection_field->setPropertyPath(static::CHANNEL_SELECTION_FIELD);
      $channel_selection_field->setType('string');
      $channel_selection_field->setDependencies([
        'config' => [
          'field.storage.' . $entry_entity_type_id . '.' . static::CHANNEL_SELECTION_FIELD,
        ],
      ]);
      $index->addField($channel_selection_field);
    }
  }

  /**
   * Adds an entry bundle to the index's rendered item field.
   *
   * If the rendered item field does not yet exist on the index, it is created.
   *
   * @param \Drupal\search_api\IndexInterface $index
   *   The search index being updated.
   * @param \Drupal\finders\Entity\FinderInterface $finder
   *   The finder entity.
   * @param string $datasource_id
   *   The ID of the datasource for the entry bundle.
   *
   * @see self::alterIndexFields()
   */
  protected function alterIndexRenderedItemField(IndexInterface $index, FinderInterface $finder, string $datasource_id): void {
    $entry_bundle_entities = $finder->getEntryBundles();

    $rendered_item_field = $index->getField('rendered_item');
    if (!$rendered_item_field) {
      // There is no rendered item field yet on this index, so create it.
      // The rendered_item index field is independent of datasource, so should
      // not have a datasource set on it.
      $rendered_item_field = new SearchIndexField($index, 'rendered_item');
      $rendered_item_field->setType('text');
      $rendered_item_field->setPropertyPath('rendered_item');
      $rendered_item_field->setLabel('Rendered HTML output');

      $configuration = $rendered_item_field->getConfiguration();
      $configuration['roles'][AccountInterface::ANONYMOUS_ROLE] = AccountInterface::ANONYMOUS_ROLE;

      // Ensure at least an empty array.
      $configuration['view_mode'][$datasource_id] ??= [];

      foreach ($entry_bundle_entities as $entry_bundle) {
        $configuration['view_mode'][$datasource_id][$entry_bundle->id()] = static::INDEX_VIEW_MODE;
      }

      $rendered_item_field->setConfiguration($configuration);

      $index->addField($rendered_item_field);
    }
    else {
      // The rendered item field already exists on this index. Ensure it has all
      // the entry bundles in the view mode configuration.
      $configuration = $rendered_item_field->getConfiguration();
      foreach ($entry_bundle_entities as $entry_bundle) {
        $configuration['view_mode'][$datasource_id][$entry_bundle->id()] = static::INDEX_VIEW_MODE;
      }
      $rendered_item_field->setConfiguration($configuration);
    }
  }

  /**
   * Gets the index entity datasource or create it if it is not found.
   *
   * @param \Drupal\search_api\IndexInterface $index
   *   The index to retrieve the datasource from.
   * @param \Drupal\finders\Entity\FinderInterface $finder
   *   The finder entity.
   *
   * @return \Drupal\search_api\Datasource\DatasourceInterface
   *   The datasource.
   */
  protected function getIndexDatasource(IndexInterface $index, FinderInterface $finder): DatasourceInterface {
    $entry_entity_type_id = $finder->getEntryEntityTypeId();
    $datasource_id = $this->getIndexDatasourceId($index, $entry_entity_type_id);

    if ($index->isValidDatasource($datasource_id)) {
      $datasource = $index->getDatasource($datasource_id);
    }
    else {
      $datasource = $this->pluginHelper->createDatasourcePlugin($index, $datasource_id);

      $index->addDatasource($datasource);
    }

    return $datasource;
  }

  /**
   * Gets the definition for the channel types field.
   *
   * This field on channels controls which entry bundles can be set as being in
   * the channel.
   *
   * @param \Drupal\Core\Config\Entity\ConfigEntityInterface $bundle
   *   The bundle entity.
   * @param \Drupal\finders\Entity\FinderInterface $finder
   *   The finder entity.
   *
   * @return \Drupal\finders\Field\BundleFieldDefinition|null
   *   The bundle field definition, or NULL if no field should be defined.
   *
   * @see \Drupal\finders\Plugin\EntityReferenceSelection\EntryTypes
   */
  protected function getChannelTypesFieldDefinition(ConfigEntityInterface $bundle, FinderInterface $finder): ?BundleFieldDefinition {
    $entry_entity_type_id = $finder->getEntryEntityTypeId();
    $entry_entity_type = $this->entityTypeManager->getDefinition($entry_entity_type_id);

    return BundleFieldDefinition::create('entity_reference')
      ->setName(static::CHANNEL_TYPES_FIELD)
      ->setLabel(t('Enabled entry types'))
      ->setDescription(t('Entries of the following types will be able to set the current channel entity as a channel.'))
      ->setRequired(FALSE)
      ->setTranslatable(FALSE)
      ->setCardinality(BundleFieldDefinition::CARDINALITY_UNLIMITED)
      ->setSettings([
        'handler' => 'finders_entry_types',
        // This field points to bundle entities of the entry entity type, e.g.
        // if the entries are nodes, it points to node types.
        'target_type' => $entry_entity_type->getBundleEntityType(),
      ])
      ->setDisplayConfigurable('form', TRUE)
      ->setDisplayOptions('form', [
        'type' => 'options_buttons',
      ]);
  }

  /**
   * Gets the definition for the view selection field.
   *
   * This field on channels allows selecting the view to show a listing of
   * entries.
   *
   * @param \Drupal\Core\Config\Entity\ConfigEntityInterface $bundle
   *   The bundle entity.
   *
   * @return \Drupal\finders\Field\BundleFieldDefinition|null
   *   The bundle field definition, or NULL if no field should be defined.
   */
  protected function getViewFieldDefinition(ConfigEntityInterface $bundle): ?BundleFieldDefinition {
    return BundleFieldDefinition::create('viewsreference')
      ->setName(static::VIEW_FIELD)
      ->setLabel(t('Event list view'))
      ->setRequired(FALSE)
      ->setTranslatable(FALSE)
      ->setCardinality(1)
      ->setSettings([
        'target_type' => 'view',
        'handler' => 'finders_channel_views',
        'handler_settings' => [
          'target_bundles' => NULL,
          'auto_create' => FALSE,
        ],
        'plugin_types' => [
          'embed' => 'embed',
        ],
      ])
      ->setDisplayConfigurable('form', TRUE)
      ->setDisplayOptions('form', [
        'type' => 'viewsreference_select',
      ])
      ->setDisplayConfigurable('view', TRUE)
      ->setDisplayOptions('view', [
        'type' => 'finders_channel_view',
      ]);
  }

  /**
   * Gets the definition for the channel selection field.
   *
   * This field on entries controls which channels an entry entity appears in.
   *
   * @param \Drupal\Core\Config\Entity\ConfigEntityInterface $bundle
   *   The bundle entity.
   * @param \Drupal\finders\Entity\FinderInterface $finder
   *   The finder.
   *
   * @return \Drupal\finders\Field\BundleFieldDefinition|null
   *   The bundle field definition, or NULL if no field should be defined.
   */
  protected function getChannelSelectionFieldDefinition(ConfigEntityInterface $bundle, FinderInterface $finder): ?BundleFieldDefinition {
    $bundle_entity_type = $bundle->getEntityType();
    $content_entity_type_id = $bundle_entity_type->getBundleOf();
    $content_entity_type = $this->entityTypeManager->getDefinition($content_entity_type_id);

    $channel_entity_type_id = $finder->getChannelEntityTypeId();

    return BundleFieldDefinition::create('entity_reference')
      ->setName(static::CHANNEL_SELECTION_FIELD)
      ->setLabel(t('Finder channels'))
      ->setRequired(FALSE)
      ->setTranslatable(FALSE)
      ->setCardinality(BundleFieldDefinition::CARDINALITY_UNLIMITED)
      ->setSettings([
        'handler' => 'finders_channels',
        'target_type' => $channel_entity_type_id,
        'handler_settings' => [
          // We don't use this setting in our selection plugin, but the class it
          // inherits from does. Setting this to NULL means it skips its bundle
          // filtering which we don't need.
          'target_bundles' => NULL,
          'sort' => [
            'field' => $content_entity_type->getKey('label'),
            'direction' => 'ASC',
          ],
        ],
      ])
      ->setDisplayConfigurable('form', TRUE)
      ->setDisplayOptions('form', [
        'type' => 'finders_channels',
      ]);
  }

  /**
   * Gets the definition for the title sort field.
   *
   * This field on entries allows an override of the entity label for sorting.
   *
   * @param \Drupal\Core\Config\Entity\ConfigEntityInterface $bundle
   *   The bundle entity.
   *
   * @return \Drupal\finders\Field\BundleFieldDefinition|null
   *   The bundle field definition, or NULL if no field should be defined.
   */
  protected function getTitleSortFieldDefinition(ConfigEntityInterface $bundle): ?BundleFieldDefinition {
    return BundleFieldDefinition::create('string')
      ->setName(static::TITLE_SORT_FIELD)
      ->setLabel(t('Title used for sorting'))
      ->setDescription(t("<strong>Can be left blank</strong>. If this field is completed it will be used instead of the <em>Title</em> for alphabetically sorted lists. For example to move 'The' or 'A' from the beginning of a name."))
      ->setRequired(FALSE)
      ->setTranslatable(TRUE)
      ->setCardinality(1)
      ->setDisplayConfigurable('form', TRUE)
      ->setDisplayOptions('form', [
        'type' => 'string_textfield',
      ]);
  }

}
