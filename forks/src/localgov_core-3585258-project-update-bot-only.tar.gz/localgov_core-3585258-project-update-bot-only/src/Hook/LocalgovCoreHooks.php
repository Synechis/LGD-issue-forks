<?php

namespace Drupal\localgov_core\Hook;

use Drupal\media\MediaInterface;
use Drupal\Core\Installer\InstallerKernel;
use Drupal\taxonomy\TermInterface;
use Drupal\node\NodeInterface;
use Drupal\Core\Hook\Attribute\Hook;

/**
 * Hook implementations for localgov_core.
 */
class LocalgovCoreHooks {

  /**
   * Implements hook_theme().
   */
  #[Hook('theme')]
  public function theme($existing, $type, $theme, $path) {
    return [
      'localgov_page_header_block' => [
        'variables' => [
          'title' => '',
          'subtitle' => NULL,
          'lede' => NULL,
          'entity' => NULL,
        ],
        'render element' => 'block',
      ],
    ];
  }

  /**
   * Implements hook_library_info_alter().
   */
  #[Hook('library_info_alter')]
  public function libraryInfoAlter(&$libraries, $extension): void {
    if ($extension === 'core') {
      $remove_css = (bool) _localgov_core_get_theme_setting('localgov_base_remove_css');
      $remove_js = (bool) _localgov_core_get_theme_setting('localgov_base_remove_js');
      foreach ($libraries as $name => $library) {
        if (str_starts_with($name, 'components.localgov_base--')) {
          if ($remove_css) {
            $libraries[$name]['css'] = [];
          }
          if ($remove_js) {
            $libraries[$name]['js'] = [];
          }
        }
      }
    }
  }

  /**
   * Implements hook_theme_suggestions_HOOK().
   */
  #[Hook('theme_suggestions_localgov_page_header_block')]
  public function themeSuggestionsLocalgovPageHeaderBlock(array $variables): array {
    $suggestions = [];
    $entity = $variables['entity'];
    if ($entity instanceof NodeInterface || $entity instanceof TermInterface) {
      $id = $entity->id();
      $type = $entity->getEntityTypeId();
      $bundle = $entity->bundle();
      $suggestions[] = 'localgov_page_header_block__' . $bundle;
      $suggestions[] = 'localgov_page_header_block__' . $type . '__' . $id;
      $suggestions[] = 'localgov_page_header_block__' . $type;
    }
    return $suggestions;
  }

  /**
   * Implements hook_template_preprocess_default_variables_alter().
   */
  #[Hook('template_preprocess_default_variables_alter')]
  public function templatePreprocessDefaultVariablesAlter(&$variables): void {
    $remove_css = (bool) _localgov_core_get_theme_setting('localgov_base_remove_css');
    $remove_js = (bool) _localgov_core_get_theme_setting('localgov_base_remove_js');
    if ($remove_css) {
      $variables['localgov_base_remove_css'] = TRUE;
    }
    if ($remove_js) {
      $variables['localgov_base_remove_js'] = TRUE;
    }
  }

  /**
   * Implements hook_modules_installed().
   *
   * This installs default blocks for modules when they're enabled on an existing
   * site. (IE, not in the installer.)
   */
  #[Hook('modules_installed')]
  public function modulesInstalled(array $modules, bool $is_syncing): void {
    if ($is_syncing) {
      return;
    }
    // If we're in the installer, do nothing.
    if (InstallerKernel::installationAttempted()) {
      return;
    }
    /** @var \Drupal\localgov_core\Service\DefaultBlockInstaller $defaultBlockInstaller */
    $defaultBlockInstaller = \Drupal::service('localgov_core.default_block_installer');
    $defaultBlockInstaller->install($modules);
  }

  /**
   * Implements hook_localgov_post_install().
   *
   * This installs default blocks as part of the installation of a new LocalGov
   * site. All LocalGov modules (IE ones whose name starts with 'localgov_') will
   * have default blocks that they define installed.
   */
  #[Hook('localgov_post_install')]
  public function localgovPostInstall(): void {
    $moduleList = \Drupal::moduleHandler()->getModuleList();
    $localgovModules = array_filter(array_keys($moduleList), function ($moduleName) {
        return str_starts_with($moduleName, 'localgov_');
    });
    /** @var \Drupal\localgov_core\Service\DefaultBlockInstaller $defaultBlockInstaller */
    $defaultBlockInstaller = \Drupal::service('localgov_core.default_block_installer');
    $defaultBlockInstaller->install($localgovModules);
  }

  /**
   * Implements hook_preprocess_file_link().
   *
   * Changes:
   * - Inserts file *type* and size into the theme variable.
   * - Reformats file size.  Example: 123.4KB.
   * - Appends file metadata to the file link text.
   *
   * @see template_preprocess_file_link()
   */
  #[Hook('preprocess_file_link')]
  public function preprocessFileLink(&$variables): void {
    $file = $variables['file'];
    $filename = $file->getFilename();
    $file_extension = pathinfo($filename, PATHINFO_EXTENSION);
    $variables['file_type'] = strtoupper($file_extension);
    // 123.45 KB -> 123.45KB
    $variables['file_size'] = strtr($variables['file_size'], [
      ' ' => '',
    ]);
    // Load media entity from file.
    $entity = $file->_referringItem?->getParent()?->getParent()?->getEntity();
    $media = $entity instanceof MediaInterface ? $entity : NULL;
    if (isset($variables['link']['#title'])) {
      $document_title = $variables['link']['#title'];
      if ($media) {
        // Assume some defaults for document media type.
        $view_mode = 'default';
        $media_file_field_name = $media->bundle() === 'document' ? 'field_media_document' : NULL;
        // Initialise description variables.
        $use_description = FALSE;
        $description = '';
        if ($media_file_field_name) {
          $entity_display_repository = \Drupal::service('entity_display.repository');
          $entity_display = $entity_display_repository->getViewDisplay($media->getEntityTypeId(), $media->bundle(), $view_mode);
          $field_display = $entity_display->getComponent($media_file_field_name);
          if ($field_display && isset($field_display['settings']['use_description_as_link_text'])) {
            $use_description = $field_display['settings']['use_description_as_link_text'];
          }
        }
        // Get the description from the file field if available.
        if ($use_description && $file->_referringItem) {
          $description = $file->_referringItem->description ?? '';
        }
        // Use description as link text if enabled and description exists.
        if ($use_description && !empty($description)) {
          $document_title = $description;
        }
        else {
          // Otherwise, see about using the media name.
          $media_name = $media->get('name')->getString();
          // If the media name is set and different to the
          // $variables['link']['#title'], we will use that instead.
          $document_title = $media_name && $media_name !== $document_title ? $media_name : $document_title;
        }
      }
      $variables['link']['#title'] = [
        '#markup' => "{$document_title} <span class=\"file-meta\">(<span class=\"file-type\">{$variables['file_type']}</span>, <span class=\"file-size\">{$variables['file_size']}</span>)</span>",
      ];
    }
    else {
      $file_title = $variables['link'];
      $variables['link'] = [
        '#markup' => "{$file_title} <span class=\"file-meta\">(<span class=\"file-type\">{$variables['file_type']}</span>, <span class=\"file-size\">{$variables['file_size']}</span>)</span>",
      ];
    }
  }

}
