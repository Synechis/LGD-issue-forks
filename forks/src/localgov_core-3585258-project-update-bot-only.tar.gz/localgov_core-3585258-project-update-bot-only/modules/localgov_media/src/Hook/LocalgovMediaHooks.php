<?php

namespace Drupal\localgov_media\Hook;

use Drupal\user\Entity\Role;
use Drupal\Core\Config\FileStorage;
use Drupal\Core\Hook\Attribute\Hook;

/**
 * Hook implementations for localgov_media.
 */
class LocalgovMediaHooks {

  /**
   * Implements hook_links_discovered_alter().
   */
  #[Hook('links_discovered_alter', module: 'localgov_media_menu')]
  public function menuLinksDiscoveredAlter(&$links): void {
    // We move our files under media.
    // @see https://github.com/localgovdrupal/localgov_core/pull/221
    // @see \Drupal\localgov_media\Plugin\Derivative\FilesLocalTasks
    unset($links['admin_toolbar_tools.extra_links:view.files']);
  }

  /**
   * Implements hook_modules_installed().
   */
  #[Hook('modules_installed')]
  public function modulesInstalled($modules, $is_syncing) {
    if (!$is_syncing && in_array('localgov_media', $modules, TRUE)) {
      // Install all optional config now rather than deferring it to later.
      $config_path = \Drupal::service('extension.list.module')->getPath('localgov_media') . '/config/optional';
      $config_source = new FileStorage($config_path);
      \Drupal::service('config.installer')->installOptionalConfig($config_source);
      // Add permission to use the WYSIWYG text format.
      if (\Drupal::configFactory()->get('filter.format.wysiwyg')->getRawData()) {
        $role_object = Role::load('authenticated');
        $role_object->grantPermission('use text format wysiwyg');
        $role_object->save();
      }
    }
  }

}
