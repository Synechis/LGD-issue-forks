<?php

namespace Drupal\localgov_roles_test_two\Hook;

use Drupal\Core\Hook\Attribute\Hook;

/**
 * Hook implementations for localgov_roles_test_two.
 */
class LocalgovRolesTestTwoHooks {
  /**
   * @file
   * Hooks for localgov_roles_test_one.
   */

  /**
   * Implements hook_localgov_roles_default().
   */
  #[Hook('localgov_roles_default')]
  public function localgovRolesDefault() {
    return [
          // @codingStandardsIgnoreLine
          \Drupal\localgov_roles\RolesHelper::EDITOR_ROLE => [
            'administer localgov roles test two',
            'delete localgov roles test two',
            'create localgov roles test two',
            'view localgov roles test two',
            'edit localgov roles test two',
          ],
    ];
  }

}
