<?php

namespace Drupal\localgov_roles_test_one\Hook;

use Drupal\localgov_roles\RolesHelper;
use Drupal\Core\Hook\Attribute\Hook;

/**
 * Hook implementations for localgov_roles_test_one.
 */
class LocalgovRolesTestOneHooks {
  /**
   * @file
   * Hooks for localgov_roles_test_one.
   */

  /**
   * Implements hook_localgov_roles_default().
   */
  #[Hook('localgov_roles_default')]
  public function localgovRolesDefault() {
    return [
          // @codingStandardsIgnoreLine
      RolesHelper::EDITOR_ROLE => [
        'delete localgov roles test one',
        'create localgov roles test one',
        'view localgov roles test one',
        'edit localgov roles test one',
      ],
          // @codingStandardsIgnoreLine
      RolesHelper::AUTHOR_ROLE => [
        'create localgov roles test one',
        'view localgov roles test one',
        'edit localgov roles test one',
      ],
    ];
  }

}
