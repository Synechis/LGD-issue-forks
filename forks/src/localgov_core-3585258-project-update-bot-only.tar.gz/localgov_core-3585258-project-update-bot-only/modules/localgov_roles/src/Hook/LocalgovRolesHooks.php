<?php

namespace Drupal\localgov_roles\Hook;

use Drupal\localgov_roles\RolesHelper;
use Drupal\Core\Hook\Attribute\Hook;

/**
 * Hook implementations for localgov_roles.
 */
class LocalgovRolesHooks {

  /**
   * Implements hook_modules_installed().
   */
  #[Hook('modules_installed')]
  public function modulesInstalled($modules, $is_syncing) {
    if (!$is_syncing) {
      foreach ($modules as $module) {
        RolesHelper::assignModuleRoles($module);
      }
    }
  }

}
