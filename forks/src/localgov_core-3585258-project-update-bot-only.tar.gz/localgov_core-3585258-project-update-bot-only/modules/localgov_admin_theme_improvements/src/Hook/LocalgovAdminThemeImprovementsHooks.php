<?php

namespace Drupal\localgov_admin_theme_improvements\Hook;

use Drupal\Core\Cache\RefinableCacheableDependencyInterface;
use Drupal\Core\Form\FormStateInterface;
use Drupal\Core\Hook\Attribute\Hook;

/**
 * Hook implementations for localgov_admin_theme_improvements.
 */
class LocalgovAdminThemeImprovementsHooks {

  /**
   * Implements hook_form_FORM_ID_alter().
   */
  #[Hook('form_revision_overview_form_alter')]
  public function formRevisionOverviewFormAlter(&$form, FormStateInterface $form_state, $form_id) {
    if ($form_id === 'revision_overview_form') {
      $form['#attached']['library'][] = 'localgov_admin_theme_improvements/revisions-page';
    }
  }

  /**
   * Implements hook_menu_local_tasks_alter().
   */
  #[Hook('menu_local_tasks_alter')]
  public function menuLocalTasksAlter(&$data, $route_name, RefinableCacheableDependencyInterface &$cacheability) {
    // Increase "Files" item weight.
    if (isset($data['tabs'][0]['views_view:view.files.page_1'])) {
      $data['tabs'][0]['views_view:view.files.page_1']['#weight'] = 20;
    }
    // Increase "Page components" item weight.
    if (isset($data['tabs'][0]['entity.paragraphs_library_item.collection'])) {
      $data['tabs'][0]['entity.paragraphs_library_item.collection']['#weight'] = 60;
    }
  }

}
