# LocalGov Editoria11y

This is a simple module to configure the editoria11y module to the needs of LocalGov Drupal.

Currently all this means is:

1. Removing permissions for Editoria11y from all roles,
2. Adding permissions for Editoria11y to only LocalGov Editor role.

Maintainers:
- Mark Conroy - https://www.drupal.org/u/markconroy
