<?php

namespace Drupal\localgov_editoria11y\Hook;

use Drupal\localgov_roles\RolesHelper;
use Drupal\Core\Hook\Attribute\Hook;

/**
 * Hook implementations for localgov_editoria11y.
 */
class LocalgovEditoria11yHooks {

  /**
   * Implements hook_localgov_roles_default().
   */
  #[Hook('localgov_roles_default')]
  public function localgovRolesDefault(): array {
    $permissions = [
      RolesHelper::EDITOR_ROLE => [
        'administer editoria11y checker',
        'manage editoria11y results',
      ],
    ];
    return $permissions;
  }

}
