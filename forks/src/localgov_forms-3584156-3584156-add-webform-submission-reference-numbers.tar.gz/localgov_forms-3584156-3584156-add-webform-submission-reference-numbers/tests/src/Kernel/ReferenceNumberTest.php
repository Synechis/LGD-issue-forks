<?php

declare(strict_types=1);

namespace Drupal\Tests\localgov_forms\Kernel;

use Drupal\KernelTests\KernelTestBase;
use Drupal\webform\Entity\Webform;
use Drupal\webform\Entity\WebformSubmission;

/**
 * Tests submission reference-number generation and token exposure.
 *
 * @group localgov_forms
 */
class ReferenceNumberTest extends KernelTestBase {

  /**
   * {@inheritdoc}
   */
  protected static $modules = [
    'system',
    'user',
    'field',
    'token',
    'webform',
    'inline_form_errors',
    'geocoder',
    'localgov_forms',
  ];

  /**
   * {@inheritdoc}
   */
  protected function setUp(): void {
    parent::setUp();
    $this->installEntitySchema('user');
    $this->installEntitySchema('webform_submission');
    $this->installSchema('webform', ['webform']);
    // 'system' provides the core.date_format.* config entities that webform's
    // save-time token replacement needs; without them date tokens fatal.
    $this->installConfig(['system', 'webform', 'localgov_forms']);
  }

  /**
   * Creates a webform with reference settings and returns a saved submission.
   */
  protected function submitWithReferenceSettings(bool $enabled, string $format): WebformSubmission {
    $webform = Webform::create([
      'id' => 'test_reference',
      'title' => 'Test reference',
      'elements' => "name:\n  '#type': textfield\n  '#title': Name\n",
      'third_party_settings' => [
        'localgov_forms' => [
          'reference_settings' => [
            'enable_reference_number' => $enabled,
            'format' => $format,
          ],
        ],
      ],
    ]);
    $webform->save();

    $submission = WebformSubmission::create([
      'webform_id' => 'test_reference',
      'data' => ['name' => 'Ada Lovelace'],
    ]);
    $submission->save();

    return WebformSubmission::load($submission->id());
  }

  /**
   * When enabled, the resolved reference is stored in submission data.
   */
  public function testReferenceStoredWhenEnabled(): void {
    $submission = $this->submitWithReferenceSettings(TRUE, '[webform:id]-[webform_submission:serial]');
    $expected = 'test_reference-' . $submission->serial();
    $this->assertSame($expected, $submission->getElementData('localgov_forms_reference'));
  }

  /**
   * When disabled, no reference is stored.
   */
  public function testNoReferenceWhenDisabled(): void {
    $submission = $this->submitWithReferenceSettings(FALSE, '[webform:id]-[webform_submission:serial]');
    $this->assertNull($submission->getElementData('localgov_forms_reference'));
  }

  /**
   * The reference token resolves to the stored value.
   */
  public function testTokenResolves(): void {
    $submission = $this->submitWithReferenceSettings(TRUE, '[webform:id]-[webform_submission:serial]');
    $expected = 'test_reference-' . $submission->serial();
    $resolved = \Drupal::token()->replace(
      '[webform_submission:localgov_forms_reference]',
      ['webform_submission' => $submission]
    );
    $this->assertSame($expected, $resolved);
  }

  /**
   * The reference token resolves to empty when no reference is stored.
   */
  public function testTokenEmptyWhenDisabled(): void {
    $submission = $this->submitWithReferenceSettings(FALSE, '[webform:id]-[webform_submission:serial]');
    $resolved = \Drupal::token()->replace(
      '[webform_submission:localgov_forms_reference]',
      ['webform_submission' => $submission],
      ['clear' => TRUE]
    );
    $this->assertSame('', $resolved);
  }

  /**
   * The reference renders as a pseudo-field on the submission view.
   */
  public function testReferenceShownOnSubmissionView(): void {
    $submission = $this->submitWithReferenceSettings(TRUE, '[webform:id]-[webform_submission:serial]');
    $expected = 'test_reference-' . $submission->serial();

    $build = \Drupal::entityTypeManager()
      ->getViewBuilder('webform_submission')
      ->view($submission, 'default');
    $html = (string) \Drupal::service('renderer')->renderInIsolation($build);

    $this->assertStringContainsString('Reference number', $html);
    $this->assertStringContainsString($expected, $html);
  }

}
