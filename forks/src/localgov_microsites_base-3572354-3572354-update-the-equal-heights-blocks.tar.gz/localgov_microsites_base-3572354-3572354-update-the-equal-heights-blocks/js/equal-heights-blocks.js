(function equalHeightsBlocksScript(Drupal) {
  Drupal.behaviors.equalHeightsBlocks = {
    attach: function (context) {

      const layouts = once('allLayouts', '.layout', context);
      const blocksToEqualiseHeights = ['.ia-block', '.call-out-box', '.featured-teaser'];

      function equaliseHeightsOfTheseBlocks(layoutWithBlocks, typeOfBlock) {
        layoutWithBlocks.forEach(item => {
          const blocksToEqualiseHeights = item.querySelectorAll(typeOfBlock);
          const blockHeights = [];

          function removeExistingHeights() {
            blocksToEqualiseHeights.forEach(block => {
              block.style.height = "";
            });
          }

          function handleGetHeights() {
            blocksToEqualiseHeights.forEach(block => {
              blockHeights.push(block.offsetHeight);
            });
            let tallestBlock = Math.max(...blockHeights);
            blocksToEqualiseHeights.forEach(block => {
              block.style.height = `${tallestBlock}px`;
            });
          }

          // We need a setTimeout here because the images take just
          // a tiny bit to load, which causes the layout to be set
          // before they are in place, then they get positioned
          // wrong on first load.
          setTimeout(() => {
            removeExistingHeights();
            handleGetHeights();
          }, 250);
        })
      }

      function handleEqualise() {
        blocksToEqualiseHeights.forEach(blockSelector => {
          const layoutsWithBlocks = layouts.filter(item => item.querySelector(blockSelector));
          if (layoutsWithBlocks.length) {
            equaliseHeightsOfTheseBlocks(layoutsWithBlocks, blockSelector);
          }
        });
      }

      handleEqualise();

      window.addEventListener('resize', Drupal.debounce(handleEqualise, 250, true));
    }
  };
}(Drupal));