<?php

/**
 * @file
 * Localgov publications importer post update hooks.
 */

/**
 * Fixes the stored schema of "pages" on the localgov_import entity.
 *
 * Sites that ran update_10007() before it was fixed have the "pages" DB column
 * as a blob, but Drupal still has the old "text" schema stored for it, so the
 * status report says that the Pages field needs to be updated.
 *
 * This is a post update rather than another update_N() so that the 1.x and 2.x
 * branches, which number their updates differently, can't get out of step.
 */
function localgov_publications_importer_post_update_fix_pages_schema(): void {
  $stored_definition = \Drupal::entityDefinitionUpdateManager()->getFieldStorageDefinition('pages', 'localgov_import');
  // Nothing to fix if the stored schema is already a blob.
  if ($stored_definition === NULL || ($stored_definition->getColumns()['value']['type'] ?? NULL) === 'blob') {
    return;
  }

  \Drupal::moduleHandler()->loadInclude('localgov_publications_importer', 'install');
  _localgov_publications_importer_store_pages_as_case_sensitive();
}
