<?php

namespace Drupal\Tests\localgov_publications_importer\Functional;

use Drupal\Core\Database\Database;
use Drupal\Core\Field\BaseFieldDefinition;
use Drupal\localgov_publications_importer\Entity\Import;

/**
 * Tests the stored schema of the "pages" field after it became a blob.
 *
 * @group localgov_publications_importer
 */
class PagesSchemaUpdateTest extends FunctionalTestBase {

  /**
   * {@inheritdoc}
   */
  protected function setUp(): void {
    parent::setUp();
    if (Database::getConnection()->databaseType() !== 'mysql') {
      $this->markTestSkipped('update_10007() uses MySQL syntax.');
    }
    $this->container->get('module_handler')->loadInclude('localgov_publications_importer', 'install');
    $this->container->get('module_handler')->loadInclude('localgov_publications_importer', 'php', 'localgov_publications_importer.post_update');
  }

  /**
   * Tests that update_10007() leaves nothing for the status report to flag.
   */
  public function testUpdate10007(): void {
    $imports = $this->installBeta2State();
    $this->assertCount(1, $this->getPagesChanges(), 'The site has the same field changes pending as a site before update_10007().');
    $this->assertSame('longtext', $this->getPagesColumnType());

    localgov_publications_importer_update_10007();
    $this->assertSame([], $this->getPagesChanges(), 'The status report has nothing to say about the pages field.');
    $this->assertSame('longblob', $this->getPagesColumnType());
    $this->assertImportsUnchanged($imports);

    // Running it again is safe.
    localgov_publications_importer_update_10007();
    $this->assertSame([], $this->getPagesChanges());
    $this->assertSame('longblob', $this->getPagesColumnType());
    $this->assertImportsUnchanged($imports);
  }

  /**
   * Tests the post update for sites that ran the original update_10007().
   */
  public function testPostUpdate(): void {
    $update_manager = $this->container->get('entity.definition_update_manager');

    // A site that is up to date is left alone.
    $installed = serialize($update_manager->getFieldStorageDefinition('pages', 'localgov_import'));
    localgov_publications_importer_post_update_fix_pages_schema();
    $this->assertSame($installed, serialize($update_manager->getFieldStorageDefinition('pages', 'localgov_import')));

    // A site that ran update_10007() before it was fixed.
    $imports = $this->installBeta2State();
    $definition = $update_manager->getFieldStorageDefinition('pages', 'localgov_import');
    assert($definition instanceof BaseFieldDefinition);
    $definition->setSetting('case_sensitive', TRUE);
    $update_manager->updateFieldStorageDefinition($definition);
    Database::getConnection()->query('ALTER TABLE {localgov_import} MODIFY pages LONGBLOB');
    $this->assertCount(1, $this->getPagesChanges(), 'The site has the field change from the status report pending.');
    $this->assertSame('longblob', $this->getPagesColumnType());

    localgov_publications_importer_post_update_fix_pages_schema();
    $this->assertSame([], $this->getPagesChanges(), 'The status report has nothing to say about the pages field.');
    $this->assertSame('longblob', $this->getPagesColumnType());
    $this->assertImportsUnchanged($imports);

    // Running it again is safe.
    localgov_publications_importer_post_update_fix_pages_schema();
    $this->assertSame([], $this->getPagesChanges());
    $this->assertImportsUnchanged($imports);
  }

  /**
   * Puts the site in the state of a 1.1.0-beta2 site, with some imports.
   *
   * Then "pages" was stored as text, which is not what the code says now.
   *
   * @return string[]
   *   The pages that were stored, keyed by the ID of the import.
   */
  protected function installBeta2State(): array {
    $update_manager = $this->container->get('entity.definition_update_manager');
    $stored_definition = $update_manager->getFieldStorageDefinition('pages', 'localgov_import');
    $beta2_definition = BaseFieldDefinition::createFromFieldStorageDefinition($stored_definition);
    $beta2_definition->setSetting('case_sensitive', FALSE);
    // There is no data yet, so Drupal changes the column.
    $update_manager->updateFieldStorageDefinition($beta2_definition);

    $imports = [];
    foreach (['Café', 'Ünïcode', 'Case SENSITIVE'] as $title) {
      $pages = serialize([$title, strtolower($title), strtoupper($title)]);
      $import = Import::create(['title' => $title, 'pages' => $pages]);
      $import->save();
      $imports[$import->id()] = $pages;
    }
    return $imports;
  }

  /**
   * Gets what the status report says about the localgov_import entity.
   *
   * @return string[]
   *   The messages, which are empty if the site is up to date.
   */
  protected function getPagesChanges(): array {
    $summary = $this->container->get('entity.definition_update_manager')->getChangeSummary();
    return array_map('strval', $summary['localgov_import'] ?? []);
  }

  /**
   * Gets the type of the "pages" DB column.
   */
  protected function getPagesColumnType(): string {
    $column = Database::getConnection()->query("SHOW COLUMNS FROM {localgov_import} LIKE 'pages'")->fetchObject();
    assert($column instanceof \stdClass);
    return strtolower($column->Type);
  }

  /**
   * Asserts that the pages of the imports are still what they were.
   *
   * @param string[] $imports
   *   The pages that were stored, keyed by the ID of the import.
   */
  protected function assertImportsUnchanged(array $imports): void {
    $stored = Database::getConnection()->query('SELECT id, pages FROM {localgov_import}')->fetchAllKeyed();
    $this->assertSame($imports, array_map('strval', $stored));
    $storage = $this->container->get('entity_type.manager')->getStorage('localgov_import');
    $storage->resetCache();
    foreach ($imports as $id => $pages) {
      $this->assertSame($pages, $storage->load($id)->get('pages')->value);
    }
  }

}
