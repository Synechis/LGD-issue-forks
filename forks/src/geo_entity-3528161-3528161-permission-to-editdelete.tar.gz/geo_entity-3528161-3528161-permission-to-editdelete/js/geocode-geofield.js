Drupal.behaviors.geoEntityGeocodeGeofield = {
  attach(context, settings) {
    Object.keys(settings.geoEntityGeocode.geofield).forEach((formId) => {
      once(
        "geoEntityGeocodeGeofield",
        document.querySelectorAll(`form[id^="${formId}"]`),
      ).forEach((form) => {
        const applyPoint = (ev) => {
          const lon = document.getElementById(
            settings.geoEntityGeocode.geofield[formId].lon,
          );
          const lat = document.getElementById(
            settings.geoEntityGeocode.geofield[formId].lat,
          );
          lon.value = ev.detail.lon;
          lat.value = ev.detail.lat;
          lat.dispatchEvent(new Event("change", { bubbles: true }));
        };
        form.addEventListener("geoEntityGeocode", applyPoint);
      });
    });
  },
};
