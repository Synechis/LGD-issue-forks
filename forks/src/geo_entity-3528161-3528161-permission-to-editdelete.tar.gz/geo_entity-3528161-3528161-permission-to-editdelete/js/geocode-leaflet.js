/* eslint-disable func-names */
(function (drupalSettings) {
  Drupal.behaviors.geoEntityGeocodeLeaflet = {
    attach(context, settings) {
      Object.keys(settings.geoEntityGeocode.leaflet).forEach((formId) => {
        once(
          "geoEntityGeocodeLeaflet",
          document.querySelectorAll(`form[id^="${formId}"]`),
        ).forEach((form) => {
          const applyPoint = (ev) => {
            const mapId = settings.geoEntityGeocode.leaflet[formId];
            const jsonElementName =
              settings.leaflet[mapId].leaflet_widget.jsonElement.substring(1);
            const inputField =
              ev.target.getElementsByClassName(jsonElementName)[0];
            inputField.value = `{"type":"Point","coordinates":[${ev.detail.lon}, ${ev.detail.lat}]}`;
            inputField.dispatchEvent(new Event("change", { bubbles: true }));
          };
          form.addEventListener("geoEntityGeocode", applyPoint);
        });
      });
    },
  };
})(drupalSettings);
