<?php

namespace Drupal\localgov_scarfolk\Hook;

use Drupal\Core\Hook\Attribute\Hook;

/**
 * Hook implementations for localgov_scarfolk.
 */
class LocalgovScarfolkHooks {
  /**
   * @file
   * Theme functions for the LocalGov Drupal Scarfolk Council theme.
   */

  /**
   * Implements hook_views_pre_render().
   */
  #[Hook('views_pre_render')]
  public function viewsPreRender($view): void {
    // Attach the events library to the events view.
    if ($view->id() === 'localgov_events_listing') {
      $view->element['#attached']['library'][] = 'localgov_scarfolk/events';
    }
  }

  /**
   * Implements hook_preprocess_HOOK() for node templates.
   */
  #[Hook('preprocess_node')]
  public function preprocessNode(&$variables): void {
    // Attach the publications library to publication nodes.
    if ($variables['node']->bundle() === 'localgov_publication_page' || $variables['node']->bundle() === 'localgov_publication_cover_page') {
      $variables['#attached']['library'][] = 'localgov_scarfolk/publications';
    }
  }

}
