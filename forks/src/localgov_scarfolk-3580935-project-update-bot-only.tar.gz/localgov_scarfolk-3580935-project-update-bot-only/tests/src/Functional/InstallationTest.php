<?php

namespace Drupal\Tests\localgov_scarfolk\Functional;

use PHPUnit\Framework\Attributes\Group;
use PHPUnit\Framework\Attributes\RunTestsInSeparateProcesses;
use Drupal\Tests\BrowserTestBase;
use Drupal\Tests\SchemaCheckTestTrait;

/**
 * Tests the Scarfolk Council theme installs correctly.
 *
 * @group localgov_scarfolk
 */
#[Group('localgov_scarfolk')]
#[RunTestsInSeparateProcesses]
class InstallationTest extends BrowserTestBase {

  use SchemaCheckTestTrait;

  /**
   * {@inheritdoc}
   */
  protected $defaultTheme = 'localgov_scarfolk';

  /**
   * Tests theme installation and default configuration.
   */
  public function testThemeInstalled(): void {
    $theme_handler = \Drupal::service('theme_handler');
    $this->assertTrue($theme_handler->themeExists('localgov_scarfolk'));
    $this->assertTrue($theme_handler->themeExists('localgov_base'));
  }

  /**
   * Tests default theme settings are applied on install.
   */
  public function testDefaultSettings(): void {
    $config = $this->config('localgov_scarfolk.settings');
    $this->assertTrue($config->get('localgov_base_add_unpublished_background_colour'));
    $this->assertEquals('default', $config->get('localgov_base_header_behaviour'));
    $this->assertTrue($config->get('localgov_base_localgov_guides_vertical_navigation'));
  }

  /**
   * Tests all declared regions are available.
   */
  public function testRegionsExist(): void {
    $theme_handler = \Drupal::service('theme_handler');
    $regions = $theme_handler->getTheme('localgov_scarfolk')->info['regions'];

    $expected_regions = [
      'tabs',
      'header',
      'search',
      'mobile_search',
      'primary_menu',
      'secondary_menu',
      'subsites_menu',
      'banner',
      'breadcrumb',
      'messages',
      'content_top',
      'content',
      'content_bottom',
      'sidebar_first',
      'sidebar_second',
      'footer_first',
      'footer_second',
      'footer_third',
      'footer',
      'lower_footer_first',
      'lower_footer_second',
      'lower_footer_third',
      'housekeeping',
      'disabled',
    ];

    foreach ($expected_regions as $region) {
      $this->assertArrayHasKey($region, $regions, "Region '$region' is missing.");
    }
  }

  /**
   * Tests the front page renders with the theme active.
   */
  public function testFrontPageRenders(): void {
    $this->drupalGet('<front>');
    $this->assertSession()->statusCodeEquals(200);
  }

  /**
   * Tests the config schema is valid.
   */
  public function testConfigSchema(): void {
    $typed_config = \Drupal::service('config.typed');
    $config = $this->config('localgov_scarfolk.settings');
    $this->assertConfigSchema($typed_config, 'localgov_scarfolk.settings', $config->get());
  }

}
