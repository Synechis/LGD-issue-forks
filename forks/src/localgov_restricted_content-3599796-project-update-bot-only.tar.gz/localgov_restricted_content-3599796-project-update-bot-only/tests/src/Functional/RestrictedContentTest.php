<?php

namespace Drupal\Tests\localgov_restricted_content\Functional;

use PHPUnit\Framework\Attributes\Group;
use PHPUnit\Framework\Attributes\RunTestsInSeparateProcesses;
use Drupal\Core\Entity\Entity\EntityViewDisplay;
use Drupal\Core\Entity\Entity\EntityViewMode;
use Drupal\field\Entity\FieldConfig;
use Drupal\field\Entity\FieldStorageConfig;
use Drupal\node\Entity\NodeType;
use Drupal\node\NodeInterface;
use Drupal\Tests\BrowserTestBase;
use Drupal\Tests\node\Traits\NodeCreationTrait;

/**
 * Functional tests for LocalGov Restricted Content.
 *
 * Covers the browser-facing behaviour: sign-in prompts for anonymous users,
 * normal access for authenticated users, and inherited restriction.
 *
 * @group localgov_restricted_content
 */
#[Group('localgov_restricted_content')]
#[RunTestsInSeparateProcesses]
class RestrictedContentTest extends BrowserTestBase {

  use NodeCreationTrait;

  /**
   * {@inheritdoc}
   */
  protected $defaultTheme = 'stark';

  /**
   * {@inheritdoc}
   */
  protected static $modules = [
    'localgov_restricted_content',
  ];

  /**
   * {@inheritdoc}
   */
  protected function setUp(): void {
    parent::setUp();

    // Create a content type for restriction testing.
    NodeType::create(['type' => 'test_page', 'name' => 'Test page'])->save();

    // Create and attach the boolean restriction field.
    FieldStorageConfig::create([
      'field_name' => 'localgov_restricted_content',
      'entity_type' => 'node',
      'type' => 'boolean',
    ])->save();
    FieldConfig::create([
      'field_name' => 'localgov_restricted_content',
      'entity_type' => 'node',
      'bundle' => 'test_page',
      'label' => 'Restricted content',
    ])->save();

    // Configure the module to treat test_page as a restrictable type.
    \Drupal::configFactory()
      ->getEditable('localgov_restricted_content.settings')
      ->set('restricted_content_types', ['test_page'])
      ->save();

    // Create the full_anonymous view mode. The module switches anonymous users
    // to this view mode when they visit restricted content, leaving the default
    // display unchanged for unrestricted content.
    EntityViewMode::create([
      'id' => 'node.full_anonymous',
      'targetEntityType' => 'node',
      'label' => 'Full anonymous',
      'status' => TRUE,
    ])->save();

    // Enable the sign-in display field on the full_anonymous display only.
    // The default display intentionally does not have this field, so the
    // sign-in prompt only appears when the view mode has been switched.
    EntityViewDisplay::create([
      'targetEntityType' => 'node',
      'bundle' => 'test_page',
      'mode' => 'full_anonymous',
      'status' => TRUE,
    ])->setComponent('restricted_content_sign_in_with_message', ['weight' => 100])
      ->save();
  }

  /**
   * Anonymous user sees the sign-in prompt on a restricted page.
   */
  public function testAnonymousSeesSignInOnRestrictedContent(): void {
    $node = $this->createNode([
      'type' => 'test_page',
      'status' => NodeInterface::PUBLISHED,
      'localgov_restricted_content' => 1,
    ]);

    $this->drupalGet($node->toUrl());
    $this->assertSession()->statusCodeEquals(200);
    $this->assertSession()->pageTextContains('This page is restricted, please sign in to see the full page.');
    $this->assertSession()->linkExists('Sign in');
  }

  /**
   * Anonymous user does not see the sign-in prompt on an unrestricted page.
   */
  public function testAnonymousDoesNotSeeSignInOnUnrestrictedContent(): void {
    $node = $this->createNode([
      'type' => 'test_page',
      'status' => NodeInterface::PUBLISHED,
      'localgov_restricted_content' => 0,
    ]);

    $this->drupalGet($node->toUrl());
    $this->assertSession()->statusCodeEquals(200);
    $this->assertSession()->pageTextNotContains('This page is restricted, please sign in to see the full page.');
  }

  /**
   * Authenticated user does not see the sign-in prompt on a restricted page.
   */
  public function testAuthenticatedDoesNotSeeSignInOnRestrictedContent(): void {
    $user = $this->drupalCreateUser(['access content']);
    $this->drupalLogin($user);

    $node = $this->createNode([
      'type' => 'test_page',
      'status' => NodeInterface::PUBLISHED,
      'localgov_restricted_content' => 1,
    ]);

    $this->drupalGet($node->toUrl());
    $this->assertSession()->statusCodeEquals(200);
    $this->assertSession()->pageTextNotContains('This page is restricted, please sign in to see the full page.');
  }

  /**
   * Child content inherits restriction when its parent is restricted.
   */
  public function testInheritedRestriction(): void {
    // Create a parent content type that is also restrictable.
    NodeType::create(['type' => 'test_parent', 'name' => 'Test parent'])->save();
    FieldConfig::create([
      'field_name' => 'localgov_restricted_content',
      'entity_type' => 'node',
      'bundle' => 'test_parent',
      'label' => 'Restricted content',
    ])->save();

    // Add the localgov_newsroom parent reference field to test_page.
    FieldStorageConfig::create([
      'field_name' => 'localgov_newsroom',
      'entity_type' => 'node',
      'type' => 'entity_reference',
      'settings' => ['target_type' => 'node'],
    ])->save();
    FieldConfig::create([
      'field_name' => 'localgov_newsroom',
      'entity_type' => 'node',
      'bundle' => 'test_page',
      'label' => 'Parent',
    ])->save();

    // Update config to include both types.
    \Drupal::configFactory()
      ->getEditable('localgov_restricted_content.settings')
      ->set('restricted_content_types', ['test_page', 'test_parent'])
      ->save();

    $parent = $this->createNode([
      'type' => 'test_parent',
      'status' => NodeInterface::PUBLISHED,
      'localgov_restricted_content' => 1,
    ]);

    $child = $this->createNode([
      'type' => 'test_page',
      'status' => NodeInterface::PUBLISHED,
      'localgov_restricted_content' => 0,
      'localgov_newsroom' => ['target_id' => $parent->id()],
    ]);

    // Anonymous user should see the sign-in prompt because the parent is
    // restricted, even though the child itself is not marked restricted.
    $this->drupalGet($child->toUrl());
    $this->assertSession()->statusCodeEquals(200);
    $this->assertSession()->pageTextContains('This page is restricted, please sign in to see the full page.');
  }

  /**
   * Admin user can access the restricted content settings page.
   */
  public function testAdminConfigPage(): void {
    $admin = $this->drupalCreateUser(['administer localgov restricted content']);
    $this->drupalLogin($admin);

    $this->drupalGet('/admin/config/content/restricted-content');
    $this->assertSession()->statusCodeEquals(200);
    $this->assertSession()->pageTextContains('Content types');
  }

}
