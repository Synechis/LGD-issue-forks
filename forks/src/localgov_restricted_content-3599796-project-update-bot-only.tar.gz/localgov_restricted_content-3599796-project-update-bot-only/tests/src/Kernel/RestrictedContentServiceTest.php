<?php

namespace Drupal\Tests\localgov_restricted_content\Kernel;

use PHPUnit\Framework\Attributes\Group;
use PHPUnit\Framework\Attributes\RunTestsInSeparateProcesses;
use Drupal\field\Entity\FieldConfig;
use Drupal\field\Entity\FieldStorageConfig;
use Drupal\KernelTests\KernelTestBase;
use Drupal\node\Entity\Node;
use Drupal\node\Entity\NodeType;
use Drupal\Tests\node\Traits\NodeCreationTrait;

/**
 * Tests the RestrictedContent service.
 *
 * Covers isEntityRestrictable(), isRestricted(), and isAncestorRestricted().
 *
 * @group localgov_restricted_content
 */
#[Group('localgov_restricted_content')]
#[RunTestsInSeparateProcesses]
class RestrictedContentServiceTest extends KernelTestBase {

  use NodeCreationTrait;

  /**
   * {@inheritdoc}
   */
  protected static $modules = [
    'system',
    'field',
    'options',
    'user',
    'node',
    'filter',
    'block',
    'field_group',
    'localgov_core',
    'localgov_restricted_content',
  ];

  /**
   * The service under test.
   *
   * @var \Drupal\localgov_restricted_content\RestrictedContentInterface
   */
  protected $restrictedContent;

  /**
   * {@inheritdoc}
   */
  protected function setUp(): void {
    parent::setUp();

    $this->installEntitySchema('user');
    $this->installEntitySchema('node');
    $this->installSchema('node', ['node_access']);
    $this->installConfig(['system', 'field', 'filter', 'localgov_restricted_content']);

    // Create the content types used across tests.
    NodeType::create(['type' => 'restrictable', 'name' => 'Restrictable'])->save();
    NodeType::create(['type' => 'parent_type', 'name' => 'Parent type'])->save();
    NodeType::create(['type' => 'other_type', 'name' => 'Other type'])->save();

    // Create the boolean restriction field storage.
    FieldStorageConfig::create([
      'field_name' => 'localgov_restricted_content',
      'entity_type' => 'node',
      'type' => 'boolean',
    ])->save();

    // Attach the restriction field to the configured types only.
    foreach (['restrictable', 'parent_type'] as $bundle) {
      FieldConfig::create([
        'field_name' => 'localgov_restricted_content',
        'entity_type' => 'node',
        'bundle' => $bundle,
        'label' => 'Restricted content',
      ])->save();
    }

    // Create a parent reference field (simulating localgov_newsroom).
    FieldStorageConfig::create([
      'field_name' => 'localgov_newsroom',
      'entity_type' => 'node',
      'type' => 'entity_reference',
      'settings' => ['target_type' => 'node'],
    ])->save();

    FieldConfig::create([
      'field_name' => 'localgov_newsroom',
      'entity_type' => 'node',
      'bundle' => 'restrictable',
      'label' => 'Newsroom',
    ])->save();

    // Configure the module: restrictable and parent_type are enabled,
    // other_type is not.
    $this->container->get('config.factory')
      ->getEditable('localgov_restricted_content.settings')
      ->set('restricted_content_types', ['restrictable', 'parent_type'])
      ->save();

    $this->restrictedContent = $this->container->get('localgov_restricted_content.restricted_content');
  }

  /**
   * Tests isEntityRestrictable().
   */
  public function testIsEntityRestrictable(): void {
    // Configured type with the field: restrictable.
    $node = Node::create(['type' => 'restrictable', 'title' => $this->randomString()]);
    $node->save();
    $this->assertTrue($this->restrictedContent->isEntityRestrictable($node));

    // Type not in config (even though the field is not present): not
    // restrictable.
    $other = Node::create(['type' => 'other_type', 'title' => $this->randomString()]);
    $other->save();
    $this->assertFalse($this->restrictedContent->isEntityRestrictable($other));
  }

  /**
   * Tests isRestricted() via the boolean field value.
   */
  public function testIsRestricted(): void {
    $unrestricted = Node::create([
      'type' => 'restrictable',
      'title' => $this->randomString(),
      'localgov_restricted_content' => 0,
    ]);
    $unrestricted->save();
    $this->assertFalse($this->restrictedContent->isRestricted($unrestricted));

    $restricted = Node::create([
      'type' => 'restrictable',
      'title' => $this->randomString(),
      'localgov_restricted_content' => 1,
    ]);
    $restricted->save();
    $this->assertTrue($this->restrictedContent->isRestricted($restricted));
  }

  /**
   * Tests that restriction is inherited through the parent reference field.
   */
  public function testIsAncestorRestricted(): void {
    $parent = Node::create([
      'type' => 'parent_type',
      'title' => $this->randomString(),
      'localgov_restricted_content' => 0,
    ]);
    $parent->save();

    $child = Node::create([
      'type' => 'restrictable',
      'title' => $this->randomString(),
      'localgov_restricted_content' => 0,
      'localgov_newsroom' => ['target_id' => $parent->id()],
    ]);
    $child->save();

    // Unrestricted parent: no inherited restriction.
    $this->assertFalse($this->restrictedContent->isAncestorRestricted($child));
    $this->assertFalse($this->restrictedContent->isRestricted($child));

    // Restrict the parent. Reload $child so the entity reference cache on
    // the localgov_newsroom field item is cleared; without a reload the
    // computed 'entity' property would still return the stale parent.
    $parent->set('localgov_restricted_content', 1)->save();
    $child = Node::load($child->id());

    $this->assertTrue($this->restrictedContent->isAncestorRestricted($child));
    $this->assertTrue($this->restrictedContent->isRestricted($child));
  }

  /**
   * Tests that a type without a parent reference field never inherits.
   */
  public function testNoParentFieldDoesNotInherit(): void {
    // parent_type has the restriction field but no parent reference field,
    // so ancestor checks must always return FALSE.
    $node = Node::create([
      'type' => 'parent_type',
      'title' => $this->randomString(),
      'localgov_restricted_content' => 0,
    ]);
    $node->save();
    $this->assertFalse($this->restrictedContent->isAncestorRestricted($node));
  }

}
