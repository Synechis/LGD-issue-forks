<?php

namespace Drupal\localgov_restricted_content\Hook;

use Drupal\Core\Entity\Display\EntityViewDisplayInterface;
use Drupal\Core\Entity\EntityInterface;
use Drupal\Core\Entity\ContentEntityFormInterface;
use Drupal\Core\Form\FormStateInterface;
use Drupal\Core\Hook\Attribute\Hook;
use Drupal\Core\StringTranslation\StringTranslationTrait;

/**
 * Hook implementations for localgov_restricted_content.
 */
class LocalgovRestrictedContentHooks {
  use StringTranslationTrait;

  /**
   * Implements hook_entity_view_mode_alter().
   */
  #[Hook('entity_view_mode_alter')]
  public function entityViewModeAlter(&$view_mode, $entity, $context) {
    if ($entity->getEntityTypeId() === 'node' and \Drupal::currentUser()->isAnonymous() and \Drupal::service('localgov_restricted_content.restricted_content')->isRestricted($entity)) {
      // Check the anonymous view display mode exists before using it.
      $entity_view_display = \Drupal::entityTypeManager()->getStorage('entity_view_display');
      $anonymous_view_mode = $view_mode . '_anonymous';
      if ($entity_view_display->load('node.' . $entity->bundle() . '.' . $anonymous_view_mode)) {
        $view_mode = $anonymous_view_mode;
      }
    }
  }

  /**
   * Implements hook_form_FORM_ID_alter().
   */
  #[Hook('form_node_form_alter')]
  public function formNodeFormAlter(&$form, FormStateInterface $form_state, $form_id) {
    $form_object = $form_state->getFormObject();
    if (!$form_object instanceof ContentEntityFormInterface) {
      return;
    }
    $entity = $form_object->getEntity();
    // Only display restricted content checkbox for selected content types.
    $form['localgov_restricted_content']['#access'] = FALSE;
    $config = \Drupal::config('localgov_restricted_content.settings');
    foreach ($config->get('restricted_content_types') as $content_type) {
      if (in_array($form_id, [
        'node_' . $content_type . '_form',
        'node_' . $content_type . '_edit_form',
      ])) {
        $form['localgov_restricted_content']['#access'] = TRUE;
        /** @var \Drupal\localgov_restricted_content\RestrictedContentInterface $restricted_content */
        $restricted_content = \Drupal::service('localgov_restricted_content.restricted_content');
        if ($restricted_content->isAncestorRestricted($entity)) {
          $form['localgov_restricted_content']['#prefix'] = $this->t('<span class="form-item__description">This is disabled because the page\'s parent is restricted.</span>');
          $form['localgov_restricted_content']['#disabled'] = TRUE;
        }
        break;
      }
    }
  }

  /**
   * Implements hook_entity_extra_field_info().
   */
  #[Hook('entity_extra_field_info')]
  public function entityExtraFieldInfo() {
    $return = [];
    $config = \Drupal::config('localgov_restricted_content.settings');
    foreach ($config->get('restricted_content_types') as $content_type) {
      $return['node'][$content_type]['display']['restricted_content_sign_in'] = [
        'label' => $this->t('Sign in link for listings'),
        'description' => $this->t('Display sign in link on teasers, cards, etc.'),
        'visible' => FALSE,
        'weight' => 0,
      ];
      $return['node'][$content_type]['display']['restricted_content_sign_in_with_message'] = [
        'label' => $this->t('Sign in link for pages'),
        'description' => $this->t('Display sign in link with message on a restricted content page.'),
        'visible' => FALSE,
        'weight' => 0,
      ];
    }
    return $return;
  }

  /**
   * Implements hook_entity_view().
   *
   * Display sign-in message and/or link for anonymous users.
   */
  #[Hook('entity_view')]
  public function entityView(array &$build, EntityInterface $entity, EntityViewDisplayInterface $display, $view_mode) {
    if (\Drupal::currentUser()->isAuthenticated()) {
      return;
    }
    $content = $display->get('content');
    if (isset($content['restricted_content_sign_in_with_message'])) {
      $build['sign_in'] = [
        '#theme' => 'localgov_restricted_content_sign_in_with_message',
      ];
    }
    elseif (isset($content['restricted_content_sign_in'])) {
      $build['sign_in'] = [
        '#theme' => 'localgov_restricted_content_sign_in',
        '#destination' => $entity->toUrl(),
      ];
    }
  }

  /**
   * Implements hook_theme().
   */
  #[Hook('theme')]
  public function theme($existing, $type, $theme, $path) {
    return [
      'localgov_restricted_content_sign_in' => [
        'render element' => 'elements',
        'variables' => [
          'destination' => NULL,
        ],
      ],
      'localgov_restricted_content_sign_in_with_message' => [
        'render element' => 'elements',
        'variables' => [
          'destination' => NULL,
        ],
      ],
    ];
  }

}
