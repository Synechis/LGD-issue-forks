<?php

namespace Drupal\localgov_news\Hook;

use Drupal\Core\Entity\EntityFormInterface;
use Drupal\Core\Form\FormStateInterface;
use Drupal\Core\Entity\Display\EntityViewDisplayInterface;
use Drupal\node\NodeInterface;
use Drupal\localgov_news\NewsExtraFieldDisplay;
use Drupal\Core\Hook\Attribute\Hook;
use Drupal\Core\StringTranslation\StringTranslationTrait;

/**
 * Hook implementations for localgov_news.
 */
class LocalgovNewsHooks {
  use StringTranslationTrait;

  /**
   * Implements hook_theme().
   */
  #[Hook('theme')]
  public function theme($existing, $type, $theme, $path) {
    return [
      'node__localgov_news_article__teaser' => [
        'template' => 'node--localgov-news-article--teaser',
        'base hook' => 'node',
      ],
      'node__localgov_news_article__full' => [
        'template' => 'node--localgov-news-article--full',
        'base hook' => 'node',
      ],
      'field__localgov_newsroom_featured' => [
        'template' => 'field--localgov-newsroom-featured',
        'base hook' => 'field',
      ],
    ];
  }

  /**
   * Implements hook_tokens_alter().
   *
   * Needed to correctly render schema metadata for categories containing commas.
   */
  #[Hook('tokens_alter')]
  public function tokensAlter(&$replacements, $context) {
    // Remove commas in news categories so they are not split.
    if ($context['type'] == 'node') {
      if (isset($replacements['[node:localgov_news_categories:0:entity]'])) {
        $replacements['[node:localgov_news_categories:0:entity]'] = stripslashes(str_replace(',', '', $replacements['[node:localgov_news_categories:0:entity]']));
      }
    }
  }

  /**
   * Implements hook_entity_extra_field_info().
   */
  #[Hook('entity_extra_field_info')]
  public function entityExtraFieldInfo() {
    return \Drupal::service('class_resolver')->getInstanceFromDefinition(NewsExtraFieldDisplay::class)->entityExtraFieldInfo();
  }

  /**
   * Implements hook_ENTITY_TYPE_view().
   */
  #[Hook('node_view')]
  public function nodeView(array &$build, NodeInterface $node, EntityViewDisplayInterface $display, $view_mode) {
    return \Drupal::service('class_resolver')->getInstanceFromDefinition(NewsExtraFieldDisplay::class)->nodeView($build, $node, $display, $view_mode);
  }

  /**
   * Implements hook_form_alter().
   */
  #[Hook('form_alter')]
  public function formAlter(array &$form, FormStateInterface $form_state, $form_id) {
    return \Drupal::service('class_resolver')->getInstanceFromDefinition(NewsExtraFieldDisplay::class)->formAlter($form, $form_state, $form_id);
  }

  /**
   * Implements hook_field_widget_complete_form_alter().
   */
  #[Hook('field_widget_complete_form_alter')]
  public function fieldWidgetCompleteFormAlter(&$field_widget_complete_form, FormStateInterface $form_state, $context) {
    // If the localgov_newsroom field only has one newsroom to choose, just select
    // it and hide the field.
    $field_definition = $context['items']->getFieldDefinition();
    if ($field_definition->getName() == 'localgov_newsroom' && isset($field_widget_complete_form['widget']['#options'])) {
      $options = $field_widget_complete_form['widget']['#options'];
      // If there are no newsrooms display a warning.
      if (count($options) == 1 && isset($options['_none'])) {
        $create_newsroom_path = 'localgov_newsroom';
        if (\Drupal::moduleHandler()->moduleExists('localgov_microsites_group')) {
          // @phpstan-ignore-next-line Ignore the next line as this is only present on microsites.
          $group = localgov_microsites_group_get_by_context();
          // @phpstan-ignore-next-line Ignore the next line as this is only present on microsites.
          if ($group instanceof \GroupInterface) {
            $create_newsroom_path = 'group_node:' . $create_newsroom_path;
          }
        }
        \Drupal::messenger()->addWarning($this->t('There are no Newsrooms. Please <a href="./@link">create a Newsroom</a> first, before creating this news article.', [
          '@link' => $create_newsroom_path,
        ]));
      }
      unset($options['_none']);
      if (count($options) == 1) {
        $field_widget_complete_form['widget']['#value'] = key($options);
        $field_widget_complete_form['widget']['#type'] = 'value';
      }
    }
    // Restrict the featured articles to articles in the newsroom.
    // A more durable, and transparent, way of doing this will be to add a custom
    // handler.
    // This is presently just restricting the search query and not the field
    // itself.
    if ($field_definition->getName() == 'localgov_newsroom_featured') {
      if ($form_state->getFormObject() instanceof EntityFormInterface) {
        $nid = $form_state->getformObject()->getEntity()->id();
      }
      if (isset($nid)) {
        foreach ($field_widget_complete_form['widget'] as $delta => $element) {
          if (!empty($element['target_id']) && $element['target_id']['#selection_handler'] == 'views') {
            $field_widget_complete_form['widget'][$delta]['target_id']['#selection_settings']['view']['arguments'] = [
              $nid,
            ];
          }
        }
      }
    }
  }

}
