<?php

namespace Drupal\govuk_pay_webform\Controller;

/**
 * Exception for when constructing data in the Webform Controller.
 *
 * @see \Drupal\govuk_pay_webform\Controller\GovPayWebformController
 */
class GovPayWebformControllerException extends \RuntimeException {}
