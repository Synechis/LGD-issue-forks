<?php

namespace Drupal\govuk_pay_webform\Controller;

use Drupal\Component\Render\FormattableMarkup;
use Drupal\Component\Render\MarkupInterface;
use Drupal\Core\Config\ConfigFactoryInterface;
use Drupal\Core\Controller\ControllerBase;
use Drupal\Core\Entity\EntityTypeManagerInterface;
use Drupal\Core\Messenger\MessengerInterface;
use Drupal\Core\Routing\TrustedRedirectResponse;
use Drupal\Core\StringTranslation\TranslatableMarkup;
use Drupal\Core\TempStore\PrivateTempStoreFactory;
use Drupal\Core\Url;
use Drupal\Core\Utility\Error;
use Drupal\Core\Utility\Token;
use Drupal\govuk_pay\Entity\GovUkPayment;
use Drupal\govuk_pay\PaymentEventService;
use Drupal\govuk_pay_webform\GovUkPayWebformService;
use Drupal\webform\Entity\Webform;
use Drupal\webform\Plugin\WebformHandlerInterface;
use Drupal\webform\WebformInterface;
use Psr\Log\LoggerInterface;
use Symfony\Component\HttpFoundation\RequestStack;
use Symfony\Component\DependencyInjection\ContainerInterface;

/**
 * Page controller for displaying GOV.UK Pay content on behalf of Webform.
 */
class GovPayWebformController extends ControllerBase {

  /**
   * The entity type manager.
   *
   * @var \Drupal\Core\Entity\EntityTypeManagerInterface
   */
  protected $entityTypeManager;

  /**
   * The GOV.UK Pay Webform service.
   *
   * @var \Drupal\govuk_pay_webform\GovUkPayWebformService
   */
  protected $paymentService;

  /**
   * The payment event service.
   *
   * @var \Drupal\govuk_pay\PaymentEventService
   */
  protected $paymentEventService;

  /**
   * The request stack.
   *
   * @var \Symfony\Component\HttpFoundation\RequestStack
   */
  protected $requestStack;

  /**
   * The messenger.
   *
   * @var \Drupal\Core\Messenger\MessengerInterface
   */
  protected $messenger;

  /**
   * The logger.
   *
   * @var \Psr\Log\LoggerInterface
   */
  protected $logger;

  /**
   * The token service.
   *
   * @var \Drupal\Core\Utility\Token
   */
  protected $token;

  /**
   * The config factory.
   *
   * @var \Drupal\Core\Config\ConfigFactoryInterface
   */
  protected $configFactory;

  /**
   * Whether verbose logging is enabled.
   *
   * @var bool
   */
  protected $verboseLogging;

  /**
   * The tempstore service.
   *
   * @var \Drupal\Core\TempStore\PrivateTempStore
   */
  protected $tempStore;

  /**
   * Constructs a new GovPayWebformController object.
   *
   * @param \Drupal\Core\Entity\EntityTypeManagerInterface $entity_type_manager
   *   The entity type manager.
   * @param \Drupal\govuk_pay_webform\GovUkPayWebformService $payment_service
   *   The GOV.UK Pay Webform service.
   * @param \Drupal\govuk_pay\PaymentEventService $payment_event_service
   *   The payment event service.
   * @param \Symfony\Component\HttpFoundation\RequestStack $request_stack
   *   The request stack.
   * @param \Drupal\Core\Messenger\MessengerInterface $messenger
   *   The messenger.
   * @param \Psr\Log\LoggerInterface $logger
   *   The logger.
   * @param \Drupal\Core\Utility\Token $token
   *   The token service.
   * @param \Drupal\Core\Config\ConfigFactoryInterface $config_factory
   *   The config factory.
   * @param \Drupal\Core\TempStore\PrivateTempStoreFactory $temp_store_factory
   *   The tempstore factory.
   */
  public function __construct(
    EntityTypeManagerInterface $entity_type_manager,
    GovUkPayWebformService $payment_service,
    PaymentEventService $payment_event_service,
    RequestStack $request_stack,
    MessengerInterface $messenger,
    LoggerInterface $logger,
    Token $token,
    ConfigFactoryInterface $config_factory,
    PrivateTempStoreFactory $temp_store_factory,
  ) {
    $this->entityTypeManager = $entity_type_manager;
    $this->paymentService = $payment_service;
    $this->paymentEventService = $payment_event_service;
    $this->requestStack = $request_stack;
    $this->messenger = $messenger;
    $this->logger = $logger;
    $this->token = $token;
    $this->configFactory = $config_factory;
    $this->verboseLogging = (bool) $this->configFactory->get('govuk_pay.settings')->get('verbose_logging');
    $this->tempStore = $temp_store_factory->get('govuk_pay_webform');
  }

  /**
   * {@inheritdoc}
   */
  public static function create(ContainerInterface $container) {
    return new static(
      $container->get('entity_type.manager'),
      $container->get('govuk_pay_webform.payment_service'),
      $container->get('govuk_pay.payment_event_service'),
      $container->get('request_stack'),
      $container->get('messenger'),
      $container->get('logger.factory')->get('govuk_pay_webform'),
      $container->get('token'),
      $container->get('config.factory'),
      $container->get('tempstore.private')
    );
  }

  /**
   * Creates the Confirmation page title.
   *
   * @return \Drupal\Core\StringTranslation\TranslatableMarkup
   */
  public function confirmationPageTitle(): TranslatableMarkup {
    $session_payment_data = $this->getPaymentSession();
    if (isset($session_payment_data['webform_id'])) {
      $webform = Webform::load($session_payment_data['webform_id']);
      return new TranslatableMarkup('@title', ['@title' => $webform->label()]);
    }

    return new TranslatableMarkup('Your payment');
  }

  /**
   * Builds the Confirmation page.
   *
   * @return array
   *   Render array.
   */
  public function confirmationPage(): array {
    try {
      $session_payment_data = $this->getPaymentSession();
      $payment_details = $this->getPaymentDetails(
        $session_payment_data['uuid'],
        $session_payment_data['webform_id'],
        $session_payment_data['submission_id']
      );
      $this->updatePaymentEntity($session_payment_data['uuid'], $payment_details);
    }
    catch (GovPayWebformControllerException $e) {
      if (isset($session_payment_data['webform_id'])) {
      }
      return [
        '#theme' => 'govuk_pay_webform__payment_error_page',
        '#error' => $e->getMessage(),
        '#cache' => ['max-age' => 0],
      ];
    }

    $page = [];
    $page['#payment_id'] = $payment_details['payment_id'];
    $page['#status'] = $payment_details['status'];
    $page['#code'] = $payment_details['code'];
    $page['#amount'] = $payment_details['amount'];
    $page['#payment_for'] = $payment_details['payment_for'];
    $page['#payment_reference'] = $payment_details['payment_reference'];
    if (in_array($payment_details['status'], ['failed', 'cancelled', 'error'])) {
      $page['#theme'] = 'govuk_pay_webform__payment_failure_page';
      $page['#message'] = $this->getFailureMessage(
        $session_payment_data['webform_id'],
        $session_payment_data['submission_id'],
        $payment_details,
      );
      $page['#retry_url'] = Url::fromRoute('govuk_pay_webform.retry_page')->toString();
    }
    else {
      $page['#theme'] = 'govuk_pay_webform__payment_success_page';
      $page['#message'] = $this->getSuccessMessage(
        $session_payment_data['webform_id'],
        $session_payment_data['submission_id'],
        $payment_details,
      );
      // Get confirmation title from webform settings.
      $handler = $this->getWebformHandler($session_payment_data['webform_id']);
      $configuration = $handler->getConfiguration();
      $page['#confirmation_title'] = $configuration['settings']['confirmation_title'];
    }
    $page['#cache']['contexts'][] = 'session';
    $page['#cache']['max-age'] = 0;

    return $page;
  }

  public function retryPaymentRedirect() {
    try {
      $session_payment_data = $this->getPaymentSession();
      if (
        $session_payment_data['webform_id'] &&
        $session_payment_data['submission_id']
      ) {
        $handler = $this->getWebformHandler($session_payment_data['webform_id']);
        $configuration = $handler->getConfiguration();
        $webform_submission = $this
          ->entityTypeManager
          ->getStorage('webform_submission')
          ->load($session_payment_data['submission_id']);

        $this->paymentService->createPayment($webform_submission, $configuration['settings']);
        // The service puts the redirect URL in the tempStore.
        // Could be nice to refactor.
        $redirect_url = $this->tempStore->get('redirect_url');
        if (!empty($redirect_url)) {
          // Clear the stored redirect URL to prevent repeated redirects.
          $this->tempStore->delete('redirect_url');
          // Create and prepare the redirect response.
          return new TrustedRedirectResponse($redirect_url, 302);
        }
      }
    }
    catch (GovPayWebformControllerException $e) {
    }
    return [
      '#theme' => 'govuk_pay_webform__payment_error_page',
      '#error' => $e->getMessage(),
      '#cache' => ['max-age' => 0],
    ];
  }

  /**
   * Retrieve the payment data from the session.
   *
   * @return array
   *   Session payment data.
   *
   * @throws \Drupal\govuk_pay_webform\Controller\GovPayWebformControllerException
   */
  protected function getPaymentSession(): array {
    // Get payment details from the session.
    $session_payment_data = $this->paymentService->getPaymentData();
    if (is_null($session_payment_data)) {
      throw new GovPayWebformControllerException($this->t('Payment information not found. The payment session may have expired.'));
    }
    if (!isset($session_payment_data['uuid'],
      $session_payment_data['webform_id'],
      $session_payment_data['submission_id'])
    ) {
      throw new GovPayWebformControllerException($this->t('Invalid payment data. Please try again or contact support.'));
    }

    return $session_payment_data;
  }

  /**
   * Retreive latest payment details using service.
   *
   * @param string $uuid
   *   Payment UUID.
   * @param string $webform_id
   *   The webform starting the payment.
   * @param int $submission_id
   *   The webform submission ID.
   *
   * @return array
   *   Payment details array.
   *
   * @throws \Drupal\govuk_pay_webform\Controller\GovPayWebformControllerException
   */
  protected function getPaymentDetails(string $uuid, string $webform_id, $submission_id): array {
    try {
      $payment_details = $this->paymentService->getPaymentDetails($uuid, $webform_id, $submission_id);
    }
    catch (\Exception $e) {
      Error::logException($this->logger, $e);
      throw new GovPayWebformControllerException(
        message: 'An error occurred while processing your payment information. Please contact support.',
        previous: $e,
      );
    }
    if (is_null($payment_details['payment_id']) || is_null($payment_details['status'])) {
      // @todo in what cases is this?
      $this->logger->error('Error processing payment missing webform: @webform_id', ['@webform_id' => $webform_id]);
      throw new GovPayWebformControllerException($this->t('An error occurred while processing your payment information. Please contact support.'));
    }

    return $payment_details;
  }

  /**
   * Update the Gov UK Paymente Entity.
   *
   * @param string $uuid
   *   Payment UUID.
   * @param array $payment_details
   *   Retrieved payment details.
   */
  protected function updatePaymentEntity($uuid, $payment_details): void {
     // Load the payment entity by UUID.
    $payment_storage = $this->entityTypeManager->getStorage('govukpayment');
    $payment_entities = $payment_storage->loadByProperties(['uuid' => $uuid]);
    if (empty($payment_entities)) {
      // @todo again what case is this?
      // This isn't a payment, but recording error.
      $this->messenger->addError($this->t('An error occurred while processing your payment information. Please contact support.'));
      $this->logger->error('Error processing payment missing payment record: @uuid', ['@uuid' => $uuid]);
      return;
    }

    $payment_entity = reset($payment_entities);
    assert($payment_entity instanceof GovUkPayment);
    // Only update if the status has changed.
    if ($payment_entity->get('status')->value !== $payment_details['status']) {
      $payment_entity->setNewRevision(TRUE);
      $payment_entity->setRevisionCreationTime(time());
      $payment_entity->setRevisionLogMessage('Payment status updated from ' . $payment_entity->get('status')->value . ' to ' . $payment_details['status']);
      // Set the revision owner to the current user if available.
      $current_user = $this->currentUser();
      if ($current_user) {
        $payment_entity->setRevisionUserId($current_user->id());
      }
      $payment_entity->set('status', $payment_details['status']);
      $payment_entity->save();

      // Log the update if verbose logging is enabled.
      if ($this->verboseLogging) {
        $this->logger->info('Payment status updated for UUID: @uuid from @old_status to @new_status', [
          '@uuid' => $uuid,
          '@old_status' => $payment_entity->get('status')->value,
          '@new_status' => $payment_details['status'],
        ]);
      }

      // Create a payment event for this status update.
      $this->paymentEventService->recordPaymentEvent(
        $payment_details['payment_id'],
        $payment_details['status'],
        'payment.status_updated',
        'redirect',
        [
          'payment_id' => $payment_details['payment_id'],
          'status' => $payment_details['status'],
          'previous_status' => $payment_entity->get('status')->value,
          'amount' => $this->getRawAmount($payment_details['amount']),
          'description' => $payment_details['payment_for'],
          'reference' => $payment_details['payment_reference'],
        ],
        time()
      );
    }
  }

  /**
   * Create the failure message from the Webform Plugin template.
   *
   * @param string $webform_id
   *   Webform ID.
   * @param int $submission_id
   *   Webform submission ID.
   * @param array $payment_details
   *   Payment details for token replacement.
   */
  protected function getFailureMessage($webform_id, $submission_id, $payment_details): MarkupInterface {
    $message = $this->getWebformMessage($webform_id, $submission_id, $payment_details, 'failure_message');
    // Provide default confirmation message if empty.
    if ($message === '') {
      $message = $this->t('Sorry your payment via GOV.UK Pay was not completed.<br/>'
        . 'Please try again, or contact support.'
      );
    }

    return new FormattableMarkup($message, []);
  }

  /**
   * Create the success message from the Webform Plugin template.
   *
   * @param string $webform_id
   *   Webform ID.
   * @param int $submission_id
   *   Webform submission ID.
   * @param array $payment_details
   *   Payment details for token replacement.
   */
  protected function getSuccessMessage($webform_id, $submission_id, $payment_details): MarkupInterface {
    $message = $this->getWebformMessage($webform_id, $submission_id, $payment_details, 'confirmation_message');
    // Provide default confirmation message if empty.
    if ($message === '') {
      $message = $this->t('Thank you for making a payment via GOV.UK Pay.<br/>'
        . 'If your payment has not shown as complete for over 1 day, '
        . 'please contact us with your payment ID.'
      );
    }

    return new FormattableMarkup($message, []);
  }

  /**
   * Retrieve webform template and replace tokens.
   *
   * @param string $webform_id
   *   Webform ID.
   * @param int $submission_id
   *   Webform submission ID.
   * @param array $payment_details
   *   Payment details for token replacement.
   * @param string $message_id
   *   The configuration setting that contains the message template.
   */
  protected function getWebformMessage($webform_id, $submission_id, $payment_details, $message_id): string {
    $message = '';

    // Load the submission if available for token replacement.
    $webform_submission = NULL;
    if ($submission_id) {
      $webform_submission = $this->entityTypeManager->getStorage('webform_submission')->load($submission_id);
    }
    if ($handler = $this->getWebformHandler($webform_id)) {
      $webform = Webform::load($webform_id);
      $configuration = $handler->getConfiguration();
      $message_template = $configuration['settings'][$message_id] ? $configuration['settings'][$message_id] : NULL;
      if ($message_template && $webform_submission) {
        // Replace tokens in the confirmation message.
        $token_data = [
          'webform' => $webform,
          'webform_submission' => $webform_submission,
        ];
        $message = $this->token->replace($message_template, $token_data);
      }
    }

    return $message;
  }

  protected function getWebformHandler(int|string $webform_id): ?WebformHandlerInterface {
    $webform = Webform::load($webform_id);
    if ($webform instanceof WebformInterface) {
      foreach ($webform->getHandlers() as $handler) {
        if ($handler->getPluginId() === 'govuk_pay') {
          return $handler;
        }
      }
    }
    return NULL;
  }

  /**
   * Extracts the raw amount value from a formatted amount string.
   *
   * Converts a formatted amount like "£50.00" to the raw integer value in pence
   * (5000).
   *
   * @param string $formatted_amount
   *   The formatted amount string (e.g., "£50.00").
   *
   * @return int
   *   The raw amount in pence/cents.
   */
  private function getRawAmount($formatted_amount) {
    // Remove currency symbol and any thousand separators.
    $numeric_value = preg_replace('/[^0-9.]/', '', $formatted_amount);

    // Convert to pence/cents (multiply by 100 and round to integer).
    return (int) round(floatval($numeric_value) * 100);
  }

}

