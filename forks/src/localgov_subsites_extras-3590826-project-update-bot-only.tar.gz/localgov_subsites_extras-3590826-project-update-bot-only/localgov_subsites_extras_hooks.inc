<?php

/**
 * @file
 * Hooks that we're temporarily implementing on behalf of other modules.
 *
 * Ideally, we want these hook implementations in their respective modules. For
 * the moment, we've implemented them here, and when this module is heading
 * towards a proper release, we'll open PRs to move them. Each hook is wrapped
 * in function_exists, so that the hook can exist in both modules temporarily.
 */

use Drupal\Core\Hook\Attribute\LegacyHook;
use Drupal\localgov_subsites_extras\Hook\LocalgovSubsitesExtrasHooksHooks;
use Drupal\node\NodeInterface;

if (!function_exists('localgov_directories_localgov_subsites_extras_current_node_alter')) {

  /**
   * Implements hook_localgov_subsites_extras_current_node_alter().
   */
  #[LegacyHook]
  function localgov_directories_localgov_subsites_extras_current_node_alter(?NodeInterface &$node) {
    \Drupal::service(LocalgovSubsitesExtrasHooksHooks::class)->localgovDirectoriesLocalgovSubsitesExtrasCurrentNodeAlter($node);
  }

}

if (!function_exists('localgov_guides_localgov_subsites_extras_current_node_alter')) {

  /**
   * Implements hook_localgov_subsites_extras_current_node_alter().
   */
  #[LegacyHook]
  function localgov_guides_localgov_subsites_extras_current_node_alter(?NodeInterface &$node) {
    \Drupal::service(LocalgovSubsitesExtrasHooksHooks::class)->localgovGuidesLocalgovSubsitesExtrasCurrentNodeAlter($node);
  }

}

if (!function_exists('localgov_step_by_step_localgov_subsites_extras_current_node_alter')) {

  /**
   * Implements hook_localgov_subsites_extras_current_node_alter().
   */
  #[LegacyHook]
  function localgov_step_by_step_localgov_subsites_extras_current_node_alter(?NodeInterface &$node) {
    \Drupal::service(LocalgovSubsitesExtrasHooksHooks::class)->localgovStepByStepLocalgovSubsitesExtrasCurrentNodeAlter($node);
  }

}

if (!function_exists('localgov_news_localgov_subsites_extras_current_node_alter')) {

  /**
   * Implements hook_localgov_subsites_extras_current_node_alter().
   */
  #[LegacyHook]
  function localgov_news_localgov_subsites_extras_current_node_alter(?NodeInterface &$node) {
    \Drupal::service(LocalgovSubsitesExtrasHooksHooks::class)->localgovNewsLocalgovSubsitesExtrasCurrentNodeAlter($node);
  }

}

if (!function_exists('localgov_publications_localgov_subsites_extras_current_node_alter')) {

  /**
   * Implements hook_localgov_subsites_extras_current_node_alter().
   */
  #[LegacyHook]
  function localgov_publications_localgov_subsites_extras_current_node_alter(?NodeInterface &$node) {
    \Drupal::service(LocalgovSubsitesExtrasHooksHooks::class)->localgovPublicationsLocalgovSubsitesExtrasCurrentNodeAlter($node);
  }

}

if (!function_exists('localgov_services_navigation_localgov_subsites_extras_current_node_alter')) {

  /**
   * Implements hook_localgov_subsites_extras_current_node_alter().
   */
  #[LegacyHook]
  function localgov_services_navigation_localgov_subsites_extras_current_node_alter(?NodeInterface &$node) {
    \Drupal::service(LocalgovSubsitesExtrasHooksHooks::class)->localgovServicesNavigationLocalgovSubsitesExtrasCurrentNodeAlter($node);
  }

}
