<?php

namespace Drupal\localgov_subsites_extras\Hook;

use Drupal\node\NodeInterface;
use Drupal\Core\Hook\Attribute\Hook;

/**
 * Hook implementations for localgov_subsites_extras.
 */
class LocalgovSubsitesExtrasHooksHooks {

  /**
   * Implements hook_localgov_subsites_extras_current_node_alter().
   */
  #[Hook('localgov_subsites_extras_current_node_alter', module: 'localgov_directories')]
  public function localgovDirectoriesLocalgovSubsitesExtrasCurrentNodeAlter(?NodeInterface &$node) {
    localgov_subsites_extras_follow_field($node, 'localgov_directory_channels');
  }

  /**
   * Implements hook_localgov_subsites_extras_current_node_alter().
   */
  #[Hook('localgov_subsites_extras_current_node_alter', module: 'localgov_guides')]
  public function localgovGuidesLocalgovSubsitesExtrasCurrentNodeAlter(?NodeInterface &$node) {
    localgov_subsites_extras_follow_field($node, 'localgov_guides_parent');
  }

  /**
   * Implements hook_localgov_subsites_extras_current_node_alter().
   */
  #[Hook('localgov_subsites_extras_current_node_alter', module: 'localgov_step_by_step')]
  public function localgovStepByStepLocalgovSubsitesExtrasCurrentNodeAlter(?NodeInterface &$node) {
    localgov_subsites_extras_follow_field($node, 'localgov_step_parent');
  }

  /**
   * Implements hook_localgov_subsites_extras_current_node_alter().
   */
  #[Hook('localgov_subsites_extras_current_node_alter', module: 'localgov_news')]
  public function localgovNewsLocalgovSubsitesExtrasCurrentNodeAlter(?NodeInterface &$node) {
    localgov_subsites_extras_follow_field($node, 'localgov_newsroom');
  }

  /**
   * Implements hook_localgov_subsites_extras_current_node_alter().
   */
  #[Hook('localgov_subsites_extras_current_node_alter', module: 'localgov_publications')]
  public function localgovPublicationsLocalgovSubsitesExtrasCurrentNodeAlter(?NodeInterface &$node) {
    if (!$node instanceof NodeInterface) {
      return;
    }
    if ($node->getType() !== 'localgov_publication_page') {
      return;
    }
    /** @var \Drupal\localgov_publications\Service\PublicationManager $publicationManager */
    $publicationManager = \Drupal::service('localgov_publications.publication_manager');
    $bookRoot = $publicationManager->getTopLevel($node);
    if (!$bookRoot instanceof NodeInterface) {
      return;
    }
    $coverPage = $publicationManager->getCoverPage((int) $bookRoot->id());
    if ($coverPage instanceof NodeInterface) {
      $node = $coverPage;
    }
    else {
      $node = $bookRoot;
    }
  }

  /**
   * Implements hook_localgov_subsites_extras_current_node_alter().
   */
  #[Hook('localgov_subsites_extras_current_node_alter', module: 'localgov_services_navigation')]
  public function localgovServicesNavigationLocalgovSubsitesExtrasCurrentNodeAlter(?NodeInterface &$node) {
    // Follow service parent reference fields if the node has one.
    localgov_subsites_extras_follow_field($node, 'localgov_services_parent');
  }

}
