<?php

namespace Drupal\localgov_subsites_extras\Hook;

use Drupal\node\NodeTypeInterface;
use Drupal\node\NodeInterface;
use Drupal\Core\Hook\Attribute\Hook;

/**
 * Hook implementations for localgov_subsites_extras.
 */
class LocalgovSubsitesExtrasHooks {

  /**
   * Implements hook_preprocess_menu().
   *
   * When a node is a child menu item of a subsite homepage node, this finds the
   * subsite homepage and inserts some of its properties into the template.
   */
  #[Hook('preprocess_menu')]
  public function preprocessMenu(&$variables) {
    /** @var \Drupal\localgov_subsites_extras\Service\SubsiteServiceInterface $subSiteService */
    $subSiteService = \Drupal::service('localgov_subsites_extras.service');
    // If the current node is part of a subsite, $subsiteHomePage will be the
    // subsite's homepage node. If it's not, it'll be null.
    $subsiteHomePage = $subSiteService->getHomePage();
    if ($subsiteHomePage instanceof NodeInterface) {
      $variables['subsite_homepage_link'] = $subsiteHomePage->toLink();
    }
  }

  /**
   * Implements hook_entity_bundle_create().
   *
   * When a new content type is created, this adds the subsite menu to its
   * available menus.
   */
  #[Hook('entity_bundle_create')]
  public function entityBundleCreate($entity_type_id, $bundle) {
    if ($entity_type_id !== 'node') {
      return;
    }
    /** @var \Drupal\node\NodeTypeInterface|null $type */
    $type = \Drupal::entityTypeManager()->getStorage('node_type')->load($bundle);
    if ($type instanceof NodeTypeInterface) {
      $availableMenus = $type->getThirdPartySetting('menu_ui', 'available_menus', [
        'main',
      ]);
      $availableMenus[] = 'subsites';
      $type->setThirdPartySetting('menu_ui', 'available_menus', $availableMenus);
      $type->save();
    }
  }

  /**
   * Implements hook_pathauto_alias_alter().
   *
   * Prepends Subsite homepage path alias to child page path aliases.
   */
  #[Hook('pathauto_alias_alter')]
  public function pathautoAliasAlter(&$alias, array &$context) {
    if ($context['module'] !== 'node') {
      return;
    }
    $src_node = $context['data']['node'];
    $subsite_home = \Drupal::service('localgov_subsites_extras.service')->getHomePage($src_node);
    if (!$subsite_home instanceof NodeInterface) {
      return;
    }
    $is_child_page = $subsite_home->id() !== $src_node->id();
    if (!$is_child_page) {
      return;
    }
    // Get the subsite homepage path alias, not using  toUrl() as that could
    // cause duplicate sub-directories in the alias.
    $subsite_home_path_alias = $subsite_home->path->alias;
    $has_no_subsite_home_path_alias = $subsite_home_path_alias === "/node/{$subsite_home->id()}";
    if ($has_no_subsite_home_path_alias) {
      return;
    }
    $has_subsite_alias_prefix = str_starts_with($alias, $subsite_home_path_alias);
    if ($has_subsite_alias_prefix) {
      return;
    }
    $alias = $subsite_home_path_alias . $alias;
  }

}
