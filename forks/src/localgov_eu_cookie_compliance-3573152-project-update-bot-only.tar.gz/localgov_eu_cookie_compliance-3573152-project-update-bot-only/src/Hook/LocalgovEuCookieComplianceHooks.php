<?php

namespace Drupal\localgov_eu_cookie_compliance\Hook;

use Drupal\Core\Render\Element\PathElement;
use Drupal\Core\Form\FormStateInterface;
use Drupal\Core\Hook\Attribute\Hook;
use Drupal\Core\StringTranslation\StringTranslationTrait;

/**
 * Hook implementations for localgov_eu_cookie_compliance.
 */
class LocalgovEuCookieComplianceHooks {
  use StringTranslationTrait;

  /**
   * Implements hook_theme().
   *
   * Provide two overrides for the default eu_cookie_compliance_popup_info theme
   * template.  One template is used for the Cookie settings block.  The other one
   * is used everywhere else.  The template for the Cookie settings block uses
   * radio boxes instead of checkboxes.
   *
   * Only declare these template overrides when a Cookies settings page path is
   * present in the site configuration.
   */
  #[Hook('theme')]
  public function theme() {
    $cookie_settings_page_path = \Drupal::config('localgov_eu_cookie_compliance.settings')->get('cookie-settings-page-path') ?? '';
    $trimmed_cookie_settings_page_path = trim($cookie_settings_page_path, '/');
    if (empty($trimmed_cookie_settings_page_path)) {
      return [];
    }
    return [
      'eu_cookie_compliance_popup_info__cookie_settings_block' => [
        'base hook' => 'eu_cookie_compliance_popup_info',
        'template' => 'eu-cookie-compliance-popup-info--cookie-settings-block',
      ],
      'eu_cookie_compliance_popup_info__override' => [
        'base hook' => 'eu_cookie_compliance_popup_info',
        'template' => 'eu-cookie-compliance-popup-info--override',
      ],
    ];
  }

  /**
   * Implements hook_eu_cookie_compliance_cid_alter().
   *
   * Add if this is the cookie page, or not, to the cache id.
   */
  #[Hook('eu_cookie_compliance_cid_alter')]
  public function euCookieComplianceCidAlter(&$cid) {
    $cid .= _localgov_eu_cookie_compliance_is_cookie_settings_page() ? ':settings_page' : ':banner';
  }

  /**
   * Implements hook_form_FORM_ID_alter() for hook_form_eu_cookie_compliance_config_form_alter().
   *
   * Alterations:
   * - Add the Cookie settings page path field and its submit handler.
   */
  #[Hook('form_eu_cookie_compliance_config_form_alter')]
  public function formEuCookieComplianceConfigFormAlter(array &$form, FormStateInterface $form_state): void {
    $config = \Drupal::config('localgov_eu_cookie_compliance.settings');
    $form['consent_per_category']['cookie-settings-page-path'] = [
      '#type' => 'path',
      '#title' => $this->t('Cookie settings page path'),
      '#description' => $this->t('Path of the Cookie settings page of this site.  Where available, use the **Path alias** of the Cookie settings page.'),
      '#default_value' => $config->get('cookie-settings-page-path'),
      '#convert_path' => PathElement::CONVERT_NONE,
    ];
    $form['#submit'][] = '_localgov_eu_cookie_compliance_path_submit';
  }

  /**
   * Implements hook_page_attachments_alter().
   */
  #[Hook('page_attachments_alter')]
  public function pageAttachmentsAlter(array &$attachment_list) {
    _localgov_eu_cookie_compliance_defer_tracker_scripts($attachment_list);
  }

}
