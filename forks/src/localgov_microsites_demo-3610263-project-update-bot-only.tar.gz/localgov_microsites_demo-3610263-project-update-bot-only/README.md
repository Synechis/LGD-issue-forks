# LocalGov Microsites Demo Content

Example content for demonstrating LocalGov Microsites and helping local
development.

## Hostnames are set to DDEV domains by default

When this module is installed, it creates or updates
domain records for the three demo microsites with these hostnames:

- `localgov-micro-1.ddev.site`
- `localgov-micro-2.ddev.site`
- `localgov-micro-3.ddev.site`

Notes:
- If your local environment uses different hostnames, update each domain record
  after install.

## ALPHA STATE MODULE
This module is in "alpha" state at the moment. It will create 3 microsites, one controller and one editor for each (6 users in total), and content for one microsite only (the Scarfolk Digital Blog microsite).

I am working on content for the other sites - Mark Conroy.

## What this module does

- Provides demo content via the `default_content` module.
- Includes groups, users, relationships, nodes, taxonomy terms, files, and
  media entities.
- On module install, creates or updates per-group domain settings for demo
  microsites (hostname, site name, slogan, and front page).

## Updating exported default content

From the Drupal web root, export content already listed in
`localgov_microsites_demo.info.yml`:

```bash
drush dcem localgov_microsites_demo
```

## Adding new demo content

1. Add the new entity UUID(s) to `localgov_microsites_demo.info.yml`.
2. Export the entity and its references:

```bash
drush dcer <entity_type> <entity_id> --folder=modules/custom/localgov_microsites_demo/content/
```

Notes:

1. `--folder` is relative to the Drupal web root.
2. Do not prefix `--folder` with `/`.
3. Keep UUID lists in `localgov_microsites_demo.info.yml` in sync with the
   exported files.

## Reference

- Default Content module docs:
  <https://www.drupal.org/docs/extending-drupal/contributed-modules/contributed-module-documentation/default-content>
