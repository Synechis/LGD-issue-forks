<?php

namespace Drupal\localgov_microsites_demo\Hook;

use Drupal\Core\Entity\ContentEntityInterface;
use Drupal\Component\Serialization\Yaml;
use Drupal\Core\Hook\Attribute\Hook;

/**
 * Hook implementations for localgov_microsites_demo.
 */
class LocalgovMicrositesDemoHooks {

  /**
   * Implements hook_preprocess_HOOK() for page.html.twig.
   */
  #[Hook('preprocess_page')]
  public function preprocessPage(array &$variables) {
    static $declared_entity_ids;
    if (!isset($declared_entity_ids)) {
      $declared_entity_ids = [];
      $info_path = __DIR__ . '/localgov_microsites_demo.info.yml';
      if (file_exists($info_path)) {
        $info = Yaml::decode(file_get_contents($info_path));
        if (!empty($info['default_content']) && is_array($info['default_content'])) {
          foreach ($info['default_content'] as $entity_ids) {
            if (!is_array($entity_ids)) {
              continue;
            }
            foreach ($entity_ids as $entity_id) {
              if (is_scalar($entity_id)) {
                $declared_entity_ids[(string) $entity_id] = TRUE;
              }
            }
          }
        }
      }
    }
    $entity_type_manager = \Drupal::entityTypeManager();
    $definitions = $entity_type_manager->getDefinitions();
    // Dump all content entities for debugging purposes.
    // @todo Remove this code when no longer needed.
    foreach ($definitions as $type_id => $definition) {
      if (!$definition->entityClassImplements(ContentEntityInterface::class)) {
        // Skip config entities.
        continue;
      }
      $storage = $entity_type_manager->getStorage($type_id);
      $ids = $storage->getQuery()->accessCheck(FALSE)->execute();
      $entities_to_exclude = [
        'paragraph',
        'path_alias',
        'domain_path',
        'group_content_menu',
        'file',
      ];
      foreach ($storage->loadMultiple($ids) as $entity) {
        if (in_array($type_id, $entities_to_exclude)) {
          continue;
        }
        if (isset($declared_entity_ids[(string) $entity->id()]) || isset($declared_entity_ids[(string) $entity->uuid()])) {
          continue;
        }
        // dump($type_id . ' --- ' . $entity->label() . ' ' . $entity->id() . ' --- ' . $entity->uuid());
      }
    }
  }

}
