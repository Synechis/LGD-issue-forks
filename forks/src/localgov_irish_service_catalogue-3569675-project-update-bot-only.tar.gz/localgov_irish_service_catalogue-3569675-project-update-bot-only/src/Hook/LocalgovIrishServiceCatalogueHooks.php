<?php

namespace Drupal\localgov_irish_service_catalogue\Hook;

use Drupal\Core\Hook\Attribute\Hook;

/**
 * Hook implementations for localgov_irish_service_catalogue.
 */
class LocalgovIrishServiceCatalogueHooks {

  /**
   * Implements hook_modules_installed().
   */
  #[Hook('modules_installed')]
  public function modulesInstalled($modules) {
    $irish_services = in_array('localgov_irish_service_catalogue', $modules);
    if ($irish_services) {
      \Drupal::service('config.installer')->installOptionalConfig();
      localgov_irish_service_catalogue_optional_fields_settings($irish_services);
    }
  }

  /**
   * Implements hook_preprocess_HOOK().
   */
  #[Hook('preprocess_block')]
  public function preprocessBlock(&$variables) {
    $blocks = [
      'irish_service_type',
      'irish_service_topic',
      'irish_service_category',
      'irish_service_user_type',
      'irish_service_municipal_district',
    ];
    if (in_array($variables['derivative_plugin_id'], $blocks)) {
      $variables['attributes']['class'][] = 'block-irish-service-catalogue';
      $variables['content'][0]['#attached']['library'][] = 'localgov_irish_service_catalogue/irish-service-catalogue';
    }
  }

}
