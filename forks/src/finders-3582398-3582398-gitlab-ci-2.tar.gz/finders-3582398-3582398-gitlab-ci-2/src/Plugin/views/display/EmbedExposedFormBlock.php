<?php

namespace Drupal\finders\Plugin\views\display;

use Drupal\Core\StringTranslation\TranslatableMarkup;
use Drupal\views\Attribute\ViewsDisplay;
use Drupal\views\Plugin\views\display\Embed;

/**
 * Provides an embed display which can be used with an exposed form block.
 *
 * Copied from https://www.drupal.org/project/views_extra_exposed_form_blocks.
 */
#[ViewsDisplay(
  id: 'embed_exposed_block',
  title: new TranslatableMarkup('Embed with Exposed Form Block'),
  help: new TranslatableMarkup('An embed display which allows the exposed form to be shown in a block.'),
  admin: new TranslatableMarkup('Embed with Exposed Form Block'),
  theme: "views_view",
  register_theme: FALSE,
)]
class EmbedExposedFormBlock extends Embed {

  /**
   * {@inheritdoc}
   */
  public function usesExposedFormInBlock() {
    return TRUE;
  }

}
