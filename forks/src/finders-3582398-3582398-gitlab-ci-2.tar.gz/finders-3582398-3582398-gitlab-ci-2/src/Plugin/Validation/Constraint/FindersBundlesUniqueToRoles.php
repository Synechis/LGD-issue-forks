<?php

namespace Drupal\finders\Plugin\Validation\Constraint;

use Drupal\Core\StringTranslation\TranslatableMarkup;
use Drupal\Core\Validation\Attribute\Constraint;
use Symfony\Component\Validator\Constraint as SymfonyConstraint;

/**
 * Validates finder entries and channels as only being one role in a finder.
 *
 * In other words, Finder A can't use the bundle B as both its channels and its
 * entries.
 */
#[Constraint(
  id: 'FindersBundlesUniqueToRoles',
  label: new TranslatableMarkup('Finders bundle roles unique in finder'),
  type: FALSE,
)]
class FindersBundlesUniqueToRoles extends SymfonyConstraint {

  /**
   * The error message if validation fails.
   *
   * @var string
   */
  public $message = "The bundle @bundle-names may not be used as both channels and entries.|The bundles @bundle-names may not be used as both channels and entries.";

}
