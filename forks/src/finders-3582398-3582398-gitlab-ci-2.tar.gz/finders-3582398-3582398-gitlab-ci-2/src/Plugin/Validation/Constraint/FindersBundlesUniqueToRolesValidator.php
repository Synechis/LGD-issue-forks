<?php

namespace Drupal\finders\Plugin\Validation\Constraint;

use Drupal\Core\Config\Schema\TypeResolver;
use Drupal\Core\DependencyInjection\ContainerInjectionInterface;
use Drupal\Core\Entity\EntityTypeBundleInfoInterface;
use Drupal\finders\Enum\FinderRole;
use Symfony\Component\DependencyInjection\ContainerInterface;
use Symfony\Component\Validator\Constraint;
use Symfony\Component\Validator\ConstraintValidator;

/**
 * Validates the FindersBundlesUniqueToRoles constraint.
 */
class FindersBundlesUniqueToRolesValidator extends ConstraintValidator implements ContainerInjectionInterface {

  /**
   * {@inheritdoc}
   */
  public static function create(ContainerInterface $container) {
    return new static(
      $container->get('entity_type.bundle.info'),
    );
  }

  /**
   * Creates a FindersBundlesValidator instance.
   *
   * @param \Drupal\Core\Entity\EntityTypeBundleInfoInterface $entity_type_bundle_info
   *   The entity type bundle info.
   */
  public function __construct(
    protected EntityTypeBundleInfoInterface $entityBundleInfo,
  ) {
  }

  /**
   * {@inheritdoc}
   */
  public function validate($items, Constraint $constraint) {
    $placeholders = $this->doValidate($items['id'], $items['channels'], $items['entries']);
    if ($placeholders) {
      $this->context->buildViolation($constraint->message)
        ->setParameter('@bundle-names', $placeholders['@bundle-names'])
        ->setPlural($placeholders['count'])
        ->addViolation();
    }
  }

  /**
   * Hacky helper method which allows the finder entity form to use this.
   *
   * @todo Fold this into self::validate() when core handles config entity
   * validation.
   */
  public function doValidate(string $validating_finder_id, array $validating_finder_channels, array $validating_finder_entries): ?array {
    // Nothing to check if channels and entries are different entity types.
    if (!array_intersect_key($validating_finder_channels, $validating_finder_entries)) {
      return NULL;
    }

    $entity_type_id = array_key_first($validating_finder_channels);

    $clashing_bundle_ids = array_intersect($validating_finder_channels[$entity_type_id], $validating_finder_entries[$entity_type_id]);
    if ($clashing_bundle_ids === []) {
      return NULL;
    }

    $bundle_info = $this->entityBundleInfo->getBundleInfo($entity_type_id);
    $clashing_bundle_info = array_intersect_key($bundle_info, array_fill_keys($clashing_bundle_ids, TRUE));
    // Finally, get the bundle labels of the duplicated bundles.
    $clashing_bundle_labels = array_column($clashing_bundle_info, 'label');

    return [
      '@bundle-names' => implode(', ', $clashing_bundle_labels),
      'count' => count($clashing_bundle_ids),
    ];
  }

}
