<?php

namespace Drupal\finders\Plugin\search_api\display;

use Drupal\search_api\Plugin\search_api\display\ViewsEmbed;

/**
 * Represents a Views extra exposed form block Search API display.
 *
 * @SearchApiDisplay(
 *   id = "views_embed_exposed_block",
 *   views_display_type = "embed_exposed_block",
 *   deriver = "Drupal\search_api\Plugin\search_api\display\ViewsDisplayDeriver"
 * )
 */
class EmbedExposedFormBlock extends ViewsEmbed {

}
