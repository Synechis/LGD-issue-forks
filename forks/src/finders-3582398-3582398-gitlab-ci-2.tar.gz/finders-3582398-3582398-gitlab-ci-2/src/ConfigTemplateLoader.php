<?php

declare(strict_types=1);

namespace Drupal\finders;

use Drupal\Component\Plugin\PluginInspectionInterface;
use Drupal\Core\Config\ConfigException;
use Drupal\Core\Config\FileStorage as ConfigFileStorage;
use Drupal\Core\Extension\ModuleExtensionList;

/**
 * Loads config templates.
 *
 * A finder requires several associated config entities, such as views, search
 * indexes, and so on. Templates of these entities, or snippets for inclusion
 * within them, are stored as YAML files in a config/template directory. This is
 * for ease of maintenance, as changes to site configuration can be copy-pasted
 * back into the config/template directory and desired changes committed to the
 * module's code.
 */
class ConfigTemplateLoader {

  /**
   * Creates a ConfigTemplateLoader instance.
   *
   * @param \Drupal\Core\Extension\ModuleExtensionList $moduleExtensionList
   *   The module extension list service.
   */
  public function __construct(
    protected ModuleExtensionList $moduleExtensionList,
  ) {
  }

  /**
   * Loads config values from a config template file.
   *
   * This first looks in the module providing the plugin, and then falls back
   * to the specified plugin type provider module.
   *
   * @param string $config_template_filename
   *   The filename of the template to load in the plugin's provider module's
   *   config template folder.
   * @param string|null $config_template_generic_filename
   *   The filename of the fallback template to load from the
   *   $config_template_filename's config template folder, if the
   *   $config_template_filename does not exist. Specify NULL to not use a
   *   fallback.
   * @param \Drupal\Component\Plugin\PluginInspectionInterface $plugin
   *   The plugin in context.
   * @param string $plugin_type_provider
   *   The module that provides the plugin type. (We wouldn't need this if
   *   plugins knew their own type!)
   * @param array $replacements
   *   An array of token replacements for the config values. These are replaced
   *   at all levels of the config values. Token names are in capital letters by
   *   convention, so they can be easily seen in the template files. Replacement
   *   values must be strings.
   *
   * @return array
   *   The loaded config values, with tokens replaced.
   *
   * @throws \Drupal\Core\Config\ConfigException
   *   Throws an exception if either:
   *   - The requested template file does not exist and no fallback was
   *     specified.
   *   - The requested template file does not exist and nor does the fallback
   *     template file.
   */
  public function loadTemplateConfigValues(string $config_template_filename, string|null $config_template_generic_filename, PluginInspectionInterface $plugin, string $plugin_type_provider, array $replacements): array {
    $plugin_provider_module = $plugin->getPluginDefinition()['provider'];

    $plugin_provider_template_directory = $this->moduleExtensionList->getPath($plugin_provider_module) . '/config/template';
    $plugin_provider_config_source = new ConfigFileStorage($plugin_provider_template_directory);

    if ($plugin_provider_config_source->exists($config_template_filename)) {
      // First look for the config template file in the plugin provider module.
      $config_values = $plugin_provider_config_source->read($config_template_filename);
    }
    elseif (!empty($config_template_generic_filename)) {
      // Fall back to the default index template if the finder type module does
      // not provide a template for the view ID.
      $plugin_type_provider_template_directory = $this->moduleExtensionList->getPath($plugin_type_provider) . '/config/template';
      $plugin_type_provider_config_source = new ConfigFileStorage($plugin_type_provider_template_directory);

      if (!$plugin_type_provider_config_source->exists($config_template_generic_filename)) {
        throw new ConfigException("Fallback template '$config_template_generic_filename' does not exist in $plugin_type_provider module.");
      }

      $config_values = $plugin_type_provider_config_source->read($config_template_generic_filename);
    }
    else {
      throw new ConfigException("Template '$config_template_filename' does not exist in provider module $plugin_provider_module and no fallback specified.");
    }

    array_walk_recursive($config_values, function (&$value) use ($replacements) {
      // Tokens will always be strings, so skip anything numeric or NULL.
      if (!is_string($value)) {
        return;
      }

      $value = str_replace(array_keys($replacements), array_values($replacements), $value);
    });

    return $config_values;
  }

}
