<?php

namespace Drupal\finders;

use Drupal\block\BlockInterface;
use Drupal\Core\Config\ConfigInstallerInterface;
use Drupal\Core\Config\Entity\ConfigEntityInterface;
use Drupal\Core\Config\Entity\ThirdPartySettingsInterface;
use Drupal\Core\Config\FileStorage as ConfigFileStorage;
use Drupal\Core\Entity\EntityDefinitionUpdateManagerInterface;
use Drupal\Core\Entity\EntityFieldManagerInterface;
use Drupal\Core\Entity\EntityLastInstalledSchemaRepositoryInterface;
use Drupal\Core\Entity\EntityTypeManagerInterface;
use Drupal\Core\Entity\EntityViewModeInterface;
use Drupal\Core\Extension\ModuleExtensionList;
use Drupal\Core\Logger\LoggerChannelFactoryInterface;
use Drupal\finders\Entity\FinderInterface;
use Drupal\finders\Enum\FinderRole;
use Drupal\search_api\IndexInterface;
use Drupal\search_api\Utility\PluginHelperInterface;
use Drupal\views\ViewEntityInterface;

/**
 * Manages definition of fields and creation of configuration for Finders.
 *
 * When a Finder is created, this defines bundle fields on its entity bundles,
 * and creates or updates config entities.
 *
 * Typically, a finder will have:
 * - Bundle fields on its channel entity bundle.
 * - Bundle fields on its entry entity bundle.
 * - A search index, which is shared among finders of the same type.
 * - A view, which is shared among finders of the same type. This is output on
 *   channel entities with a viewsreference field, with its exposed filters
 *   hidden.
 * - A Views exposed form block for the channel view.
 * - A block shown on entry entities for searching that entity's channels.
 *
 * Other finder types may add more fields or config entities.
 *
 * @todo Convert code that loads config template files to use
 * ConfigTemplateLoader.
 */
class FinderConfigManager {

  /**
   * The entity type manager.
   *
   * @var \Drupal\Core\Entity\EntityTypeManagerInterface
   */
  protected $entityTypeManager;

  /**
   * The entity field manager.
   *
   * @var \Drupal\Core\Entity\EntityFieldManagerInterface
   */
  protected $entityFieldManager;

  /**
   * The module extension list service.
   *
   * @var \Drupal\Core\Extension\ModuleExtensionList
   */
  protected $moduleExtensionList;

  /**
   * The entity last installed schema repository service.
   *
   * @var \Drupal\Core\Entity\EntityLastInstalledSchemaRepositoryInterface
   */
  protected $entityLastInstalledSchemaRepository;

  /**
   * The entity definition update manager.
   *
   * @var \Drupal\Core\Entity\EntityDefinitionUpdateManagerInterface
   */
  protected $entityDefinitionUpdateManager;

  /**
   * The config installer service.
   *
   * @var \Drupal\Core\Config\ConfigInstallerInterface
   */
  protected $configInstaller;

  /**
   * The logger channel factory.
   *
   * @var \Drupal\Core\Logger\LoggerChannelFactoryInterface
   */
  protected $loggerChannelFactory;

  /**
   * The plugin helper service.
   *
   * @var \Drupal\search_api\Utility\PluginHelperInterface
   */
  protected $pluginHelper;

  /**
   * Creates a FinderConfigManager instance.
   *
   * @param \Drupal\Core\Entity\EntityTypeManagerInterface $entity_type_manager
   *   The entity type manager.
   * @param \Drupal\Core\Entity\EntityFieldManagerInterface $entity_field_manager
   *   The entity field manager.
   * @param \Drupal\Core\Extension\ModuleExtensionList $module_extension_list
   *   The module extension list service.
   * @param \Drupal\Core\Config\ConfigInstallerInterface $config_installer
   *   The config installer service.
   * @param \Drupal\Core\Logger\LoggerChannelFactoryInterface $logger_channel_factory
   *   The logger channel factory.
   * @param \Drupal\search_api\Utility\PluginHelperInterface $plugin_helper
   *   The plugin helper service.
   * @param \Drupal\Core\Entity\EntityLastInstalledSchemaRepositoryInterface $entity_last_installed_schema_repository
   *   The entity last installed schema repository service.
   * @param \Drupal\Core\Entity\EntityDefinitionUpdateManagerInterface $entity_definition_update_manager
   *   The entity definition update manager.
   */
  public function __construct(
    EntityTypeManagerInterface $entity_type_manager,
    EntityFieldManagerInterface $entity_field_manager,
    EntityLastInstalledSchemaRepositoryInterface $entity_last_installed_schema_repository,
    EntityDefinitionUpdateManagerInterface $entity_definition_update_manager,
    ModuleExtensionList $module_extension_list,
    ConfigInstallerInterface $config_installer,
    LoggerChannelFactoryInterface $logger_channel_factory,
    PluginHelperInterface $plugin_helper,
  ) {
    $this->entityTypeManager = $entity_type_manager;
    $this->entityFieldManager = $entity_field_manager;
    $this->entityLastInstalledSchemaRepository = $entity_last_installed_schema_repository;
    $this->entityDefinitionUpdateManager = $entity_definition_update_manager;
    $this->moduleExtensionList = $module_extension_list;
    $this->configInstaller = $config_installer;
    $this->loggerChannelFactory = $logger_channel_factory;
    $this->pluginHelper = $plugin_helper;
  }

  /**
   * Gets the finder bundle fields for a given bundle.
   *
   * @param \Drupal\Core\Config\Entity\ConfigEntityInterface $bundle_entity
   *   The bundle entity.
   *
   * @return \Drupal\finders\Field\BundleFieldDefinition[]
   *   An array bundle field definitions, for either channel bundles or entry
   *   bundles as appropriate, keyed by the field name. If the given bundle
   *   entity is not configured for finders, an empty array is returned.
   */
  public function getBundleFieldDefinitions(ConfigEntityInterface $bundle_entity): array {
    // Bail if this bundle does not participate in a finder.
    if (!($finder = $this->entityTypeManager->getStorage('finder')->getFinderForBundleEntity($bundle_entity))) {
      return [];
    }

    $finder_type = $finder->getFinderTypePlugin();
    $finder_role = $finder->getFinderRoleForBundle($bundle_entity);

    if (!$finder_type) {
      return [];
    }
    else {
      return match ($finder_role) {
        FinderRole::Channels => $this->getChannelFieldDefinitions($bundle_entity, $finder),
        FinderRole::Entries => $this->getEntryFieldDefinitions($bundle_entity, $finder),
      };
    }
  }

  /**
   * Gets the channel field definitions for a given bundle and finder type.
   *
   * @param \Drupal\Core\Config\Entity\ConfigEntityInterface $bundle_entity
   *   The bundle entity.
   * @param \Drupal\finders\Entity\FinderInterface $finder
   *   The finder entity.
   *
   * @return array
   *   An array of bundle field definitions.
   */
  protected function getChannelFieldDefinitions(ConfigEntityInterface $bundle_entity, FinderInterface $finder): array {
    $bundle_entity_type = $bundle_entity->getEntityType();
    $content_entity_type_id = $bundle_entity_type->getBundleOf();

    $finder_type = $finder->getFinderTypePlugin();
    $channel_field_definitions = $finder_type->getChannelFieldDefinitions($bundle_entity, $finder);

    // Allow modules to alter the channel field definitions.
    \Drupal::moduleHandler()->alter('finders_channel_fields', $channel_field_definitions, $bundle_entity, $finder);

    /** @var \Drupal\finders\Field\BundleFieldDefinition $field_definition */
    foreach ($channel_field_definitions as $field_definition) {
      // Set the target entity type and bundle on all bundle fields.
      $field_definition->setTargetEntityTypeId($content_entity_type_id);
      $field_definition->setTargetBundle($bundle_entity->id());
    }

    return $channel_field_definitions;
  }

  /**
   * Gets the channel field definitions for a given bundle and finder type.
   *
   * @param \Drupal\Core\Config\Entity\ConfigEntityInterface $bundle_entity
   *   The bundle entity.
   * @param \Drupal\finders\Entity\FinderInterface $finder
   *   The finder entity.
   *
   * @return array
   *   An array of bundle field definitions.
   */
  protected function getEntryFieldDefinitions(ConfigEntityInterface $bundle_entity, FinderInterface $finder): array {
    $bundle_entity_type = $bundle_entity->getEntityType();
    $content_entity_type_id = $bundle_entity_type->getBundleOf();

    $finder_type = $finder->getFinderTypePlugin();
    $entry_field_definitions = $finder_type->getEntryFieldDefinitions($bundle_entity, $finder);

    // Allow modules to alter the entry field definitions.
    \Drupal::moduleHandler()->alter('finders_entry_fields', $entry_field_definitions, $bundle_entity, $finder);

    /** @var \Drupal\finders\Field\BundleFieldDefinition $field_definition */
    foreach ($entry_field_definitions as $field_definition) {
      // Set the target entity type and bundle on all bundle fields.
      $field_definition->setTargetEntityTypeId($content_entity_type_id);
      $field_definition->setTargetBundle($bundle_entity->id());
    }

    return $entry_field_definitions;
  }

  /**
   * Set up a finder's config after it has been saved.
   *
   * It is essential that this method and everything it calls be idempotent, as
   * it is called every time a finder entity is updated. This is because
   * third-party extensions and alter hooks may want to add further
   * configuration. Therefore, any configuration changes must check they have
   * not previously been done.
   *
   * @param \Drupal\finders\Entity\FinderInterface $finder
   *   The finder entity. It has already been saved.
   */
  public function ensureFinderConfig(FinderInterface $finder): void {
    $finder_type = $finder->getFinderTypePlugin();

    // Set up the bundle fields on channel and entry bundles.
    foreach ($finder->getChannelBundles() as $channel_bundle) {
      $this->configureAsChannel($channel_bundle, $finder);
    }
    foreach ($finder->getEntryBundles() as $entry_bundle) {
      $this->configureAsEntry($entry_bundle, $finder);
    }

    // Set up the view modes.
    $entry_entity_type_id = $finder->getEntryEntityTypeId();
    foreach (['INDEX_VIEW_MODE', 'RESULTS_VIEW_MODE'] as $view_mode_constant) {
      $view_mode_id = $entry_entity_type_id . '.' . $finder_type->getFinderTypeConstant($view_mode_constant);
      $view_mode = $this->entityTypeManager->getStorage('entity_view_mode')->load($view_mode_id);
      if (empty($view_mode)) {
        $view_mode = $this->loadTemplateViewMode($view_mode_id, $finder);
        $view_mode->save();
      }
    }

    // Set up entity view displays for our view modes on entry bundles.
    $entityDisplayRepository = \Drupal::service('entity_display.repository');
    foreach ($finder->getEntryBundles() as $entry_bundle) {
      foreach (['INDEX_VIEW_MODE', 'RESULTS_VIEW_MODE'] as $view_mode_constant) {
        $view_mode_name = $finder_type->getFinderTypeConstant($view_mode_constant);

        // Create the display, or load the existing one.
        $display = $this->entityTypeManager->getStorage('entity_view_display')->load($entry_entity_type_id . '.' . $entry_bundle->id() . '.' . $view_mode_name);
        if (!$display) {
          $display = $entityDisplayRepository->getViewDisplay($entry_entity_type_id, $entry_bundle->id(), 'default')->createCopy($view_mode_name);
        }

        // Allow the Finder type plugin to make alterations whether the display
        // already existed or is being created.
        $finder_type->alterEntryViewDisplay($display, $entry_bundle, $finder);

        $display->save();
      }
    }
    // The EntityDisplayRepository's cache needs to be invalidated manually due
    // to a core bug.
    // See https://www.drupal.org/project/drupal/issues/3588811.
    \Drupal::service('cache_tags.invalidator')->invalidateTags(['entity_field_info']);

    // Set up the indexes for the finder type.
    foreach ($finder_type->getIndexIds() as $index_id) {
      $index = $this->entityTypeManager->getStorage('search_api_index')->load($index_id);
      // Create the Finder's search index if it doesn't already exist.
      if (empty($index)) {
        $index = $this->loadTemplateIndex($index_id, $finder);
      }
      assert($index instanceof IndexInterface);
      $finder_type->alterSearchIndex($index, $finder);

      // Allow modules to alter the index.
      // This is a separate alter hook so that the bundle fields exist for
      // implementations of this hook to check.
      \Drupal::moduleHandler()->alter('finders_index', $index, $finder);

      $index->save();

      // Configure the view for the index.
      foreach ($finder_type->getViewIds($index) as $view_id) {
        $view = $this->entityTypeManager->getStorage('view')->load($view_id);
        // Create the view if it doesn't already exist.
        if (empty($view)) {
          $view = $this->loadTemplateView($view_id, $index, $finder);
        }
        $finder_type->alterView($view, $index, $finder);

        \Drupal::moduleHandler()->alter('finders_view', $view, $index, $finder);

        $view->save();
      }
    }

    // Add the Views exposed form block for the channel view.
    $channel_view_id = $finder_type->getFinderTypeConstant('CHANNEL_VIEW');
    $channel_view_display_id = $finder_type->getFinderTypeConstant('CHANNEL_VIEW_DISPLAY');
    // The derived plugin ID for the Views exposed form block for our channel
    // view.
    $block_plugin_id = 'views_exposed_filter_block:' . $channel_view_id . '-' . $channel_view_display_id;

    // Check for an existing exposed form block for the channel view.
    $exposed_form_blocks = $this->entityTypeManager->getStorage('block')->loadByProperties([
      'plugin' => $block_plugin_id,
    ]);

    $channel_view = $this->entityTypeManager->getStorage('view')->load($channel_view_id);
    if (empty($exposed_form_blocks)) {
      $exposed_form_block = $this->loadTemplateExposedFormBlock($block_plugin_id, $channel_view, $finder);
    }
    else {
      $exposed_form_block = reset($exposed_form_blocks);
    }

    // Set the block visibility on both a new block and an existing one, so that
    // adding channel bundles to an existing finder adds them here.
    $this->setBlockVisibility($exposed_form_block, FinderRole::Channels, $finder);

    $finder_type->alterViewsExposedFormBlock($exposed_form_block, $channel_view, $finder);

    $exposed_form_block->save();

    // Add the channel search block.
    // This block will be common to all finders.
    $channel_search_blocks = $this->entityTypeManager->getStorage('block')->loadByProperties([
      'plugin' => 'finders_channel_search',
    ]);
    if (empty($channel_search_blocks)) {
      $channel_search_block = $this->loadTemplateChannelSearchBlock($finder);
    }
    else {
      $channel_search_block = reset($channel_search_blocks);
    }

    // Set the block visibility on both a new block and an existing one, so that
    // channel bundles from a new finder and channel bundles added to an
    // existing finder are added.
    $this->setBlockVisibility($channel_search_block, FinderRole::Entries, $finder);

    $finder_type->alterChannelSearchBlock($channel_search_block, $finder);

    $channel_search_block->save();

    // Allow the finder type and other modules to make final adjustments to
    // any configuration.
    $finder_type->postConfigure($finder);
    \Drupal::moduleHandler()->invokeAll('finders_post_configure', [$finder]);
  }

  /**
   * Sets up a bundle as finder channels.
   *
   * @param \Drupal\Core\Config\Entity\ConfigEntityInterface $bundle_entity
   *   The entity bundle entity.
   * @param \Drupal\finders\Entity\FinderInterface $finder
   *   The finder entity.
   */
  protected function configureAsChannel(ConfigEntityInterface $bundle_entity, FinderInterface $finder): void {
    $entity_type_id = $bundle_entity->getEntityType()->getBundleOf();

    $channel_field_definitions = $this->getChannelFieldDefinitions($bundle_entity, $finder);

    $installed_storage_definitions = $this->entityLastInstalledSchemaRepository->getLastInstalledFieldStorageDefinitions($entity_type_id);

    // Register bundle fields on the entity type.
    foreach ($channel_field_definitions as $field_definition) {
      if (!isset($installed_storage_definitions[$field_definition->getName()])) {
        $this->entityDefinitionUpdateManager->installFieldStorageDefinition($field_definition->getName(), $entity_type_id, 'finders', $field_definition);
      }
    }
  }

  /**
   * Sets up a bundle as finder entries.
   *
   * @param \Drupal\Core\Config\Entity\ConfigEntityInterface $bundle_entity
   *   The entity bundle entity.
   * @param \Drupal\finders\Entity\FinderInterface $finder
   *   The finder entity.
   */
  protected function configureAsEntry(ConfigEntityInterface $bundle_entity, FinderInterface $finder): void {
    $entity_type_id = $bundle_entity->getEntityType()->getBundleOf();

    $entry_field_definitions = $this->getEntryFieldDefinitions($bundle_entity, $finder);

    $installed_storage_definitions = $this->entityLastInstalledSchemaRepository->getLastInstalledFieldStorageDefinitions($entity_type_id);

    // Register bundle fields on the entity type.
    foreach ($entry_field_definitions as $field_definition) {
      if (!isset($installed_storage_definitions[$field_definition->getName()])) {
        $this->entityDefinitionUpdateManager->installFieldStorageDefinition($field_definition->getName(), $entity_type_id, 'finders', $field_definition);
      }
    }
  }

  /**
   * Creates a view mode on entries for the given view mode ID.
   *
   * @param string $view_mode_id
   *   The ID of the view mode to create, including the target entity type ID
   *   prefix.
   * @param \Drupal\finders\Entity\FinderInterface $finder
   *   The finder this is for.
   *
   * @return \Drupal\Core\Entity\EntityViewModeInterface
   *   The view mode created from the template configuration. It is the caller's
   *   responsibility to save this.
   */
  protected function loadTemplateViewMode(string $view_mode_id, FinderInterface $finder): EntityViewModeInterface {
    $finder_type = $finder->getFinderTypePlugin();

    $view_mode_suffix = explode('.', $view_mode_id)[1];

    $template_directory = $this->moduleExtensionList->getPath($finder_type->getPluginDefinition()['provider']) . '/config/template';
    $config_source = new ConfigFileStorage($template_directory);
    $config_filename = 'core.entity_view_mode.entry_type.' . $view_mode_suffix;

    // Fall back to the default view mode template if the finder type module
    // does not provide a template for the view mode.
    if (!$config_source->exists($config_filename)) {
      $template_directory = $this->moduleExtensionList->getPath('finders') . '/config/template';
      $config_source = new ConfigFileStorage($template_directory);
      $config_filename = "core.entity_view_mode.entry_type.{$view_mode_suffix}_template";
    }

    $config_values = $config_source->read($config_filename);

    $entry_entity_type_id = $finder->getEntryEntityTypeId();

    $replacements = [
      'ENTRY_ENTITY_TYPE_ID' => $entry_entity_type_id,
    ];

    array_walk($config_values, function (&$config_value) use ($replacements) {
      $config_value = str_replace(array_keys($replacements), array_values($replacements), $config_value);
    });

    $view_mode = $this->entityTypeManager->getStorage('entity_view_mode')->create($config_values);

    return $view_mode;
  }

  /**
   * Creates a stub search index template from a template YAML config file.
   *
   * If there exists a Search API Index Config YAML file in the config/template
   * directory of the module that provides the finder type, then this is used as
   * the template. If not, the default index template will be used.
   *
   * @param string $index_id
   *   The ID of the search index to create.
   * @param \Drupal\finders\Entity\FinderInterface $finder
   *   The finder being configured.
   *
   * @return \Drupal\search_api\IndexInterface
   *   The search index created from the template configuration. It is the
   *   caller's responsibility to save this.
   */
  protected function loadTemplateIndex(string $index_id, FinderInterface $finder): IndexInterface {
    $finder_type = $finder->getFinderTypePlugin();

    $template_directory = $this->moduleExtensionList->getPath($finder_type->getPluginDefinition()['provider']) . '/config/template';
    $config_source = new ConfigFileStorage($template_directory);
    $config_filename = 'search_api.index.' . $index_id;

    // Fall back to the default index template if the finder type module does
    // not provide a template for the index ID.
    if (!$config_source->exists($config_filename)) {
      $template_directory = $this->moduleExtensionList->getPath('finders') . '/config/template';
      $config_source = new ConfigFileStorage($template_directory);
      $config_filename = 'search_api.index.finders_index_template';
    }

    $config_values = $config_source->read($config_filename);

    // Set the ID and name of the index.
    $config_values['id'] = $index_id;
    $config_values['name'] = $finder_type->getPluginDefinition()['label'];

    $search_index = $this->entityTypeManager->getStorage('search_api_index')->create($config_values);

    // Set a default server if one exists.
    $servers = $this->entityTypeManager->getStorage('search_api_server')->loadMultiple();
    foreach ($servers as $server_id => $server) {
      if ($server->getThirdPartySetting('finders', 'default_server', NULL)) {
        $search_index->setServer($server);
        $search_index->setStatus(TRUE);
      }
    }

    $this->setFindersThirdParty($search_index, $finder);

    return $search_index;
  }

  /**
   * Creates a stub view template from a template YAML config file.
   *
   * @param string $view_id
   *   The ID of the view to create.
   * @param \Drupal\finders\Entity\FinderInterface $finder
   *   The finder being configured.
   * @param \Drupal\search_api\IndexInterface $search_index
   *   The search index which is the source for the view's data. This has
   *   already been set up for the finder type.
   *
   * @return \Drupal\views\ViewEntityInterface
   *   The view created from the template configuration. It is the caller's
   *   responsibility to save this.
   *
   * @see config/template/views.view.finder_channel_template.yml
   */
  protected function loadTemplateView(string $view_id, IndexInterface $search_index, FinderInterface $finder): ViewEntityInterface {
    $finder_type = $finder->getFinderTypePlugin();

    $config_filename = 'views.view.' . $view_id;

    $config_values = \Drupal::service('finders.config_template_loader')->loadTemplateConfigValues(
      $config_filename,
      'views.view.finder_channel_template',
      $finder_type,
      'finders',
      [
        'VIEW_ID' => $view_id,
        'FINDER_TYPE' => $finder_type->getPluginDefinition()['label'],
      ],
    );

    // Set the index as a config and cache dependency.
    $config_values['dependencies']['config'][] = $search_index->id();
    foreach ($config_values['display'] as &$display_definition) {
      $display_definition['cache_metadata']['tags'][] = 'config:search_api.index.' . $search_index->id();
    }

    // Set up the base table.
    // search_api_views_data() declares a base table for each index.
    $base_table = 'search_api_index_' . $search_index->id();
    $config_values['base_table'] = $base_table;
    foreach (['fields', 'filters', 'sorts', 'arguments'] as $views_plugin_type) {
      foreach ($config_values['display']['default']['display_options'][$views_plugin_type] as &$definition) {
        $definition['table'] = $base_table;
      }
    }

    $view = $this->entityTypeManager->getStorage('view')->create($config_values);

    $this->setFindersThirdParty($view, $finder);

    return $view;
  }

  /**
   * Creates a block template for the channel view exposed form block.
   *
   * @param string $block_plugin_id
   *   The ID of the block plugin to use for the block.
   * @param \Drupal\views\ViewEntityInterface $view
   *   The view that the block shows the exposed filters for.
   * @param \Drupal\finders\Entity\FinderInterface $finder
   *   The finder being configured.
   *
   * @return \Drupal\block\BlockInterface
   *   The block created from the template configuration. It is the caller's
   *   responsibility to save this.
   *
   * @see config/template/block.block.theme_exposed_form_finders_channel_template.yml
   */
  protected function loadTemplateExposedFormBlock(string $block_plugin_id, ViewEntityInterface $view, FinderInterface $finder): BlockInterface {
    $finder_type = $finder->getFinderTypePlugin();

    $finder_channel_entity_type_id = $finder->getChannelEntityTypeId();

    // Get the main theme (rather than the active theme, which will likely be
    // the admin theme).
    $config = \Drupal::config('system.theme');
    $theme_id = $config->get('default');

    $region = $this->guessSidebarRegion($theme_id);

    // Form the block ID from the theme ID and the block plugin ID.
    $block_id = $theme_id . '_' . str_replace([':', '-'], '_', $block_plugin_id);

    $config_values = \Drupal::service('finders.config_template_loader')->loadTemplateConfigValues(
      'block.block.theme_exposed_form_finders_channel',
      'block.block.theme_exposed_form_finders_channel_template',
      $finder_type,
      'finders',
      [
        'BLOCK_ID' => $block_id,
        'BLOCK_PLUGIN_ID' => $block_plugin_id,
        'CHANNEL_ENTITY_TYPE_ID' => $finder_channel_entity_type_id,
        'VIEW_ID' => $view->id(),
        'THEME' => $theme_id,
        'REGION' => $region,
      ],
    );

    // Handle the token in the visibility and context mapping keys. Work
    // outwards so the keys are simpler. The bundles for visibility are set in
    // static::setBlockVisibility().
    $config_values['visibility']['entity_bundle:CHANNEL_ENTITY_TYPE_ID']['context_mapping'][$finder_channel_entity_type_id] = $config_values['visibility']['entity_bundle:CHANNEL_ENTITY_TYPE_ID']['context_mapping']['CHANNEL_ENTITY_TYPE_ID'];
    unset($config_values['visibility']['entity_bundle:CHANNEL_ENTITY_TYPE_ID']['context_mapping']['CHANNEL_ENTITY_TYPE_ID']);

    $config_values['visibility']['entity_bundle:' . $finder_channel_entity_type_id] = $config_values['visibility']['entity_bundle:CHANNEL_ENTITY_TYPE_ID'];
    unset($config_values['visibility']['entity_bundle:CHANNEL_ENTITY_TYPE_ID']);

    $block = $this->entityTypeManager->getStorage('block')->create($config_values);

    $this->setFindersThirdParty($block, $finder);

    return $block;
  }

  /**
   * Creates a block template for the channel search block.
   *
   * @param \Drupal\finders\Entity\FinderInterface $finder
   *   The finder being configured.
   *
   * @return \Drupal\block\BlockInterface
   *   The block created from the template configuration. It is the caller's
   *   responsibility to save this.
   *
   * @see config/template/block.block.theme_finders_channel_search_template.yml
   */
  protected function loadTemplateChannelSearchBlock(FinderInterface $finder): BlockInterface {
    $finder_type = $finder->getFinderTypePlugin();

    $finder_entry_entity_type_id = $finder->getEntryEntityTypeId();

    // Get the main theme (rather than the active theme, which will likely be
    // the admin theme).
    $config = \Drupal::config('system.theme');
    $theme_id = $config->get('default');

    $region = $this->guessSidebarRegion($theme_id);

    // Form the block ID from the theme ID and the block plugin ID.
    $block_id = $theme_id . '_finders_channel_search';

    $config_values = \Drupal::service('finders.config_template_loader')->loadTemplateConfigValues(
      'block.block.theme_finders_channel_search',
      'block.block.theme_finders_channel_search_template',
      $finder_type,
      'finders',
      [
        'BLOCK_ID' => $block_id,
        'ENTRY_ENTITY_TYPE_ID' => $finder_entry_entity_type_id,
        'THEME' => $theme_id,
        'REGION' => $region,
      ],
    );

    // Handle the token in the visibility and context mapping keys. Work
    // outwards so the keys are simpler. The bundles for visibility are set in
    // static::setBlockVisibility().
    $config_values['settings']['context_mapping'][$finder_entry_entity_type_id] = $config_values['settings']['context_mapping']['ENTRY_ENTITY_TYPE_ID'];
    unset($config_values['settings']['context_mapping']['ENTRY_ENTITY_TYPE_ID']);

    $config_values['visibility']['entity_bundle:ENTRY_ENTITY_TYPE_ID']['context_mapping'][$finder_entry_entity_type_id] = $config_values['visibility']['entity_bundle:ENTRY_ENTITY_TYPE_ID']['context_mapping']['ENTRY_ENTITY_TYPE_ID'];
    unset($config_values['visibility']['entity_bundle:ENTRY_ENTITY_TYPE_ID']['context_mapping']['ENTRY_ENTITY_TYPE_ID']);

    $config_values['visibility']['entity_bundle:' . $finder_entry_entity_type_id] = $config_values['visibility']['entity_bundle:ENTRY_ENTITY_TYPE_ID'];
    unset($config_values['visibility']['entity_bundle:ENTRY_ENTITY_TYPE_ID']);

    $block = $this->entityTypeManager->getStorage('block')->create($config_values);

    $this->setFindersThirdParty($block, $finder);

    return $block;
  }

  /**
   * Determines a sidebar-ish region in the given theme.
   *
   * We need to do some guesswork because core doesn't provide a way to
   * determine a sidebar region.
   *
   * @param string|null $theme_id
   *   The theme ID. (This is allowed to be NULL for kernel tests which don't
   *   set a theme.)
   *
   * @return string
   *   The name of a region in the given theme. (If NULL was given, this is an
   *   empty string.)
   */
  protected function guessSidebarRegion(?string $theme_id): string {
    $regions = system_region_list($theme_id);
    // First try the first sidebar region.
    if (isset($regions['sidebar_first'])) {
      $region = 'sidebar_first';
    }
    // Next try to find something else sidebar-ish.
    elseif ($matches = preg_grep('/^sidebar/', array_keys($regions))) {
      $region = reset($matches);
    }
    // Fall back to the default region.
    else {
      $region = system_default_region($theme_id);
    }

    return $region;
  }

  /**
   * Sets the bundle visibility on a block.
   *
   * @param \Drupal\block\BlockInterface $block
   *   The block entity to update. This might be newly created and not yet be saved. It is the caller's
   *   responsibility to save this in all cases.
   * @param \Drupal\finders\Enum\FinderRole $finder_role
   *   The finder role to set visibility for. All bundles for this role are set
   *   for the visibility, unless the block has no visibility configuration for
   *   the relevant entity type.
   * @param \Drupal\finders\Entity\FinderInterface $finder
   *   The finder being configured.
   */
  protected function setBlockVisibility(BlockInterface $block, FinderRole $finder_role, FinderInterface $finder): void {
    $entity_type_id = match ($finder_role) {
      FinderRole::Channels => $finder->getChannelEntityTypeId(),
      FinderRole::Entries => $finder->getEntryEntityTypeId(),
    };
    $bundle_ids = match ($finder_role) {
      FinderRole::Channels => $finder->getChannelBundleIds(),
      FinderRole::Entries => $finder->getEntryBundleIds(),
    };

    $visibility_config_id = 'entity_bundle:' . $entity_type_id;

    // Not sure why getVisibility() doesn't work, so get the config values
    // directly.
    $visibility_config = $block->get('visibility');

    if (!isset($visibility_config[$visibility_config_id])) {
      // Bail if a site admin has removed all the bundle visibility.
      return;
    }

    // Add the bundles. The block may be used for other finders (either of the
    // same type, or all finders), so do not clobber any bundles already there.
    $visibility_config[$visibility_config_id]['bundles'] += array_combine($bundle_ids, $bundle_ids);

    $block->setVisibilityConfig($visibility_config_id, $visibility_config[$visibility_config_id]);
  }

  /**
   * Adds the finder ID and type to a config entity's third-party settings.
   *
   * This allows us to determine which finder(s) a config entity uses.
   *
   * @param \Drupal\Core\Config\Entity\ThirdPartySettingsInterface $config_entity
   *   The config entity to set the value on. It is the caller's responsibility
   *   to save this.
   * @param \Drupal\finders\Entity\FinderInterface $finder
   *   The finder being configured.
   */
  public function setFindersThirdParty(ThirdPartySettingsInterface $config_entity, FinderInterface $finder): void {
    $finders_list = $config_entity->getThirdPartySetting('finders', 'finders', []);

    $finders_list[$finder->id()] = $finder->getFinderTypePlugin()->getPluginId();

    $config_entity->setThirdPartySetting('finders', 'finders', $finders_list);
  }

}
