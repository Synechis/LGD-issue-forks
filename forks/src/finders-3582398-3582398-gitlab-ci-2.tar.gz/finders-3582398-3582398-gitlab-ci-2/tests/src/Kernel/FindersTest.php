<?php

namespace Drupal\Tests\finders\Kernel;

use Drupal\Core\Entity\EntityInterface;
use Drupal\Core\Entity\Plugin\DataType\ConfigEntityAdapter;
use Drupal\finders\Plugin\FinderType\FinderTypeBase;
use Drupal\KernelTests\KernelTestBase;

/**
 * Tests setting up a finder.
 *
 * @group finders
 */
class FindersTest extends KernelTestBase {

  /**
   * The modules to enable.
   *
   * @var array
   */
  protected static $modules = [
    'system',
    'user',
    'block',
    'views',
    'viewsreference',
    'search_api',
    'finders',
    // We use this for its test finder plugin, but we don't install its config.
    'finders_test',
    'entity_test',
  ];

  /**
   * The entity type manager.
   *
   * @var \Drupal\Core\Entity\EntityTypeManagerInterface
   */
  protected $entityTypeManager;

  /**
   * The entity field manager.
   *
   * @var \Drupal\Core\Entity\EntityFieldManagerInterface
   */
  protected $entityFieldManager;

  /**
   * {@inheritdoc}
   */
  protected function setUp(): void {
    parent::setUp();

    $this->installEntitySchema('search_api_task');

    $this->installEntitySchema('entity_test_with_bundle');

    $this->installConfig('finders');

    // Set up the theme so that the Views exposed block can be placed by the
    // Finder.
    $this->container->get('theme_installer')->install(['stark']);
    $this->config('system.theme')->set('default', 'stark')->save();

    $this->entityTypeManager = $this->container->get('entity_type.manager');
    $this->entityFieldManager = $this->container->get('entity_field.manager');
  }

  /**
   * Tests setting up a finder.
   */
  public function testFinderSetup() {
    // Create bundles that will be channels and entries.
    $channel_bundle = $this->entityTypeManager->getStorage('entity_test_bundle')->create([
      'id' => 'test_channel_bundle',
      'label' => 'Label',
      'status' => TRUE,
    ]);
    $channel_bundle->save();

    $channel_bundle_other = $this->entityTypeManager->getStorage('entity_test_bundle')->create([
      'id' => 'test_channel_bundle_two',
      'label' => 'Label',
      'status' => TRUE,
    ]);
    $channel_bundle_other->save();

    $entry_bundle_one = $this->entityTypeManager->getStorage('entity_test_bundle')->create([
      'id' => 'test_entry_bundle_one',
      'label' => 'Label',
      'status' => TRUE,
    ]);
    $entry_bundle_one->save();
    $entry_bundle_two = $this->entityTypeManager->getStorage('entity_test_bundle')->create([
      'id' => 'test_entry_bundle_two',
      'label' => 'Label',
      'status' => TRUE,
    ]);
    $entry_bundle_two->save();

    // Create a channel entity.
    $channel = $this->entityTypeManager->getStorage('entity_test_with_bundle')->create([
      'name' => 'test channel',
      'type' => 'test_channel_bundle',
    ]);
    $channel->save();
    // The channel does not have the finder field on it yet.
    $this->assertFalse($channel->hasField(FinderTypeBase::CHANNEL_TYPES_FIELD));

    // Attempt to create a finder with the same bundle for both entries and
    // channels, which should fail validation.
    $finder_invalid = $this->entityTypeManager->getStorage('finder')->create([
      'id' => 'invalid',
      'label' => 'Invalid',
      'type' => 'test',
      'channels' => [
        'entity_test_with_bundle' => [
          'test_channel_bundle',
        ],
      ],
      'entries' => [
        'entity_test_with_bundle' => [
          'test_channel_bundle',
        ],
      ],
    ]);

    // For a top-level constraint we have to use the more convoluted way of
    // validating a config entity because of this core bug:
    // https://www.drupal.org/project/drupal/issues/3427106.
    $violations = \Drupal::service('config.typed')->createFromNameAndData(
      $finder_invalid->getConfigDependencyName(),
      $finder_invalid->toArray()
    )->validate();
    $this->assertCount(1, $violations);
    $this->assertEquals('The bundle Label may not be used as both channels and entries.', $violations[0]->getMessage());

    // Create the finder we'll actually use.
    $finder = $this->entityTypeManager->getStorage('finder')->create([
      'id' => 'test_finder',
      'label' => 'Test',
      'type' => 'test',
      'channels' => [
        'entity_test_with_bundle' => [
          'test_channel_bundle',
        ],
      ],
      'entries' => [
        'entity_test_with_bundle' => [
          // Only set one entry bundle for now, so we test behaviour when adding
          // a second one later.
          'test_entry_bundle_one',
        ],
      ],
    ]);
    $finder->save();

    $adapter = ConfigEntityAdapter::createFromEntity($finder);
    $violations = $adapter->validate();
    $this->assertEmpty($violations);

    // Attempt to create a second finder with the same entries, which should
    // fail validation.
    $finder_invalid = $this->entityTypeManager->getStorage('finder')->create([
      'id' => 'invalid',
      'label' => 'Invalid',
      'type' => 'test',
      'channels' => [
        'entity_test_with_bundle' => [
          'test_channel_bundle',
        ],
      ],
      'entries' => [
        'entity_test_with_bundle' => [
          'test_entry_bundle_one',
        ],
      ],
    ]);
    $adapter = ConfigEntityAdapter::createFromEntity($finder_invalid);
    $violations = $adapter->validate();
    $this->assertNotEmpty($violations);

    // The bundle fields on channel and entry bundles are defined and present on
    // the entities.
    $channel_fields = $this->entityFieldManager->getFieldDefinitions('entity_test_with_bundle', 'test_channel_bundle');
    $this->assertArrayHasKey(FinderTypeBase::CHANNEL_TYPES_FIELD, $channel_fields);

    $channel = $this->reloadEntity($channel);
    $this->assertTrue($channel->hasField(FinderTypeBase::CHANNEL_TYPES_FIELD));

    $entry_fields = $this->entityFieldManager->getFieldDefinitions('entity_test_with_bundle', 'test_entry_bundle_one');
    $this->assertArrayHasKey(FinderTypeBase::CHANNEL_SELECTION_FIELD, $entry_fields);

    // View modes have been created for the entry entity type.
    $view_mode = $this->entityTypeManager->getStorage('entity_view_mode')->load('entity_test_with_bundle.finders_index');
    $this->assertNotEmpty($view_mode);
    $view_mode = $this->entityTypeManager->getStorage('entity_view_mode')->load('entity_test_with_bundle.finders_results');
    $this->assertNotEmpty($view_mode);

    // View displays have been created for the entry bundle and the two view
    // modes.
    $view_display = $this->entityTypeManager->getStorage('entity_view_display')->load('entity_test_with_bundle.test_entry_bundle_one.finders_index');
    $this->assertNotEmpty($view_display);
    $view_display = $this->entityTypeManager->getStorage('entity_view_display')->load('entity_test_with_bundle.test_entry_bundle_one.finders_results');
    $this->assertNotEmpty($view_display);

    // A search index has been created by the creation of the channel bundle.
    $search_index = $this->entityTypeManager->getStorage('search_api_index')->load('finders_index_default');
    $this->assertNotEmpty($search_index);
    $this->assertEquals(['test_finder' => 'test'], $search_index->getThirdPartySetting('finders', 'finders'));
    $fields = $search_index->getFields();
    // The entity_test_with_bundle label field is 'name', unlike nodes.
    $this->assertArrayHasKey('name', $fields);
    $this->assertArrayHasKey('rendered_item', $fields);
    $this->assertArrayHasKey('finders_title_sort', $fields);
    $this->assertArrayHasKey('finders_channels', $fields);

    // A view has been created by the creation of the channel bundle.
    $view = $this->entityTypeManager->getStorage('view')->load('finders_channel_list');
    $this->assertNotEmpty($view);
    $this->assertEquals(['test_finder' => 'test'], $view->getThirdPartySetting('finders', 'finders'));
    $this->assertArrayHasKey('finders_title_sort', $view->getDisplay('default')['display_options']['sorts']);
    $this->assertArrayHasKey('finders_channels', $view->getDisplay('default')['display_options']['arguments']);

    // A block has been created for the view exposed form.
    /** @var \Drupal\block\BlockInterface $exposed_form_block */
    $exposed_form_block = $this->entityTypeManager->getStorage('block')->load('stark_views_exposed_filter_block_finders_channel_list_channel_embed');
    $this->assertNotEmpty($exposed_form_block);
    $this->assertEquals(['test_finder' => 'test'], $exposed_form_block->getThirdPartySetting('finders', 'finders'));
    $this->assertEquals('views_exposed_filter_block:finders_channel_list-channel_embed', $exposed_form_block->getPluginId());
    $this->assertEquals('sidebar_first', $exposed_form_block->getRegion());
    $this->assertArrayHasKey('entity_bundle:entity_test_with_bundle', $exposed_form_block->getVisibility());
    $bundle_visibility_config = $exposed_form_block->getVisibility()['entity_bundle:entity_test_with_bundle'];
    $this->assertContains('test_channel_bundle', $bundle_visibility_config['bundles']);
    $this->assertNotContains('test_channel_bundle_two', $bundle_visibility_config['bundles'], 'The bundle that is not (yet) a channel bundle is not set in the visibility.');

    // The channel search block has been created.
    /** @var \Drupal\block\BlockInterface $channel_search_block */
    $channel_search_block = $this->entityTypeManager->getStorage('block')->load('stark_finders_channel_search');
    $this->assertNotEmpty($channel_search_block);
    $this->assertEquals(['test_finder' => 'test'], $channel_search_block->getThirdPartySetting('finders', 'finders'));
    $this->assertEquals('finders_channel_search', $channel_search_block->getPluginId());
    $this->assertEquals('sidebar_first', $channel_search_block->getRegion());
    $this->assertArrayHasKey('entity_bundle:entity_test_with_bundle', $channel_search_block->getVisibility());
    $bundle_visibility_config = $channel_search_block->getVisibility()['entity_bundle:entity_test_with_bundle'];
    $this->assertContains('test_entry_bundle_one', $bundle_visibility_config['bundles']);
    $this->assertNotContains('test_entry_bundle_two', $bundle_visibility_config['bundles'], 'The bundle that is not (yet) an entry bundle is not set in the visibility.');

    // Set up a second entry bundle on the finder.
    $finder->set('entries', [
      'entity_test_with_bundle' => [
        'test_entry_bundle_one',
        'test_entry_bundle_two',
      ],
    ]);
    $finder->save();

    // The channel search block's visibility has been updated with the new
    // entry bundle.
    $channel_search_block = $this->reloadEntity($channel_search_block);
    $bundle_visibility_config = $channel_search_block->getVisibility()['entity_bundle:entity_test_with_bundle'];
    $this->assertContains('test_entry_bundle_one', $bundle_visibility_config['bundles']);
    $this->assertContains('test_entry_bundle_two', $bundle_visibility_config['bundles']);

    // Set up a second channel bundle on the finder.
    $finder->set('channels', [
      'entity_test_with_bundle' => [
        'test_channel_bundle',
        'test_channel_bundle_two',
      ],
    ]);
    $finder->save();

    // The exposed form block's visibility has been updated with the new
    // channel bundle.
    $exposed_form_block = $this->reloadEntity($exposed_form_block);
    $bundle_visibility_config = $exposed_form_block->getVisibility()['entity_bundle:entity_test_with_bundle'];
    $this->assertContains('test_channel_bundle', $bundle_visibility_config['bundles']);
    $this->assertContains('test_channel_bundle_two', $bundle_visibility_config['bundles']);

    // Set up a second finder, to check common config entities dont' get things
    // clobbered.
    $channel_bundle_other = $this->entityTypeManager->getStorage('entity_test_bundle')->create([
      'id' => 'test_channel_bundle_other',
      'label' => 'Label',
      'status' => TRUE,
    ]);
    $channel_bundle_other->save();

    $entry_bundle_other = $this->entityTypeManager->getStorage('entity_test_bundle')->create([
      'id' => 'test_entry_bundle_other',
      'label' => 'Label',
      'status' => TRUE,
    ]);
    $entry_bundle_other->save();

    // Create the secondary finder.
    $finder = $this->entityTypeManager->getStorage('finder')->create([
      'id' => 'test_other',
      'label' => 'Test other',
      'type' => 'test',
      'channels' => [
        'entity_test_with_bundle' => [
          'test_channel_bundle_other',
        ],
      ],
      'entries' => [
        'entity_test_with_bundle' => [
          'test_entry_bundle_other',
        ],
      ],
    ]);
    $finder->save();

    // The exposed form block's visibility has been updated with the new
    // finder's channel bundle, but has not clobbered the first finder's
    // bundles.
    $exposed_form_block = $this->reloadEntity($exposed_form_block);
    $bundle_visibility_config = $exposed_form_block->getVisibility()['entity_bundle:entity_test_with_bundle'];
    $this->assertContains('test_channel_bundle_other', $bundle_visibility_config['bundles']);
    $this->assertContains('test_channel_bundle', $bundle_visibility_config['bundles']);
    $this->assertContains('test_channel_bundle_two', $bundle_visibility_config['bundles']);

    // Check API functions on the finder type manager.
    $finder_type_manager = $this->container->get('plugin.manager.finders_finder_type');
    $this->assertArrayHasKey('test', $finder_type_manager->getActiveFinderTypes());

    // At present unrestricted which test entity type bundles.
    $channel->{FinderTypeBase::CHANNEL_TYPES_FIELD} = $channels = [
      ['target_id' => 'test_entry_bundle_one'],
      ['target_id' => 'test_entry_bundle_two'],
    ];
    $channel->save();

    $channel = $this->reloadEntity($channel);
    $this->assertEquals($channels, $channel->get(FinderTypeBase::CHANNEL_TYPES_FIELD)->getValue());

    // Create an entry entity.
    $entry = $this->entityTypeManager->getStorage('entity_test_with_bundle')->create([
      'name' => 'test entry',
      'type' => 'test_entry_bundle_one',
      FinderTypeBase::CHANNEL_SELECTION_FIELD => $channel->id(),
    ]);
    $entry->save();

    // The possible values for the channels types field on the channel entity
    // are the entry bundles for the finder.
    $this->assertEquals(
      [
        'test_entry_bundle_one',
        'test_entry_bundle_two',
      ],
      $channel->{FinderTypeBase::CHANNEL_TYPES_FIELD}->get(0)->getSettableValues()
    );

    // The possible values for the channels field on the entry entity
    // are the channels that reference the entry entity's bundle.
    $this->assertEquals(
      [
        $channel->id(),
      ],
      $entry->{FinderTypeBase::CHANNEL_SELECTION_FIELD}->get(0)->getSettableValues()
    );
  }

  /**
   * Reloads the given entity from the storage and returns it.
   *
   * @todo Replace this with EntityTrait when 10.4.0 is minimum supported
   * version.
   *
   * @param \Drupal\Core\Entity\EntityInterface $entity
   *   The entity to be reloaded.
   *
   * @return \Drupal\Core\Entity\EntityInterface
   *   The reloaded entity.
   */
  protected function reloadEntity(EntityInterface $entity) {
    $controller = $this->entityTypeManager->getStorage($entity->getEntityTypeId());
    $controller->resetCache([$entity->id()]);
    return $controller->load($entity->id());
  }

}
