# Finders facets

TODO: write some documentation.

## Requirements

This module requires the following modules:

- [facets](https://www.drupal.org/project/facets)
- [better_exposed_filters](https://www.drupal.org/project/better_exposed_filters)

Additionally, the following modules are recommended:

- [entity_add_another](https://www.drupal.org/project/entity_add_another) allows
  the UX for adding facet entities to be streamlined.

## Installation

Install as you would normally install a contributed Drupal module. For further
information, see
[Installing Drupal Modules](https://www.drupal.org/docs/extending-drupal/installing-drupal-modules).

## Configuration

1. Grant the 'Administer Finders facet type entities' permission to roles that
   should create facet types.
2. Grant the 'Administer Finders facet entities' permission to roles that
   should create facets.
3. Facets are visible to users with the main 'Access content' permission.
4. Go to Administration » Content » Finders Facets
5. Create one or more Finders Facet types.
6. Create one or more Finders Facets.
7. Edit a finder, and enable the 'Enable facets' checkbox.
8. Edit a finder channel entity, and select the facet types that channel allows.
9. Edit finder entry entities in that channel and select the facets.
