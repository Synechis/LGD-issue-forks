<?php

declare(strict_types=1);

namespace Drupal\finders_facets\Plugin\facets\processor;

use Drupal\Core\Entity\EntityTypeManagerInterface;
use Drupal\Core\Plugin\ContainerFactoryPluginInterface;
use Drupal\Core\Routing\RouteMatchInterface;
use Drupal\facets\FacetInterface;
use Drupal\facets\Processor\BuildProcessorInterface;
use Drupal\facets\Processor\ProcessorPluginBase;
use Drupal\facets\Result\ResultInterface;
use Drupal\finders_facets\Facets\FacetPluginSupportsTrait;
use Drupal\finders_facets\Hook\FindersHooks;
use Drupal\node\NodeInterface;
use Symfony\Component\DependencyInjection\ContainerInterface;

/**
 * Removes finders facets that not present in the current Finder channel.
 *
 * When an entry entity belongs to several channels, it can have facets from all
 * the facet types that all the channels support. This processor removes facets
 * that are from facet types that the current channel entity doesn't support.
 *
 * This has a very low weight to save other processors in the build stage the
 * bother of working with results that are going to be removed.
 *
 * @FacetsProcessor(
 *   id = "finders_facets_channel_filter",
 *   label = @Translation("Finder channel filter"),
 *   description = @Translation("Remove Finders Facets not present in the current Finder channel."),
 *   stages = {
 *     "build" = -50,
 *   }
 * )
 */
class FindersFacetsChannelFilter extends ProcessorPluginBase implements BuildProcessorInterface, ContainerFactoryPluginInterface {

  use FacetPluginSupportsTrait;

  /**
   * {@inheritdoc}
   */
  public static function create(ContainerInterface $container, array $configuration, $plugin_id, $plugin_definition) {
    return new static(
      $configuration,
      $plugin_id,
      $plugin_definition,
      $container->get('entity_type.manager'),
      $container->get('current_route_match'),
    );
  }

  /**
   * Creates a FindersFacetsChannelFilter instance.
   *
   * @param array $configuration
   *   A configuration array containing information about the plugin instance.
   * @param string $plugin_id
   *   The plugin_id for the plugin instance.
   * @param mixed $plugin_definition
   *   The plugin implementation definition.
   * @param \Drupal\Core\Entity\EntityTypeManagerInterface $entityTypeManager
   *   The entity type manager.
   * @param \Drupal\Core\Routing\RouteMatchInterface $currentRouteMatch
   *   The currently active route match object.
   */
  public function __construct(
    array $configuration,
    $plugin_id,
    $plugin_definition,
    protected EntityTypeManagerInterface $entityTypeManager,
    protected RouteMatchInterface $currentRouteMatch,
  ) {
    parent::__construct($configuration, $plugin_id, $plugin_definition);
  }

  /**
   * {@inheritdoc}
   */
  public function build(FacetInterface $facet, array $results) {
    $facet_storage = $this->entityTypeManager->getStorage('finders_facet');

    // Assume this is on a channel node.
    // @todo Handle other entities that can also be finder channels. There's no
    // way to get the host entity other than from the route match - the Facet
    // entity knows the SearchAPI Index and the view it's used for, so we can
    // load the view, and once
    // http://www.drupal.org/project/finders/issues/3556211 is fixed, we can get
    // the finder, then the channel entity type, and from that we know what to
    // get from the route match for the channel entity.
    $channel_entity = $this->currentRouteMatch->getParameter('node');

    // Bail if we can't get a channel node.
    if (!$channel_entity instanceof NodeInterface) {
      return $results;
    }

    // Bail if the channel node doesn't have our facet field.
    if (!$channel_entity->hasField(FindersHooks::FACET_ENABLE_FIELD)) {
      return $results;
    }

    // Load the finders facet entities.
    $finders_facet_ids = array_map(fn (ResultInterface $result) => $result->getRawValue(), $results);
    $finders_facets = $facet_storage->loadMultiple($finders_facet_ids);

    // Get the active facet types from the channel entity.
    $active_facet_types = array_column($channel_entity->finders_facets_enable->getValue(), 'target_id');

    $filtered_results = array_filter(
      $results,
      // Filter out finders facets whose type is not one of the active finders
      // facet types.
      fn (ResultInterface $result) => in_array($finders_facets[$result->getRawValue()]->bundle(), $active_facet_types),
    );

    return $filtered_results;
  }

}
