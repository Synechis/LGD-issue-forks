<?php

declare(strict_types=1);

namespace Drupal\finders_facets\Plugin\facets\processor;

use Drupal\Core\Entity\EntityTypeManagerInterface;
use Drupal\Core\Plugin\ContainerFactoryPluginInterface;
use Drupal\facets\Processor\SortProcessorPluginBase;
use Drupal\facets\Result\ResultInterface;
use Symfony\Component\DependencyInjection\ContainerInterface;

/**
 * Sort Facet items by their weight property.
 *
 * @FacetsProcessor(
 *   id = "finders_facets_weight_order",
 *   label = @Translation("Sort finder facets by weight"),
 *   description = @Translation("Sorts the widget results by their weight. Only applies to Facet items with a *weight* property."),
 *   default_enabled = TRUE,
 *   stages = {
 *     "sort" = 50
 *   }
 * )
 */
class WeightOrderProcessor extends SortProcessorPluginBase implements ContainerFactoryPluginInterface {

  /**
   * Mapping between facet id and facet weight.
   *
   * @var array
   */
  protected $facetsWeightMap = [];

  /**
   * The entity type manager.
   *
   * @var \Drupal\Core\Entity\EntityTypeManagerInterface
   */
  protected $entityTypeManager;

  /**
   * {@inheritdoc}
   */
  public static function create(ContainerInterface $container, array $configuration, $plugin_id, $plugin_definition) {
    return new static(
      $configuration,
      $plugin_id,
      $plugin_definition,
      $container->get('entity_type.manager')
    );
  }

  /**
   * Constructs a new object.
   *
   * @param array $configuration
   *   A configuration array containing information about the plugin instance.
   * @param string $plugin_id
   *   The plugin_id for the plugin instance.
   * @param mixed $plugin_definition
   *   The plugin implementation definition.
   * @param \Drupal\Core\Entity\EntityTypeManagerInterface $entity_type_manager
   *   The entity type manager.
   */
  public function __construct(array $configuration, $plugin_id, $plugin_definition, EntityTypeManagerInterface $entity_type_manager) {
    parent::__construct($configuration, $plugin_id, $plugin_definition);

    $this->entityTypeManager = $entity_type_manager;
  }

  /**
   * {@inheritdoc}
   *
   * Compare *Facet items* by the value of their *weight* property.
   */
  public function sortResults(ResultInterface $a, ResultInterface $b) {
    $a_facet_id = $a->getRawValue();
    $b_facet_id = $b->getRawValue();

    $this->loadFacetWeightsOnce($a_facet_id, $b_facet_id);

    $a_weight = $this->facetsWeightMap[$a_facet_id];
    $b_weight = $this->facetsWeightMap[$b_facet_id];

    return $a_weight <=> $b_weight;
  }

  /**
   * Loads the weight value into the facetWeight property of each Result item.
   *
   * Here we strive to load each Facet item only once for performance reasons.
   * When a Facet item is sent for comparison for the first time, we load its
   * weight and retain it as the value of its *facetWeight* property.
   * Subsequent comparisons reuse this weight value instead of reloading this
   * Facet item.
   */
  protected function loadFacetWeightsOnce(int|string $a_facet_id, int|string $b_facet_id): void {
    $facet_storage = $this->entityTypeManager->getStorage('finders_facet');

    if (!array_key_exists($a_facet_id, $this->facetsWeightMap)) {
      $a_facet_entity = $facet_storage->load($a_facet_id);
      $this->facetsWeightMap[$a_facet_id] = $a_facet_entity->get('weight')->value ?? 0;
    }

    if (!array_key_exists($b_facet_id, $this->facetsWeightMap)) {
      $b_facet_entity = $facet_storage->load($b_facet_id);
      $this->facetsWeightMap[$b_facet_id] = $b_facet_entity->get('weight')->value ?? 0;
    }
  }

}
