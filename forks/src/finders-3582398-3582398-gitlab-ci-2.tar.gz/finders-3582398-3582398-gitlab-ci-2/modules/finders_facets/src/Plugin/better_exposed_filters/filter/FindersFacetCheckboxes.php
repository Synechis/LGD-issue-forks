<?php

namespace Drupal\finders_facets\Plugin\better_exposed_filters\filter;

use Drupal\better_exposed_filters\Attribute\FiltersWidget;
use Drupal\better_exposed_filters\Plugin\better_exposed_filters\filter\RadioButtons;
use Drupal\Component\Utility\SortArray;
use Drupal\Core\Config\ConfigFactoryInterface;
use Drupal\Core\Entity\EntityTypeManagerInterface;
use Drupal\Core\Form\FormStateInterface;
use Drupal\Core\Plugin\ContainerFactoryPluginInterface;
use Drupal\Core\StringTranslation\TranslatableMarkup;
use Symfony\Component\DependencyInjection\ContainerInterface;
use Symfony\Component\HttpFoundation\Request;

/**
 * Finders facets filter widget.
 *
 * This groups the facet checkboxes by their facet type.
 */
#[FiltersWidget(
  id: 'finders_facets_checkboxes',
  title: new TranslatableMarkup('Finders facets checkboxes'),
)]
class FindersFacetCheckboxes extends RadioButtons implements ContainerFactoryPluginInterface {

/**
   * The entity type manager.
   *
   * @var \Drupal\Core\Entity\EntityTypeManagerInterface
   */
  protected $entityTypeManager;

  /**
   * {@inheritdoc}
   */
  public static function create(ContainerInterface $container, array $configuration, $plugin_id, $plugin_definition): static {
    return new static(
      $configuration,
      $plugin_id,
      $plugin_definition,
      $container->get('request_stack')->getCurrentRequest(),
      $container->get('config.factory'),
      $container->get('entity_type.manager'),
    );
  }

  /**
   * Creates a FindersFacetCheckboxes instance.
   *
   * @param array $configuration
   *   A configuration array containing information about the plugin instance.
   * @param string $plugin_id
   *   The plugin_id for the plugin instance.
   * @param mixed $plugin_definition
   *   The plugin implementation definition.
   * @param \Symfony\Component\HttpFoundation\Request $request
   *   The request.
   * @param \Drupal\Core\Config\ConfigFactoryInterface $configFactory
   *   The configFactory.
   * @param \Drupal\Core\Entity\EntityTypeManagerInterface $entity_type_manager
   *   The entity type manager.
   */
  public function __construct(
    array $configuration,
    $plugin_id,
    $plugin_definition,
    Request $request,
    ConfigFactoryInterface $configFactory,
    EntityTypeManagerInterface $entity_type_manager,
  ) {
    parent::__construct($configuration, $plugin_id, $plugin_definition, $request, $configFactory);
    $this->entityTypeManager = $entity_type_manager;
  }

  /**
   * {@inheritdoc}
   */
  public function exposedFormAlter(array &$form, FormStateInterface $form_state): void {
    parent::exposedFormAlter($form, $form_state);

    /** @var \Drupal\views\Plugin\views\filter\FilterPluginBase $filter */
    $filter = $this->handler;

    // Form element is designated by the element ID which is user-
    // configurable.
    $field_id = $filter->options['is_grouped'] ? $filter->options['group_info']['identifier'] : $filter->options['expose']['identifier'];

    // Facets come here with an empty form before the view query is run.
    if (empty($form[$field_id]['#options'])) {
      return;
    }

    $original_options = $form[$field_id]['#options'];

    $facet_type_storage = $this->entityTypeManager->getStorage('finders_facet_type');
    $facet_storage = $this->entityTypeManager->getStorage('finders_facet');
    $facet_ids = array_keys($original_options);
    $facets = $facet_storage->loadMultiple($facet_ids);

    // Group the facet options by their facet type.
    $grouped_items = [];
    foreach ($facets as $facet_id => $facet) {
      $grouped_items[$facet->bundle()]['children'][$facet_id] = $original_options[$facet_id];
    }

    // Add facet type labels.
    $active_facet_types = $facet_type_storage->loadMultiple(array_keys($grouped_items));
    foreach ($active_facet_types as $facet_type_id => $facet_type) {
      $grouped_items[$facet_type_id]['title'] = $facet_type->label();
      $grouped_items[$facet_type_id]['weight'] = $facet_type->getWeight();
    }

    uasort($grouped_items, SortArray::sortByWeightElement(...));

    $form[$field_id]['#finders_facets_groups'] = $grouped_items;
    $form[$field_id]['#theme'] = 'finders_facets_bef_checkboxes';
  }

}
