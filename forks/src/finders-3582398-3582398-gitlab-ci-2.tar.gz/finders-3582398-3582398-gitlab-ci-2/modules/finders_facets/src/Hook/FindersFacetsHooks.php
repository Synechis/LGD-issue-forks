<?php

declare(strict_types=1);

namespace Drupal\finders_facets\Hook;

use Drupal\Core\Hook\Attribute\Hook;

/**
 * Contains hook implementations for the Finders Facets module.
 */
class FindersFacetsHooks {

  /**
   * Implements hook_theme().
   */
  #[Hook('theme')]
  public function theme($existing, $type, $theme, $path): array {
    return [
      'finders_facets_bef_checkboxes' => [
        'render element' => 'elements',
        'base_hook' => 'bef_checkboxes',
      ],
    ];
  }

}
