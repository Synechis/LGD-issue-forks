<?php

namespace Drupal\finders_facets\Entity;

use Drupal\Core\Config\Entity\ConfigEntityInterface;
use Drupal\Core\Entity\EntityDescriptionInterface;

/**
 * Interface for Finders Facet Type entities.
 */
interface FindersFacetTypeInterface extends ConfigEntityInterface, EntityDescriptionInterface {

  /**
   * Returns the weight of this facet type (used for sorting).
   *
   * @return int
   *   The facet type weight.
   */
  public function getWeight(): int;

}
