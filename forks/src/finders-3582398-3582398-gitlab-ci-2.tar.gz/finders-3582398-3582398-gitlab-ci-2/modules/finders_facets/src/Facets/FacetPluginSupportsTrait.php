<?php

declare(strict_types=1);

namespace Drupal\finders_facets\Facets;

use Drupal\facets\FacetInterface;
use Drupal\finders_facets\Hook\FindersHooks;

/**
 * Trait for our Facets plugins to declare that they only work with our facets.
 */
trait FacetPluginSupportsTrait {

  /**
   * Implements \Drupal\facets\Processor\ProcessorInterface::supportsFacet()
   */
  public function supportsFacet(FacetInterface $facet) {
    return ($facet->getFieldIdentifier() == FindersHooks::FACET_INDEXING_FIELD);
  }

}
