<?php

namespace Drupal\localgov_sa11y\Hook;

use Drupal\Core\Hook\Attribute\Hook;
/**
 * Hook implementations for localgov_sa11y.
 */
class LocalgovSa11yHooks
{
    /**
     * @file
     * Primary module hooks for Localgov Sa11y module.
     */
    /**
     * Implements hook_page_attachments().
     */
    #[Hook('page_attachments')]
    public function pageAttachments(array &$page)
    {
        $admin_theme = \Drupal::config('system.theme')->get('admin');
        $active_theme = \Drupal::theme()->getActiveTheme()->getName();
        $using_admin_theme = $admin_theme === $active_theme;
        if (\Drupal::currentUser()->hasPermission('use_localgov_sa11y') && !$using_admin_theme) {
            $page['#attached']['library'][] = 'localgov_sa11y/localgov_sa11y';
        }
        $config = \Drupal::configFactory()->get('localgov_sa11y.settings');
        $page['#attached']['drupalSettings']['localgov_sa11y']['checkRoot'] = $config->get('checkRoot');
        $page['#attached']['drupalSettings']['localgov_sa11y']['containerIgnore'] = $config->get('containerIgnore');
        $page['#attached']['drupalSettings']['localgov_sa11y']['contrastIgnore'] = $config->get('contrastIgnore');
        $page['#attached']['drupalSettings']['localgov_sa11y']['linkIgnore'] = $config->get('linkIgnore');
        $page['#attached']['drupalSettings']['localgov_sa11y']['exportResultsPlugin'] = $config->get('exportResultsPlugin');
        $page['#attached']['drupalSettings']['localgov_sa11y']['checkAllHideToggles'] = $config->get('checkAllHideToggles');
        $page['#attached']['drupalSettings']['localgov_sa11y']['panelPosition'] = $config->get('panelPosition');
    }
}
