<?php

namespace Drupal\localgov_publications_importer;

use Smalot\PdfParser\Element\ElementName;

/**
 * Works out which image filter is left to handle for a PDF image.
 *
 * A PDF image can list several filters, for example
 * [/ASCII85Decode /FlateDecode]. The PDF parser decodes the ones it supports,
 * in the order they are listed, before the importer gets the image data. So
 * what is left to handle is not the first or the last name in the list:
 * - If the parser could not decode one of the filters (JPEG, JPEG 2000, JBIG2,
 *   CCITT, Crypt), the data is whatever that filter takes as input. The first
 *   such filter decides how the data is used, for example DCTDecode for a JPEG.
 * - If the parser decoded all of them, the data is raw samples, which the
 *   transform rebuilds into an image.
 */
final class ImageFilterResolver {

  /**
   * The filters the PDF parser decodes before it hands over the image data.
   */
  const DECODED_BY_PARSER = [
    'ASCIIHexDecode',
    'ASCII85Decode',
    'LZWDecode',
    'FlateDecode',
    'RunLengthDecode',
  ];

  /**
   * The filter name for raw samples.
   *
   * This keeps the name FlateDecode, which imports that were extracted earlier
   * have stored for the same kind of data.
   */
  const RAW_SAMPLES = 'FlateDecode';

  /**
   * Gets the filter name to store for an image.
   *
   * @param mixed $filter
   *   The content of the /Filter entry of the image: a name, an array of names
   *   or nothing at all.
   *
   * @return string
   *   The name of the first filter the parser cannot decode, or RAW_SAMPLES if
   *   there is none.
   */
  public static function resolve(mixed $filter): string {
    foreach (is_array($filter) ? $filter : [$filter] as $name) {
      if ($name instanceof ElementName) {
        $name = $name->getContent();
      }
      if (is_string($name) && $name !== '' && !in_array($name, self::DECODED_BY_PARSER, TRUE)) {
        return $name;
      }
    }
    return self::RAW_SAMPLES;
  }

}
