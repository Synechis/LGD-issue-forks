<?php

namespace Drupal\Tests\localgov_publications_importer\Functional;

use Drupal\Core\File\FileExists;
use Drupal\file\Entity\File;
use Drupal\localgov_publications_importer\Entity\Import;
use Drupal\localgov_publications_importer\ImageInterface;
use Drupal\localgov_publications_importer\Plugin\LocalGovImporter\Extract\SmalotPdfParserExtract;
use Drupal\localgov_publications_importer\Plugin\LocalGovImporter\Transform\Images;
use Drupal\media\Entity\Media;

/**
 * Tests that images with chained PDF filters survive extract and transform.
 *
 * A PDF image can list several filters, for example
 * [/ASCII85Decode /FlateDecode]. The PDF parser decodes the ones it supports,
 * in order, so what the importer receives is either raw samples or the bytes
 * of the first filter the parser cannot decode.
 *
 * @group localgov_publications_importer
 */
class ChainedImageFilterTest extends FunctionalTestBase {

  use PdfImageFixtureTrait;

  /**
   * Data provider for the filter chains that must produce an image.
   *
   * Each case is the /Filter entry, the encoded image stream and the expected
   * kind of file: 'png' (rebuilt from raw samples) or 'jpg' (the JPEG bytes).
   */
  public static function supportedChainProvider(): array {
    $flate = gzcompress(self::rawPixels());
    $jpeg = self::jpegBytes();
    return [
      'single Flate' => ['/FlateDecode', $flate, 'png'],
      'one-element array' => ['[/FlateDecode]', $flate, 'png'],
      'ASCII85 then Flate' => ['[/ASCII85Decode /FlateDecode]', self::ascii85($flate), 'png'],
      'ASCIIHex then Flate' => ['[/ASCIIHexDecode /FlateDecode]', strtoupper(bin2hex($flate)) . '>', 'png'],
      'single DCT' => ['/DCTDecode', $jpeg, 'jpg'],
      'ASCII85 then DCT' => ['[/ASCII85Decode /DCTDecode]', self::ascii85($jpeg, FALSE), 'jpg'],
    ];
  }

  /**
   * Data provider for the filter chains that must be skipped, not saved.
   */
  public static function skippedChainProvider(): array {
    return [
      // The PDF parser rejects "z" in ASCII85 data and leaves the stream
      // encoded, so the bytes are not a JPEG even though the filter says so.
      'ASCII85 with z then DCT, left encoded by the parser' => [
        '[/ASCII85Decode /DCTDecode]',
        self::ascii85(self::jpegBytes(), TRUE),
      ],
      'ASCII85 then JPX, a codec the importer cannot decode' => [
        '[/ASCII85Decode /JPXDecode]',
        self::ascii85('not a real JPEG 2000 stream'),
      ],
    ];
  }

  /**
   * Tests that supported chains give a file and media with the right pixels.
   *
   * @dataProvider supportedChainProvider
   */
  public function testSupportedChain(string $filter, string $stream, string $kind): void {
    $image = $this->importImage($filter, $stream);

    $this->assertNotNull($image->getFileId(), 'The image has a file entity.');
    $this->assertNotNull($image->getMediaId(), 'The image has a media entity.');
    $this->assertInstanceOf(Media::class, Media::load($image->getMediaId()));

    $file = File::load($image->getFileId());
    $bytes = (string) file_get_contents($file->getFileUri());
    if ($kind === 'jpg') {
      $this->assertSame('jpg', $image->fileExtension());
      $this->assertSame("\xFF\xD8", substr($bytes, 0, 2), 'The saved file is a JPEG.');
      return;
    }

    $this->assertSame('png', $image->fileExtension());
    $gd = imagecreatefromstring($bytes);
    $this->assertInstanceOf(\GdImage::class, $gd, 'The saved file is a readable image.');
    $this->assertSame(self::imageSize(), imagesx($gd));
    $this->assertSame(self::imageSize(), imagesy($gd));
    // Compare a few pixels with rgb(x * 32, y * 32, (x + y) * 16).
    foreach ([[0, 0], [7, 7], [3, 5]] as [$x, $y]) {
      $rgb = imagecolorat($gd, $x, $y);
      $this->assertSame(
        [$x * 32, $y * 32, ($x + $y) * 16],
        [($rgb >> 16) & 0xFF, ($rgb >> 8) & 0xFF, $rgb & 0xFF],
        "Pixel ($x, $y) has the expected colour."
      );
    }
  }

  /**
   * Tests that images that cannot be decoded are skipped, not saved as junk.
   *
   * @dataProvider skippedChainProvider
   */
  public function testSkippedChain(string $filter, string $stream): void {
    $mediaBefore = count(Media::loadMultiple());
    $image = $this->importImage($filter, $stream);

    $this->assertNull($image->getFileId(), 'No file was saved.');
    $this->assertNull($image->getMediaId(), 'No media was created.');
    $this->assertCount($mediaBefore, Media::loadMultiple(), 'No media entity was added.');
  }

  /**
   * Runs the extract and transform steps on a one image PDF.
   *
   * @return \Drupal\localgov_publications_importer\ImageInterface
   *   The image as it is after the transform.
   */
  protected function importImage(string $filter, string $stream): ImageInterface {
    $file = $this->container->get('file.repository')
      ->writeData(self::buildPdf($filter, $stream), 'public://chained-filter.pdf', FileExists::Replace);

    $import = Import::create([
      'file' => $file,
      'title' => 'Chained filter',
      'creator' => $this->drupalCreateUser(),
      'pipeline' => 'standard',
    ]);
    $import->save();

    $extract = SmalotPdfParserExtract::create($this->container, [], 'smalot_pdfparser', []);
    $extract->extract($import);
    $import->save();

    $images = $import->getPages()[0]->getImages();
    $this->assertCount(1, $images, 'The extract step found the image.');

    $transform = Images::create($this->container, [], 'transform_images', []);
    $transform->transform($import);

    // transform() serialises the mutated pages back into the entity.
    return $import->getPages()[0]->getImages()[0];
  }

}
