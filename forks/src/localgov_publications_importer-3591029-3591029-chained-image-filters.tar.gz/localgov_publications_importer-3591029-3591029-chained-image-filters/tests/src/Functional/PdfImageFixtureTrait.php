<?php

namespace Drupal\Tests\localgov_publications_importer\Functional;

/**
 * Builds small synthetic PDFs with one image, for image filter tests.
 *
 * Every PDF also has a text layer, so the extract step does not skip the page
 * for having no text. The image is an 8x8 RGB gradient, see rawPixels().
 */
trait PdfImageFixtureTrait {

  /**
   * Gets the width and height of the fixture image, in pixels.
   *
   * This is a method, not a constant, because traits cannot have constants
   * before PHP 8.2.
   */
  protected static function imageSize(): int {
    return 8;
  }

  /**
   * Gets the raw samples of the fixture image: 8 bits of R, G and B per pixel.
   *
   * Pixel (x, y) is rgb(x * 32, y * 32, (x + y) * 16).
   */
  protected static function rawPixels(): string {
    $samples = '';
    for ($y = 0; $y < self::imageSize(); $y++) {
      for ($x = 0; $x < self::imageSize(); $x++) {
        $samples .= chr($x * 32) . chr($y * 32) . chr(($x + $y) * 16);
      }
    }
    return $samples;
  }

  /**
   * Gets the fixture image as a JPEG.
   */
  protected static function jpegBytes(): string {
    $image = imagecreatetruecolor(self::imageSize(), self::imageSize());
    for ($y = 0; $y < self::imageSize(); $y++) {
      for ($x = 0; $x < self::imageSize(); $x++) {
        imagesetpixel($image, $x, $y, imagecolorallocate($image, $x * 32, $y * 32, ($x + $y) * 16));
      }
    }
    ob_start();
    imagejpeg($image, NULL, 90);
    return (string) ob_get_clean();
  }

  /**
   * Encodes data as ASCII85.
   *
   * @param string $data
   *   The data to encode.
   * @param bool $shortcutZero
   *   Whether to write four zero bytes as "z", which the specification allows.
   */
  protected static function ascii85(string $data, bool $shortcutZero = TRUE): string {
    $encoded = '';
    $length = strlen($data);
    for ($i = 0; $i < $length; $i += 4) {
      $chunk = substr($data, $i, 4);
      $padding = 4 - strlen($chunk);
      $value = unpack('N', str_pad($chunk, 4, "\0"))[1];
      if ($shortcutZero && $value === 0 && $padding === 0) {
        $encoded .= 'z';
        continue;
      }
      $group = '';
      for ($k = 0; $k < 5; $k++) {
        $group = chr($value % 85 + 33) . $group;
        $value = intdiv($value, 85);
      }
      $encoded .= substr($group, 0, 5 - $padding);
    }
    return $encoded . '~>';
  }

  /**
   * Builds a one page PDF with one image.
   *
   * @param string $filter
   *   The /Filter entry as written in the PDF, for example
   *   "[/ASCII85Decode /FlateDecode]".
   * @param string $stream
   *   The image stream bytes, already encoded for that filter chain.
   */
  protected static function buildPdf(string $filter, string $stream): string {
    $size = self::imageSize();
    $text = "BT /F1 12 Tf 20 100 Td (Sample image embedded in a PDF) Tj ET\nq 64 0 0 64 20 20 cm /Im1 Do Q";
    $objects = [
      1 => '<< /Type /Catalog /Pages 2 0 R >>',
      2 => '<< /Type /Pages /Kids [3 0 R] /Count 1 >>',
      3 => '<< /Type /Page /Parent 2 0 R /MediaBox [0 0 200 140] /Contents 4 0 R /Resources << /Font << /F1 5 0 R >> /XObject << /Im1 6 0 R >> >> >>',
      4 => '<< /Length ' . strlen($text) . " >>\nstream\n" . $text . "\nendstream",
      5 => '<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica >>',
      6 => "<< /Type /XObject /Subtype /Image /Width $size /Height $size /ColorSpace /DeviceRGB /BitsPerComponent 8 /Filter $filter /Length " . strlen($stream) . " >>\nstream\n" . $stream . "\nendstream",
    ];
    $pdf = "%PDF-1.4\n";
    $offsets = [];
    foreach ($objects as $number => $body) {
      $offsets[$number] = strlen($pdf);
      $pdf .= "$number 0 obj\n$body\nendobj\n";
    }
    $xref = strlen($pdf);
    $pdf .= "xref\n0 " . (count($objects) + 1) . "\n0000000000 65535 f \n";
    foreach ($offsets as $offset) {
      $pdf .= sprintf("%010d 00000 n \n", $offset);
    }
    $pdf .= 'trailer << /Size ' . (count($objects) + 1) . " /Root 1 0 R >>\nstartxref\n$xref\n%%EOF\n";
    return $pdf;
  }

}
