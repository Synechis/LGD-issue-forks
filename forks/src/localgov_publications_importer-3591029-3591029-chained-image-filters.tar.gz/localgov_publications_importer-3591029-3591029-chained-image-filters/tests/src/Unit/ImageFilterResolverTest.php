<?php

namespace Drupal\Tests\localgov_publications_importer\Unit;

use Drupal\localgov_publications_importer\ImageFilterResolver;
use Drupal\Tests\UnitTestCase;
use Smalot\PdfParser\Element\ElementName;

/**
 * Tests which image filter name is kept for a PDF image's /Filter value.
 *
 * @group localgov_publications_importer
 * @coversDefaultClass \Drupal\localgov_publications_importer\ImageFilterResolver
 */
class ImageFilterResolverTest extends UnitTestCase {

  /**
   * Data provider for testResolve().
   *
   * The expected names follow what the PDF parser hands over: it has already
   * applied every filter it can decode, in array order. What is left is raw
   * samples (named FlateDecode, the raw sample branch of the transform) or the
   * bytes of the first filter it cannot decode.
   */
  public static function filterProvider(): array {
    return [
      'single name' => ['FlateDecode', 'FlateDecode'],
      'single DCT name' => ['DCTDecode', 'DCTDecode'],
      'one-element array' => [[new ElementName('FlateDecode')], 'FlateDecode'],
      'ASCII85 then Flate' => [
        [new ElementName('ASCII85Decode'), new ElementName('FlateDecode')],
        'FlateDecode',
      ],
      'ASCIIHex then Flate' => [
        [new ElementName('ASCIIHexDecode'), new ElementName('FlateDecode')],
        'FlateDecode',
      ],
      'ASCII85 then DCT' => [
        [new ElementName('ASCII85Decode'), new ElementName('DCTDecode')],
        'DCTDecode',
      ],
      'Flate then DCT' => [
        [new ElementName('FlateDecode'), new ElementName('DCTDecode')],
        'DCTDecode',
      ],
      'ASCII85 then JPX' => [
        [new ElementName('ASCII85Decode'), new ElementName('JPXDecode')],
        'JPXDecode',
      ],
      'only a decodable filter that is not Flate' => [
        [new ElementName('LZWDecode')],
        'FlateDecode',
      ],
      'plain strings in an array' => [['ASCII85Decode', 'DCTDecode'], 'DCTDecode'],
      'empty array' => [[], 'FlateDecode'],
      'no filter at all' => [NULL, 'FlateDecode'],
      'missing element content' => [FALSE, 'FlateDecode'],
    ];
  }

  /**
   * Tests that the first filter the parser cannot decode is kept.
   *
   * @dataProvider filterProvider
   * @covers ::resolve
   */
  public function testResolve(mixed $filter, string $expected): void {
    $this->assertSame($expected, ImageFilterResolver::resolve($filter));
  }

}
