<?php

namespace Drupal\localgov_step_by_step;

/**
 * Helper class for module install functions.
 */
class InstallHelper {

  /**
   * Set form settings for optional services and topic fields on installation.
   *
   * @param bool $services
   *   If localgov_services is (being) installed.
   * @param bool $topics
   *   If localgov_topics is (being) installed.
   */
  public static function optionalFieldsSettings($services, $topics): void {
    $properties = [
      'targetEntityType' => 'node',
      'bundle' => 'localgov_step_by_step_overview',
    ];
    if ($form_displays = \Drupal::entityTypeManager()->getStorage('entity_form_display')->loadByProperties($properties)) {
      foreach ($form_displays as $form_display) {
        assert($form_display instanceof EntityFormDisplayInterface);
        if ($services && !$form_display->getComponent('localgov_services_parent')) {
          $form_display->setComponent('localgov_services_parent', [
            'type' => 'entity_reference_autocomplete',
            'region' => 'content',
            'settings' => [
              'match_operator' => 'CONTAINS',
              'size' => '60',
              'placeholder' => '',
              'match_limit' => 10,
            ],
            'weight' => -1,
          ])->save();
        }
        if ($topics && !$form_display->getComponent('localgov_topic_classified')) {
          $form_display->setComponent('localgov_topic_classified', [
            'type' => 'entity_reference_autocomplete',
            'region' => 'content',
            'settings' => [
              'match_operator' => 'CONTAINS',
              'size' => '60',
              'placeholder' => '',
              'match_limit' => 10,
            ],
            'weight' => 50,
          ])->save();
        }
      }
    }
  }

}
