<?php

namespace Drupal\localgov_step_by_step\Hook;

use Drupal\Core\Extension\ModuleHandlerInterface;
use Drupal\Core\Hook\Attribute\Hook;
use Drupal\localgov_roles\RolesHelper;

/**
 * Localgov_roles Hook implementations for localgov_step_by_step.
 */
class LocalgovRolesHooks {

  /**
   * Constructs a new LocalgovRolesHooks.
   *
   * @param Drupal\Core\Extension\ModuleHandlerInterface $moduleHandler
   *   Module handler service.
   */
  public function __construct(
    private readonly ModuleHandlerInterface $moduleHandler,
  ) {}

  /**
   * Implements hook_localgov_roles_default().
   */
  #[Hook('localgov_roles_default')]
  public function localgovRolesDefault() {
    // Content editing permissions.
    $perms = [
      RolesHelper::EDITOR_ROLE => [
        'create localgov_step_by_step_overview content',
        'create localgov_step_by_step_page content',
        'delete any localgov_step_by_step_overview content',
        'delete any localgov_step_by_step_page content',
        'delete localgov_step_by_step_overview revisions',
        'delete localgov_step_by_step_page revisions',
        'delete own localgov_step_by_step_overview content',
        'delete own localgov_step_by_step_page content',
        'edit any localgov_step_by_step_overview content',
        'edit any localgov_step_by_step_page content',
        'edit own localgov_step_by_step_overview content',
        'edit own localgov_step_by_step_page content',
        'revert localgov_step_by_step_overview revisions',
        'revert localgov_step_by_step_page revisions',
        'view localgov_step_by_step_overview revisions',
        'view localgov_step_by_step_page revisions',
      ],
      RolesHelper::AUTHOR_ROLE => [
        'create localgov_step_by_step_overview content',
        'create localgov_step_by_step_page content',
        'delete own localgov_step_by_step_overview content',
        'delete own localgov_step_by_step_page content',
        'edit own localgov_step_by_step_overview content',
        'edit own localgov_step_by_step_page content',
        'revert localgov_step_by_step_overview revisions',
        'revert localgov_step_by_step_page revisions',
        'view localgov_step_by_step_overview revisions',
        'view localgov_step_by_step_page revisions',
      ],
      RolesHelper::CONTRIBUTOR_ROLE => [
        'create localgov_step_by_step_overview content',
        'create localgov_step_by_step_page content',
        'delete own localgov_step_by_step_overview content',
        'delete own localgov_step_by_step_page content',
        'edit own localgov_step_by_step_overview content',
        'edit own localgov_step_by_step_page content',
        'view localgov_step_by_step_overview revisions',
        'view localgov_step_by_step_page revisions',
      ],
    ];
    // Content scheduling permissions required by localgov_workflows.
    if ($this->moduleHandler->moduleExists('localgov_workflows')) {
      $perms[RolesHelper::EDITOR_ROLE] = array_merge($perms[RolesHelper::EDITOR_ROLE], [
        'add scheduled transitions node localgov_step_by_step_overview',
        'add scheduled transitions node localgov_step_by_step_page',
        'reschedule scheduled transitions node localgov_step_by_step_overview',
        'reschedule scheduled transitions node localgov_step_by_step_page',
        'view scheduled transitions node localgov_step_by_step_overview',
        'view scheduled transitions node localgov_step_by_step_page',
      ]);
      $perms[RolesHelper::AUTHOR_ROLE] = array_merge($perms[RolesHelper::AUTHOR_ROLE], [
        'add scheduled transitions node localgov_step_by_step_overview',
        'add scheduled transitions node localgov_step_by_step_page',
        'reschedule scheduled transitions node localgov_step_by_step_overview',
        'reschedule scheduled transitions node localgov_step_by_step_page',
        'view scheduled transitions node localgov_step_by_step_overview',
        'view scheduled transitions node localgov_step_by_step_page',
      ]);
      $perms[RolesHelper::CONTRIBUTOR_ROLE] = array_merge($perms[RolesHelper::CONTRIBUTOR_ROLE], [
        'add scheduled transitions node localgov_step_by_step_overview',
        'add scheduled transitions node localgov_step_by_step_page',
        'reschedule scheduled transitions node localgov_step_by_step_overview',
        'reschedule scheduled transitions node localgov_step_by_step_page',
        'view scheduled transitions node localgov_step_by_step_overview',
        'view scheduled transitions node localgov_step_by_step_page',
      ]);
    }
    return $perms;
  }

}
