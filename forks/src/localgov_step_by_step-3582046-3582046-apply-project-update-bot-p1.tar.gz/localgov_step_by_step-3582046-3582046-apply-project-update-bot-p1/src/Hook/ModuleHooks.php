<?php

namespace Drupal\localgov_step_by_step\Hook;

use Drupal\Core\Config\ConfigInstallerInterface;
use Drupal\Core\Hook\Attribute\Hook;
use Drupal\localgov_step_by_step\InstallHelper;

/**
 * Module.api Hook implementations for localgov_step_by_step.
 */
class ModuleHooks {

  /**
   * Constructs a new ModuleHooks.
   *
   * @param Drupal\Core\Config\ConfigInstallerInterface $configInstaller
   *   Configuration installer service.
   */
  public function __construct(
    private readonly ConfigInstallerInterface $configInstaller,
  ) {}

  /**
   * Implements hook_modules_installed().
   */
  #[Hook('modules_installed')]
  public function modulesInstalled($modules) {
    $services = in_array('localgov_services_navigation', $modules, TRUE);
    $topics = in_array('localgov_topics', $modules, TRUE);
    if ($services) {
      $this->configInstaller->installOptionalConfig(NULL, [
        'config' => 'field.storage.node.localgov_services_parent',
      ]);
    }
    if ($topics) {
      $this->configInstaller->installOptionalConfig(NULL, [
        'config' => 'field.storage.node.localgov_topic_classified',
      ]);
    }
    if ($services || $topics) {
      InstallHelper::optionalFieldsSettings($services, $topics);
    }
  }

}
