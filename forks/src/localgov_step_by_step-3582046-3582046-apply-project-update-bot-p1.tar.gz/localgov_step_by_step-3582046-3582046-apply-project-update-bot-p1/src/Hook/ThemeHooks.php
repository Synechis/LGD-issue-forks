<?php

namespace Drupal\localgov_step_by_step\Hook;

use Drupal\Core\Entity\EntityTypeManagerInterface;
use Drupal\Core\Hook\Attribute\Hook;
use Drupal\Core\StringTranslation\StringTranslationTrait;

/**
 * Theme Hook implementations for localgov_step_by_step.
 */
class ThemeHooks {

  use StringTranslationTrait;

  /**
   * Constructs a new ThemeHooks.
   *
   * @param Drupal\Core\Entity\EntityTypeManagerInterface $entityTypeManger
   *   Entity type manager interface.
   */
  public function __construct(
    private readonly EntityTypeManagerInterface $entityTypeManger,
  ) {}

  /**
   * Implements hook_theme().
   *
   * Provides the following themes:
   * - Step by step navigation view's Prev/Next block.
   */
  #[Hook('theme')]
  public function theme() {
    return [
      'step_by_step_part_of_block' => [
        'variables' => [
          'label' => NULL,
          'url' => NULL,
        ],
        'render element' => 'children',
      ],
      'views_view_list__localgov_step_by_step_navigation__prev_next' => [
        'base hook' => 'views_view_list',
      ],
    ];
  }

  /**
   * Implements hook_preprocess_views_view_list().
   *
   * Marks the rows corresponding to the current, previous, and next nodes.
   */
  #[Hook('preprocess_views_view_list')]
  public function preprocessViewsViewList(array &$variables) {
    $view = $variables['view'];
    $view_id = $view->id();
    $view_display_id = $view->current_display;
    $is_step_by_step_nav = $view_id === 'localgov_step_by_step_navigation';
    $is_step_by_step_nav_block = $view_display_id === 'steps';
    $is_step_by_step_prev_next_block = $view_display_id === 'prev_next';
    $current_nid = $is_step_by_step_nav ? $view->args[0] : '';
    if ($is_step_by_step_nav && $is_step_by_step_prev_next_block) {
      $this->findPrevNextSteps($current_nid, $variables);
    }
    elseif ($is_step_by_step_nav && $is_step_by_step_nav_block) {
      $this->markCurrentStep($current_nid, $variables);
    }
    if ($is_step_by_step_nav) {
      $variables['view']->element['#attached']['library'][] = 'localgov_step_by_step/step-by-step-nav';
    }
  }

  /**
   * Find previous and next steps.
   *
   * Find the previous and next Step by step page nodes relative to the current
   * node.  The current node is the one where we are displaying this block.  Its
   * node ID is treated as the first contextual argument of our View.
   */
  private function findPrevNextSteps(string $current_nid, array &$variables): void {

    $prev_step_index = -1;
    $next_step_index = -1;

    foreach ($variables['rows'] as $key => $row) {
      $row_nid = $row['content']['#row']->node_field_data_node__localgov_step_by_step_pages_1_nid ?? '-1';
      $is_current_step = ($row_nid === $current_nid);

      if ($is_current_step) {
        $prev_step_index = $key - 1;
        $next_step_index = $key + 1;

        break;
      }
    }

    $variables['has_prev_step'] = array_key_exists($prev_step_index, $variables['rows']);
    $variables['has_next_step'] = array_key_exists($next_step_index, $variables['rows']);
    $variables['prev_step_nid'] = $variables['rows'][$prev_step_index]['content']['#row']->node_field_data_node__localgov_step_by_step_pages_1_nid ?? -1;
    $variables['next_step_nid'] = $variables['rows'][$next_step_index]['content']['#row']->node_field_data_node__localgov_step_by_step_pages_1_nid ?? -1;
    $variables['prev_step_link_text'] = $this->t('Previous Step');
    $variables['prev_step_index'] = $prev_step_index;
    $variables['next_step_index'] = $next_step_index;

    $is_first_step = ($next_step_index === 1);
    $variables['next_step_link_text'] = $is_first_step ? $this->t('Next Step') : $this->t('Next Step');

    $node_storage = $this->entityTypeManger->getStorage('node');
    if ($variables['has_next_step']) {
      $variables['next_step_title'] = $node_storage->load($variables['next_step_nid'])->title->value;
    }
    if ($variables['has_prev_step']) {
      $variables['prev_step_title'] = $node_storage->load($variables['prev_step_nid'])->title->value;
    }
  }

  /**
   * Mark the row corresponding to the current Step by step page node.
   */
  private function markCurrentStep(string $current_nid, array &$variables): void {

    foreach ($variables['rows'] as &$row) {
      $row_nid = $row['content']['#row']->node_field_data_node__localgov_step_by_step_pages_1_nid ?? '-1';

      $is_current_step = ($row_nid === $current_nid);
      if ($is_current_step) {
        $row['attributes']['class'][] = 'step--active';
        $row['attributes']['aria-current'] = 'step';
        break;
      }
    }
  }

}
