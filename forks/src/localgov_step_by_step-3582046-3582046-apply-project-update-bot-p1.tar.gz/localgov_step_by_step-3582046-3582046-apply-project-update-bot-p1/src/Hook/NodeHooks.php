<?php

namespace Drupal\localgov_step_by_step\Hook;

use Drupal\Core\Entity\EntityInterface;
use Drupal\Core\Hook\Attribute\Hook;
use Drupal\Core\Logger\LoggerChannelFactoryInterface;

/**
 * Entity node Hook implementations for localgov_step_by_step.
 */
class NodeHooks {

  /**
   * Constructs a new Node Hooks.
   *
   * @param Drupal\Core\Logger\LoggerChannelFactoryInterface $logger
   *   Logger factory service.
   */
  public function __construct(
    private readonly LoggerChannelFactoryInterface $logger,
  ) {}

  /**
   * Implements hook_ENTITY_TYPE_insert().
   *
   * Implements hook_ENTITY_TYPE_update().
   *
   * The step_by_step_overview and step_by_step_page content types reference
   * each other.  When a step_by_step_page type node is updated, find its
   * step_by_step_overview node. Then make sure this step_by_step_overview node
   * refers back to the step_by_step_page node.
   */
  #[Hook('node_insert')]
  #[Hook('node_update')]
  public function nodeUpdate(EntityInterface $entity) {
    $is_not_step_by_step_page_node = $entity->bundle() !== 'localgov_step_by_step_page';
    if ($is_not_step_by_step_page_node) {
      return;
    }
    $step_by_step_page_node = $entity;
    $step_by_step_page_nid = $step_by_step_page_node->id();
    $step_by_step_overview_node = $step_by_step_page_node->localgov_step_parent->entity ?? FALSE;
    if (empty($step_by_step_overview_node)) {
      return;
    }
    try {
      $has_ref_to_this_step_by_step_page = array_filter($step_by_step_overview_node->localgov_step_by_step_pages->referencedEntities(), function (EntityInterface $page_node) use ($step_by_step_page_nid): bool {
          return $page_node->id() === $step_by_step_page_nid;
      });
      if ($has_ref_to_this_step_by_step_page) {
        return;
      }
      $step_by_step_overview_node->localgov_step_by_step_pages->appendItem($step_by_step_page_nid);
      $step_by_step_overview_node->save();
    }
    catch (\Exception $e) {
      $this->logger->get('localgov-step-by-step')->error($e->getMessage());
    }
  }

}
