<?php

namespace Drupal\localgov_search\Hook;

use Drupal\views\ViewExecutable;
use Drupal\search_api\Entity\Index;
use Drupal\views\Entity\View;
use Drupal\Core\Routing\RouteMatchInterface;
use Drupal\Core\Hook\Attribute\Hook;
use Drupal\Core\StringTranslation\StringTranslationTrait;

/**
 * Hook implementations for localgov_search.
 */
class LocalgovSearchHooks {
  use StringTranslationTrait;

  /**
   * Implements hook_help().
   */
  #[Hook('help')]
  public function help($route_name, RouteMatchInterface $route_match) {
    switch ($route_name) {
      // Main module help for the localgov_search module.
      case 'help.page.localgov_search':
        $output = '';
        $output .= '<h3>' . $this->t('About') . '</h3>';
        $output .= '<p>' . $this->t('Sitewide search for LocalGov Drupal') . '</p>';
        return $output;

      default:
    }
  }

  /**
   * Implements hook_entity_bundle_create().
   */
  #[Hook('entity_bundle_create')]
  public static function entityBundleCreate($entity_type_id, $bundle) {
    if ($entity_type_id == 'node') {
      // Add bundle's search result view mode to sitewide_search view.
      if (($view = View::load('localgov_sitewide_search')) && $display = $view->get('display')) {
        if (isset($display['default']['display_options']['row'])) {
          $display['default']['display_options']['row']['options']['view_modes']['entity:node'][$bundle] = 'search_result';
          $view->set('display', $display);
          $view->save();
        }
      }
      // Add bundle's search index view mode to sitewide search index.
      if (($index = Index::load('localgov_sitewide_search')) && $index_field = $index->getField('rendered_item')) {
        $field_config = $index_field->getConfiguration();
        if (!isset($field_config['view_mode']['entity:node'][$bundle])) {
          $field_config['view_mode']['entity:node'][$bundle] = 'search_index';
          $index_field->setConfiguration($field_config);
          $index->save();
        }
      }
    }
  }

  /**
   * Implements hook_views_pre_render().
   */
  #[Hook('views_pre_render')]
  public static function viewsPreRender(ViewExecutable $view) {
    if (isset($view->element['#name']) && $view->element['#name'] == 'localgov_sitewide_search' && isset($view->element['#display_id']) && $view->element['#display_id'] == 'sitewide_search_page') {
      // Hide search results if no search has been made.
      if (\Drupal::request()->query->get('s') === NULL) {
        $view->header = [];
        $view->empty = [];
      }
      elseif (isset($view->exposed_data['s']) && (int) $view->total_rows > 0) {
        $title = $view->exposed_data['s'] . ' - ' . $view->getTitle();
        $view->setTitle($title);
      }
    }
  }

  /**
   * Implements hook_preprocess_HOOK() for form hook.
   */
  #[Hook('preprocess_form')]
  public static function preprocessForm(&$variables) {
    // Add aria role to sitewide search form.
    if (isset($variables['element']['#id']) && $variables['element']['#id'] == 'views-exposed-form-localgov-sitewide-search-sitewide-search-page') {
      $variables['attributes']['role'] = 'search';
      $variables['attributes']['aria-label'] = 'Sitewide';
    }
  }

}
