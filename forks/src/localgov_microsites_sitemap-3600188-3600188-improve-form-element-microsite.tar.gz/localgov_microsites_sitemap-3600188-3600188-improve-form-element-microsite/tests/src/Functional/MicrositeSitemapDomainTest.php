<?php

declare(strict_types=1);

namespace Drupal\Tests\localgov_microsites_sitemap\Functional;

use Drupal\Core\Entity\EntityInterface;
use Drupal\Tests\BrowserTestBase;
use Drupal\Tests\localgov_microsites_group\Traits\GroupCreationTrait;
use Drupal\Tests\localgov_microsites_group\Traits\InitializeGroupsTrait;
use Drupal\domain\DomainInterface;
use Drupal\group\Entity\GroupType;
use Drupal\group\Entity\Storage\GroupRelationshipTypeStorageInterface;
use Drupal\localgov_microsites_group\DomainFromGroupTrait;
use Drupal\simple_sitemap\Queue\QueueWorker;

/**
 * Tests that each microsite domain serves a sitemap.xml of its own content.
 *
 * @group localgov_microsites_sitemap
 */
class MicrositeSitemapDomainTest extends BrowserTestBase {

  use InitializeGroupsTrait;
  use GroupCreationTrait, DomainFromGroupTrait {
    GroupCreationTrait::getEntityTypeManager insteadof DomainFromGroupTrait;
  }

  /**
   * {@inheritdoc}
   */
  protected static $modules = [
    'localgov_core',
    'localgov_media',
  ];

  /**
   * {@inheritdoc}
   *
   * Prevent check for config schema raising errors.
   */
  protected static $configSchemaCheckerExclusions = [
    'pathauto.pattern.localgov_page',
    'core.entity_form_display.paragraph.localgov_image.default',
    'core.entity_form_display.paragraph.localgov_featured_campaign.default',
    'core.entity_form_display.paragraph.localgov_newsroom_teaser.default',
    'core.entity_form_display.paragraph.localgov_banner_primary.default',
    'core.entity_form_display.paragraph.localgov_banner_secondary.default',
    'core.entity_form_display.paragraph.localgov_box_link.default',
    'core.entity_form_display.paragraph.localgov_call_out_box.default',
    'core.entity_form_display.paragraph.localgov_featured_subsite.default',
    'core.entity_form_display.paragraph.localgov_featured_teaser.default',
    'core.entity_form_display.paragraph.localgov_key_contact_item.default',
    'core.entity_form_display.paragraph.localgov_media_with_text.default',
  ];

  /**
   * {@inheritdoc}
   */
  protected $defaultTheme = 'stark';

  /**
   * {@inheritdoc}
   */
  protected function setUp(): void {
    parent::setUp();

    $this->container->get('module_installer')->install([
      'localgov_microsites_group',
      'simple_sitemap',
    ]);
    $this->rebuildContainer();

    // A content type the microsite group type can hold.
    $this->drupalCreateContentType([
      'type' => 'test_page',
      'name' => 'Test page',
    ]);

    $group_type = $this->getEntityTypeManager()->getStorage('group_type')->load('microsite');
    assert($group_type instanceof GroupType);
    $storage = $this->getEntityTypeManager()->getStorage('group_relationship_type');
    assert($storage instanceof GroupRelationshipTypeStorageInterface);
    $storage->save($storage->createFromPlugin($group_type, 'group_node:test_page'));
  }

  /**
   * Each microsite's sitemap.xml lists its own content and no one else's.
   */
  public function testEachMicrositeServesItsOwnSitemap(): void {
    // The microsites exist before the module is installed, so their sitemaps
    // have to be set up by the module install.
    $this->createMicrositeGroups([], 2);
    $this->createMicrositeGroupsDomains($this->groups);
    [1 => $group1, 2 => $group2] = $this->groups;

    $this->container->get('module_installer')->install(['localgov_microsites_sitemap']);
    $this->rebuildContainer();

    $node1 = $this->drupalCreateNode(['type' => 'test_page']);
    $group1->addRelationship($node1, 'group_node:test_page');
    $node2 = $this->drupalCreateNode(['type' => 'test_page']);
    $group2->addRelationship($node2, 'group_node:test_page');

    $this->container->get('simple_sitemap.generator')
      ->setSitemaps(['lgd_ms_' . $group1->id(), 'lgd_ms_' . $group2->id()])
      ->rebuildQueue()
      ->generate(QueueWorker::GENERATE_TYPE_BACKEND);

    $domain1 = $this->getDomainFromGroup($group1);
    $domain2 = $this->getDomainFromGroup($group2);
    $this->assertInstanceOf(DomainInterface::class, $domain1);
    $this->assertInstanceOf(DomainInterface::class, $domain2);

    $locations = $this->getSitemapLocations($domain1);
    $this->assertContains($this->micrositeUrl($node1, $domain1), $locations);
    $this->assertNotContains($this->micrositeUrl($node2, $domain2), $locations);
    $this->assertNotContains($this->micrositeUrl($node2, $domain1), $locations);

    $locations = $this->getSitemapLocations($domain2);
    $this->assertContains($this->micrositeUrl($node2, $domain2), $locations);
    $this->assertNotContains($this->micrositeUrl($node1, $domain1), $locations);
    $this->assertNotContains($this->micrositeUrl($node1, $domain2), $locations);
  }

  /**
   * Requests sitemap.xml on a domain and returns the <loc> of every URL.
   *
   * @param \Drupal\domain\DomainInterface $domain
   *   The microsite domain.
   *
   * @return string[]
   *   The sitemap URLs.
   */
  protected function getSitemapLocations(DomainInterface $domain): array {
    $this->drupalGet($domain->getPath() . 'sitemap.xml');
    $this->assertSession()->statusCodeEquals(200);

    $locations = [];
    foreach (simplexml_load_string($this->getSession()->getPage()->getContent())->url as $url) {
      $locations[] = (string) $url->loc;
    }
    return $locations;
  }

  /**
   * Returns the canonical URL of an entity on a microsite domain.
   *
   * @param \Drupal\Core\Entity\EntityInterface $entity
   *   The entity.
   * @param \Drupal\domain\DomainInterface $domain
   *   The microsite domain.
   *
   * @return string
   *   The absolute URL on the microsite domain.
   */
  protected function micrositeUrl(EntityInterface $entity, DomainInterface $domain): string {
    return str_replace(
      rtrim($GLOBALS['base_url'], '/'),
      rtrim($domain->getPath(), '/'),
      $entity->toUrl('canonical', ['absolute' => TRUE])->toString()
    );
  }

}
