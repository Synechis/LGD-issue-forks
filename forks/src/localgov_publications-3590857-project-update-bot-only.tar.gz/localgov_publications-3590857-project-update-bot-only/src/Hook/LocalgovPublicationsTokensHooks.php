<?php

namespace Drupal\localgov_publications\Hook;

use Drupal\localgov_publications\Token\Hooks;
use Drupal\Core\Render\BubbleableMetadata;
use Drupal\Core\Hook\Attribute\Hook;

/**
 * Hook implementations for localgov_publications.
 */
class LocalgovPublicationsTokensHooks {

  /**
   * Implements hook_tokens_alter().
   */
  #[Hook('tokens_alter')]
  public function tokensAlter(array &$replacements, array $context, BubbleableMetadata $bubbleable_metadata) {
    \Drupal::service('class_resolver')->getInstanceFromDefinition(Hooks::class)->tokensAlter($replacements, $context, $bubbleable_metadata);
  }

}
