<?php

namespace Drupal\localgov_publications\Hook;

use Drupal\Core\Entity\EntityInterface;
use Drupal\Core\Config\Entity\ConfigDependencyManager;
use Drupal\Core\Config\StorageInterface;
use Drupal\Core\Config\FileStorage;
use Drupal\Core\Config\InstallStorage;
use Drupal\Core\Url;
use Drupal\Core\Form\FormStateInterface;
use Drupal\Core\Access\AccessResult;
use Drupal\node\NodeInterface;
use Drupal\Core\Session\AccountInterface;
use Drupal\block\Entity\Block;
use Drupal\Core\Hook\Attribute\Hook;
use Drupal\Core\StringTranslation\StringTranslationTrait;

/**
 * Hook implementations for localgov_publications.
 */
class LocalgovPublicationsHooks {
  use StringTranslationTrait;

  /**
   * Implements hook_theme().
   */
  #[Hook('theme')]
  public function theme($existing, $type, $theme, $path): array {
    return [
      'book_navigation__publication' => [
        'template' => 'book-navigation--publication',
        'base hook' => 'book_navigation__publication',
      ],
      'localgov_publication_page_header_block' => [
        'variables' => [
          'title' => '',
          'node_title' => '',
          'published_date' => NULL,
          'last_updated_date' => NULL,
        ],
      ],
      'paragraph__localgov_publications_banner' => [
        'template' => 'paragraph--localgov-publications-banner',
        'base hook' => 'paragraph',
      ],
      'media__document__publication' => [
        'template' => 'media--document--publication',
        'base hook' => 'media',
      ],
      'field__localgov_publication' => [
        'template' => 'publication-html-reference',
        'base hook' => 'field',
      ],
    ];
  }

  /**
   * Implements hook_theme_suggestions_HOOK().
   */
  #[Hook('theme_suggestions_book_navigation')]
  public function themeSuggestionsBookNavigation(array $variables): array {
    $suggestions = [];
    // Only add suggestion on publication pages and publication cover pages.
    $node = \Drupal::routeMatch()->getParameter('node');
    if (localgov_publications_is_publication_type($node->getType())) {
      $suggestions[] = $variables['theme_hook_original'] . '__publication';
    }
    return $suggestions;
  }

  /**
   * Implements hook_block_access().
   */
  #[Hook('block_access')]
  public function blockAccess(Block $block, $operation, AccountInterface $account) {
    if ($block->getPluginId() == 'localgov_page_header_block' && $operation == 'view') {
      $node = \Drupal::routeMatch()->getParameter('node');
      if ($node instanceof NodeInterface && localgov_publications_is_publication_type($node->getType())) {
        return AccessResult::forbiddenIf(TRUE)->addCacheableDependency($block);
      }
    }
  }

  /**
   * Implements hook_form_FORM_ID_alter() for book_admin_edit.
   */
  #[Hook('form_book_admin_edit_alter')]
  public function formBookAdminEditAlter(&$form, FormStateInterface $form_state, $form_id): void {
    // If we're on the route this module uses for this form, change some wording.
    $route_name = \Drupal::routeMatch()->getRouteName();
    if ($route_name === 'publication.admin_edit') {
      $form['save']['#value'] = $this->t('Save publication pages');
    }
  }

  /**
   * Implements hook_form_BASE_ID_alter().
   */
  #[Hook('form_node_form_alter')]
  public function formNodeFormAlter(&$form, FormStateInterface $form_state, $form_id): void {
    _localgov_publications_node_form_alter($form, $form_state, $form_id);
  }

  /**
   * Implements hook_form_BASE_ID_alter().
   */
  #[Hook('form_node_edit_form_alter')]
  public function formNodeEditFormAlter(&$form, FormStateInterface $form_state, $form_id): void {
    _localgov_publications_node_form_alter($form, $form_state, $form_id);
  }

  /**
   * Implements hook_node_links_alter().
   *
   * If book module has added the "Add child page" link, and we're on a
   * publication type page, alter the link, so it creates a
   * localgov_publication_page, instead of the default book type.
   */
  #[Hook('node_links_alter')]
  public function nodeLinksAlter(array &$links, NodeInterface $node, array &$context): void {
    if (localgov_publications_is_publication_type($node->getType()) && isset($links['book']['#links']['book_add_child'])) {
      $links['book']['#links']['book_add_child']['url'] = Url::fromRoute('node.add', [
        'node_type' => 'localgov_publication_page',
      ], [
        'query' => [
          'parent' => $node->id(),
        ],
      ]);
    }
  }

  /**
   * Implements hook_preprocess_node().
   */
  #[Hook('preprocess_node')]
  public function preprocessNode(&$variables): void {
    $view_mode = $variables['elements']['#view_mode'];
    /** @var \Drupal\node\NodeInterface $node */
    $node = $variables['elements']['#node'];
    if ($view_mode === 'full' && localgov_publications_is_publication_type($node->getType())) {
      $variables['content']['#attached']['library'][] = 'localgov_publications/localgov-publications';
    }
  }

  /**
   * Implements hook_modules_installed().
   */
  #[Hook('modules_installed')]
  public function modulesInstalled($modules, $is_syncing) {
    if (!$is_syncing && in_array('book', $modules, TRUE)) {
      // If book module is being installed, prevent the 'book' node type and its
      // dependencies from being installed from its config (or rather, delete it
      // -- there's no way to intercept it within the config API).
      $extension_path = \Drupal::service('extension.path.resolver')->getPath('module', 'book');
      $optional_install_path = $extension_path . '/' . InstallStorage::CONFIG_OPTIONAL_DIRECTORY;
      // Get all of book module's optional config.
      $storage = new FileStorage($optional_install_path, StorageInterface::DEFAULT_COLLECTION);
      $list = $storage->listAll();
      $config_to_create = $storage->readMultiple($list);
      // Filter this to those config entities that depend on the 'book' node type.
      $dependency_manager = new ConfigDependencyManager();
      $dependency_manager->setData($config_to_create);
      $dependencies = $dependency_manager->getDependentEntities('config', 'node.type.book');
      foreach (array_keys($dependencies) as $config_name) {
        \Drupal::configFactory()->getEditable($config_name)->delete();
      }
      \Drupal::configFactory()->getEditable('node.type.book')->delete();
      // The mapping of fields to bundles is stored in the key-value store. As we
      // removed the content type and its fields on a config level, we also need
      // to clear out the book data from here, as it won't be done for us like it
      // is when you delete a content type via the UI.
      $kvStore = \Drupal::keyValue('entity.definitions.bundle_field_map');
      $fieldMap = $kvStore->get('node');
      unset($fieldMap['body']['bundles']['book']);
      $kvStore->set('node', $fieldMap);
      // Clear all caches to ensure there are no references to the Book node left.
      drupal_flush_all_caches();
    }
  }

  /**
   * Implements hook_entity_insert().
   *
   * NB that we don't implement hook_node_insert to ensure we run after pathauto.
   */
  #[Hook('entity_insert')]
  public function entityInsert(EntityInterface $entity): void {
    if ($entity instanceof NodeInterface) {
      localgov_publications_update_path_aliases($entity);
    }
  }

  /**
   * Implements hook_entity_update().
   *
   * NB that we don't implement hook_node_update to ensure we run after pathauto.
   */
  #[Hook('entity_update')]
  public function entityUpdate(EntityInterface $entity): void {
    if ($entity instanceof NodeInterface) {
      localgov_publications_update_path_aliases($entity);
    }
  }

}
