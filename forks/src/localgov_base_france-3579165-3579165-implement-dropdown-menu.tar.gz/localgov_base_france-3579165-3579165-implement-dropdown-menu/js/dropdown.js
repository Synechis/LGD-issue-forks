/**
 * @file
 * DSFR dropdown navigation behaviour.
 *
 * Handles toggle, accordion, click-outside, and keyboard (Escape) for the
 * lgd-dropdown dropdown menus rendered by menu--main.html.twig.
 */

(function (Drupal, once) {
  'use strict';

  /**
   * Open a dropdown panel.
   *
   * @param {HTMLButtonElement} btn  The toggle button.
   * @param {HTMLElement} panel      The collapsible panel element.
   */
  function openDropdown(btn, panel) {
    btn.setAttribute('aria-expanded', 'true');
    panel.classList.add('lgd-dropdown__collapsible--expanded');
  }

  /**
   * Close a dropdown panel.
   *
   * @param {HTMLButtonElement} btn  The toggle button.
   * @param {HTMLElement} panel      The collapsible panel element.
   */
  function closeDropdown(btn, panel) {
    btn.setAttribute('aria-expanded', 'false');
    panel.classList.remove('lgd-dropdown__collapsible--expanded');
  }

  /**
   * Close all open dropdowns within a nav element.
   *
   * @param {HTMLElement} nav       The lgd-dropdown container.
   * @param {HTMLElement} [except]  Button to skip (keep open).
   */
  function closeAll(nav, except) {
    nav.querySelectorAll('.lgd-dropdown__btn[aria-expanded="true"]').forEach(function (openBtn) {
      if (openBtn === except) {
        return;
      }
      var panelId = openBtn.getAttribute('aria-controls');
      var panel = nav.querySelector('#' + panelId);
      if (panel) {
        closeDropdown(openBtn, panel);
      }
    });
  }

  Drupal.behaviors.dropdownNav = {
    attach: function (context) {
      once('dropdown-nav-btn', '.lgd-dropdown .lgd-dropdown__btn', context).forEach(function (btn) {
        var nav = btn.closest('.lgd-dropdown');
        var panelId = btn.getAttribute('aria-controls');
        var panel = document.getElementById(panelId);

        if (!panel || !nav) {
          return;
        }

        // Toggle on click (accordion: close siblings first).
        btn.addEventListener('click', function () {
          var isExpanded = btn.getAttribute('aria-expanded') === 'true';

          // Close all other dropdowns in this nav first.
          closeAll(nav, btn);

          if (isExpanded) {
            closeDropdown(btn, panel);
          }
          else {
            openDropdown(btn, panel);
          }
        });

        // Close on Escape key; return focus to the button that opened the panel.
        document.addEventListener('keydown', function (e) {
          if (e.key === 'Escape' && btn.getAttribute('aria-expanded') === 'true') {
            closeDropdown(btn, panel);
            btn.focus();
          }
        });
      });

      // Close all dropdowns when clicking outside any lgd-dropdown.
      once('dropdown-nav-outside', 'body', context).forEach(function (body) {
        body.addEventListener('click', function (e) {
          document.querySelectorAll('.lgd-dropdown').forEach(function (nav) {
            if (!nav.contains(e.target)) {
              nav.querySelectorAll('.lgd-dropdown__btn[aria-expanded="true"]').forEach(function (openBtn) {
                var panelId = openBtn.getAttribute('aria-controls');
                var panel = nav.querySelector('#' + panelId);
                if (panel) {
                  closeDropdown(openBtn, panel);
                }
              });
            }
          });
        });
      });
    },
  };

})(Drupal, once);
