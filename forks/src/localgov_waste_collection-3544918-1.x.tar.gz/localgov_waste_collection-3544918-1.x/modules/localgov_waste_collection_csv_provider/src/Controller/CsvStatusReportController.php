<?php

namespace Drupal\localgov_waste_collection_csv_provider\Controller;

use Drupal\Core\Controller\ControllerBase;
use Drupal\Core\Database\Connection;
use Symfony\Component\DependencyInjection\ContainerInterface;

/**
 * Controller for CSV import status report.
 */
class CsvStatusReportController extends ControllerBase {

  /**
   * The database connection.
   *
   * @var \Drupal\Core\Database\Connection
   */
  protected $database;

  /**
   * Constructs a CsvStatusReportController object.
   *
   * @param \Drupal\Core\Database\Connection $database
   *   The database connection.
   */
  public function __construct(Connection $database) {
    $this->database = $database;
  }

  /**
   * {@inheritdoc}
   */
  public static function create(ContainerInterface $container) {
    return new static(
      $container->get('database')
    );
  }

  /**
   * Builds the status report page.
   *
   * @return array
   *   A render array containing the status report.
   */
  public function content() {
    $build = [];

    // Get last import timestamp.
    $last_import = $this->getLastImportDate();
    $last_import_formatted = $last_import ?
      \Drupal::service('date.formatter')->format($last_import, 'medium') :
      $this->t('No imports yet');

    // Page header.
    $build['header'] = [
      '#type' => 'html_tag',
      '#tag' => 'p',
      '#value' => $this->t('This report shows statistics about the imported waste collection data.'),
    ];

    $build['last_import'] = [
      '#type' => 'html_tag',
      '#tag' => 'p',
      '#value' => $this->t('<strong>Last import:</strong> @date', ['@date' => $last_import_formatted]),
    ];

    // Core metrics table.
    $build['core_metrics'] = [
      '#type' => 'table',
      '#caption' => $this->t('Core Metrics'),
      '#header' => [
        $this->t('Metric'),
        $this->t('Value'),
        $this->t('Description'),
      ],
      '#rows' => [
        [
          $this->t('Total Properties'),
          $this->getPropertyCount(),
          $this->t('Number of unique UPRNs in the properties table'),
        ],
        [
          $this->t('Total Collection Records'),
          $this->getCollectionCount(),
          $this->t('Total number of collection schedule records'),
        ],
        [
          $this->t('Unique Collection Rounds'),
          $this->getUniqueRoundCount(),
          $this->t('Number of distinct collection rounds'),
        ],
        [
          $this->t('Property-Round Mappings'),
          $this->getMappedCollectionCount(),
          $this->t('Number of property-to-collection-round assignments'),
        ],
      ],
      '#attributes' => ['class' => ['system-status-report']],
    ];

    // Data quality metrics.
    $unmapped_collections = $this->getUnmappedCollectionsCount();
    $orphaned_properties = $this->getOrphanedPropertyMappingsCount();
    $orphaned_rounds = $this->getOrphanedRoundMappingsCount();

    $data_quality_rows = [
      [
        $this->t('Unmapped Collections'),
        $unmapped_collections,
        $this->t('Collection rounds with no property assignments'),
        $unmapped_collections > 0 ? ['class' => ['color-warning']] : [],
      ],
      [
        $this->t('Orphaned Property Mappings'),
        $orphaned_properties,
        $this->t('Mappings referencing non-existent UPRNs'),
        $orphaned_properties > 0 ? ['class' => ['color-error']] : [],
      ],
      [
        $this->t('Orphaned Round Mappings'),
        $orphaned_rounds,
        $this->t('Mappings referencing non-existent collection rounds'),
        $orphaned_rounds > 0 ? ['class' => ['color-error']] : [],
      ],
    ];

    $build['data_quality'] = [
      '#type' => 'table',
      '#caption' => $this->t('Data Quality Metrics'),
      '#header' => [
        $this->t('Metric'),
        $this->t('Value'),
        $this->t('Description'),
      ],
      '#rows' => [],
      '#attributes' => ['class' => ['system-status-report']],
    ];

    foreach ($data_quality_rows as $row) {
      $row_attributes = $row[3] ?? [];
      unset($row[3]);
      $build['data_quality']['#rows'][] = [
        'data' => $row,
        '#attributes' => $row_attributes,
      ];
    }

    // Collection breakdown by waste type.
    $collections_by_type = $this->getCollectionsByWasteType();
    if (!empty($collections_by_type)) {
      $build['waste_types'] = [
        '#type' => 'table',
        '#caption' => $this->t('Collections by Waste Type'),
        '#header' => [
          $this->t('Waste Type'),
          $this->t('Count'),
        ],
        '#rows' => $collections_by_type,
        '#attributes' => ['class' => ['system-status-report']],
      ];
    }

    // Link back to CSV upload form.
    $build['actions'] = [
      '#type' => 'html_tag',
      '#tag' => 'p',
      '#value' => $this->t('<a href="@url">Back to CSV Upload Form</a>', [
        '@url' => '/admin/config/services/waste_csv',
      ]),
    ];

    return $build;
  }

  /**
   * Gets the total count of properties.
   *
   * @return int
   *   The number of properties.
   */
  protected function getPropertyCount() {
    try {
      return (int) $this->database->select('localgov_waste_collection_properties', 'p')
        ->countQuery()
        ->execute()
        ->fetchField();
    }
    catch (\Exception $e) {
      return 0;
    }
  }

  /**
   * Gets the total count of collections.
   *
   * @return int
   *   The number of collection records.
   */
  protected function getCollectionCount() {
    try {
      return (int) $this->database->select('localgov_waste_collection_collections', 'c')
        ->countQuery()
        ->execute()
        ->fetchField();
    }
    catch (\Exception $e) {
      return 0;
    }
  }

  /**
   * Gets the total count of property-round mappings.
   *
   * @return int
   *   The number of mappings.
   */
  protected function getMappedCollectionCount() {
    try {
      return (int) $this->database->select('localgov_waste_collection_property_round', 'pr')
        ->countQuery()
        ->execute()
        ->fetchField();
    }
    catch (\Exception $e) {
      return 0;
    }
  }

  /**
   * Gets the count of unique collection rounds.
   *
   * @return int
   *   The number of unique collection rounds.
   */
  protected function getUniqueRoundCount() {
    try {
      return (int) $this->database->select('localgov_waste_collection_collections', 'c')
        ->fields('c', ['collection_round'])
        ->distinct()
        ->countQuery()
        ->execute()
        ->fetchField();
    }
    catch (\Exception $e) {
      return 0;
    }
  }

  /**
   * Gets the count of unmapped collections.
   *
   * Collections that exist but have no property assignments.
   *
   * @return int
   *   The number of unmapped collection rounds.
   */
  protected function getUnmappedCollectionsCount() {
    try {
      $subquery = $this->database->select('localgov_waste_collection_property_round', 'pr')
        ->fields('pr', ['collection_round'])
        ->distinct();

      return (int) $this->database->select('localgov_waste_collection_collections', 'c')
        ->fields('c', ['collection_round'])
        ->distinct()
        ->condition('c.collection_round', $subquery, 'NOT IN')
        ->countQuery()
        ->execute()
        ->fetchField();
    }
    catch (\Exception $e) {
      return 0;
    }
  }

  /**
   * Gets the count of orphaned property mappings.
   *
   * Mappings where the UPRN doesn't exist in the properties table.
   *
   * @return int
   *   The number of orphaned property mappings.
   */
  protected function getOrphanedPropertyMappingsCount() {
    try {
      $subquery = $this->database->select('localgov_waste_collection_properties', 'p')
        ->fields('p', ['uprn']);

      return (int) $this->database->select('localgov_waste_collection_property_round', 'pr')
        ->condition('pr.uprn', $subquery, 'NOT IN')
        ->countQuery()
        ->execute()
        ->fetchField();
    }
    catch (\Exception $e) {
      return 0;
    }
  }

  /**
   * Gets the count of orphaned round mappings.
   *
   * Mappings where the collection_round doesn't exist in collections table.
   *
   * @return int
   *   The number of orphaned round mappings.
   */
  protected function getOrphanedRoundMappingsCount() {
    try {
      $subquery = $this->database->select('localgov_waste_collection_collections', 'c')
        ->fields('c', ['collection_round'])
        ->distinct();

      return (int) $this->database->select('localgov_waste_collection_property_round', 'pr')
        ->condition('pr.collection_round', $subquery, 'NOT IN')
        ->countQuery()
        ->execute()
        ->fetchField();
    }
    catch (\Exception $e) {
      return 0;
    }
  }

  /**
   * Gets the most recent import timestamp.
   *
   * @return int|null
   *   The Unix timestamp of the last import, or NULL if no imports exist.
   */
  protected function getLastImportDate() {
    try {
      $result = $this->database->select('localgov_waste_collection_properties', 'p')
        ->fields('p', ['updated'])
        ->orderBy('updated', 'DESC')
        ->range(0, 1)
        ->execute()
        ->fetchField();

      return $result ? (int) $result : NULL;
    }
    catch (\Exception $e) {
      return NULL;
    }
  }

  /**
   * Gets collections grouped by waste type.
   *
   * @return array
   *   An array of rows, each containing waste type and count.
   */
  protected function getCollectionsByWasteType() {
    try {
      $query = $this->database->select('localgov_waste_collection_collections', 'c')
        ->fields('c', ['waste_type'])
        ->groupBy('c.waste_type');
      $query->addExpression('COUNT(*)', 'count');

      $results = $query->execute()->fetchAll();

      $rows = [];
      foreach ($results as $result) {
        $waste_type = $result->waste_type ?: $this->t('(Not specified)');
        $rows[] = [$waste_type, $result->count];
      }

      return $rows;
    }
    catch (\Exception $e) {
      return [];
    }
  }

}
