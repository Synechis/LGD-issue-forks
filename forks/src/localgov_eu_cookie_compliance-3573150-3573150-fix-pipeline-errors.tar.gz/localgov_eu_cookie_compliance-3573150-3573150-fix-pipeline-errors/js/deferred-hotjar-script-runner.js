/**
 * @param jQuery
 * @param Drupal
 * @param drupalSettings
 * @file
 * Insert Hotjar script into page head.
 *
 * This script is supposed to be invoked by the EU Cookie compliance module once
 * agreement for the Hotjar cookie has been obtained.
 *
 * @see localgov_eu_cookie_compliance_page_attachments_alter().
 */

(function runDeferredScripts(jQuery, Drupal, drupalSettings) {
  const deferredScripts = JSON.parse(drupalSettings.deferred_scripts || {});

  jQuery(deferredScripts.hotjar_script_tag).appendTo('head');
})(jQuery, Drupal, drupalSettings);
