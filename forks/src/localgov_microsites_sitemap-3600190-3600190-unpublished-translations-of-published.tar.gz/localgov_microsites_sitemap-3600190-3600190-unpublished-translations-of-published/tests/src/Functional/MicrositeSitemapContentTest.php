<?php

declare(strict_types=1);

namespace Drupal\Tests\localgov_microsites_sitemap\Functional;

use Drupal\Core\Entity\EntityInterface;
use Drupal\Tests\BrowserTestBase;
use Drupal\Tests\TestFileCreationTrait;
use Drupal\Tests\localgov_microsites_group\Traits\GroupCreationTrait;
use Drupal\Tests\localgov_microsites_group\Traits\InitializeGroupsTrait;
use Drupal\domain\DomainInterface;
use Drupal\file\Entity\File;
use Drupal\group\Entity\GroupType;
use Drupal\group\Entity\Storage\GroupRelationshipTypeStorageInterface;
use Drupal\language\Entity\ConfigurableLanguage;
use Drupal\localgov_microsites_group\DomainFromGroupTrait;
use Drupal\media\Entity\Media;
use Drupal\simple_sitemap\Entity\SimpleSitemap;
use Drupal\simple_sitemap\Queue\QueueWorker;

/**
 * Tests the sitemap of a microsite with some content types disabled.
 *
 * @group localgov_microsites_sitemap
 */
class MicrositeSitemapContentTest extends BrowserTestBase {

  use InitializeGroupsTrait;
  use GroupCreationTrait, DomainFromGroupTrait {
    GroupCreationTrait::getEntityTypeManager insteadof DomainFromGroupTrait;
  }
  use TestFileCreationTrait;

  /**
   * {@inheritdoc}
   */
  protected static $modules = [
    'localgov_core',
    'localgov_media',
  ];

  /**
   * {@inheritdoc}
   *
   * Prevent check for config schema raising errors.
   */
  protected static $configSchemaCheckerExclusions = [
    'pathauto.pattern.localgov_page',
    'core.entity_form_display.paragraph.localgov_image.default',
    'core.entity_form_display.paragraph.localgov_featured_campaign.default',
    'core.entity_form_display.paragraph.localgov_newsroom_teaser.default',
    'core.entity_form_display.paragraph.localgov_banner_primary.default',
    'core.entity_form_display.paragraph.localgov_banner_secondary.default',
    'core.entity_form_display.paragraph.localgov_box_link.default',
    'core.entity_form_display.paragraph.localgov_call_out_box.default',
    'core.entity_form_display.paragraph.localgov_featured_subsite.default',
    'core.entity_form_display.paragraph.localgov_featured_teaser.default',
    'core.entity_form_display.paragraph.localgov_key_contact_item.default',
    'core.entity_form_display.paragraph.localgov_media_with_text.default',
    'views.view.lgms_embed_view_news',
    'field.field.node.localgov_news_article.localgov_news_categories',
  ];

  /**
   * {@inheritdoc}
   */
  protected $defaultTheme = 'stark';

  /**
   * {@inheritdoc}
   */
  protected function setUp(): void {
    parent::setUp();

    $this->container->get('module_installer')->install(['localgov_microsites_group']);
    $this->container->get('module_installer')->install([
      'localgov_microsites_news',
      'simple_sitemap',
      'localgov_microsites_sitemap',
    ]);
    $this->rebuildContainer();

    // A content type not claimed by any microsites module, so it is always
    // enabled. The news content types are claimed by localgov_microsites_news,
    // so a microsite can turn them off.
    $this->drupalCreateContentType([
      'type' => 'test_page',
      'name' => 'Test page',
    ]);

    $group_type = $this->getEntityTypeManager()->getStorage('group_type')->load('microsite');
    assert($group_type instanceof GroupType);
    $storage = $this->getEntityTypeManager()->getStorage('group_relationship_type');
    assert($storage instanceof GroupRelationshipTypeStorageInterface);
    $storage->save($storage->createFromPlugin($group_type, 'group_node:test_page'));

  }

  /**
   * Only nodes of the enabled content types end up in the sitemap.
   */
  public function testSitemapOnlyContainsEnabledContentTypes(): void {
    $this->createMicrositeGroups([
      'lgms_modules_disabled' => ['localgov_microsites_news'],
    ], 2);
    $this->createMicrositeGroupsDomains($this->groups);
    [1 => $group, 2 => $other_group] = $this->groups;
    $sitemap_id = 'lgd_ms_' . $group->id();

    // Bundle settings are only written for the enabled content types:
    // localgov_page and test_page are not claimed by any microsites module, the
    // news ones are disabled.
    $config_factory = $this->container->get('config.factory');
    $prefix = 'simple_sitemap.bundle_settings.' . $sitemap_id . '.';
    $this->assertEqualsCanonicalizing(
      [$prefix . 'node.localgov_page', $prefix . 'node.test_page'],
      $config_factory->listAll($prefix)
    );

    // Content of an enabled type in the microsite.
    $enabled = $this->drupalCreateNode(['type' => 'test_page']);
    $group->addRelationship($enabled, 'group_node:test_page');

    // Content of a disabled type, still related to the microsite.
    $disabled = $this->drupalCreateNode(['type' => 'localgov_newsroom']);
    $group->addRelationship($disabled, 'group_node:localgov_newsroom');

    // Media related to the microsite.
    $image = current($this->getTestFiles('image'));
    $file = File::create(['uri' => $image->uri]);
    $file->save();
    $media = Media::create([
      'bundle' => 'image',
      'name' => $this->randomMachineName(),
      'field_media_image' => [
        'target_id' => $file->id(),
        'alt' => $this->randomMachineName(),
      ],
      'status' => 1,
    ]);
    $media->save();
    $group->addRelationship($media, 'group_media:image');

    // Content of an enabled type in another microsite, and outside of any.
    $other_microsite = $this->drupalCreateNode(['type' => 'test_page']);
    $other_group->addRelationship($other_microsite, 'group_node:test_page');
    $no_microsite = $this->drupalCreateNode(['type' => 'test_page']);

    $this->container->get('simple_sitemap.generator')
      ->setSitemaps([$sitemap_id])
      ->rebuildQueue()
      ->generate(QueueWorker::GENERATE_TYPE_BACKEND);

    $locations = $this->getSitemapLocations($sitemap_id);

    $domain = $this->getDomainFromGroup($group);
    $this->assertInstanceOf(DomainInterface::class, $domain);
    $this->assertSame([$this->micrositeUrl($enabled, $domain)], $locations);
    $this->assertNotContains($this->micrositeUrl($disabled, $domain), $locations);
    $this->assertNotContains($this->micrositeUrl($media, $domain), $locations);
    $this->assertNotContains($this->micrositeUrl($other_microsite, $domain), $locations);
    $this->assertNotContains($this->micrositeUrl($no_microsite, $domain), $locations);
  }

  /**
   * Unpublished translations of published content are not listed.
   */
  public function testUnpublishedTranslationIsNotListed(): void {
    $this->container->get('module_installer')->install(['language']);
    ConfigurableLanguage::createFromLangcode('sv')->save();
    $this->rebuildContainer();

    $this->createMicrositeGroups([], 1);
    $this->createMicrositeGroupsDomains($this->groups);
    $group = $this->groups[1];
    $sitemap_id = 'lgd_ms_' . $group->id();

    // A published translation, so the sitemap is shown to list translations.
    $published = $this->drupalCreateNode(['type' => 'test_page']);
    $published->addTranslation('sv', ['title' => $this->randomMachineName()])->save();
    $group->addRelationship($published, 'group_node:test_page');

    $unpublished = $this->drupalCreateNode(['type' => 'test_page']);
    $unpublished->addTranslation('sv', [
      'title' => $this->randomMachineName(),
      'status' => 0,
    ])->save();
    $group->addRelationship($unpublished, 'group_node:test_page');

    $this->container->get('simple_sitemap.generator')
      ->setSitemaps([$sitemap_id])
      ->rebuildQueue()
      ->generate(QueueWorker::GENERATE_TYPE_BACKEND);

    $domain = $this->getDomainFromGroup($group);
    $this->assertInstanceOf(DomainInterface::class, $domain);
    $locations = $this->getSitemapLocations($sitemap_id);
    $alternates = $this->getSitemapAlternateUrls($sitemap_id);

    $this->assertEqualsCanonicalizing([
      $this->micrositeUrl($published, $domain),
      $this->micrositeUrl($published->getTranslation('sv'), $domain),
      $this->micrositeUrl($unpublished, $domain),
    ], $locations);
    $this->assertContains($this->micrositeUrl($published->getTranslation('sv'), $domain), $alternates);
    $this->assertNotContains($this->micrositeUrl($unpublished->getTranslation('sv'), $domain), $alternates);
  }

  /**
   * Returns the <loc> of every URL in a generated sitemap.
   *
   * @param string $sitemap_id
   *   The sitemap variant ID.
   *
   * @return string[]
   *   The sitemap URLs.
   */
  protected function getSitemapLocations(string $sitemap_id): array {
    $sitemap = SimpleSitemap::load($sitemap_id);
    $this->assertNotNull($sitemap);
    $content = $sitemap->fromPublished()->toString();
    $this->assertNotEmpty($content, 'The sitemap has been generated.');

    $locations = [];
    foreach (simplexml_load_string($content)->url as $url) {
      $locations[] = (string) $url->loc;
    }
    return $locations;
  }

  /**
   * Returns the href of every hreflang alternate in a generated sitemap.
   *
   * @param string $sitemap_id
   *   The sitemap variant ID.
   *
   * @return string[]
   *   The alternate URLs.
   */
  protected function getSitemapAlternateUrls(string $sitemap_id): array {
    $content = SimpleSitemap::load($sitemap_id)->fromPublished()->toString();
    $xml = simplexml_load_string($content);
    $xml->registerXPathNamespace('xhtml', 'http://www.w3.org/1999/xhtml');

    $hrefs = [];
    foreach ($xml->xpath('//xhtml:link') as $link) {
      $hrefs[] = (string) $link['href'];
    }
    return $hrefs;
  }

  /**
   * Returns the canonical URL of an entity on a microsite domain.
   *
   * @param \Drupal\Core\Entity\EntityInterface $entity
   *   The entity.
   * @param \Drupal\domain\DomainInterface $domain
   *   The microsite domain.
   *
   * @return string
   *   The absolute URL on the microsite domain.
   */
  protected function micrositeUrl(EntityInterface $entity, DomainInterface $domain): string {
    return str_replace(
      rtrim($GLOBALS['base_url'], '/'),
      rtrim($domain->getPath(), '/'),
      $entity->toUrl('canonical', ['absolute' => TRUE])->toString()
    );
  }

}
