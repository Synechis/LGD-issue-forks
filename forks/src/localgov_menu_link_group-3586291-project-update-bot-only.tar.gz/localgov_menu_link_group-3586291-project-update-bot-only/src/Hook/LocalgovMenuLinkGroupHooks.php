<?php

namespace Drupal\localgov_menu_link_group\Hook;

use Drupal\Core\Entity\EntityInterface;
use Drupal\localgov_menu_link_group\MenuLinkGrouper;
use Drupal\Core\Hook\Attribute\Hook;

/**
 * Hook implementations for localgov_menu_link_group.
 */
class LocalgovMenuLinkGroupHooks {

  /**
   * Implements hook_preprocess_menu().
   */
  #[Hook('preprocess_menu')]
  public function preprocessMenu(&$variables) {
    $variables['menu_name'] = $variables['menu_name'] ?? 'admin';
    _localgov_menu_link_group_filter_menu($variables['items'], $variables['menu_name']);
  }

  /**
   * Implements hook_menu_links_discovered_alter().
   *
   * The localgov_menu_link_group entities tell us which menu link should go under
   * which group.  For each group, we generate a menu link.  This menu link serves
   * as the parent menu link for all the child menu links attached to that entity.
   */
  #[Hook('menu_links_discovered_alter')]
  public function menuLinksDiscoveredAlter(array &$menu_links) {
    $active_groups = \Drupal::service('entity_type.manager')->getStorage('localgov_menu_link_group')->loadByProperties([
      'status' => 1,
    ]);
    $menu_link_grouper = new MenuLinkGrouper($menu_links);
    // @phpstan-ignore-next-line Ignore the next line, it is correct but PHPStan cannot infer the type correctly.
    array_walk($active_groups, [
      $menu_link_grouper,
      'groupChildMenuLinks',
    ]);
  }

  /**
   * Implements hook_ENTITY_TYPE_insert().
   *
   * Rebuild menu link cache when a new localgov_menu_link_group entity is added.
   */
  #[Hook('localgov_menu_link_group_insert')]
  public function localgovMenuLinkGroupInsert(EntityInterface $entity) {
    \Drupal::service('plugin.manager.menu.link')->rebuild();
  }

  /**
   * Implements hook_ENTITY_TYPE_update().
   */
  #[Hook('localgov_menu_link_group_update')]
  public function localgovMenuLinkGroupUpdate(EntityInterface $entity) {
    localgov_menu_link_group_localgov_menu_link_group_insert($entity);
  }

}
