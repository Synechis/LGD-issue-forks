<?php

namespace Drupal\finders\Plugin\FinderType;

use Drupal\Core\StringTranslation\TranslatableMarkup;
use Drupal\finders\Attribute\FinderType;

/**
 * Basic finder type with no extras.
 */
#[FinderType(
  id: "simple",
  label: new TranslatableMarkup("Simple"),
  description: new TranslatableMarkup("Basic finder type."),
)]
class Simple extends FinderTypeBase {

}
