<?php

namespace Drupal\finders\Plugin\Block;

use Drupal\Core\Block\Attribute\Block;
use Drupal\Core\Block\BlockBase;
use Drupal\Core\Cache\CacheableMetadata;
use Drupal\Core\Entity\ContentEntityInterface;
use Drupal\Core\Entity\EntityRepositoryInterface;
use Drupal\Core\Entity\EntityTypeManagerInterface;
use Drupal\Core\Form\FormBuilderInterface;
use Drupal\Core\Form\FormState;
use Drupal\Core\Plugin\ContainerFactoryPluginInterface;
use Drupal\Core\Plugin\Context\EntityContextDefinition;
use Drupal\Core\StringTranslation\TranslatableMarkup;
use Drupal\finders\Enum\FinderRole;
use Drupal\finders\Plugin\FinderType\FinderTypeInterface;
use Drupal\views\Form\ViewsExposedForm;
use Drupal\views\Views;
use Symfony\Component\DependencyInjection\ContainerInterface;

/**
 * Shows the Views exposed filters of the channel view on entry entities.
 *
 * This only works for entry entities which are nodes, because of the context
 * definition on the plugin definition.
 *
 * @todo Functional test for cache tag invalidation scenario.
 */
#[Block(
  id: 'finders_channel_search',
  admin_label: new TranslatableMarkup('Finders channel search'),
  context_definitions: [
    'node' => new EntityContextDefinition(
      data_type: 'entity:node',
    ),
  ],
)]
class ChannelSearchBlock extends BlockBase implements ContainerFactoryPluginInterface {

  /**
   * The entity type manager.
   *
   * @var \Drupal\Core\Entity\EntityTypeManagerInterface
   */
  protected $entityTypeManager;

  /**
   * The entity repository service.
   *
   * @var \Drupal\Core\Entity\EntityRepositoryInterface
   */
  protected $entityRepository;

  /**
   * The form builder service.
   *
   * @var \Drupal\Core\Form\FormBuilderInterface
   */
  protected $formBuilder;

  /**
   * {@inheritdoc}
   */
  public static function create(ContainerInterface $container, array $configuration, $plugin_id, $plugin_definition) {
    return new static(
      $configuration,
      $plugin_id,
      $plugin_definition,
      $container->get('entity_type.manager'),
      $container->get('entity.repository'),
      $container->get('form_builder'),
    );
  }

  /**
   * Creates a ChannelSearchBlock instance.
   *
   * @param array $configuration
   *   A configuration array containing information about the plugin instance.
   * @param string $plugin_id
   *   The plugin_id for the plugin instance.
   * @param mixed $plugin_definition
   *   The plugin implementation definition.
   * @param \Drupal\Core\Entity\EntityTypeManagerInterface $entity_type_manager
   *   The entity type manager.
   * @param \Drupal\Core\Entity\EntityRepositoryInterface $entity_repository
   *   The entity repository service.
   * @param \Drupal\Core\Form\FormBuilderInterface $form_builder
   *   The form builder service.
   */
  public function __construct(
    array $configuration,
    $plugin_id,
    $plugin_definition,
    EntityTypeManagerInterface $entity_type_manager,
    EntityRepositoryInterface $entity_repository,
    FormBuilderInterface $form_builder,
  ) {
    parent::__construct($configuration, $plugin_id, $plugin_definition);
    $this->entityTypeManager = $entity_type_manager;
    $this->entityRepository = $entity_repository;
    $this->formBuilder = $form_builder;
  }

  /**
   * {@inheritdoc}
   */
  public function build() {
    /** @var \Drupal\node\NodeInterface $host_node */
    $host_node = $this->getContextValue('node');
    if (empty($host_node)) {
      return [];
    }

    // Get the finder for the host entity if one exists.
    // @todo Change to using getBundleEntity() when 11.3 is our minimum core
    // version. See https://www.drupal.org/node/2699835.
    $bundle_entity = $host_node->type->entity;

    /** @var \Drupal\finders\Entity\FinderInterface $finder */
    $finder = $this->entityTypeManager->getStorage('finder')->getFinderForBundleEntity($bundle_entity);

    if (empty($finder)) {
      return [];
    }

    // Bail if this is a channel entity.
    $finder_role = $finder->getFinderRoleForBundle($bundle_entity);
    if ($finder_role != FinderRole::Entries) {
      return [];
    }

    $finder_type = $finder->getFinderTypePlugin();

    $channel_view_id = $finder_type->getFinderTypeConstant('CHANNEL_VIEW');
    $channel_view = Views::getView($channel_view_id);

    // Bail if the channel view doesn't exist.
    if (empty($channel_view)) {
      return [];
    }

    return $this->getEntryForm($host_node, $finder_type);
  }

  /**
   * Gets the Views exposed filter form for an entry entity.
   *
   * @param \Drupal\Core\Entity\ContentEntityInterface $entry_entity
   *   The entry entity.
   * @param \Drupal\finders\Plugin\FinderType\FinderTypeInterface $finder_type
   *   The finder type plugin.
   *
   * @return array
   *   A render array.
   */
  public function getEntryForm(ContentEntityInterface $entry_entity, FinderTypeInterface $finder_type): array {
    $forms = $form_list = [];

    $channels_field = $finder_type->getFinderTypeConstant('CHANNEL_SELECTION_FIELD');
    $view_field = $finder_type->getFinderTypeConstant('VIEW_FIELD');

    $cache_dependencies = [];
    foreach ($entry_entity->get($channels_field)->referencedEntities() as $delta => $channel_entity) {
      // Get the view that the channel uses.
      if ($channel_entity->get($view_field)->isEmpty()) {
        continue;
      }

      $view_id = $channel_entity->get($view_field)->target_id;

      $view = Views::getView($view_id);

      if (empty($view)) {
        continue;
      }

      $cache_dependencies[] = $channel_entity;
      $cache_dependencies[] = $view;

      // Get the referenced View display.
      $display_id = $channel_entity->get($view_field)->display_id;
      $view->setDisplay($display_id);
      $view->setArguments([$channel_entity->id()]);
      $view->initHandlers();

      $form_state = (new FormState())
        ->setStorage([
          'view' => $view,
          'display' => &$view->display_handler->display,
          'rerender' => NULL,
        ])
        ->setMethod('get')
        ->setAlwaysProcess()
        ->disableRedirect();

      $form = $this->formBuilder->buildForm(ViewsExposedForm::class, $form_state);

      $form['actions']['submit']['#value'] = $this->t('Search');
      $form['#action'] = $channel_entity->toUrl()->toString();
      $form['#attributes']['class'][] = $delta ? 'finders-search-channel-secondary' : 'finders-search-channel-primary';
      $channel_label = $this->entityRepository->getTranslationFromContext($channel_entity)->label();
      $form['#id'] .= '--' . $channel_entity->id();
      $form["#info"]["filter-search_api_fulltext"]["label"] = $this->t('Search <span class="finders-search-channel" id="@id--channel">@channel</span>', [
        '@id' => $form['#id'],
        '@channel' => $channel_label,
      ]);
      // Can we do this with the form builder?
      // Do we need to deal with date-drupal-selector?
      // Questions for search_api_autocomplete?
      $form_list[$form['#id']] = $channel_label;

      // @todo Copy this from localgov_directories.
      // $form['#attached']['library'][] = 'localgov_directories/localgov_directories_search';
      $forms[] = $form;

      $forms['#attached']['drupalSettings']['finders']['findersSearch'] = $form_list;
    }

    // Add cacheability: this block depends on the view, and on the channel
    // node, since that could change the view that is used.
    $cacheability = CacheableMetadata::createFromRenderArray($forms);

    foreach ($cache_dependencies as $dependency) {
      $cacheability->addCacheableDependency($dependency);
    }

    $cacheability->applyTo($forms);

    return $forms;
  }

}
