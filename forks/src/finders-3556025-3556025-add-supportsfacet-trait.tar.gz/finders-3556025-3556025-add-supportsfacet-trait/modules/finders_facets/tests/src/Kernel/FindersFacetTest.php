<?php

namespace Drupal\Tests\finders_facets\Kernel;

use Drupal\KernelTests\KernelTestBase;
use Drupal\Tests\block\Traits\BlockCreationTrait;
use Drupal\Tests\finders_facets\Traits\HttpKernelUiHelperTrait;
use Drupal\Tests\user\Traits\UserCreationTrait;

/**
 * Tests setting up a finder with facets and facet filter ouput.
 *
 * @group finders_facets
 */
class FindersFacetTest extends KernelTestBase {

  use BlockCreationTrait;
  use HttpKernelUiHelperTrait;
  use UserCreationTrait;

  /**
   * The modules to enable.
   *
   * @var array
   */
  protected static $modules = [
    'system',
    'user',
    'field',
    'block',
    'views',
    'viewsreference',
    'search_api',
    'search_api_db',
    'finders',
    'finders_db',
    'node',
    'facets',
    'finders_facets',
    'better_exposed_filters',
    'facets_exposed_filters',
    'finders_test',
  ];

  /**
   * {@inheritdoc}
   */
  protected static $configSchemaCheckerExclusions = [
    'search_api.server.finders_default',
  ];

  /**
   * The entity type manager.
   *
   * @var \Drupal\Core\Entity\EntityTypeManagerInterface
   */
  protected $entityTypeManager;

  /**
   * The entity field manager.
   *
   * @var \Drupal\Core\Entity\EntityFieldManagerInterface
   */
  protected $entityFieldManager;

  /**
   * {@inheritdoc}
   */
  protected function setUp(): void {
    parent::setUp();

    $this->entityTypeManager = $this->container->get('entity_type.manager');
    $this->entityFieldManager = $this->container->get('entity_field.manager');

    $this->installEntitySchema('user');

    // We have to use the node entity type in this test rather than
    // entity_test_with_bundle because the block contexts only work with nodes.
    $this->installEntitySchema('node');

    $this->installConfig('finders');

    $this->installEntitySchema('finders_facet');

    // Set up the search index so we can see the view and facets.
    $this->installEntitySchema('search_api_task');
    $this->installSchema('search_api', ['search_api_item']);
    $this->installConfig('search_api');
    $this->installConfig(['finders_db']);

    $this->setUpCurrentUser([], [
      // This allows access to both nodes and finders facets.
      'access content',
    ]);

    // Set up the theme so that the Views exposed block can be placed by the
    // Finder.
    $this->container->get('theme_installer')->install(['stark']);
    $this->config('system.theme')->set('default', 'stark')->save();

    $this->placeBlock('page_title_block');

    // Create the fallback date format.
    $this->entityTypeManager->getStorage('date_format')->create([
      'id' => 'fallback',
      'label' => 'Fallback date format',
      'pattern' => 'D, m/d/Y - H:i',
      'locked' => TRUE,
    ])->save();
  }

  /**
   * Tests a finder with facets.
   */
  public function testFinderWithFacets() {
    // Create bundles that will be channels and entries.
    $channel_bundle = $this->entityTypeManager->getStorage('node_type')->create([
      'type' => 'test_channel_bundle',
      'status' => TRUE,
    ]);
    $channel_bundle->save();

    $entry_bundle_one = $this->entityTypeManager->getStorage('node_type')->create([
      'type' => 'test_entry_bundle_one',
      'status' => TRUE,
    ]);
    $entry_bundle_one->save();
    $entry_bundle_two = $this->entityTypeManager->getStorage('node_type')->create([
      'type' => 'test_entry_bundle_two',
      'status' => TRUE,
    ]);
    $entry_bundle_two->save();

    // Create a finder without facets enabled.
    $finder = $this->entityTypeManager->getStorage('finder')->create([
      'id' => 'test',
      'label' => 'Test',
      'type' => 'test',
      'channels' => [
        'node' => [
          'test_channel_bundle',
        ],
      ],
      'entries' => [
        'node' => [
          'test_entry_bundle_one',
        ],
      ],
    ]);
    // Save the finder now, so we test that updating an existing finder to have
    // facets works properly.
    $finder->save();

    // Enable facets on the finder.
    $finder->setThirdPartySetting(
      'finders_facets',
      'facets',
      TRUE
    );
    $finder->save();

    // The channel bundle has the facet types field on it.
    $channel_fields = $this->entityFieldManager->getFieldDefinitions('node', 'test_channel_bundle');
    $this->assertArrayHasKey('finders_facets_enable', $channel_fields);

    // The entry bundle has the facet selection field on it.
    $channel_fields = $this->entityFieldManager->getFieldDefinitions('node', 'test_entry_bundle_one');
    $this->assertArrayHasKey('finders_facets_select', $channel_fields);

    $search_index = $this->entityTypeManager->getStorage('search_api_index')->load('finders_index_default');
    $this->assertNotEmpty($search_index);
    $fields = $search_index->getFields();

    // The facets field has been added to the search index.
    $this->assertArrayHasKey('finders_facets_filter', $fields);

    // The facet filter has been added to the view.
    $view = $this->entityTypeManager->getStorage('view')->load('finders_channel_list');
    $this->assertNotEmpty($view);

    $displays = $view->get('display');
    $filters = $displays['default']['display_options']['filters'];

    $this->assertArrayHasKey('search_api_fulltext', $filters, 'The channel view has the full text search filter.');
    $this->assertArrayHasKey('facets_finders_facets_filter', $filters, 'The channel view has the facet filter.');

    // Check the filter plugins are all valid.
    $view_executable = $this->container->get('views.executable')->get($view);
    $view_executable->setDisplay('channel_embed');
    $view_executable->initHandlers();
    $display = $view_executable->getDisplay();
    $filters = $display->getHandlers('filter');
    foreach ($filters as $key => $filter) {
      $this->assertNotEquals('broken', $filter->getPluginId());
    }

    // No facet config entities have been created.
    $facets = $this->entityTypeManager->getStorage('facets_facet')->loadMultiple();
    $this->assertEmpty($facets);

    // Create two facet types.
    $cats_facet_type = $this->entityTypeManager->getStorage('finders_facet_type')->create([
      'id' => 'cat',
    ]);
    $cats_facet_type->save();

    $dog_facet_type = $this->entityTypeManager->getStorage('finders_facet_type')->create([
      'id' => 'dog',
    ]);
    $dog_facet_type->save();

    // Create some facets.
    $cat_1 = $this->entityTypeManager->getStorage('finders_facet')->create([
      'title' => 'Sylvester',
      'type' => 'cat',
    ]);
    $cat_1->save();

    $dog_1 = $this->entityTypeManager->getStorage('finders_facet')->create([
      'title' => 'Scooby-Doo',
      'type' => 'dog',
    ]);
    $dog_1->save();

    // Create two channel entities.
    $cat_channel = $this->entityTypeManager->getStorage('node')->create([
      'title' => 'Cat channel',
      'type' => 'test_channel_bundle',
      'finders_channel_types' => [
        'test_entry_bundle_one',
      ],
      'finders_view' => [
        'target_id' => 'finders_channel_list',
        'display_id' => 'channel_embed',
      ],
      'finders_facets_enable' => [
        'cat',
      ],
    ]);
    $cat_channel->save();

    $dog_channel = $this->entityTypeManager->getStorage('node')->create([
      'title' => 'Dog channel',
      'type' => 'test_channel_bundle',
      'finders_channel_types' => [
        'test_entry_bundle_one',
      ],
      'finders_view' => [
        'target_id' => 'finders_channel_list',
        'display_id' => 'channel_embed',
      ],
      'finders_facets_enable' => [
        'dog',
      ],
    ]);
    $dog_channel->save();

    // Create an entry in both channels, with one facet from each type.
    $entry = $this->entityTypeManager->getStorage('node')->create([
      'title' => 'Animals entry',
      'type' => 'test_entry_bundle_one',
      'finders_channels' => [
        $cat_channel->id(),
        $dog_channel->id(),
      ],
      'finders_facets_select' => [
        $cat_1->id(),
        $dog_1->id(),
      ],
    ]);
    $entry->save();

    // Update the search index.
    $index = $this->entityTypeManager->getStorage('search_api_index')->load('finders_index_default');
    $indexed = $index->indexItems();
    $this->assertEquals(1, $indexed);

    // Check the cat channel.
    $this->drupalGet($cat_channel->toUrl('canonical'));
    $this->assertSession()->statusCodeEquals(200);
    $this->assertSession()->pageTextContains('Cat channel');
    // The entry entity is show on the cat channel.
    $this->assertSession()->pageTextContains('Animals entry');
    // Only the cat facets are shown, because the channel only has the cats
    // facet type.
    $this->assertSession()->pageTextContains('Sylvester');
    $this->assertSession()->pageTextNotContains('Scooby-Doo');

    // Check the dog channel.
    // We need to clear the processed facets static cache, otherwise we get
    // incorrect facet values.
    // @todo Remove this when
    // https://www.drupal.org/project/facets/issues/3591087 is fixed.
    drupal_static_reset('facets_exposed_filters_get_processed_facet');
    $this->drupalGet($dog_channel->toUrl('canonical'));
    $this->assertSession()->statusCodeEquals(200);
    $this->assertSession()->pageTextContains('Dog channel');
    // The entry entity is show on the dog channel.
    $this->assertSession()->pageTextContains('Animals entry');
    // Only the dog facets are shown, because the channel only has the dogs
    // facet type.
    $this->assertSession()->pageTextContains('Scooby-Doo');
    $this->assertSession()->pageTextNotContains('Sylvester');
  }

}
