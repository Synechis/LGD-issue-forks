<?php

namespace Drupal\finders_facets\Form;

use Drupal\Core\Entity\EntityDeleteForm;
use Drupal\Core\Form\FormStateInterface;

/**
 * Delete confirmation form for Finders Facet Type entities.
 *
 * @todo Remove this when https://www.drupal.org/project/drupal/issues/3571580
 * is fixed and in the lowest supported version of Drupal Core.
 */
class FindersFacetTypeDeleteForm extends EntityDeleteForm {

  /**
   * {@inheritdoc}
   */
  public function buildForm(array $form, FormStateInterface $form_state) {
    // Get the count of facets that use this facet type.
    $num_facets = $this->entityTypeManager->getStorage('finders_facet')->getQuery()
      ->accessCheck(FALSE)
      ->condition('type', $this->entity->id())
      ->count()
      ->execute();

    // If dependent facets exist give a warning.
    if ($num_facets > 0) {
      // Change the title, as the user can't delete.
      $form['#title'] = $this->t("Unable to delete facet type %type.", [
        '%type' => $this->entity->label(),
      ]);

      $caption = $this->formatPlural(
        $num_facets,
        'The facet type %label is used by 1 facet and cannot be deleted.',
        'The facet type %label is used by @count facets and cannot be deleted.',
        ['%label' => $this->entity->label()]
      );
      $form['description'] = [
        '#type' => 'html_tag',
        '#tag' => 'p',
        '#value' => $caption,
      ];

      // Retrieve and add the form actions array but without the submit button.
      $actions = $this->actionsElement($form, $form_state);
      unset($actions['submit']);
      if (!empty($actions)) {

        $form['actions'] = $actions;
      }

      return $form;
    }

    return parent::buildForm($form, $form_state);
  }

}
