<?php

namespace Drupal\finders_facets\Form;

use Drupal\Core\Entity\ContentEntityForm;
use Drupal\Core\Form\FormStateInterface;

/**
 * Provides the default form handler for the Finders Facet entity.
 */
class FindersFacetForm extends ContentEntityForm {

  /**
   * {@inheritdoc}
   */
  public function form(array $form, FormStateInterface $form_state) {
    $form = parent::form($form, $form_state);
    return $form;
  }

  /**
   * {@inheritdoc}
   */
  public function save(array $form, FormStateInterface $form_state) {
    $status = parent::save($form, $form_state);

    $t_args = [
      '%name' => $this->entity->label(),
      '%bundle' => $this->entity->type->entity->label(),
    ];
    $message = '';
    if ($status == SAVED_UPDATED) {
      $message = $this->t('The %bundle finders facet %name has been updated.', $t_args);
    }
    elseif ($status == SAVED_NEW) {
      $message = $this->t('The %bundle finders facet %name has been added.', $t_args);
    }
    $this->messenger()->addStatus($message);

    $form_state->setRedirectUrl($this->entity->toUrl('collection'));

    return $status;
  }

}
