# Finders

Finders allows content editors to create searchable and filterable lists of
items, without needing to change site configuration.

Site administrators configure a Finder configuration entity, defining which
content types act as:
  - channels: Content which shows lists of entries.
  - entries: Content which appears in channels.

Content editors can then create channel and entry entities, which can be
searched by site users.

Finders uses Search API and Views to create lists of entry entities. Faceted
search can be added by enabling the Finders Facets submodule.

Finders is intentionally opinionated in what it creates and controls, but allows
extensive customisation via its plugin type.

Originally designed for LocalGov Drupal Directories as a simple way for site
builders to create ways for users to find content entries. This has been
generalized so information architecture modules such as directories, events,
news, consultations, anything that has entries in a channel can be configured by
the site builder to create an easy system for users to search and filter through
content.

Finders can be extended with:
  - The Finders Facets submodule in this project. This allows the creation of
    multiple facets that finder entries can be filtered on using Facets module.
  - The Finders Events module (https://www.drupal.org/project/finders_events)
  - Custom finder type plugins.

## Requirements

This module requires the following modules:

- [search_api](https://www.drupal.org/project/search_api)
- [viewsreference](https://www.drupal.org/project/viewsreference)

## Recommended modules

- [pathauto](http://drupal.org/project/pathauto) If Pathauto module is present,
  and channels and entry entities both have path patterns, the path for the
  channel is automatically prepended to the generated entry path. This requires
  the patch from https://www.drupal.org/project/token/issues/3047568 to function
  correctly.

## Installation

Install as you would normally install a contributed Drupal module. For further
information, see
[Installing Drupal Modules](https://www.drupal.org/docs/extending-drupal/installing-drupal-modules).

Additionally, enable the Finders DB submodule in this project if you want to use
the Search API database backend.

## Configuration

1. Enable a module that provides a finder type.
2. Create at least two entity bundles, such as node types, one for channels and
   one for entries.
3. Go to Administration » Structure » Finders.
4. Use the 'Add finder' link.
5. Enter the name for the finder.
6. Select a type for the finder.
7. Select the channel and entry bundles.
8. Creating the finder makes changes to your site, including:
   - Defining bundle fields on the channel and entry bundles.
   - Creating a search index for the finder type.
   - Creating a view for for the finder type. This is output on
     channel entities with a viewsreference field.
   - Creating a block for the view's exposed form, configured to show on channel
     entities.
   - Creating a block for searching an entry entity's channels.
   Specific finder types may make further changes.
9. If you have the Finders DB submodule enabled, the newly-created Search API
   index will have a DB backend Search API server set on it. Otherwise, edit the
   search index and set a Search API server.

## Known limitations

Relative date facets are currently not supported. This is due to a Drupal Facets
issue [#3375282](https://www.drupal.org/project/facets/issues/3375282), where
relative date ranges can calculate an incorrect date granularity (off-by-one),
leading to invalid date formats and runtime exceptions. Until the issue is
resolved upstream, relative date facets should not be used.

