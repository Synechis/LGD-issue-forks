<?php

/**
 * @file
 * Hooks provided by the Finders module.
 */

use Drupal\Core\Config\Entity\ConfigEntityInterface;
use Drupal\finders\Entity\FinderInterface;
use Drupal\search_api\IndexInterface;
use Drupal\views\ViewEntityInterface;

/**
 * @addtogroup hooks
 * @{
 */

/**
 * Perform alterations on the channel bundle fields before they are created.
 *
 * @param \Drupal\finders\Field\BundleFieldDefinition[] $channel_field_definitions
 *   An array of bundle field definitions to be added to the channel bundle.
 *   These have not yet been declared to the field system. Field definitions
 *   added to this array may omit the target entity type and bundle as a
 *   convenience.
 * @param \Drupal\Core\Config\Entity\ConfigEntityInterface $bundle_entity
 *   The bundle entity that is being configured as a channel.
 * @param \Drupal\finders\Entity\FinderInterface $finder
 *   The finder entity.
 *
 * @see \Drupal\finders\FinderConfigManage::ensureFinderConfig()
 */
function hook_finders_channel_fields_alter(array &$channel_field_definitions, ConfigEntityInterface $bundle_entity, FinderInterface $finder) {
  // Change the label of the finder channel types field.
  $finder_type_plugin = $finder->getFinderTypePlugin();
  $channel_field_definitions[$finder_type_plugin::CHANNEL_TYPES_FIELD]->setLabel(t('Enabled items'));
}

/**
 * Perform alterations on a finder search index when it is being updated.
 *
 * This hook is invoked after the finder type plugin's alterSearch() has been
 * called.
 *
 * @param \Drupal\search_api\IndexInterface $index
 *   The search index. It has not yet been saved, and will be saved by the
 *   invoker of this hook.
 * @param \Drupal\finders\Entity\FinderInterface $finder
 *   The finder entity.
 *
 * @see \Drupal\finders\FinderConfigManage::ensureFinderConfig()
 */
function hook_finders_index_alter(IndexInterface $index, FinderInterface $finder): void {
  // Change the boost on the index title field.
  $index->getField('title')->setBoost(10.0);
}

/**
 * Perform alterations on a finder view index when it is being updated.
 *
 * This hook is invoked after the finder type plugin's alterView() has been
 * called.
 *
 * @param \Drupal\views\ViewEntityInterface $view
 *   The view. It has not yet been saved, and will be saved by the invoker of
 *   this hook.
 * @param \Drupal\search_api\IndexInterface $index
 *   The search index. It has already been updated with configuration for the
 *   finder.
 * @param \Drupal\finders\Entity\FinderInterface $finder
 *   The finder entity.
 *
 * @see \Drupal\finders\FinderConfigManage::ensureFinderConfig()
 */
function hook_finders_view_alter(ViewEntityInterface $view, IndexInterface $index, FinderInterface $finder): void {
  // Add a field to the index.
  $field = new \Drupal\search_api\Item\Field($index, 'rendered_item');
  $field->setType('text');
  $field->setPropertyPath('rendered_item');
  $field->setLabel('Rendered HTML output');
  $index->addField($field);
}

/**
 * Perform alterations on the entry bundle fields before they are created.
 *
 * @param \Drupal\finders\Field\BundleFieldDefinition[] $entry_field_definitions
 *   An array of bundle field definitions to be added to the entry bundle. These
 *   have not yet been declared to the field system. Field definitions added to
 *   this array may omit the target entity type and bundle as a convenience.
 * @param \Drupal\Core\Config\Entity\ConfigEntityInterface $bundle_entity
 *   The bundle entity that is being configured as an entry.
 * @param \Drupal\finders\Entity\FinderInterface $finder
 *   The finder entity.
 *
 * @see \Drupal\finders\FinderConfigManage::ensureFinderConfig()
 */
function hook_finders_entry_fields_alter(array &$entry_field_definitions, ConfigEntityInterface $bundle_entity, FinderInterface $finder) {
  // Change the label of the finder channel selection field.
  $finder_type_plugin = $finder->getFinderTypePlugin();
  $entry_field_definitions[$finder_type_plugin::CHANNEL_SELECTION_FIELD]->setLabel(t('Directories'));
}

/**
 * Act after a finder has been configured.
 *
 * This is invoked after a finder has had its fields set up, and its search
 * indexes and views created or updated.
 *
 * It is essential that implementations of this hook be idempotent, as
 * it is invoked every time a finder entity is updated.
 *
 * @param \Drupal\finders\Entity\FinderInterface $finder
 *   The finder entity.
 *
 * @see \Drupal\finders\FinderConfigManage::ensureFinderConfig()
 */
function hook_finders_post_configure(FinderInterface $finder) {
  // Create a custom config entity based on the finder.
  $cat_storage = \Drupal::service('entity_type.manager')->getStorage('cats');
  if (!$cat_storage->load($finder->id())) {
    $cat = $cat_storage->create([
      'id' => $finder->id(),
    ]);
    $cat->save();
  }
}

/**
 * Perform alterations on Finder Type definitions.
 *
 * @param array &$info
 *   Array of information on Finder Type plugins.
 */
function hook_finder_type_info_alter(array &$info) {
  // Change the class of the 'foo' plugin.
  $info['foo']['class'] = SomeOtherClass::class;
}

/**
 * @} End of "addtogroup hooks".
 */
