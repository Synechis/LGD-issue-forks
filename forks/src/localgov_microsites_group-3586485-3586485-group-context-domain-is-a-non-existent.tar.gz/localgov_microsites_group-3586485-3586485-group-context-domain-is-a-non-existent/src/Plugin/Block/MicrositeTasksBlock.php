<?php

namespace Drupal\localgov_microsites_group\Plugin\Block;

use Drupal\Core\Access\AccessManagerInterface;
use Drupal\Core\Block\BlockBase;
use Drupal\Core\Cache\CacheableMetadata;
use Drupal\Core\Config\ConfigFactoryInterface;
use Drupal\Core\Menu\LocalTaskManagerInterface;
use Drupal\Core\Plugin\ContainerFactoryPluginInterface;
use Drupal\Core\Plugin\Context\ContextRepositoryInterface;
use Drupal\Core\Routing\RouteMatch;
use Drupal\Core\Session\AccountInterface;
use Drupal\Core\Url;
use Drupal\group\Entity\GroupInterface;
use Symfony\Component\DependencyInjection\ContainerInterface;
use Symfony\Component\Routing\Route;

/**
 * Provides a local task of group as a sitewide block.
 *
 * @Block(
 *   id = "microsite_tasks_block",
 *   admin_label = @Translation("Microsite tasks"),
 * )
 */
class MicrositeTasksBlock extends BlockBase implements ContainerFactoryPluginInterface {

  /**
   * The local task manager.
   *
   * @var \Drupal\Core\Menu\LocalTaskManagerInterface
   */
  protected $localTaskManager;

  /**
   * The context repository.
   *
   * @var \Drupal\Core\Plugin\Context\ContextRepositoryInterface
   */
  protected $contextRepository;

  /**
   * The config factory.
   *
   * @var \Drupal\Core\Config\ConfigFactoryInterface
   */
  protected $configFactory;

  /**
   * Access manager.
   *
   * @var \Drupal\Core\Access\AccessManagerInterface
   */
  protected $accessManager;

  /**
   * The current user.
   *
   * @var \Drupal\Core\Session\AccountInterface
   */
  protected $currentUser;

  /**
   * Creates a LocalTasksBlock instance.
   *
   * @param array $configuration
   *   A configuration array containing information about the plugin instance.
   * @param string $plugin_id
   *   The plugin_id for the plugin instance.
   * @param mixed $plugin_definition
   *   The plugin implementation definition.
   * @param \Drupal\Core\Menu\LocalTaskManagerInterface $local_task_manager
   *   The local task manager.
   * @param \Drupal\Core\Plugin\Context\ContextRepositoryInterface $context_repository
   *   The context repository.
   * @param \Drupal\Core\Config\ConfigFactoryInterface $config_factory
   *   The config factory.
   * @param \Drupal\Core\Access\AccessManagerInterface $access_manager
   *   The access manager.
   * @param \Drupal\Core\Session\AccountInterface $current_user
   *   The current user.
   */
  public function __construct(array $configuration, $plugin_id, $plugin_definition, LocalTaskManagerInterface $local_task_manager, ContextRepositoryInterface $context_repository, ConfigFactoryInterface $config_factory, AccessManagerInterface $access_manager, AccountInterface $current_user) {
    parent::__construct($configuration, $plugin_id, $plugin_definition);
    $this->localTaskManager = $local_task_manager;
    $this->contextRepository = $context_repository;
    $this->configFactory = $config_factory;
    $this->accessManager = $access_manager;
    $this->currentUser = $current_user;
  }

  /**
   * {@inheritdoc}
   */
  public static function create(ContainerInterface $container, array $configuration, $plugin_id, $plugin_definition) {
    return new static(
      $configuration,
      $plugin_id,
      $plugin_definition,
      $container->get('plugin.manager.menu.local_task'),
      $container->get('context.repository'),
      $container->get('config.factory'),
      $container->get('access_manager'),
      $container->get('current_user')
    );
  }

  /**
   * {@inheritdoc}
   */
  public function build() {
    $cacheability = new CacheableMetadata();
    $cacheability->addCacheableDependency($this->localTaskManager);

    $group = $this->getActiveGroup($cacheability);

    $menu = [];
    if ($group instanceof GroupInterface) {
      $group_id = $group->id();
      $menu['#theme'] = 'microsites_task_block';
      $route = new RouteMatch(
        'entity.group.canonical',
        new Route('group/{group}'),
        ['group' => $group],
        ['group' => $group_id],
      );
      $tasks = $this->localTaskManager->getLocalTasksForRoute('entity.group.canonical');
      foreach ($tasks[0] as $task_id => $task) {
        $route_name = $task->getRouteName();
        $route_parameters = $task->getRouteParameters($route);
        $link = [
          '#type' => 'link',
          '#title' => localgov_microsites_group_local_task_title($task_id) ?: $task->getTitle() . " something",
          '#url' => Url::fromRoute($route_name, $route_parameters),
          '#options' => $task->getOptions($route),
        ];
        if (localgov_microsites_group_local_task_hidden($task_id)) {
          $access = FALSE;
        }
        else {
          $access = $this->accessManager
            ->checkNamedRoute($route_name, $route_parameters, $this->currentUser, TRUE);
        }
        $menu['#links'][] = [
          'link' => $link,
          '#access' => $access,
          '#weight' => $task->getWeight(),
        ];
        $cacheability
          ->addCacheableDependency($task)
          ->addCacheableDependency($access);
      }
    }

    $cacheability->applyTo($menu);
    return $menu;
  }

  /**
   * Gets the active group from the Group Sites context provider.
   *
   * @param \Drupal\Core\Cache\CacheableMetadata $cacheability
   *   Cacheable metadata to add the context's metadata to.
   *
   * @return \Drupal\group\Entity\GroupInterface|null
   *   The active group, or NULL if there is none.
   */
  protected function getActiveGroup(CacheableMetadata $cacheability): ?GroupInterface {
    $config = $this->configFactory->get('group_sites.settings');
    $cacheability->addCacheableDependency($config);

    $context_id = $config->get('context_provider');
    if ($context_id === NULL) {
      return NULL;
    }

    $contexts = $this->contextRepository->getRuntimeContexts([$context_id]);
    $context = reset($contexts);
    if ($context === FALSE) {
      return NULL;
    }
    $cacheability->addCacheableDependency($context);

    $group = $context->hasContextValue() ? $context->getContextValue() : NULL;
    return $group instanceof GroupInterface ? $group : NULL;
  }

}
