# LocalGov Consultations Demo Content

Provides sample demo content for the [LocalGov Consultations](https://www.drupal.org/project/localgov_consultations) module. Useful for evaluating the module or onboarding new developers.

On install, all nodes are resaved automatically to ensure URL aliases (via Pathauto) and banner images are correctly generated.

## Requirements

- [LocalGov Consultations](https://www.drupal.org/project/localgov_consultations)
- [Default Content](https://www.drupal.org/project/default_content)

## Installation

Enable the module as you would any other Drupal module:

```
drush en localgov_consultations_demo_content
```

Demo content is imported automatically on install. No additional configuration is needed.

## Uninstalling

Uninstalling this module does **not** remove the demo content. Delete the consultation nodes manually before uninstalling if you want a clean state.
