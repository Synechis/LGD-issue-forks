<?php

declare(strict_types=1);

namespace Drupal\Tests\localgov_consultations\Kernel;

use Drupal\Core\Datetime\DrupalDateTime;
use Drupal\datetime\Plugin\Field\FieldType\DateTimeItemInterface;
use Drupal\field\Entity\FieldStorageConfig;
use Drupal\filter\Entity\FilterFormat;
use Drupal\geo_entity\Entity\GeoEntityType;
use Drupal\KernelTests\KernelTestBase;
use Drupal\media\Entity\MediaType;
use Drupal\node\Entity\Node;
use Drupal\node\NodeInterface;
use Drupal\paragraphs\Entity\ParagraphsType;

/**
 * Base class for LocalGov Consultations kernel tests.
 */
abstract class ConsultationsKernelTestBase extends KernelTestBase {

  /**
   * {@inheritdoc}
   */
  protected static $configSchemaCheckerExclusions = [
    // Missing schema for entity reference handler settings.
    'field.field.node.consultation.localgov_consultation_contact',
    // Missing schema for field_group and entity_browser_entity_form settings.
    'core.entity_form_display.node.consultation.default',
  ];

  /**
   * {@inheritdoc}
   */
  protected static $modules = [
    'address',
    'block',
    'breakpoint',
    'ckeditor5',
    'crop',
    'datetime',
    'datetime_range',
    'editor',
    'entity_reference_revisions',
    'field',
    'field_group',
    'file',
    'filter',
    'geo_entity',
    'geo_entity_address',
    'geofield',
    'image',
    'image_widget_crop',
    'inline_entity_form',
    'layout_discovery',
    'layout_paragraphs',
    'link',
    'linkit',
    'localgov_consultations',
    'localgov_core',
    'localgov_services',
    'localgov_workflows_notifications',
    'media',
    'media_library',
    'media_library_edit',
    'menu_ui',
    'node',
    'options',
    'paragraphs',
    'path',
    'path_alias',
    'pathauto',
    'responsive_image',
    'system',
    'taxonomy',
    'telephone',
    'text',
    'token',
    'user',
    'views',
    'workflows',
  ];

  /**
   * {@inheritdoc}
   */
  protected function setUp(): void {
    parent::setUp();

    $this->installEntitySchema('user');
    $this->installEntitySchema('node');
    $this->installEntitySchema('paragraph');
    $this->installEntitySchema('taxonomy_term');
    $this->installEntitySchema('media');
    $this->installEntitySchema('file');
    $this->installEntitySchema('path_alias');
    $this->installSchema('file', ['file_usage']);
    $this->installSchema('node', ['node_access']);
    $this->installConfig([
      'system',
      'field',
      'filter',
      'node',
      'media',
      'pathauto',
    ]);

    $this->createRequiredDependencyConfig();

    $this->installConfig([
      'localgov_consultations',
    ]);
  }

  /**
   * Creates a consultation node with useful defaults.
   *
   * @param array $values
   *   Entity values to override.
   *
   * @return \Drupal\node\NodeInterface
   *   The saved consultation node.
   */
  protected function createConsultation(array $values = []): NodeInterface {
    $values += [
      'type' => 'consultation',
      'title' => 'Test consultation',
      'status' => NodeInterface::PUBLISHED,
      'localgov_consultation_status' => 'upcoming',
      'localgov_consultation_date' => [
        'value' => $this->formatDate('+1 day'),
        'end_value' => $this->formatDate('+2 days'),
      ],
    ];

    $node = Node::create($values);
    $node->save();

    return $node;
  }

  /**
   * Formats a relative date for the consultation date range field.
   *
   * @param string $relative
   *   A relative date string accepted by strtotime().
   *
   * @return string
   *   Date string in Drupal date storage format.
   */
  protected function formatDate(string $relative): string {
    $date_time = new DrupalDateTime($relative);
    $site_timezone = \Drupal::configFactory()->get('system.date')->get('timezone.default') ?? 'UTC';
    return $date_time->format(DateTimeItemInterface::DATE_STORAGE_FORMAT, $site_timezone);
  }

  /**
   * Creates config entities that consultation install config depends on.
   */
  private function createRequiredDependencyConfig(): void {
    FilterFormat::create([
      'format' => 'wysiwyg',
      'name' => 'WYSIWYG',
    ])->save();

    MediaType::create([
      'id' => 'image',
      'label' => 'Image',
      'source' => 'image',
      'source_configuration' => [
        'source_field' => 'field_media_image',
      ],
    ])->save();
    MediaType::create([
      'id' => 'document',
      'label' => 'Document',
      'source' => 'file',
      'source_configuration' => [
        'source_field' => 'field_media_document',
      ],
    ])->save();

    GeoEntityType::create([
      'id' => 'address',
      'label' => 'Address',
      'label_token' => '[geo_entity:address]',
    ])->save();

    ParagraphsType::create([
      'id' => 'localgov_contact',
      'label' => 'Contact',
    ])->save();

    FieldStorageConfig::create([
      'field_name' => 'localgov_common_tasks',
      'entity_type' => 'node',
      'type' => 'link',
      'cardinality' => 6,
    ])->save();
    FieldStorageConfig::create([
      'field_name' => 'localgov_title',
      'entity_type' => 'paragraph',
      'type' => 'string',
      'settings' => [
        'max_length' => 255,
        'is_ascii' => FALSE,
        'case_sensitive' => FALSE,
      ],
    ])->save();
  }

}
