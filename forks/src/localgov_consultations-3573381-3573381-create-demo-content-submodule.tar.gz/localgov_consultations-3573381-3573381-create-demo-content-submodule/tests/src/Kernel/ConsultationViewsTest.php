<?php

declare(strict_types=1);

namespace Drupal\Tests\localgov_consultations\Kernel;

use Drupal\node\Entity\Node;
use Drupal\node\Entity\NodeType;
use Drupal\views\Views;

/**
 * Tests the consultations view installed configuration.
 *
 * @group localgov_consultations
 */
final class ConsultationViewsTest extends ConsultationsKernelTestBase {

  /**
   * Tests the view only returns consultation nodes.
   */
  public function testConsultationsViewQuery(): void {
    $matching = $this->createConsultation([
      'title' => 'Visible consultation',
      'status' => 1,
      'localgov_consultation_status' => 'open',
      'localgov_consultation_date' => [
        'value' => $this->formatDate('-2 days'),
        'end_value' => $this->formatDate('+2 days'),
      ],
    ]);
    $unpublished = $this->createConsultation([
      'title' => 'Draft consultation',
      'status' => 0,
      'localgov_consultation_status' => 'upcoming',
      'localgov_consultation_date' => [
        'value' => $this->formatDate('+2 days'),
        'end_value' => $this->formatDate('+4 days'),
      ],
    ]);

    NodeType::create([
      'type' => 'page',
      'name' => 'Page',
    ])->save();
    Node::create([
      'type' => 'page',
      'title' => 'Ordinary page',
      'status' => 1,
    ])->save();

    $view = Views::getView('consultations');
    $this->assertNotFalse($view);
    $view->setDisplay('open_consultations');
    $view->execute();

    $result_ids = array_map(static fn($row) => $row->nid, $view->result);
    $this->assertContains($matching->id(), $result_ids);
    $this->assertNotContains($unpublished->id(), $result_ids);
    $this->assertCount(1, $view->result);
  }

}
