<?php

declare(strict_types=1);

namespace Drupal\Tests\localgov_consultations\Kernel;

use Drupal\Core\Form\FormState;
use Drupal\block\Entity\Block;
use Drupal\file\Entity\File;

/**
 * Tests install-time defaults and banner block plugins.
 *
 * @group localgov_consultations
 */
final class ConsultationInstallAndBlockTest extends ConsultationsKernelTestBase {

  /**
   * Tests hook_install() initialises state, template config, and blocks.
   */
  public function testInstallDefaults(): void {
    $this->container->get('state')->delete('localgov_consultations_process_opens_last_run');
    $this->container->get('state')->delete('localgov_consultations_process_closes_last_run');
    Block::load('localgov_consultations_landing_banner')?->delete();
    Block::load('localgov_consultations_page_banner')?->delete();

    $this->container->get('module_handler')->loadInclude('localgov_consultations', 'install');
    localgov_consultations_install();

    $this->assertIsInt($this->container->get('state')->get('localgov_consultations_process_opens_last_run'));
    $this->assertIsInt($this->container->get('state')->get('localgov_consultations_process_closes_last_run'));

    $landing_banner = Block::load('localgov_consultations_landing_banner');
    $this->assertInstanceOf(Block::class, $landing_banner);
    $this->assertSame('localgov_consultations_landing_banner', $landing_banner->getPluginId());
    $this->assertSame('/consultations', $landing_banner->getVisibility()['request_path']['pages']);

    $page_banner = Block::load('localgov_consultations_page_banner');
    $this->assertInstanceOf(Block::class, $page_banner);
    $this->assertSame('localgov_consultations_page_banner', $page_banner->getPluginId());
    $this->assertSame('/consultations/*', $page_banner->getVisibility()['request_path']['pages']);
  }

  /**
   * Tests the landing banner block builds with the module fallback image.
   */
  public function testLandingBannerFallbackBuild(): void {
    $block = $this->container->get('plugin.manager.block')->createInstance('localgov_consultations_landing_banner');
    $build = $block->build();

    $this->assertSame(['localgov-consultations--banner-block-wrapper'], $build['#attributes']['class']);
    $this->assertSame(['localgov-consultations--banner-image'], $build['banner_wrapper']['#attributes']['class']);
    $this->assertStringEndsWith('/images/localgov_consultations_demo_image.jpg', $build['banner_wrapper']['banner_image']['#uri']);
    $this->assertSame('LocalGov Consultations banner', (string) $build['banner_wrapper']['banner_image']['#alt']);
    $this->assertArrayHasKey('exposed_wrapper', $build);
  }

  /**
   * Tests the landing banner block stores uploaded file configuration.
   */
  public function testLandingBannerSubmitStoresFileUsage(): void {
    $file = File::create([
      'uri' => 'public://test-banner.jpg',
      'filename' => 'test-banner.jpg',
      'status' => 0,
    ]);
    $file->save();

    $block = $this->container->get('plugin.manager.block')->createInstance('localgov_consultations_landing_banner');
    $form_state = new FormState();
    $form_state->setValue('image', [$file->id()]);
    $form_state->setValue('alt_text', 'Uploaded consultation banner');

    $block->blockSubmit([], $form_state);

    $configuration = $block->getConfiguration();
    $this->assertSame((int) $file->id(), $configuration['image_fid']);
    $this->assertSame('Uploaded consultation banner', $configuration['alt_text']);
    $this->assertTrue((bool) File::load($file->id())->isPermanent());
  }

  /**
   * Tests the page banner block is empty when the route is not a consultation.
   */
  public function testPageBannerWithoutRouteNodeBuildsEmpty(): void {
    $block = $this->container->get('plugin.manager.block')->createInstance('localgov_consultations_page_banner');

    $this->assertSame([], $block->build());
    $this->assertContains('route', $block->getCacheContexts());
  }

}
