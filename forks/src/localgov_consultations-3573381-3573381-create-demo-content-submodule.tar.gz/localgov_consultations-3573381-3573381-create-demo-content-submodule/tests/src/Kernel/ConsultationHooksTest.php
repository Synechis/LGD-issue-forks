<?php

declare(strict_types=1);

namespace Drupal\Tests\localgov_consultations\Kernel;

use Drupal\paragraphs\Entity\Paragraph;
use PHPUnit\Framework\Attributes\Group;

/**
 * Tests module hook implementations.
 */
#[Group('localgov_consultations')]
final class ConsultationHooksTest extends ConsultationsKernelTestBase {

  /**
   * Tests hook_theme() exposes the module templates.
   */
  public function testThemeHooks(): void {
    $themes = localgov_consultations_theme([], 'module', 'localgov_consultations', 'modules/contrib/localgov_consultations');

    $this->assertArrayHasKey('node__consultation', $themes);
    $this->assertArrayHasKey('node__consultation__teaser', $themes);
    $this->assertArrayHasKey('views_view__consultations', $themes);
    $this->assertArrayHasKey('field__node__localgov_consultation_date__consultation', $themes);
    $this->assertArrayHasKey('field__node__localgov_consultation_timeline__consultation', $themes);
    $this->assertArrayHasKey('paragraph__localgov_consultation_tl_steps', $themes);
    $this->assertArrayHasKey('paragraph__localgov_consultation_timeline', $themes);
  }

  /**
   * Tests consultation node preprocessing adds display date data.
   */
  public function testNodePreprocessDisplayDate(): void {
    $node = $this->createConsultation([
      'localgov_consultation_date' => [
        'value' => $this->formatDate('-30 days'),
        'end_value' => $this->formatDate('+30 days'),
      ],
    ]);
    $variables = [
      'node' => $node,
      'view_mode' => 'full',
    ];

    localgov_consultations_preprocess_node($variables);

    $this->assertArrayHasKey('consultation_display_date', $variables);
    $this->assertStringContainsString('Closes on', (string) $variables['consultation_display_date']['#markup']);
    $this->assertStringContainsString('consultation-status-label open', $variables['consultation_display_date']['#prefix']);
    $this->assertContains('localgov_consultations/localgov_consultations', $variables['#attached']['library']);
  }

  /**
   * Tests consultation timeline paragraph preprocessing.
   */
  public function testTimelineStepPreprocess(): void {
    $complete = Paragraph::create([
      'type' => 'localgov_consultation_tl_steps',
      'localgov_title' => 'Complete step',
      'localgov_consultation_complete' => TRUE,
      'localgov_consultation_date' => $this->formatDate('+1 day'),
    ]);
    $complete->save();
    $complete_variables = ['paragraph' => $complete];

    localgov_consultations_preprocess_paragraph($complete_variables);

    $this->assertTrue($complete_variables['is_complete']);
    $this->assertTrue($complete_variables['date_is_past_or_today']);

    $past = Paragraph::create([
      'type' => 'localgov_consultation_tl_steps',
      'localgov_title' => 'Past step',
      'localgov_consultation_complete' => FALSE,
      'localgov_consultation_date' => $this->formatDate('-1 day'),
    ]);
    $past->save();
    $past_variables = ['paragraph' => $past];

    localgov_consultations_preprocess_paragraph($past_variables);

    $this->assertFalse($past_variables['is_complete']);
    $this->assertTrue($past_variables['date_is_past_or_today']);
  }

}
