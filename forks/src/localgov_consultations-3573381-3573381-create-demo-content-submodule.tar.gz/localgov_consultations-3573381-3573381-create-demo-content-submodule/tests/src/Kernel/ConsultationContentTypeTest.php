<?php

declare(strict_types=1);

namespace Drupal\Tests\localgov_consultations\Kernel;

use Drupal\field\Entity\FieldConfig;
use Drupal\field\Entity\FieldStorageConfig;
use Drupal\node\Entity\NodeType;
use Drupal\node\NodeInterface;
use Drupal\paragraphs\Entity\Paragraph;
use Drupal\paragraphs\Entity\ParagraphsType;

/**
 * Tests consultation content model and node creation.
 *
 * @group localgov_consultations
 */
final class ConsultationContentTypeTest extends ConsultationsKernelTestBase {

  /**
   * Tests the consultation bundle and important fields are installed.
   */
  public function testConsultationContentModel(): void {
    $node_type = NodeType::load('consultation');
    $this->assertInstanceOf(NodeType::class, $node_type);
    $this->assertSame('Consultation', $node_type->label());
    $this->assertTrue($node_type->shouldCreateNewRevision());

    $expected_fields = [
      'body',
      'localgov_common_tasks',
      'localgov_consultation_banner',
      'localgov_consultation_categories',
      'localgov_consultation_contact',
      'localgov_consultation_date',
      'localgov_consultation_dept',
      'localgov_consultation_documents',
      'localgov_consultation_link',
      'localgov_consultation_location',
      'localgov_consultation_rs_link',
      'localgov_consultation_rs_summary',
      'localgov_consultation_status',
      'localgov_consultation_summary',
      'localgov_consultation_teaser_img',
      'localgov_consultation_timeline',
    ];

    foreach ($expected_fields as $field_name) {
      $this->assertInstanceOf(
        FieldConfig::class,
        FieldConfig::load("node.consultation.$field_name"),
        "$field_name field config exists."
      );
    }

    $status_storage = FieldStorageConfig::load('node.localgov_consultation_status');
    $this->assertSame('list_string', $status_storage->getType());
    $this->assertSame([
      'upcoming' => 'Upcoming',
      'open' => 'Open',
      'closed' => 'Closed',
      'complete' => 'Concluded',
    ], $status_storage->getSetting('allowed_values'));

    $this->assertSame('daterange', FieldStorageConfig::load('node.localgov_consultation_date')->getType());
    $this->assertInstanceOf(ParagraphsType::class, ParagraphsType::load('localgov_consultation_timeline'));
    $this->assertInstanceOf(ParagraphsType::class, ParagraphsType::load('localgov_consultation_tl_steps'));
  }

  /**
   * Tests a basic consultation node can be saved with installed fields.
   */
  public function testConsultationNodeCreation(): void {
    $node = $this->createConsultation([
      'title' => 'Road layout consultation',
      'body' => [
        'value' => 'Tell us what you think about the proposed road layout.',
        'format' => 'plain_text',
      ],
      'localgov_consultation_summary' => 'A short consultation summary.',
      'localgov_consultation_link' => [
        'uri' => 'https://example.com/respond',
        'title' => 'Respond to this consultation',
      ],
      'localgov_consultation_date' => [
        'value' => '2026-06-01',
        'end_value' => '2026-06-30',
      ],
    ]);

    $this->assertSame('consultation', $node->bundle());
    $this->assertSame(NodeInterface::PUBLISHED, (int) $node->get('status')->value);
    $this->assertSame('Road layout consultation', $node->label());
    $this->assertSame('upcoming', $node->get('localgov_consultation_status')->value);
    $this->assertSame('2026-06-01', $node->get('localgov_consultation_date')->value);
    $this->assertSame('2026-06-30', $node->get('localgov_consultation_date')->end_value);
    $this->assertSame('A short consultation summary.', $node->get('localgov_consultation_summary')->value);
    $this->assertSame('Respond to this consultation', $node->get('localgov_consultation_link')->title);
  }

  /**
   * Tests timeline paragraph data can be saved for a consultation.
   */
  public function testConsultationTimelineParagraphCreation(): void {
    $step = Paragraph::create([
      'type' => 'localgov_consultation_tl_steps',
      'localgov_title' => 'Consultation opens',
      'localgov_consultation_date' => '2026-06-01',
      'localgov_consultation_summary' => 'Residents can submit feedback.',
      'localgov_consultation_complete' => FALSE,
    ]);
    $step->save();

    $timeline = Paragraph::create([
      'type' => 'localgov_consultation_timeline',
      'localgov_consultation_steps' => [
        [
          'target_id' => $step->id(),
          'target_revision_id' => $step->getRevisionId(),
        ],
      ],
    ]);
    $timeline->save();

    $node = $this->createConsultation([
      'localgov_consultation_timeline' => [
        [
          'target_id' => $timeline->id(),
          'target_revision_id' => $timeline->getRevisionId(),
        ],
      ],
    ]);

    $this->assertCount(1, $node->get('localgov_consultation_timeline')->referencedEntities());
    $this->assertSame('Consultation opens', $step->get('localgov_title')->value);
  }

}
