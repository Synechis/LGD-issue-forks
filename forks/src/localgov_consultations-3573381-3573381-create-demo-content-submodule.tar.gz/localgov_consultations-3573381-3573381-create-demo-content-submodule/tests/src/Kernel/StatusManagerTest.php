<?php

declare(strict_types=1);

namespace Drupal\Tests\localgov_consultations\Kernel;

use Drupal\node\Entity\Node;
use Drupal\node\NodeInterface;

/**
 * Tests date-based consultation status changes.
 *
 * @group localgov_consultations
 */
final class StatusManagerTest extends ConsultationsKernelTestBase {

  /**
   * Tests automatic status changes based on consultation dates.
   */
  public function testDateBasedStatusUpdates(): void {
    $past_start = $this->formatDate('-10 days');
    $past_end = $this->formatDate('-1 day');
    $today = $this->formatDate('today');
    $future_start = $this->formatDate('+1 day');
    $future_end = $this->formatDate('+10 days');

    $to_open = $this->createConsultation([
      'title' => 'Ready to open',
      'localgov_consultation_status' => 'upcoming',
      'localgov_consultation_date' => [
        'value' => $past_start,
        'end_value' => $future_end,
      ],
    ]);
    $to_close = $this->createConsultation([
      'title' => 'Ready to close',
      'localgov_consultation_status' => 'open',
      'localgov_consultation_date' => [
        'value' => $past_start,
        'end_value' => $past_end,
      ],
    ]);
    $open_until_end_of_today = $this->createConsultation([
      'title' => 'Open through closing date',
      'localgov_consultation_status' => 'open',
      'localgov_consultation_date' => [
        'value' => $past_start,
        'end_value' => $today,
      ],
    ]);
    $future = $this->createConsultation([
      'title' => 'Still upcoming',
      'localgov_consultation_status' => 'upcoming',
      'localgov_consultation_date' => [
        'value' => $future_start,
        'end_value' => $future_end,
      ],
    ]);
    $complete = $this->createConsultation([
      'title' => 'Already concluded',
      'localgov_consultation_status' => 'complete',
      'localgov_consultation_date' => [
        'value' => $past_start,
        'end_value' => $past_end,
      ],
    ]);
    $unpublished = $this->createConsultation([
      'title' => 'Unpublished ready to open',
      'status' => NodeInterface::NOT_PUBLISHED,
      'localgov_consultation_status' => 'upcoming',
      'localgov_consultation_date' => [
        'value' => $past_start,
        'end_value' => $future_end,
      ],
    ]);

    $result = $this->container
      ->get('localgov_consultations.status_manager')
      ->updateConsultationStatuses();

    $this->assertSame(['opened' => 1, 'closed' => 1], $result);
    $this->assertSame('open', Node::load($to_open->id())->get('localgov_consultation_status')->value);
    $this->assertSame('closed', Node::load($to_close->id())->get('localgov_consultation_status')->value);
    $this->assertSame('open', Node::load($open_until_end_of_today->id())->get('localgov_consultation_status')->value);
    $this->assertSame('upcoming', Node::load($future->id())->get('localgov_consultation_status')->value);
    $this->assertSame('complete', Node::load($complete->id())->get('localgov_consultation_status')->value);
    $this->assertSame('upcoming', Node::load($unpublished->id())->get('localgov_consultation_status')->value);
  }

  /**
   * Tests cron delegates to the status manager.
   */
  public function testCronUpdatesConsultationStatuses(): void {
    $node = $this->createConsultation([
      'localgov_consultation_status' => 'upcoming',
      'localgov_consultation_date' => [
        'value' => $this->formatDate('-1 day'),
        'end_value' => $this->formatDate('+1 day'),
      ],
    ]);

    localgov_consultations_cron();

    $this->assertSame('open', Node::load($node->id())->get('localgov_consultation_status')->value);
  }

}
