<?php

declare(strict_types=1);

namespace Drupal\Tests\localgov_consultations\Functional;

use Drupal\Tests\node\Traits\NodeCreationTrait;
use Drupal\datetime\Plugin\Field\FieldType\DateTimeItemInterface;
use Drupal\node\NodeInterface;
use PHPUnit\Framework\Attributes\Group;
use PHPUnit\Framework\Attributes\IgnoreDeprecations;
use PHPUnit\Framework\Attributes\RunTestsInSeparateProcesses;

/**
 * Tests the consultations listing page at /consultations.
 *
 * @see https://www.drupal.org/project/drupal/issues/3302838
 */
#[Group('localgov_consultations')]
#[IgnoreDeprecations]
#[RunTestsInSeparateProcesses]
class ConsultationHomePageTest extends ConsultationsFunctionalTestBase {

  use NodeCreationTrait;

  /**
   * {@inheritdoc}
   */
  protected static $configSchemaCheckerExclusions = [
    // Missing schema for entity reference handler settings.
    'field.field.node.consultation.localgov_consultation_contact',
    // Missing schema for field_group settings.
    'core.entity_form_display.node.consultation.default',
    // Missing schema for media_library_edit third-party settings.
    // See https://www.drupal.org/project/media_library_edit/issues/3315757.
    'core.entity_form_display.paragraph.localgov_image.default',
    // Missing schema in geo_entity_address for leaflet field formatter
    // settings.
    'core.entity_form_display.geo_entity.address.default',
    'core.entity_form_display.geo_entity.address.inline',
  ];

  /**
   * {@inheritdoc}
   */
  protected static $modules = [
    'localgov_consultations_home_page',
  ];

  /**
   * Tests the /consultations page loads with expected elements.
   */
  public function testConsultationsPageLoads(): void {
    $this->drupalGet('/consultations');
    $this->assertSession()->statusCodeEquals(200);
    $this->assertSession()->pageTextContains('Consultations');

    // Test banner image exists.
    $this->assertSession()->elementExists('css', '.localgov-consultations--banner-block-wrapper');
    $this->assertSession()->elementExists('css', '.localgov-consultations--banner-image');
    // Test filters present.
    $this->assertSession()->fieldExists('title');
    $this->assertSession()->fieldExists('localgov_consultation_status_value');
  }

  /**
   * Tests a published consultation appears in the listing.
   */
  public function testPublishedConsultationAppearsInListing(): void {
    $this->createNode([
      'type' => 'consultation',
      'title' => 'Road Improvements Consultation',
      'status' => NodeInterface::PUBLISHED,
      'localgov_consultation_status' => 'open',
      'localgov_consultation_date' => [
        'value' => $this->formatDate('-1 day'),
        'end_value' => $this->formatDate('+10 days'),
      ],
    ]);

    $this->drupalGet('/consultations');
    $this->assertSession()->pageTextContains('Road Improvements Consultation');
  }

  /**
   * Tests an unpublished consultation does not appear in the listing.
   */
  public function testUnpublishedConsultationHiddenFromListing(): void {
    $this->createNode([
      'type' => 'consultation',
      'title' => 'Hidden Draft Consultation',
      'status' => NodeInterface::NOT_PUBLISHED,
      'uid' => 1,
      'localgov_consultation_status' => 'upcoming',
      'localgov_consultation_date' => [
        'value' => $this->formatDate('+1 day'),
        'end_value' => $this->formatDate('+10 days'),
      ],
    ]);

    $this->drupalGet('/consultations');
    $this->assertSession()->pageTextNotContains('Hidden Draft Consultation');
  }

  /**
   * Tests filtering the listing by consultation status via URL parameter.
   */
  public function testStatusFilterNarrowsResults(): void {
    $this->createNode([
      'type' => 'consultation',
      'title' => 'Open Consultation Result',
      'status' => NodeInterface::PUBLISHED,
      'localgov_consultation_status' => 'open',
      'localgov_consultation_date' => [
        'value' => $this->formatDate('-1 day'),
        'end_value' => $this->formatDate('+10 days'),
      ],
    ]);
    $this->createNode([
      'type' => 'consultation',
      'title' => 'Upcoming Consultation Result',
      'status' => NodeInterface::PUBLISHED,
      'localgov_consultation_status' => 'upcoming',
      'localgov_consultation_date' => [
        'value' => $this->formatDate('+1 day'),
        'end_value' => $this->formatDate('+10 days'),
      ],
    ]);

    $this->drupalGet('/consultations', ['query' => ['localgov_consultation_status_value' => 'open']]);
    $this->assertSession()->pageTextContains('Open Consultation Result');
    $this->assertSession()->pageTextNotContains('Upcoming Consultation Result');
  }

  /**
   * Tests filtering the listing by keyword via URL parameter.
   */
  public function testKeywordFilterNarrowsResults(): void {
    $this->createNode([
      'type' => 'consultation',
      'title' => 'Parking Zone Consultation',
      'status' => NodeInterface::PUBLISHED,
      'localgov_consultation_status' => 'open',
      'localgov_consultation_date' => [
        'value' => $this->formatDate('-1 day'),
        'end_value' => $this->formatDate('+10 days'),
      ],
    ]);
    $this->createNode([
      'type' => 'consultation',
      'title' => 'Library Closure Consultation',
      'status' => NodeInterface::PUBLISHED,
      'localgov_consultation_status' => 'open',
      'localgov_consultation_date' => [
        'value' => $this->formatDate('-1 day'),
        'end_value' => $this->formatDate('+10 days'),
      ],
    ]);

    $this->drupalGet('/consultations', ['query' => ['title' => 'Parking']]);
    $this->assertSession()->pageTextContains('Parking Zone Consultation');
    $this->assertSession()->pageTextNotContains('Library Closure Consultation');
  }

  /**
   * Formats a relative date string for a consultation date range field.
   */
  protected function formatDate(string $relative): string {
    return gmdate(DateTimeItemInterface::DATE_STORAGE_FORMAT, strtotime($relative));
  }

}
