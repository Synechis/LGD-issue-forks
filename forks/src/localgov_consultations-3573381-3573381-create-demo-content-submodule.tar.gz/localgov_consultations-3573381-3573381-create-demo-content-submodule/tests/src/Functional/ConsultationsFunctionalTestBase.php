<?php

declare(strict_types=1);

namespace Drupal\Tests\localgov_consultations\Functional;

use Drupal\Tests\BrowserTestBase;
use Symfony\Component\DependencyInjection\ContainerInterface;

/**
 * Base class for consultation functional tests.
 */
abstract class ConsultationsFunctionalTestBase extends BrowserTestBase {

  /**
   * {@inheritdoc}
   */
  protected $profile = 'testing';

  /**
   * {@inheritdoc}
   */
  protected $defaultTheme = 'stark';

  /**
   * Installs prerequisite and test modules in dependency-safe stages.
   *
   * The testing profile does not provide the distribution configuration that
   * LocalGov Consultations expects. Installing each static module group through
   * the BrowserTestBase setup phase makes that configuration available before
   * the next group is validated.
   *
   * {@inheritdoc}
   */
  protected function installModulesFromClassProperty(ContainerInterface $container): void {
    $test_modules = static::$modules;

    try {
      $container->get('config.storage')->write(
        'field.storage.node.body',
        [
          'langcode' => 'en',
          'status' => TRUE,
          'dependencies' => [
            'module' => [
              'node',
              'text',
            ],
          ],
          'id' => 'node.body',
          'field_name' => 'body',
          'entity_type' => 'node',
          'type' => 'text_with_summary',
          'settings' => [],
          'module' => 'text',
          'locked' => FALSE,
          'cardinality' => 1,
          'translatable' => TRUE,
          'indexes' => [],
          'persist_with_no_fields' => TRUE,
          'custom_storage' => FALSE,
        ],
      );

      static::$modules = [
        'field_ui',
        'node',
        'options',
        'path',
        'localgov_core',
        'localgov_media',
        'localgov_media_test_config',
      ];
      parent::installModulesFromClassProperty($container);

      static::$modules = [
        'localgov_paragraphs',
      ];
      parent::installModulesFromClassProperty($this->container);

      static::$modules = $test_modules;
      parent::installModulesFromClassProperty($this->container);
    }
    finally {
      static::$modules = $test_modules;
    }
  }

}
