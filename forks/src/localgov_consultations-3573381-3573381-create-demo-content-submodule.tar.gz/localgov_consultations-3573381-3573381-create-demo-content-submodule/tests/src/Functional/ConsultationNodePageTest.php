<?php

declare(strict_types=1);

namespace Drupal\Tests\localgov_consultations\Functional;

use Drupal\Tests\node\Traits\NodeCreationTrait;
use Drupal\datetime\Plugin\Field\FieldType\DateTimeItemInterface;
use Drupal\node\NodeInterface;
use PHPUnit\Framework\Attributes\DataProvider;
use PHPUnit\Framework\Attributes\Group;
use PHPUnit\Framework\Attributes\IgnoreDeprecations;
use PHPUnit\Framework\Attributes\RunTestsInSeparateProcesses;

/**
 * Tests individual consultation node pages.
 *
 * @see https://www.drupal.org/project/drupal/issues/3302838
 */
#[Group('localgov_consultations')]
#[IgnoreDeprecations]
#[RunTestsInSeparateProcesses]
class ConsultationNodePageTest extends ConsultationsFunctionalTestBase {

  use NodeCreationTrait;

  /**
   * {@inheritdoc}
   */
  protected static $configSchemaCheckerExclusions = [
    // Missing schema for entity reference handler settings.
    'field.field.node.consultation.localgov_consultation_contact',
    // Missing schema for field_group settings.
    'core.entity_form_display.node.consultation.default',
    // Missing schema for media_library_edit third-party settings.
    // See https://www.drupal.org/project/media_library_edit/issues/3315757.
    'core.entity_form_display.paragraph.localgov_image.default',
    // Missing schema in geo_entity_address for leaflet field formatter
    // settings.
    'core.entity_form_display.geo_entity.address.default',
    'core.entity_form_display.geo_entity.address.inline',
  ];

  /**
   * {@inheritdoc}
   */
  protected static $modules = [
    'localgov_consultations_node_page',
  ];

  /**
   * Tests a consultation node page loads and shows the title.
   */
  public function testConsultationNodePageLoads(): void {
    $node = $this->createNode([
      'type' => 'consultation',
      'title' => 'Town Centre Regeneration Consultation',
      'status' => NodeInterface::PUBLISHED,
      'localgov_consultation_status' => 'open',
      'localgov_consultation_date' => [
        'value' => $this->formatDate('-1 day'),
        'end_value' => $this->formatDate('+10 days'),
      ],
    ]);

    $this->drupalGet($node->toUrl()->toString());
    $this->assertSession()->statusCodeEquals(200);
    $this->assertSession()->pageTextContains('Town Centre Regeneration Consultation');
  }

  /**
   * Tests the status label rendered for each consultation status.
   */
  #[DataProvider('consultationStatusProvider')]
  public function testConsultationShowsStatus(string $status, string $startOffset, string $endOffset, string $expectedLabel): void {
    $node = $this->createNode([
      'type' => 'consultation',
      'title' => 'Consultation Status Test',
      'status' => NodeInterface::PUBLISHED,
      'localgov_consultation_status' => $status,
      'localgov_consultation_date' => [
        'value' => $this->formatDate($startOffset),
        'end_value' => $this->formatDate($endOffset),
      ],
    ]);
    $this->drupalGet($node->toUrl()->toString());
    $this->assertSession()->elementContains('css', '.consultation__status', $expectedLabel);
  }

  /**
   * Provides consultation statuses and their expected labels.
   */
  public static function consultationStatusProvider(): array {
    return [
      'open' => ['open', '-1 day', '+30 days', 'Open'],
      'upcoming' => ['upcoming', '+5 days', '+30 days', 'Upcoming'],
      'closed' => ['closed', '-30 days', '-1 day', 'Closed'],
    ];
  }

  /**
   * Tests a consultation node with a body renders the body text.
   */
  public function testConsultationBodyTextRendered(): void {
    $node = $this->createNode([
      'type' => 'consultation',
      'title' => 'Consultation With Body',
      'status' => NodeInterface::PUBLISHED,
      'localgov_consultation_status' => 'open',
      'body' => [
        'value' => 'This consultation asks residents for their views on local planning.',
        'format' => 'plain_text',
      ],
      'localgov_consultation_date' => [
        'value' => $this->formatDate('-1 day'),
        'end_value' => $this->formatDate('+10 days'),
      ],
    ]);

    $this->drupalGet($node->toUrl()->toString());
    $this->assertSession()->pageTextContains('This consultation asks residents for their views on local planning.');
  }

  /**
   * Tests a results summary is rendered on a completed consultation page.
   */
  public function testConsultationResultsSummaryRendered(): void {
    $node = $this->createNode([
      'type' => 'consultation',
      'title' => 'Consultation With Results Summary',
      'status' => NodeInterface::PUBLISHED,
      'localgov_consultation_status' => 'complete',
      'localgov_consultation_rs_summary' => [
        'value' => 'A brief summary of the consultation results.',
        'format' => 'plain_text',
      ],
      'localgov_consultation_date' => [
        'value' => $this->formatDate('-30 days'),
        'end_value' => $this->formatDate('-1 day'),
      ],
    ]);

    $this->drupalGet($node->toUrl()->toString());
    $this->assertSession()->pageTextContains('A brief summary of the consultation results.');
  }

  /**
   * Formats a relative date string for a consultation date range field.
   */
  protected function formatDate(string $relative): string {
    return gmdate(DateTimeItemInterface::DATE_STORAGE_FORMAT, strtotime($relative));
  }

}
