<?php

namespace Drupal\localgov_directories\Hook;

use Drupal\Core\Form\FormStateInterface;
use Drupal\search_api\IndexInterface;
use Drupal\facets\FacetInterface;
use Drupal\localgov_directories\ConfigurationHelper;
use Drupal\localgov_directories\Constants;
use Drupal\field\FieldConfigInterface;
use Drupal\Core\Entity\ContentEntityInterface;
use Drupal\pathauto\Entity\PathautoPattern;
use Drupal\Core\Entity\Display\EntityViewDisplayInterface;
use Drupal\node\NodeInterface;
use Drupal\localgov_directories\DirectoryExtraFieldDisplay;
use Drupal\Core\Hook\Attribute\Hook;

/**
 * Hook implementations for localgov_directories.
 */
class LocalgovDirectoriesHooks {

  /**
   * Implements hook_theme().
   */
  #[Hook('theme')]
  public function theme() {
    return [
      'localgov_directories_facets' => [
        'render element' => 'elements',
      ],
      'facets_item_list__links__localgov_directories_facets' => [
        'base hook' => 'facets_item_list',
      ],
          // Facets for proximity search look no different.
      'facets_item_list__links__localgov_directories_facets_proximity_search' => [
        'base hook' => 'facets_item_list',
        'template' => 'facets-item-list--links--localgov-directories-facets',
      ],
          // Facet Checkboxes are rendered through Javascript.  So the same markup as
          // "link" Facets suffices.
      'facets_item_list__checkbox__localgov_directories_facets' => [
        'base hook' => 'facets_item_list',
        'template' => 'facets-item-list--links--localgov-directories-facets',
      ],
      'facets_item_list__checkbox__localgov_directories_facets_proximity_search' => [
        'base hook' => 'facets_item_list',
        'template' => 'facets-item-list--links--localgov-directories-facets',
      ],
      'facets_item_list__dropdown__localgov_directories_facets' => [
        'base hook' => 'facets_item_list',
        'template' => 'facets-item-list--dropdown--localgov-directories-facets',
      ],
      'facets_item_list__dropdown__localgov_directories_facets_proximity_search' => [
        'base hook' => 'facets_item_list',
        'template' => 'facets-item-list--dropdown--localgov-directories-facets',
      ],
      'checkboxes__localgov_directories_facets' => [
        'base hook' => 'checkboxes',
      ],
      'bef_checkboxes_directory_facets' => [
        'render element' => 'element',
        'base_hook' => 'bef_checkboxes',
      ],
    ];
  }

  /**
   * Implements hook_modules_installed().
   */
  #[Hook('modules_installed')]
  public function modulesInstalled($modules, $is_syncing) {
    $services = in_array('localgov_services_navigation', $modules, TRUE);
    if ($is_syncing) {
      return;
    }
    if ($services) {
      \Drupal::service('config.installer')->installOptionalConfig(NULL, [
        'config' => 'field.storage.node.localgov_services_parent',
      ]);
      localgov_directories_optional_fields_settings($services);
    }
  }

  /**
   * Implements hook_entity_extra_field_info().
   */
  #[Hook('entity_extra_field_info')]
  public function entityExtraFieldInfo() {
    return \Drupal::service('class_resolver')->getInstanceFromDefinition(DirectoryExtraFieldDisplay::class)->entityExtraFieldInfo();
  }

  /**
   * Implements hook_ENTITY_TYPE_view().
   */
  #[Hook('node_view')]
  public function nodeView(array &$build, NodeInterface $node, EntityViewDisplayInterface $display, $view_mode) {
    return \Drupal::service('class_resolver')->getInstanceFromDefinition(DirectoryExtraFieldDisplay::class)->nodeView($build, $node, $display, $view_mode);
  }

  /**
   * Implements hook_pathauto_pattern_alter().
   */
  #[Hook('pathauto_pattern_alter')]
  public function pathautoPatternAlter(PathautoPattern $pattern, array $context) {
    // If pathauto isn't set to include this entity into directory, but
    // it has opt-ed in with the field add the (optional) parent to the path.
    $entity = reset($context['data']);
    assert($entity instanceof ContentEntityInterface);
    if ($entity->hasField('localgov_directory_channels') && strpos($pattern->getPattern(), '[node:localgov_directory_channels:0:entity:url:path]') === FALSE) {
      $pattern->setPattern('[node:localgov_directory_channels:0:entity:url:path]/' . $pattern->getPattern());
    }
  }

  /**
   * Implements hook_ENTITY_TYPE_insert().
   *
   * - Mark new Directory entry content type for indexing.
   * - Display the Directory channel search block on pages of this new Directory
   *   entry content type.
   */
  #[Hook('field_config_insert')]
  public function fieldConfigInsert(FieldConfigInterface $field) {
    if ($field->getName() == Constants::CHANNEL_SELECTION_FIELD) {
      \Drupal::classResolver(ConfigurationHelper::class)->insertedDirectoryChannelField($field);
    }
    elseif ($field->getName() == Constants::FACET_SELECTION_FIELD) {
      \Drupal::classResolver(ConfigurationHelper::class)->insertedFacetField($field);
    }
    elseif ($field->getName() == Constants::TITLE_SORT_FIELD) {
      \Drupal::classResolver(ConfigurationHelper::class)->insertedTitleSortField($field);
    }
  }

  /**
   * Implements hook_ENTITY_TYPE_insert().
   *
   * - Load optional configuration (presently facet blocks) when the facet is
   *   configured.
   */
  #[Hook('facets_facet_insert')]
  public function facetsFacetInsert(FacetInterface $facet) {
    \Drupal::service('config.installer')->installOptionalConfig(NULL, [
      'config' => 'facets.facet.' . $facet->id(),
    ]);
  }

  /**
   * Implements hook_ENTITY_TYPE_delete().
   */
  #[Hook('field_config_delete')]
  public function fieldConfigDelete(FieldConfigInterface $field) {
    if ($field->getName() == Constants::CHANNEL_SELECTION_FIELD) {
      \Drupal::classResolver(ConfigurationHelper::class)->deletedDirectoryChannelField($field);
    }
  }

  /**
   * Implements hook_ENTITY_TYPE_update().
   */
  #[Hook('search_api_index_update')]
  public function searchApiIndexUpdate(IndexInterface $index) {
    if ($index->status() && $index->getField(Constants::FACET_INDEXING_FIELD)) {
      \Drupal::classResolver(ConfigurationHelper::class)->createFacet(Constants::FACET_CONFIG_ENTITY_ID, Constants::FACET_CONFIG_FILE);
    }
  }

  /**
   * Implements hook_theme_suggestions_HOOK_alter() for hook_theme_suggestions_checkbox_alter().
   */
  #[Hook('theme_suggestions_checkboxes_alter')]
  public function themeSuggestionsCheckboxesAlter(array &$suggestions, array $variables) {
    $is_dir_facet_checkbox = isset($variables['element']['#name']) ? $variables['element']['#name'] === Constants::FACET_CONFIG_ENTITY_ID || $variables['element']['#name'] === Constants::FACET_CONFIG_ENTITY_ID_FOR_PROXIMITY_SEARCH : FALSE;
    if ($is_dir_facet_checkbox) {
      $suggestions[] = 'checkboxes__localgov_directories_facets';
    }
  }

  /**
   * Implements hook_form_FORM_ID_alter() for hook_form_facets_form_alter().
   *
   * Hides form submit buttons for an empty LocalGov Directory facet form.
   *
   * @see Drupal\facets\FacetManager\DefaultFacetManager::build()
   */
  #[Hook('form_facets_form_alter')]
  public function formFacetsFormAlter(array &$form, FormStateInterface $form_state) {
    $has_empty_dir_facet = FALSE;
    if (isset($form['facets'][Constants::FACET_CONFIG_ENTITY_ID][0]['#attributes']['class'][0])) {
      $has_empty_dir_facet = $form['facets'][Constants::FACET_CONFIG_ENTITY_ID][0]['#attributes']['class'][0] === Constants::FACET_EMPTY_CLASS;
    }
    elseif (isset($form['facets'][Constants::FACET_CONFIG_ENTITY_ID_FOR_PROXIMITY_SEARCH][0]['#attributes']['class'][0])) {
      $has_empty_dir_facet = $form['facets'][Constants::FACET_CONFIG_ENTITY_ID_FOR_PROXIMITY_SEARCH][0]['#attributes']['class'][0] === Constants::FACET_EMPTY_CLASS;
    }
    if ($has_empty_dir_facet) {
      $form['actions']['#attributes']['class'][] = 'hidden';
    }
  }

  /**
   * Implements hook_leaflet_map_view_style_alter().
   */
  #[Hook('leaflet_map_view_style_alter')]
  public function leafletMapViewStyleAlter(&$js_settings, $leaflet_map) {
    // Add a value to the map if there are no features.
    // https://github.com/localgovdrupal/localgov_directories/issues/229#issuecomment-1271418506
    // This can be used in template if needed.
    $js_settings['map']['is_empty'] = empty($js_settings['features']);
  }

  /**
   * Implements hook_facets_search_api_query_type_mapping_alter().
   */
  #[Hook('facets_search_api_query_type_mapping_alter')]
  public function facetsSearchApiQueryTypeMappingAlter($backend_plugin_id, array &$query_types) {
    $query_types['localgov_directories'] = 'localgov_directories_query_type';
  }

}
