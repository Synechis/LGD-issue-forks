<?php

declare(strict_types=1);

namespace Drupal\localgov_forms\Hook;

use Drupal\Component\Utility\NestedArray;
use Drupal\Core\Render\Element;
use Drupal\Core\Form\FormStateInterface;
use Drupal\Core\Hook\Attribute\Hook;
use Drupal\Core\Url;
use Drupal\Core\Security\TrustedCallbackInterface;
use Drupal\Core\StringTranslation\TranslatableMarkup;
use Drupal\webform\WebformInterface;
use Drupal\webform\WebformSubmissionForm;
use Drupal\webform\WebformThirdPartySettingsManager;
use Drupal\webform\Entity\Webform;

/**
 * Theme related hooks.
 */
class ThemeHooks implements TrustedCallbackInterface {

  /**
   * @var array
   *   Input element types not to attach to.
   */
  public static array $skipTypes = [];

  /**
   * Construct a new class.
   *
   * @param \Drupal\webform\WebformThirdPartySettingsManager $webformThirdPartySettings
   *   Webform third party settings manager.
   */
  public function __construct(protected WebformThirdPartySettingsManager $webformThirdPartySettings) {
  }

  /**
   * {@inheritdoc}
   */
  public static function trustedCallbacks() {
    return ['optionalPreRender', 'addressOptionalPreRender'];
  }

  #[Hook('form_webform_settings_form_alter')]
  public function webformSettingsForm(&$form, FormStateInterface $form_state, $form_id) {
    $webform = $form_state->getFormObject()->getEntity();
    assert($webform instanceof WebformInterface);

    $form['third_party_settings']['localgov_forms'] = [
      '#type' => 'details',
      '#title' => new TranslatableMarkup('LocalGov Forms'),
    ];
    $form['third_party_settings']['localgov_forms']['description'] = [
      '#markup' => new TranslatableMarkup('<p>The default values for these can be found in <a href="@webform_configuration">Webforms: Forms configuration</a>.</p>', [
        '@webform_configuration' => Url::fromRoute('webform.config')->toString(),
      ]),
    ];
    $form['third_party_settings']['localgov_forms']['mark_optional'] = [
      '#type' => 'radios',
      '#options' => [
        '' => new TranslatableMarkup('Default'),
        'enabled' => new TranslatableMarkup('Enabled'),
        'disabled' => new TranslatableMarkup('Disabled'),
      ],
      '#title' => new TranslatableMarkup("Add '(optional)' to non-required elements"),
      '#description' => new TranslatableMarkup('If checked GDS forms style addition to the label title.'),
      '#default_value' => $webform->getThirdPartySetting('localgov_forms', 'mark_optional', ''),
    ];
    $form['third_party_settings']['localgov_forms']['gds_required'] = [
      '#type' => 'radios',
      '#options' => [
        '' => new TranslatableMarkup('Default'),
        'enabled' => new TranslatableMarkup('Enabled'),
        'disabled' => new TranslatableMarkup('Disabled'),
      ],
      '#title' => new TranslatableMarkup("Default required message to GDS style"),
      '#description' => new TranslatableMarkup('Uses Enter field, rathen than Field required.'),
      '#default_value' => $webform->getThirdPartySetting('localgov_forms', 'gds_required', ''),
    ];
  }

  #[Hook('webform_admin_third_party_settings_form_alter')]
  public function webformAdminForm(&$form, FormStateInterface $form_state) {
    $form['third_party_settings']['localgov_forms'] = [
      '#type' => 'details',
      '#title' => new TranslatableMarkup('LocalGov Forms'),
    ];
    $form['third_party_settings']['localgov_forms']['mark_optional'] = [
      '#type' => 'checkbox',
      '#title' => new TranslatableMarkup("Add '(optional)' to non-required elements"),
      '#description' => new TranslatableMarkup('If checked, by default, use the GDS forms style addition to the label title.'),
      '#default_value' => $this->webformThirdPartySettings->getThirdPartySetting('localgov_forms', 'mark_optional') ?: FALSE,
    ];
    $form['third_party_settings']['localgov_forms']['gds_required'] = [
      '#type' => 'checkbox',
      '#title' => new TranslatableMarkup("Default required message to GDS style"),
      '#description' => new TranslatableMarkup('If checked, by default, uses "Enter {field}", rathen than "{Field} required".'),
      '#default_value' => $this->webformThirdPartySettings->getThirdPartySetting('localgov_forms', 'gds_required') ?: FALSE,
    ];
  }

  #[Hook('element_info_alter')]
  public function elementInfoAlter(array &$types): void {
    if ($this->webformThirdPartySettings->getThirdPartySetting('localgov_forms', 'mark_optional') ?: FALSE) {
      foreach ($types as $type => $info) {
        if (($info['#input'] ?? FALSE) && !in_array($type, static::$skipTypes, TRUE)) {
          $types[$type]['#after_build'][] = [static::class, 'optionalElement'];
          $types[$type]['#pre_render'][] = [static::class, 'optionalPreRender'];
        }
      }
      // localgov_webform_uk_address sub-fields don't reliably receive the
      // (optional) label via the generic per-element after_build/pre_render
      // above, because intermediate form rebuilds (caused by #states on
      // wizard pages) discard the modification before final render. Instead,
      // handle this composite at its own level: a pre_render on the composite
      // itself runs only when the composite is genuinely being rendered, and
      // can safely edit its children's render arrays in place.
      if (isset($types['localgov_webform_uk_address'])) {
        $types['localgov_webform_uk_address']['#pre_render'][] = [static::class, 'addressOptionalPreRender'];
      }
    }

    if ($this->webformThirdPartySettings->getThirdPartySetting('localgov_forms', 'gds_required') ?: FALSE) {
      foreach ($types as $type => $info) {
        if (($info['#input'] ?? FALSE) && !in_array($type, static::$skipTypes, TRUE)) {
          $types[$type]['#after_build'][] = [static::class, 'gdsRequired'];
        }
      }
    }
    if (isset($types['localgov_forms_date'])) {

      array_unshift(
        $types['localgov_forms_date']['#element_validate'],
        [static::class, 'normalizeConditionalRequired']
      );

      $types['localgov_forms_date']['#element_validate'][] = [
        static::class,
        'clearHiddenWizardPageErrors',
      ];
    }    
  }

  /**
   * Normalise Webform composite conditional required state.
   *
   * Webform composites replace #required with #_required when the field's
   * required state depends on #states. Core Datelist and LocalgovFormsDate
   * validation only checks #required, causing required validation to be
   * skipped for date elements inside composites.
   */
  public static function normalizeConditionalRequired(
    array &$element,
    FormStateInterface $form_state,
    array &$complete_form
  ): void {

    if (!empty($element['#_required']) && empty($element['#required'])) {
      $element['#required'] = TRUE;
    }
  }
  /**
   * Remove validation errors from hidden wizard pages.
   *
   * When localgov_forms_date exists on wizard pages hidden via #states,
   * date validation may execute for elements that are not on the page
   * currently being submitted. Remove those errors so they do not block
   * submission or mask errors on the visible page.
   */
  public static function clearHiddenWizardPageErrors(
    array &$element,
    FormStateInterface $form_state,
    array &$complete_form
  ): void {

    $webform_parents = $element['#webform_parents'] ?? [];

    if (empty($webform_parents)) {
      return;
    }

    $current_page = $form_state->get('current_page');
    $element_page = $webform_parents[0] ?? NULL;

    if (!$current_page || !$element_page || $current_page === $element_page) {
      return;
    }

    $element_id = implode('][', $element['#parents']);

    $errors = $form_state->getErrors();

    $form_state->clearErrors();

    foreach ($errors as $key => $message) {

      if (
        $key === $element_id ||
        str_starts_with($key, $element_id . '][')
      ) {
        continue;
      }

      $form_state->setErrorByName($key, $message);
    }
  }

  /**
   * Pre-render callback for the localgov_webform_uk_address element.
   *
   * Adds '(optional)' to the labels of non-required sub-fields
   * (address_1, address_2, town_city, postcode).
   *
   * The composite's #process step inconsistently maps YAML's
   * #sub__required (two underscores) onto the render array - only
   * address_lookup, address_1, and postcode receive a #sub___required
   * (three underscores) property, and address_2/town_city never receive
   * any equivalent property regardless of configuration. Rather than rely
   * on these inconsistent render-array properties, this reads the
   * original element configuration directly from the webform entity -
   * the source of truth for #sub__required - giving consistent behaviour
   * across all four sub-fields.
   *
   * This runs as a pre_render on the composite itself, which only fires
   * when the composite is genuinely being rendered - avoiding the
   * after_build/pre_render timing issues that occur on #states-conditional
   * wizard pages.
   *
   * @param array $build
   *   The composite element's render array.
   *
   * @return array
   *   The, potentially altered, render array.
   */
  public static function addressOptionalPreRender(array $build): array {
    $sub_fields = ['address_1', 'address_2', 'town_city', 'postcode'];
    $required_check_fields = array_merge(['address_lookup'], $sub_fields);

    $webform_id = $build['#webform'] ?? NULL;
    $webform_key = $build['#webform_key'] ?? NULL;

    if (!$webform_id || !$webform_key) {
      return $build;
    }

    $webform = Webform::load($webform_id);
    if (!$webform) {
      return $build;
    }

    $element_config = $webform->getElementDecoded($webform_key) ?? [];

    // If none of the sub-fields are required, the whole address is
    // effectively optional - don't mark individual fields, matching the
    // behaviour for other element types.
    $has_required = FALSE;
    foreach ($required_check_fields as $sub) {
      if (!empty($element_config['#' . $sub . '__required'])) {
        $has_required = TRUE;
        break;
      }
    }

    if (!$has_required) {
      return $build;
    }

    foreach ($sub_fields as $sub) {
      if (!isset($build[$sub]) || !is_array($build[$sub]) || !isset($build[$sub]['#title'])) {
        continue;
      }

      // Skip if the generic per-element mechanism (optionalElement, during
      // #after_build) already handled this field.
      if (isset($build[$sub]['#lgd_optional'])) {
        continue;
      }

      // Skip if we've already processed this field ourselves.
      if (isset($build[$sub]['#lgd_address_optional_done'])) {
        continue;
      }

      // Skip if this sub-field is required, per the original config.
      if (!empty($element_config['#' . $sub . '__required'])) {
        continue;
      }

      $build[$sub]['#title'] = $build[$sub]['#title'] . ' <span class="localgov-form-optional">'
        . new TranslatableMarkup('(optional)')
        . '</span>';
      $build[$sub]['#attributes']['class'][] = 'lgd-optional';

      // Intentionally NOT setting #lgd_optional - that flag would cause
      // this child's own #pre_render (optionalPreRender) to append a
      // second (optional) label.
      $build[$sub]['#lgd_address_optional_done'] = TRUE;
    }

    return $build;
  }

  /**
   * After build callback.
   *
   * Add '(optional)' to appropriate non-required element titles.
   *
   * @param array $element
   *   The form element.
   * @param \Drupal\Core\Form\FormStateInterface $form_state
   *   The form state.
   *
   * @return array
   *   The, potentially altered, form element.
   */
  static function optionalElement(array $element, FormStateInterface $form_state): array {
    if ($form_state->getFormObject() instanceof WebformSubmissionForm &&
      ($webform = $form_state->getFormObject()->getEntity()->getWebform()) &&
      static::isEnabled('mark_optional', $webform)
    ) {
      $type = $element['#type'];
      if ($type === 'checkbox' || $type === 'radio') {
        // If it is desired to add optional to single checkboxes there will be
        // a single parent with the same name as the checkbox in #parents.
        // A checkbox in a checkboxes list will have at least two parents.
        return $element;
      }

      // Computed 'fields' are input fields.
      if ($type === 'item' && isset($element['#webform_plugin_id'])) {
        if ($element['#webform_plugin_id'] === 'webform_computed_twig' || $element['#webform_plugin_id'] === 'webform_computed_token') {
          return $element;
        }
      }

      $form = $form_state->getCompleteForm();
      $parents = $element['#array_parents'];
      array_pop($parents);
      $parent = NestedArray::getValue($form, $parents);
      $parent_type = $parent['#type'] ?? '';

      // Don't show optional on the 'other' textfield from select_or_other.
      if (
        in_array($parent_type, ['webform_select_other', 'webform_radios_other', 'webform_checkboxes_other'], TRUE)
        && $type === 'textfield'
      ) {
        return $element;
      }

      // Don't show optional on date parts.
      if ($parent_type === 'localgov_forms_date') {
        return $element;
      }

      // Don't show optional on every field if whole address optional.
      if ($parent_type === 'localgov_webform_uk_address') {
        $all_optional = TRUE;
        foreach (Element::children($parent) as $sibling_name) {
          $sibling = $parent[$sibling_name];
          if ($sibling['#access'] && isset($sibling['#required']) && $sibling['#required']) {
            $all_optional = FALSE;
            break;
          }
        }
        if ($all_optional) {
          return $element;
        }
      }

      // Seems conditionally required will trigger this,
      // if default required, it's then disable with JS.
      if (
        // Standard forms.
        $element['#required'] === FALSE &&
        // Composite form elements.
        !(isset($element['#_required']) && $element['#_required'] === TRUE)
      ) {
        $element['#lgd_optional'] = TRUE;
        $element['#attached']['library'][] = 'localgov_forms/localgov_forms.state';
      }
    }

    return $element;
  }

  /**
   * Element pre-render callback.
   *
   * If after build based on the element within the form this is an optional
   * element, add output details.
   *
   * @param array $build
   *   Render array.
   *
   * @return array
   *   Render array, altered as appropriate.
   */
  public static function optionalPreRender(array $build): array {
    if (isset($build['#lgd_optional']) && isset($build['#title'])) {
      $id = $build['#attributes']['data-drupal-selector'] ?? $build['#id'];
      $build['#title'] .= ' <span data-lgd-webform-optional="' . $build['#id'] . '" class="localgov-form-optional">'
        . new TranslatableMarkup('(optional)')
        . '</span>';
      // This could be all done only in js to this .lgd-optional > label.
      $build['#attributes']['class'][] = 'lgd-optional';
    }
    return $build;
  }

  /**
   * After build callback.
   *
   * @param array $element
   *   The form element.
   * @param \Drupal\Core\Form\FormStateInterface $form_state
   *   The form state.
   *
   * @return array
   *   The, potentially altered, form element.
   */
  static function gdsRequired(array $element, FormStateInterface $form_state): array {
    if ($form_state->getFormObject() instanceof WebformSubmissionForm &&
      ($webform = $form_state->getFormObject()->getEntity()->getWebform()) &&
      static::isEnabled('gds_required', $webform) &&
      array_key_exists('#required', $element) &&
      isset($element['#title']) && !isset($element['#required_error'])
    ) {
      // GDS style is English, but we translate it anyway, because...?
      $title = strtolower((string) $element['#title']);
      $article = in_array(substr($title, 0, 1), ['a', 'e', 'i', 'o', 'u'], TRUE) ? 'an' : 'a';
      // These are cast directly to strings as there are webform elements
      // that pass required_error through a TranslatableMarkup.
      if (in_array($element['#type'], ['checkboxes', 'radios', 'select'], TRUE)) {
        $element['#required_error'] = (string) new TranslatableMarkup(
          'Select @article @title', [
            '@article' => $article,
            '@title' => $title,
          ]
        );
      }
      if (in_array($element['#type'], ['file', 'managed_file', 'webform_document_file', 'webform_image_file'], TRUE)) {
        $element['#required_error'] = (string) new TranslatableMarkup(
          'Upload @article @title', [
            '@article' => $article,
            '@title' => $title,
          ]
        );
      }
      else {
        $element['#required_error'] = (string) new TranslatableMarkup(
          'Enter @article @title', [
            '@article' => $article,
            '@title' => $title,
          ]
        );
      }
    }

    return $element;
  }

  /**
   * Check if a Third Party Setting is enabled.
   *
   * Individual webform setting, or default.
   *
   * @param string $setting
   *   The setting key.
   * @param \Drupal\webform\WebformInterface $webform
   *   The individual webform.
   *
   * @return bool
   *   TRUE if enabled.
   */
  private static function isEnabled(string $setting, WebformInterface $webform): bool {
    $webform_setting = $webform->getThirdPartySetting('localgov_forms', $setting);
    if ($webform_setting === 'enabled') {
      return TRUE;
    }
    elseif ($webform_setting === 'disabled') {
      return FALSE;
    }
    return \Drupal::service('webform.third_party_settings_manager')->getThirdPartySetting('localgov_forms', $setting, FALSE);
  }

}
