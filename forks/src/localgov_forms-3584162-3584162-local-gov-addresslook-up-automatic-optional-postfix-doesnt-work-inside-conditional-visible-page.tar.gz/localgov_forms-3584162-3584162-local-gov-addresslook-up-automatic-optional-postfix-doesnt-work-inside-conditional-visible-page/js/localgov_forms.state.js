/**
 * @file
 * Additional JavaScript behaviors for webform #states.
 */
(function ($, Drupal, once) {

  'use strict';

  /**
   * Update the "(optional)" label for a form element.
   *
   * @param {HTMLElement} element
   *   The form element or its wrapper.
   * @param {boolean} isRequired
   *   Whether the element is currently required.
   */
  function updateOptionalLabel(element, isRequired) {
    // This was the id / selector when we added the optional. It can get wrapped, and the state is moved
    // onto the container. Probably a better way of doing this.
    var id = element.attributes['data-drupal-selector']?.value ??
      element.firstElementChild?.attributes['data-drupal-selector']?.value;
    var $optional = $();
    if (id) {
      $optional = $('span[data-lgd-webform-optional="' + id + '"]');
      if (!$optional.length && element.id) {
        $optional = $('span[data-lgd-webform-optional="' + element.id + '"]');
      }
    }
    if (!$optional.length) {
      $optional = $(element).find('span.localgov-form-optional');
    }
    if ($optional.length) {
      $optional.html(isRequired ? '' : Drupal.t('(optional)'));
    }
  }

  // Handle #states changes.
  $(document).on('state:required', function (e) {
    updateOptionalLabel(e.target, e.value);
  });

  // Handle initial load, AJAX, submit with validation errors.
  Drupal.behaviors.localgovFormsState = {
    attach: function (context) {
      $(once('lgd-optional-init', '.lgd-optional', context)).each(function () {
        var isRequired = this.hasAttribute('required') ||
          $(this).closest('.js-form-item').find('[required]').length > 0;
        updateOptionalLabel(this, isRequired);
      });
    }
  };

})(jQuery, Drupal, once);
