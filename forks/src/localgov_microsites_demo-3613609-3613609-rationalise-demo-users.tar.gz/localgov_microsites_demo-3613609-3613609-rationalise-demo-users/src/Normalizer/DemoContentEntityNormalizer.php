<?php

namespace Drupal\localgov_microsites_demo\Normalizer;

use Drupal\Core\Entity\ContentEntityInterface;
use Drupal\default_content\Normalizer\ContentEntityNormalizer;

/**
 * Extends default content normalization for microsites demo exports.
 */
class DemoContentEntityNormalizer extends ContentEntityNormalizer {

  /**
   * {@inheritdoc}
   */
  protected function getFieldsToNormalize(ContentEntityInterface $entity): array {
    $fields = parent::getFieldsToNormalize($entity);

    // Group relationship exports need gid preserved for stable imports.
    if ($entity->getEntityTypeId() === 'group_relationship' && $entity->hasField('gid') && !in_array('gid', $fields, TRUE)) {
      $fields[] = 'gid';
    }

    return $fields;
  }

}
