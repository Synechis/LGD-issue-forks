# LocalGov Microsites Demo Content

Example content for demonstrating LocalGov Microsites and helping local
development.

## Hostnames are set to DDEV domains by default

When this module is installed, it creates or updates
domain records for the three demo microsites with these hostnames:

- `localgov-micro-1.ddev.site`
- `localgov-micro-2.ddev.site`
- `localgov-micro-3.ddev.site`

Notes:
- If your local environment uses different hostnames, update each domain record
  after install.

## Scope and install assumptions

This module is demo content intended for clean installs of Drupal.

- Config-sync installation paths are out of scope.
- The install hook intentionally skips work when module installation is part of
  config sync.

## What this module does

- Creates 3 Microsites
- - Scarfolk Independent Living
- - Scarfolk People's Park
- - Scarfolk Digital Blog
- Creates 6 users
- - living-controller
- - living-editor
- - park-controller
- - park-editor
- - blog-controller
- - blog-editor
- Provides demo content via the `default_content` module.
- Includes groups, users, relationships, nodes, taxonomy terms, files, and
  media entities.
- Optional: on module install, creates or updates per-group domain settings for demo microsites (hostname, site name, slogan, and front page). Defaults are provided.

## Updating exported default content

From the Drupal web root, export content already listed in
`localgov_microsites_demo.info.yml`:

```bash
drush dcem localgov_microsites_demo
```

## Adding new demo content

1. Add the new entity UUID(s) to `localgov_microsites_demo.info.yml`.
2. Export the entity and its references:

```bash
drush dcer <entity_type> <entity_id> --folder=modules/contrib/localgov_microsites_demo/content/
```

Notes:

1. `--folder` is relative to the Drupal web root.
2. Do not prefix `--folder` with `/`.
3. Keep UUID lists in `localgov_microsites_demo.info.yml` in sync with the
   exported files.

## Running tests

From the Drupal web root, run the kernel test class for this module:

```bash
php ./core/scripts/run-tests.sh --php /usr/bin/php --module localgov_microsites_demo --class "Drupal\\Tests\\localgov_microsites_demo\\Kernel\\DemoInstallKernelTest"
```

## Reference

- Default Content module docs:
  <https://www.drupal.org/docs/extending-drupal/contributed-modules/contributed-module-documentation/default-content>
